Refactored MF->Java/NET modernization core project structure.

> **Notice (pipelines v2).** As soon as the new pipeline is crafted as a Claude plugin - avoid changes in `actuals/`.
> I make and test every change in the working folder(s), then build the plugin, overwriting the changes in `actuals/`!
> A convenient way to contribute changes will be set up soon. For now, if you would like to change anything in the pipeline - contact me (Yauhen Peshkur).

Initial state is tagged as `v0.1`.

Current state: **v2.3.0** - pipelines plugin 2.3.0 (`mu-design`, `mu-implement`, `mu-build-tests`, `mu-validate`, `mu-report`).
Quick review: [actuals/docs/pipelines/README.md](actuals/docs/pipelines/README.md); installation and steps:
[actuals/docs/pipelines/pipeline_v2.md](actuals/docs/pipelines/pipeline_v2.md).

| Tag | Content |
|---|---|
| `v0.1` | initial state |
| `v1.0` | pipelines v1 |
| `v2.0` | pipelines plugin 2.0 (`mu-design`, `mu-implement`) |
| `v2.1` | pipelines plugin 2.1.0: + `mu-build-tests`, `mu-validate`, `actuals/tools/e2e-framework` |
| `v2.2` | pipelines plugin 2.2.0: + `mu-report` (one HTML page with the test results of an MU), templates and docs updated |
| - | pipelines plugin 2.2.1 (not tagged yet): fix wave 1 - recording run key includes the check SQL, pending decisions reported, `runnerImage` in recording fingerprints (default container `parity-cobol-runner`), `golden-db2` required by `mu-build-tests` (no fallback to `db2`), decided answers reported apart from the legacy ones, stricter `DECISION` failure class |
| `v2.3` | pipelines plugin 2.3.0: MU `boundaries` (extraction/design stop at other MUs' entry points, `--mu`), SERVICE archetype, self-contained `<name>.usage.md` for clients, hand-written run stubs in `unit/stubs/` |


## Repository Structure

The repository is organized into three main areas: `actuals`, `works`, and `archive`.

```text
.claude-plugin/          marketplace of the pipelines plugin
actuals/
+-- pipelines/           the pipelines plugin (skills, scripts, templates)
+-- tools/
|   +-- parity-tester/
|   +-- e2e-framework/
+-- docs/
|   +-- pipelines/
+-- scripts/
|   +-- token-count/
+-- other/

works/
+-- pipelines/
+-- tools/
+-- portfolios-split/
+-- claude-session-tracker/

archive/
+-- pipelines_v1/
+-- conductor_v1/
+-- works/
|   +-- pipelines_v1/
|   +-- pipelines_v2/
|   +-- validation_v2/
+-- initial-state/

.gitattributes
.gitignore
README.md
```

### `.claude-plugin/`

`marketplace.json`: the marketplace `mainframe-modernization` that publishes the `pipelines` plugin from `actuals/pipelines/`.

### `actuals/`

Contains the **current, actively used project artifacts**.

This area contains cleaned and ready-to-use artifacts and does not include intermediate working files created during their development or preparation.

* **`actuals/pipelines/`**
  The `pipelines` Claude Code plugin (v2.3.0): the commands `mu-init`, `mflens-login`, `mu-design`, `mu-implement`, `mu-build-tests`, `mu-validate`, `mu-report`, the skills they use, shared scripts and templates.

* **`actuals/tools/`**
  Local tools the pipelines use, copied into a workspace's `tools/`.

  * **`actuals/tools/parity-tester/`**
    COBOL runner (GnuCOBOL with CA Gen shims) and Db2; used by `mu-design` and `mu-build-tests`.

  * **`actuals/tools/e2e-framework/`**
    Replay test framework (Cucumber, golden masters, fixtures, comparator); used by `mu-validate`.

* **`actuals/docs/`**
  Contains documentation and tutorials for the artifacts published under `actuals`, intended for use by the team.

  * **`actuals/docs/pipelines/`**
    `README.md` (quick review) and `pipeline_v2.md` (installation, workspace set-up, steps, updates).

* **`actuals/scripts/`**
  Contains supporting scripts used by the project.

  * **`actuals/scripts/token-count/`**
    Contains scripts for parsing orchestrator execution history and calculating token usage and execution statistics. These scripts originate from `mf-cobol-to-dotnet-java-agents/scripts`.

* **`actuals/other/`**
  Contains other reusable project artifacts that do not belong to the categories above: `claude-session-tracker` and `session-tracker-server` (session status line and its server), `code-review` (review command for generated solutions), `pipeline-support` (investigation of pipeline execution artifacts), `java-du-archetype` (Maven project archetype/template originating from `agent-works/java-spring-mu-library-project`).

### `works/`

Contains **work-in-progress materials and intermediate artifacts**.

This area is used for active development, preparation of documents and reusable components, exchange of working artifacts, experiments, and other materials that are not yet ready to be published under `actuals`.

* **`works/pipelines/`**
  The workplace that collects all pipeline changes (skills, templates, scripts); the source for releasing the plugin into `actuals/pipelines/`.

* **`works/tools/`**
  Working tools folder (`parity-tester`, `e2e-framework`) to improve; the source for releasing the tools into `actuals/tools/`.

* **`works/portfolios-split/`**
  Working area for script development by Andrey and Alexey.

* **`works/claude-session-tracker/`**
  Session tracker for Claude work.

### `archive/`

Contains **legacy, obsolete, historical, and other materials that should be preserved but are no longer part of the active project structure**.

Most of the previous contents of the core repository are stored here. Relevant artifacts are gradually moved or reworked into either:

* `actuals/` when they become clean, reusable project artifacts;
* `works/` when they require further development or preparation.

* **`archive/pipelines_v1/`**
  Previous version of the distributable pipelines (formerly `actuals/pipelines/`) and their documentation.

* **`archive/conductor_v1/`**
  The v1 conductor driving the AS-IS, TSA and LLD pipelines.

* **`archive/works/pipelines_v1/`**
  Former `works/pipelines/`: working notes and blueprints of the v1 pipeline development (originates from the `agent-works` workspace).

* **`archive/works/pipelines_v2/`**, **`archive/works/validation_v2/`**
  Former `works/pipelines_v2/` and `works/validation_v2/`: obsolete v2 workspaces, replaced by `works/pipelines/` and `works/tools/`.

* **`archive/initial-state/`**
  The initial repository state.

### `.gitattributes`, `.gitignore`

Line-ending rules, and repository-wide exclusions for local and generated files that should not be committed: personal agent configurations, caches, temporary files, locally generated artifacts and similar development-specific files.

### `README.md`

Provides the repository overview and documents its structure, the purpose of the main directories, and where different types of project artifacts are located.

## Directory Usage Principle

The overall lifecycle of an artifact is:

```text
works/  --> actuals/
   |
   +------> archive/
```

* **`works`** - artifacts currently being developed or prepared.
* **`actuals`** - clean, current artifacts ready for project/team use.
* **`archive`** - historical or obsolete artifacts retained for reference.

This separation keeps production-ready project assets isolated from work-in-progress materials and historical repository content.
