> **Notice (pipelines v2).** As soon as the new pipeline is crafted as a Claude plugin - avoid changes in `actuals/`.
> I make and test every change in the working folder(s), then build the plugin, overwriting the changes in `actuals/`!
> A convenient way to contribute changes will be set up soon. For now, if you would like to change anything in the pipeline - contact me (Yauhen Peshkur).

Folder entries description:

- pipelines/ - the migration pipeline v2 (plugin version 2.3.0) as the Claude Code plugin `pipelines`: commands `mu-init`, `mflens-login`, `mu-design`, `mu-implement`, `mu-build-tests`, `mu-validate`, `mu-report`. Claude Code installs it from this repository by itself (no clone; nothing is copied into the client repo) - see docs/pipelines/pipeline_v2.md, quick review in docs/pipelines/README.md.

- tools/ - local tools required by pipelines v2, each downloaded separately into the workspace's `tools/` (see the same doc):
  - tools/parity-tester/ - COBOL runner and Db2; used by `mu-design` and `mu-build-tests`.
  - tools/e2e-framework/ - replay test framework; used by `mu-validate`.

- scripts/ - here are the scripts that can support you in different tasks, however they are NOT a part of pipelines set.

- docs/ - user/developer documentation on any artefacts in this (i.e. 'actuals') folder.

- other/ - any support artefacts for pipeline or migration usage.

- other/claude-session-tracker/ - helper tool to track session spendings for pipeline executors (works and tested for console)
