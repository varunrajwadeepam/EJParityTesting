package org.example.demo.mu;

import org.springframework.stereotype.Service;

/** Synthetic service point of the synthetic MU. */
@Service
public class GreetingService {

    public record GreetingRequest(String name) {
    }

    public record GreetingResponse(String greeting) {
    }

    public GreetingResponse greet(GreetingRequest request) {
        return new GreetingResponse("HELLO " + request.name());
    }
}
