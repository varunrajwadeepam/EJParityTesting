package org.example.demo;

import org.example.demo.mu.GreetingService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.Clock;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Synthetic application class (default component scan: org.example.demo) with a REST API over the MU's service. */
@SpringBootApplication
public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    @Bean
    public Clock clock() {
        return Clock.systemDefaultZone();
    }

    @RestController
    public static class GreetingController {

        private final GreetingService service;
        private final Clock clock;

        public GreetingController(GreetingService service, Clock clock) {
            this.service = service;
            this.clock = clock;
        }

        @GetMapping("/greetings/{name}")
        public ResponseEntity<Map<String, Object>> greet(@PathVariable String name,
                                                         @RequestParam(defaultValue = "") String punctuation) {
            if ("DOWN".equals(name)) {
                return ResponseEntity.status(503).body(Map.of("status", 503, "error", "Service Unavailable"));
            }
            Map<String, Object> body = new LinkedHashMap<>();
            body.put("greeting", service.greet(new GreetingService.GreetingRequest(name)).greeting() + punctuation);
            body.put("today", LocalDate.now(clock).toString());
            body.put("items", List.of(Map.of("code", "G    ", "text", "GREETING")));
            return ResponseEntity.ok(body);
        }
    }
}
