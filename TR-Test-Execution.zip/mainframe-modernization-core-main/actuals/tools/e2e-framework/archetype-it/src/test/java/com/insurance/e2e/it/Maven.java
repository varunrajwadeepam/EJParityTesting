package com.insurance.e2e.it;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/** Runs a nested Maven build with the private IT repository (head) chained to the user's repository (tail). */
final class Maven {

    record Result(int exitCode, String log, Path logFile) {
        boolean succeeded() {
            return exitCode == 0;
        }
    }

    private final Path repository;
    private final Path tail;
    private final Path mavenHome;

    Maven(Path repository, Path tail, Path mavenHome) {
        this.repository = repository;
        this.tail = tail;
        this.mavenHome = mavenHome;
    }

    Result run(Path directory, String logName, String... arguments) throws IOException, InterruptedException {
        return run(directory, logName, java.util.Map.of(), arguments);
    }

    /** As {@link #run(Path, String, String...)}, with extra environment variables (the run-level E2E settings). */
    Result run(Path directory, String logName, java.util.Map<String, String> environment, String... arguments)
            throws IOException, InterruptedException {
        List<String> command = new ArrayList<>();
        command.add(executable().toString());
        command.add("-B");
        command.add("-ntp");
        command.add("-Dmaven.repo.local=" + repository);
        command.add("-Dmaven.repo.local.tail=" + tail);
        command.addAll(List.of(arguments));
        Path log = directory.resolveSibling(logName + ".log");
        ProcessBuilder builder = new ProcessBuilder(command)
                .directory(directory.toFile())
                .redirectErrorStream(true)
                .redirectOutput(log.toFile());
        builder.environment().putAll(environment);
        Process process = builder.start();
        if (!process.waitFor(20, TimeUnit.MINUTES)) {
            process.destroyForcibly();
            throw new IllegalStateException("Maven did not finish within 20 minutes: " + command);
        }
        return new Result(process.exitValue(), Files.readString(log, StandardCharsets.UTF_8), log);
    }

    private Path executable() {
        boolean windows = System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win");
        return mavenHome.resolve("bin").resolve(windows ? "mvn.cmd" : "mvn");
    }
}
