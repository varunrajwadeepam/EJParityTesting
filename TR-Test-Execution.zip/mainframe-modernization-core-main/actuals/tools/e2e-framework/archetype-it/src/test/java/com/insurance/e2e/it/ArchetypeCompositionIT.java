package com.insurance.e2e.it;

import com.insurance.e2e.core.golden.GoldenMaster;
import com.insurance.e2e.core.golden.GoldenMasterStore;
import com.insurance.e2e.core.golden.Lifecycle;
import com.insurance.e2e.core.golden.LifecycleState;
import com.insurance.e2e.core.golden.Provenance;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.observation.Outcome;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.jar.JarFile;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Generates and builds a test solution for a synthetic mini-product, exactly as the engine stage's scaffold does:
 * <ol>
 *   <li>build the product snapshot with tests and repackaging skipped (the plain app jar must be usable);</li>
 *   <li>generate the basement archetype into an empty staging directory and copy it into place;</li>
 *   <li>generate the MU archetype into another empty staging directory, copy it, add the aggregator's module line;</li>
 *   <li>build the generated reactor in the default profile - no services: the empty dynamic-test factory and the
 *       empty Cucumber suite must run without errors, the basement smoke test must skip;</li>
 *   <li>add a register and a view mapping (what the design stage writes) and build the MU module again: the
 *       register lint must pass with the plugins on the classpath;</li>
 *   <li>add what the design stage writes for an imported golden-master package (1.1 register with HTTP requests and
 *       declared statuses, payload mapping, signed profile, accepted recordings, the generated feature): the default
 *       profile lints the features against the register and the golden masters; the replay profile executes them -
 *       the real application boots with a web server, every runnable scenario goes over HTTP with its clock pinned, a
 *       declared N/A or block is reported, a difference is a result (the build succeeds with test failures ignored,
 *       as the execute stage runs it).</li>
 * </ol>
 */
class ArchetypeCompositionIT {

    static final String MARKER = "<!-- e2e:mu-modules";

    static Path work;
    static Maven maven;
    static String frameworkVersion;
    static String archetypePlugin;

    @BeforeAll
    static void setUp() throws IOException {
        Path repository = Path.of(System.getProperty("e2e.it.repo"));
        Path tail = Path.of(System.getProperty("e2e.it.tail"));
        frameworkVersion = System.getProperty("e2e.framework.version");
        archetypePlugin = "org.apache.maven.plugins:maven-archetype-plugin:"
                + System.getProperty("e2e.archetype.plugin.version") + ":generate";
        maven = new Maven(repository, tail, Path.of(System.getProperty("maven.home")));
        work = Path.of(System.getProperty("e2e.it.work")).resolve("run-" + System.currentTimeMillis());
        Files.createDirectories(work);
        stageParentPom(repository, Path.of(System.getProperty("e2e.framework.root")));
    }

    @Test
    void theGeneratedTestSolutionBuildsAgainstASyntheticProduct() throws Exception {
        Path product = work.resolve("product");
        copyTree(resource("mini-product"), product);
        Maven.Result snapshot = maven.run(product, "01-product-snapshot", "install", "-DskipTests",
                "-Dspring-boot.repackage.skip=true");
        assertThat(snapshot.succeeded()).as("product snapshot build, see %s", snapshot.logFile()).isTrue();
        assertPlainApplicationJar();

        Path solution = work.resolve("solution-e2e");
        Path basementStaging = Files.createDirectories(work.resolve("staging-basement"));
        Maven.Result basement = maven.run(basementStaging, "02-generate-basement", archetypePlugin,
                "-DinteractiveMode=false",
                "-DarchetypeGroupId=com.insurance.archetypes",
                "-DarchetypeArtifactId=modernization-e2e-basement-archetype",
                "-DarchetypeVersion=" + frameworkVersion,
                "-DgroupId=org.example.demo", "-DartifactId=solution-e2e", "-Dversion=1.0.0-SNAPSHOT",
                "-Dpackage=e2e.org.example.demo",
                "-DappId=demo", "-DappMainClass=org.example.demo.DemoApplication", "-DappBasePackage=org.example.demo",
                "-DappGroupId=org.example.demo", "-DappArtifactId=demo-app", "-DproductVersion=1.0.0-SNAPSHOT",
                "-DspringBootVersion=" + System.getProperty("e2e.spring.boot.version"),
                "-DframeworkVersion=" + frameworkVersion, "-DreenableDataSource=true",
                "-DoutputDirectory=" + basementStaging);
        assertThat(basement.succeeded()).as("basement generation, see %s", basement.logFile()).isTrue();
        copyTree(basementStaging.resolve("solution-e2e"), solution);

        assertThat(solution.resolve(".gitignore")).hasContent("**/target/");
        assertThat(Files.readString(solution.resolve("demo-e2e-parent/pom.xml")))
                .contains("<artifactId>spring-boot-starter-parent</artifactId>", "<artifactId>modernization-e2e-bom</artifactId>",
                        "<cucumber.version>7.21.1</cucumber.version>", "<id>e2e-replay</id>", "${project.basedir}",
                        "org.example.demo:*-e2e");
        assertThat(Files.readString(solution.resolve("demo-e2e-basement/src/main/resources/application-e2e.yml")))
                .contains("exclude: []", "url: ${E2E_DB_URL}", "schema: ${E2E_DB_SCHEMA}", "port: 0");
        assertThat(Files.readString(solution.resolve("demo-e2e-basement/src/main/resources/e2e/logback-e2e.xml")))
                .contains("<file>target/e2e-reports/application.log</file>", "<level>WARN</level>");
        assertThat(Files.readString(solution.resolve(
                "demo-e2e-basement/src/test/java/e2e/org/example/demo/RealApplicationSmokeTest.java")))
                .contains("@EnabledIf(\"e2e.org.example.demo.E2eBasement#validationDatabaseConfigured\")",
                        "classes = org.example.demo.DemoApplication.class",
                        "@DynamicPropertySource", "E2eBasement.targetProperties()");
        assertThat(Files.readString(solution.resolve("README.md"))).contains("## Build").doesNotContain("$h2");

        Path muStaging = Files.createDirectories(solution.resolve("target").resolve("scaffold-staging").resolve("mu"));
        Maven.Result mu = maven.run(muStaging, "03-generate-mu", archetypePlugin,
                "-DinteractiveMode=false",
                "-DarchetypeGroupId=com.insurance.archetypes",
                "-DarchetypeArtifactId=modernization-mu-e2e-archetype",
                "-DarchetypeVersion=" + frameworkVersion,
                "-DgroupId=org.example.demo", "-DartifactId=demo-mu-e2e", "-Dversion=1.0.0-SNAPSHOT",
                "-Dpackage=e2e.org.example.demo.mu",
                "-DappId=demo", "-DmuId=mu", "-DmuClassPrefix=DemoMu", "-DmuName=MU-DEMO-01",
                "-DproductGroupId=org.example.demo", "-DproductModuleArtifactId=demo-mu",
                "-DoutputDirectory=" + muStaging);
        assertThat(mu.succeeded()).as("MU module generation, see %s", mu.logFile()).isTrue();
        copyTree(muStaging.resolve("demo-mu-e2e"), solution.resolve("demo-mu-e2e"));
        insertModule(solution.resolve("pom.xml"), "demo-mu-e2e");

        Path module = solution.resolve("demo-mu-e2e");
        assertThat(module.resolve("src/test/java/e2e/org/example/demo/mu/DemoMuParityTest.java")).exists();
        assertThat(module.resolve("src/test/java/e2e/org/example/demo/mu/DemoMuBehaviourSuite.java")).exists();
        assertThat(module.resolve("src/test/resources/e2e/features/README.md")).exists();
        assertThat(Files.readString(module.resolve("src/test/resources/e2e/mu.yaml"))).contains("mu: MU-DEMO-01");
        assertThat(module.resolve("src/test/resources/e2e/phrasebook.yaml")).exists();

        Maven.Result build = maven.run(solution, "04-build-default-profile", "verify");
        assertThat(build.succeeded()).as("default-profile build, see %s", build.logFile()).isTrue();
        assertThat(build.log())
                .contains("Running e2e.org.example.demo.mu.DemoMuParityTest")
                .contains("Running e2e.org.example.demo.mu.DemoMuBehaviourSuite")
                .contains("Running e2e.org.example.demo.RealApplicationSmokeTest")
                .contains("BUILD SUCCESS");
        assertThat(surefireReport(module, "DemoMuParityTest")).contains("failures=\"0\"").contains("errors=\"0\"");

        writeDesignArtifacts(module);
        Maven.Result lint = maven.run(solution, "05-build-with-register", "verify", "-pl", "demo-mu-e2e", "-am");
        assertThat(lint.succeeded()).as("register lint build, see %s", lint.logFile()).isTrue();
        assertThat(Files.readString(module.resolve("target/e2e-reports/e2e-lint.md")))
                .contains("MU-DEMO-01", "| DEMO-GREET-001 | L4 | service | DEMO0001 | PASSED |");

        writeImportedPackage(module);
        // clean: a removed resource stays in target/test-classes otherwise (the wrapper clears that copy itself)
        Maven.Result features = maven.run(solution, "06-lint-features", "clean", "verify", "-pl", "demo-mu-e2e", "-am");
        assertThat(features.succeeded()).as("default-profile build with features, see %s", features.logFile()).isTrue();
        assertThat(surefireReport(module, "DemoMuParityTest")).as("register lint incl. the features' coverage")
                .contains("failures=\"0\"").contains("errors=\"0\"");
        assertThat(surefireReport(module, "DemoMuBehaviourSuite")).as("the features linted, the declared ones skipped")
                .contains("tests=\"5\"", "failures=\"0\"", "errors=\"0\"", "skipped=\"2\"");
        assertThat(module.resolve("target/cucumber")).as("a lint writes no Cucumber report (BehaviourReports)")
                .doesNotExist();

        Maven.Result replay = maven.run(solution, "07-replay-http",
                Map.of("E2E_TARGET_DB_REQUIRED", "false", "E2E_TARGET_PROPERTIES", "{\"demo.marker\":\"e2e\"}"),
                "verify", "-Pe2e-replay", "-pl", "demo-mu-e2e", "-am", "-Dmaven.test.failure.ignore=true");
        assertThat(replay.succeeded()).as("replay build, see %s", replay.logFile()).isTrue();
        assertThat(surefireReport(module, "DemoMuBehaviourSuite")).as("the features execute the scenarios")
                .contains("tests=\"5\"", "failures=\"1\"", "skipped=\"2\"");
        assertThat(Files.readString(module.resolve("target/e2e-reports/e2e-lint.md")))
                .as("the register-driven class only lints, in every mode").contains("DEMO-HTTP-001");
        assertThat(module.resolve("target/cucumber/demo-mu-e2e.html")).exists();
        Path cucumber = module.resolve("target/cucumber/demo-mu-e2e.json");
        String replayed = Files.readString(cucumber);
        assertThat(replayed).as("the replay's Cucumber report holds what was executed").contains("DEMO-HTTP-003", "failed");
        String report = Files.readString(module.resolve("target/e2e-reports/e2e-replay.md"));
        assertThat(report)
                .contains("| DEMO-HTTP-001 | L4 | service | DEMO0002 | PASSED |")
                .contains("| DEMO-HTTP-002 | L4 | service | DEMO0002 | PASSED |")
                .contains("| DEMO-HTTP-003 | L4 | service | DEMO0002 | FAILED |")
                .contains("| DEMO-HTTP-004 | L4 | service | DEMO0002 | NOT_APPLICABLE |")
                .contains("| DEMO-HTTP-005 | L4 | service | DEMO0002 | BLOCKED |")
                .contains("## Failed - with the hypotheses the scenario carries",
                        "| DEMO-HTTP-003 | greet-other-day | the target punctuates differently | OK 200: ",
                        "declared blocked: the legacy unit could not be recorded");
        assertThat(Files.readString(module.resolve("target/e2e-reports/e2e-replay.json")))
                .as("the target's answer is kept for the failure").contains("\"target\"", "HELLO WORLD!");
        assertThat(Files.readString(module.resolve("target/e2e-reports/application.log")))
                .as("the booted application logs through the basement's configuration")
                .contains("profile is active: \"e2e\"", "Tomcat started on port");

        // the engine stage of any MU lints the whole test solution: it must leave every module's replay report alone
        Maven.Result relint = maven.run(solution, "08-lint-after-replay", "verify");
        assertThat(relint.succeeded()).as("default-profile build after the replay, see %s", relint.logFile()).isTrue();
        assertThat(Files.readString(cucumber)).as("the replay's Cucumber report survives a lint").isEqualTo(replayed);
        try (var files = Files.list(module.resolve("target/cucumber"))) {
            assertThat(files.map(p -> p.getFileName().toString()).sorted().toList())
                    .containsExactly("demo-mu-e2e.html", "demo-mu-e2e.json");
        }
    }

    /**
     * What the design stage writes for an imported golden-master package: a 1.1 register with HTTP requests, declared
     * statuses and the import's tags, the payload mapping, the signed comparison profile, the accepted recordings and
     * the generated feature. The package replaces the component-lens register of the previous step.
     */
    private static void writeImportedPackage(Path module) throws IOException {
        Path e2e = module.resolve("src/test/resources/e2e");
        Files.delete(e2e.resolve("scenarios/register.json"));
        Files.delete(e2e.resolve("view-mappings/DEMO0001.json"));
        Files.writeString(e2e.resolve("scenarios/package.json"), """
                { "schemaVersion": "1.1", "mu": "MU-DEMO-01", "generatedBy": "archetype-it (as e2e_package import)",
                  "scenarios": [
                    { "scenarioId": "DEMO-HTTP-001", "title": "greet-world", "clock": "20240816103000",
                      "levels": [ { "level": "L4", "lens": "service", "legacy": "LEG-SP:DEMO0002", "target": "TGT-HTTP:app" } ],
                      "request": { "NAME-0001": "WORLD" },
                      "http": { "method": "GET", "path": "/greetings/WORLD", "query": { "punctuation": "!" } } },
                    { "scenarioId": "DEMO-HTTP-002", "title": "greet-down", "clock": "20240816103000",
                      "levels": [ { "level": "L4", "lens": "service", "legacy": "LEG-SP:DEMO0002", "target": "TGT-HTTP:app" } ],
                      "request": { "NAME-0001": "DOWN" },
                      "http": { "method": "GET", "path": "/greetings/DOWN" } },
                    { "scenarioId": "DEMO-HTTP-003", "title": "greet-other-day", "clock": "20310101103000",
                      "hypotheses": [ "the target punctuates differently" ], "tags": [ "hypothesis" ],
                      "levels": [ { "level": "L4", "lens": "service", "legacy": "LEG-SP:DEMO0002", "target": "TGT-HTTP:app" } ],
                      "request": { "NAME-0001": "WORLD" },
                      "http": { "method": "GET", "path": "/greetings/WORLD", "query": { "punctuation": "!" } } },
                    { "scenarioId": "DEMO-HTTP-004", "status": "not-applicable", "statusReason": "varies only an input the API lacks",
                      "tags": [ "not-applicable" ], "levels": [ { "legacy": "LEG-SP:DEMO0002", "target": "TGT-HTTP:app" } ],
                      "request": { "USER-ID-0001": "X" } },
                    { "scenarioId": "DEMO-HTTP-005", "status": "blocked", "statusReason": "the legacy unit could not be recorded",
                      "tags": [ "blocked" ], "levels": [ { "legacy": "LEG-SP:DEMO0002", "target": "TGT-HTTP:app" } ],
                      "request": { "NAME-0001": "X" } } ] }
                """);
        Files.createDirectories(e2e.resolve("features"));
        Files.writeString(e2e.resolve("features/DEMO0002.feature"), """
                # Generated by e2e_package import (here: written as it would) - do not edit.
                @level:L4 @lens:service @unit:DEMO0002
                Feature: DEMO0002 - GET /greetings/{name} (synthetic)
                  Comparison: HTTP status must match; strings right-trimmed; for errors only the status

                  @DEMO-HTTP-001
                  Scenario: DEMO-HTTP-001 greet-world
                    Given the clock 2024-08-16 10:30:00
                    When the client sends GET /greetings/WORLD?punctuation=%21
                    Then the answer matches the accepted golden master "DEMO-HTTP-001"
                    And the golden master holds status 200 and 1 item, starting with:
                      | code | text     |
                      | G    | GREETING |

                  @DEMO-HTTP-002
                  Scenario: DEMO-HTTP-002 greet-down
                    Given the clock 2024-08-16 10:30:00
                    When the client sends GET /greetings/DOWN
                    Then the answer matches the accepted golden master "DEMO-HTTP-002"
                    And the golden master holds status 503

                  @DEMO-HTTP-003 @hypothesis
                  Scenario: DEMO-HTTP-003 greet-other-day
                    Hypothesis (anticipated, never the expected value): the target punctuates differently
                    Given the clock 2031-01-01 10:30:00
                    When the client sends GET /greetings/WORLD?punctuation=%21
                    Then the answer matches the accepted golden master "DEMO-HTTP-003"

                  @DEMO-HTTP-004 @not-applicable
                  Scenario: DEMO-HTTP-004
                    * the case is not applicable: varies only an input the API lacks

                  @DEMO-HTTP-005 @blocked
                  Scenario: DEMO-HTTP-005
                    * the case is blocked: the legacy unit could not be recorded
                """);
        Files.writeString(e2e.resolve("view-mappings/DEMO0002.json"), """
                { "schemaVersion": "1.0", "unit": "DEMO0002", "description": "the API response of the package",
                  "fields": [ { "legacy": "greeting", "target": "greeting" }, { "legacy": "today", "target": "today" } ],
                  "groups": [ { "name": "items", "target": "items",
                                "fields": [ { "legacy": "code", "target": "code", "type": "CODE" },
                                            { "legacy": "text", "target": "text", "type": "TEXT" } ] } ] }
                """);
        Files.writeString(e2e.resolve("profiles.json"), """
                { "schemaVersion": "1.0", "profiles": [ { "name": "contract", "rules": [
                  { "rule": "RTRIM", "decision": "PKG-CMP-DEMO0002" },
                  { "rule": "NULL_AS_BLANK", "decision": "PKG-CMP-DEMO0002" },
                  { "rule": "OUTCOME_ONLY_ON_ERROR", "decision": "PKG-CMP-DEMO0002" } ] } ] }""");
        GoldenMasterStore store = new GoldenMasterStore(e2e.resolve("golden"));
        String today = """
                { "greeting": "HELLO WORLD!", "today": "2024-08-16", "items": [ { "code": "G", "text": "GREETING" } ] }""";
        accept(store, "DEMO-HTTP-001", today, Outcome.ok(200L));
        accept(store, "DEMO-HTTP-002", "{ \"status\": 503 }", new Outcome(Outcome.Kind.TECHNICAL_FAILURE, 503L, null, null));
        // pinned to 2031: the date matches (the target reads the clock bean), the recorded punctuation does not
        accept(store, "DEMO-HTTP-003", today.replace("2024-08-16", "2031-01-01").replace("WORLD!", "WORLD?"),
                Outcome.ok(200L));
    }

    private static void accept(GoldenMasterStore store, String id, String payload, Outcome outcome) throws IOException {
        Provenance provenance = new Provenance("gnucobol-emulated", "synthetic package", null, null, null, Map.of(),
                null, null, null, Map.of(), "logic", "2026-10-09", 1);
        GoldenMaster recorded = GoldenMaster.recorded(id, "DEMO0002", "L4", "service", Map.of(),
                Observation.targetPayload(JsonSupport.mapper().readTree(payload), outcome), Map.of(), provenance,
                "archetype-it", "2026-10-12T00:00:00Z", null);
        store.writeNew(recorded);
        store.updateLifecycle(Lifecycle.transition(recorded, LifecycleState.ACCEPTED, "archetype-it reviewer",
                "record gate", "PKG-CMP-DEMO0002", "2026-10-12T01:00:00Z"));
    }

    private static void assertPlainApplicationJar() throws IOException {
        Path jar = Path.of(System.getProperty("e2e.it.repo"))
                .resolve("org/example/demo/demo-app/1.0.0-SNAPSHOT/demo-app-1.0.0-SNAPSHOT.jar");
        assertThat(jar).exists();
        try (JarFile file = new JarFile(jar.toFile())) {
            assertThat(file.getEntry("org/example/demo/DemoApplication.class"))
                    .as("the snapshot's app jar must be plain (not repackaged) to serve as a dependency").isNotNull();
            assertThat(file.getEntry("BOOT-INF/")).isNull();
        }
    }

    private static void writeDesignArtifacts(Path module) throws IOException {
        Path e2e = module.resolve("src/test/resources/e2e");
        Files.createDirectories(e2e.resolve("scenarios"));
        Files.createDirectories(e2e.resolve("view-mappings"));
        Files.writeString(e2e.resolve("scenarios/register.json"), """
                { "schemaVersion": "1.0", "mu": "MU-DEMO-01", "generatedBy": "archetype-it",
                  "scenarios": [ { "scenarioId": "DEMO-GREET-001", "priority": "P0",
                    "levels": [ { "legacy": "LEG-SP:DEMO0001", "target": "TGT-SP:GreetingService.greet" } ],
                    "request": { "NAME-0001": "WORLD" } } ] }
                """);
        Files.writeString(e2e.resolve("view-mappings/DEMO0001.json"), """
                { "schemaVersion": "1.0", "unit": "DEMO0001",
                  "inputs": [ { "legacy": "NAME-0001", "target": "name" } ],
                  "fields": [ { "legacy": "GREETING-0002", "target": "greeting", "type": "TEXT" } ] }
                """);
    }

    static void insertModule(Path aggregator, String module) throws IOException {
        String pom = Files.readString(aggregator, StandardCharsets.UTF_8);
        int marker = pom.indexOf(MARKER);
        assertThat(marker).as("module marker in %s", aggregator).isPositive();
        int lineEnd = pom.indexOf('\n', marker) + 1;
        String updated = pom.substring(0, lineEnd) + "    <module>" + module + "</module>\n" + pom.substring(lineEnd);
        Files.writeString(aggregator, updated, StandardCharsets.UTF_8);
    }

    private static String surefireReport(Path module, String simpleName) throws IOException {
        try (Stream<Path> files = Files.list(module.resolve("target/surefire-reports"))) {
            Path report = files.filter(p -> p.getFileName().toString().startsWith("TEST-")
                    && p.getFileName().toString().endsWith(simpleName + ".xml")).findFirst().orElseThrow();
            return Files.readString(report, StandardCharsets.UTF_8);
        }
    }

    /** invoker:install stages the reactor's artifacts; their parent POM is added here when it is not. */
    private static void stageParentPom(Path repository, Path frameworkRoot) throws IOException {
        Path target = repository.resolve("com/insurance/e2e/modernization-e2e-framework").resolve(frameworkVersion)
                .resolve("modernization-e2e-framework-" + frameworkVersion + ".pom");
        if (!Files.exists(target)) {
            Files.createDirectories(target.getParent());
            Files.copy(frameworkRoot.resolve("pom.xml"), target);
        }
    }

    private static Path resource(String name) throws URISyntaxException {
        return Path.of(ArchetypeCompositionIT.class.getClassLoader().getResource(name).toURI());
    }

    static void copyTree(Path source, Path target) throws IOException {
        List<Path> paths;
        try (Stream<Path> walk = Files.walk(source)) {
            paths = new ArrayList<>(walk.toList());
        }
        for (Path path : paths) {
            Path destination = target.resolve(source.relativize(path).toString());
            if (Files.isDirectory(path)) {
                Files.createDirectories(destination);
            } else {
                Files.createDirectories(destination.getParent());
                try (InputStream in = Files.newInputStream(path)) {
                    Files.copy(in, destination, StandardCopyOption.REPLACE_EXISTING);
                }
            }
        }
    }
}
