package com.insurance.e2e.core.golden;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.TestData;
import com.insurance.e2e.core.json.JsonSupport;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class GoldenMasterTest {

    static GoldenMaster recorded() {
        return GoldenMaster.recorded("DEMO-001", TestData.UNIT, "L4", Map.of("TABLE-NAME-0001", "COLOUR"),
                TestData.legacyReport("BLUE", "CYAN"), Map.of("coverage", Map.of("DEMO0001", List.of(1, 2))),
                TestData.provenance("fx-1"), "e2e-record", "2026-10-02T10:00:00Z", null);
    }

    @Test
    void aRecordingIsSealedAndStartsItsHistory() {
        GoldenMaster master = recorded();

        assertThat(master.state()).isEqualTo(LifecycleState.RECORDED);
        assertThat(master.integrityHolds()).isTrue();
        assertThat(master.contentHash()).hasSize(64);
        assertThat(master.history()).singleElement().satisfies(t -> {
            assertThat(t.from()).isNull();
            assertThat(t.to()).isEqualTo(LifecycleState.RECORDED);
            assertThat(t.reason()).contains("2 identical run");
        });
        assertThat(Lifecycle.historyProblems(master)).isEmpty();
    }

    @Test
    void lensAndOriginAreSealedAndAbsentOnesKeepThe10Hash(@TempDir Path dir) {
        GoldenMaster plain = recorded();
        Map<String, Object> content10 = new java.util.LinkedHashMap<>();
        content10.put("schemaVersion", plain.schemaVersion());
        content10.put("scenarioId", plain.scenarioId());
        content10.put("unit", plain.unit());
        content10.put("level", plain.level());
        content10.put("request", plain.request());
        content10.put("observation", plain.observation());
        content10.put("evidence", plain.evidence());
        content10.put("provenance", plain.provenance());
        content10.put("supersedes", plain.supersedes());
        assertThat(plain.contentHash()).isEqualTo(JsonSupport.canonicalHash(content10));
        assertThat(plain.schemaVersion()).isEqualTo("1.1");

        GoldenMaster imported = new GoldenMaster("1.1", "TC-1", TestData.UNIT, "L4", Map.of("A", "1"),
                plain.observation(), Map.of("legacy", Map.of("count", 2)), plain.provenance(), LifecycleState.RECORDED,
                plain.history(), null, null, "service", Map.of("kind", "package", "caseId", "TC-1")).sealed();
        GoldenMaster otherOrigin = new GoldenMaster("1.1", "TC-1", TestData.UNIT, "L4", Map.of("A", "1"),
                plain.observation(), Map.of("legacy", Map.of("count", 2)), plain.provenance(), LifecycleState.RECORDED,
                plain.history(), null, null, "service", Map.of("kind", "package", "caseId", "TC-9")).sealed();
        assertThat(imported.integrityHolds()).isTrue();
        assertThat(imported.contentHash()).isNotEqualTo(otherOrigin.contentHash());
        assertThat(new GoldenMaster("1.1", "A", "U", null, null, plain.observation(), null, plain.provenance(),
                LifecycleState.RECORDED, plain.history(), null, null, null, Map.of()).origin()).isNull();

        GoldenMasterStore store = new GoldenMasterStore(dir);
        store.writeNew(imported);
        assertThat(store.verifyAll()).isEmpty();
        GoldenMaster read = store.find(TestData.UNIT, "TC-1").orElseThrow();
        assertThat(read.lens()).isEqualTo("service");
        assertThat(read.origin()).containsEntry("kind", "package");
        assertThat(read.integrityHolds()).isTrue();
    }

    @Test
    void lifecycleChangesKeepTheContentHash() {
        GoldenMaster accepted = Lifecycle.transition(recorded(), LifecycleState.ACCEPTED, "ba.reviewer",
                "explained at the record gate", "D-001", "2026-10-02T11:00:00Z");

        assertThat(accepted.state()).isEqualTo(LifecycleState.ACCEPTED);
        assertThat(accepted.contentHash()).isEqualTo(recorded().contentHash());
        assertThat(accepted.integrityHolds()).isTrue();
        assertThat(accepted.history()).hasSize(2);
        assertThat(Lifecycle.historyProblems(accepted)).isEmpty();
    }

    @Test
    void acceptanceMustBeSignedAndIllegalStepsAreRefused() {
        assertThatThrownBy(() -> Lifecycle.transition(recorded(), LifecycleState.ACCEPTED, " ", "r", null, "t"))
                .isInstanceOf(E2eException.class).hasMessageContaining("signed");
        GoldenMaster stale = Lifecycle.transition(recorded(), LifecycleState.STALE, "e2e", "engine changed", null, "t");
        assertThatThrownBy(() -> Lifecycle.transition(stale, LifecycleState.ACCEPTED, "x", "r", null, "t"))
                .isInstanceOf(E2eException.class).hasMessageContaining("not allowed");
        GoldenMaster disputed = Lifecycle.transition(recorded(), LifecycleState.DISPUTED, "triage", "suspected engine defect", null, "t");
        assertThat(Lifecycle.allowed(disputed.state(), LifecycleState.STALE)).isTrue();
        assertThat(Lifecycle.allowed(disputed.state(), LifecycleState.ACCEPTED)).isFalse();
    }

    @Test
    void stalenessIsComputedFromProvenance() {
        GoldenMaster accepted = Lifecycle.transition(recorded(), LifecycleState.ACCEPTED, "ba", "ok", null, "t");
        Provenance same = TestData.provenance("fx-1");
        Provenance otherFixture = TestData.provenance("fx-2");

        assertThat(Lifecycle.effectiveState(accepted, same)).isEqualTo(LifecycleState.ACCEPTED);
        assertThat(Lifecycle.effectiveState(accepted, otherFixture)).isEqualTo(LifecycleState.STALE);
        assertThat(Lifecycle.effectiveState(accepted, null)).isEqualTo(LifecycleState.ACCEPTED);
    }

    @Test
    void historyProblemsAreReported() {
        GoldenMaster master = recorded();
        GoldenMaster noHistory = new GoldenMaster("1.0", "A", "U", null, null, master.observation(), null,
                master.provenance(), LifecycleState.RECORDED, List.of(), null, null);
        assertThat(Lifecycle.historyProblems(noHistory)).containsExactly("history is empty");

        List<LifecycleTransition> broken = List.of(
                new LifecycleTransition(LifecycleState.ACCEPTED, LifecycleState.RECORDED, "t", "x", null, null),
                new LifecycleTransition(LifecycleState.DISPUTED, LifecycleState.ACCEPTED, "t", null, null, null),
                new LifecycleTransition(LifecycleState.ACCEPTED, LifecycleState.RECORDED, "t", "x", null, null));
        GoldenMaster wrong = new GoldenMaster("1.0", "A", "U", null, null, master.observation(), null,
                master.provenance(), LifecycleState.ACCEPTED, broken, null, null);
        assertThat(Lifecycle.historyProblems(wrong))
                .anyMatch(p -> p.contains("must start with the recording"))
                .anyMatch(p -> p.contains("starts from DISPUTED"))
                .anyMatch(p -> p.contains("not allowed"))
                .anyMatch(p -> p.contains("disagrees"));
    }

    @Test
    void provenanceTreatsUnknownAsUnchanged() {
        Provenance stored = TestData.provenance("fx-1");
        Provenance replay = new Provenance(null, null, null, null, null, Map.of(), null, "fx-1", "20240101120000",
                Map.of(), "logic", null, null);
        Provenance changed = new Provenance("gnucobol-emulated", "engine-2", "image-1", "patch-1", "shims-2",
                Map.of("DEMO0001", "hash-b", "NEW0001", "h"), "driver-1", "fx-1", "20240101120000",
                Map.of("AUTOCOMMIT", "on"), "platform-emulated", "later", 3);

        assertThat(stored.changedFields(replay)).isEmpty();
        assertThat(stored.changedFields(changed)).containsExactly("engine", "shimTree", "sources:DEMO0001",
                "sources:NEW0001", "env:AUTOCOMMIT", "dbMode");
    }

    @Test
    void storeWritesNewNeverOverwritesAndArchivesReRecordings(@TempDir Path dir) {
        GoldenMasterStore store = new GoldenMasterStore(dir);
        GoldenMaster first = recorded();

        Path file = store.writeNew(first);
        assertThat(file).isEqualTo(dir.resolve(TestData.UNIT).resolve("DEMO-001.json"));
        assertThat(store.find(TestData.UNIT, "DEMO-001")).contains(first);
        assertThat(store.find(TestData.UNIT, "NOPE")).isEmpty();
        assertThatThrownBy(() -> store.writeNew(first)).isInstanceOf(E2eException.class).hasMessageContaining("never overwritten");

        GoldenMaster accepted = Lifecycle.transition(first, LifecycleState.ACCEPTED, "ba", "ok", null, "t");
        store.updateLifecycle(accepted);
        assertThat(store.find(TestData.UNIT, "DEMO-001").orElseThrow().state()).isEqualTo(LifecycleState.ACCEPTED);

        GoldenMaster other = GoldenMaster.recorded("DEMO-001", TestData.UNIT, "L4", Map.of(),
                TestData.legacyReport("NAVY", "TEAL"), Map.of(), TestData.provenance("fx-9"), "e2e", "t", null);
        assertThatThrownBy(() -> store.updateLifecycle(other)).isInstanceOf(E2eException.class).hasMessageContaining("content hash");
        assertThatThrownBy(() -> store.rerecord(accepted, other)).isInstanceOf(E2eException.class).hasMessageContaining("supersedes");

        GoldenMaster next = GoldenMaster.recorded("DEMO-001", TestData.UNIT, "L4", Map.of(),
                TestData.legacyReport("NAVY", "TEAL"), Map.of(), TestData.provenance("fx-9"), "e2e", "t",
                accepted.contentHash());
        store.rerecord(accepted, next);
        assertThat(store.find(TestData.UNIT, "DEMO-001").orElseThrow().supersedes()).isEqualTo(accepted.contentHash());
        assertThat(dir.resolve(TestData.UNIT).resolve(GoldenMasterStore.SUPERSEDED_DIR)
                .resolve("DEMO-001." + accepted.contentHash().substring(0, 12) + ".json")).exists();
        assertThat(store.verifyAll()).isEmpty();
        assertThat(store.root()).isEqualTo(dir);
    }

    @Test
    void storeRefusesUnsealedMastersAndUpdatesOfMissingOnes(@TempDir Path dir) {
        GoldenMasterStore store = new GoldenMasterStore(dir);
        GoldenMaster master = recorded();
        GoldenMaster unsealed = new GoldenMaster("1.0", master.scenarioId(), master.unit(), master.level(),
                master.request(), master.observation(), master.evidence(), master.provenance(), master.state(),
                master.history(), "0".repeat(64), null);

        assertThatThrownBy(() -> store.writeNew(unsealed)).isInstanceOf(E2eException.class).hasMessageContaining("not sealed");
        assertThatThrownBy(() -> store.updateLifecycle(master)).isInstanceOf(E2eException.class).hasMessageContaining("No golden master");
    }

    @Test
    void integrityDetectsEditsWrongPathsAndBrokenFiles(@TempDir Path dir) throws IOException {
        GoldenMasterStore store = new GoldenMasterStore(dir);
        Path file = store.writeNew(recorded());
        assertThat(new GoldenMasterStore(dir.resolve("absent")).verifyAll()).isEmpty();

        String edited = Files.readString(file).replace("BLUE", "GREEN");
        Files.writeString(file, edited);
        assertThat(store.verifyAll()).singleElement().asString().contains("content hash mismatch");

        Path misplaced = dir.resolve("OTHER").resolve("DEMO-001.json");
        Files.createDirectories(misplaced.getParent());
        JsonSupport.write(misplaced, recorded());
        assertThat(store.verify(misplaced)).anyMatch(p -> p.contains("wrong path"));

        Path broken = dir.resolve("OTHER").resolve("BROKEN.json");
        Files.writeString(broken, "{ nope");
        assertThat(store.verify(broken)).singleElement().asString().contains("not valid JSON");

        Path invalid = dir.resolve("OTHER").resolve("INVALID.json");
        Files.writeString(invalid, "{\"schemaVersion\":\"1.0\"}");
        assertThat(store.verify(invalid)).isNotEmpty().allMatch(p -> p.startsWith("OTHER/INVALID.json"));
    }
}
