package com.insurance.e2e.core.run;

import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.observation.Outcome;
import com.insurance.e2e.core.scenario.Scenario;
import com.insurance.e2e.core.spi.Availability;
import com.insurance.e2e.core.spi.CapturePlugin;
import com.insurance.e2e.core.spi.EnvironmentPlugin;
import com.insurance.e2e.core.spi.ExecutionContext;
import com.insurance.e2e.core.spi.TriggerPlugin;

import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Synthetic plugins for runner tests: each side returns what the test queued. */
final class FakePlugins {

    private FakePlugins() {
    }

    /** Legacy trigger: returns queued raw reports in order, repeating the last one. */
    static final class LegacyTrigger implements TriggerPlugin {
        final Deque<Observation> reports = new ArrayDeque<>();
        Availability availability = Availability.up();
        int calls;

        @Override
        public String id() {
            return "fake-legacy";
        }

        @Override
        public Set<String> kinds() {
            return Set.of("LEG-SP");
        }

        @Override
        public Availability availability(ExecutionContext context) {
            return availability;
        }

        @Override
        public TriggerResult trigger(Request request) {
            calls++;
            Observation next = reports.size() > 1 ? reports.poll() : reports.peek();
            return new TriggerResult(request.binding(), next, null,
                    Map.of("source:DEMO0001", "hash-a", "driver", "driver-1", "runnerImage", "image-1"));
        }
    }

    /** Capture for both sides: the trigger payload already is the observation. */
    static final class PassThroughCapture implements CapturePlugin {
        private final Set<String> kinds;

        PassThroughCapture(String... kinds) {
            this.kinds = Set.of(kinds);
        }

        @Override
        public String id() {
            return "fake-capture";
        }

        @Override
        public Set<String> kinds() {
            return kinds;
        }

        @Override
        public Observation capture(Request request) {
            return (Observation) request.result().payload();
        }
    }

    /** Target trigger: returns a JSON payload as a target observation. */
    static final class TargetTrigger implements TriggerPlugin {
        String json = "{}";
        Availability availability = Availability.up();

        @Override
        public String id() {
            return "fake-target";
        }

        @Override
        public Set<String> kinds() {
            return Set.of("TGT-SP");
        }

        @Override
        public Availability availability(ExecutionContext context) {
            return availability;
        }

        @Override
        public TriggerResult trigger(Request request) {
            try {
                return new TriggerResult(request.binding(),
                        Observation.targetPayload(JsonSupport.mapper().readTree(json), Outcome.ok(0L)), null, Map.of());
            } catch (IOException e) {
                throw new IllegalStateException(e);
            }
        }
    }

    /** Environment: reports a fixed pack hash and queued state hashes. */
    static final class Environment implements EnvironmentPlugin {
        String packHash = "fx-1";
        final Deque<String> stateHashes = new ArrayDeque<>(List.of("state-1"));
        Availability availability = Availability.up();
        int prepared;

        @Override
        public String id() {
            return "fake-env";
        }

        @Override
        public Set<String> kinds() {
            return Set.of(JDBC);
        }

        @Override
        public Availability availability(ExecutionContext context) {
            return availability;
        }

        @Override
        public FixtureState prepare(Scenario scenario, String fixture, ExecutionContext context) {
            prepared++;
            String state = stateHashes.size() > 1 ? stateHashes.poll() : stateHashes.peek();
            return new FixtureState(fixture, packHash, state, List.of("COLOUR_CODE"));
        }

        @Override
        public String stateHash(List<String> tables, ExecutionContext context) {
            return stateHashes.peek();
        }
    }
}
