package com.insurance.e2e.core.run;

import com.fasterxml.jackson.databind.node.TextNode;
import com.insurance.e2e.core.TestData;
import com.insurance.e2e.core.compare.FieldComparePlugin;
import com.insurance.e2e.core.compare.MappingRepository;
import com.insurance.e2e.core.compare.ProfileSet;
import com.insurance.e2e.core.golden.GoldenMaster;
import com.insurance.e2e.core.golden.GoldenMasterStore;
import com.insurance.e2e.core.golden.Lifecycle;
import com.insurance.e2e.core.golden.LifecycleState;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.observation.Outcome;
import com.insurance.e2e.core.scenario.Assertion;
import com.insurance.e2e.core.scenario.BindingRef;
import com.insurance.e2e.core.scenario.CompareSpec;
import com.insurance.e2e.core.scenario.LevelBinding;
import com.insurance.e2e.core.scenario.Scenario;
import com.insurance.e2e.core.spi.Availability;
import com.insurance.e2e.core.spi.ExecutionContext;
import com.insurance.e2e.core.spi.PluginRegistry;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class ScenarioRunnerTest {

    static final String MATCHING_TARGET = """
            { "responseCode": 0, "message": "", "items": [ { "code": "B", "text": "BLUE" }, { "code": "C", "text": "CYAN" } ] }""";

    @TempDir
    Path dir;

    FakePlugins.LegacyTrigger legacy;
    FakePlugins.TargetTrigger target;
    FakePlugins.Environment environment;
    PluginRegistry registry;
    GoldenMasterStore store;
    MappingRepository mappings;
    Path signedProfiles;

    @BeforeEach
    void setUp() throws IOException {
        legacy = new FakePlugins.LegacyTrigger();
        legacy.reports.add(TestData.legacyReport("BLUE", "CYAN"));
        target = new FakePlugins.TargetTrigger();
        target.json = MATCHING_TARGET;
        environment = new FakePlugins.Environment();
        registry = new PluginRegistry()
                .register(legacy)
                .register(new FakePlugins.PassThroughCapture("LEG-SP", "TGT-SP"))
                .register(target)
                .register(environment)
                .register(new FieldComparePlugin());
        store = new GoldenMasterStore(dir.resolve("golden"));
        JsonSupport.write(dir.resolve("view-mappings").resolve(TestData.UNIT + ".json"), TestData.mapping());
        mappings = MappingRepository.load(dir.resolve("view-mappings"));
        signedProfiles = dir.resolve("profiles.json");
        Files.writeString(signedProfiles, """
                { "schemaVersion": "1.0", "profiles": [ { "name": "contract", "rules": [
                  { "rule": "RTRIM", "decision": "D-1" }, { "rule": "NULL_AS_BLANK", "decision": "D-2" } ] } ] }""");
    }

    ScenarioRunner runner(String engine) {
        ExecutionContext context = ExecutionContext.builder()
                .property("e2e.provenance.engine", engine)
                .property("e2e.recorded.by", "test")
                .environment(Map.of())
                .clock(Clock.fixed(Instant.parse("2026-10-02T10:00:00Z"), ZoneOffset.UTC))
                .build();
        return new ScenarioRunner(registry, store, mappings, ProfileSet.load(signedProfiles), context,
                ProvenanceSource.fromContext());
    }

    Scenario scenario() {
        return TestData.scenario("DEMO-001", CompareSpec.defaults(), "DEMO0001/seed.sql");
    }

    @Test
    void lintPassesWhenPluginsAndMappingExist() {
        ScenarioReport report = runner("e1").run(E2eMode.LINT, scenario(), TestData.level());

        assertThat(report.status()).isEqualTo(ScenarioReport.Status.PASSED);
        assertThat(report.notes()).contains("no golden master yet");
        assertThat(report.mode()).isEqualTo("LINT");
    }

    @Test
    void lintBlocksOnMissingPluginsAndMappings() {
        LevelBinding http = new LevelBinding(null, BindingRef.parse("LEG-SP:" + TestData.UNIT), BindingRef.parse("TGT-HTTP:/x"), "NO-MAPPING");

        ScenarioReport report = runner("e1").run(E2eMode.LINT, scenario(), http);

        assertThat(report.status()).isEqualTo(ScenarioReport.Status.BLOCKED);
        assertThat(report.message()).contains("TRIGGER plugin for kind 'TGT-HTTP'", "CAPTURE plugin", "no view mapping 'NO-MAPPING'");
    }

    @Test
    void lintReportsLegacyOnlyLevelsAndGoldenIntegrity() throws IOException {
        LevelBinding legacyOnly = new LevelBinding(null, BindingRef.parse("LEG-SP:" + TestData.UNIT), null, null);
        assertThat(runner("e1").run(E2eMode.LINT, scenario(), legacyOnly).notes())
                .contains("legacy-only level (no target binding yet)");

        runner("e1").run(E2eMode.RECORD, scenario(), TestData.level());
        assertThat(runner("e1").run(E2eMode.LINT, scenario(), TestData.level()).notes()).contains("golden master RECORDED");

        Path file = store.pathFor(TestData.UNIT, "DEMO-001");
        Files.writeString(file, Files.readString(file).replace("CYAN", "TEAL"));
        ScenarioReport edited = runner("e1").run(E2eMode.LINT, scenario(), TestData.level());
        assertThat(edited.status()).isEqualTo(ScenarioReport.Status.FAILED);
        assertThat(edited.message()).contains("content hash mismatch");
    }

    @Test
    void recordWritesASealedGoldenMasterWithProvenance() {
        Scenario withAssertion = new Scenario("DEMO-002", null, null, null, "P1", null, null, null, null,
                List.of(TestData.level()), "DEMO0001/seed.sql", "20240101120000", null, Map.of("A", "1"),
                null, List.of(new Assertion("RESPONSE-CODE-0002", "1", "package")), null);

        ScenarioReport report = runner("e1").run(E2eMode.RECORD, withAssertion, TestData.level());

        assertThat(report.status()).isEqualTo(ScenarioReport.Status.RECORDED);
        assertThat(report.notes()).anyMatch(n -> n.startsWith("discrepancy (package)"));
        GoldenMaster master = store.find(TestData.UNIT, "DEMO-002").orElseThrow();
        assertThat(master.integrityHolds()).isTrue();
        assertThat(master.provenance().sources()).containsEntry("DEMO0001", "hash-a");
        assertThat(master.provenance().driver()).isEqualTo("driver-1");
        assertThat(master.provenance().runnerImage()).isEqualTo("image-1");
        assertThat(master.provenance().fixture()).isEqualTo("fx-1");
        assertThat(master.provenance().repeatRuns()).isEqualTo(2);
        assertThat(master.provenance().engine()).isEqualTo("e1");
        assertThat(master.provenance().dbMode()).isEqualTo("logic");
        assertThat(legacy.calls).isEqualTo(2);
        assertThat(environment.prepared).isEqualTo(2);
    }

    @Test
    void recordRefusesANonDeterministicLegacy() {
        legacy.reports.clear();
        legacy.reports.add(TestData.legacyReport("BLUE", "CYAN"));
        legacy.reports.add(TestData.legacyReport("BLUE", "TEAL"));

        ScenarioReport report = runner("e1").run(E2eMode.RECORD, scenario(), TestData.level());

        assertThat(report.status()).isEqualTo(ScenarioReport.Status.FAILED);
        assertThat(report.message()).contains("non-deterministic", "EQ-6", "TEXT-0003(002)");
        assertThat(store.find(TestData.UNIT, "DEMO-001")).isEmpty();
    }

    @Test
    void recordKeepsCurrentGoldenMastersAndReRecordsStaleOnes() {
        runner("e1").run(E2eMode.RECORD, scenario(), TestData.level());
        GoldenMaster first = store.find(TestData.UNIT, "DEMO-001").orElseThrow();

        ScenarioReport kept = runner("e1").run(E2eMode.RECORD, scenario(), TestData.level());
        assertThat(kept.status()).isEqualTo(ScenarioReport.Status.PASSED);
        assertThat(kept.message()).startsWith("kept");

        legacy.reports.clear();
        legacy.reports.add(TestData.legacyReport("BLUE", "AQUA"));
        ScenarioReport rerecorded = runner("e2").run(E2eMode.RECORD, scenario(), TestData.level());
        assertThat(rerecorded.status()).isEqualTo(ScenarioReport.Status.RECORDED);
        assertThat(rerecorded.notes()).anyMatch(n -> n.contains("re-recorded") && n.contains("TEXT-0003(002)"));
        GoldenMaster second = store.find(TestData.UNIT, "DEMO-001").orElseThrow();
        assertThat(second.supersedes()).isEqualTo(first.contentHash());
        assertThat(store.verifyAll()).isEmpty();
    }

    @Test
    void replayNeedsAnAcceptedCurrentGoldenMaster() {
        assertThat(runner("e1").run(E2eMode.REPLAY, scenario(), TestData.level()).message()).contains("record it first");

        runner("e1").run(E2eMode.RECORD, scenario(), TestData.level());
        ScenarioReport recordedOnly = runner("e1").run(E2eMode.REPLAY, scenario(), TestData.level());
        assertThat(recordedOnly.status()).isEqualTo(ScenarioReport.Status.BLOCKED);
        assertThat(recordedOnly.message()).contains("RECORDED", "only accepted");

        accept();
        ScenarioReport stale = runner("e2").run(E2eMode.REPLAY, scenario(), TestData.level());
        assertThat(stale.message()).contains("STALE", "engine");
    }

    @Test
    void replayComparesTheTargetWithTheGoldenMasterUnderBothProfiles() {
        runner("e1").run(E2eMode.RECORD, scenario(), TestData.level());
        accept();

        ScenarioReport match = runner("e1").run(E2eMode.REPLAY, scenario(), TestData.level());
        assertThat(match.status()).isEqualTo(ScenarioReport.Status.PASSED);
        assertThat(match.verdictProfile()).isEqualTo("contract");
        assertThat(match.contract().status().name()).isEqualTo("MATCH");
        assertThat(match.strict().status().name()).isEqualTo("DIFF");
        assertThat(match.message()).contains("match under contract");
        assertThat(match.target()).as("a passing scenario keeps no answer").isNull();

        target.json = MATCHING_TARGET.replace("CYAN", "TEAL");
        ScenarioReport diff = runner("e1").run(E2eMode.REPLAY, scenario(), TestData.level());
        assertThat(diff.status()).isEqualTo(ScenarioReport.Status.FAILED);
        assertThat(diff.message()).contains("DIFF under contract", "rows[2].TEXT-0003");
        assertThat(diff.target()).as("what the target said, for triage").isNotNull();
        assertThat(diff.target().outcome().kind().name()).isEqualTo("OK");
        assertThat(diff.target().payload()).contains("TEAL").doesNotContain("CYAN");
        assertThat(diff.target().truncated()).isFalse();
        assertThat(JsonSupport.mapper().valueToTree(diff).has("target")).isTrue();
        assertThat(JsonSupport.mapper().valueToTree(match).has("target")).as("no answer, no field").isFalse();
    }

    @Test
    void theTargetsAnswerIsCutAtItsLimit() {
        String longText = "x".repeat(ScenarioReport.TargetAnswer.LIMIT + 500);
        ScenarioReport.TargetAnswer answer = ScenarioReport.TargetAnswer.of(Observation
                .targetPayload(TextNode.valueOf(longText), Outcome.failure("java.lang.NullPointerException", null))
                .withMeta(Map.of("http.status", "500")));

        assertThat(answer.truncated()).isTrue();
        assertThat(answer.payload()).hasSize(ScenarioReport.TargetAnswer.LIMIT);
        assertThat(answer.meta()).containsEntry("http.status", "500");
        assertThat(answer.outcome().kind()).isEqualTo(Outcome.Kind.TECHNICAL_FAILURE);
        assertThat(ScenarioReport.TargetAnswer.of(Observation.canonical(Map.of(), Map.of(), null)).payload())
                .as("nothing captured, nothing shown").isNull();
        assertThat(answer.excerpt(10)).isEqualTo("\"xxxxxxxxx...");
    }

    @Test
    void theTargetsWholeAnswerIsKeptAndAMessageShowsItsStart() {
        String items = "[" + "{\"code\":\"A00\",\"text\":\"CAP BUSINESS EVENT A00\"},".repeat(300) + "{}]";
        ScenarioReport.TargetAnswer answer = ScenarioReport.TargetAnswer.of(Observation
                .targetPayload(JsonSupport.mapper().createObjectNode().set("items", readTree(items)), Outcome.ok(200L)));

        assertThat(answer.payload()).as("an API answer of ~14 000 characters is kept whole").hasSizeGreaterThan(14_000)
                .endsWith("{}]}");
        assertThat(answer.truncated()).isFalse();
        assertThat(answer.excerpt(20)).isEqualTo(answer.payload().substring(0, 20) + "...");
        assertThat(answer.excerpt(100_000)).as("a short answer whole").isEqualTo(answer.payload());
        assertThat(new ScenarioReport.TargetAnswer(null, Map.of(), null, false).excerpt(5)).isNull();
    }

    private static com.fasterxml.jackson.databind.JsonNode readTree(String json) {
        try {
            return JsonSupport.mapper().readTree(json);
        } catch (java.io.IOException e) {
            throw new IllegalStateException(e);
        }
    }

    @Test
    void replayBlocksWhenTheFixtureChangedAndSkipsWhenTheTargetIsDown() {
        runner("e1").run(E2eMode.RECORD, scenario(), TestData.level());
        accept();

        environment.packHash = "fx-other";
        assertThat(runner("e1").run(E2eMode.REPLAY, scenario(), TestData.level()).message()).contains("fixture pack changed");

        environment.packHash = "fx-1";
        target.availability = Availability.down("connection refused");
        ScenarioReport skipped = runner("e1").run(E2eMode.REPLAY, scenario(), TestData.level());
        assertThat(skipped.status()).isEqualTo(ScenarioReport.Status.SKIPPED);
        assertThat(skipped.message()).contains("connection refused");

        environment.availability = Availability.down("no database");
        assertThat(runner("e1").run(E2eMode.REPLAY, scenario(), TestData.level()).message()).contains("no database");
    }

    @Test
    void replayAndLiveBlockWithoutTargetOrMapping() {
        LevelBinding legacyOnly = new LevelBinding(null, BindingRef.parse("LEG-SP:" + TestData.UNIT), null, null);
        LevelBinding unmapped = new LevelBinding(null, BindingRef.parse("LEG-SP:" + TestData.UNIT), BindingRef.parse("TGT-SP:X.y"), "NONE");

        assertThat(runner("e1").run(E2eMode.REPLAY, scenario(), legacyOnly).status()).isEqualTo(ScenarioReport.Status.BLOCKED);
        assertThat(runner("e1").run(E2eMode.REPLAY, scenario(), unmapped).message()).contains("no view mapping 'NONE'");
        assertThat(runner("e1").run(E2eMode.LIVE, scenario(), legacyOnly).status()).isEqualTo(ScenarioReport.Status.BLOCKED);
        assertThat(runner("e1").run(E2eMode.LIVE, scenario(), unmapped).message()).contains("no view mapping 'NONE'");
    }

    @Test
    void liveRunsBothLegsOnTheSameState() {
        ScenarioReport match = runner("e1").run(E2eMode.LIVE, scenario(), TestData.level());
        assertThat(match.status()).isEqualTo(ScenarioReport.Status.PASSED);
        assertThat(environment.prepared).isEqualTo(2);

        environment.stateHashes.clear();
        environment.stateHashes.addAll(List.of("state-1", "state-2"));
        ScenarioReport drift = runner("e1").run(E2eMode.LIVE, scenario(), TestData.level());
        assertThat(drift.status()).isEqualTo(ScenarioReport.Status.BLOCKED);
        assertThat(drift.message()).contains("table state differs");
    }

    @Test
    void aMissingPluginDuringExecutionBlocksWithARouteBack() {
        registry = new PluginRegistry().register(legacy).register(new FakePlugins.PassThroughCapture("LEG-SP"));
        Scenario noFixture = TestData.scenario("DEMO-003");

        ScenarioReport report = runner("e1").run(E2eMode.LIVE, noFixture, TestData.level());

        assertThat(report.status()).isEqualTo(ScenarioReport.Status.BLOCKED);
        assertThat(report.message()).contains("route-back to the framework owner");
    }

    @Test
    void declaredStatusesAreReportedInEveryModeAndNeverExecuted() {
        Scenario notApplicable = declared("TC-NA", Scenario.NOT_APPLICABLE, "the API has no such input");
        Scenario blocked = declared("TC-BL", Scenario.BLOCKED, "legacy module CRR0000 missing");

        for (E2eMode mode : E2eMode.values()) {
            ScenarioReport na = runner("e1").run(mode, notApplicable, TestData.level());
            ScenarioReport bl = runner("e1").run(mode, blocked, TestData.level());
            assertThat(na.status()).isEqualTo(ScenarioReport.Status.NOT_APPLICABLE);
            assertThat(na.message()).isEqualTo("not applicable at the service lens: the API has no such input");
            assertThat(bl.status()).isEqualTo(ScenarioReport.Status.BLOCKED);
            assertThat(bl.message()).isEqualTo("declared blocked: legacy module CRR0000 missing");
            assertThat(bl.lens()).isEqualTo("service");
            assertThat(bl.title()).isEqualTo("declared");
            assertThat(bl.hypotheses()).containsExactly("a hypothesis");
        }
        assertThat(legacy.calls).isZero();
        assertThat(environment.prepared).isZero();
    }

    @Test
    void recordingsCarryTheLensAndReplayNotesAScenarioThatChangedItsFixture() {
        runner("e1").run(E2eMode.RECORD, scenario(), TestData.level());
        assertThat(store.find(TestData.UNIT, "DEMO-001").orElseThrow().lens()).isEqualTo("service");
        assertThat(store.find(TestData.UNIT, "DEMO-001").orElseThrow().level()).isEqualTo("L4");
        accept();

        environment.stateHashes.clear();
        environment.stateHashes.addAll(List.of("state-1", "state-after-write"));
        ScenarioReport report = runner("e1").run(E2eMode.REPLAY, scenario(), TestData.level());

        assertThat(report.status()).isEqualTo(ScenarioReport.Status.PASSED);
        assertThat(report.notes()).anyMatch(n -> n.contains("changed the table state"));
        assertThat(report.level()).isEqualTo("L4");
        assertThat(report.lens()).isEqualTo("service");
    }

    private static Scenario declared(String id, String status, String reason) {
        return new Scenario(id, null, null, null, null, null, null, null, null, List.of(TestData.level()),
                "DEMO0001/seed.sql", null, null, Map.of("A", "1"), null, null, null, "declared", null, null, status,
                reason, List.of("a hypothesis"), null, null);
    }

    @Test
    void modesParseFromTheProperty() {
        assertThat(E2eMode.parse(null)).isEqualTo(E2eMode.LINT);
        assertThat(E2eMode.parse(" e2e-replay ")).isEqualTo(E2eMode.REPLAY);
        assertThat(E2eMode.parse("execute")).isEqualTo(E2eMode.REPLAY);
        assertThat(E2eMode.parse("Record")).isEqualTo(E2eMode.RECORD);
        org.assertj.core.api.Assertions.assertThatThrownBy(() -> E2eMode.parse("fast"))
                .hasMessageContaining("Unknown e2e.mode");
    }

    private void accept() {
        GoldenMaster recorded = store.find(TestData.UNIT, "DEMO-001").orElseThrow();
        store.updateLifecycle(Lifecycle.transition(recorded, LifecycleState.ACCEPTED, "ba", "record gate", "D-0",
                "2026-10-02T11:00:00Z"));
    }
}
