package com.insurance.e2e.core.scenario;

import com.insurance.e2e.core.E2eException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class RegisterLoaderTest {

    static final String VALID = """
            {
              "schemaVersion": "1.0",
              "mu": "MU-DEMO-01",
              "generatedBy": "test",
              "scenarios": [
                {
                  "scenarioId": "DEMO-RANGE-001",
                  "origin": { "ptCase": "demo-case", "note": "cross-check only" },
                  "servicePoint": "DEMO0001",
                  "branch": "COLOUR",
                  "priority": "P0",
                  "ruleIds": ["BR-1"],
                  "risks": ["PR-17"],
                  "caveats": ["EC-04"],
                  "levels": [
                    { "legacy": "LEG-CMP:DEMO0101", "target": "TGT-CMP:ColourRepository.findCodes" },
                    { "legacy": "LEG-SP:DEMO0001", "target": "TGT-SP:LookupService.lookup", "level": "L4" }
                  ],
                  "fixture": "DEMO0001/seed.sql",
                  "clock": "20240101120000",
                  "dbMode": "logic",
                  "request": { "TABLE-NAME-0001": "COLOUR", "SEARCH-VALUE-0001": "B", "ITEM-0002(001)": "x" },
                  "compare": { "profile": "contract", "rows": "set", "order": "report-only" },
                  "assert": [ { "field": "RESPONSE-CODE-0002", "eq": "0", "source": "pt-case" } ]
                }
              ]
            }
            """;

    private final RegisterLoader loader = new RegisterLoader();

    @Test
    void readsAValidRegister() {
        ScenarioRegister register = read(VALID);

        assertThat(register.mu()).isEqualTo("MU-DEMO-01");
        assertThat(register.scenarios()).hasSize(1);
        Scenario scenario = register.scenarios().get(0);
        assertThat(scenario.levels()).hasSize(2);
        assertThat(scenario.levels().get(0).legacy().kind()).isEqualTo("LEG-CMP");
        assertThat(scenario.levels().get(1).target().ref()).isEqualTo("LookupService.lookup");
        assertThat(scenario.compare().rowsAsSet()).isTrue();
        assertThat(scenario.assertions()).singleElement().extracting(Assertion::field).isEqualTo("RESPONSE-CODE-0002");
        assertThat(scenario.origin()).containsEntry("ptCase", "demo-case");
    }

    static final String PACKAGE_REGISTER = """
            {
              "schemaVersion": "1.1",
              "mu": "MU-DEMO-01",
              "source": { "package": "DEMO0001-tests.json", "packageHash": "abc" },
              "scenarios": [
                {
                  "scenarioId": "TC-001",
                  "title": "codes-all", "description": "whole table", "category": "Happy",
                  "levels": [ { "level": "L4", "lens": "service", "legacy": "LEG-SP:DEMO0001", "target": "TGT-HTTP:app" } ],
                  "fixture": "seed-tests", "clock": "20240816103000", "clockSensitive": false,
                  "request": { "TABLE-NAME-0001": "COLOUR" },
                  "http": { "method": "GET", "path": "/codes/COLOUR", "query": { "searchValue": "", "effectiveDate": "20240816" } },
                  "hypotheses": [ "the target returns more rows" ],
                  "compare": { "expectEmpty": true }
                },
                {
                  "scenarioId": "TC-002", "status": "not-applicable", "statusReason": "no such input in the API",
                  "levels": [ { "legacy": "LEG-SP:DEMO0001", "target": "TGT-HTTP:app" } ],
                  "request": { "USER-ID-0001": "X" }
                }
              ]
            }
            """;

    @Test
    void readsAPackageRegisterWithStatusesAndAnHttpRequest() {
        ScenarioRegister register = read(PACKAGE_REGISTER);

        Scenario first = register.scenarios().get(0);
        assertThat(first.http().path()).isEqualTo("/codes/COLOUR");
        assertThat(List.copyOf(first.http().query().keySet())).containsExactly("searchValue", "effectiveDate");
        assertThat(first.levels().get(0).effectiveLens()).isEqualTo("service");
        assertThat(first.hypotheses()).containsExactly("the target returns more rows");
        assertThat(first.isRunnable()).isTrue();
        assertThat(first.compare().emptyExpected()).isTrue();
        assertThat(register.scenarios().get(1).isNotApplicable()).isTrue();

        assertThatThrownBy(() -> read(PACKAGE_REGISTER.replace(", \"statusReason\": \"no such input in the API\"", "")))
                .isInstanceOf(E2eException.class).hasMessageContaining("statusReason");
        assertThatThrownBy(() -> read(PACKAGE_REGISTER.replace("\"path\": \"/codes/COLOUR\"", "\"path\": \"codes\"")))
                .isInstanceOf(E2eException.class).hasMessageContaining("path");
    }

    @Test
    void readsTheUserACallIsMadeAsAndAListComparedAsASetOnItsOwn() {
        ScenarioRegister register = read(PACKAGE_REGISTER
                .replace("\"effectiveDate\": \"20240816\" } }", "\"effectiveDate\": \"20240816\" }, \"principal\": \"AB12\" }")
                .replace("\"compare\": { \"expectEmpty\": true }", "\"compare\": { \"setPaths\": [\"sources\"] }")
                .replace("\"statusReason\": \"no such input in the API\"",
                        "\"statusReason\": \"no such input in the API\", \"blockedBy\": \"identity\""));

        Scenario first = register.scenarios().get(0);
        assertThat(first.http().principal()).isEqualTo("AB12");
        assertThat(first.compare().setPaths()).containsExactly("sources");
        assertThat(first.compare().rowsAsSet("sources")).isTrue();
        assertThat(first.compare().rowsAsSet("wip")).isFalse();
        assertThat(read(PACKAGE_REGISTER).scenarios().get(0).http().principal()).as("no caller").isNull();
        assertThatThrownBy(() -> read(PACKAGE_REGISTER.replace("\"effectiveDate\": \"20240816\" } }",
                "\"effectiveDate\": \"20240816\" }, \"principal\": \"\" }")))
                .isInstanceOf(E2eException.class).hasMessageContaining("principal");
    }

    @Test
    void readsAnAnswerTheArchitectureDecided() {
        String decided = "\"compare\": { \"expectEmpty\": true }, \"decided\": { \"source\": \"PAR-510-05\", "
                + "\"status\": 400, \"recordedStatus\": 500, \"register\": \"parity/p510.md:46\", "
                + "\"required\": \"400 REQUEST-SCHEMA-VALIDATION\", \"tables\": \"recorded\", \"rules\": [\"r1\"] }";
        Scenario first = read(PACKAGE_REGISTER.replace("\"compare\": { \"expectEmpty\": true }", decided))
                .scenarios().get(0);

        assertThat(first.decided()).isEqualTo(new DecidedAnswer("PAR-510-05", 400, 500, "parity/p510.md:46",
                "400 REQUEST-SCHEMA-VALIDATION", "recorded", List.of("r1")));
        assertThat(read(PACKAGE_REGISTER.replace("\"compare\": { \"expectEmpty\": true }",
                "\"decided\": { \"source\": \"PAR-CG-07\", \"status\": 400, \"recordedStatus\": null }"))
                .scenarios().get(0).decided().recordedStatus()).as("the recording gives no status").isNull();
        assertThat(read(PACKAGE_REGISTER).scenarios().get(0).decided()).as("the recording's answer").isNull();
        assertThatThrownBy(() -> read(PACKAGE_REGISTER.replace("\"compare\": { \"expectEmpty\": true }",
                "\"decided\": { \"status\": 400 }")))
                .isInstanceOf(E2eException.class).hasMessageContaining("source");
        assertThatThrownBy(() -> read(PACKAGE_REGISTER.replace("\"compare\": { \"expectEmpty\": true }",
                "\"decided\": { \"source\": \"PAR-1\", \"status\": 400, \"tables\": \"some\" }")))
                .isInstanceOf(E2eException.class).hasMessageContaining("tables");
    }

    @Test
    void reportsEverySchemaViolation() {
        String invalid = VALID.replace("\"P0\"", "\"P9\"")
                .replace("\"SEARCH-VALUE-0001\": \"B\"", "\"bad key!\": \"B\"")
                .replace("\"clock\": \"20240101120000\"", "\"clock\": \"today\"");

        assertThatThrownBy(() -> read(invalid))
                .isInstanceOf(E2eException.class)
                .satisfies(e -> assertThat(((E2eException) e).problems()).hasSizeGreaterThanOrEqualTo(3));
    }

    @Test
    void refusesUnknownKeysMissingLevelsAndMultiLineValues() {
        assertThatThrownBy(() -> read(VALID.replace("\"generatedBy\"", "\"generated_by\""))).isInstanceOf(E2eException.class);
        assertThatThrownBy(() -> read(VALID.replace("\"COLOUR\", \"SEARCH", "\"COL\\nOUR\", \"SEARCH"))).isInstanceOf(E2eException.class);
        String noLevels = """
                { "schemaVersion": "1.0", "mu": "M", "scenarios": [ { "scenarioId": "A", "levels": [], "request": {} } ] }
                """;
        assertThatThrownBy(() -> read(noLevels)).isInstanceOf(E2eException.class);
        assertThatThrownBy(() -> read(VALID.replace("\"1.0\"", "\"2.0\""))).isInstanceOf(E2eException.class);
    }

    @Test
    void refusesInvalidJson() {
        assertThatThrownBy(() -> read("{ not json")).isInstanceOf(E2eException.class).hasMessageContaining("not valid JSON");
    }

    @Test
    void refusesDuplicateIdsWithinOneRegister() {
        String twice = """
                { "schemaVersion": "1.0", "mu": "M", "scenarios": [
                  { "scenarioId": "A", "levels": [ { "legacy": "LEG-SP:U" } ], "request": {} },
                  { "scenarioId": "A", "levels": [ { "legacy": "LEG-SP:U" } ], "request": {} } ] }
                """;
        assertThatThrownBy(() -> read(twice)).isInstanceOf(E2eException.class).hasMessageContaining("duplicate scenarioId 'A'");
    }

    @Test
    void readsADirectoryAndRefusesIdsDefinedTwiceAcrossFiles(@TempDir Path dir) throws IOException {
        Files.writeString(dir.resolve("a.json"), VALID);
        Files.writeString(dir.resolve("ignored.txt"), "not a register");
        assertThat(loader.readDirectory(dir)).hasSize(1);

        Files.writeString(dir.resolve("b.json"), VALID);
        assertThatThrownBy(() -> loader.readDirectory(dir))
                .isInstanceOf(E2eException.class)
                .hasMessageContaining("already defined in a.json");
    }

    @Test
    void aMissingDirectoryIsAnEmptyModule(@TempDir Path dir) {
        assertThat(loader.readDirectory(dir.resolve("scenarios"))).isEmpty();
        assertThat(loader.readDirectory(null)).isEmpty();
    }

    @Test
    void readsFromAPathAndValidatesTrees(@TempDir Path dir) throws IOException {
        Path file = dir.resolve("r.json");
        Files.writeString(file, VALID);
        assertThat(loader.read(file).scenarios()).hasSize(1);
        assertThat(loader.validate(com.insurance.e2e.core.json.JsonSupport.mapper().readTree(VALID))).isEmpty();
        assertThatThrownBy(() -> loader.read(dir.resolve("missing.json"))).isInstanceOf(E2eException.class);
    }

    private ScenarioRegister read(String json) {
        return loader.read("test", new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8)));
    }

    static List<String> ids(ScenarioRegister register) {
        return register.scenarios().stream().map(Scenario::scenarioId).toList();
    }
}
