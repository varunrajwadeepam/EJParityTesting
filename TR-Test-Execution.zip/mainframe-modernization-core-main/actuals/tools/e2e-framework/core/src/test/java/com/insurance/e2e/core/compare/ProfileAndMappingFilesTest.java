package com.insurance.e2e.core.compare;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.TestData;
import com.insurance.e2e.core.json.JsonSupport;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ProfileAndMappingFilesTest {

    @Test
    void missingProfilesMeanNothingIsSignedYet(@TempDir Path dir) {
        ProfileSet set = ProfileSet.load(dir.resolve("profiles.json"));

        assertThat(set.profile("strict").rules()).isEmpty();
        assertThat(set.profile("contract").rules()).isEmpty();
        assertThat(ProfileSet.load(null).profiles()).hasSize(2);
        assertThatThrownBy(() -> set.profile("lenient")).isInstanceOf(E2eException.class);
    }

    @Test
    void contractRulesNeedDecisions(@TempDir Path dir) throws IOException {
        Path file = dir.resolve("profiles.json");
        Files.writeString(file, """
                { "schemaVersion": "1.0", "profiles": [
                  { "name": "contract", "rules": [ { "rule": "RTRIM", "decision": "D-001" },
                                                  { "rule": "IGNORE_FIELDS", "decision": "D-002", "fields": ["X-AS"] } ] } ] }
                """);
        ProfileSet signed = ProfileSet.load(file);
        assertThat(signed.profile("contract").has(NormalizationRule.RTRIM)).isTrue();
        assertThat(signed.profile("contract").ignoredFields()).containsExactly("X-AS");
        assertThat(signed.profile("strict").rules()).isEmpty();

        Files.writeString(file, """
                { "schemaVersion": "1.0", "profiles": [
                  { "name": "strict", "rules": [ { "rule": "RTRIM", "decision": "D-1" } ] },
                  { "name": "contract", "rules": [ { "rule": "RTRIM" }, { "decision": "D-3" } ] } ] }
                """);
        assertThatThrownBy(() -> ProfileSet.load(file))
                .isInstanceOf(E2eException.class)
                .satisfies(e -> assertThat(((E2eException) e).problems()).hasSize(3));
    }

    @Test
    void mappingsLoadByFileName(@TempDir Path dir) {
        JsonSupport.write(dir.resolve("DEMO0001.json"), TestData.mapping());
        MappingRepository repository = MappingRepository.load(dir);

        assertThat(repository.find("DEMO0001")).isPresent();
        assertThat(repository.find("DEMO0001").orElseThrow().groups()).hasSize(1);
        assertThat(repository.find("OTHER")).isEmpty();
        assertThat(repository.all()).containsOnlyKeys("DEMO0001");
        assertThat(MappingRepository.load(dir.resolve("absent")).all()).isEmpty();
        assertThat(MappingRepository.empty().all()).isEmpty();
    }

    @Test
    void theFieldComparatorIsAPlugin() {
        FieldComparePlugin plugin = new FieldComparePlugin();
        assertThat(plugin.id()).isEqualTo("field-comparator");
        assertThat(plugin.kinds()).containsExactly("view-fields");
        assertThat(plugin.availability(null).available()).isTrue();
    }
}
