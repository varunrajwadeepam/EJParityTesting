package com.insurance.e2e.core.misc;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.compare.ComparisonResult;
import com.insurance.e2e.core.compare.FieldDiff;
import com.insurance.e2e.core.mu.MuDescriptor;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.observation.Outcome;
import com.insurance.e2e.core.report.ReportWriter;
import com.insurance.e2e.core.report.RunReport;
import com.insurance.e2e.core.run.ScenarioReport;
import com.insurance.e2e.core.json.JsonSupport;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class SupportingTypesTest {

    @Test
    void occurrenceKeysFollowTheDriverFormat() {
        assertThat(Observation.occurrenceKey("CODE", 7)).isEqualTo("CODE(007)");
        assertThat(Observation.occurrenceKey("CODE", 1234)).isEqualTo("CODE(1234)");
        assertThat(Observation.parseOccurrenceKey("CODE(012)")).isEqualTo(Map.entry("CODE", 12));
        assertThat(Observation.parseOccurrenceKey("CODE")).isNull();
    }

    @Test
    void observationsKnowWhenTheyAreEmpty() {
        assertThat(Observation.rawLegacy(Map.of("A", "  "), null).isEmpty()).isTrue();
        assertThat(Observation.rawLegacy(Map.of("A", "x"), Outcome.ok()).isEmpty()).isFalse();
        assertThat(Observation.canonical(Map.of(), Map.of("g", List.of(Map.of("a", "1"))), null).isEmpty()).isFalse();
        Observation withMeta = Observation.rawLegacy(Map.of(), null).withMeta(Map.of("runId", "r1"));
        assertThat(withMeta.meta()).containsEntry("runId", "r1");
        assertThat(withMeta.outcome().kind()).isEqualTo(Outcome.Kind.OK);
        assertThat(Outcome.failure("X", "boom").kind()).isEqualTo(Outcome.Kind.TECHNICAL_FAILURE);
        assertThat(new Outcome(null, null, null, null).kind()).isEqualTo(Outcome.Kind.OK);
    }

    @Test
    void descriptorsLoadAndValidate(@TempDir Path dir) throws IOException {
        Path file = dir.resolve("mu.yaml");
        Files.writeString(file, """
                schemaVersion: 1
                mu: MU-DEMO-01
                productModule: demo-mu
                servicePoint: DEMO0001
                legacyUnits: [DEMO0001, DEMO0101]
                targetUnits: ["LookupService.lookup"]
                pluginKinds: [LEG-SP, TGT-SP]
                """);
        MuDescriptor descriptor = MuDescriptor.load(file);
        assertThat(descriptor.legacyUnits()).containsExactly("DEMO0001", "DEMO0101");
        assertThat(descriptor.pluginKinds()).contains("TGT-SP");
        assertThat(MuDescriptor.loadIfPresent(dir.resolve("absent.yaml"))).isNull();

        Files.writeString(file, "");
        assertThatThrownBy(() -> MuDescriptor.load(file)).isInstanceOf(E2eException.class);
        Files.writeString(file, "schemaVersion: [unclosed");
        assertThatThrownBy(() -> MuDescriptor.load(file)).isInstanceOf(E2eException.class);
        assertThat(new MuDescriptor(null, null, null, null, null, null, null, null).problems()).hasSize(2);
    }

    @Test
    void reportsRenderJsonAndMarkdown(@TempDir Path dir) throws IOException {
        FieldDiff diff = new FieldDiff("TEXT", FieldDiff.Kind.VALUE, "A", "B|C", "VALUE", "U|TEXT|VALUE:VALUE");
        ComparisonResult contract = new ComparisonResult("S1", "U", "L4", "contract", ComparisonResult.Status.DIFF,
                1, 0, List.of(diff), List.of(), Set.of("D-1"), List.of("U|TEXT|VALUE:VALUE"));
        ScenarioReport failed = new ScenarioReport("S1", "L4", "U", "REPLAY", ScenarioReport.Status.FAILED,
                "DIFF under contract | x", null, contract, "contract", List.of());
        ScenarioReport passed = new ScenarioReport("S2", "L4", "U", "REPLAY", ScenarioReport.Status.PASSED,
                "match", null, null, null, null);
        RunReport report = RunReport.of("MU-DEMO", "REPLAY", "t0", "t1", List.of(failed, passed));

        assertThat(report.counts()).containsEntry("FAILED", 1).containsEntry("PASSED", 1);
        String markdown = ReportWriter.markdown(report);
        assertThat(markdown).contains("# E2E run report - MU-DEMO (REPLAY)", "| S1 | L4 | - | U | FAILED | - | DIFF |",
                "`U|TEXT|VALUE:VALUE` | S1", "DIFF under contract \\| x");

        ReportWriter.writeJson(report, dir.resolve("r.json"));
        ReportWriter.writeMarkdown(report, dir.resolve("md").resolve("r.md"));
        assertThat(JsonSupport.readTree(dir.resolve("r.json")).get("counts").get("FAILED").asInt()).isEqualTo(1);
        assertThat(dir.resolve("md").resolve("r.md")).exists();
        assertThat(new RunReport("m", "LINT", "a", "b", Map.of("PASSED", 3), null).counts()).containsEntry("PASSED", 3);
    }

    @Test
    void reportsListFailuresWithHypothesesAndTheReasonsOfBlockedAndNotApplicableScenarios() {
        ScenarioReport failed = new ScenarioReport("TC-1", "L4", "U", "REPLAY", ScenarioReport.Status.FAILED,
                "DIFF under contract", null, null, "contract", List.of(), "service", "codes-all",
                List.of("the target returns the rows the legacy never copies"),
                new ScenarioReport.TargetAnswer(new Outcome(Outcome.Kind.TECHNICAL_FAILURE, 500L,
                        "java.lang.NullPointerException", null), Map.of("http.status", "500"),
                        "{\"error\":\"Internal | Server Error\"}", false));
        ScenarioReport bare = new ScenarioReport("TC-4", "L4", "U", "REPLAY", ScenarioReport.Status.FAILED,
                "DIFF", null, null, "contract", List.of(), "service", null, null);
        ScenarioReport blocked = new ScenarioReport("TC-2", "L4", "U", "REPLAY", ScenarioReport.Status.BLOCKED,
                "declared blocked: legacy module missing", null, null, null, List.of(), "service", "codes-detail", null);
        ScenarioReport notApplicable = new ScenarioReport("TC-3", "L4", "U", "REPLAY",
                ScenarioReport.Status.NOT_APPLICABLE, "not applicable at the service lens: no such input", null, null,
                null, null, "service", "echo-user", null);

        String markdown = ReportWriter.markdown(RunReport.of("MU-DEMO", "REPLAY", "t0", "t1",
                List.of(failed, bare, blocked, notApplicable)));

        assertThat(markdown).contains("| TC-1 | L4 | service | U | FAILED |",
                "## Failed - with the hypotheses the scenario carries",
                "| Scenario | Title | Hypotheses | Target answered |",
                "| TC-1 | codes-all | the target returns the rows the legacy never copies | TECHNICAL_FAILURE 500: "
                        + "{\"error\":\"Internal \\| Server Error\"} |",
                "| TC-4 |  | - | - |",
                "## Blocked - with the reason", "| TC-2 | codes-detail | declared blocked: legacy module missing |",
                "## Not applicable - never executed, never counted",
                "| TC-3 | echo-user | not applicable at the service lens: no such input |");
        assertThat(failed.hypotheses()).hasSize(1);
        assertThat(bare.hypotheses()).isEmpty();
    }

    @Test
    void exceptionsCarryTheirProblems() {
        E2eException plain = new E2eException("plain");
        E2eException listed = new E2eException("listed", List.of("a", "b"));
        E2eException caused = new E2eException("caused", new IllegalStateException("x"));

        assertThat(plain.problems()).isEmpty();
        assertThat(listed).hasMessage("listed: a; b");
        assertThat(listed.problems()).containsExactly("a", "b");
        assertThat(caused.getCause()).isInstanceOf(IllegalStateException.class);
        assertThat(new E2eException("n", (List<String>) null).problems()).isEmpty();
    }
}
