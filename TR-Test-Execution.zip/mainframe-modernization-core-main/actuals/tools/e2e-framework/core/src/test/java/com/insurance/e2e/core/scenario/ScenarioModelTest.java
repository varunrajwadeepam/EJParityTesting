package com.insurance.e2e.core.scenario;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.TestData;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.observation.Outcome;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ScenarioModelTest {

    @Test
    void bindingReferencesParseAndClassify() {
        BindingRef legacy = BindingRef.parse("LEG-CMP:UNIT0042");
        BindingRef target = BindingRef.parse(" TGT-SP:Service.method ");

        assertThat(legacy.kind()).isEqualTo("LEG-CMP");
        assertThat(legacy.ref()).isEqualTo("UNIT0042");
        assertThat(legacy.isLegacy()).isTrue();
        assertThat(legacy.isServicePoint()).isFalse();
        assertThat(target.isLegacy()).isFalse();
        assertThat(target.isServicePoint()).isTrue();
        assertThat(BindingRef.parse("TGT-HTTP:/lookup").isServicePoint()).isTrue();
        assertThat(target).hasToString("TGT-SP:Service.method");
    }

    @Test
    void malformedBindingReferencesAreRefused() {
        assertThatThrownBy(() -> BindingRef.parse("no-kind")).isInstanceOf(E2eException.class);
        assertThatThrownBy(() -> BindingRef.parse(null)).isInstanceOf(E2eException.class);
        assertThatThrownBy(() -> new BindingRef("LEG-SP", " ")).isInstanceOf(E2eException.class);
    }

    @Test
    void levelsAreEmulatedParityWithALensDerivedFromTheBindingKinds() {
        LevelBinding component = new LevelBinding(null, BindingRef.parse("LEG-CMP:A1"), BindingRef.parse("TGT-CMP:Repo.find"), null);
        LevelBinding servicePoint = TestData.level();
        LevelBinding http = new LevelBinding(null, BindingRef.parse("LEG-SP:A1"), BindingRef.parse("TGT-HTTP:app"), null);
        LevelBinding explicit = new LevelBinding("L5", BindingRef.parse("LEG-SP:A1"), null, "custom", "component");

        assertThat(component.effectiveLevel()).isEqualTo("L4");
        assertThat(component.effectiveLens()).isEqualTo("component");
        assertThat(servicePoint.effectiveLevel()).isEqualTo("L4");
        assertThat(servicePoint.effectiveLens()).isEqualTo("service");
        assertThat(http.effectiveLens()).isEqualTo("service");
        assertThat(explicit.effectiveLevel()).isEqualTo("L5");
        assertThat(explicit.effectiveLens()).isEqualTo("component");
        assertThat(component.effectiveMapping()).isEqualTo("A1");
        assertThat(explicit.effectiveMapping()).isEqualTo("custom");
        assertThat(explicit.toString()).isEqualTo("L5/component LEG-SP:A1");
        assertThat(http.toString()).isEqualTo("L4/service LEG-SP:A1 <-> TGT-HTTP:app");
        assertThatThrownBy(() -> new LevelBinding(null, null, null, null)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void scenarioTagsAndDisplayNameCarryTheTraceability() {
        Scenario scenario = TestData.scenario("DEMO-001");

        assertThat(scenario.effectiveTags()).containsExactly("P0", "PR-1", "EC-1", "level:L4", "lens:service",
                "unit:DEMO0001", "branch:COLOUR", "smoke");
        assertThat(scenario.displayName()).isEqualTo("DEMO-001 [P0 PR-1 EC-1]");
        assertThat(scenario.request()).containsKeys("TABLE-NAME-0001", "SEARCH-VALUE-0001");
        assertThat(List.copyOf(scenario.request().keySet())).containsExactly("TABLE-NAME-0001", "SEARCH-VALUE-0001");
        assertThat(scenario.isRunnable()).isTrue();
        assertThat(scenario.status()).isEqualTo(Scenario.RUNNABLE);
    }

    @Test
    void aPackageScenarioCarriesStatusHttpRequestAndHypotheses() {
        Map<String, String> query = new java.util.LinkedHashMap<>();
        query.put("searchValue", "");
        query.put("effectiveDate", "0");
        HttpRequestSpec http = new HttpRequestSpec("get", "/codes/%20A", query, null, null);
        Scenario scenario = new Scenario("TC-1", Map.of("caseId", "TC-1"), null, null, null, null, null, null, null,
                List.of(TestData.level()), "pack-1", "20240816103000", null, Map.of("TABLE-NAME-0001", " A"), null,
                null, null, "codes-leading-blank", "a leading blank is significant", "Edge", null, null,
                List.of("the target trims the path variable"), true, http);
        Scenario notApplicable = new Scenario("TC-2", null, null, null, null, null, null, null, null,
                List.of(TestData.level()), null, null, null, Map.of(), null, null, null, null, null, null,
                Scenario.NOT_APPLICABLE, "no such input in the API", null, null, null);
        Scenario blocked = new Scenario("TC-3", null, null, null, null, null, null, null, null,
                List.of(TestData.level()), null, null, null, Map.of(), null, null, null, null, null, null,
                Scenario.BLOCKED, "legacy module missing", null, null, null);

        assertThat(http.method()).isEqualTo("GET");
        assertThat(List.copyOf(http.query().keySet())).containsExactly("searchValue", "effectiveDate");
        assertThat(http.headers()).isEmpty();
        assertThat(new HttpRequestSpec(null, "/", null, null, null).method()).isEqualTo("GET");
        assertThat(http.target()).as("the path as written, the query encoded").isEqualTo("/codes/%20A?searchValue=&effectiveDate=0");
        Map<String, String> odd = new java.util.LinkedHashMap<>();
        odd.put("search value", " A~*/é");
        assertThat(new HttpRequestSpec("GET", "/x", odd, null, null).target())
                .isEqualTo("/x?search+value=+A%7E*%2F%C3%A9");
        assertThat(new HttpRequestSpec("GET", "/x", null, null, null).target()).isEqualTo("/x");
        Map<String, String> indexed = new java.util.LinkedHashMap<>();
        indexed.put("context[0].kind", "DIRECT");
        indexed.put("note", "%5B[");
        HttpRequestSpec contexts = new HttpRequestSpec("GET", "/x%5B1%5D", indexed, null, null);
        assertThat(contexts.target()).isEqualTo("/x%5B1%5D?context%5B0%5D.kind=DIRECT&note=%255B%5B");
        assertThat(contexts.readableTarget()).as("brackets readable in the query only; an encoded '%5B' text stays")
                .isEqualTo("/x%5B1%5D?context[0].kind=DIRECT&note=%255B[");
        assertThat(scenario.displayName()).isEqualTo("TC-1 codes-leading-blank");
        assertThat(scenario.effectiveTags()).contains("category:Edge", "clock-sensitive", "lens:service");
        assertThat(scenario.hypotheses()).containsExactly("the target trims the path variable");
        assertThat(scenario.isRunnable()).isTrue();
        assertThat(notApplicable.isNotApplicable()).isTrue();
        assertThat(notApplicable.isRunnable()).isFalse();
        assertThat(blocked.isDeclaredBlocked()).isTrue();
        assertThat(blocked.hypotheses()).isEmpty();
    }

    @Test
    void absentCollectionsBecomeEmptyAndCompareDefaultsApply() {
        Scenario bare = new Scenario("X", null, null, null, null, null, null, null, null, null, null, null, null,
                null, null, null, null);

        assertThat(bare.levels()).isEmpty();
        assertThat(bare.request()).isEmpty();
        assertThat(bare.displayName()).isEqualTo("X");
        assertThat(bare.compare().effectiveProfile()).isEqualTo("contract");
        assertThat(bare.compare().rowsAsSet()).isFalse();
        assertThat(bare.compare().orderReportOnly()).isFalse();
        assertThat(bare.compare().emptyExpected()).isFalse();
        CompareSpec set = new CompareSpec("strict", "set", "report-only", true, null);
        assertThat(set.rowsAsSet()).isTrue();
        assertThat(set.orderReportOnly()).isTrue();
        assertThat(set.emptyExpected()).isTrue();
        assertThat(set.effectiveProfile()).isEqualTo("strict");
    }

    @Test
    void assertionsCheckReportedValuesByteForByte() {
        Observation report = Observation.rawLegacy(Map.of("RC", "0", "TEXT", "A  "), Outcome.ok());

        assertThat(new Assertion("RC", "0", "pt-case").holdsFor(report)).isTrue();
        assertThat(new Assertion("TEXT", "A", "rule").holdsFor(report)).isFalse();
        assertThat(new Assertion("MISSING", "", "rule").holdsFor(report)).isFalse();
    }

    @Test
    void registersDefaultToNoScenarios() {
        assertThat(new ScenarioRegister("1.0", "MU-1", null, null, null).scenarios()).isEmpty();
    }
}
