package com.insurance.e2e.core.junit;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.TestData;
import com.insurance.e2e.core.compare.FieldComparePlugin;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.run.E2eMode;
import com.insurance.e2e.core.scenario.ScenarioRegister;
import com.insurance.e2e.core.spi.CapturePlugin;
import com.insurance.e2e.core.spi.ExecutionContext;
import com.insurance.e2e.core.spi.PluginRegistry;
import com.insurance.e2e.core.spi.TriggerPlugin;
import org.junit.jupiter.api.DynamicContainer;
import org.junit.jupiter.api.DynamicNode;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.opentest4j.TestAbortedException;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class E2eScenarioTestsTest {

    @TempDir
    Path module;

    /** Legacy side that always reports the same synthetic report. */
    static final class Legacy implements TriggerPlugin, CapturePlugin {
        @Override
        public String id() {
            return "legacy";
        }

        @Override
        public com.insurance.e2e.core.spi.ExtensionPoint point() {
            return com.insurance.e2e.core.spi.ExtensionPoint.TRIGGER;
        }

        @Override
        public Set<String> kinds() {
            return Set.of("LEG-SP");
        }

        @Override
        public TriggerResult trigger(TriggerPlugin.Request request) {
            return new TriggerResult(request.binding(), TestData.legacyReport("BLUE", "CYAN"), null, Map.of());
        }

        @Override
        public com.insurance.e2e.core.observation.Observation capture(CapturePlugin.Request request) {
            return (com.insurance.e2e.core.observation.Observation) request.result().payload();
        }
    }

    Path resources() throws IOException {
        Path resources = module.resolve("target").resolve("test-classes").resolve("e2e");
        Files.createDirectories(resources.resolve("scenarios"));
        JsonSupport.write(resources.resolve("scenarios").resolve("register.json"),
                new ScenarioRegister("1.0", "MU-DEMO", null, "test", List.of(TestData.scenario("DEMO-001"))));
        JsonSupport.write(resources.resolve("view-mappings").resolve(TestData.UNIT + ".json"), TestData.mapping());
        Files.writeString(resources.resolve("mu.yaml"), "schemaVersion: 1\nmu: MU-DEMO\nlegacyUnits: [DEMO0001]\n");
        return resources;
    }

    E2eScenarioTests tests(Path resources, E2eMode mode, PluginRegistry registry, Map<String, String> props) {
        return E2eScenarioTests.forModule("e2e")
                .resourceDir(resources)
                .moduleDir(module)
                .mode(mode)
                .registry(registry)
                .context(ExecutionContext.builder().properties(props).environment(Map.of()).build());
    }

    static List<DynamicTest> flatten(List<? extends DynamicNode> nodes) {
        List<DynamicTest> tests = new ArrayList<>();
        for (DynamicNode node : nodes) {
            if (node instanceof DynamicContainer container) {
                tests.addAll(flatten(container.getChildren().map(DynamicNode.class::cast).toList()));
            } else {
                tests.add((DynamicTest) node);
            }
        }
        return tests;
    }

    @Test
    void lintModeYieldsOneContainerPerScenarioAndAReport() throws Throwable {
        PluginRegistry registry = new PluginRegistry().register(new Legacy()).register(new FieldComparePlugin());
        List<DynamicNode> nodes = tests(resources(), E2eMode.LINT, registry, Map.of()).dynamicTests().toList();

        assertThat(nodes).hasSize(3);
        assertThat(nodes.get(0).getDisplayName()).isEqualTo("DEMO-001 [P0 PR-1 EC-1]");
        List<DynamicTest> tests = flatten(nodes);
        assertThatThrownBy(() -> tests.get(0).getExecutable().execute())
                .isInstanceOf(AssertionError.class)
                .hasMessageContaining("BLOCKED")
                .hasMessageContaining("TGT-SP");
        tests.get(1).getExecutable().execute();
        Path report = module.resolve("target").resolve("e2e-reports").resolve("e2e-lint.md");
        assertThat(report).exists();
        assertThat(Files.readString(report)).contains("MU-DEMO", "BLOCKED");
        assertThat(tests.get(2).getDisplayName()).isEqualTo("behaviour specification coverage");
        assertThatThrownBy(() -> tests.get(2).getExecutable().execute())
                .as("no feature generated yet: reported, not failed")
                .isInstanceOf(TestAbortedException.class).hasMessageContaining("no Behaviour Specification yet");
    }

    @Test
    void theRegisterDrivenTestsLintWhateverTheRunModeSays() throws Throwable {
        PluginRegistry registry = new PluginRegistry().register(new Legacy()).register(new FieldComparePlugin());
        List<DynamicTest> tests = flatten(E2eScenarioTests.forModule("e2e").resourceDir(resources()).moduleDir(module)
                .registry(registry)
                .context(ExecutionContext.builder().property("e2e.mode", "replay").environment(Map.of()).build())
                .dynamicTests().toList());

        assertThatThrownBy(() -> tests.get(0).getExecutable().execute()).isInstanceOf(AssertionError.class);
        tests.get(1).getExecutable().execute();
        assertThat(module.resolve("target/e2e-reports/e2e-lint.json")).exists();
        assertThat(module.resolve("target/e2e-reports/e2e-replay.json")).doesNotExist();
    }

    @Test
    void scenariosAreSelectedByIdAndUnknownIdsFail() throws Throwable {
        Path resources = resources();
        JsonSupport.write(resources.resolve("scenarios").resolve("register.json"), new ScenarioRegister("1.0",
                "MU-DEMO", null, "test", List.of(TestData.scenario("DEMO-001"), TestData.scenario("DEMO-002"))));

        List<DynamicNode> one = tests(resources, E2eMode.LINT, new PluginRegistry(),
                Map.of("e2e.scenarios", "DEMO-002")).dynamicTests().toList();
        assertThat(one).extracting(DynamicNode::getDisplayName)
                .containsExactly("DEMO-002 [P0 PR-1 EC-1]", "e2e run report", "behaviour specification coverage");

        List<DynamicNode> typo = tests(resources, E2eMode.LINT, new PluginRegistry(),
                Map.of("e2e.scenarios", "DEMO-001, DEMO-009")).dynamicTests().toList();
        assertThat(typo.get(0).getDisplayName()).isEqualTo("selection");
        assertThatThrownBy(() -> ((DynamicTest) typo.get(0)).getExecutable().execute())
                .isInstanceOf(AssertionError.class).hasMessageContaining("DEMO-009");
        assertThat(typo).extracting(DynamicNode::getDisplayName).contains("DEMO-001 [P0 PR-1 EC-1]")
                .doesNotContain("DEMO-002 [P0 PR-1 EC-1]");
    }

    @Test
    void theCoverageLintComparesTheFeaturesWithTheRegister() throws Throwable {
        Path resources = resources();
        Path features = Files.createDirectories(resources.resolve("features"));
        Files.writeString(features.resolve("demo.feature"), """
                @unit:DEMO0001
                Feature: Demo
                  @DEMO-001 @P0
                  Scenario: DEMO-001 one
                    * a step
                """);
        List<DynamicTest> covered = flatten(tests(resources, E2eMode.LINT, new PluginRegistry(), Map.of())
                .dynamicTests().toList());
        covered.get(covered.size() - 1).getExecutable().execute();

        Files.writeString(features.resolve("other.feature"), """
                Feature: Other
                  Rule: R1 - a rule
                    @DEMO-001
                    Scenario: DEMO-001 again
                      * a step
                    Scenario: nobody
                      * a step
                """);
        List<DynamicTest> twice = flatten(tests(resources, E2eMode.LINT, new PluginRegistry(), Map.of())
                .dynamicTests().toList());
        assertThatThrownBy(() -> twice.get(twice.size() - 1).getExecutable().execute())
                .isInstanceOf(AssertionError.class)
                .hasMessageContaining("other.feature:6 'nobody' names no register scenario")
                .hasMessageContaining("DEMO-001 has 2 feature scenarios (demo.feature:4, other.feature:4)");
    }

    @Test
    void recordModeWritesGoldenMastersIntoTheModuleSources() throws Throwable {
        PluginRegistry registry = new PluginRegistry().register(new Legacy()).register(new FieldComparePlugin());
        List<DynamicTest> tests = flatten(tests(resources(), E2eMode.RECORD, registry,
                Map.of("e2e.record.repeat", "1")).dynamicTests().toList());

        tests.get(0).getExecutable().execute();
        assertThat(module.resolve("src/test/resources/e2e/golden/DEMO0001/DEMO-001.json")).exists();
    }

    @Test
    void goldenIntegrityIsCheckedInLintMode() throws Throwable {
        Path resources = resources();
        Path golden = resources.resolve("golden").resolve("DEMO0001");
        Files.createDirectories(golden);
        Files.writeString(golden.resolve("DEMO-001.json"), "{\"schemaVersion\":\"1.0\"}");
        List<DynamicNode> nodes = tests(resources, E2eMode.LINT, new PluginRegistry(), Map.of()).dynamicTests().toList();

        assertThat(nodes.get(0).getDisplayName()).isEqualTo("golden-master integrity");
        assertThatThrownBy(() -> ((DynamicTest) nodes.get(0)).getExecutable().execute())
                .isInstanceOf(AssertionError.class).hasMessageContaining("golden-master integrity");
    }

    @Test
    void unavailableServicesAbortInsteadOfFailing() throws Throwable {
        PluginRegistry registry = new PluginRegistry().register(new Legacy()).register(new FieldComparePlugin())
                .register(new TriggerPlugin() {
                    @Override
                    public String id() {
                        return "down";
                    }

                    @Override
                    public Set<String> kinds() {
                        return Set.of("TGT-SP");
                    }

                    @Override
                    public com.insurance.e2e.core.spi.Availability availability(ExecutionContext c) {
                        return com.insurance.e2e.core.spi.Availability.down("target not started");
                    }

                    @Override
                    public TriggerResult trigger(Request request) {
                        throw new IllegalStateException("not reached");
                    }
                })
                .register(new CapturePlugin() {
                    @Override
                    public String id() {
                        return "target-capture";
                    }

                    @Override
                    public Set<String> kinds() {
                        return Set.of("TGT-SP");
                    }

                    @Override
                    public com.insurance.e2e.core.observation.Observation capture(CapturePlugin.Request request) {
                        throw new IllegalStateException("not reached");
                    }
                });
        List<DynamicTest> tests = flatten(tests(resources(), E2eMode.LIVE, registry, Map.of()).dynamicTests().toList());

        assertThatThrownBy(() -> tests.get(0).getExecutable().execute())
                .isInstanceOf(TestAbortedException.class).hasMessageContaining("target not started");
    }

    @Test
    void declaredStatusesAbortTheirTestsAndStayInTheReport() throws Throwable {
        Path resources = resources();
        com.insurance.e2e.core.scenario.Scenario notApplicable = new com.insurance.e2e.core.scenario.Scenario(
                "TC-NA", null, null, null, null, null, null, null, null, List.of(TestData.level()), null, null, null,
                Map.of(), null, null, null, "echo", null, null, "not-applicable", "the API has no such input", null,
                null, null);
        com.insurance.e2e.core.scenario.Scenario blocked = new com.insurance.e2e.core.scenario.Scenario(
                "TC-BL", null, null, null, null, null, null, null, null, List.of(TestData.level()), null, null, null,
                Map.of(), null, null, null, "detail", null, null, "blocked", "legacy module missing", null, null, null);
        JsonSupport.write(resources.resolve("scenarios").resolve("register.json"),
                new ScenarioRegister("1.1", "MU-DEMO", null, "test", List.of(notApplicable, blocked)));
        List<DynamicTest> tests = flatten(tests(resources, E2eMode.REPLAY, new PluginRegistry(), Map.of())
                .dynamicTests().toList());

        assertThatThrownBy(() -> tests.get(0).getExecutable().execute())
                .isInstanceOf(TestAbortedException.class).hasMessageContaining("N/A: not applicable at the service lens");
        assertThatThrownBy(() -> tests.get(1).getExecutable().execute())
                .isInstanceOf(TestAbortedException.class).hasMessageContaining("BLOCKED: declared blocked");
        tests.get(2).getExecutable().execute();
        String report = Files.readString(module.resolve("target").resolve("e2e-reports").resolve("e2e-replay.md"));
        assertThat(report).contains("| NOT_APPLICABLE | 1 |", "| BLOCKED | 1 |", "legacy module missing",
                "the API has no such input");
    }

    @Test
    void emptyOrMissingModulesYieldNoTestsAndTagsFilter() throws IOException {
        Path empty = module.resolve("empty");
        Files.createDirectories(empty);
        Files.writeString(empty.resolve("mu.yaml"), "schemaVersion: 1\nmu: MU-EMPTY\n");

        assertThat(tests(empty, E2eMode.LINT, new PluginRegistry(), Map.of()).dynamicTests()).isEmpty();
        assertThat(tests(module.resolve("absent"), E2eMode.LINT, new PluginRegistry(), Map.of()).dynamicTests()).isEmpty();
        assertThat(tests(resources(), E2eMode.LINT, new PluginRegistry(), Map.of("e2e.tags", "P1")).dynamicTests()).isEmpty();
        assertThat(tests(resources(), E2eMode.LINT, new PluginRegistry(), Map.of("e2e.tags", "P0 & level:L4")).dynamicTests()).hasSize(3);
    }

    @Test
    void classpathResourcesResolveToDirectories() {
        assertThat(E2eScenarioTests.classpathDir("no/such/resource")).isNull();
        assertThat(E2eScenarioTests.classpathDir("com/insurance/e2e/core/schema")).isDirectory();
        assertThat(E2eScenarioTests.forModule("no-such-root").registry(new PluginRegistry()).dynamicTests()).isEmpty();
    }

    @Test
    void anInvalidDescriptorFailsTheFactory() throws IOException {
        Path resources = resources();
        Files.writeString(resources.resolve("mu.yaml"), "schemaVersion: 2\n");
        assertThatThrownBy(() -> tests(resources, E2eMode.LINT, new PluginRegistry(), Map.of()).dynamicTests())
                .isInstanceOf(E2eException.class).hasMessageContaining("mu is required");
    }
}
