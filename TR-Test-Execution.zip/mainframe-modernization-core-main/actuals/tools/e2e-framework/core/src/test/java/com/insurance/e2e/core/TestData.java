package com.insurance.e2e.core;

import com.insurance.e2e.core.compare.FieldMapping;
import com.insurance.e2e.core.compare.FieldType;
import com.insurance.e2e.core.compare.GroupMapping;
import com.insurance.e2e.core.compare.OutcomeMapping;
import com.insurance.e2e.core.compare.ViewMapping;
import com.insurance.e2e.core.golden.Provenance;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.observation.Outcome;
import com.insurance.e2e.core.scenario.BindingRef;
import com.insurance.e2e.core.scenario.CompareSpec;
import com.insurance.e2e.core.scenario.LevelBinding;
import com.insurance.e2e.core.scenario.Scenario;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Synthetic test data shared by the core tests (no real program or application names). */
public final class TestData {

    public static final String UNIT = "DEMO0001";

    private TestData() {
    }

    public static LevelBinding level() {
        return new LevelBinding(null, BindingRef.parse("LEG-SP:" + UNIT), BindingRef.parse("TGT-SP:DemoService.lookup"), null);
    }

    public static Scenario scenario(String id) {
        return scenario(id, CompareSpec.defaults(), null);
    }

    public static Scenario scenario(String id, CompareSpec compare, String fixture) {
        Map<String, String> request = new LinkedHashMap<>();
        request.put("TABLE-NAME-0001", "COLOUR");
        request.put("SEARCH-VALUE-0001", "B");
        return new Scenario(id, Map.of("generator", "TS-1"), UNIT, "COLOUR", "P0", List.of("BR-1"), List.of("PR-1"),
                List.of("EC-1"), List.of("smoke"), List.of(level()), fixture, "20240101120000", "logic", request,
                compare, List.of(), null);
    }

    /** Legacy report: response code, message, count and two occurrences of a code/text group. */
    public static Observation legacyReport(String text1, String text2) {
        Map<String, String> fields = new LinkedHashMap<>();
        fields.put("RESPONSE-CODE-0002", "0");
        fields.put("MESSAGE-0002", "    ");
        fields.put("EXIT-STATE", "0");
        fields.put("COUNT-0002", "2");
        fields.put("CODE-0003(001)", "B    ");
        fields.put("TEXT-0003(001)", text1);
        fields.put("CODE-0003(002)", "C    ");
        fields.put("TEXT-0003(002)", text2);
        fields.put("CODE-0003(003)", "     ");
        fields.put("TEXT-0003(003)", "    ");
        return Observation.rawLegacy(fields, Outcome.ok());
    }

    public static ViewMapping mapping() {
        return new ViewMapping("1.0", UNIT, "demo mapping",
                List.of(new FieldMapping("TABLE-NAME-0001", "tableName", FieldType.STRING, false, null),
                        new FieldMapping("SEARCH-VALUE-0001", "searchValue", FieldType.STRING, false, null)),
                List.of(new FieldMapping("RESPONSE-CODE-0002", "responseCode", FieldType.NUMBER, false, null),
                        new FieldMapping("MESSAGE-0002", "message", FieldType.TEXT, false, null),
                        new FieldMapping("ATTR-0002AS", null, FieldType.STRING, false, "legacy-only attribute byte")),
                List.of(new GroupMapping("rows", "items", "COUNT-0002",
                        List.of(new FieldMapping("CODE-0003", "code", FieldType.CODE, false, null),
                                new FieldMapping("TEXT-0003", "text", FieldType.TEXT, false, null)))),
                List.of("ATTR-0002AS"), List.of(), new OutcomeMapping("EXIT-STATE", null));
    }

    public static Provenance provenance(String fixture) {
        return new Provenance("gnucobol-emulated", "engine-1", "image-1", "patch-1", "shims-1",
                Map.of("DEMO0001", "hash-a"), "driver-1", fixture, "20240101120000", Map.of("AUTOCOMMIT", "off"),
                "logic", "2026-10-02T10:00:00Z", 2);
    }
}
