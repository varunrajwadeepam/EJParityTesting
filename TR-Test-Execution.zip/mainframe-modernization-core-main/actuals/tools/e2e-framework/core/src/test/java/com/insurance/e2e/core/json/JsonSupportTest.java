package com.insurance.e2e.core.json;

import com.fasterxml.jackson.databind.JsonNode;
import com.insurance.e2e.core.E2eException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class JsonSupportTest {

    @Test
    void canonicalHashIgnoresKeyOrderButNotValues() throws IOException {
        JsonNode a = JsonSupport.mapper().readTree("{\"b\":1,\"a\":{\"y\":[1,2],\"x\":\"v\"}}");
        JsonNode b = JsonSupport.mapper().readTree("{ \"a\": { \"x\": \"v\", \"y\": [1, 2] }, \"b\": 1 }");
        JsonNode c = JsonSupport.mapper().readTree("{\"a\":{\"x\":\"v\",\"y\":[2,1]},\"b\":1}");

        assertThat(JsonSupport.canonicalHash(a)).isEqualTo(JsonSupport.canonicalHash(b));
        assertThat(JsonSupport.canonicalHash(a)).isNotEqualTo(JsonSupport.canonicalHash(c));
        assertThat(new String(JsonSupport.canonicalBytes(b), StandardCharsets.UTF_8))
                .isEqualTo("{\"a\":{\"x\":\"v\",\"y\":[1,2]},\"b\":1}");
    }

    @Test
    void hashesFilesAndBytes(@TempDir Path dir) throws IOException {
        Path file = dir.resolve("x.txt");
        Files.writeString(file, "abc");
        assertThat(JsonSupport.sha256Hex(file))
                .isEqualTo("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")
                .isEqualTo(JsonSupport.sha256Hex("abc".getBytes(StandardCharsets.UTF_8)));
        assertThatThrownBy(() -> JsonSupport.sha256Hex(dir.resolve("missing"))).isInstanceOf(RuntimeException.class);
    }

    @Test
    void writesAndReadsFiles(@TempDir Path dir) {
        Path file = dir.resolve("nested").resolve("value.json");
        JsonSupport.write(file, Map.of("k", List.of("v")));

        @SuppressWarnings("unchecked")
        Map<String, Object> back = JsonSupport.read(file, Map.class);
        assertThat(back).containsEntry("k", List.of("v"));
        assertThat(JsonSupport.readTree(file).get("k").get(0).asText()).isEqualTo("v");
        assertThat(JsonSupport.toJson(Map.of("a", 1))).contains("\"a\" : 1");
        assertThatThrownBy(() -> JsonSupport.read(dir.resolve("none.json"), Map.class)).isInstanceOf(E2eException.class);
        assertThatThrownBy(() -> JsonSupport.readTree(dir.resolve("none.json"))).isInstanceOf(E2eException.class);
    }

    @Test
    void scalarTextRendersJsonScalars() throws IOException {
        JsonNode node = JsonSupport.mapper().readTree("{\"n\":1.50,\"i\":7,\"s\":\"x \",\"b\":true,\"z\":null,\"o\":{\"a\":1}}");

        assertThat(JsonSupport.scalarText(node.get("n"))).isEqualTo("1.50");
        assertThat(JsonSupport.scalarText(node.get("i"))).isEqualTo("7");
        assertThat(JsonSupport.scalarText(node.get("s"))).isEqualTo("x ");
        assertThat(JsonSupport.scalarText(node.get("b"))).isEqualTo("true");
        assertThat(JsonSupport.scalarText(node.get("z"))).isNull();
        assertThat(JsonSupport.scalarText(node.get("missing"))).isNull();
        assertThat(JsonSupport.scalarText(node.get("o"))).isEqualTo("{\"a\":1}");
        assertThat(JsonSupport.scalarText(null)).isNull();
        // Java results keep their scale as well (strict compares 1.50 and 1.5 as different values).
        JsonNode fromJava = JsonSupport.mapper().valueToTree(Map.of("v", new java.math.BigDecimal("1.50")));
        assertThat(JsonSupport.scalarText(fromJava.get("v"))).isEqualTo("1.50");
    }

    @Test
    void orderedCopyKeepsOrderAndNulls() {
        Map<String, String> source = new LinkedHashMap<>();
        source.put("z", null);
        source.put("a", "1");

        Map<String, String> copy = JsonSupport.orderedCopy(source);
        assertThat(copy.keySet()).containsExactly("z", "a");
        assertThat(copy.get("z")).isNull();
        assertThat(copy).containsEntry("a", "1");
        assertThat(JsonSupport.orderedCopy(new HashMap<String, String>())).isEmpty();
        assertThat(JsonSupport.orderedCopy((Map<String, String>) null)).isEmpty();
    }

    @Test
    void readsYaml() throws IOException {
        Map<?, ?> yaml = JsonSupport.yamlMapper().readValue("a: 1\nb: [x, y]\n", Map.class);
        assertThat(yaml.get("b")).isEqualTo(List.of("x", "y"));
    }

    @Test
    void schemasValidateAndRejectUnknownResources() throws IOException {
        JsonNode bad = JsonSupport.mapper().readTree("{\"schemaVersion\":\"1.0\"}");
        assertThat(Schemas.validate(Schemas.SCENARIO_REGISTER, bad)).isNotEmpty();
        assertThatThrownBy(() -> Schemas.validate("/no/such/schema.json", bad)).isInstanceOf(E2eException.class);
    }
}
