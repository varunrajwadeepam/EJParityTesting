package com.insurance.e2e.core.junit;

import com.insurance.e2e.core.E2eException;
import org.junit.jupiter.api.Test;

import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class TagExpressionTest {

    private static final Set<String> TAGS = Set.of("P0", "level:L4", "PR-17", "unit:DEMO0001");

    @Test
    void blankSelectsEverything() {
        assertThat(TagExpression.parse(null).matches(Set.of())).isTrue();
        assertThat(TagExpression.parse("  ").matches(TAGS)).isTrue();
    }

    @Test
    void operatorsCombine() {
        assertThat(TagExpression.parse("P0").matches(TAGS)).isTrue();
        assertThat(TagExpression.parse("P1").matches(TAGS)).isFalse();
        assertThat(TagExpression.parse("P0 & level:L4").matches(TAGS)).isTrue();
        assertThat(TagExpression.parse("P0 & !PR-17").matches(TAGS)).isFalse();
        assertThat(TagExpression.parse("P1 | unit:DEMO0001").matches(TAGS)).isTrue();
        assertThat(TagExpression.parse("!(P1 | P2) & (lens:component | level:L4)").matches(TAGS)).isTrue();
        assertThat(TagExpression.parse("!!P0").matches(TAGS)).isTrue();
        assertThat(TagExpression.parse("P0 & level:L4")).hasToString("P0 & level:L4");
    }

    @Test
    void malformedExpressionsAreRefused() {
        assertThatThrownBy(() -> TagExpression.parse("P0 &")).isInstanceOf(E2eException.class);
        assertThatThrownBy(() -> TagExpression.parse("(P0")).isInstanceOf(E2eException.class);
        assertThatThrownBy(() -> TagExpression.parse("P0 P1")).isInstanceOf(E2eException.class);
        assertThatThrownBy(() -> TagExpression.parse("P0 # P1")).isInstanceOf(E2eException.class);
    }
}
