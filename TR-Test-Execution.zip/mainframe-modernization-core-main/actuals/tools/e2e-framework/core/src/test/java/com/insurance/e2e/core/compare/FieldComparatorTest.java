package com.insurance.e2e.core.compare;

import com.fasterxml.jackson.databind.JsonNode;
import com.insurance.e2e.core.TestData;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.observation.Outcome;
import com.insurance.e2e.core.scenario.CompareSpec;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class FieldComparatorTest {

    private final FieldComparator comparator = new FieldComparator();
    private final NormalizationProfile strict = NormalizationProfile.strict();
    private final NormalizationProfile contract = new NormalizationProfile("contract", List.of(
            new NormalizationProfile.RuleBinding(NormalizationRule.RTRIM, "D-001", null),
            new NormalizationProfile.RuleBinding(NormalizationRule.NULL_AS_BLANK, "D-002", null),
            new NormalizationProfile.RuleBinding(NormalizationRule.NUMERIC_SCALE_INSENSITIVE, "D-003", null)));

    static Observation target(String json) {
        try {
            return Observation.targetPayload(JsonSupport.mapper().readTree(json), Outcome.ok(0L));
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    static final String MATCHING_TARGET = """
            { "responseCode": 0, "message": null,
              "items": [ { "code": "B", "text": "BLUE" }, { "code": "C", "text": "CYAN" } ] }
            """;

    @Test
    void legacyProjectionUsesTheCountFieldAndOccurrences() {
        Observation canonical = TestData.mapping().toCanonical(TestData.legacyReport("BLUE      ", "CYAN"));

        assertThat(canonical.form()).isEqualTo(Observation.Form.CANONICAL);
        assertThat(canonical.fields()).containsOnlyKeys("RESPONSE-CODE-0002", "MESSAGE-0002");
        assertThat(canonical.groups().get("rows")).hasSize(2);
        assertThat(canonical.groups().get("rows").get(0)).containsEntry("CODE-0003", "B    ").containsEntry("TEXT-0003", "BLUE      ");
        assertThat(canonical.outcome().exitState()).isZero();
    }

    @Test
    void targetProjectionFollowsDotPathsAndLists() {
        Observation canonical = TestData.mapping().toCanonical(target(MATCHING_TARGET));

        assertThat(canonical.fields()).containsEntry("RESPONSE-CODE-0002", "0").containsKey("MESSAGE-0002");
        assertThat(canonical.fields().get("MESSAGE-0002")).isNull();
        assertThat(canonical.groups().get("rows")).extracting(r -> r.get("CODE-0003")).containsExactly("B", "C");
        assertThat(canonical.groups().get("rows").get(1)).containsEntry("TEXT-0003", "CYAN");
    }

    @Test
    void contractMatchesWhatStrictReportsAsRepresentationalDifferences() {
        Observation legacy = TestData.legacyReport("BLUE", "CYAN");
        Observation tgt = target(MATCHING_TARGET);

        ComparisonResult underContract = comparator.compare("S1", "L4", legacy, tgt, TestData.mapping(), contract, CompareSpec.defaults());
        ComparisonResult underStrict = comparator.compare("S1", "L4", legacy, tgt, TestData.mapping(), strict, CompareSpec.defaults());

        assertThat(underContract.status()).isEqualTo(ComparisonResult.Status.MATCH);
        assertThat(underContract.isMatch()).isTrue();
        assertThat(underContract.decisions()).containsExactlyInAnyOrder("D-001", "D-002", "D-003");
        assertThat(underStrict.status()).isEqualTo(ComparisonResult.Status.DIFF);
        assertThat(underStrict.diffs()).extracting(FieldDiff::pattern).contains("TRAILING_BLANKS", "NULL_VS_BLANK");
        assertThat(underStrict.signatures()).contains("DEMO0001|rows[].CODE-0003|VALUE:TRAILING_BLANKS",
                "DEMO0001|MESSAGE-0002|VALUE:NULL_VS_BLANK");
        assertThat(underStrict.compared()).isGreaterThan(underStrict.matched());
    }

    @Test
    void valueRowCountAndExitStateDifferencesAreReported() {
        Observation legacy = TestData.legacyReport("BLUE", "CYAN");
        Observation tgt = Observation.targetPayload(read("""
                { "responseCode": 1, "message": "", "items": [ { "code": "B", "text": "NAVY" } ] }"""), Outcome.ok(1837L));

        ComparisonResult result = comparator.compare("S2", "L4", legacy, tgt, TestData.mapping(), contract, CompareSpec.defaults());

        assertThat(result.status()).isEqualTo(ComparisonResult.Status.DIFF);
        assertThat(result.diffs()).extracting(FieldDiff::kind).contains(FieldDiff.Kind.VALUE, FieldDiff.Kind.ROW_COUNT,
                FieldDiff.Kind.EXIT_STATE);
        assertThat(result.diffs()).filteredOn(d -> d.field().equals("rows[1].TEXT-0003"))
                .singleElement().satisfies(d -> assertThat(d.pattern()).isEqualTo("VALUE"));
    }

    @Test
    void anErrorStatusIsComparedOnTheOutcomeOnlyUnderTheSignedRule() {
        NormalizationProfile http = new NormalizationProfile("contract", List.of(
                new NormalizationProfile.RuleBinding(NormalizationRule.RTRIM, "PKG-CMP-U", null),
                new NormalizationProfile.RuleBinding(NormalizationRule.OUTCOME_ONLY_ON_ERROR, "PKG-CMP-U", null)));
        ViewMapping body = new ViewMapping("1.0", "U", null, List.of(),
                List.of(new FieldMapping("status", "status", FieldType.NUMBER, false, null)), List.of(), List.of(),
                List.of(), null);
        Observation expected503 = Observation.targetPayload(read("{ \"status\": 503, \"error\": \"Service Unavailable\" }"),
                new Outcome(Outcome.Kind.TECHNICAL_FAILURE, 503L, null, null));
        Observation actual503 = Observation.targetPayload(read("{ \"timestamp\": \"t\", \"message\": \"generic\" }"),
                new Outcome(Outcome.Kind.TECHNICAL_FAILURE, 503L, null, null));
        Observation actual500 = Observation.targetPayload(read("{}"),
                new Outcome(Outcome.Kind.TECHNICAL_FAILURE, 500L, null, null));
        Observation expected200 = Observation.targetPayload(read("{ \"status\": 1 }"), Outcome.ok(200L));
        Observation actual400 = Observation.targetPayload(read("{ \"status\": 400 }"),
                new Outcome(Outcome.Kind.BUSINESS_EXCEPTION, 400L, null, null));

        ComparisonResult same = comparator.compare("S", "L4", expected503, actual503, body, http, CompareSpec.defaults());
        ComparisonResult otherStatus = comparator.compare("S", "L4", expected503, actual500, body, http, CompareSpec.defaults());
        ComparisonResult clientError = comparator.compare("S", "L4", expected200, actual400, body, http, CompareSpec.defaults());
        ComparisonResult withoutRule = comparator.compare("S", "L4", expected503, actual503, body, contract, CompareSpec.defaults());

        assertThat(same.status()).isEqualTo(ComparisonResult.Status.MATCH);
        assertThat(same.notes()).anyMatch(n -> n.contains("OUTCOME_ONLY_ON_ERROR"));
        assertThat(otherStatus.status()).isEqualTo(ComparisonResult.Status.DIFF);
        assertThat(otherStatus.diffs()).extracting(FieldDiff::kind).containsExactly(FieldDiff.Kind.EXIT_STATE);
        assertThat(clientError.diffs()).extracting(FieldDiff::kind).containsExactly(FieldDiff.Kind.EXIT_STATE);
        assertThat(withoutRule.diffs()).extracting(FieldDiff::kind).contains(FieldDiff.Kind.MISSING_IN_TARGET);
    }

    @Test
    void outcomeKindsMustAgree() {
        Observation legacy = TestData.legacyReport("BLUE", "CYAN");
        Observation failed = new Observation(Observation.Form.TARGET_PAYLOAD, Map.of(), Map.of(),
                new Outcome(Outcome.Kind.BUSINESS_EXCEPTION, null, "LookupException", "not found"), null, Map.of());

        ComparisonResult result = comparator.compare("S3", "L4", legacy, failed, TestData.mapping(), contract, CompareSpec.defaults());

        assertThat(result.diffs()).extracting(FieldDiff::kind).contains(FieldDiff.Kind.OUTCOME_KIND,
                FieldDiff.Kind.MISSING_IN_TARGET);
    }

    @Test
    void aCataloguedBusinessExceptionEqualsACompletedLegacyRunWithTheSameExitState() {
        ViewMapping exitOnly = new ViewMapping("1.0", "U", null, List.of(), List.of(), List.of(), List.of(), List.of(),
                new OutcomeMapping("EXIT-STATE", null));
        Observation legacy = Observation.rawLegacy(Map.of("EXIT-STATE", "1837641424", "TEXT", "x"), Outcome.ok());
        Observation sameOutcome = new Observation(Observation.Form.TARGET_PAYLOAD, Map.of(), Map.of(),
                new Outcome(Outcome.Kind.BUSINESS_EXCEPTION, 1837641424L, "NotFound", "not found"), null, Map.of());
        Observation otherExit = new Observation(Observation.Form.TARGET_PAYLOAD, Map.of(), Map.of(),
                new Outcome(Outcome.Kind.BUSINESS_EXCEPTION, 7L, "NotFound", "not found"), null, Map.of());
        Observation crashed = new Observation(Observation.Form.TARGET_PAYLOAD, Map.of(), Map.of(),
                Outcome.failure("NullPointerException", null), null, Map.of());

        assertThat(comparator.compare("S", "L4", legacy, sameOutcome, exitOnly, strict, CompareSpec.defaults()).diffs())
                .extracting(FieldDiff::kind).doesNotContain(FieldDiff.Kind.OUTCOME_KIND, FieldDiff.Kind.EXIT_STATE);
        assertThat(comparator.compare("S", "L4", legacy, otherExit, exitOnly, strict, CompareSpec.defaults()).diffs())
                .extracting(FieldDiff::kind).contains(FieldDiff.Kind.EXIT_STATE).doesNotContain(FieldDiff.Kind.OUTCOME_KIND);
        assertThat(comparator.compare("S", "L4", legacy, crashed, exitOnly, strict, CompareSpec.defaults()).diffs())
                .extracting(FieldDiff::kind).contains(FieldDiff.Kind.OUTCOME_KIND);
    }

    @Test
    void rowsComparedAsASetReportOrderSeparately() {
        Observation legacy = TestData.legacyReport("BLUE", "CYAN");
        Observation swapped = target("""
                { "responseCode": 0, "message": "", "items": [ { "code": "C", "text": "CYAN" }, { "code": "B", "text": "BLUE" } ] }""");

        ComparisonResult reportOnly = comparator.compare("S4", "L4", legacy, swapped, TestData.mapping(), contract,
                new CompareSpec(null, "set", "report-only", null, null));
        ComparisonResult strictOrder = comparator.compare("S4", "L4", legacy, swapped, TestData.mapping(), contract,
                new CompareSpec(null, "set", "strict", null, null));
        ComparisonResult ordered = comparator.compare("S4", "L4", legacy, swapped, TestData.mapping(), contract,
                CompareSpec.defaults());

        assertThat(reportOnly.status()).isEqualTo(ComparisonResult.Status.MATCH);
        assertThat(reportOnly.notes()).anyMatch(n -> n.contains("order of rows differs"));
        assertThat(strictOrder.diffs()).extracting(FieldDiff::kind).containsExactly(FieldDiff.Kind.ORDER);
        assertThat(ordered.status()).isEqualTo(ComparisonResult.Status.DIFF);
    }

    @Test
    void aListNamedAsASetIsComparedAsOneAndAnotherListKeepsItsOrder() {
        Observation legacy = TestData.legacyReport("BLUE", "CYAN");
        Observation swapped = target("""
                { "responseCode": 0, "message": "", "items": [ { "code": "C", "text": "CYAN" }, { "code": "B", "text": "BLUE" } ] }""");

        ComparisonResult named = comparator.compare("S4", "L4", legacy, swapped, TestData.mapping(), contract,
                new CompareSpec(null, null, "report-only", null, null, null, List.of("rows")));
        ComparisonResult other = comparator.compare("S4", "L4", legacy, swapped, TestData.mapping(), contract,
                new CompareSpec(null, null, "report-only", null, null, null, List.of("sources")));

        assertThat(named.status()).isEqualTo(ComparisonResult.Status.MATCH);
        assertThat(named.notes()).anyMatch(n -> n.contains("order of rows differs"));
        assertThat(other.status()).as("only the named list is a set").isEqualTo(ComparisonResult.Status.DIFF);
        assertThat(new CompareSpec(null, null, null, null, null, null, List.of("rows")).rowsAsSet()).isFalse();
        assertThat(new CompareSpec(null, "set", null, null, null).rowsAsSet("anything")).isTrue();
    }

    @Test
    void setComparisonFindsMissingAndExtraRows() {
        Observation legacy = TestData.legacyReport("BLUE", "CYAN");
        Observation other = target("""
                { "responseCode": 0, "message": "", "items": [ { "code": "B", "text": "BLUE" }, { "code": "D", "text": "DUSK" } ] }""");

        ComparisonResult result = comparator.compare("S5", "L4", legacy, other, TestData.mapping(), contract,
                new CompareSpec(null, "set", null, null, null));

        assertThat(result.diffs()).extracting(FieldDiff::kind)
                .containsExactlyInAnyOrder(FieldDiff.Kind.ROW_MISSING_IN_TARGET, FieldDiff.Kind.ROW_EXTRA_IN_TARGET);
        assertThat(result.signatures()).contains("DEMO0001|rows[]|ROW_MISSING_IN_TARGET");
    }

    @Test
    void emptyAgainstEmptyIsVacuousUnlessExpected() {
        Map<String, String> fields = new LinkedHashMap<>();
        fields.put("RESPONSE-CODE-0002", "0");
        fields.put("MESSAGE-0002", " ");
        fields.put("COUNT-0002", "0");
        Observation legacy = Observation.rawLegacy(fields, Outcome.ok(0L));
        Observation tgt = target("{ \"responseCode\": 0, \"message\": \"\", \"items\": [] }");

        ComparisonResult vacuous = comparator.compare("S6", "L4", legacy, tgt, TestData.mapping(), contract, CompareSpec.defaults());
        ComparisonResult expected = comparator.compare("S6", "L4", legacy, tgt, TestData.mapping(), contract,
                new CompareSpec(null, null, null, true, null));

        assertThat(vacuous.status()).isEqualTo(ComparisonResult.Status.VACUOUS);
        assertThat(vacuous.notes()).anyMatch(n -> n.startsWith("anti-vacuity"));
        assertThat(expected.status()).isEqualTo(ComparisonResult.Status.MATCH);
    }

    @Test
    void identityMappingComparesAllReportedFieldsAndFindsMissingOnes() {
        Observation a = TestData.legacyReport("BLUE", "CYAN");
        Map<String, String> fewer = new LinkedHashMap<>(a.fields());
        fewer.remove("TEXT-0003(002)");
        fewer.put("EXTRA", "1");
        Observation b = Observation.rawLegacy(fewer, Outcome.ok());

        ComparisonResult same = comparator.compare("S7", "L4", a, a, ViewMapping.identity("U"), strict, CompareSpec.defaults());
        ComparisonResult differs = comparator.compare("S7", "L4", a, b, ViewMapping.identity("U"), strict, CompareSpec.defaults());

        assertThat(same.status()).isEqualTo(ComparisonResult.Status.MATCH);
        assertThat(differs.diffs()).extracting(FieldDiff::kind)
                .containsExactlyInAnyOrder(FieldDiff.Kind.MISSING_IN_TARGET, FieldDiff.Kind.MISSING_IN_LEGACY);
    }

    @Test
    void ignoredFieldsAndMissingMappedFieldsAreHandled() {
        NormalizationProfile ignoring = new NormalizationProfile("contract", List.of(
                new NormalizationProfile.RuleBinding(NormalizationRule.IGNORE_FIELDS, "D-9", List.of("MESSAGE-0002", "TEXT-0003")),
                new NormalizationProfile.RuleBinding(NormalizationRule.RTRIM, "D-1", null)));
        Observation legacy = TestData.legacyReport("BLUE", "CYAN");
        Observation tgt = target("{ \"responseCode\": 0, \"message\": \"other\", \"items\": [ { \"code\": \"B\", \"text\": \"X\" }, { \"code\": \"C\" } ] }");

        ComparisonResult result = comparator.compare("S8", "L4", legacy, tgt, TestData.mapping(), ignoring, CompareSpec.defaults());

        assertThat(result.status()).isEqualTo(ComparisonResult.Status.MATCH);
        assertThat(result.notes()).anyMatch(n -> n.contains("not compared"));
        assertThat(ignoring.ignoredFields()).containsExactly("MESSAGE-0002", "TEXT-0003");

        ViewMapping withMissing = new ViewMapping("1.0", "U", null, List.of(),
                List.of(new FieldMapping("NOT-REPORTED", "nowhere", FieldType.STRING, false, null)),
                List.of(), List.of(), List.of(), null);
        ComparisonResult missing = comparator.compare("S9", "L4", legacy, tgt, withMissing, strict, CompareSpec.defaults());
        assertThat(missing.diffs()).extracting(FieldDiff::kind).containsExactly(FieldDiff.Kind.MISSING_ON_BOTH);
    }

    @Test
    void aScenarioLeavesOutAFieldOrOneGroupsFieldWithTheDecisionItRestsOn() {
        Observation legacy = TestData.legacyReport("BLUE", "CYAN");
        Observation tgt = target("{ \"responseCode\": 0, \"message\": \"other\", \"items\": [ { \"code\": \"B\", \"text\": \"X\" }, { \"code\": \"C\", \"text\": \"Y\" } ] }");
        NormalizationProfile ignoring = contract.ignoring(List.of("MESSAGE-0002"), "PAR-C-07")
                .ignoring(List.of("rows[].TEXT-0003"), "PAR-X");
        NormalizationProfile elsewhere = contract.ignoring(List.of("other[].TEXT-0003"), "PAR-X");

        ComparisonResult result = comparator.compare("S10", "L4", legacy, tgt, TestData.mapping(), ignoring, CompareSpec.defaults());
        ComparisonResult compared = comparator.compare("S10", "L4", legacy, tgt, TestData.mapping(), elsewhere, CompareSpec.defaults());
        ComparisonResult asSet = comparator.compare("S10", "L4", legacy, tgt, TestData.mapping(), ignoring,
                new CompareSpec(null, "set", "report-only", null, null));

        assertThat(result.status()).isEqualTo(ComparisonResult.Status.MATCH);
        assertThat(result.decisions()).contains("D-001", "PAR-C-07", "PAR-X");
        assertThat(asSet.status()).isEqualTo(ComparisonResult.Status.MATCH);
        assertThat(ignoring.ignores("rows", "TEXT-0003")).isTrue();
        assertThat(ignoring.ignores(null, "TEXT-0003")).isFalse();
        assertThat(compared.diffs()).extracting(FieldDiff::field).contains("MESSAGE-0002", "rows[1].TEXT-0003");
        assertThat(contract.ignoring(List.of(), "PAR-X")).isSameAs(contract);
    }

    @Test
    void normalizationRulesBehaveAsDocumented() {
        FieldMapping text = FieldMapping.of("T");
        FieldMapping number = new FieldMapping("N", "n", FieldType.NUMBER, false, null);
        FieldMapping echo = new FieldMapping("E", "e", FieldType.STRING, true, null);
        NormalizationProfile all = new NormalizationProfile("contract", List.of(
                new NormalizationProfile.RuleBinding(NormalizationRule.RTRIM, "D", null),
                new NormalizationProfile.RuleBinding(NormalizationRule.NULL_AS_BLANK, "D", null),
                new NormalizationProfile.RuleBinding(NormalizationRule.NUMERIC_SCALE_INSENSITIVE, "D", null),
                new NormalizationProfile.RuleBinding(NormalizationRule.TRIM_ECHO, "D", null)));

        assertThat(strict.normalize("A  ", text)).isEqualTo("A  ");
        assertThat(strict.normalize(null, text)).isNull();
        assertThat(strict.normalize("1.50", number)).isEqualTo("1.50");
        assertThat(strict.normalize("+7", number)).isEqualTo("7");
        assertThat(strict.normalize("n/a", number)).isEqualTo("n/a");
        assertThat(all.normalize("A  ", text)).isEqualTo("A");
        assertThat(all.normalize(null, text)).isEmpty();
        assertThat(all.normalize("   ", text)).isEmpty();
        assertThat(all.normalize("1.50", number)).isEqualTo("1.5");
        assertThat(all.normalize("0.00", number)).isEqualTo("0");
        assertThat(all.normalize(" ", number)).isEmpty();
        assertThat(strict.normalize(" ", number)).isEmpty();
        assertThat(all.normalize("  KIND   ", echo)).isEqualTo("KIND");
        assertThat(strict.decisions()).isEmpty();
    }

    @Test
    void diffPatternsClassifyRepresentationalDifferences() {
        assertThat(DiffPatterns.classify(null, " ")).isEqualTo("NULL_VS_BLANK");
        assertThat(DiffPatterns.classify("x", null)).isEqualTo("NULL_VS_VALUE");
        assertThat(DiffPatterns.classify("A  ", "A")).isEqualTo("TRAILING_BLANKS");
        assertThat(DiffPatterns.classify(" A", "A")).isEqualTo("PADDING");
        assertThat(DiffPatterns.classify("abc", "ABC")).isEqualTo("CASE");
        assertThat(DiffPatterns.classify("1.50", "1.5")).isEqualTo("NUMERIC_SCALE");
        assertThat(DiffPatterns.classify("", "X")).isEqualTo("BLANK_VS_VALUE");
        assertThat(DiffPatterns.classify("POLICY TERM", "POLICY")).isEqualTo("TRUNCATION");
        assertThat(DiffPatterns.classify("A", "B")).isEqualTo("VALUE");
    }

    @Test
    void outcomeMappingCanReadTheTargetExitState() {
        ViewMapping mapping = new ViewMapping("1.0", "U", null, List.of(), List.of(), List.of(), List.of(), List.of(),
                new OutcomeMapping("EXIT-STATE", "status.code"));
        Observation projected = mapping.toCanonical(Observation.targetPayload(read("{\"status\":{\"code\":42}}"), Outcome.ok()));
        Observation absent = mapping.toCanonical(Observation.targetPayload(null, Outcome.ok()));

        assertThat(projected.outcome().exitState()).isEqualTo(42L);
        assertThat(absent.fields()).isEmpty();
        assertThat(ViewMapping.parseLong("x")).isNull();
        assertThat(ViewMapping.parseLong(" 12 ")).isEqualTo(12L);
        assertThat(mapping.field("nothing")).isEmpty();
    }

    @Test
    void groupCountFallsBackToTheHighestOccurrence() {
        GroupMapping group = new GroupMapping("g", "items", null, List.of(FieldMapping.of("F")));
        ViewMapping mapping = new ViewMapping("1.0", "U", null, List.of(), List.of(), List.of(group), List.of(), List.of(), null);
        Observation raw = Observation.rawLegacy(Map.of("F(001)", "a", "F(003)", "c", "OTHER(009)", "x"), Outcome.ok());

        assertThat(mapping.toCanonical(raw).groups().get("g")).hasSize(3);
    }

    @Test
    void aRootListIsAddressedWithTheRootPath() throws IOException {
        GroupMapping rows = new GroupMapping("rows", ViewMapping.ROOT, null, List.of(new FieldMapping("CODE", "code", FieldType.CODE, false, null)));
        ViewMapping mapping = new ViewMapping("1.0", "U", null, List.of(), List.of(), List.of(rows), List.of(), List.of(), null);
        Observation projected = mapping.toCanonical(Observation.targetPayload(read("[{\"code\":\"A\"},{\"code\":\"B\"}]"), Outcome.ok()));

        assertThat(projected.groups().get("rows")).extracting(r -> r.get("CODE")).containsExactly("A", "B");
        assertThat(ViewMapping.at(read("{\"a\":1}"), "")).isNotNull();
        assertThat(new OutcomeMapping("X", null, null).exceptions()).isEmpty();
    }

    // ------------------------------------------------------------------ ordered lists: the rows aligned first

    /** An answer whose {@code items} are the given {@code code/text} rows (a row "B" is code B, text B-TEXT). */
    static Observation rows(String... codes) {
        StringBuilder items = new StringBuilder();
        for (String code : codes) {
            String[] parts = code.split("/", 2);
            items.append(items.isEmpty() ? "" : ",").append("{\"code\":\"").append(parts[0]).append("\",\"text\":\"")
                    .append(parts.length > 1 ? parts[1] : parts[0] + "-TEXT").append("\"}");
        }
        return target("{ \"responseCode\": 0, \"message\": \"\", \"items\": [" + items + "] }");
    }

    private ComparisonResult inOrder(Observation legacy, Observation tgt, NormalizationProfile profile) {
        return comparator.compare("S-ROWS", "L4", legacy, tgt, TestData.mapping(), profile, CompareSpec.defaults());
    }

    private static List<String> texts(ComparisonResult result) {
        return result.diffs().stream().map(FieldDiff::text).toList();
    }

    @Test
    void aRowTheTargetLacksIsOneDifferenceNotAShiftOfEveryLaterRow() {
        ComparisonResult result = inOrder(rows("A", "B", "C", "D", "E", "F"), rows("A", "B", "D", "E", "F"), contract);

        assertThat(texts(result)).containsExactly("rows[] ROW_COUNT legacy='6' target='5'",
                "rows[3] ROW_MISSING_IN_TARGET legacy='C|C-TEXT' target='null'");
        assertThat(result.signatures()).containsExactly("DEMO0001|rows[]|ROW_COUNT",
                "DEMO0001|rows[]|ROW_MISSING_IN_TARGET");
        assertThat(result.notes()).anyMatch(n -> n.equals("rows of rows aligned in order: 1 missing in the target, 0 extra "
                + "in the target (each one difference, not a shift of the rows after it)"));
        assertThat(result.compared()).as("2 scalars, the exit state, 5 aligned rows x 2 fields, the missing row's 2")
                .isEqualTo(15);
        assertThat(result.matched()).isEqualTo(13);
    }

    @Test
    void aRowMissingInTheMiddleAndOneExtraAtTheEndAreTwoDifferences() {
        // the shape of TC-508-006: the Java lacks one row, and its last row is one the legacy's cap left out
        ComparisonResult result = inOrder(rows("001", "002", "009", "010", "011", "A00"),
                rows("001", "002", "010", "011", "A00", "A01"), contract);

        assertThat(texts(result)).containsExactly("rows[3] ROW_MISSING_IN_TARGET legacy='009|009-TEXT' target='null'",
                "rows[6] ROW_EXTRA_IN_TARGET legacy='null' target='A01|A01-TEXT'");
        assertThat(result.status()).isEqualTo(ComparisonResult.Status.DIFF);
    }

    @Test
    void aChangedRowIsComparedFieldByFieldUnderItsLegacyPositionAsBefore() {
        ComparisonResult changed = inOrder(rows("A", "B/BLUE", "C"), rows("A", "B/NAVY", "C"), contract);
        ComparisonResult everyRow = inOrder(rows("A/1", "B/2", "C/3"), rows("A/x", "B/y", "C/z"), contract);

        assertThat(texts(changed)).containsExactly("rows[2].TEXT-0003 VALUE legacy='BLUE' target='NAVY' (VALUE)");
        assertThat(changed.signatures()).containsExactly("DEMO0001|rows[].TEXT-0003|VALUE:VALUE");
        assertThat(changed.notes()).noneMatch(n -> n.contains("aligned"));
        assertThat(everyRow.diffs()).extracting(FieldDiff::field)
                .as("no row missing: exactly the positional comparison")
                .containsExactly("rows[1].TEXT-0003", "rows[2].TEXT-0003", "rows[3].TEXT-0003");
        assertThat(everyRow.compared()).as("2 scalars, the exit state, 3 rows x 2 fields").isEqualTo(9);
        assertThat(everyRow.matched()).isEqualTo(6);
    }

    @Test
    void aMovedRowIsMissingWhereTheLegacyHasItAndExtraWhereTheTargetHasIt() {
        ComparisonResult moved = inOrder(rows("A", "B", "C"), rows("B", "C", "A"), contract);

        assertThat(texts(moved)).containsExactly("rows[1] ROW_MISSING_IN_TARGET legacy='A|A-TEXT' target='null'",
                "rows[3] ROW_EXTRA_IN_TARGET legacy='null' target='A|A-TEXT'");
        assertThat(moved.status()).as("the order still counts").isEqualTo(ComparisonResult.Status.DIFF);
        assertThat(moved.notes()).anyMatch(n -> n.endsWith("; they are the same rows in another order"));
    }

    @Test
    void rowsAlignUnderTheProfilesNormalizationAndLeaveIgnoredFieldsOut() {
        Observation legacy = rows("A/BLUE   ", "B", "C");
        Observation tgt = rows("A/BLUE", "C");

        assertThat(texts(inOrder(legacy, tgt, contract))).as("RTRIM: A is the same row")
                .containsExactly("rows[] ROW_COUNT legacy='3' target='2'",
                        "rows[2] ROW_MISSING_IN_TARGET legacy='B|B-TEXT' target='null'");
        assertThat(texts(inOrder(legacy, tgt, strict))).as("strict: A differs, B is missing")
                .containsExactly("rows[] ROW_COUNT legacy='3' target='2'",
                        "rows[1].TEXT-0003 VALUE legacy='BLUE   ' target='BLUE' (TRAILING_BLANKS)",
                        "rows[2] ROW_MISSING_IN_TARGET legacy='B|B-TEXT' target='null'");
        NormalizationProfile ignoringText = new NormalizationProfile("contract", List.of(
                new NormalizationProfile.RuleBinding(NormalizationRule.IGNORE_FIELDS, "D-9", List.of("TEXT-0003"))));
        assertThat(texts(inOrder(rows("A/1", "B/2", "C/3"), rows("A/9", "C/8"), ignoringText)))
                .as("an ignored field never keeps two rows apart")
                .containsExactly("rows[] ROW_COUNT legacy='3' target='2'",
                        "rows[2] ROW_MISSING_IN_TARGET legacy='B' target='null'");
    }

    @Test
    void aFieldOneRowLacksIsStillAFieldDifferenceOfThatRow() {
        Observation tgt = target("{ \"responseCode\": 0, \"message\": \"\", \"items\": ["
                + "{\"code\":\"A\",\"text\":\"A-TEXT\"}, {\"code\":\"B\"}, {\"code\":\"C\",\"text\":\"C-TEXT\"} ] }");

        assertThat(texts(inOrder(rows("A", "B", "C"), tgt, strict)))
                .containsExactly("rows[2].TEXT-0003 MISSING_IN_TARGET legacy='B-TEXT' target='null'");
    }

    @Test
    void aSideWithNoRowIsTheRowCountOnly() {
        assertThat(texts(inOrder(rows("A", "B"), rows(), contract)))
                .containsExactly("rows[] ROW_COUNT legacy='2' target='0'");
        assertThat(texts(inOrder(rows(), rows("A"), contract)))
                .containsExactly("rows[] ROW_COUNT legacy='0' target='1'");
    }

    @Test
    void groupsTooLargeToAlignAreComparedByPositionWithANote() {
        int n = (int) Math.sqrt(FieldComparator.ALIGN_LIMIT) + 2;      // n x n cells: beyond the limit
        String[] legacy = new String[n];
        String[] tgt = new String[n];
        for (int i = 0; i < n; i++) {
            legacy[i] = "L" + i;
            tgt[i] = "T" + i;
        }

        ComparisonResult result = inOrder(rows(legacy), rows(tgt), contract);

        assertThat(result.notes()).anyMatch(s -> s.startsWith("rows of rows compared by position (" + n + " x " + n));
        assertThat(result.diffs()).hasSize(2 * n);
        assertThat(result.diffs().get(0).text()).isEqualTo("rows[1].CODE-0003 VALUE legacy='L0' target='T0' (VALUE)");
    }

    @Test
    void theAlignmentKeepsItsInvariantsAndIsTheSameOnEveryRun() {
        java.util.Random random = new java.util.Random(20261103L);
        for (int round = 0; round < 400; round++) {
            String[] legacy = randomRows(random);
            String[] tgt = randomRows(random);
            ComparisonResult first = inOrder(rows(legacy), rows(tgt), contract);
            ComparisonResult again = inOrder(rows(legacy), rows(tgt), contract);

            assertThat(texts(again)).as("deterministic").isEqualTo(texts(first));
            assertThat(first.isMatch() || first.status() == ComparisonResult.Status.VACUOUS)
                    .as("a match exactly when the lists are equal: %s vs %s", List.of(legacy), List.of(tgt))
                    .isEqualTo(List.of(legacy).equals(List.of(tgt)));
            long missing = first.diffs().stream().filter(d -> d.kind() == FieldDiff.Kind.ROW_MISSING_IN_TARGET).count();
            long extra = first.diffs().stream().filter(d -> d.kind() == FieldDiff.Kind.ROW_EXTRA_IN_TARGET).count();
            if (legacy.length > 0 && tgt.length > 0) {
                assertThat(missing - extra).as("rows missing - rows extra = the length difference")
                        .isEqualTo(legacy.length - tgt.length);
            }
            assertThat(missing).isLessThanOrEqualTo(legacy.length);
            assertThat(extra).isLessThanOrEqualTo(tgt.length);
            long changedFields = first.diffs().stream().filter(d -> d.kind() == FieldDiff.Kind.VALUE).count();
            if (missing == 0 && extra == 0) {
                assertThat(changedFields).as("no row missing or extra: exactly the positional comparison: %s vs %s",
                        List.of(legacy), List.of(tgt)).isEqualTo(positionalValueDiffs(legacy, tgt));
            }
            assertThat(changedFields + missing + extra).as("never more than by position plus every row")
                    .isLessThanOrEqualTo(2L * Math.min(legacy.length, tgt.length) + Math.abs(legacy.length - tgt.length));
        }
    }

    private static String[] randomRows(java.util.Random random) {
        String[] codes = new String[random.nextInt(7)];
        for (int i = 0; i < codes.length; i++) {
            codes[i] = String.valueOf((char) ('A' + random.nextInt(4))) + "/" + random.nextInt(2);
        }
        return codes;
    }

    /** What the earlier, positional comparison counted: value differences of the rows at the same position. */
    private static long positionalValueDiffs(String[] legacy, String[] tgt) {
        long count = 0;
        for (int i = 0; i < Math.min(legacy.length, tgt.length); i++) {
            String[] l = legacy[i].split("/");
            String[] t = tgt[i].split("/");
            count += (l[0].equals(t[0]) ? 0 : 1) + (l[1].equals(t[1]) ? 0 : 1);
        }
        return count;
    }

    private static JsonNode read(String json) {
        try {
            return JsonSupport.mapper().readTree(json);
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }
}
