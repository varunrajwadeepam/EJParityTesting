package com.insurance.e2e.core.spi;

import com.insurance.e2e.core.compare.FieldComparePlugin;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.scenario.Scenario;
import org.junit.jupiter.api.Test;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class SpiTest {

    record NamedCapture(String id, Set<String> kinds) implements CapturePlugin {
        @Override
        public Observation capture(Request request) {
            return null;
        }
    }

    @Test
    void serviceLoaderDiscoversTheBuiltInComparator() {
        PluginRegistry registry = PluginRegistry.discover();

        assertThat(registry.all()).anyMatch(p -> p instanceof FieldComparePlugin);
        assertThat(registry.compare(ComparePlugin.VIEW_FIELDS)).isInstanceOf(FieldComparePlugin.class);
        assertThat(PluginRegistry.discover(SpiTest.class.getClassLoader()).all()).isNotEmpty();
    }

    @Test
    void laterRegistrationsWinAndMissingKindsAreBlocking() {
        NamedCapture first = new NamedCapture("first", Set.of("LEG-SP"));
        NamedCapture second = new NamedCapture("second", Set.of("LEG-SP", "LEG-CMP"));
        PluginRegistry registry = new PluginRegistry().register(first).register(second);

        assertThat(registry.capture("LEG-SP")).isSameAs(second);
        assertThat(registry.find(CapturePlugin.class, "LEG-CMP")).containsSame(second);
        assertThat(registry.find(TriggerPlugin.class, "LEG-SP")).isEmpty();
        assertThat(first.point()).isEqualTo(ExtensionPoint.CAPTURE);

        assertThatThrownBy(() -> registry.trigger("LEG-SP"))
                .isInstanceOfSatisfying(MissingPluginException.class, e -> {
                    assertThat(e.point()).isEqualTo(ExtensionPoint.TRIGGER);
                    assertThat(e.kind()).isEqualTo("LEG-SP");
                    assertThat(e.routeBack()).contains("framework owner");
                });
        assertThatThrownBy(() -> registry.environment("jdbc")).isInstanceOf(MissingPluginException.class);
    }

    @Test
    void contextLooksUpExplicitThenSystemThenEnvironment() {
        System.setProperty("e2e.test.sys", "from-system");
        try {
            ExecutionContext context = ExecutionContext.builder()
                    .property("e2e.test.explicit", "explicit")
                    .properties(Map.of("e2e.test.blank", " "))
                    .environment(Map.of("E2E_TEST_ENV", "from-env", "E2E_TEST_SYS", "env-loses"))
                    .attribute("shared", 42)
                    .clock(Clock.fixed(Instant.parse("2026-10-02T09:15:30.123Z"), ZoneOffset.UTC))
                    .build();

            assertThat(context.property("e2e.test.explicit")).isEqualTo("explicit");
            assertThat(context.property("e2e.test.sys")).isEqualTo("from-system");
            assertThat(context.property("e2e.test.env")).isEqualTo("from-env");
            assertThat(context.property("e2e.test.blank")).isNull();
            assertThat(context.property("e2e.test.none", "fallback")).isEqualTo("fallback");
            assertThat(context.attribute("shared", Integer.class)).contains(42);
            assertThat(context.attribute("shared", String.class)).isEmpty();
            context.putAttribute(String.class.getName(), "value");
            assertThat(context.attribute(String.class)).contains("value");
            assertThat(context.now()).isEqualTo("2026-10-02T09:15:30Z");
        } finally {
            System.clearProperty("e2e.test.sys");
        }
        assertThat(ExecutionContext.fromSystem().now()).endsWith("Z");
    }

    @Test
    void recordsCarryTheirParts() {
        assertThat(Availability.up().available()).isTrue();
        assertThat(Availability.down("x").reason()).isEqualTo("x");
        assertThat(new TriggerPlugin.TriggerResult(null, "p", null, null).provenance()).isEmpty();
        assertThat(new EnvironmentPlugin.FixtureState("f", "p", "s", null).tables()).isEmpty();
        EnvironmentPlugin env = new EnvironmentPlugin() {
            @Override
            public String id() {
                return "env";
            }

            @Override
            public Set<String> kinds() {
                return Set.of(JDBC);
            }

            @Override
            public FixtureState prepare(Scenario scenario, String fixture, ExecutionContext context) {
                return new FixtureState(fixture, "p", "s", List.of("T"));
            }

            @Override
            public String stateHash(List<String> tables, ExecutionContext context) {
                return "s";
            }
        };
        assertThat(env.point()).isEqualTo(ExtensionPoint.ENVIRONMENT);
        assertThat(env.availability(null).available()).isTrue();
        assertThat(new FieldComparePlugin().point()).isEqualTo(ExtensionPoint.COMPARE);
    }
}
