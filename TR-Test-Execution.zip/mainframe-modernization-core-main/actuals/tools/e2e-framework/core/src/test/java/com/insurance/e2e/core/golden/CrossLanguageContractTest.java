package com.insurance.e2e.core.golden;

import org.junit.jupiter.api.Test;

import java.net.URISyntaxException;
import java.nio.file.Path;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * The seal contract with the pipeline scripts: {@code contract/golden/UNIT1/TC-1.json} was sealed by this framework,
 * {@code contract/golden/UNIT2/TC-2.json} by the scripts' {@code e2elib.canonical} (an imported recording),
 * {@code UNIT3/TC-3.json} likewise - an error answer without a body, written with {@code "payload": null}, and
 * {@code UNIT4/TC-4.json} - a recording of a format-2 package: the legacy sources' hashes, the repeats and the
 * recording's run ids in the sealed content. All must verify here, and the scripts' tests verify them the same way -
 * a change to either canonical form breaks one side.
 */
class CrossLanguageContractTest {

    @Test
    void goldenMastersSealedByJavaAndByThePipelineScriptsVerifyAlike() throws URISyntaxException {
        GoldenMasterStore store = new GoldenMasterStore(Path.of(getClass().getResource("/contract/golden").toURI()));

        assertThat(store.verifyAll()).isEmpty();
        GoldenMaster javaSealed = store.find("UNIT1", "TC-1").orElseThrow();
        GoldenMaster scriptSealed = store.find("UNIT2", "TC-2").orElseThrow();
        assertThat(javaSealed.integrityHolds()).isTrue();
        assertThat(scriptSealed.integrityHolds()).isTrue();
        assertThat(scriptSealed.origin()).containsEntry("kind", "package").containsEntry("caseId", "TC-2");
        assertThat(scriptSealed.lens()).isEqualTo("service");
        assertThat(scriptSealed.observation().payload().get("missing").isNull()).isTrue();
        GoldenMaster noBody = store.find("UNIT3", "TC-3").orElseThrow();
        assertThat(noBody.integrityHolds()).as("\"payload\": null seals as no payload").isTrue();
        assertThat(noBody.observation().payload().isNull()).as("read as JSON null").isTrue();
        assertThat(noBody.observation().outcome().exitState()).isEqualTo(404L);
        GoldenMaster recorded = store.find("UNIT4", "TC-4").orElseThrow();
        assertThat(recorded.integrityHolds()).isTrue();
        assertThat(recorded.provenance().sources()).containsOnlyKeys("UNIT4.CBL", "UNIT4A.CBL");
        assertThat(recorded.provenance().repeatRuns()).isEqualTo(2);
        assertThat(recorded.evidence()).containsKeys("legacy", "recording");
    }
}
