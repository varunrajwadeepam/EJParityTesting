package com.insurance.e2e.core.run;

import com.fasterxml.jackson.databind.JsonNode;
import com.insurance.e2e.core.compare.ComparisonResult;
import com.insurance.e2e.core.compare.FieldComparator;
import com.insurance.e2e.core.compare.FieldDiff;
import com.insurance.e2e.core.compare.FieldMapping;
import com.insurance.e2e.core.compare.FieldType;
import com.insurance.e2e.core.compare.GroupMapping;
import com.insurance.e2e.core.compare.NormalizationProfile;
import com.insurance.e2e.core.compare.NormalizationRule;
import com.insurance.e2e.core.compare.ViewMapping;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.observation.Outcome;
import com.insurance.e2e.core.scenario.CompareSpec;
import com.insurance.e2e.core.scenario.Scenario;
import com.insurance.e2e.core.scenario.TableCheck;
import com.insurance.e2e.core.spi.EnvironmentPlugin;
import com.insurance.e2e.core.spi.ExecutionContext;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

/** Format 3 of the golden-master packages: what a call left in the tables, compared like the answer itself. */
class TableCaptureTest {

    static final TableCheck CHECK = new TableCheck("WRIT", "SELECT NBR, AMT, DT, NOTE FROM WRIT ORDER BY NBR",
            List.of("NBR", "AMT", "DT", "NOTE"), null);

    static Map<String, Object> row(String nbr, Object amount, String date, String note) {
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("NBR", nbr);
        row.put("AMT", amount);
        row.put("DT", date);
        row.put("NOTE", note);
        return row;
    }

    static EnvironmentPlugin environment(List<Map<String, Object>> rows) {
        return new EnvironmentPlugin() {
            @Override
            public String id() {
                return "fake";
            }

            @Override
            public Set<String> kinds() {
                return Set.of(JDBC);
            }

            @Override
            public FixtureState prepare(Scenario scenario, String fixture, ExecutionContext context) {
                return null;
            }

            @Override
            public String stateHash(List<String> tables, ExecutionContext context) {
                return "h";
            }

            @Override
            public List<Map<String, Object>> rows(String query, ExecutionContext context) {
                return rows;
            }
        };
    }

    static Scenario scenario(Boolean answerEmpty) {
        return new Scenario("TC-1", null, null, null, null, null, null, null, null, null, null, null, null, Map.of(),
                null, null, null, null, null, null, null, null, null, null, null, List.of(CHECK), answerEmpty);
    }

    /** One mapping per answer shape (as the import writes them): the given scalar fields, the table group. */
    static ViewMapping mapping(String... fields) {
        return new ViewMapping("1.0", "U", "format 3", null,
                java.util.Arrays.stream(fields).map(f -> new FieldMapping(f, f, FieldType.STRING, false, null)).toList(),
                List.of(new GroupMapping("table:WRIT", "$tables.WRIT", null,
                        List.of(new FieldMapping("NBR", "NBR", FieldType.STRING, false, null),
                                new FieldMapping("AMT", "AMT", FieldType.NUMBER, false, null),
                                new FieldMapping("DT", "DT", FieldType.DATE, false, null),
                                new FieldMapping("NOTE", "NOTE", FieldType.STRING, false, null)))),
                null, null, null);
    }

    static NormalizationProfile contract() {
        return new NormalizationProfile("contract", List.of(
                new NormalizationProfile.RuleBinding(NormalizationRule.RTRIM, "PKG-CMP-U", null),
                new NormalizationProfile.RuleBinding(NormalizationRule.NULL_AS_BLANK, "PKG-CMP-U", null),
                new NormalizationProfile.RuleBinding(NormalizationRule.NUMERIC_SCALE_INSENSITIVE, "PKG-CMP-U", null)));
    }

    static Observation golden(String json) throws Exception {
        return Observation.targetPayload(JsonSupport.mapper().readTree(json), new Outcome(Outcome.Kind.OK, 200L, null, null));
    }

    static ExecutionContext context() {
        return ExecutionContext.builder().environment(Map.of()).build();
    }

    @Test
    void anEmptyAnswerAndTheRowsAreAddedToTheTargetsAnswer() {
        Observation answered = Observation.targetPayload(null, new Outcome(Outcome.Kind.OK, 200L, null, null));
        Observation augmented = TableCapture.augment(answered, scenario(true),
                environment(List.of(row("A1        ", new BigDecimal("1000.00"), "2024-08-16", null))), context());

        JsonNode payload = augmented.payload();
        assertThat(payload.get("$empty").asBoolean()).isTrue();
        assertThat(payload.at("/$tables/WRIT/0/AMT").decimalValue()).isEqualByComparingTo("1000.00");
        assertThat(payload.at("/$tables/WRIT/0/NOTE").isNull()).isTrue();
        assertThat(augmented.outcome().exitState()).isEqualTo(200L);
    }

    @Test
    void aBodyIsKeptAndTheEmptinessIsItsOwnField() throws Exception {
        Observation answered = Observation.targetPayload(JsonSupport.mapper().readTree("{\"code\":\"X\"}"),
                new Outcome(Outcome.Kind.BUSINESS_EXCEPTION, 404L, null, null));
        JsonNode payload = TableCapture.augment(answered, scenario(false), environment(List.of()), context()).payload();

        assertThat(payload.get("code").asText()).isEqualTo("X");
        assertThat(payload.get("$empty").asBoolean()).isFalse();
        assertThat(payload.at("/$tables/WRIT").isArray()).isTrue();
        assertThat(payload.at("/$tables/WRIT").size()).isZero();
    }

    @Test
    void rowsMatchByValueTrimmedAndNullAsBlank() throws Exception {
        Observation target = TableCapture.augment(Observation.targetPayload(null, new Outcome(Outcome.Kind.OK, 200L,
                        null, null)), scenario(true),
                environment(List.of(row("A1        ", new BigDecimal("1000.00"), "2024-08-16", null))), context());
        Observation legacy = golden("{\"$empty\":true,\"$tables\":{\"WRIT\":[{\"NBR\":\"A1\",\"AMT\":1000.0,"
                + "\"DT\":\"2024-08-16\",\"NOTE\":null}]}}");

        ComparisonResult result = new FieldComparator().compare("TC-1", "L4", legacy, target, mapping("$empty"), contract(),
                CompareSpec.defaults());

        assertThat(result.status()).isEqualTo(ComparisonResult.Status.MATCH);
    }

    @Test
    void aDifferentValueAMissingRowAndANonEmptyAnswerAreDifferences() throws Exception {
        Observation target = TableCapture.augment(Observation.targetPayload(JsonSupport.mapper().readTree(
                        "{\"code\":\"X\"}"), new Outcome(Outcome.Kind.OK, 200L, null, null)), scenario(true),
                environment(List.of(row("A1", new BigDecimal("999.99"), "2024-08-16", null))), context());
        Observation legacy = golden("{\"$empty\":true,\"$tables\":{\"WRIT\":[{\"NBR\":\"A1\",\"AMT\":1000.0,"
                + "\"DT\":\"2024-08-16\",\"NOTE\":null},{\"NBR\":\"A2\",\"AMT\":1,\"DT\":\"2024-08-16\",\"NOTE\":\"N\"}]}}");

        ComparisonResult result = new FieldComparator().compare("TC-1", "L4", legacy, target, mapping("$empty", "code"), contract(),
                CompareSpec.defaults());

        assertThat(result.status()).isEqualTo(ComparisonResult.Status.DIFF);
        assertThat(result.diffs()).extracting(FieldDiff::field)
                .contains("$empty", "table:WRIT[]", "table:WRIT[1].AMT");
        assertThat(result.signatures()).contains("U|table:WRIT[]|ROW_COUNT");
        assertThat(result.signatures()).anyMatch(s -> s.startsWith("U|table:WRIT[].AMT|VALUE"));
    }

    @Test
    void aTableDeclaredUnorderedIsComparedAsAMultiset() throws Exception {
        ViewMapping base = mapping();
        GroupMapping table = base.groups().get(0);
        ViewMapping unordered = new ViewMapping("1.0", "U", "set", null, base.fields(),
                List.of(new GroupMapping(table.name(), table.target(), null, table.fields(), "set")), null, null, null);
        Observation target = golden("{\"$tables\":{\"WRIT\":[{\"NBR\":\"B\",\"AMT\":2,\"DT\":\"d\",\"NOTE\":null},"
                + "{\"NBR\":\"A\",\"AMT\":1,\"DT\":\"d\",\"NOTE\":null}]}}");
        Observation legacy = golden("{\"$tables\":{\"WRIT\":[{\"NBR\":\"A\",\"AMT\":1,\"DT\":\"d\",\"NOTE\":null},"
                + "{\"NBR\":\"B\",\"AMT\":2,\"DT\":\"d\",\"NOTE\":null}]}}");

        ComparisonResult asSet = new FieldComparator().compare("TC-1", "L4", legacy, target, unordered, contract(),
                CompareSpec.defaults());
        assertThat(asSet.status()).isEqualTo(ComparisonResult.Status.MATCH);
        assertThat(asSet.notes()).anyMatch(n -> n.contains("order of table:WRIT differs"));
        assertThat(new FieldComparator().compare("TC-1", "L4", legacy, target, mapping(), contract(),
                CompareSpec.defaults()).status()).isEqualTo(ComparisonResult.Status.DIFF);
    }

    @Test
    void onAnErrorAnswerOnlyTheStatusAndTheRowsAreComparedUnderOutcomeOnlyOnError() throws Exception {
        NormalizationProfile outcomeOnly = new NormalizationProfile("contract", List.of(
                new NormalizationProfile.RuleBinding(NormalizationRule.RTRIM, "PKG-CMP-U", null),
                new NormalizationProfile.RuleBinding(NormalizationRule.OUTCOME_ONLY_ON_ERROR, "PKG-CMP-U", null)));
        Outcome rejected = new Outcome(Outcome.Kind.BUSINESS_EXCEPTION, 400L, null, null);
        Observation legacy = Observation.targetPayload(JsonSupport.mapper().readTree("{\"code\":\"A\",\"$tables\":{\"WRIT\":"
                + "[{\"NBR\":\"A1\",\"AMT\":1,\"DT\":\"d\",\"NOTE\":null}]}}"), rejected);
        Observation otherBody = Observation.targetPayload(JsonSupport.mapper().readTree("{\"code\":\"B\",\"$tables\":{\"WRIT\":"
                + "[{\"NBR\":\"A1\",\"AMT\":1,\"DT\":\"d\",\"NOTE\":null}]}}"), rejected);
        Observation otherRows = Observation.targetPayload(JsonSupport.mapper().readTree("{\"code\":\"A\",\"$tables\":{\"WRIT\":"
                + "[]}}"), rejected);

        ComparisonResult sameRows = new FieldComparator().compare("TC-1", "L4", legacy, otherBody, mapping("code"),
                outcomeOnly, CompareSpec.defaults());
        ComparisonResult lostRows = new FieldComparator().compare("TC-1", "L4", legacy, otherRows, mapping("code"),
                outcomeOnly, CompareSpec.defaults());

        assertThat(sameRows.status()).isEqualTo(ComparisonResult.Status.MATCH);
        assertThat(sameRows.notes()).anyMatch(n -> n.contains("rows the call left are compared on an error answer"));
        assertThat(lostRows.diffs()).extracting(FieldDiff::field).containsExactly("table:WRIT[]");
    }
}
