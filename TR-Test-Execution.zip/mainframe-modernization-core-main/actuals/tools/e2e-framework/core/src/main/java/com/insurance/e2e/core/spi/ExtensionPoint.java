package com.insurance.e2e.core.spi;

/**
 * The four extension points of the framework core. A new technology arrives as a plugin behind one or more of
 * them - never as a fork of the framework.
 */
public enum ExtensionPoint {
    /** How a scenario starts the behaviour (legacy driver run, in-process call, REST, message, batch, UI, ...). */
    TRIGGER,
    /** What is observed (reported view fields, DB state, events, files, UI state, ...). */
    CAPTURE,
    /** How observations of one type are compared (fields, table diffs, event streams, files, ...). */
    COMPARE,
    /** Environment and fixtures (database rows, brokers, browsers, ...). */
    ENVIRONMENT
}
