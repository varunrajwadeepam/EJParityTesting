package com.insurance.e2e.core.run;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.databind.JsonNode;
import com.insurance.e2e.core.compare.ComparisonResult;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.observation.Outcome;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The outcome of one scenario level in one mode.
 *
 * @param status         {@link Status#BLOCKED} is never silent: it fails the test with its route-back, unless the
 *                       block was declared in the register (then it is reported and the test is aborted);
 *                       {@link Status#SKIPPED} is only for an unavailable service; {@link Status#NOT_APPLICABLE} is a
 *                       scenario the lens cannot express - reported, never executed or counted
 * @param verdictProfile the profile whose comparison decided the status; both comparisons are always reported
 * @param lens           the level's lens ({@code service}, {@code component})
 * @param title          the scenario's title, for readers of the report
 * @param hypotheses     anticipated differences from reading the code (the scenario's {@code hypotheses}): shown next
 *                       to a failure, never used to decide it
 * @param target         what the target answered, for a compared scenario that did not pass ({@code null} otherwise)
 */
public record ScenarioReport(String scenarioId, String level, String unit, String mode, Status status,
                             String message, ComparisonResult strict, ComparisonResult contract,
                             String verdictProfile, List<String> notes, String lens, String title,
                             List<String> hypotheses, TargetAnswer target) {

    public enum Status { PASSED, FAILED, BLOCKED, SKIPPED, RECORDED, NOT_APPLICABLE }

    @JsonCreator
    public ScenarioReport {
        notes = notes == null ? List.of() : List.copyOf(notes);
        hypotheses = hypotheses == null ? List.of() : List.copyOf(hypotheses);
    }

    /** A report without the target's answer. */
    public ScenarioReport(String scenarioId, String level, String unit, String mode, Status status, String message,
                          ComparisonResult strict, ComparisonResult contract, String verdictProfile,
                          List<String> notes, String lens, String title, List<String> hypotheses) {
        this(scenarioId, level, unit, mode, status, message, strict, contract, verdictProfile, notes, lens, title,
                hypotheses, null);
    }

    /** A report without lens, title, hypotheses or the target's answer. */
    public ScenarioReport(String scenarioId, String level, String unit, String mode, Status status, String message,
                          ComparisonResult strict, ComparisonResult contract, String verdictProfile,
                          List<String> notes) {
        this(scenarioId, level, unit, mode, status, message, strict, contract, verdictProfile, notes, null, null, null);
    }

    static ScenarioReport of(Status status, String scenarioId, String level, String unit, E2eMode mode,
                             String message, List<String> notes) {
        return new ScenarioReport(scenarioId, level, unit, mode.name(), status, message, null, null, null, notes);
    }

    /** The same report with the scenario's descriptive fields attached. */
    ScenarioReport describedBy(String lensName, String scenarioTitle, List<String> scenarioHypotheses) {
        return new ScenarioReport(scenarioId, level, unit, mode, status, message, strict, contract, verdictProfile,
                notes, lensName, scenarioTitle, scenarioHypotheses, target);
    }

    /** The same report with the target's answer kept. */
    ScenarioReport answeredBy(Observation observation) {
        return new ScenarioReport(scenarioId, level, unit, mode, status, message, strict, contract, verdictProfile,
                notes, lens, title, hypotheses, TargetAnswer.of(observation));
    }

    /**
     * What the target answered, kept for a compared scenario that did not pass so that triage sees it - nothing is
     * decided on it.
     *
     * @param outcome   the outcome as captured (kind, exit state, exception type, message)
     * @param meta      the capture's metadata, e.g. {@code http.status}, {@code http.request}, {@code http.contentType}
     * @param payload   the answer as compact JSON - the payload, or the fields and groups of a field observation - whole,
     *                  only an answer beyond {@link #LIMIT} characters cut (a failure message shows {@link #excerpt})
     * @param truncated whether the payload was cut
     */
    public record TargetAnswer(Outcome outcome, Map<String, String> meta, String payload, boolean truncated) {

        /** The characters of an answer kept: the whole answer in practice (an API answer is far smaller). */
        public static final int LIMIT = 1_000_000;

        /** The start of the answer, for a one-screen message ({@code ...} when there is more). */
        public String excerpt(int characters) {
            if (payload == null) {
                return null;
            }
            return payload.length() > characters ? payload.substring(0, characters) + "..."
                    : payload + (truncated ? "..." : "");
        }

        static TargetAnswer of(Observation observation) {
            String text = answerText(observation);
            boolean cut = text != null && text.length() > LIMIT;
            return new TargetAnswer(observation.outcome(), observation.meta(), cut ? text.substring(0, LIMIT) : text,
                    cut);
        }

        private static String answerText(Observation observation) {
            if (observation.payload() != null) {
                return observation.payload().toString();
            }
            if (observation.fields().isEmpty() && observation.groups().isEmpty()) {
                return null;
            }
            Map<String, Object> view = new LinkedHashMap<>();
            view.put("fields", observation.fields());
            view.put("groups", observation.groups());
            JsonNode tree = JsonSupport.mapper().valueToTree(view);
            return tree.toString();
        }
    }
}
