package com.insurance.e2e.core.golden;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.observation.Observation;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The recorded legacy behaviour for one scenario x legacy unit: the complete report, its provenance and its
 * lifecycle.
 *
 * <p>A golden master is <strong>never edited</strong>. Its content (request, observation, evidence, provenance, lens,
 * origin) is sealed by {@code contentHash}; only the lifecycle state and history change, and a content change happens
 * only by re-recording into a new golden master that names the old one in {@code supersedes}.
 *
 * @param evidence executed source lines per member, SQL footprint, the raw legacy report of an imported recording,
 *                 ... - opaque to the core, part of the content
 * @param lens     the lens the recording serves ({@code service}, {@code component}); absent in 1.0 golden masters
 * @param origin   where a recording made outside this run came from (for an imported package: {@code kind=package},
 *                 the package file and hash, the case id, the producer's run id); absent when recorded here
 */
public record GoldenMaster(String schemaVersion, String scenarioId, String unit, String level,
                           Map<String, String> request, Observation observation, Map<String, Object> evidence,
                           Provenance provenance, LifecycleState state, List<LifecycleTransition> history,
                           String contentHash, String supersedes, String lens, Map<String, String> origin) {

    public static final String CURRENT_SCHEMA_VERSION = "1.1";

    @JsonCreator
    public GoldenMaster {
        request = JsonSupport.orderedCopy(request);
        evidence = JsonSupport.orderedCopy(evidence);
        history = history == null ? List.of() : List.copyOf(history);
        origin = origin == null || origin.isEmpty() ? null : JsonSupport.orderedCopy(origin);
    }

    /** A golden master in the 1.0 shape (no lens, no origin). */
    public GoldenMaster(String schemaVersion, String scenarioId, String unit, String level,
                        Map<String, String> request, Observation observation, Map<String, Object> evidence,
                        Provenance provenance, LifecycleState state, List<LifecycleTransition> history,
                        String contentHash, String supersedes) {
        this(schemaVersion, scenarioId, unit, level, request, observation, evidence, provenance, state, history,
                contentHash, supersedes, null, null);
    }

    /** A freshly recorded golden master, sealed with its content hash. */
    public static GoldenMaster recorded(String scenarioId, String unit, String level, Map<String, String> request,
                                        Observation observation, Map<String, Object> evidence, Provenance provenance,
                                        String by, String at, String supersedes) {
        return recorded(scenarioId, unit, level, null, request, observation, evidence, provenance, by, at, supersedes);
    }

    /** A freshly recorded golden master for a lens, sealed with its content hash. */
    public static GoldenMaster recorded(String scenarioId, String unit, String level, String lens,
                                        Map<String, String> request, Observation observation,
                                        Map<String, Object> evidence, Provenance provenance, String by, String at,
                                        String supersedes) {
        LifecycleTransition first = new LifecycleTransition(null, LifecycleState.RECORDED, at, by,
                "recorded " + (provenance.repeatRuns() == null ? 1 : provenance.repeatRuns()) + " identical run(s)", null);
        GoldenMaster unsealed = new GoldenMaster(CURRENT_SCHEMA_VERSION, scenarioId, unit, level, request, observation,
                evidence, provenance, LifecycleState.RECORDED, List.of(first), null, supersedes, lens, null);
        return unsealed.sealed();
    }

    /**
     * The hash over the content fields only (not state, history or the hash itself). {@code lens} and {@code origin}
     * enter only when present, so a 1.0 golden master keeps its hash. A payload that is JSON {@code null} (read from
     * {@code "payload": null}) seals as no payload, as the pipeline scripts seal it.
     */
    public String computeContentHash() {
        Map<String, Object> content = new LinkedHashMap<>();
        content.put("schemaVersion", schemaVersion);
        content.put("scenarioId", scenarioId);
        content.put("unit", unit);
        content.put("level", level);
        content.put("request", request);
        content.put("observation", observation != null && observation.payload() != null && observation.payload().isNull()
                ? new Observation(observation.form(), observation.fields(), observation.groups(), observation.outcome(),
                        null, observation.meta())
                : observation);
        content.put("evidence", evidence);
        content.put("provenance", provenance);
        content.put("supersedes", supersedes);
        if (lens != null) {
            content.put("lens", lens);
        }
        if (origin != null) {
            content.put("origin", origin);
        }
        return JsonSupport.canonicalHash(content);
    }

    @JsonIgnore
    public boolean integrityHolds() {
        return contentHash != null && contentHash.equals(computeContentHash());
    }

    GoldenMaster sealed() {
        return new GoldenMaster(schemaVersion, scenarioId, unit, level, request, observation, evidence, provenance,
                state, history, computeContentHash(), supersedes, lens, origin);
    }

    GoldenMaster withLifecycle(LifecycleTransition transition) {
        List<LifecycleTransition> next = new ArrayList<>(history);
        next.add(transition);
        return new GoldenMaster(schemaVersion, scenarioId, unit, level, request, observation, evidence, provenance,
                transition.to(), next, contentHash, supersedes, lens, origin);
    }
}
