package com.insurance.e2e.core.run;

import com.insurance.e2e.core.golden.Provenance;
import com.insurance.e2e.core.scenario.LevelBinding;
import com.insurance.e2e.core.scenario.Scenario;
import com.insurance.e2e.core.spi.ExecutionContext;

import java.util.Map;

/**
 * The current provenance of the legacy side, for recording golden masters and for computing staleness.
 *
 * <p>The default reads the engine facts from properties ({@code e2e.provenance.*}, normally fed from the
 * application's engine manifest) and the scenario's own clock and DB mode; source and driver hashes come from the
 * trigger, which built the bundle.
 */
@FunctionalInterface
public interface ProvenanceSource {

    Provenance current(Scenario scenario, LevelBinding level, ExecutionContext context);

    static ProvenanceSource fromContext() {
        return (scenario, level, context) -> new Provenance(
                context.property("e2e.provenance.platform", "gnucobol-emulated"),
                context.property("e2e.provenance.engine"),
                context.property("e2e.provenance.runnerImage"),
                context.property("e2e.provenance.gixsqlPatch"),
                context.property("e2e.provenance.shimTree"),
                Map.of(),
                null,
                null,
                scenario.clock(),
                Map.of(),
                scenario.dbMode() == null ? context.property("e2e.db.mode", "logic") : scenario.dbMode(),
                null,
                null);
    }
}
