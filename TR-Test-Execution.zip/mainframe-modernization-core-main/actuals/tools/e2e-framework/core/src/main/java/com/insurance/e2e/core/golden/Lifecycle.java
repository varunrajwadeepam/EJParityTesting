package com.insurance.e2e.core.golden;

import com.insurance.e2e.core.E2eException;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.insurance.e2e.core.golden.LifecycleState.ACCEPTED;
import static com.insurance.e2e.core.golden.LifecycleState.DISPUTED;
import static com.insurance.e2e.core.golden.LifecycleState.RECORDED;
import static com.insurance.e2e.core.golden.LifecycleState.STALE;

/** The golden-master lifecycle rules (see {@link LifecycleState}). */
public final class Lifecycle {

    private static final Map<LifecycleState, Set<LifecycleState>> ALLOWED = new EnumMap<>(LifecycleState.class);

    static {
        ALLOWED.put(RECORDED, EnumSet.of(ACCEPTED, DISPUTED, STALE));
        ALLOWED.put(ACCEPTED, EnumSet.of(DISPUTED, STALE));
        ALLOWED.put(DISPUTED, EnumSet.of(STALE));
        ALLOWED.put(STALE, EnumSet.noneOf(LifecycleState.class));
    }

    private Lifecycle() {
    }

    public static boolean allowed(LifecycleState from, LifecycleState to) {
        return ALLOWED.get(from).contains(to);
    }

    /**
     * Applies one lifecycle transition. Acceptance is the record gate's decision, so it must name who accepted.
     *
     * @throws E2eException when the transition is not allowed or an acceptance is unsigned
     */
    public static GoldenMaster transition(GoldenMaster master, LifecycleState to, String by, String reason,
                                          String decision, String at) {
        if (!allowed(master.state(), to)) {
            throw new E2eException("Golden master " + master.unit() + "/" + master.scenarioId()
                    + ": transition " + master.state() + " -> " + to + " is not allowed");
        }
        if (to == ACCEPTED && (by == null || by.isBlank())) {
            throw new E2eException("Accepting golden master " + master.unit() + "/" + master.scenarioId()
                    + " needs the name of the person who signed the record gate");
        }
        return master.withLifecycle(new LifecycleTransition(master.state(), to, at, by, reason, decision));
    }

    /**
     * The state that counts now: {@link LifecycleState#STALE} whenever an identity field of the provenance changed,
     * whatever the stored state says.
     */
    public static LifecycleState effectiveState(GoldenMaster master, Provenance current) {
        if (current != null && !master.provenance().changedFields(current).isEmpty()) {
            return STALE;
        }
        return master.state();
    }

    /** Problems in the recorded history: wrong start, broken chain, illegal steps, or a state that disagrees. */
    public static List<String> historyProblems(GoldenMaster master) {
        List<String> problems = new ArrayList<>();
        List<LifecycleTransition> history = master.history();
        if (history.isEmpty()) {
            problems.add("history is empty");
            return problems;
        }
        LifecycleTransition first = history.get(0);
        if (first.from() != null || first.to() != RECORDED) {
            problems.add("history must start with the recording (null -> RECORDED)");
        }
        for (int i = 1; i < history.size(); i++) {
            LifecycleTransition previous = history.get(i - 1);
            LifecycleTransition current = history.get(i);
            if (current.from() != previous.to()) {
                problems.add("history step " + i + " starts from " + current.from() + " but the previous state is "
                        + previous.to());
            } else if (!allowed(current.from(), current.to())) {
                problems.add("history step " + i + ": " + current.from() + " -> " + current.to() + " is not allowed");
            }
            if (current.to() == ACCEPTED && (current.by() == null || current.by().isBlank())) {
                problems.add("history step " + i + ": acceptance is not signed");
            }
        }
        if (history.get(history.size() - 1).to() != master.state()) {
            problems.add("state " + master.state() + " disagrees with the last history entry "
                    + history.get(history.size() - 1).to());
        }
        return problems;
    }
}
