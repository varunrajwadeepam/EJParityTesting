package com.insurance.e2e.core.scenario;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * One comparison level of a scenario: the legacy unit that is the oracle and, once it exists, the target unit.
 *
 * <p>Levels and lenses follow the strategy's pyramid: emulated functional parity is {@code L4}, observed through one
 * of three lenses - {@code component} (a target component against the legacy unit it replaces), {@code service} (the
 * composed target service, e.g. its API, against the legacy service point) or {@code static}. {@code L5} (the legacy
 * executed on a real mainframe) is only ever set explicitly.
 *
 * @param level   explicit level label; {@value #EMULATED} when absent
 * @param legacy  the legacy binding (required: no comparison without an oracle)
 * @param target  the target binding; absent for legacy-only recording
 * @param mapping id of the view mapping; defaults to the legacy unit name
 * @param lens    explicit lens; derived from the binding kinds when absent (service point kinds give
 *                {@value #SERVICE}, everything else {@value #COMPONENT})
 */
public record LevelBinding(String level, BindingRef legacy, BindingRef target, String mapping, String lens) {

    public static final String EMULATED = "L4";
    public static final String SERVICE = "service";
    public static final String COMPONENT = "component";

    @JsonCreator
    public LevelBinding {
        if (legacy == null) {
            throw new IllegalArgumentException("A level needs a legacy binding");
        }
    }

    /** A level without an explicit lens. */
    public LevelBinding(String level, BindingRef legacy, BindingRef target, String mapping) {
        this(level, legacy, target, mapping, null);
    }

    @JsonIgnore
    public String effectiveLevel() {
        return level != null && !level.isBlank() ? level : EMULATED;
    }

    @JsonIgnore
    public String effectiveLens() {
        if (lens != null && !lens.isBlank()) {
            return lens;
        }
        boolean servicePoint = legacy.isServicePoint() || (target != null && target.isServicePoint());
        return servicePoint ? SERVICE : COMPONENT;
    }

    /** The legacy unit (engine name) whose golden masters back this level. */
    @JsonIgnore
    public String legacyUnit() {
        return legacy.ref();
    }

    @JsonIgnore
    public String effectiveMapping() {
        return mapping == null || mapping.isBlank() ? legacyUnit() : mapping;
    }

    @Override
    public String toString() {
        return effectiveLevel() + "/" + effectiveLens() + " " + legacy + (target == null ? "" : " <-> " + target);
    }
}
