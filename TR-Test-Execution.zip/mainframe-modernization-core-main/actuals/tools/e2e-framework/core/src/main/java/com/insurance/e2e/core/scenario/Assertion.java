package com.insurance.e2e.core.scenario;

import com.insurance.e2e.core.observation.Observation;

import java.util.Objects;

/**
 * A business assertion or package expectation used as a cross-check against a recorded legacy report. It is never
 * the oracle: a disagreement goes to the discrepancy log, not into a verdict.
 *
 * @param field  legacy field name as reported (occurrence form {@code NAME(001)} allowed)
 * @param eq     the expected value, byte for byte
 * @param source where the expectation came from ({@code pt-case}, {@code rule}, {@code package}, ...)
 */
public record Assertion(String field, String eq, String source) {

    /** {@code true} when the observation reports {@code field} with exactly the expected value. */
    public boolean holdsFor(Observation observation) {
        return observation.fields().containsKey(field) && Objects.equals(observation.fields().get(field), eq);
    }
}
