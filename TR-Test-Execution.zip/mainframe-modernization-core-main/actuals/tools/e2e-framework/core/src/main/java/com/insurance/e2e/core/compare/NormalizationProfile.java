package com.insurance.e2e.core.compare;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * A normalization profile. {@code strict} applies nothing: values are compared as reported, so every
 * representational difference shows. {@code contract} applies only rules backed by a decision (D).
 */
public record NormalizationProfile(String name, List<RuleBinding> rules) {

    /** A rule switched on by a decision; {@code fields} is used by {@link NormalizationRule#IGNORE_FIELDS}. */
    public record RuleBinding(NormalizationRule rule, String decision, List<String> fields) {
        public RuleBinding {
            fields = fields == null ? List.of() : List.copyOf(fields);
        }
    }

    public NormalizationProfile {
        rules = rules == null ? List.of() : List.copyOf(rules);
    }

    public static NormalizationProfile strict() {
        return new NormalizationProfile("strict", List.of());
    }

    /** A contract profile with no signed rules yet: behaves like strict until decisions are recorded. */
    public static NormalizationProfile unsignedContract() {
        return new NormalizationProfile("contract", List.of());
    }

    public boolean has(NormalizationRule rule) {
        return rules.stream().anyMatch(r -> r.rule() == rule);
    }

    /**
     * The fields this profile does not compare: a field name (anywhere: a scalar, or a field of every row group) or a
     * qualified {@code group[].field} (that group's field only).
     */
    public Set<String> ignoredFields() {
        Set<String> ignored = new LinkedHashSet<>();
        rules.stream().filter(r -> r.rule() == NormalizationRule.IGNORE_FIELDS).forEach(r -> ignored.addAll(r.fields()));
        return ignored;
    }

    /** Whether {@code field} - a scalar ({@code group} null) or a field of the row group {@code group} - is ignored. */
    public boolean ignores(String group, String field) {
        Set<String> ignored = ignoredFields();
        return ignored.contains(field) || (group != null && ignored.contains(group + "[]." + field));
    }

    /**
     * This profile with the {@code paths} a scenario does not compare added as one {@link NormalizationRule#IGNORE_FIELDS}
     * rule backed by {@code decision}; the profile itself when there are none.
     */
    public NormalizationProfile ignoring(List<String> paths, String decision) {
        if (paths == null || paths.isEmpty()) {
            return this;
        }
        List<RuleBinding> more = new ArrayList<>(rules);
        more.add(new RuleBinding(NormalizationRule.IGNORE_FIELDS, decision, paths));
        return new NormalizationProfile(name, more);
    }

    /** Decision IDs behind this profile's rules, for the report. */
    public Set<String> decisions() {
        Set<String> ids = new LinkedHashSet<>();
        rules.forEach(r -> {
            if (r.decision() != null) {
                ids.add(r.decision());
            }
        });
        return ids;
    }

    /** The comparison form of {@code value} under this profile for a field of the given mapping. */
    public String normalize(String value, FieldMapping mapping) {
        String v = value;
        if (v == null) {
            return has(NormalizationRule.NULL_AS_BLANK) ? "" : null;
        }
        if (mapping.type() == FieldType.NUMBER) {
            return normalizeNumber(v);
        }
        if (mapping.isEcho() && has(NormalizationRule.TRIM_ECHO)) {
            v = v.strip();
        }
        if (has(NormalizationRule.RTRIM)) {
            v = v.stripTrailing();
        }
        if (has(NormalizationRule.NULL_AS_BLANK) && v.isBlank()) {
            v = "";
        }
        return v;
    }

    private String normalizeNumber(String value) {
        String trimmed = value.strip();
        if (trimmed.isEmpty()) {
            return has(NormalizationRule.NULL_AS_BLANK) ? "" : trimmed;
        }
        try {
            BigDecimal number = new BigDecimal(trimmed.startsWith("+") ? trimmed.substring(1) : trimmed);
            if (has(NormalizationRule.NUMERIC_SCALE_INSENSITIVE)) {
                number = number.stripTrailingZeros();
                if (number.signum() == 0) {
                    number = BigDecimal.ZERO;
                }
            }
            return number.toPlainString();
        } catch (NumberFormatException e) {
            return value;
        }
    }
}
