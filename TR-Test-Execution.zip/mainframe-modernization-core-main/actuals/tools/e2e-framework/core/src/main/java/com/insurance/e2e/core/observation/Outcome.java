package com.insurance.e2e.core.observation;

/**
 * The outcome dimension of an observation: did the unit complete, raise a business outcome, or fail?
 *
 * <p>Exit states are compared on their <strong>numeric</strong> value, never by name: generated exit-state names
 * differ per program for the same value.
 *
 * @param kind          what happened
 * @param exitState     numeric exit state, when the side reports one
 * @param exceptionType target side: the exception class; legacy side: unused
 * @param message       the reported message, if any
 */
public record Outcome(Kind kind, Long exitState, String exceptionType, String message) {

    public enum Kind {
        /** Completed normally (a business "not found" with an exit state is still OK at this level). */
        OK,
        /** A business outcome signalled as an exception on the target side. */
        BUSINESS_EXCEPTION,
        /** A technical failure: unexpected exception, driver error, abend. */
        TECHNICAL_FAILURE,
        /** The unit was not executed (e.g. the run was refused before execution). */
        NOT_RUN
    }

    public Outcome {
        kind = kind == null ? Kind.OK : kind;
    }

    public static Outcome ok() {
        return new Outcome(Kind.OK, null, null, null);
    }

    public static Outcome ok(Long exitState) {
        return new Outcome(Kind.OK, exitState, null, null);
    }

    public static Outcome failure(String type, String message) {
        return new Outcome(Kind.TECHNICAL_FAILURE, null, type, message);
    }

    public Outcome withExitState(Long value) {
        return new Outcome(kind, value, exceptionType, message);
    }
}
