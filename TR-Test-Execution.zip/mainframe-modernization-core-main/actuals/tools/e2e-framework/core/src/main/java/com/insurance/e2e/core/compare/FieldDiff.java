package com.insurance.e2e.core.compare;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * One difference between the legacy and the target observation.
 *
 * @param field     canonical field; inside a group {@code group[row].FIELD} (rows counted from 1)
 * @param kind      what differs
 * @param legacy    legacy value as reported (before normalization)
 * @param target    target value as reported (before normalization)
 * @param pattern   classification of a value difference (e.g. {@code TRAILING_BLANKS}); {@code null} otherwise
 * @param signature clustering key: one root cause should produce one signature across scenarios
 */
public record FieldDiff(String field, Kind kind, String legacy, String target, String pattern, String signature) {

    public enum Kind {
        VALUE,
        MISSING_IN_TARGET,
        MISSING_IN_LEGACY,
        MISSING_ON_BOTH,
        ROW_COUNT,
        ROW_MISSING_IN_TARGET,
        ROW_EXTRA_IN_TARGET,
        ORDER,
        EXIT_STATE,
        OUTCOME_KIND
    }

    /** One line for people: {@code items[6].code VALUE legacy='009' target='010' (VALUE)}. */
    @JsonIgnore
    public String text() {
        StringBuilder text = new StringBuilder(field).append(' ').append(kind);
        if (legacy != null || target != null) {
            text.append(" legacy='").append(legacy).append("' target='").append(target).append('\'');
        }
        if (pattern != null) {
            text.append(" (").append(pattern).append(')');
        }
        return text.toString();
    }
}
