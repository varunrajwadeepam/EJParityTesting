package com.insurance.e2e.core.json;

import com.fasterxml.jackson.databind.JsonNode;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import com.networknt.schema.ValidationMessage;
import com.insurance.e2e.core.E2eException;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Loads the framework's bundled JSON schemas (draft 2020-12) once and validates documents against them. The 1.1
 * schemas accept every 1.0 document (1.1 only adds optional properties), so they are the only ones bundled.
 */
public final class Schemas {

    public static final String SCENARIO_REGISTER = "/com/insurance/e2e/core/schema/scenario-register-1.1.schema.json";
    public static final String GOLDEN_MASTER = "/com/insurance/e2e/core/schema/golden-master-1.1.schema.json";

    private static final Map<String, JsonSchema> CACHE = new ConcurrentHashMap<>();
    private static final JsonSchemaFactory FACTORY = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V202012);

    private Schemas() {
    }

    /** Validation messages for {@code document}, sorted for stable reports; empty when valid. */
    public static List<String> validate(String schemaResource, JsonNode document) {
        JsonSchema schema = CACHE.computeIfAbsent(schemaResource, Schemas::load);
        return schema.validate(document).stream()
                .map(ValidationMessage::getMessage)
                .sorted()
                .toList();
    }

    private static JsonSchema load(String resource) {
        try (InputStream in = Schemas.class.getResourceAsStream(resource)) {
            if (in == null) {
                throw new E2eException("Bundled schema not found: " + resource);
            }
            return FACTORY.getSchema(in);
        } catch (IOException e) {
            throw new E2eException("Cannot load schema " + resource, e);
        }
    }
}
