package com.insurance.e2e.core.golden;

/**
 * One entry of a golden master's lifecycle history.
 *
 * @param from     previous state; {@code null} for the recording itself
 * @param to       new state
 * @param at       ISO-8601 UTC timestamp
 * @param by       who decided it (a person for the record gate; a stage or script otherwise)
 * @param reason   short reason
 * @param decision the signed decision ID behind it, when there is one
 */
public record LifecycleTransition(LifecycleState from, LifecycleState to, String at, String by, String reason,
                                  String decision) {
}
