package com.insurance.e2e.core.report;

import com.insurance.e2e.core.run.ScenarioReport;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/** All scenario-level outcomes of one run of one MU module. */
public record RunReport(String mu, String mode, String startedAt, String finishedAt, Map<String, Integer> counts,
                        List<ScenarioReport> scenarios) {

    public RunReport {
        scenarios = scenarios == null ? List.of() : List.copyOf(scenarios);
        counts = counts == null || counts.isEmpty() ? countByStatus(scenarios) : Map.copyOf(counts);
    }

    public static RunReport of(String mu, String mode, String startedAt, String finishedAt,
                               List<ScenarioReport> scenarios) {
        return new RunReport(mu, mode, startedAt, finishedAt, null, scenarios);
    }

    private static Map<String, Integer> countByStatus(List<ScenarioReport> scenarios) {
        Map<String, Integer> counts = new TreeMap<>();
        scenarios.forEach(s -> counts.merge(s.status().name(), 1, Integer::sum));
        return counts;
    }
}
