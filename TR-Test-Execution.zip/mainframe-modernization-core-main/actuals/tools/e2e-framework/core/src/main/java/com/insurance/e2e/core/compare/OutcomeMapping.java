package com.insurance.e2e.core.compare;

import java.util.List;

/**
 * Where each side reports its numeric exit state, and how target exceptions map to outcomes.
 *
 * @param legacyExitStateField legacy field with the numeric exit state (for CA:Gen drivers typically
 *                             {@code PSMGR-EXIT-STATE})
 * @param targetExitStatePath  dot path of an exit-state value in the target result, when the target reports one
 * @param exceptions           the outcome catalogue: which target exception stands for which legacy outcome (the
 *                             way a parity test maps an exit state to an exception class and message)
 */
public record OutcomeMapping(String legacyExitStateField, String targetExitStatePath, List<ExceptionRule> exceptions) {

    /**
     * One catalogue entry.
     *
     * @param exception      exception class, fully qualified or simple name; matched along the cause chain
     * @param kind           {@code BUSINESS_EXCEPTION} (a legacy business outcome) or {@code TECHNICAL_FAILURE}
     * @param exitState      the legacy exit state this exception stands for
     * @param messagePattern optional regular expression the message must match
     */
    public record ExceptionRule(String exception, String kind, Long exitState, String messagePattern) {
    }

    public OutcomeMapping {
        exceptions = exceptions == null ? List.of() : List.copyOf(exceptions);
    }

    public OutcomeMapping(String legacyExitStateField, String targetExitStatePath) {
        this(legacyExitStateField, targetExitStatePath, List.of());
    }
}
