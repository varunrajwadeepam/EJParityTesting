package com.insurance.e2e.core.compare;

import com.insurance.e2e.core.spi.ComparePlugin;

import java.util.Set;

/** The MVP compare binding: the typed field comparator behind the COMPARE extension point. */
public final class FieldComparePlugin implements ComparePlugin {

    private final FieldComparator comparator = new FieldComparator();

    @Override
    public String id() {
        return "field-comparator";
    }

    @Override
    public Set<String> kinds() {
        return Set.of(VIEW_FIELDS);
    }

    @Override
    public ComparisonResult compare(Request request) {
        return comparator.compare(request.scenarioId(), request.level(), request.legacy(), request.target(),
                request.mapping(), request.profile(), request.spec());
    }
}
