package com.insurance.e2e.core.junit;

import com.insurance.e2e.core.scenario.Scenario;
import com.insurance.e2e.core.spi.ExecutionContext;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Which scenarios a run takes: {@code -De2e.scenarios} (scenario ids, comma- or blank-separated) and
 * {@code -De2e.tags} (a {@link TagExpression} over {@link Scenario#effectiveTags()}); both must hold. Nothing set
 * selects everything. The register-driven tests and the Behaviour Specification apply the same selection.
 */
public final class ScenarioSelection {

    public static final String TAGS_PROPERTY = "e2e.tags";
    public static final String SCENARIOS_PROPERTY = "e2e.scenarios";

    private final TagExpression tags;
    private final Set<String> ids;
    private final String text;

    private ScenarioSelection(TagExpression tags, Set<String> ids, String text) {
        this.tags = tags;
        this.ids = ids;
        this.text = text;
    }

    public static ScenarioSelection fromContext(ExecutionContext context) {
        return of(context.property(SCENARIOS_PROPERTY), context.property(TAGS_PROPERTY));
    }

    public static ScenarioSelection of(String scenarioIds, String tagExpression) {
        Set<String> ids = new LinkedHashSet<>();
        if (scenarioIds != null) {
            for (String id : scenarioIds.split("[,;\\s]+")) {
                if (!id.isBlank()) {
                    ids.add(id.trim());
                }
            }
        }
        StringBuilder text = new StringBuilder();
        if (!ids.isEmpty()) {
            text.append(SCENARIOS_PROPERTY).append('=').append(String.join(",", ids));
        }
        if (tagExpression != null && !tagExpression.isBlank()) {
            text.append(text.isEmpty() ? "" : " ").append(TAGS_PROPERTY).append("=\"").append(tagExpression).append('"');
        }
        return new ScenarioSelection(TagExpression.parse(tagExpression), Set.copyOf(ids), text.toString());
    }

    public boolean matches(Scenario scenario) {
        return (ids.isEmpty() || ids.contains(scenario.scenarioId())) && tags.matches(scenario.effectiveTags());
    }

    /** Selected ids no scenario has (a typo selects nothing silently otherwise). */
    public List<String> unknownIds(Collection<Scenario> scenarios) {
        Set<String> known = new LinkedHashSet<>();
        scenarios.forEach(s -> known.add(s.scenarioId()));
        return ids.stream().filter(id -> !known.contains(id)).sorted().toList();
    }

    public boolean selectsAll() {
        return text.isEmpty();
    }

    @Override
    public String toString() {
        return selectsAll() ? "(everything)" : text;
    }
}
