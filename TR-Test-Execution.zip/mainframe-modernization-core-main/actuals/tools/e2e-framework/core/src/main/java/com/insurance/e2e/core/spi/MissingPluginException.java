package com.insurance.e2e.core.spi;

import com.insurance.e2e.core.E2eException;

/**
 * No plugin serves a needed kind. The affected scenarios are {@code BLOCKED} and a route-back goes to the framework
 * owner - a missing plugin is never a silent skip.
 */
public class MissingPluginException extends E2eException {

    private final ExtensionPoint point;
    private final String kind;

    public MissingPluginException(ExtensionPoint point, String kind) {
        super("No " + point + " plugin serves kind '" + kind + "'");
        this.point = point;
        this.kind = kind;
    }

    public ExtensionPoint point() {
        return point;
    }

    public String kind() {
        return kind;
    }

    /** The route-back text for the triage log. */
    public String routeBack() {
        return "route-back to the framework owner: provide a " + point + " plugin for kind '" + kind
                + "' (framework module + tests, released with the distributive)";
    }
}
