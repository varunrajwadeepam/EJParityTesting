package com.insurance.e2e.core.compare;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;
import java.util.Set;

/**
 * The comparison of one scenario level under one profile.
 *
 * @param status     {@link Status#MATCH}, {@link Status#DIFF} or {@link Status#VACUOUS} (both sides returned nothing
 *                   and the scenario did not declare that as expected - never silently a match)
 * @param compared   number of value pairs compared
 * @param matched    number of value pairs equal after normalization
 * @param decisions  decision IDs behind the profile's rules
 * @param signatures distinct diff signatures, sorted
 */
public record ComparisonResult(String scenarioId, String unit, String level, String profile, Status status,
                               int compared, int matched, List<FieldDiff> diffs, List<String> notes,
                               Set<String> decisions, List<String> signatures) {

    public enum Status { MATCH, DIFF, VACUOUS }

    public ComparisonResult {
        diffs = diffs == null ? List.of() : List.copyOf(diffs);
        notes = notes == null ? List.of() : List.copyOf(notes);
        decisions = decisions == null ? Set.of() : Set.copyOf(decisions);
        signatures = signatures == null ? List.of() : List.copyOf(signatures);
    }

    @JsonIgnore
    public boolean isMatch() {
        return status == Status.MATCH;
    }
}
