package com.insurance.e2e.core.junit;

import com.insurance.e2e.core.golden.GoldenMasterStore;
import com.insurance.e2e.core.run.E2eMode;
import com.insurance.e2e.core.run.E2eModule;
import com.insurance.e2e.core.run.ScenarioReport;
import com.insurance.e2e.core.run.ScenarioRunner;
import com.insurance.e2e.core.scenario.LevelBinding;
import com.insurance.e2e.core.scenario.Scenario;
import com.insurance.e2e.core.spi.ExecutionContext;
import com.insurance.e2e.core.spi.PluginRegistry;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.DynamicContainer;
import org.junit.jupiter.api.DynamicNode;
import org.junit.jupiter.api.DynamicTest;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

/**
 * Turns an MU e2e module's resources into JUnit 5 dynamic tests: one container per scenario, one test per level.
 * A generated test class needs only:
 *
 * <pre>{@code
 * @TestFactory
 * Stream<DynamicNode> scenarios() {
 *     return E2eScenarioTests.forModule("e2e").dynamicTests();
 * }
 * }</pre>
 *
 * <p>These tests <strong>lint</strong>, in every run mode: the plugins, mappings and golden masters each scenario
 * needs, the golden masters' seals, and the coverage of the register by the Behaviour Specification (every register
 * scenario has exactly one feature scenario and the reverse). The scenarios are executed by the Behaviour
 * Specification (the module's Cucumber suite), through the same {@link ScenarioRunner} - an explicit {@link #mode}
 * is for tests of the framework only. Layout: see {@link E2eModule}; selection from {@code -De2e.scenarios} and
 * {@code -De2e.tags} ({@link ScenarioSelection}). A module without scenarios yields no tests at all.
 */
public final class E2eScenarioTests {

    public static final String MODULE_DIR_PROPERTY = E2eModule.MODULE_DIR_PROPERTY;
    public static final String TAGS_PROPERTY = ScenarioSelection.TAGS_PROPERTY;
    public static final String SCENARIOS_PROPERTY = ScenarioSelection.SCENARIOS_PROPERTY;
    /** Execution-context attribute (a {@link Path}) naming the module's e2e resource root, for plugins. */
    public static final String RESOURCES_DIR_ATTRIBUTE = E2eModule.RESOURCES_DIR_ATTRIBUTE;

    private final String resourceRoot;
    private Path resourceDir;
    private Path moduleDir;
    private E2eMode mode;
    private PluginRegistry registry;
    private ExecutionContext context;

    private E2eScenarioTests(String resourceRoot) {
        this.resourceRoot = resourceRoot;
    }

    public static E2eScenarioTests forModule(String resourceRoot) {
        return new E2eScenarioTests(resourceRoot);
    }

    /** Reads the module resources from this directory instead of the classpath. */
    public E2eScenarioTests resourceDir(Path dir) {
        this.resourceDir = dir;
        return this;
    }

    /** The module base directory; record mode writes golden masters under its {@code src/test/resources}. */
    public E2eScenarioTests moduleDir(Path dir) {
        this.moduleDir = dir;
        return this;
    }

    /** Executes in this mode instead of linting - framework tests only; a module's scenarios execute as features. */
    public E2eScenarioTests mode(E2eMode value) {
        this.mode = value;
        return this;
    }

    public E2eScenarioTests registry(PluginRegistry value) {
        this.registry = value;
        return this;
    }

    public E2eScenarioTests context(ExecutionContext value) {
        this.context = value;
        return this;
    }

    public Stream<DynamicNode> dynamicTests() {
        ExecutionContext ctx = context == null ? ExecutionContext.fromSystem() : context;
        E2eMode runMode = mode == null ? E2eMode.LINT : mode;
        Path resources = resourceDir == null ? classpathDir(resourceRoot) : resourceDir;
        if (resources == null || !Files.isDirectory(resources)) {
            return Stream.empty();
        }
        E2eModule module = E2eModule.load(resourceRoot, resources, moduleDir, runMode, registry, ctx);
        ScenarioRunner runner = module.runner();
        GoldenMasterStore store = module.goldens();
        ScenarioSelection selection = ScenarioSelection.fromContext(ctx);

        List<ScenarioReport> collected = Collections.synchronizedList(new ArrayList<>());
        List<DynamicNode> nodes = new ArrayList<>();
        if (runMode == E2eMode.LINT && Files.isDirectory(store.root())) {
            nodes.add(DynamicTest.dynamicTest("golden-master integrity", () -> {
                List<String> problems = store.verifyAll();
                if (!problems.isEmpty()) {
                    throw new AssertionError("golden-master integrity: " + String.join("; ", problems));
                }
            }));
        }
        List<String> unknown = selection.unknownIds(module.scenarios());
        if (!unknown.isEmpty()) {
            nodes.add(DynamicTest.dynamicTest("selection", () -> {
                throw new AssertionError("-D" + SCENARIOS_PROPERTY + " names scenarios the register does not have: "
                        + String.join(", ", unknown));
            }));
        }
        int scenarios = 0;
        for (Scenario scenario : module.scenarios()) {
            if (!selection.matches(scenario)) {
                continue;
            }
            scenarios++;
            List<DynamicTest> levels = new ArrayList<>();
            for (LevelBinding level : scenario.levels()) {
                levels.add(DynamicTest.dynamicTest(level.toString(),
                        () -> execute(runner, runMode, scenario, level, collected)));
            }
            nodes.add(DynamicContainer.dynamicContainer(scenario.displayName(), levels));
        }
        if (scenarios > 0) {
            String started = ctx.now();
            nodes.add(DynamicTest.dynamicTest("e2e run report",
                    () -> module.writeReport(runMode, started, List.copyOf(collected))));
            nodes.add(DynamicTest.dynamicTest("behaviour specification coverage", () -> coverage(module)));
        }
        return nodes.stream();
    }

    /**
     * Every register scenario has exactly one feature scenario and the reverse. A module whose design stage has not
     * generated the Behaviour Specification yet (no {@code .feature} file at all) is reported, not failed.
     */
    private static void coverage(E2eModule module) {
        Path features = module.featuresDir();
        Assumptions.assumeTrue(E2eModule.hasFeatures(features),
                "no Behaviour Specification yet: the design stage (e2e_package import) generates features/*.feature");
        List<String> problems = FeatureCoverage.problems(features, module.scenarios());
        if (!problems.isEmpty()) {
            List<String> shown = problems.subList(0, Math.min(20, problems.size()));
            throw new AssertionError("the features and the register disagree (" + problems.size() + "): "
                    + String.join("; ", shown) + (problems.size() > shown.size() ? "; ..." : ""));
        }
    }

    /**
     * Signals one level's outcome to JUnit. A block the register declared (with its reason and owner) is a known,
     * reported state, not a harness defect: the test is aborted, the run report keeps it as {@code BLOCKED}.
     */
    private static void execute(ScenarioRunner runner, E2eMode mode, Scenario scenario, LevelBinding level,
                                List<ScenarioReport> collected) {
        ScenarioReport report = runner.run(mode, scenario, level);
        collected.add(report);
        switch (report.status()) {
            case PASSED, RECORDED -> {
                // nothing to signal
            }
            case SKIPPED -> Assumptions.abort("SKIPPED: " + report.message());
            case NOT_APPLICABLE -> Assumptions.abort("N/A: " + report.message());
            case BLOCKED, FAILED -> {
                if (report.status() == ScenarioReport.Status.BLOCKED && scenario.isDeclaredBlocked()) {
                    Assumptions.abort("BLOCKED: " + report.message());
                }
                throw new AssertionError(report.status() + ": " + report.message()
                        + (report.notes().isEmpty() ? "" : " | notes: " + String.join("; ", report.notes()))
                        + (report.hypotheses().isEmpty() ? "" : " | hypotheses: " + String.join("; ", report.hypotheses())));
            }
        }
    }

    static Path classpathDir(String resource) {
        return E2eModule.classpathDir(resource);
    }
}
