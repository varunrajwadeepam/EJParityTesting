package com.insurance.e2e.core.scenario;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.databind.JsonNode;
import com.insurance.e2e.core.json.JsonSupport;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Map;

/**
 * The target side's HTTP request of a service-lens scenario.
 *
 * @param method  HTTP method, upper case (default {@code GET})
 * @param path    request path as sent, <strong>already percent-encoded</strong> ({@code /lookups/%20KIND}); a binding
 *                never encodes it again
 * @param query   query parameters in order, names and values <strong>raw</strong>; the binding encodes them
 * @param headers   extra request headers
 * @param body      JSON request body, if any
 * @param principal the user the call is made as - the legacy's user id the recording ran with, for an API that takes
 *                  the user from the caller's identity (a package's {@code request.principal}); {@code null}: no caller.
 *                  Never a credential: the binding turns it into a test identity, or does not send the call
 */
public record HttpRequestSpec(String method, String path, Map<String, String> query, Map<String, String> headers,
                              JsonNode body, String principal) {

    @JsonCreator
    public HttpRequestSpec {
        method = method == null || method.isBlank() ? "GET" : method.trim().toUpperCase(Locale.ROOT);
        query = JsonSupport.orderedCopy(query);
        headers = JsonSupport.orderedCopy(headers);
        principal = principal == null || principal.isBlank() ? null : principal;
    }

    /** A request made with no caller. */
    public HttpRequestSpec(String method, String path, Map<String, String> query, Map<String, String> headers,
                           JsonNode body) {
        this(method, path, query, headers, body, null);
    }

    /** What is requested, exactly as sent: the path and the encoded query ({@code /lookups/KIND?searchValue=+A}). */
    public String target() {
        return path + encodedQuery(query);
    }

    /**
     * {@link #target()} for people: the brackets of an indexed parameter shown as they are
     * ({@code ?context[0].kind=DIRECT}, sent as {@code ?context%5B0%5D.kind=DIRECT}). Unambiguous, because the encoder
     * writes a {@code %} as {@code %25}: a {@code %5B} / {@code %5D} of the encoded query only ever stands for a bracket.
     */
    public String readableTarget() {
        return path + encodedQuery(query).replace("%5B", "[").replace("%5D", "]");
    }

    /** The encoded query string, {@code ?a=1&b=} - empty when there are no parameters. */
    public static String encodedQuery(Map<String, String> parameters) {
        if (parameters == null || parameters.isEmpty()) {
            return "";
        }
        StringBuilder query = new StringBuilder();
        parameters.forEach((name, value) -> query.append(query.isEmpty() ? '?' : '&')
                .append(URLEncoder.encode(name, StandardCharsets.UTF_8)).append('=')
                .append(value == null ? "" : URLEncoder.encode(value, StandardCharsets.UTF_8)));
        return query.toString();
    }
}
