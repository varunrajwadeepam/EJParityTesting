package com.insurance.e2e.core.junit;

import com.insurance.e2e.core.E2eException;

import java.util.Set;
import java.util.function.Predicate;

/**
 * Tag selection for dynamic tests, which carry no JUnit tags of their own. Same operators as JUnit tag
 * expressions: {@code !} not, {@code &} and, {@code |} or, parentheses; tags may contain {@code : . _ -}.
 * Example: {@code -De2e.tags="P0 & lens:service & !clock-sensitive"}.
 */
public final class TagExpression {

    private final Predicate<Set<String>> predicate;
    private final String text;

    private TagExpression(Predicate<Set<String>> predicate, String text) {
        this.predicate = predicate;
        this.text = text;
    }

    /** A blank expression selects everything. */
    public static TagExpression parse(String text) {
        if (text == null || text.isBlank()) {
            return new TagExpression(tags -> true, "");
        }
        Parser parser = new Parser(text);
        Predicate<Set<String>> predicate = parser.or();
        parser.skipSpaces();
        if (parser.pos < text.length()) {
            throw new E2eException("Unexpected '" + text.charAt(parser.pos) + "' at " + parser.pos + " in tag expression '" + text + "'");
        }
        return new TagExpression(predicate, text);
    }

    public boolean matches(Set<String> tags) {
        return predicate.test(tags);
    }

    @Override
    public String toString() {
        return text;
    }

    private static final class Parser {
        private final String text;
        private int pos;

        Parser(String text) {
            this.text = text;
        }

        Predicate<Set<String>> or() {
            Predicate<Set<String>> left = and();
            while (peek('|')) {
                pos++;
                left = left.or(and());
            }
            return left;
        }

        Predicate<Set<String>> and() {
            Predicate<Set<String>> left = unary();
            while (peek('&')) {
                pos++;
                left = left.and(unary());
            }
            return left;
        }

        Predicate<Set<String>> unary() {
            if (peek('!')) {
                pos++;
                return unary().negate();
            }
            if (peek('(')) {
                pos++;
                Predicate<Set<String>> inner = or();
                if (!peek(')')) {
                    throw new E2eException("Missing ')' in tag expression '" + text + "'");
                }
                pos++;
                return inner;
            }
            return tag();
        }

        Predicate<Set<String>> tag() {
            skipSpaces();
            int start = pos;
            while (pos < text.length() && isTagChar(text.charAt(pos))) {
                pos++;
            }
            if (start == pos) {
                throw new E2eException("Expected a tag at " + pos + " in tag expression '" + text + "'");
            }
            String tag = text.substring(start, pos);
            return tags -> tags.contains(tag);
        }

        boolean peek(char c) {
            skipSpaces();
            return pos < text.length() && text.charAt(pos) == c;
        }

        void skipSpaces() {
            while (pos < text.length() && Character.isWhitespace(text.charAt(pos))) {
                pos++;
            }
        }

        private static boolean isTagChar(char c) {
            return Character.isLetterOrDigit(c) || c == ':' || c == '.' || c == '_' || c == '-';
        }
    }
}
