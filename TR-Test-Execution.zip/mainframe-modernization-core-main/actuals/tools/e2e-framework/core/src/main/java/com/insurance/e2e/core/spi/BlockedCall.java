package com.insurance.e2e.core.spi;

import com.insurance.e2e.core.E2eException;

/**
 * A trigger cannot make a scenario's call in this run's configuration - e.g. the call is made as a user
 * ({@link com.insurance.e2e.core.scenario.HttpRequestSpec#principal()}) and no caller identity is configured. The
 * scenario is {@code BLOCKED} with the reason and the owner who can lift it; the call is never sent in another way
 * (anonymously, as another user), and it is never a difference of the application under validation.
 */
public class BlockedCall extends E2eException {

    private final String owner;

    public BlockedCall(String reason, String owner) {
        super(reason);
        this.owner = owner;
    }

    /** Who can lift the block (a command, a configuration key, a stage). */
    public String owner() {
        return owner;
    }
}
