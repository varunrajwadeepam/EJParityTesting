package com.insurance.e2e.core.scenario;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.insurance.e2e.core.json.JsonSupport;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * One scenario of the register: the machine contract. It carries <strong>no expected values</strong> - the golden
 * master recorded from the legacy execution supplies them.
 *
 * <p>{@code request} keeps its order: it is the order in which the legacy driver applies the inputs, which is
 * observable when two inputs touch the same group. {@code http} is the target side's request when the target is an
 * HTTP API.
 *
 * <p>{@code status} says whether the scenario can run at all: {@value #RUNNABLE} (default), {@value #NOT_APPLICABLE}
 * (the request cannot be expressed at this lens - reported, never executed or counted) or {@value #BLOCKED} (known not
 * to run, e.g. the legacy could not be recorded - reported with its reason and owner). {@code hypotheses} are
 * anticipated differences from reading the code: shown next to a failure, never an expected value.
 *
 * <p>{@code tables} are the table checks read after the call (what the call left in the database), and
 * {@code answerEmpty} states whether the answer has a body at all: both come from a golden-master package of format 3
 * and are compared like the answer itself.
 *
 * <p>{@code decided} marks a scenario whose expected answer the architecture decides ({@link DecidedAnswer}): its golden
 * master holds the decided answer, not the recording's - an accepted deviation, reported apart from the scenarios
 * equal to the legacy. It changes nothing in the comparison (the golden master is the oracle).
 */
public record Scenario(
        String scenarioId,
        Map<String, String> origin,
        String servicePoint,
        String branch,
        String priority,
        List<String> ruleIds,
        List<String> risks,
        List<String> caveats,
        List<String> tags,
        List<LevelBinding> levels,
        String fixture,
        String clock,
        String dbMode,
        Map<String, String> request,
        CompareSpec compare,
        @JsonProperty("assert") List<Assertion> assertions,
        String golden,
        String title,
        String description,
        String category,
        String status,
        String statusReason,
        List<String> hypotheses,
        Boolean clockSensitive,
        HttpRequestSpec http,
        List<TableCheck> tables,
        Boolean answerEmpty,
        DecidedAnswer decided) {

    public static final String RUNNABLE = "runnable";
    public static final String NOT_APPLICABLE = "not-applicable";
    public static final String BLOCKED = "blocked";

    @JsonCreator
    public Scenario {
        origin = JsonSupport.orderedCopy(origin);
        ruleIds = ruleIds == null ? List.of() : List.copyOf(ruleIds);
        risks = risks == null ? List.of() : List.copyOf(risks);
        caveats = caveats == null ? List.of() : List.copyOf(caveats);
        tags = tags == null ? List.of() : List.copyOf(tags);
        levels = levels == null ? List.of() : List.copyOf(levels);
        request = JsonSupport.orderedCopy(request);
        compare = compare == null ? CompareSpec.defaults() : compare;
        assertions = assertions == null ? List.of() : List.copyOf(assertions);
        status = status == null || status.isBlank() ? RUNNABLE : status;
        hypotheses = hypotheses == null ? List.of() : List.copyOf(hypotheses);
        tables = tables == null ? List.of() : List.copyOf(tables);
    }

    /** A scenario in the 1.0 shape: runnable, no HTTP request, no hypotheses. */
    public Scenario(String scenarioId, Map<String, String> origin, String servicePoint, String branch, String priority,
                    List<String> ruleIds, List<String> risks, List<String> caveats, List<String> tags,
                    List<LevelBinding> levels, String fixture, String clock, String dbMode, Map<String, String> request,
                    CompareSpec compare, List<Assertion> assertions, String golden) {
        this(scenarioId, origin, servicePoint, branch, priority, ruleIds, risks, caveats, tags, levels, fixture, clock,
                dbMode, request, compare, assertions, golden, null, null, null, null, null, null, null, null, null, null,
                null);
    }

    /** A scenario in the 1.1 shape (an answer, no table checks). */
    public Scenario(String scenarioId, Map<String, String> origin, String servicePoint, String branch, String priority,
                    List<String> ruleIds, List<String> risks, List<String> caveats, List<String> tags,
                    List<LevelBinding> levels, String fixture, String clock, String dbMode, Map<String, String> request,
                    CompareSpec compare, List<Assertion> assertions, String golden, String title, String description,
                    String category, String status, String statusReason, List<String> hypotheses,
                    Boolean clockSensitive, HttpRequestSpec http) {
        this(scenarioId, origin, servicePoint, branch, priority, ruleIds, risks, caveats, tags, levels, fixture, clock,
                dbMode, request, compare, assertions, golden, title, description, category, status, statusReason,
                hypotheses, clockSensitive, http, null, null, null);
    }

    /** A scenario in the 1.1 shape with table checks (format 3), its answer not decided. */
    public Scenario(String scenarioId, Map<String, String> origin, String servicePoint, String branch, String priority,
                    List<String> ruleIds, List<String> risks, List<String> caveats, List<String> tags,
                    List<LevelBinding> levels, String fixture, String clock, String dbMode, Map<String, String> request,
                    CompareSpec compare, List<Assertion> assertions, String golden, String title, String description,
                    String category, String status, String statusReason, List<String> hypotheses,
                    Boolean clockSensitive, HttpRequestSpec http, List<TableCheck> tables, Boolean answerEmpty) {
        this(scenarioId, origin, servicePoint, branch, priority, ruleIds, risks, caveats, tags, levels, fixture, clock,
                dbMode, request, compare, assertions, golden, title, description, category, status, statusReason,
                hypotheses, clockSensitive, http, tables, answerEmpty, null);
    }

    /** Whether the scenario reads tables or states its answer's emptiness after the call (format 3). */
    @JsonIgnore
    public boolean checksState() {
        return !tables.isEmpty() || answerEmpty != null;
    }

    @JsonIgnore
    public boolean isRunnable() {
        return RUNNABLE.equals(status);
    }

    @JsonIgnore
    public boolean isNotApplicable() {
        return NOT_APPLICABLE.equals(status);
    }

    @JsonIgnore
    public boolean isDeclaredBlocked() {
        return BLOCKED.equals(status);
    }

    /**
     * Tags used for selection ({@code -De2e.tags}) and shown in test names: the priority, risks, caveats,
     * {@code level:Lx} and {@code lens:x} per level, {@code unit:U} per legacy unit, {@code branch:X},
     * {@code category:X}, {@code clock-sensitive} and the explicit tags.
     */
    @JsonIgnore
    public Set<String> effectiveTags() {
        Set<String> all = new LinkedHashSet<>();
        if (priority != null && !priority.isBlank()) {
            all.add(priority);
        }
        all.addAll(risks);
        all.addAll(caveats);
        for (LevelBinding level : levels) {
            all.add("level:" + level.effectiveLevel());
            all.add("lens:" + level.effectiveLens());
            all.add("unit:" + level.legacyUnit());
        }
        if (branch != null && !branch.isBlank()) {
            all.add("branch:" + branch.replace(' ', '_'));
        }
        if (category != null && !category.isBlank()) {
            all.add("category:" + category.replace(' ', '_'));
        }
        if (Boolean.TRUE.equals(clockSensitive)) {
            all.add("clock-sensitive");
        }
        all.addAll(tags);
        return all;
    }

    /** Display name: id, title and the priority, risk and caveat tags that matter when reading a report. */
    @JsonIgnore
    public String displayName() {
        StringBuilder name = new StringBuilder(scenarioId);
        if (title != null && !title.isBlank()) {
            name.append(' ').append(title);
        }
        Set<String> shown = new LinkedHashSet<>();
        if (priority != null && !priority.isBlank()) {
            shown.add(priority);
        }
        shown.addAll(risks);
        shown.addAll(caveats);
        if (!shown.isEmpty()) {
            name.append(" [").append(String.join(" ", shown)).append(']');
        }
        return name.toString();
    }
}
