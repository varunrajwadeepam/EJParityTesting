package com.insurance.e2e.core.golden;

import com.fasterxml.jackson.databind.JsonNode;
import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.json.Schemas;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Golden masters on disk: {@code <root>/<unit>/<scenarioId>.json}; superseded ones move to
 * {@code <root>/<unit>/.superseded/<scenarioId>.<hash12>.json} and are never deleted.
 *
 * <p>The store enforces "never edited": a new golden master is written only where none exists, and an update is
 * accepted only when it changes nothing but the lifecycle (same content hash).
 */
public final class GoldenMasterStore {

    public static final String SUPERSEDED_DIR = ".superseded";

    private final Path root;

    public GoldenMasterStore(Path root) {
        this.root = root;
    }

    public Path root() {
        return root;
    }

    public Path pathFor(String unit, String scenarioId) {
        return root.resolve(unit).resolve(scenarioId + ".json");
    }

    public Optional<GoldenMaster> find(String unit, String scenarioId) {
        Path file = pathFor(unit, scenarioId);
        return Files.isRegularFile(file) ? Optional.of(read(file)) : Optional.empty();
    }

    public GoldenMaster read(Path file) {
        return JsonSupport.read(file, GoldenMaster.class);
    }

    /** Writes a new golden master; refuses to overwrite an existing one (re-record instead). */
    public Path writeNew(GoldenMaster master) {
        requireSealed(master);
        Path file = pathFor(master.unit(), master.scenarioId());
        if (Files.exists(file)) {
            throw new E2eException("Golden master " + file + " already exists; a golden master is never overwritten "
                    + "- re-record it instead");
        }
        JsonSupport.write(file, master);
        return file;
    }

    /** Persists a lifecycle change. The content hash must be unchanged. */
    public Path updateLifecycle(GoldenMaster updated) {
        requireSealed(updated);
        Path file = pathFor(updated.unit(), updated.scenarioId());
        GoldenMaster stored = find(updated.unit(), updated.scenarioId())
                .orElseThrow(() -> new E2eException("No golden master to update at " + file));
        if (!stored.contentHash().equals(updated.contentHash())) {
            throw new E2eException("Golden master " + file + ": only the lifecycle may change, the content hash differs");
        }
        JsonSupport.write(file, updated);
        return file;
    }

    /**
     * Replaces a golden master by a re-recording: {@code previous} - with its final lifecycle, normally ending in
     * {@code STALE} - is archived under {@code .superseded/}, and the new one (which must name the previous content
     * hash in {@code supersedes}) is written in its place.
     */
    public Path rerecord(GoldenMaster previous, GoldenMaster next) {
        requireSealed(previous);
        requireSealed(next);
        if (!previous.contentHash().equals(next.supersedes())) {
            throw new E2eException("A re-recording must name the golden master it supersedes ("
                    + previous.contentHash() + ")");
        }
        Path file = pathFor(previous.unit(), previous.scenarioId());
        Path archive = file.getParent().resolve(SUPERSEDED_DIR)
                .resolve(previous.scenarioId() + "." + previous.contentHash().substring(0, 12) + ".json");
        JsonSupport.write(archive, previous);
        JsonSupport.write(file, next);
        return file;
    }

    /** Integrity of every golden master under the root: schema, content hash, path, lifecycle history. */
    public List<String> verifyAll() {
        List<String> problems = new ArrayList<>();
        if (!Files.isDirectory(root)) {
            return problems;
        }
        List<Path> files;
        try (Stream<Path> walk = Files.walk(root)) {
            files = walk.filter(Files::isRegularFile)
                    .filter(p -> p.getFileName().toString().endsWith(".json"))
                    .filter(p -> !p.getParent().getFileName().toString().equals(SUPERSEDED_DIR))
                    .sorted()
                    .toList();
        } catch (IOException e) {
            throw new E2eException("Cannot list golden masters under " + root, e);
        }
        for (Path file : files) {
            problems.addAll(verify(file));
        }
        return problems;
    }

    /** Integrity problems of one golden-master file; empty when it is sound. */
    public List<String> verify(Path file) {
        List<String> problems = new ArrayList<>();
        String name = root.relativize(file).toString().replace('\\', '/');
        JsonNode tree;
        try {
            tree = JsonSupport.readTree(file);
        } catch (E2eException e) {
            problems.add(name + ": not valid JSON");
            return problems;
        }
        for (String message : Schemas.validate(Schemas.GOLDEN_MASTER, tree)) {
            problems.add(name + ": " + message);
        }
        if (!problems.isEmpty()) {
            return problems;
        }
        GoldenMaster master = read(file);
        if (!master.integrityHolds()) {
            problems.add(name + ": content hash mismatch - the golden master was edited");
        }
        Path expected = pathFor(master.unit(), master.scenarioId());
        if (!expected.normalize().equals(file.normalize())) {
            problems.add(name + ": stored under the wrong path (expected " + root.relativize(expected) + ")");
        }
        for (String problem : Lifecycle.historyProblems(master)) {
            problems.add(name + ": " + problem);
        }
        return problems;
    }

    private static void requireSealed(GoldenMaster master) {
        if (!master.integrityHolds()) {
            throw new E2eException("Golden master " + master.unit() + "/" + master.scenarioId()
                    + " is not sealed (content hash missing or wrong)");
        }
    }
}
