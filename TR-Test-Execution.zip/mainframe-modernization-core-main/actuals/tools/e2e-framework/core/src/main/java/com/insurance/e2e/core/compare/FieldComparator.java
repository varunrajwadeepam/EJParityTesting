package com.insurance.e2e.core.compare;

import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.observation.Outcome;
import com.insurance.e2e.core.scenario.CompareSpec;
import com.insurance.e2e.core.scenario.TableCheck;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

/**
 * The typed, field-level comparator (the MVP compare binding).
 *
 * <ul>
 *   <li>both observations are projected into the canonical form by the view mapping;</li>
 *   <li>the outcome is compared on its kind and its <strong>numeric</strong> exit state;</li>
 *   <li>scalar fields are compared after the profile's normalization;</li>
 *   <li>row groups are compared as a multiset or in order, as the scenario's ordering evidence dictates;</li>
 *   <li>a field the profile ignores - by name, or as {@code group[].field} - is not compared;</li>
 *   <li>on an error answer under {@code OUTCOME_ONLY_ON_ERROR} the body is not compared, the rows a call left
 *       ({@code table:} groups) still are;</li>
 *   <li>an empty-versus-empty comparison is {@code VACUOUS}, not a match, unless the scenario expects it;</li>
 *   <li>every difference carries a signature for clustering.</li>
 * </ul>
 */
public final class FieldComparator {

    public ComparisonResult compare(String scenarioId, String level, Observation legacy, Observation target,
                                    ViewMapping mapping, NormalizationProfile profile, CompareSpec spec) {
        Observation l = mapping.toCanonical(legacy);
        Observation t = mapping.toCanonical(target);
        Context ctx = new Context(mapping.unit(), profile);

        compareOutcome(ctx, l.outcome(), t.outcome());
        if (profile.has(NormalizationRule.OUTCOME_ONLY_ON_ERROR)
                && (l.outcome().kind() != Outcome.Kind.OK || t.outcome().kind() != Outcome.Kind.OK)) {
            ctx.notes.add("outcome compared only (profile " + profile.name() + ", rule OUTCOME_ONLY_ON_ERROR): "
                    + describe(l.outcome()) + " vs " + describe(t.outcome()));
            if (groupNames(l, t, mapping).stream().anyMatch(FieldComparator::isTableGroup)) {
                ctx.notes.add("the rows the call left are compared on an error answer too");
                compareGroups(ctx, l, t, mapping, spec, true);
            }
            return result(scenarioId, level, mapping, profile, ctx,
                    ctx.diffs.isEmpty() ? ComparisonResult.Status.MATCH : ComparisonResult.Status.DIFF);
        }
        boolean anyValue = compareScalars(ctx, l, t, mapping);
        boolean anyRows = compareGroups(ctx, l, t, mapping, spec, false);

        boolean hasGroups = !groupNames(l, t, mapping).isEmpty();
        boolean vacuous = hasGroups ? !anyRows : !anyValue;
        ComparisonResult.Status status;
        if (!ctx.diffs.isEmpty()) {
            status = ComparisonResult.Status.DIFF;
        } else if (vacuous && !spec.emptyExpected()) {
            status = ComparisonResult.Status.VACUOUS;
            ctx.notes.add("anti-vacuity: both sides returned nothing; declare compare.expectEmpty if that is the point");
        } else {
            status = ComparisonResult.Status.MATCH;
        }
        return result(scenarioId, level, mapping, profile, ctx, status);
    }

    private static ComparisonResult result(String scenarioId, String level, ViewMapping mapping,
                                           NormalizationProfile profile, Context ctx, ComparisonResult.Status status) {
        Set<String> signatures = new TreeSet<>();
        ctx.diffs.forEach(d -> signatures.add(d.signature()));
        return new ComparisonResult(scenarioId, mapping.unit(), level, profile.name(), status, ctx.compared,
                ctx.matched, ctx.diffs, ctx.notes, profile.decisions(), new ArrayList<>(signatures));
    }

    private static String describe(Outcome outcome) {
        return outcome.kind() + (outcome.exitState() == null ? "" : " " + outcome.exitState());
    }

    /**
     * The legacy side completes and reports an exit state; the target may signal the same business outcome as an
     * exception. A catalogued business exception (one that names its legacy exit state) is therefore equivalent to a
     * completed legacy run - the exit states decide. A failure on one side only, or an uncatalogued business
     * exception, is an outcome difference.
     */
    private void compareOutcome(Context ctx, Outcome legacy, Outcome target) {
        boolean legacyFailed = failed(legacy);
        boolean targetFailed = failed(target);
        boolean uncatalogued = !targetFailed && target.kind() == Outcome.Kind.BUSINESS_EXCEPTION
                && legacy.kind() == Outcome.Kind.OK && target.exitState() == null;
        if (legacyFailed != targetFailed || uncatalogued) {
            ctx.diff("$outcome", FieldDiff.Kind.OUTCOME_KIND, legacy.kind().name(),
                    target.kind() + (target.exceptionType() == null ? "" : " " + target.exceptionType()), null);
        }
        if (legacy.exitState() != null && target.exitState() != null) {
            ctx.compared++;
            if (legacy.exitState().equals(target.exitState())) {
                ctx.matched++;
            } else {
                ctx.diff("$exitState", FieldDiff.Kind.EXIT_STATE, legacy.exitState().toString(),
                        target.exitState().toString(), null);
            }
        }
    }

    /** @return {@code true} when any compared scalar carries a non-blank value on either side */
    private boolean compareScalars(Context ctx, Observation l, Observation t, ViewMapping mapping) {
        Set<String> names = new LinkedHashSet<>();
        if (mapping.isIdentity()) {
            names.addAll(l.fields().keySet());
            names.addAll(t.fields().keySet());
        } else {
            mapping.fields().forEach(f -> names.add(f.legacy()));
        }
        boolean anyValue = false;
        for (String name : names) {
            if (ctx.profile.ignores(null, name)) {
                ctx.notes.add("not compared (profile " + ctx.profile.name() + "): " + name);
                continue;
            }
            FieldMapping field = mapping.field(name).orElse(FieldMapping.of(name));
            if (!mapping.isIdentity() && field.target() == null) {
                continue; // legacy-only field: reported, never compared
            }
            boolean inLegacy = l.fields().containsKey(name);
            boolean inTarget = t.fields().containsKey(name);
            String lv = l.fields().get(name);
            String tv = t.fields().get(name);
            if (!inLegacy && !inTarget) {
                ctx.diff(name, FieldDiff.Kind.MISSING_ON_BOTH, null, null, null);
                continue;
            }
            if (!inTarget) {
                ctx.diff(name, FieldDiff.Kind.MISSING_IN_TARGET, lv, null, null);
                continue;
            }
            if (!inLegacy) {
                ctx.diff(name, FieldDiff.Kind.MISSING_IN_LEGACY, null, tv, null);
                continue;
            }
            anyValue |= notBlank(lv) || notBlank(tv);
            ctx.compareValue(name, name, field, lv, tv);
        }
        return anyValue;
    }

    /** @return {@code true} when any group has at least one row on either side */
    private boolean compareGroups(Context ctx, Observation l, Observation t, ViewMapping mapping, CompareSpec spec,
                                  boolean tablesOnly) {
        boolean anyRows = false;
        for (String group : groupNames(l, t, mapping)) {
            if (tablesOnly && !isTableGroup(group)) {
                continue;
            }
            List<Map<String, String>> lr = l.groups().getOrDefault(group, List.of());
            List<Map<String, String>> tr = t.groups().getOrDefault(group, List.of());
            anyRows |= !lr.isEmpty() || !tr.isEmpty();
            List<FieldMapping> fields = groupFields(group, lr, tr, mapping);
            if (lr.size() != tr.size()) {
                ctx.diff(group + "[]", FieldDiff.Kind.ROW_COUNT, Integer.toString(lr.size()),
                        Integer.toString(tr.size()), null);
            }
            boolean declaredSet = groupRowsAsSet(group, mapping);   // a multiset by the recording: order means nothing
            if (spec.rowsAsSet(group) || declaredSet) {
                compareRowsAsSet(ctx, group, lr, tr, fields, declaredSet || spec.orderReportOnly());
            } else {
                compareRowsInOrder(ctx, group, lr, tr, fields);
            }
        }
        return anyRows;
    }

    /**
     * An ordered group whose rows are aligned before they are compared, beyond this many cell pairs (legacy rows x
     * target rows, after the common start and end) compared by position instead - the alignment's table would be
     * too large.
     */
    static final long ALIGN_LIMIT = 4_000_000L;

    /**
     * An ordered group. The rows are aligned first: the longest common subsequence of the rows equal under the profile
     * (every compared field after its normalization, an ignored field left out, a field one row lacks never equal), so
     * that a row one side lacks is <strong>one</strong> difference - {@link FieldDiff.Kind#ROW_MISSING_IN_TARGET} or
     * {@link FieldDiff.Kind#ROW_EXTRA_IN_TARGET} - and not a shift of every later row. Between two aligned rows the
     * rows left on both sides are paired in order and compared field by field (a changed row, named by its legacy
     * position as before); the rest are missing or extra. The order still counts: a row that moved is missing where the
     * legacy has it and extra where the target has it. A list where no row is missing or extra compares exactly as by
     * position; a side with no row at all is the row count's difference only (as before).
     */
    private void compareRowsInOrder(Context ctx, String group, List<Map<String, String>> lr,
                                    List<Map<String, String>> tr, List<FieldMapping> fields) {
        if (lr.isEmpty() || tr.isEmpty()) {
            return;                                         // one side has no row: the row count says it, once
        }
        List<int[]> matches = align(ctx, group, lr, tr, fields);
        if (matches == null) {                              // too large to align: by position, as before
            ctx.notes.add("rows of " + group + " compared by position (" + lr.size() + " x " + tr.size()
                    + " rows, too many to align)");
            for (int i = 0; i < Math.min(lr.size(), tr.size()); i++) {
                compareRow(ctx, group, lr.get(i), tr.get(i), i, fields);
            }
            return;
        }
        int width = (int) fields.stream().filter(f -> !ctx.profile.ignores(group, f.legacy())).count();
        int missing = 0;
        int extra = 0;
        List<String> missingKeys = new ArrayList<>();
        List<String> extraKeys = new ArrayList<>();
        int nextL = 0;
        int nextT = 0;
        List<int[]> walk = new ArrayList<>(matches);
        walk.add(new int[] {lr.size(), tr.size()});         // the end: what is left after the last aligned row
        for (int[] match : walk) {
            int gapL = match[0] - nextL;
            int gapT = match[1] - nextT;
            int paired = Math.min(gapL, gapT);
            for (int k = 0; k < paired; k++) {              // changed rows: field by field
                compareRow(ctx, group, lr.get(nextL + k), tr.get(nextT + k), nextL + k, fields);
            }
            for (int k = paired; k < gapL; k++) {
                int li = nextL + k;
                ctx.diffSigned(group + "[" + (li + 1) + "]", group + "[]", FieldDiff.Kind.ROW_MISSING_IN_TARGET,
                        ctx.rowText(group, lr.get(li), fields), null, null);
                ctx.compared += width;
                missing++;
                missingKeys.add(String.valueOf(ctx.rowKey(group, lr.get(li), fields)));
            }
            for (int k = paired; k < gapT; k++) {
                int ti = nextT + k;
                ctx.diffSigned(group + "[" + (ti + 1) + "]", group + "[]", FieldDiff.Kind.ROW_EXTRA_IN_TARGET,
                        null, ctx.rowText(group, tr.get(ti), fields), null);
                ctx.compared += width;
                extra++;
                extraKeys.add(String.valueOf(ctx.rowKey(group, tr.get(ti), fields)));
            }
            if (match[0] < lr.size()) {                      // an aligned row: equal, still compared field by field
                compareRow(ctx, group, lr.get(match[0]), tr.get(match[1]), match[0], fields);
            }
            nextL = match[0] + 1;
            nextT = match[1] + 1;
        }
        if (missing > 0 || extra > 0) {
            missingKeys.sort(null);
            extraKeys.sort(null);
            ctx.notes.add("rows of " + group + " aligned in order: " + missing + " missing in the target, " + extra
                    + " extra in the target (each one difference, not a shift of the rows after it)"
                    + (missingKeys.equals(extraKeys) ? "; they are the same rows in another order" : ""));
        }
    }

    /** One legacy row against one target row, field by field (rows named by the legacy position, from 1). */
    private static void compareRow(Context ctx, String group, Map<String, String> lrow, Map<String, String> trow,
                                   int legacyIndex, List<FieldMapping> fields) {
        for (FieldMapping f : fields) {
            if (ctx.profile.ignores(group, f.legacy())) {
                continue;
            }
            String key = group + "[" + (legacyIndex + 1) + "]." + f.legacy();
            String signatureKey = group + "[]." + f.legacy();
            if (!lrow.containsKey(f.legacy()) || !trow.containsKey(f.legacy())) {
                ctx.diffSigned(key, signatureKey, lrow.containsKey(f.legacy())
                                ? FieldDiff.Kind.MISSING_IN_TARGET : FieldDiff.Kind.MISSING_IN_LEGACY,
                        lrow.get(f.legacy()), trow.get(f.legacy()), null);
                continue;
            }
            ctx.compareValue(key, signatureKey, f, lrow.get(f.legacy()), trow.get(f.legacy()));
        }
    }

    /**
     * The aligned rows {@code [legacy index, target index]} in order - the common start and end, and between them the
     * longest common subsequence of equal rows (ties: a legacy row is passed over before a target row, so the result is
     * the same on every run) - or {@code null} when the middle is beyond {@link #ALIGN_LIMIT}.
     */
    private static List<int[]> align(Context ctx, String group, List<Map<String, String>> lr,
                                     List<Map<String, String>> tr, List<FieldMapping> fields) {
        List<List<String>> lk = lr.stream().map(r -> ctx.rowKey(group, r, fields)).toList();
        List<List<String>> tk = tr.stream().map(r -> ctx.rowKey(group, r, fields)).toList();
        int start = 0;
        while (start < lk.size() && start < tk.size() && lk.get(start).equals(tk.get(start))) {
            start++;
        }
        int endL = lk.size();
        int endT = tk.size();
        while (endL > start && endT > start && lk.get(endL - 1).equals(tk.get(endT - 1))) {
            endL--;
            endT--;
        }
        int a = endL - start;
        int b = endT - start;
        if ((long) a * b > ALIGN_LIMIT) {
            return null;
        }
        List<int[]> matches = new ArrayList<>();
        for (int i = 0; i < start; i++) {
            matches.add(new int[] {i, i});
        }
        if (a > 0 && b > 0) {
            int[] lcs = new int[(a + 1) * (b + 1)];         // lcs[i * (b + 1) + j]: LCS of lk[start+i..), tk[start+j..)
            for (int i = a - 1; i >= 0; i--) {
                for (int j = b - 1; j >= 0; j--) {
                    lcs[i * (b + 1) + j] = lk.get(start + i).equals(tk.get(start + j))
                            ? lcs[(i + 1) * (b + 1) + j + 1] + 1
                            : Math.max(lcs[(i + 1) * (b + 1) + j], lcs[i * (b + 1) + j + 1]);
                }
            }
            int i = 0;
            int j = 0;
            while (i < a && j < b) {
                if (lk.get(start + i).equals(tk.get(start + j))) {
                    matches.add(new int[] {start + i, start + j});
                    i++;
                    j++;
                } else if (lcs[(i + 1) * (b + 1) + j] >= lcs[i * (b + 1) + j + 1]) {
                    i++;
                } else {
                    j++;
                }
            }
        }
        for (int k = 0; k < lk.size() - endL; k++) {
            matches.add(new int[] {endL + k, endT + k});
        }
        return matches;
    }

    private void compareRowsAsSet(Context ctx, String group, List<Map<String, String>> lr,
                                  List<Map<String, String>> tr, List<FieldMapping> fields, boolean orderReportOnly) {
        List<List<String>> lt = lr.stream().map(r -> ctx.tuple(group, r, fields)).toList();
        List<List<String>> tt = tr.stream().map(r -> ctx.tuple(group, r, fields)).toList();
        Map<List<String>, Integer> remaining = new HashMap<>();
        tt.forEach(row -> remaining.merge(row, 1, Integer::sum));
        int matchedRows = 0;
        for (int i = 0; i < lt.size(); i++) {
            List<String> row = lt.get(i);
            Integer count = remaining.get(row);
            if (count != null && count > 0) {
                remaining.put(row, count - 1);
                matchedRows++;
            } else {
                ctx.diffSigned(group + "[" + (i + 1) + "]", group + "[]", FieldDiff.Kind.ROW_MISSING_IN_TARGET,
                        String.join("|", nullSafe(row)), null, null);
            }
        }
        for (int i = 0; i < tt.size(); i++) {
            List<String> row = tt.get(i);
            Integer count = remaining.get(row);
            if (count != null && count > 0) {
                remaining.put(row, count - 1);
                ctx.diffSigned(group + "[" + (i + 1) + "]", group + "[]", FieldDiff.Kind.ROW_EXTRA_IN_TARGET,
                        null, String.join("|", nullSafe(row)), null);
            }
        }
        int width = Math.max(1, fields.size());
        ctx.compared += Math.max(lt.size(), tt.size()) * width;
        ctx.matched += matchedRows * width;
        if (matchedRows == lt.size() && lt.size() == tt.size() && !lt.equals(tt)) {
            if (orderReportOnly) {
                ctx.notes.add("order of " + group + " differs (report-only, EC-04)");
            } else {
                ctx.diffSigned(group + "[]", group + "[]", FieldDiff.Kind.ORDER, "legacy order", "target order", null);
            }
        }
    }

    private static boolean isTableGroup(String group) {
        return group.startsWith(TableCheck.GROUP_PREFIX);
    }

    private static boolean groupRowsAsSet(String group, ViewMapping mapping) {
        return mapping.groups().stream().anyMatch(g -> g.name().equals(group) && g.rowsAsSet());
    }

    private static Set<String> groupNames(Observation l, Observation t, ViewMapping mapping) {
        Set<String> names = new LinkedHashSet<>();
        if (mapping.isIdentity()) {
            names.addAll(l.groups().keySet());
            names.addAll(t.groups().keySet());
        } else {
            mapping.groups().forEach(g -> names.add(g.name()));
        }
        return names;
    }

    private static List<FieldMapping> groupFields(String group, List<Map<String, String>> lr,
                                                  List<Map<String, String>> tr, ViewMapping mapping) {
        for (GroupMapping g : mapping.groups()) {
            if (g.name().equals(group)) {
                return g.fields().stream().filter(f -> f.target() != null).toList();
            }
        }
        Set<String> keys = new LinkedHashSet<>();
        lr.forEach(r -> keys.addAll(r.keySet()));
        tr.forEach(r -> keys.addAll(r.keySet()));
        return keys.stream().map(FieldMapping::of).toList();
    }

    private static boolean notBlank(String value) {
        return value != null && !value.isBlank();
    }

    private static boolean failed(Outcome outcome) {
        return outcome.kind() == Outcome.Kind.TECHNICAL_FAILURE || outcome.kind() == Outcome.Kind.NOT_RUN;
    }

    private static List<String> nullSafe(List<String> row) {
        return row.stream().map(v -> v == null ? "<null>" : v).toList();
    }

    /** Mutable state of one comparison. */
    private static final class Context {
        final String unit;
        final NormalizationProfile profile;
        final List<FieldDiff> diffs = new ArrayList<>();
        final List<String> notes = new ArrayList<>();
        int compared;
        int matched;

        Context(String unit, NormalizationProfile profile) {
            this.unit = unit;
            this.profile = profile;
        }

        void compareValue(String key, String signatureKey, FieldMapping field, String lv, String tv) {
            compared++;
            if (Objects.equals(profile.normalize(lv, field), profile.normalize(tv, field))) {
                matched++;
            } else {
                diffSigned(key, signatureKey, FieldDiff.Kind.VALUE, lv, tv, DiffPatterns.classify(lv, tv));
            }
        }

        /** A row as the alignment matches it: per compared field its normalized value, a field the row lacks marked. */
        List<String> rowKey(String group, Map<String, String> row, List<FieldMapping> fields) {
            List<String> values = new ArrayList<>();
            for (FieldMapping f : fields) {
                if (!profile.ignores(group, f.legacy())) {
                    String value = row.containsKey(f.legacy()) ? profile.normalize(row.get(f.legacy()), f) : null;
                    values.add(!row.containsKey(f.legacy()) ? "\u0000absent" : value == null ? "\u0000null" : "=" + value);
                }
            }
            return values;
        }

        /** A missing or extra row for people: its compared fields' values as answered, {@code |}-separated. */
        String rowText(String group, Map<String, String> row, List<FieldMapping> fields) {
            List<String> values = new ArrayList<>();
            for (FieldMapping f : fields) {
                if (!profile.ignores(group, f.legacy())) {
                    values.add(row.containsKey(f.legacy()) ? String.valueOf(row.get(f.legacy())) : "<absent>");
                }
            }
            return String.join("|", values);
        }

        List<String> tuple(String group, Map<String, String> row, List<FieldMapping> fields) {
            List<String> values = new ArrayList<>();
            for (FieldMapping f : fields) {
                if (!profile.ignores(group, f.legacy())) {
                    values.add(profile.normalize(row.get(f.legacy()), f));
                }
            }
            return values;
        }

        void diff(String field, FieldDiff.Kind kind, String legacy, String target, String pattern) {
            diffSigned(field, field, kind, legacy, target, pattern);
        }

        void diffSigned(String field, String signatureField, FieldDiff.Kind kind, String legacy, String target,
                        String pattern) {
            String signature = unit + "|" + signatureField + "|" + kind + (pattern == null ? "" : ":" + pattern);
            diffs.add(new FieldDiff(field, kind, legacy, target, pattern, signature));
        }
    }
}
