package com.insurance.e2e.core.scenario;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;

/**
 * How a scenario's observations are compared.
 *
 * @param profile     the profile that decides the verdict: {@code strict} or {@code contract} (both are always reported)
 * @param rows        {@code set} (multiset, as the ordering evidence dictates - EC-04) or {@code ordered}
 * @param order       with {@code rows=set}: {@code report-only} records an order difference as a note, {@code strict}
 *                    makes it a difference
 * @param expectEmpty the scenario deliberately expects no rows on either side; otherwise an empty-vs-empty
 *                    comparison is reported as vacuous (anti-vacuity guard)
 * @param mapping     id of the view mapping, overriding the level's
 * @param ignore      the answer's paths this scenario does not compare under the contract profile - a field
 *                    ({@code effectiveDate}) or every element's field of a list ({@code items[].selectChar}) - each with
 *                    the reason (the decision) it rests on; the strict profile still compares them
 * @param setPaths    the answer's lists compared as sets when not every list is ({@code rows} names them all): the
 *                    other lists, and the rows of a table check, keep their own order (a package's per-list
 *                    {@code compare} mode set)
 */
public record CompareSpec(String profile, String rows, String order, Boolean expectEmpty, String mapping,
                          List<Ignored> ignore, List<String> setPaths) {

    public static final String STRICT = "strict";
    public static final String CONTRACT = "contract";

    /** One path a scenario does not compare, and why. */
    public record Ignored(String path, String reason) {
    }

    @JsonCreator
    public CompareSpec {
        ignore = ignore == null ? List.of() : List.copyOf(ignore);
        setPaths = setPaths == null ? List.of() : List.copyOf(setPaths);
    }

    /** A comparison that compares every path. */
    public CompareSpec(String profile, String rows, String order, Boolean expectEmpty, String mapping) {
        this(profile, rows, order, expectEmpty, mapping, null, null);
    }

    /** A comparison with no list compared as a set on its own. */
    public CompareSpec(String profile, String rows, String order, Boolean expectEmpty, String mapping,
                       List<Ignored> ignore) {
        this(profile, rows, order, expectEmpty, mapping, ignore, null);
    }

    public static CompareSpec defaults() {
        return new CompareSpec(null, null, null, null, null);
    }

    public String effectiveProfile() {
        return profile == null || profile.isBlank() ? CONTRACT : profile;
    }

    /** Every list of the answer compared as a set ({@code rows=set}). */
    public boolean rowsAsSet() {
        return "set".equals(rows);
    }

    /** Whether the rows of one group (a list of the answer) are compared as a set: every list's are, or this one is named. */
    public boolean rowsAsSet(String group) {
        return rowsAsSet() || setPaths.contains(group);
    }

    public boolean orderReportOnly() {
        return "report-only".equals(order);
    }

    public boolean emptyExpected() {
        return Boolean.TRUE.equals(expectEmpty);
    }

    /** The paths not compared under the contract profile, in order. */
    @JsonIgnore
    public List<String> ignoredPaths() {
        return ignore.stream().map(Ignored::path).toList();
    }
}
