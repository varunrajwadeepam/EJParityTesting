package com.insurance.e2e.core.json;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.cfg.JsonNodeFeature;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.dataformat.yaml.YAMLMapper;
import com.insurance.e2e.core.E2eException;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * The single place that decides how framework files are read, written and hashed.
 *
 * <p>Hashes are computed over a <em>canonical</em> form - object keys sorted recursively, no whitespace - so that
 * re-indenting or re-ordering a golden master's keys never changes its identity, while any value change does.
 */
public final class JsonSupport {

    // Decimals stay exact: 1.50 is not 1.5 under the strict profile, so neither parsing (doubles) nor tree building
    // (Jackson strips BigDecimal trailing zeros by default) may change a reported value's scale.
    private static final ObjectMapper MAPPER = JsonMapper.builder()
            .enable(SerializationFeature.INDENT_OUTPUT)
            .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
            .enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)
            .disable(JsonNodeFeature.STRIP_TRAILING_BIGDECIMAL_ZEROES)
            .serializationInclusion(JsonInclude.Include.NON_NULL)
            .build();

    private static final ObjectMapper CANONICAL = JsonMapper.builder()
            .disable(SerializationFeature.INDENT_OUTPUT)
            .enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)
            .disable(JsonNodeFeature.STRIP_TRAILING_BIGDECIMAL_ZEROES)
            .serializationInclusion(JsonInclude.Include.NON_NULL)
            .build();

    private static final ObjectMapper YAML = YAMLMapper.builder()
            .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
            .build();

    private JsonSupport() {
    }

    /** Shared mapper for framework files: pretty output, nulls omitted from objects, unknown keys tolerated. */
    public static ObjectMapper mapper() {
        return MAPPER;
    }

    /** Mapper for the YAML descriptors of an MU module ({@code mu.yaml}, {@code phrasebook.yaml}). */
    public static ObjectMapper yamlMapper() {
        return YAML;
    }

    public static <T> T read(Path file, Class<T> type) {
        try {
            return MAPPER.readValue(file.toFile(), type);
        } catch (IOException e) {
            throw new E2eException("Cannot read " + file + " as " + type.getSimpleName(), e);
        }
    }

    public static JsonNode readTree(Path file) {
        try {
            return MAPPER.readTree(file.toFile());
        } catch (IOException e) {
            throw new E2eException("Cannot parse JSON " + file, e);
        }
    }

    public static void write(Path file, Object value) {
        try {
            Path parent = file.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            String text = MAPPER.writeValueAsString(value) + "\n";
            Files.writeString(file, text, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException("Cannot write " + file, e);
        }
    }

    public static String toJson(Object value) {
        try {
            return MAPPER.writeValueAsString(value);
        } catch (JsonProcessingException e) {
            throw new E2eException("Cannot serialize " + value.getClass().getSimpleName(), e);
        }
    }

    /** Canonical bytes: keys sorted recursively, compact, UTF-8. Basis of every content hash. */
    public static byte[] canonicalBytes(Object value) {
        JsonNode tree = value instanceof JsonNode node ? node : MAPPER.valueToTree(value);
        try {
            return CANONICAL.writeValueAsBytes(sortKeys(tree));
        } catch (JsonProcessingException e) {
            throw new E2eException("Cannot canonicalize value", e);
        }
    }

    public static String sha256Hex(byte[] data) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 is not available", e);
        }
    }

    public static String sha256Hex(Path file) {
        try {
            return sha256Hex(Files.readAllBytes(file));
        } catch (IOException e) {
            throw new UncheckedIOException("Cannot hash " + file, e);
        }
    }

    /** Hash of the canonical form of {@code value}. */
    public static String canonicalHash(Object value) {
        return sha256Hex(canonicalBytes(value));
    }

    static JsonNode sortKeys(JsonNode node) {
        if (node.isObject()) {
            List<String> names = new ArrayList<>();
            node.fieldNames().forEachRemaining(names::add);
            names.sort(String::compareTo);
            ObjectNode sorted = JsonNodeFactory.instance.objectNode();
            for (String name : names) {
                sorted.set(name, sortKeys(node.get(name)));
            }
            return sorted;
        }
        if (node.isArray()) {
            ArrayNode array = JsonNodeFactory.instance.arrayNode();
            for (Iterator<JsonNode> it = node.elements(); it.hasNext(); ) {
                array.add(sortKeys(it.next()));
            }
            return array;
        }
        return node;
    }

    /** Converts a JSON scalar to the string form used in observations; {@code null} for JSON null or missing. */
    public static String scalarText(JsonNode node) {
        if (node == null || node.isNull() || node.isMissingNode()) {
            return null;
        }
        if (node.isNumber()) {
            return node.decimalValue().toPlainString();
        }
        if (node.isValueNode()) {
            return node.asText();
        }
        return node.toString();
    }

    /** Immutable copy of a map that keeps insertion order and tolerates {@code null} values. */
    public static <V> Map<String, V> orderedCopy(Map<String, V> source) {
        if (source == null || source.isEmpty()) {
            return Map.of();
        }
        return java.util.Collections.unmodifiableMap(new java.util.LinkedHashMap<>(source));
    }
}
