package com.insurance.e2e.core.compare;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.json.JsonSupport;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * The view mappings of one MU module ({@code view-mappings/<id>.json}); the id is the file name without
 * extension and defaults to the legacy unit name.
 */
public final class MappingRepository {

    private final Map<String, ViewMapping> mappings;

    private MappingRepository(Map<String, ViewMapping> mappings) {
        this.mappings = mappings;
    }

    public static MappingRepository empty() {
        return new MappingRepository(Map.of());
    }

    public static MappingRepository load(Path dir) {
        Map<String, ViewMapping> found = new LinkedHashMap<>();
        if (dir != null && Files.isDirectory(dir)) {
            try (Stream<Path> files = Files.list(dir)) {
                for (Path file : files.filter(p -> p.toString().endsWith(".json")).sorted().toList()) {
                    String id = file.getFileName().toString().replaceFirst("\\.json$", "");
                    found.put(id, JsonSupport.read(file, ViewMapping.class));
                }
            } catch (IOException e) {
                throw new E2eException("Cannot list view mappings in " + dir, e);
            }
        }
        return new MappingRepository(found);
    }

    public Optional<ViewMapping> find(String id) {
        return Optional.ofNullable(mappings.get(id));
    }

    public Map<String, ViewMapping> all() {
        return Map.copyOf(mappings);
    }
}
