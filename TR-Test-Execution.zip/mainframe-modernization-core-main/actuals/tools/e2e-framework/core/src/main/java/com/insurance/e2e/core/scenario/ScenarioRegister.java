package com.insurance.e2e.core.scenario;

import java.util.List;

/**
 * A versioned scenario register file ({@code src/test/resources/e2e/scenarios/*.json} of an MU e2e module).
 *
 * @param schemaVersion register schema version, currently {@value #CURRENT_SCHEMA_VERSION}
 * @param mu            the migration unit the register belongs to
 * @param description   free text
 * @param generatedBy   the stage or script that wrote it (e.g. {@code e2e-design})
 * @param scenarios     the scenarios, in file order
 */
public record ScenarioRegister(String schemaVersion, String mu, String description, String generatedBy,
                               List<Scenario> scenarios) {

    public static final String CURRENT_SCHEMA_VERSION = "1.0";

    public ScenarioRegister {
        scenarios = scenarios == null ? List.of() : List.copyOf(scenarios);
    }
}
