package com.insurance.e2e.core.spi;

import java.util.Set;

/**
 * A plugin behind one extension point. Plugins are discovered with {@link java.util.ServiceLoader} (declare them in
 * {@code META-INF/services/com.insurance.e2e.core.spi.Plugin}) or registered explicitly, and need a public no-arg
 * constructor when discovered: configuration comes from the {@link ExecutionContext} at call time.
 *
 * <p>Keep the contract small and stable: technology-specific behaviour belongs inside the plugin.
 */
public interface Plugin {

    /** Stable id, e.g. {@code paritytester-trigger}. */
    String id();

    ExtensionPoint point();

    /**
     * The kinds this plugin serves: binding kinds ({@code LEG-SP}, {@code TGT-CMP}, ...) for trigger and capture,
     * observation kinds ({@code view-fields}) for compare, environment kinds ({@code jdbc}) for environment.
     */
    Set<String> kinds();

    /** Whether the plugin's service is reachable; unavailable means skip, never fail. */
    default Availability availability(ExecutionContext context) {
        return Availability.up();
    }
}
