package com.insurance.e2e.core.spi;

import com.insurance.e2e.core.compare.ViewMapping;
import com.insurance.e2e.core.scenario.BindingRef;
import com.insurance.e2e.core.scenario.Scenario;

import java.util.Map;

/** Extension point TRIGGER: starts the behaviour a scenario describes. */
public interface TriggerPlugin extends Plugin {

    @Override
    default ExtensionPoint point() {
        return ExtensionPoint.TRIGGER;
    }

    TriggerResult trigger(Request request);

    /**
     * @param mapping the unit's view mapping; a target trigger binds the scenario request through its
     *                {@code inputs}, a legacy trigger uses the request as it stands (legacy field names)
     */
    record Request(BindingRef binding, Scenario scenario, ViewMapping mapping, ExecutionContext context) {
    }

    /**
     * What the trigger got back.
     *
     * @param payload    the raw result (a runner report, a returned Java object, ...)
     * @param failure    the exception the target raised, if any (a business outcome is still a result)
     * @param provenance identity facts the trigger knows (source and driver hashes, ...) for golden masters
     */
    record TriggerResult(BindingRef binding, Object payload, Throwable failure, Map<String, String> provenance) {
        public TriggerResult {
            provenance = provenance == null ? Map.of() : Map.copyOf(provenance);
        }
    }
}
