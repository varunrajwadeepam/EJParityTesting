package com.insurance.e2e.core.compare;

import java.math.BigDecimal;

/**
 * Classifies a value difference so that representational differences cluster (padding, case, scale, truncation)
 * and stand apart from real value differences.
 */
public final class DiffPatterns {

    private DiffPatterns() {
    }

    public static String classify(String legacy, String target) {
        if (legacy == null || target == null) {
            String other = legacy == null ? target : legacy;
            return other == null || other.isBlank() ? "NULL_VS_BLANK" : "NULL_VS_VALUE";
        }
        String l = legacy.stripTrailing();
        String t = target.stripTrailing();
        if (l.equals(t)) {
            return "TRAILING_BLANKS";
        }
        if (legacy.strip().equals(target.strip())) {
            return "PADDING";
        }
        if (l.equalsIgnoreCase(t)) {
            return "CASE";
        }
        if (numericallyEqual(legacy, target)) {
            return "NUMERIC_SCALE";
        }
        if (l.isEmpty() != t.isEmpty()) {
            return "BLANK_VS_VALUE";
        }
        if (l.startsWith(t) || t.startsWith(l)) {
            return "TRUNCATION";
        }
        return "VALUE";
    }

    static boolean numericallyEqual(String a, String b) {
        try {
            return new BigDecimal(a.strip()).compareTo(new BigDecimal(b.strip())) == 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
