package com.insurance.e2e.core.junit;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.scenario.Scenario;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

/**
 * The register and the Behaviour Specification describe the same scenarios: every register scenario has exactly one
 * feature scenario, tagged {@code @<scenarioId>}, and every feature scenario names exactly one register scenario.
 * A plain reading of the {@code .feature} files (tags, scenario lines, doc strings) - the steps of each scenario are
 * checked against its register entry and golden master by the Behaviour Specification's glue.
 */
public final class FeatureCoverage {

    /** One scenario of a feature file with its effective tags (its own and those of its feature and rule). */
    public record FeatureScenario(Path file, int line, String keyword, String name, Set<String> tags) {
        String where() {
            return file.getFileName() + ":" + line;
        }
    }

    private static final List<String> SCENARIO_KEYWORDS = List.of("Scenario Outline:", "Scenario Template:",
            "Scenario:", "Example:");

    private FeatureCoverage() {
    }

    /** The problems, empty when the features and the register agree. */
    public static List<String> problems(Path featuresDir, Collection<Scenario> scenarios) {
        Set<String> ids = new LinkedHashSet<>();
        scenarios.forEach(s -> ids.add(s.scenarioId()));
        Map<String, List<FeatureScenario>> byId = new LinkedHashMap<>();
        ids.forEach(id -> byId.put(id, new ArrayList<>()));
        List<String> problems = new ArrayList<>();
        for (FeatureScenario feature : readAll(featuresDir)) {
            if (feature.keyword().startsWith("Scenario Outline") || feature.keyword().startsWith("Scenario Template")) {
                problems.add(feature.where() + " '" + feature.name() + "': a scenario outline - one feature scenario "
                        + "per register scenario, please");
                continue;
            }
            List<String> named = feature.tags().stream().filter(ids::contains).toList();
            if (named.isEmpty()) {
                problems.add(feature.where() + " '" + feature.name() + "' names no register scenario (tag it "
                        + "@<scenarioId>)");
            } else if (named.size() > 1) {
                problems.add(feature.where() + " '" + feature.name() + "' names several register scenarios " + named);
            } else {
                byId.get(named.get(0)).add(feature);
            }
        }
        byId.forEach((id, found) -> {
            if (found.isEmpty()) {
                problems.add(id + " has no feature scenario");
            } else if (found.size() > 1) {
                problems.add(id + " has " + found.size() + " feature scenarios ("
                        + String.join(", ", found.stream().map(FeatureScenario::where).toList()) + ")");
            }
        });
        return problems;
    }

    /** Every scenario of every {@code .feature} file under {@code dir}, files in name order. */
    public static List<FeatureScenario> readAll(Path dir) {
        if (!Files.isDirectory(dir)) {
            return List.of();
        }
        List<Path> files;
        try (Stream<Path> walk = Files.walk(dir)) {
            files = walk.filter(p -> p.getFileName().toString().endsWith(".feature") && Files.isRegularFile(p))
                    .sorted().toList();
        } catch (IOException e) {
            throw new E2eException("Cannot read " + dir, e);
        }
        List<FeatureScenario> all = new ArrayList<>();
        for (Path file : files) {
            try {
                all.addAll(read(file, Files.readAllLines(file, StandardCharsets.UTF_8)));
            } catch (IOException e) {
                throw new E2eException("Cannot read " + file, e);
            }
        }
        return all;
    }

    static List<FeatureScenario> read(Path file, List<String> lines) {
        List<FeatureScenario> scenarios = new ArrayList<>();
        Set<String> pending = new LinkedHashSet<>();
        Set<String> featureTags = Set.of();
        Set<String> ruleTags = Set.of();
        String docString = null;
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i).strip();
            if (docString != null) {
                if (line.startsWith(docString)) {
                    docString = null;
                }
                continue;
            }
            if (line.startsWith("\"\"\"") || line.startsWith("```")) {
                docString = line.substring(0, 3);
                continue;
            }
            if (line.isEmpty() || line.startsWith("#")) {
                continue;
            }
            if (line.startsWith("@")) {
                for (String token : line.split("\\s+")) {
                    if (token.startsWith("#")) {
                        break;
                    }
                    if (token.startsWith("@") && token.length() > 1) {
                        pending.add(token.substring(1));
                    }
                }
                continue;
            }
            if (line.startsWith("Feature:")) {
                featureTags = Set.copyOf(pending);
                ruleTags = Set.of();
                pending.clear();
            } else if (line.startsWith("Rule:")) {
                ruleTags = Set.copyOf(pending);
                pending.clear();
            } else if (line.startsWith("Background:") || line.startsWith("Examples:") || line.startsWith("Scenarios:")) {
                pending.clear();
            } else {
                for (String keyword : SCENARIO_KEYWORDS) {
                    if (line.startsWith(keyword)) {
                        Set<String> tags = new LinkedHashSet<>(featureTags);
                        tags.addAll(ruleTags);
                        tags.addAll(pending);
                        scenarios.add(new FeatureScenario(file, i + 1, keyword,
                                line.substring(keyword.length()).strip(), Set.copyOf(tags)));
                        pending.clear();
                        break;
                    }
                }
            }
        }
        return scenarios;
    }
}
