package com.insurance.e2e.core.spi;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ServiceLoader;

/** The plugins available to a run. Later registrations win over earlier ones for the same point and kind. */
public final class PluginRegistry {

    private final List<Plugin> plugins = new ArrayList<>();

    /** Every plugin declared through {@link ServiceLoader} on the given class loader. */
    public static PluginRegistry discover(ClassLoader loader) {
        PluginRegistry registry = new PluginRegistry();
        ServiceLoader.load(Plugin.class, loader).forEach(registry::register);
        return registry;
    }

    public static PluginRegistry discover() {
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        return discover(loader == null ? PluginRegistry.class.getClassLoader() : loader);
    }

    public PluginRegistry register(Plugin plugin) {
        plugins.add(plugin);
        return this;
    }

    public List<Plugin> all() {
        return List.copyOf(plugins);
    }

    public <T extends Plugin> Optional<T> find(Class<T> type, String kind) {
        for (int i = plugins.size() - 1; i >= 0; i--) {
            Plugin plugin = plugins.get(i);
            if (type.isInstance(plugin) && plugin.kinds().contains(kind)) {
                return Optional.of(type.cast(plugin));
            }
        }
        return Optional.empty();
    }

    public <T extends Plugin> T require(Class<T> type, ExtensionPoint point, String kind) {
        return find(type, kind).orElseThrow(() -> new MissingPluginException(point, kind));
    }

    public TriggerPlugin trigger(String kind) {
        return require(TriggerPlugin.class, ExtensionPoint.TRIGGER, kind);
    }

    public CapturePlugin capture(String kind) {
        return require(CapturePlugin.class, ExtensionPoint.CAPTURE, kind);
    }

    public ComparePlugin compare(String kind) {
        return require(ComparePlugin.class, ExtensionPoint.COMPARE, kind);
    }

    public EnvironmentPlugin environment(String kind) {
        return require(EnvironmentPlugin.class, ExtensionPoint.ENVIRONMENT, kind);
    }
}
