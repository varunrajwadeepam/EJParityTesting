package com.insurance.e2e.core.golden;

import com.insurance.e2e.core.json.JsonSupport;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TreeSet;

/**
 * Where a golden master came from. Every identity field is a value or a hash, so that staleness is
 * <em>computed</em> by comparing the stored provenance with the current one, never remembered.
 *
 * @param platform    {@code gnucobol-emulated} today; {@code mainframe} if recordings ever arrive
 * @param engine      legacy engine version (e.g. the parity-tester commit)
 * @param runnerImage runner image digest
 * @param gixsqlPatch SQL preprocessor version and patch level
 * @param shimTree    hash of the runtime shim tree
 * @param sources     legacy member name -> content hash
 * @param driver      hash of the generated driver
 * @param fixture     hash of the fixture pack the recording ran on (P15: the fixture is part of the oracle)
 * @param clock       pinned clock, e.g. {@code 20240816103000}
 * @param env         execution environment switches that affect behaviour
 * @param dbMode      {@code logic} or {@code platform-emulated}
 * @param recordedAt  when (not part of the identity)
 * @param repeatRuns  how many identical runs proved determinism (not part of the identity)
 */
public record Provenance(String platform, String engine, String runnerImage, String gixsqlPatch, String shimTree,
                         Map<String, String> sources, String driver, String fixture, String clock,
                         Map<String, String> env, String dbMode, String recordedAt, Integer repeatRuns) {

    public Provenance {
        sources = JsonSupport.orderedCopy(sources);
        env = JsonSupport.orderedCopy(env);
    }

    /**
     * Identity fields that differ between this (stored) provenance and {@code current}. A field unknown on either
     * side is not a change: a replay environment without the legacy engine cannot know the runner image, and that
     * must not make every golden master stale.
     */
    public List<String> changedFields(Provenance current) {
        List<String> changed = new ArrayList<>();
        compare(changed, "platform", platform, current.platform);
        compare(changed, "engine", engine, current.engine);
        compare(changed, "runnerImage", runnerImage, current.runnerImage);
        compare(changed, "gixsqlPatch", gixsqlPatch, current.gixsqlPatch);
        compare(changed, "shimTree", shimTree, current.shimTree);
        compareMap(changed, "sources", sources, current.sources);
        compare(changed, "driver", driver, current.driver);
        compare(changed, "fixture", fixture, current.fixture);
        compare(changed, "clock", clock, current.clock);
        compareMap(changed, "env", env, current.env);
        compare(changed, "dbMode", dbMode, current.dbMode);
        return changed;
    }

    private static void compare(List<String> changed, String name, String stored, String now) {
        if (stored != null && now != null && !stored.equals(now)) {
            changed.add(name);
        }
    }

    private static void compareMap(List<String> changed, String name, Map<String, String> stored,
                                   Map<String, String> now) {
        if (stored.isEmpty() || now.isEmpty()) {
            return;
        }
        TreeSet<String> keys = new TreeSet<>(stored.keySet());
        keys.addAll(now.keySet());
        for (String key : keys) {
            if (!Objects.equals(stored.get(key), now.get(key))) {
                changed.add(name + ":" + key);
            }
        }
    }
}
