package com.insurance.e2e.core.run;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.scenario.Scenario;
import com.insurance.e2e.core.scenario.TableCheck;
import com.insurance.e2e.core.spi.EnvironmentPlugin;
import com.insurance.e2e.core.spi.ExecutionContext;

import java.math.BigDecimal;
import java.util.Map;

/**
 * What a call left behind, added to the target's answer so that one comparison covers both (golden-master packages of
 * format 3): {@value #TABLES}{@code .<table>} - the rows of each table check, read on the validation database right
 * after the call - and {@value #EMPTY} - whether the answer had no body. The golden master carries the same keys
 * (written by the import), and the view mapping maps each table to the group {@code table:<table>}: the comparator
 * then counts and compares the rows like any list of the answer.
 */
public final class TableCapture {

    public static final String TABLES = "$tables";
    public static final String EMPTY = "$empty";
    /** Where a non-object answer goes when the state is added (the object then holds it). */
    public static final String BODY = "$body";

    private TableCapture() {
    }

    public static Observation augment(Observation target, Scenario scenario, EnvironmentPlugin environment,
                                      ExecutionContext context) {
        JsonNode payload = target.payload();
        boolean empty = payload == null || payload.isNull() || payload.isMissingNode()
                || (payload.isTextual() && payload.asText().isBlank());
        ObjectNode out;
        if (payload instanceof ObjectNode object) {
            out = object.deepCopy();
        } else {
            out = JsonNodeFactory.instance.objectNode();
            if (!empty) {
                out.set(BODY, payload);
            }
        }
        if (scenario.answerEmpty() != null) {
            out.put(EMPTY, empty);
        }
        if (!scenario.tables().isEmpty()) {
            ObjectNode tables = out.putObject(TABLES);
            for (TableCheck check : scenario.tables()) {
                ArrayNode rows = tables.putArray(check.name());
                for (Map<String, Object> row : environment.rows(check.query(), context)) {
                    ObjectNode element = rows.addObject();
                    row.forEach((column, value) -> element.set(column, node(value)));
                }
            }
        }
        return new Observation(target.form(), target.fields(), target.groups(), target.outcome(), out, target.meta());
    }

    static JsonNode node(Object value) {
        JsonNodeFactory nodes = JsonNodeFactory.instance;
        if (value == null) {
            return nodes.nullNode();
        }
        if (value instanceof BigDecimal decimal) {
            return nodes.numberNode(decimal);
        }
        if (value instanceof Long number) {
            return nodes.numberNode(number);
        }
        if (value instanceof Integer number) {
            return nodes.numberNode(number.longValue());
        }
        if (value instanceof Boolean flag) {
            return nodes.booleanNode(flag);
        }
        return nodes.textNode(value.toString());
    }
}
