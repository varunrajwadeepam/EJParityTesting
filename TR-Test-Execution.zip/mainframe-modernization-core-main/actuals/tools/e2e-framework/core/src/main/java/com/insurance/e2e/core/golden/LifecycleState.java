package com.insurance.e2e.core.golden;

/**
 * Lifecycle of a golden master.
 *
 * <pre>
 * (none) --record, N&gt;=2 identical runs--&gt; RECORDED --record gate: explained--&gt; ACCEPTED
 * RECORDED --unexplained / emulator suspected--&gt; DISPUTED
 * ACCEPTED --triage finds an engine defect--&gt; DISPUTED
 * RECORDED | ACCEPTED --provenance input changed--&gt; STALE
 * DISPUTED --resolved (needs re-recording)--&gt; STALE
 * STALE --re-record + diff old vs new--&gt; a NEW golden master in RECORDED
 * </pre>
 * Only {@link #ACCEPTED} golden masters support a verdict; {@link #DISPUTED} and {@link #STALE} block the scenario on
 * the legacy side.
 */
public enum LifecycleState {
    RECORDED,
    ACCEPTED,
    DISPUTED,
    STALE
}
