package com.insurance.e2e.core.run;

import com.insurance.e2e.core.compare.ComparisonResult;
import com.insurance.e2e.core.compare.FieldComparator;
import com.insurance.e2e.core.compare.FieldDiff;
import com.insurance.e2e.core.compare.MappingRepository;
import com.insurance.e2e.core.compare.NormalizationProfile;
import com.insurance.e2e.core.compare.ProfileSet;
import com.insurance.e2e.core.compare.ViewMapping;
import com.insurance.e2e.core.golden.GoldenMaster;
import com.insurance.e2e.core.golden.GoldenMasterStore;
import com.insurance.e2e.core.golden.Lifecycle;
import com.insurance.e2e.core.golden.LifecycleState;
import com.insurance.e2e.core.golden.Provenance;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.scenario.Assertion;
import com.insurance.e2e.core.scenario.BindingRef;
import com.insurance.e2e.core.scenario.CompareSpec;
import com.insurance.e2e.core.scenario.LevelBinding;
import com.insurance.e2e.core.scenario.Scenario;
import com.insurance.e2e.core.spi.Availability;
import com.insurance.e2e.core.spi.BlockedCall;
import com.insurance.e2e.core.spi.CapturePlugin;
import com.insurance.e2e.core.spi.ComparePlugin;
import com.insurance.e2e.core.spi.EnvironmentPlugin;
import com.insurance.e2e.core.spi.ExecutionContext;
import com.insurance.e2e.core.spi.ExtensionPoint;
import com.insurance.e2e.core.spi.MissingPluginException;
import com.insurance.e2e.core.spi.PluginRegistry;
import com.insurance.e2e.core.spi.TriggerPlugin;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Executes one scenario level in one mode by composing the four extension points. It decides nothing about
 * technology: every side effect goes through a plugin, and every refusal says why.
 *
 * <ul>
 *   <li>a missing plugin, mapping or golden master is {@code BLOCKED} (with its route-back) - never skipped;</li>
 *   <li>an unreachable service is {@code SKIPPED} with the reason;</li>
 *   <li>a scenario the register declares {@code not-applicable} or {@code blocked} is reported with its reason in every
 *       mode and never executed;</li>
 *   <li>only {@code accepted}, non-stale golden masters support a verdict; staleness is computed from provenance.</li>
 * </ul>
 */
public final class ScenarioRunner {

    /** The decision a compare.ignore reason names first: {@code PAR-C-07 (DEC-11): ...} -> {@code PAR-C-07}. */
    private static final Pattern DECISION = Pattern.compile("^\\s*([A-Z][A-Z0-9]*(?:-[A-Z0-9]+)+)");

    private final PluginRegistry registry;
    private final GoldenMasterStore goldens;
    private final MappingRepository mappings;
    private final ProfileSet profiles;
    private final ExecutionContext context;
    private final ProvenanceSource provenance;

    public ScenarioRunner(PluginRegistry registry, GoldenMasterStore goldens, MappingRepository mappings,
                          ProfileSet profiles, ExecutionContext context, ProvenanceSource provenance) {
        this.registry = registry;
        this.goldens = goldens;
        this.mappings = mappings;
        this.profiles = profiles;
        this.context = context;
        this.provenance = provenance;
    }

    public ScenarioReport run(E2eMode mode, Scenario scenario, LevelBinding level) {
        return dispatch(mode, scenario, level)
                .describedBy(level.effectiveLens(), scenario.title(), scenario.hypotheses());
    }

    private ScenarioReport dispatch(E2eMode mode, Scenario scenario, LevelBinding level) {
        if (scenario.isNotApplicable()) {
            return report(ScenarioReport.Status.NOT_APPLICABLE, scenario, level, mode,
                    "not applicable at the " + level.effectiveLens() + " lens: " + scenario.statusReason(), List.of());
        }
        if (scenario.isDeclaredBlocked()) {
            return report(ScenarioReport.Status.BLOCKED, scenario, level, mode,
                    "declared blocked: " + scenario.statusReason(), List.of());
        }
        try {
            return switch (mode) {
                case LINT -> lint(scenario, level);
                case REPLAY -> replay(scenario, level);
                case RECORD -> record(scenario, level);
                case LIVE -> live(scenario, level);
            };
        } catch (MissingPluginException e) {
            return report(ScenarioReport.Status.BLOCKED, scenario, level, mode, e.getMessage() + "; " + e.routeBack(),
                    List.of());
        } catch (BlockedCall e) {                // the call cannot be made as configured: never sent another way
            return report(ScenarioReport.Status.BLOCKED, scenario, level, mode,
                    e.getMessage() + (e.owner() == null ? "" : " (owner: " + e.owner() + ")"), List.of());
        } catch (Unavailable e) {
            return report(ScenarioReport.Status.SKIPPED, scenario, level, mode, e.getMessage(), List.of());
        }
    }

    ScenarioReport lint(Scenario scenario, LevelBinding level) {
        List<String> notes = new ArrayList<>();
        List<String> blockers = new ArrayList<>();
        requirePlugins(level.legacy(), blockers);
        if (level.target() == null) {
            notes.add("legacy-only level (no target binding yet)");
        } else {
            requirePlugins(level.target(), blockers);
            String mappingId = mappingId(scenario, level);
            if (mappings.find(mappingId).isEmpty()) {
                blockers.add("no view mapping '" + mappingId + "' (written by the design stage)");
            }
        }
        Optional<GoldenMaster> golden = goldens.find(level.legacyUnit(), scenario.scenarioId());
        if (golden.isPresent()) {
            List<String> problems = goldens.verify(goldens.pathFor(level.legacyUnit(), scenario.scenarioId()));
            if (!problems.isEmpty()) {
                return report(ScenarioReport.Status.FAILED, scenario, level, E2eMode.LINT,
                        "golden master integrity: " + String.join("; ", problems), notes);
            }
            notes.add("golden master " + golden.get().state());
        } else {
            notes.add("no golden master yet");
        }
        if (!blockers.isEmpty()) {
            return report(ScenarioReport.Status.BLOCKED, scenario, level, E2eMode.LINT, String.join("; ", blockers), notes);
        }
        return report(ScenarioReport.Status.PASSED, scenario, level, E2eMode.LINT, "lint ok", notes);
    }

    ScenarioReport replay(Scenario scenario, LevelBinding level) {
        if (level.target() == null) {
            return report(ScenarioReport.Status.BLOCKED, scenario, level, E2eMode.REPLAY,
                    "no target binding: nothing to replay (legacy-only level)", List.of());
        }
        Optional<ViewMapping> mapping = mappings.find(mappingId(scenario, level));
        if (mapping.isEmpty()) {
            return report(ScenarioReport.Status.BLOCKED, scenario, level, E2eMode.REPLAY,
                    "no view mapping '" + mappingId(scenario, level) + "'", List.of());
        }
        Optional<GoldenMaster> stored = goldens.find(level.legacyUnit(), scenario.scenarioId());
        if (stored.isEmpty()) {
            return report(ScenarioReport.Status.BLOCKED, scenario, level, E2eMode.REPLAY,
                    "no golden master for " + level.legacyUnit() + "/" + scenario.scenarioId() + " - record it first",
                    List.of());
        }
        GoldenMaster golden = stored.get();
        Provenance current = provenance.current(scenario, level, context);
        LifecycleState effective = Lifecycle.effectiveState(golden, current);
        if (effective != LifecycleState.ACCEPTED) {
            List<String> changed = golden.provenance().changedFields(current);
            return report(ScenarioReport.Status.BLOCKED, scenario, level, E2eMode.REPLAY,
                    "golden master is " + effective + (changed.isEmpty() ? "" : " (changed: " + changed + ")")
                            + "; only accepted golden masters support a verdict", List.of());
        }
        List<String> notes = new ArrayList<>();
        EnvironmentPlugin.FixtureState fixture = prepareFixture(scenario);
        if (fixture != null && golden.provenance().fixture() != null
                && !golden.provenance().fixture().equals(fixture.packHash())) {
            return report(ScenarioReport.Status.BLOCKED, scenario, level, E2eMode.REPLAY,
                    "fixture pack changed since recording (stale golden master)", List.of());
        }
        Observation target = execute(level.target(), scenario, mapping.get()).observation();
        if (scenario.checksState()) {
            try {
                target = TableCapture.augment(target, scenario, environment(), context);
            } catch (RuntimeException e) {
                return report(ScenarioReport.Status.BLOCKED, scenario, level, E2eMode.REPLAY,
                        "the table checks could not be read after the call: " + e.getMessage(), List.of());
            }
        }
        if (fixture != null && !Objects.equals(environment().stateHash(fixture.tables(), context), fixture.stateHash())) {
            notes.add("the scenario changed the table state of fixture " + fixture.fixture()
                    + "; the next scenario on it reloads it");
        }
        return compareBoth(scenario, level, E2eMode.REPLAY, mapping.get(), golden.observation(), target, notes);
    }

    ScenarioReport record(Scenario scenario, LevelBinding level) {
        List<String> notes = new ArrayList<>();
        Provenance current = provenance.current(scenario, level, context);
        Optional<GoldenMaster> existing = goldens.find(level.legacyUnit(), scenario.scenarioId());
        if (existing.isPresent()) {
            LifecycleState effective = Lifecycle.effectiveState(existing.get(), current);
            if (effective != LifecycleState.STALE) {
                return report(ScenarioReport.Status.PASSED, scenario, level, E2eMode.RECORD,
                        "kept: golden master is " + effective + " and its provenance is unchanged", notes);
            }
        }
        int repeat = Math.max(1, Integer.parseInt(context.property("e2e.record.repeat", "2")));
        ViewMapping identity = ViewMapping.identity(level.legacyUnit());
        List<Execution> runs = new ArrayList<>();
        EnvironmentPlugin.FixtureState fixture = null;
        for (int i = 0; i < repeat; i++) {
            fixture = prepareFixture(scenario);
            runs.add(execute(level.legacy(), scenario, identity));
        }
        Observation first = runs.get(0).observation();
        String firstHash = JsonSupport.canonicalHash(first);
        for (int i = 1; i < runs.size(); i++) {
            if (!JsonSupport.canonicalHash(runs.get(i).observation()).equals(firstHash)) {
                ComparisonResult diff = identityDiff(scenario, level, first, runs.get(i).observation());
                return report(ScenarioReport.Status.FAILED, scenario, level, E2eMode.RECORD,
                        "non-deterministic legacy result: run " + (i + 1) + " differs from run 1 (EQ-6): "
                                + summary(diff), notes);
            }
        }
        for (Assertion assertion : scenario.assertions()) {
            if (!assertion.holdsFor(first)) {
                notes.add("discrepancy (" + Objects.toString(assertion.source(), "assertion") + "): "
                        + assertion.field() + " expected '" + assertion.eq() + "' but the legacy reported '"
                        + first.fields().get(assertion.field()) + "'");
            }
        }
        Provenance recorded = merge(current, runs.get(0).result().provenance(), fixture, repeat);
        String by = context.property("e2e.recorded.by", "e2e-record");
        GoldenMaster next = GoldenMaster.recorded(scenario.scenarioId(), level.legacyUnit(), level.effectiveLevel(),
                level.effectiveLens(), scenario.request(), first, Map.of(), recorded, by, context.now(),
                existing.map(GoldenMaster::contentHash).orElse(null));
        if (existing.isPresent()) {
            GoldenMaster previous = existing.get();
            if (previous.state() != LifecycleState.STALE) {
                previous = Lifecycle.transition(previous, LifecycleState.STALE, by,
                        "provenance changed: " + previous.provenance().changedFields(current), null, context.now());
            }
            goldens.rerecord(previous, next);
            ComparisonResult diff = identityDiff(scenario, level, previous.observation(), first);
            notes.add("re-recorded, superseding " + previous.contentHash().substring(0, 12) + "; old vs new: "
                    + (diff.diffs().isEmpty() ? "identical report" : summary(diff)) + " -> triage");
        } else {
            goldens.writeNew(next);
        }
        return report(ScenarioReport.Status.RECORDED, scenario, level, E2eMode.RECORD,
                "recorded " + repeat + " identical run(s) as " + LifecycleState.RECORDED, notes);
    }

    ScenarioReport live(Scenario scenario, LevelBinding level) {
        if (level.target() == null) {
            return report(ScenarioReport.Status.BLOCKED, scenario, level, E2eMode.LIVE,
                    "no target binding: nothing to compare live (legacy-only level)", List.of());
        }
        Optional<ViewMapping> mapping = mappings.find(mappingId(scenario, level));
        if (mapping.isEmpty()) {
            return report(ScenarioReport.Status.BLOCKED, scenario, level, E2eMode.LIVE,
                    "no view mapping '" + mappingId(scenario, level) + "'", List.of());
        }
        if (scenario.checksState()) {
            return report(ScenarioReport.Status.BLOCKED, scenario, level, E2eMode.LIVE,
                    "table checks are compared with the recorded rows only (replay): the legacy leg writes to its own"
                            + " database", List.of());
        }
        EnvironmentPlugin.FixtureState before = prepareFixture(scenario);
        Observation legacy = execute(level.legacy(), scenario, mapping.get()).observation();
        EnvironmentPlugin.FixtureState again = prepareFixture(scenario);
        if (before != null && again != null && !Objects.equals(before.stateHash(), again.stateHash())) {
            return report(ScenarioReport.Status.BLOCKED, scenario, level, E2eMode.LIVE,
                    "table state differs between the legacy and the target leg; refusing to compare", List.of());
        }
        Observation target = execute(level.target(), scenario, mapping.get()).observation();
        return compareBoth(scenario, level, E2eMode.LIVE, mapping.get(), legacy, target, new ArrayList<>());
    }

    private ScenarioReport compareBoth(Scenario scenario, LevelBinding level, E2eMode mode, ViewMapping mapping,
                                       Observation legacy, Observation target, List<String> notes) {
        ComparePlugin comparator = registry.compare(ComparePlugin.VIEW_FIELDS);
        CompareSpec spec = scenario.compare();
        NormalizationProfile strictProfile = profiles.profile(CompareSpec.STRICT);
        NormalizationProfile contractProfile = ignoring(profiles.profile(CompareSpec.CONTRACT), spec);
        ComparisonResult strict = comparator.compare(new ComparePlugin.Request(scenario.scenarioId(),
                level.effectiveLevel(), legacy, target, mapping, strictProfile, spec));
        ComparisonResult contract = comparator.compare(new ComparePlugin.Request(scenario.scenarioId(),
                level.effectiveLevel(), legacy, target, mapping, contractProfile, spec));
        String verdictProfile = spec.effectiveProfile();
        ComparisonResult verdict = CompareSpec.STRICT.equals(verdictProfile) ? strict : contract;
        ScenarioReport.Status status = verdict.isMatch() ? ScenarioReport.Status.PASSED : ScenarioReport.Status.FAILED;
        String message = verdict.isMatch()
                ? "match under " + verdictProfile + " (strict: " + strict.status() + ")"
                : verdict.status() + " under " + verdictProfile + ": " + summary(verdict);
        notes.addAll(verdict.notes());
        ScenarioReport report = new ScenarioReport(scenario.scenarioId(), level.effectiveLevel(), level.legacyUnit(),
                mode.name(), status, message, strict, contract, verdictProfile, notes);
        return status == ScenarioReport.Status.PASSED ? report : report.answeredBy(target);    // for triage
    }

    /**
     * The contract profile with the paths a scenario does not compare ({@code compare.ignore}), each backed by the
     * decision its reason names first (e.g. {@code PAR-C-07}); the strict profile keeps comparing them.
     */
    static NormalizationProfile ignoring(NormalizationProfile contract, CompareSpec spec) {
        NormalizationProfile result = contract;
        for (CompareSpec.Ignored ignored : spec.ignore()) {
            result = result.ignoring(List.of(ignored.path()), decisionOf(ignored.reason()));
        }
        return result;
    }

    static String decisionOf(String reason) {
        Matcher found = DECISION.matcher(reason == null ? "" : reason);
        return found.find() ? found.group(1) : "compare.ignore";
    }

    private Execution execute(BindingRef binding, Scenario scenario, ViewMapping mapping) {
        TriggerPlugin trigger = registry.trigger(binding.kind());
        CapturePlugin capture = registry.capture(binding.kind());
        Availability availability = trigger.availability(context);
        if (!availability.available()) {
            throw new Unavailable(binding + ": " + availability.reason());
        }
        TriggerPlugin.TriggerResult result = trigger.trigger(new TriggerPlugin.Request(binding, scenario, mapping, context));
        Observation observation = capture.capture(new CapturePlugin.Request(binding, result, scenario, mapping, context));
        return new Execution(observation, result);
    }

    private EnvironmentPlugin.FixtureState prepareFixture(Scenario scenario) {
        if (scenario.fixture() == null) {
            return null;
        }
        EnvironmentPlugin environment = environment();
        Availability availability = environment.availability(context);
        if (!availability.available()) {
            throw new Unavailable("environment: " + availability.reason());
        }
        return environment.prepare(scenario, scenario.fixture(), context);
    }

    private EnvironmentPlugin environment() {
        return registry.environment(context.property("e2e.environment.kind", EnvironmentPlugin.JDBC));
    }

    private void requirePlugins(BindingRef binding, List<String> blockers) {
        if (registry.find(TriggerPlugin.class, binding.kind()).isEmpty()) {
            blockers.add(new MissingPluginException(ExtensionPoint.TRIGGER, binding.kind()).routeBack());
        }
        if (registry.find(CapturePlugin.class, binding.kind()).isEmpty()) {
            blockers.add(new MissingPluginException(ExtensionPoint.CAPTURE, binding.kind()).routeBack());
        }
    }

    private Provenance merge(Provenance current, Map<String, String> fromTrigger,
                             EnvironmentPlugin.FixtureState fixture, int repeat) {
        Map<String, String> sources = new LinkedHashMap<>(current.sources());
        fromTrigger.forEach((key, value) -> {
            if (key.startsWith("source:")) {
                sources.put(key.substring("source:".length()), value);
            }
        });
        return new Provenance(
                fromTrigger.getOrDefault("platform", current.platform()),
                fromTrigger.getOrDefault("engine", current.engine()),
                fromTrigger.getOrDefault("runnerImage", current.runnerImage()),
                fromTrigger.getOrDefault("gixsqlPatch", current.gixsqlPatch()),
                fromTrigger.getOrDefault("shimTree", current.shimTree()),
                sources,
                fromTrigger.getOrDefault("driver", current.driver()),
                fixture == null ? current.fixture() : fixture.packHash(),
                current.clock(),
                current.env(),
                current.dbMode(),
                context.now(),
                repeat);
    }

    private ComparisonResult identityDiff(Scenario scenario, LevelBinding level, Observation a, Observation b) {
        return new FieldComparator().compare(scenario.scenarioId(), level.effectiveLevel(), a, b,
                ViewMapping.identity(level.legacyUnit()), NormalizationProfile.strict(), CompareSpec.defaults());
    }

    private static String mappingId(Scenario scenario, LevelBinding level) {
        String fromSpec = scenario.compare().mapping();
        return fromSpec == null || fromSpec.isBlank() ? level.effectiveMapping() : fromSpec;
    }

    static String summary(ComparisonResult result) {
        if (result.diffs().isEmpty()) {
            return String.join("; ", result.notes());
        }
        StringBuilder text = new StringBuilder(result.diffs().size() + " difference(s): ");
        List<FieldDiff> shown = result.diffs().subList(0, Math.min(5, result.diffs().size()));
        for (int i = 0; i < shown.size(); i++) {
            if (i > 0) {
                text.append("; ");
            }
            text.append(shown.get(i).text());
        }
        if (result.diffs().size() > shown.size()) {
            text.append("; ...");
        }
        return text.toString();
    }

    private static ScenarioReport report(ScenarioReport.Status status, Scenario scenario, LevelBinding level,
                                         E2eMode mode, String message, List<String> notes) {
        return ScenarioReport.of(status, scenario.scenarioId(), level.effectiveLevel(), level.legacyUnit(), mode,
                message, notes);
    }

    private record Execution(Observation observation, TriggerPlugin.TriggerResult result) {
    }

    /** A service a plugin needs is down: the level is skipped with the reason. */
    private static final class Unavailable extends RuntimeException {
        Unavailable(String message) {
            super(message);
        }
    }
}
