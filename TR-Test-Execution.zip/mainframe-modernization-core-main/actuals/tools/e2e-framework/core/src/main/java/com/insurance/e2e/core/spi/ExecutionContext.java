package com.insurance.e2e.core.spi;

import java.time.Clock;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

/**
 * What a plugin may know about the run: configuration properties and shared objects (e.g. a Spring application
 * context). A property is looked up in the explicit properties, then the system properties, then the environment
 * ({@code e2e.db.url} -> {@code E2E_DB_URL}).
 */
public final class ExecutionContext {

    private final Map<String, String> properties;
    private final Map<String, Object> attributes;
    private final Map<String, String> environment;
    private final Clock clock;

    private ExecutionContext(Map<String, String> properties, Map<String, Object> attributes,
                             Map<String, String> environment, Clock clock) {
        this.properties = properties;
        this.attributes = attributes;
        this.environment = environment;
        this.clock = clock;
    }

    public static ExecutionContext fromSystem() {
        return builder().build();
    }

    public static Builder builder() {
        return new Builder();
    }

    public String property(String key) {
        String value = properties.get(key);
        if (value == null) {
            value = System.getProperty(key);
        }
        if (value == null) {
            value = environment.get(key.toUpperCase(Locale.ROOT).replace('.', '_').replace('-', '_'));
        }
        return value == null || value.isBlank() ? null : value;
    }

    public String property(String key, String defaultValue) {
        String value = property(key);
        return value == null ? defaultValue : value;
    }

    public <T> Optional<T> attribute(Class<T> type) {
        return attribute(type.getName(), type);
    }

    public <T> Optional<T> attribute(String key, Class<T> type) {
        Object value = attributes.get(key);
        return type.isInstance(value) ? Optional.of(type.cast(value)) : Optional.empty();
    }

    /** Stores a shared object for later plugins (e.g. a lazily booted application context). */
    public void putAttribute(String key, Object value) {
        attributes.put(key, value);
    }

    /** Current UTC time, second precision, ISO-8601 ({@code 2026-10-02T09:15:00Z}). */
    public String now() {
        return DateTimeFormatter.ISO_INSTANT.format(Instant.now(clock).truncatedTo(ChronoUnit.SECONDS));
    }

    public static final class Builder {
        private final Map<String, String> properties = new LinkedHashMap<>();
        private final Map<String, Object> attributes = new LinkedHashMap<>();
        private Map<String, String> environment = System.getenv();
        private Clock clock = Clock.systemUTC();

        public Builder property(String key, String value) {
            properties.put(key, value);
            return this;
        }

        public Builder properties(Map<String, String> values) {
            properties.putAll(values);
            return this;
        }

        public Builder attribute(String key, Object value) {
            attributes.put(key, value);
            return this;
        }

        /** Replaces the process environment (tests). */
        public Builder environment(Map<String, String> values) {
            environment = Map.copyOf(values);
            return this;
        }

        public Builder clock(Clock value) {
            clock = value;
            return this;
        }

        public ExecutionContext build() {
            return new ExecutionContext(Collections.unmodifiableMap(new LinkedHashMap<>(properties)),
                    Collections.synchronizedMap(new LinkedHashMap<>(attributes)), environment, clock);
        }
    }
}
