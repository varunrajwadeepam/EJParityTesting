package com.insurance.e2e.core.spi;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.scenario.Scenario;

import java.util.List;
import java.util.Map;

/**
 * Extension point ENVIRONMENT / FIXTURES: puts the environment into the exact state a scenario names, and proves
 * it. Both legs of a comparison must start from the same state (P15: the fixture is part of the oracle).
 */
public interface EnvironmentPlugin extends Plugin {

    /** The environment kind of the MVP JDBC binding. */
    String JDBC = "jdbc";

    @Override
    default ExtensionPoint point() {
        return ExtensionPoint.ENVIRONMENT;
    }

    /** Loads the named fixture; returns the pack hash and the resulting state hash of the tables it touches. */
    FixtureState prepare(Scenario scenario, String fixture, ExecutionContext context);

    /** Hash of the current content of {@code tables}. */
    String stateHash(List<String> tables, ExecutionContext context);

    /**
     * The rows a table check's query returns after the call, in query order, typed for comparison: text as stored
     * (trailing blanks kept), numbers as {@link java.math.BigDecimal} or {@link Long}, a date as {@code YYYY-MM-DD}, a
     * time stamp in ISO form, NULL as {@code null}. Column names as the query names them.
     */
    default List<Map<String, Object>> rows(String query, ExecutionContext context) {
        throw new E2eException("The environment binding " + id() + " cannot read tables: a scenario with table checks"
                + " needs a database environment (jdbc)");
    }

    /**
     * @param packHash  hash of the fixture pack files (identity of the oracle's input)
     * @param stateHash hash of the tables after loading (identity of the actual state)
     */
    record FixtureState(String fixture, String packHash, String stateHash, List<String> tables) {
        public FixtureState {
            tables = tables == null ? List.of() : List.copyOf(tables);
        }
    }
}
