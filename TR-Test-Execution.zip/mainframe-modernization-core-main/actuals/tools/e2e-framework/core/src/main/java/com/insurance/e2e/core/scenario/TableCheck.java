package com.insurance.e2e.core.scenario;

import java.util.List;

/**
 * One table check of a scenario: after the call, {@code query} is run on the validation database and its rows are
 * compared with the rows the legacy left (the golden master's {@code $tables.<name>}). An empty list of rows in the
 * golden master states that no row is expected.
 *
 * @param name    the table (the group name in the comparison: {@code table:<name>})
 * @param query   the SELECT: the columns, the predicate (if any), the order
 * @param columns the columns in query order
 * @param compare {@code ordered} (row by row, default) or {@code set} (as a multiset)
 */
public record TableCheck(String name, String query, List<String> columns, String compare) {

    public static final String ORDERED = "ordered";
    public static final String SET = "set";
    /** The prefix of a table's comparison group. */
    public static final String GROUP_PREFIX = "table:";

    public TableCheck {
        columns = columns == null ? List.of() : List.copyOf(columns);
        compare = compare == null || compare.isBlank() ? ORDERED : compare;
    }

    /** The comparison group of this table. */
    public String group() {
        return GROUP_PREFIX + name;
    }
}
