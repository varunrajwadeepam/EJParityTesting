package com.insurance.e2e.core.compare;

/** The normalization rules a {@code contract} profile may apply - each only when backed by a signed decision. */
public enum NormalizationRule {
    /** Ignore trailing blanks of text, code and date fields. */
    RTRIM,
    /** Treat a null value and an all-blank value as equal. */
    NULL_AS_BLANK,
    /** Compare numbers by value regardless of scale ({@code 1.50} = {@code 1.5}). */
    NUMERIC_SCALE_INSENSITIVE,
    /** Trim echo fields on both ends (padded input echoes). */
    TRIM_ECHO,
    /** Do not compare the listed fields (e.g. attribute bytes). */
    IGNORE_FIELDS,
    /**
     * When either side did not complete normally (an HTTP error status, a failure), compare the outcome - kind and
     * numeric exit state - only: an error body is generic and is not part of the contract.
     */
    OUTCOME_ONLY_ON_ERROR
}
