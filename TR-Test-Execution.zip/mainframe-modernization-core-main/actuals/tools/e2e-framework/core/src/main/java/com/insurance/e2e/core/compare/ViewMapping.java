package com.insurance.e2e.core.compare;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.JsonNode;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.observation.Outcome;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * The reviewed view mapping of one legacy unit: legacy view field to target field, with type, plus the fields that
 * exist on one side only. It projects both sides into one canonical form (legacy names, row groups) so that the
 * comparator never needs to know either side's representation.
 *
 * <p>{@code inputs} map the legacy request fields onto the target's request (dot paths; {@code argN} addresses the
 * N-th parameter of a multi-parameter method), so one scenario request drives both sides.
 *
 * <p>An <em>identity</em> mapping (no fields, no groups) compares the reported fields by name; it serves
 * legacy-against-legacy comparisons such as the determinism check and re-recording diffs.
 */
public record ViewMapping(String schemaVersion, String unit, String description, List<FieldMapping> inputs,
                          List<FieldMapping> fields, List<GroupMapping> groups, List<String> legacyOnly,
                          List<String> targetOnly, OutcomeMapping outcome) {

    /** Dot path that addresses the whole target result (e.g. a list returned by a repository). */
    public static final String ROOT = "$";

    public ViewMapping {
        inputs = inputs == null ? List.of() : List.copyOf(inputs);
        fields = fields == null ? List.of() : List.copyOf(fields);
        groups = groups == null ? List.of() : List.copyOf(groups);
        legacyOnly = legacyOnly == null ? List.of() : List.copyOf(legacyOnly);
        targetOnly = targetOnly == null ? List.of() : List.copyOf(targetOnly);
    }

    public static ViewMapping identity(String unit) {
        return new ViewMapping("1.0", unit, "identity", List.of(), List.of(), List.of(), List.of(), List.of(), null);
    }

    @JsonIgnore
    public boolean isIdentity() {
        return fields.isEmpty() && groups.isEmpty();
    }

    public Optional<FieldMapping> field(String legacyName) {
        return fields.stream().filter(f -> f.legacy().equals(legacyName)).findFirst();
    }

    /** Projects an observation of any form into the canonical form. */
    public Observation toCanonical(Observation observation) {
        return switch (observation.form()) {
            case CANONICAL -> observation;
            case RAW_LEGACY -> projectLegacy(observation);
            case TARGET_PAYLOAD -> projectTarget(observation);
        };
    }

    Observation projectLegacy(Observation raw) {
        Outcome outcome = raw.outcome();
        if (outcome.exitState() == null && this.outcome != null && this.outcome.legacyExitStateField() != null) {
            outcome = outcome.withExitState(parseLong(raw.fields().get(this.outcome.legacyExitStateField())));
        }
        if (isIdentity()) {
            return new Observation(Observation.Form.CANONICAL, raw.fields(), Map.of(), outcome, null, raw.meta());
        }
        Map<String, String> scalars = new LinkedHashMap<>();
        for (FieldMapping f : fields) {
            if (raw.fields().containsKey(f.legacy())) {
                scalars.put(f.legacy(), raw.fields().get(f.legacy()));
            }
        }
        Map<String, List<Map<String, String>>> rows = new LinkedHashMap<>();
        for (GroupMapping g : groups) {
            int count = legacyRowCount(raw, g);
            List<Map<String, String>> list = new ArrayList<>();
            for (int i = 1; i <= count; i++) {
                Map<String, String> row = new LinkedHashMap<>();
                for (FieldMapping f : g.fields()) {
                    String key = Observation.occurrenceKey(f.legacy(), i);
                    if (raw.fields().containsKey(key)) {
                        row.put(f.legacy(), raw.fields().get(key));
                    }
                }
                list.add(row);
            }
            rows.put(g.name(), list);
        }
        return new Observation(Observation.Form.CANONICAL, scalars, rows, outcome, null, raw.meta());
    }

    Observation projectTarget(Observation targetObservation) {
        JsonNode payload = targetObservation.payload();
        Outcome outcome = targetObservation.outcome();
        if (this.outcome != null && this.outcome.targetExitStatePath() != null && outcome.exitState() == null) {
            outcome = outcome.withExitState(parseLong(JsonSupport.scalarText(at(payload, this.outcome.targetExitStatePath()))));
        }
        Map<String, String> scalars = new LinkedHashMap<>();
        Map<String, List<Map<String, String>>> rows = new LinkedHashMap<>();
        if (payload == null || payload.isNull() || payload.isMissingNode()) {
            return new Observation(Observation.Form.CANONICAL, scalars, rows, outcome, payload, targetObservation.meta());
        }
        if (isIdentity()) {
            for (Iterator<Map.Entry<String, JsonNode>> it = payload.fields(); it.hasNext(); ) {
                Map.Entry<String, JsonNode> e = it.next();
                if (e.getValue().isValueNode()) {
                    scalars.put(e.getKey(), JsonSupport.scalarText(e.getValue()));
                }
            }
        }
        for (FieldMapping f : fields) {
            if (f.target() == null) {
                continue;
            }
            JsonNode node = at(payload, f.target());
            if (!node.isMissingNode()) {
                scalars.put(f.legacy(), JsonSupport.scalarText(node));
            }
        }
        for (GroupMapping g : groups) {
            JsonNode list = at(payload, g.target());
            List<Map<String, String>> out = new ArrayList<>();
            if (list.isArray()) {
                for (JsonNode element : list) {
                    Map<String, String> row = new LinkedHashMap<>();
                    for (FieldMapping f : g.fields()) {
                        JsonNode node = f.target() == null ? null : at(element, f.target());
                        if (node != null && !node.isMissingNode()) {
                            row.put(f.legacy(), JsonSupport.scalarText(node));
                        }
                    }
                    out.add(row);
                }
            }
            rows.put(g.name(), out);
        }
        return new Observation(Observation.Form.CANONICAL, scalars, rows, outcome, payload, targetObservation.meta());
    }

    private static int legacyRowCount(Observation raw, GroupMapping g) {
        if (g.legacyCount() != null) {
            Long count = parseLong(raw.fields().get(g.legacyCount()));
            if (count != null) {
                return count.intValue();
            }
        }
        int max = 0;
        for (String key : raw.fields().keySet()) {
            Map.Entry<String, Integer> occ = Observation.parseOccurrenceKey(key);
            if (occ != null && g.fields().stream().anyMatch(f -> f.legacy().equals(occ.getKey()))) {
                max = Math.max(max, occ.getValue());
            }
        }
        return max;
    }

    /** The node at a dot path; {@value #ROOT} or an empty path is the node itself. */
    public static JsonNode at(JsonNode node, String dotPath) {
        if (node == null) {
            return com.fasterxml.jackson.databind.node.MissingNode.getInstance();
        }
        if (dotPath == null || dotPath.isEmpty() || ROOT.equals(dotPath)) {
            return node;
        }
        return node.at("/" + dotPath.replace('.', '/'));
    }

    static Long parseLong(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        try {
            return Long.parseLong(value.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
