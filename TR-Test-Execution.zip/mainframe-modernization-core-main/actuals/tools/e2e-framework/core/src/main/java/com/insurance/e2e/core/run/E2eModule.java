package com.insurance.e2e.core.run;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.compare.MappingRepository;
import com.insurance.e2e.core.compare.ProfileSet;
import com.insurance.e2e.core.golden.GoldenMasterStore;
import com.insurance.e2e.core.mu.MuDescriptor;
import com.insurance.e2e.core.report.ReportWriter;
import com.insurance.e2e.core.report.RunReport;
import com.insurance.e2e.core.scenario.RegisterLoader;
import com.insurance.e2e.core.scenario.Scenario;
import com.insurance.e2e.core.scenario.ScenarioRegister;
import com.insurance.e2e.core.spi.ExecutionContext;
import com.insurance.e2e.core.spi.PluginRegistry;

import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

/**
 * An MU e2e module's executable assets, loaded once for a run, with the {@link ScenarioRunner} over them. Both runners
 * use it - the register-driven tests ({@code E2eScenarioTests}, which lint) and the Behaviour Specification (the
 * Cucumber glue, which executes) - so a scenario, its golden master and its report are the same whichever side reads
 * them.
 *
 * <p>Layout under the resource root: {@code scenarios/*.json}, {@code view-mappings/*.json}, {@code profiles.json},
 * {@code golden/<unit>/<scenarioId>.json}, {@code features/*.feature}, {@code mu.yaml}. Record mode writes golden
 * masters into the module's sources ({@code src/test/resources/<root>/golden}); every other mode reads the copy the
 * run has.
 */
public final class E2eModule {

    public static final String MODULE_DIR_PROPERTY = "e2e.module.dir";
    /** Execution-context attribute (a {@link Path}) naming the module's e2e resource root, for plugins. */
    public static final String RESOURCES_DIR_ATTRIBUTE = "e2e.resources.dir";
    public static final String FEATURES_DIR = "features";

    private final String resourceRoot;
    private final Path resources;
    private final Path moduleDir;
    private final E2eMode mode;
    private final ExecutionContext context;
    private final String mu;
    private final List<ScenarioRegister> registers;
    private final GoldenMasterStore goldens;
    private final ScenarioRunner runner;

    private E2eModule(String resourceRoot, Path resources, Path moduleDir, E2eMode mode, ExecutionContext context,
                      String mu, List<ScenarioRegister> registers, GoldenMasterStore goldens, ScenarioRunner runner) {
        this.resourceRoot = resourceRoot;
        this.resources = resources;
        this.moduleDir = moduleDir;
        this.mode = mode;
        this.context = context;
        this.mu = mu;
        this.registers = registers;
        this.goldens = goldens;
        this.runner = runner;
    }

    /**
     * Loads the module whose resources are {@code resources}; {@code null} arguments take their defaults: the module
     * directory from {@value #MODULE_DIR_PROPERTY} (else the working directory), the mode from {@code -De2e.mode},
     * the plugins from the classpath, the context from the system.
     */
    public static E2eModule load(String resourceRoot, Path resources, Path moduleDir, E2eMode mode,
                                 PluginRegistry registry, ExecutionContext context) {
        ExecutionContext ctx = context == null ? ExecutionContext.fromSystem() : context;
        E2eMode runMode = mode == null ? E2eMode.parse(ctx.property(E2eMode.PROPERTY)) : mode;
        Path module = moduleDir != null ? moduleDir
                : Paths.get(ctx.property(MODULE_DIR_PROPERTY, System.getProperty("user.dir")));
        ctx.putAttribute(RESOURCES_DIR_ATTRIBUTE, resources);
        MuDescriptor descriptor = MuDescriptor.loadIfPresent(resources.resolve("mu.yaml"));
        List<ScenarioRegister> registers = new RegisterLoader().readDirectory(resources.resolve("scenarios"));
        MappingRepository mappings = MappingRepository.load(resources.resolve("view-mappings"));
        ProfileSet profiles = ProfileSet.load(resources.resolve("profiles.json"));
        Path goldenRoot = runMode == E2eMode.RECORD
                ? module.resolve("src").resolve("test").resolve("resources").resolve(resourceRoot).resolve("golden")
                : resources.resolve("golden");
        GoldenMasterStore store = new GoldenMasterStore(goldenRoot);
        ScenarioRunner runner = new ScenarioRunner(registry == null ? PluginRegistry.discover() : registry, store,
                mappings, profiles, ctx, ProvenanceSource.fromContext());
        String mu = descriptor != null && descriptor.mu() != null ? descriptor.mu()
                : registers.stream().map(ScenarioRegister::mu).findFirst().orElse(resourceRoot);
        return new E2eModule(resourceRoot, resources, module, runMode, ctx, mu, List.copyOf(registers), store, runner);
    }

    public String resourceRoot() {
        return resourceRoot;
    }

    public Path resources() {
        return resources;
    }

    public Path moduleDir() {
        return moduleDir;
    }

    public E2eMode mode() {
        return mode;
    }

    public ExecutionContext context() {
        return context;
    }

    public String mu() {
        return mu;
    }

    public List<ScenarioRegister> registers() {
        return registers;
    }

    public GoldenMasterStore goldens() {
        return goldens;
    }

    public ScenarioRunner runner() {
        return runner;
    }

    public Path featuresDir() {
        return resources.resolve(FEATURES_DIR);
    }

    /** Every scenario of every register, in register order. */
    public List<Scenario> scenarios() {
        List<Scenario> all = new ArrayList<>();
        registers.forEach(r -> all.addAll(r.scenarios()));
        return all;
    }

    public Optional<Scenario> scenario(String scenarioId) {
        return scenarios().stream().filter(s -> s.scenarioId().equals(scenarioId)).findFirst();
    }

    /**
     * Writes the run report {@code target/e2e-reports/<root>-<mode>.json} and {@code .md}, the scenarios in register
     * order whichever order they ran in.
     */
    public RunReport writeReport(E2eMode reportMode, String startedAt, List<ScenarioReport> reports) {
        Map<String, Integer> order = new HashMap<>();
        List<Scenario> all = scenarios();
        for (int i = 0; i < all.size(); i++) {
            order.putIfAbsent(all.get(i).scenarioId(), i);
        }
        List<ScenarioReport> sorted = new ArrayList<>(reports);
        sorted.sort(Comparator.comparingInt(r -> order.getOrDefault(r.scenarioId(), Integer.MAX_VALUE)));
        RunReport report = RunReport.of(mu, reportMode.name(), startedAt, context.now(), sorted);
        Path dir = moduleDir.resolve("target").resolve("e2e-reports");
        String base = resourceRoot + "-" + reportMode.name().toLowerCase(Locale.ROOT);
        ReportWriter.writeJson(report, dir.resolve(base + ".json"));
        ReportWriter.writeMarkdown(report, dir.resolve(base + ".md"));
        return report;
    }

    /** A classpath resource directory as a path; {@code null} when absent. */
    public static Path classpathDir(String resource) {
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        URL url = (loader == null ? E2eModule.class.getClassLoader() : loader).getResource(resource);
        if (url == null) {
            return null;
        }
        if (!"file".equals(url.getProtocol())) {
            throw new E2eException("E2E resources must be on the file system (got " + url + "); run from the module");
        }
        try {
            return Paths.get(url.toURI());
        } catch (URISyntaxException e) {
            throw new E2eException("Cannot resolve " + url, e);
        }
    }

    /** Whether {@code dir} holds at least one {@code .feature} file (at any depth). */
    public static boolean hasFeatures(Path dir) {
        if (!Files.isDirectory(dir)) {
            return false;
        }
        try (var walk = Files.walk(dir)) {
            return walk.anyMatch(p -> p.getFileName().toString().endsWith(".feature") && Files.isRegularFile(p));
        } catch (java.io.IOException e) {
            throw new E2eException("Cannot read " + dir, e);
        }
    }
}
