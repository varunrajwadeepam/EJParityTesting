package com.insurance.e2e.core.scenario;

import com.fasterxml.jackson.databind.JsonNode;
import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.json.Schemas;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Reads scenario registers and refuses invalid ones with <em>every</em> problem listed: JSON-schema violations
 * first, then the semantic rules the schema cannot express (unique scenario IDs within and across files).
 */
public final class RegisterLoader {

    public ScenarioRegister read(Path file) {
        try (InputStream in = Files.newInputStream(file)) {
            return read(file.toString(), in);
        } catch (IOException e) {
            throw new E2eException("Cannot read register " + file, e);
        }
    }

    public ScenarioRegister read(String sourceName, InputStream in) {
        JsonNode tree;
        try {
            tree = JsonSupport.mapper().readTree(in);
        } catch (IOException e) {
            throw new E2eException("Register " + sourceName + " is not valid JSON", List.of(e.getMessage()), e);
        }
        List<String> problems = new ArrayList<>(validate(tree));
        if (!problems.isEmpty()) {
            throw new E2eException("Register " + sourceName + " is invalid", problems);
        }
        ScenarioRegister register;
        try {
            register = JsonSupport.mapper().treeToValue(tree, ScenarioRegister.class);
        } catch (IOException | RuntimeException e) {
            throw new E2eException("Register " + sourceName + " cannot be bound", List.of(String.valueOf(e.getMessage())), e);
        }
        problems.addAll(duplicateIds(register, new HashMap<>(), sourceName));
        if (!problems.isEmpty()) {
            throw new E2eException("Register " + sourceName + " is invalid", problems);
        }
        return register;
    }

    /** Schema validation only; empty when the document conforms. */
    public List<String> validate(JsonNode document) {
        return Schemas.validate(Schemas.SCENARIO_REGISTER, document);
    }

    /**
     * Every {@code *.json} register in {@code dir} (sorted by file name). A missing directory is an empty module, not
     * an error: an MU e2e module exists before {@code design} writes its first register.
     */
    public List<ScenarioRegister> readDirectory(Path dir) {
        if (dir == null || !Files.isDirectory(dir)) {
            return List.of();
        }
        List<Path> files;
        try (Stream<Path> listing = Files.list(dir)) {
            files = listing.filter(p -> p.getFileName().toString().endsWith(".json")).sorted().toList();
        } catch (IOException e) {
            throw new E2eException("Cannot list registers in " + dir, e);
        }
        List<ScenarioRegister> registers = new ArrayList<>();
        Map<String, String> seen = new HashMap<>();
        List<String> problems = new ArrayList<>();
        for (Path file : files) {
            ScenarioRegister register = read(file);
            problems.addAll(duplicateIds(register, seen, file.getFileName().toString()));
            registers.add(register);
        }
        if (!problems.isEmpty()) {
            throw new E2eException("Scenario IDs are not unique across the registers in " + dir, problems);
        }
        return registers;
    }

    /** Records every ID of {@code register} in {@code owners} (id -> source) and reports any ID seen before. */
    private static List<String> duplicateIds(ScenarioRegister register, Map<String, String> owners, String source) {
        List<String> problems = new ArrayList<>();
        Set<String> local = new HashSet<>();
        for (Scenario scenario : register.scenarios()) {
            String id = scenario.scenarioId();
            if (!local.add(id)) {
                problems.add("duplicate scenarioId '" + id + "' in " + source);
            } else if (owners.containsKey(id)) {
                problems.add("scenarioId '" + id + "' in " + source + " is already defined in " + owners.get(id));
            } else {
                owners.put(id, source);
            }
        }
        return problems;
    }
}
