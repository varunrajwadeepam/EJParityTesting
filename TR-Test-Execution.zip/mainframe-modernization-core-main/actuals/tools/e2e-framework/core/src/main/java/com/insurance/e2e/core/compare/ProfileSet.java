package com.insurance.e2e.core.compare;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.scenario.CompareSpec;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The profiles of one MU ({@code profiles.json}). Both {@code strict} and {@code contract} always exist; a missing
 * file means no rule has been signed yet, so {@code contract} behaves like {@code strict}.
 *
 * <p>Refused: a {@code strict} profile with rules, and any {@code contract} rule without a decision ID - contract
 * normalization is only ever what a decision authority signed.
 */
public record ProfileSet(String schemaVersion, List<NormalizationProfile> profiles) {

    public ProfileSet {
        profiles = profiles == null ? List.of() : List.copyOf(profiles);
    }

    public static ProfileSet defaults() {
        return new ProfileSet("1.0", List.of(NormalizationProfile.strict(), NormalizationProfile.unsignedContract()));
    }

    /** Loads {@code file}; returns {@link #defaults()} when it does not exist. */
    public static ProfileSet load(Path file) {
        if (file == null || !Files.isRegularFile(file)) {
            return defaults();
        }
        ProfileSet set = JsonSupport.read(file, ProfileSet.class);
        List<String> problems = set.problems();
        if (!problems.isEmpty()) {
            throw new E2eException("Profiles " + file + " are invalid", problems);
        }
        return set;
    }

    public List<String> problems() {
        List<String> problems = new ArrayList<>();
        for (NormalizationProfile profile : profiles) {
            if (CompareSpec.STRICT.equals(profile.name()) && !profile.rules().isEmpty()) {
                problems.add("the strict profile must not carry normalization rules");
            }
            for (NormalizationProfile.RuleBinding rule : profile.rules()) {
                if (rule.rule() == null) {
                    problems.add("profile " + profile.name() + ": a rule has no name");
                } else if (rule.decision() == null || rule.decision().isBlank()) {
                    problems.add("profile " + profile.name() + ": rule " + rule.rule() + " is not backed by a decision ID");
                }
            }
        }
        return problems;
    }

    /** The named profile; {@code strict} and {@code contract} fall back to their defaults when not declared. */
    public NormalizationProfile profile(String name) {
        Map<String, NormalizationProfile> byName = new LinkedHashMap<>();
        byName.put(CompareSpec.STRICT, NormalizationProfile.strict());
        byName.put(CompareSpec.CONTRACT, NormalizationProfile.unsignedContract());
        profiles.forEach(p -> byName.put(p.name(), p));
        NormalizationProfile profile = byName.get(name);
        if (profile == null) {
            throw new E2eException("Unknown normalization profile '" + name + "'");
        }
        return profile;
    }
}
