package com.insurance.e2e.core.compare;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * One reviewed pairing of a legacy view field with a target field.
 *
 * @param legacy the legacy field name as reported (canonical name in comparisons)
 * @param target dot path into the target result ({@code responseCode}, {@code header.userId}); inside a group,
 *               relative to the group element; {@code null} when the field exists on the legacy side only
 * @param type   comparison type, default {@link FieldType#STRING}
 * @param echo   the field echoes an input (e.g. padded descriptor echo); {@code TRIM_ECHO} applies to it
 * @param note   why the pairing is what it is (the mapping encodes decisions, so it is reviewed)
 */
public record FieldMapping(String legacy, String target, FieldType type, Boolean echo, String note) {

    public FieldMapping {
        type = type == null ? FieldType.STRING : type;
    }

    public static FieldMapping of(String legacy) {
        return new FieldMapping(legacy, legacy, FieldType.STRING, false, null);
    }

    @JsonIgnore
    public boolean isEcho() {
        return Boolean.TRUE.equals(echo);
    }
}
