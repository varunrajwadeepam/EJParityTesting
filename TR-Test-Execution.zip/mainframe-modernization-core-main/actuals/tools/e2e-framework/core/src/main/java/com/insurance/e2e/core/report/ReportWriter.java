package com.insurance.e2e.core.report;

import com.insurance.e2e.core.compare.ComparisonResult;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.run.ScenarioReport;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

/** Writes a run report as JSON (the machine record, e.g. {@code comparison.json}) and as a Markdown summary. */
public final class ReportWriter {

    /** Characters of the target's answer shown in the Markdown summary. */
    private static final int EXCERPT = 160;

    private ReportWriter() {
    }

    public static void writeJson(RunReport report, Path file) {
        JsonSupport.write(file, report);
    }

    public static void writeMarkdown(RunReport report, Path file) {
        try {
            Files.createDirectories(file.toAbsolutePath().getParent());
            Files.writeString(file, markdown(report), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException("Cannot write " + file, e);
        }
    }

    public static String markdown(RunReport report) {
        StringBuilder md = new StringBuilder();
        md.append("# E2E run report - ").append(report.mu()).append(" (").append(report.mode()).append(")\n\n");
        md.append("Started ").append(report.startedAt()).append(", finished ").append(report.finishedAt()).append(".\n\n");
        md.append("| Status | Levels |\n|---|---|\n");
        report.counts().forEach((status, count) -> md.append("| ").append(status).append(" | ").append(count).append(" |\n"));
        md.append("\n| Scenario | Level | Lens | Unit | Status | strict | contract | Message |\n|---|---|---|---|---|---|---|---|\n");
        Map<String, TreeSet<String>> clusters = new TreeMap<>();
        for (ScenarioReport s : report.scenarios()) {
            md.append("| ").append(s.scenarioId()).append(" | ").append(s.level()).append(" | ")
                    .append(s.lens() == null ? "-" : s.lens()).append(" | ").append(s.unit())
                    .append(" | ").append(s.status()).append(" | ").append(status(s.strict()))
                    .append(" | ").append(status(s.contract())).append(" | ").append(escape(s.message())).append(" |\n");
            ComparisonResult verdict = "strict".equals(s.verdictProfile()) ? s.strict() : s.contract();
            if (verdict != null) {
                verdict.signatures().forEach(sig -> clusters.computeIfAbsent(sig, k -> new TreeSet<>()).add(s.scenarioId()));
            }
        }
        if (!clusters.isEmpty()) {
            md.append("\n## Difference signatures (one root cause, one row)\n\n| Signature | Scenarios |\n|---|---|\n");
            clusters.forEach((sig, ids) -> md.append("| `").append(sig).append("` | ").append(String.join(", ", ids)).append(" |\n"));
        }
        section(md, report, ScenarioReport.Status.FAILED, "Failed - with the hypotheses the scenario carries",
                "Hypotheses are anticipated differences from reading the code; they explain nothing until triage confirms them.");
        section(md, report, ScenarioReport.Status.BLOCKED, "Blocked - with the reason", null);
        section(md, report, ScenarioReport.Status.NOT_APPLICABLE, "Not applicable - never executed, never counted", null);
        return md.toString();
    }

    private static void section(StringBuilder md, RunReport report, ScenarioReport.Status status, String heading,
                                String intro) {
        List<ScenarioReport> rows = report.scenarios().stream().filter(s -> s.status() == status).toList();
        if (rows.isEmpty()) {
            return;
        }
        md.append("\n## ").append(heading).append("\n\n");
        if (intro != null) {
            md.append(intro).append("\n\n");
        }
        boolean failed = status == ScenarioReport.Status.FAILED;
        md.append(failed ? "| Scenario | Title | Hypotheses | Target answered |\n|---|---|---|---|\n"
                : "| Scenario | Title | Reason |\n|---|---|---|\n");
        for (ScenarioReport s : rows) {
            String detail = failed ? (s.hypotheses().isEmpty() ? "-" : String.join("; ", s.hypotheses())) : s.message();
            md.append("| ").append(s.scenarioId()).append(" | ").append(escape(s.title() == null ? "" : s.title()))
                    .append(" | ").append(escape(detail));
            if (failed) {
                md.append(" | ").append(escape(answer(s.target())));
            }
            md.append(" |\n");
        }
    }

    /** The outcome and the start of the answer; the full answer (up to its limit) is in the JSON report. */
    static String answer(ScenarioReport.TargetAnswer target) {
        if (target == null) {
            return "-";
        }
        StringBuilder text = new StringBuilder(target.outcome().kind().name());
        if (target.outcome().exitState() != null) {
            text.append(' ').append(target.outcome().exitState());
        }
        String payload = target.payload();
        if (payload != null) {
            text.append(": ").append(payload.length() > EXCERPT ? payload.substring(0, EXCERPT) + "..." : payload);
        }
        return text.toString();
    }

    private static String status(ComparisonResult result) {
        return result == null ? "-" : result.status().name();
    }

    private static String escape(String text) {
        return text == null ? "" : text.replace("|", "\\|").replace("\n", " ");
    }
}
