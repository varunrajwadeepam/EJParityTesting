package com.insurance.e2e.core.scenario;

import com.fasterxml.jackson.annotation.JsonCreator;

import java.util.List;

/**
 * A scenario whose expected answer the architecture decides - a decided parity register row (a golden-master
 * package's {@code decidedAnswer}): the golden master holds the decided status, not the one the legacy recording gives,
 * and the recording stays its evidence. Such a scenario is an <em>accepted deviation</em>: it is compared with the
 * decided answer like any other with its golden master, and reported apart from the scenarios equal to the legacy.
 * Descriptive in the run - the golden master is the oracle; the Behaviour Specification states the decision and the
 * framework checks that statement.
 *
 * @param source         the register row that decides the answer ({@code PAR-510-05})
 * @param status         the decided HTTP status (the golden master's)
 * @param recordedStatus the status the legacy recording gives, {@code null} when it gives none
 * @param register       where the row is ({@code parity/p510.md:46}), if stated
 * @param required       the row's requirement, verbatim, if stated
 * @param tables         {@code recorded} (the rows after the call are the recording's) or {@code notCompared}
 * @param rules          the package rules that applied the row
 */
public record DecidedAnswer(String source, Integer status, Integer recordedStatus, String register, String required,
                            String tables, List<String> rules) {

    @JsonCreator
    public DecidedAnswer {
        rules = rules == null ? List.of() : List.copyOf(rules);
    }
}
