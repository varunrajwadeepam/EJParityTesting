package com.insurance.e2e.core;

import java.util.List;

/**
 * Base unchecked exception of the framework. Carries an optional list of problems so that one failure
 * can report every violation found (e.g. all schema errors of a register), not just the first.
 */
public class E2eException extends RuntimeException {

    private final List<String> problems;

    public E2eException(String message) {
        this(message, List.of(), null);
    }

    public E2eException(String message, Throwable cause) {
        this(message, List.of(), cause);
    }

    public E2eException(String message, List<String> problems) {
        this(message, problems, null);
    }

    public E2eException(String message, List<String> problems, Throwable cause) {
        super(problems == null || problems.isEmpty() ? message : message + ": " + String.join("; ", problems), cause);
        this.problems = problems == null ? List.of() : List.copyOf(problems);
    }

    /** Every individual problem behind this exception; empty when the message says it all. */
    public List<String> problems() {
        return problems;
    }
}
