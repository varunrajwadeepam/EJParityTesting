package com.insurance.e2e.core.observation;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.JsonNode;
import com.insurance.e2e.core.json.JsonSupport;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * What one side reported for one execution.
 *
 * <p>Three forms exist, so that each side can be captured completely and projected only at comparison time:
 * <ul>
 *   <li>{@link Form#RAW_LEGACY} - every reported field, occurrence fields flattened as {@code NAME(001)}, exactly
 *       as the legacy driver prints them. This is what a golden master stores: the complete export view, not an
 *       asserted subset.</li>
 *   <li>{@link Form#TARGET_PAYLOAD} - the target's raw result as a JSON tree in {@code payload}.</li>
 *   <li>{@link Form#CANONICAL} - projected through a view mapping into canonical field names and row groups;
 *       the only form the comparator compares.</li>
 * </ul>
 * Values are strings; {@code null} means "reported as null" (SQL NULL on the target side), which is different from
 * "not reported" (key absent).
 */
public record Observation(Form form, Map<String, String> fields, Map<String, List<Map<String, String>>> groups,
                          Outcome outcome, JsonNode payload, Map<String, String> meta) {

    public enum Form { RAW_LEGACY, TARGET_PAYLOAD, CANONICAL }

    private static final Pattern OCCURRENCE = Pattern.compile("^(.+)\\((\\d+)\\)$");

    public Observation {
        form = form == null ? Form.CANONICAL : form;
        fields = JsonSupport.orderedCopy(fields);
        groups = copyGroups(groups);
        outcome = outcome == null ? Outcome.ok() : outcome;
        meta = JsonSupport.orderedCopy(meta);
    }

    public static Observation rawLegacy(Map<String, String> fields, Outcome outcome) {
        return new Observation(Form.RAW_LEGACY, fields, Map.of(), outcome, null, Map.of());
    }

    public static Observation targetPayload(JsonNode payload, Outcome outcome) {
        return new Observation(Form.TARGET_PAYLOAD, Map.of(), Map.of(), outcome, payload, Map.of());
    }

    public static Observation canonical(Map<String, String> fields, Map<String, List<Map<String, String>>> groups,
                                        Outcome outcome) {
        return new Observation(Form.CANONICAL, fields, groups, outcome, null, Map.of());
    }

    public Observation withMeta(Map<String, String> extra) {
        Map<String, String> merged = new LinkedHashMap<>(meta);
        merged.putAll(extra);
        return new Observation(form, fields, groups, outcome, payload, merged);
    }

    /** Occurrence key as the legacy driver prints it: {@code NAME(001)}. */
    public static String occurrenceKey(String field, int occurrence) {
        return field + "(" + (occurrence < 1000 ? String.format("%03d", occurrence) : Integer.toString(occurrence)) + ")";
    }

    /** Splits {@code NAME(001)} into the base name and the occurrence; {@code null} when not an occurrence key. */
    public static Map.Entry<String, Integer> parseOccurrenceKey(String key) {
        Matcher m = OCCURRENCE.matcher(key);
        return m.matches() ? Map.entry(m.group(1), Integer.parseInt(m.group(2))) : null;
    }

    /** {@code true} when no field carries a non-blank value and every group is empty. */
    @JsonIgnore
    public boolean isEmpty() {
        boolean blankFields = fields.values().stream().allMatch(v -> v == null || v.isBlank());
        boolean noRows = groups.values().stream().allMatch(List::isEmpty);
        return blankFields && noRows && (payload == null || payload.isNull() || payload.isEmpty());
    }

    private static Map<String, List<Map<String, String>>> copyGroups(Map<String, List<Map<String, String>>> source) {
        if (source == null || source.isEmpty()) {
            return Map.of();
        }
        Map<String, List<Map<String, String>>> copy = new LinkedHashMap<>();
        source.forEach((name, rows) -> {
            List<Map<String, String>> rowCopies = new ArrayList<>();
            if (rows != null) {
                rows.forEach(row -> rowCopies.add(JsonSupport.orderedCopy(row)));
            }
            copy.put(name, Collections.unmodifiableList(rowCopies));
        });
        return Collections.unmodifiableMap(copy);
    }
}
