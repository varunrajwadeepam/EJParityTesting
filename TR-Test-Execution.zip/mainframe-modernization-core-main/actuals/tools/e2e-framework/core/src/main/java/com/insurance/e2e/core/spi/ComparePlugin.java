package com.insurance.e2e.core.spi;

import com.insurance.e2e.core.compare.ComparisonResult;
import com.insurance.e2e.core.compare.NormalizationProfile;
import com.insurance.e2e.core.compare.ViewMapping;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.scenario.CompareSpec;

/** Extension point COMPARE: compares the two observations of one scenario level under one profile. */
public interface ComparePlugin extends Plugin {

    /** The observation kind of the MVP field comparator. */
    String VIEW_FIELDS = "view-fields";

    @Override
    default ExtensionPoint point() {
        return ExtensionPoint.COMPARE;
    }

    ComparisonResult compare(Request request);

    record Request(String scenarioId, String level, Observation legacy, Observation target, ViewMapping mapping,
                   NormalizationProfile profile, CompareSpec spec) {
    }
}
