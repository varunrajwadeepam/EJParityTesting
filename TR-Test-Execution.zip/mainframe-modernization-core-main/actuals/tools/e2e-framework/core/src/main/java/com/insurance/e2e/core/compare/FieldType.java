package com.insurance.e2e.core.compare;

/** How a mapped field's values are compared. */
public enum FieldType {
    /** Text compared character by character (padding significant under {@code strict}). */
    STRING,
    /** A code value; compared like {@link #STRING}. */
    CODE,
    /** Descriptive text; compared like {@link #STRING}. */
    TEXT,
    /** A date or timestamp in its reported form; compared like {@link #STRING}. */
    DATE,
    /** A number, compared by value; scale differences count only under {@code strict}. */
    NUMBER
}
