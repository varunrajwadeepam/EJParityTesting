package com.insurance.e2e.core.spi;

import com.insurance.e2e.core.compare.ViewMapping;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.scenario.BindingRef;
import com.insurance.e2e.core.scenario.Scenario;

/**
 * Extension point CAPTURE: turns what a trigger produced (or what the environment now holds) into an
 * {@link Observation}. Legacy captures return the complete raw report; target captures may project through the
 * mapping.
 */
public interface CapturePlugin extends Plugin {

    @Override
    default ExtensionPoint point() {
        return ExtensionPoint.CAPTURE;
    }

    Observation capture(Request request);

    record Request(BindingRef binding, TriggerPlugin.TriggerResult result, Scenario scenario, ViewMapping mapping,
                   ExecutionContext context) {
    }
}
