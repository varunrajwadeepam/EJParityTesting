package com.insurance.e2e.core.run;

import com.insurance.e2e.core.E2eException;

import java.util.Locale;

/**
 * Run modes, selected by the e2e parent's Maven profiles through the {@code e2e.mode} system property.
 *
 * <ul>
 *   <li>{@link #LINT} (default profile) - registers, mappings, golden-master integrity and plugin availability;
 *       no services needed;</li>
 *   <li>{@link #REPLAY} ({@code e2e-replay}) - the target against accepted golden masters, on their fixtures;</li>
 *   <li>{@link #RECORD} ({@code e2e-record}) - the legacy side through the engine, writing golden masters;</li>
 *   <li>{@link #LIVE} ({@code e2e-live}) - both sides back to back on the same rows.</li>
 * </ul>
 */
public enum E2eMode {
    LINT,
    REPLAY,
    RECORD,
    LIVE;

    public static final String PROPERTY = "e2e.mode";

    public static E2eMode parse(String value) {
        if (value == null || value.isBlank()) {
            return LINT;
        }
        String normalized = value.trim().toUpperCase(Locale.ROOT).replace("E2E-", "");
        if ("EXECUTE".equals(normalized)) {
            return REPLAY;
        }
        try {
            return valueOf(normalized);
        } catch (IllegalArgumentException e) {
            throw new E2eException("Unknown e2e.mode '" + value + "' (lint, replay, record, live)");
        }
    }
}
