package com.insurance.e2e.core.compare;

import java.util.List;

/**
 * A repeating group: legacy occurrence fields ({@code NAME(001)}, {@code NAME(002)}, ...) paired with a target list.
 *
 * @param name        canonical group name used in reports
 * @param target      dot path of the target list
 * @param legacyCount legacy field holding the number of valid occurrences; when absent, the highest reported
 *                    occurrence of the group's fields is used
 * @param fields      member fields; {@code legacy} is the base name without occurrence, {@code target} is relative
 *                    to a list element
 * @param rows        {@code set} to compare this group's rows as a multiset whatever the scenario says (a table check
 *                    the recording declares unordered); {@code null} or {@code ordered}: the scenario decides
 */
public record GroupMapping(String name, String target, String legacyCount, List<FieldMapping> fields, String rows) {

    public GroupMapping {
        fields = fields == null ? List.of() : List.copyOf(fields);
    }

    public GroupMapping(String name, String target, String legacyCount, List<FieldMapping> fields) {
        this(name, target, legacyCount, fields, null);
    }

    public boolean rowsAsSet() {
        return "set".equals(rows);
    }
}
