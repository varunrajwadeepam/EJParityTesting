package com.insurance.e2e.core.scenario;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.insurance.e2e.core.E2eException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A binding reference {@code KIND:REF}, e.g. {@code LEG-SP:DEMO0001} or {@code TGT-CMP:LookupRepository.findCodes}.
 *
 * <p>The kind selects the plugin (trigger + capture) that executes the binding; the ref is opaque to the core and
 * interpreted by that plugin. Kinds starting with {@code LEG} are legacy-side, everything else is target-side.
 */
public record BindingRef(String kind, String ref) {

    private static final Pattern FORM = Pattern.compile("^([A-Z]+(?:-[A-Z]+)*):(\\S+)$");

    public BindingRef {
        if (kind == null || kind.isBlank() || ref == null || ref.isBlank()) {
            throw new E2eException("Binding reference needs a kind and a ref, got '" + kind + ":" + ref + "'");
        }
    }

    @JsonCreator
    public static BindingRef parse(String text) {
        Matcher m = FORM.matcher(text == null ? "" : text.trim());
        if (!m.matches()) {
            throw new E2eException("Not a binding reference (KIND:REF): '" + text + "'");
        }
        return new BindingRef(m.group(1), m.group(2));
    }

    public boolean isLegacy() {
        return kind.startsWith("LEG");
    }

    /** {@code true} for service-point level kinds ({@code *-SP}, {@code *-HTTP}). */
    public boolean isServicePoint() {
        return kind.endsWith("-SP") || kind.endsWith("-HTTP");
    }

    @JsonValue
    @Override
    public String toString() {
        return kind + ":" + ref;
    }
}
