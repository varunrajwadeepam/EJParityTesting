package com.insurance.e2e.core.spi;

/**
 * Whether a plugin's service is reachable right now. An unavailable service makes the affected tests
 * <em>skip</em> (with the reason), never fail - the {@code requireAvailable()} pattern.
 */
public record Availability(boolean available, String reason) {

    public static Availability up() {
        return new Availability(true, null);
    }

    public static Availability down(String reason) {
        return new Availability(false, reason);
    }
}
