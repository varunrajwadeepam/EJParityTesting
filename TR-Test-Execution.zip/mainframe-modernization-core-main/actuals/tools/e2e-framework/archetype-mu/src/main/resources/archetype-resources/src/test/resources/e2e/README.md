# E2E resources of ${muName}

Written only by ${muName}'s E2E-VALIDATE stages; the generated test classes read them.

| Path | Written by | Content |
|---|---|---|
| `mu.yaml` | scope, design | MU id, service point, legacy units (engine names), target units, plugin kinds |
| `scenarios/*.json` | design | scenario register (schema 1.1; no expected values; HTTP requests, declared N/A and blocked statuses, hypotheses) |
| `view-mappings/<unit>.json` | design | legacy view field (or API response field) to Java field, inputs, outcome catalogue (reviewed) |
| `profiles.json` | design, record gate | `strict` / `contract` normalization rules, each backed by a decision ID |
| `fixtures/manifest.json`, `fixtures/*.sql`, `fixtures/schema/*.sql` | fixtures | delete-then-insert packs and their hashes; the table definitions of the E2E-owned schema |
| `golden/<unit>/<scenarioId>.json` | record (imported: design; accepted: record gate) | golden masters: full report, provenance, origin, lifecycle (never edited) |
| `rules/<unit>.json` | design | the behaviour rules a package states, with the cases that prove each |
| `features/<unit>.feature` | design (`e2e_package import`; reviewed by the design agent, named at the record gate) | Behaviour Specification: one scenario per register scenario, executed through the same runner; every step checked against the register and the golden master |
| `phrasebook.yaml` | - | business phrases to requests and checks (not used yet) |

Levels follow the strategy's pyramid: emulated functional parity is `L4`, seen through a lens - `service` (the API or
service point against the legacy service point) or `component`. Select with `-De2e.scenarios` (ids) and `-De2e.tags`,
e.g. `lens:service & category:Edge` - both test classes apply them; the module's `README.md` has the exact commands.
