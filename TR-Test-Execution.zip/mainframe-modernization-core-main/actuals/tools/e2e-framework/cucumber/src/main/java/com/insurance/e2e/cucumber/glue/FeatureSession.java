package com.insurance.e2e.cucumber.glue;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.run.E2eMode;
import com.insurance.e2e.core.run.E2eModule;
import com.insurance.e2e.core.run.ScenarioReport;
import com.insurance.e2e.core.scenario.LevelBinding;
import com.insurance.e2e.core.scenario.Scenario;
import com.insurance.e2e.core.spi.ExecutionContext;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The e2e modules the features of this JVM belong to - each loaded once, as {@link E2eModule} (the same assets and
 * {@link com.insurance.e2e.core.run.ScenarioRunner} the register-driven tests use) - and the reports their scenarios
 * produced. A feature belongs to the resource root that holds its {@code features/} folder.
 *
 * <p>The mode is {@code -De2e.mode}: {@code lint} (the default profile) only checks the steps against the register
 * and the golden masters; every other mode executes the scenarios, and {@link #finishAll()} writes the module's run
 * report {@code target/e2e-reports/<root>-<mode>.json} / {@code .md} - the evidence the execute stage reads.
 */
final class FeatureSession {

    private static final Map<Path, FeatureSession> SESSIONS = new LinkedHashMap<>();

    private final E2eModule module;
    private final String startedAt;
    private final List<ScenarioReport> reports = new ArrayList<>();

    private FeatureSession(E2eModule module) {
        this.module = module;
        this.startedAt = module.context().now();
    }

    /** The session of the module a feature file belongs to. */
    static synchronized FeatureSession forFeature(URI feature) {
        Path resources = resourcesOf(feature);
        return SESSIONS.computeIfAbsent(resources, r -> new FeatureSession(E2eModule.load(
                r.getFileName().toString(), r, null, null, null, ExecutionContext.fromSystem())));
    }

    /** Writes the run report of every module that executed scenarios, and forgets the sessions. */
    static synchronized void finishAll() {
        try {
            for (FeatureSession session : SESSIONS.values()) {
                if (session.executes() && !session.reports.isEmpty()) {
                    session.module.writeReport(session.module.mode(), session.startedAt, List.copyOf(session.reports));
                }
            }
        } finally {
            SESSIONS.clear();
        }
    }

    E2eModule module() {
        return module;
    }

    E2eMode mode() {
        return module.mode();
    }

    boolean executes() {
        return module.mode() != E2eMode.LINT;
    }

    /** Runs every level of the scenario in the session's mode; the reports join the run report. */
    synchronized List<ScenarioReport> run(Scenario scenario) {
        List<ScenarioReport> levels = new ArrayList<>();
        for (LevelBinding level : scenario.levels()) {
            levels.add(module.runner().run(module.mode(), scenario, level));
        }
        reports.addAll(levels);
        return levels;
    }

    /** {@code .../<root>/features/<any depth>/x.feature} -> {@code .../<root>}. */
    static Path resourcesOf(URI feature) {
        Path file = toPath(feature);
        for (Path dir = file.getParent(); dir != null; dir = dir.getParent()) {
            if (dir.getFileName() != null && E2eModule.FEATURES_DIR.equals(dir.getFileName().toString())
                    && dir.getParent() != null) {
                return dir.getParent();
            }
        }
        throw new E2eException("Feature " + feature + " is not under a " + E2eModule.FEATURES_DIR
                + "/ folder of an e2e resource root (e.g. src/test/resources/e2e/features/)");
    }

    private static Path toPath(URI feature) {
        try {
            if ("classpath".equals(feature.getScheme())) {
                String resource = feature.getSchemeSpecificPart().replaceFirst("^/+", "");
                ClassLoader loader = Thread.currentThread().getContextClassLoader();
                URL url = (loader == null ? FeatureSession.class.getClassLoader() : loader).getResource(resource);
                if (url == null || !"file".equals(url.getProtocol())) {
                    throw new E2eException("Feature " + feature + " is not a file on the test classpath (got " + url
                            + "); run from the module");
                }
                return Paths.get(url.toURI());
            }
            return Paths.get(feature);
        } catch (URISyntaxException | IllegalArgumentException e) {
            throw new E2eException("Cannot resolve the feature " + feature, e);
        }
    }
}
