package com.insurance.e2e.cucumber.glue;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import com.insurance.e2e.core.compare.ComparisonResult;
import com.insurance.e2e.core.compare.FieldDiff;
import com.insurance.e2e.core.golden.GoldenMaster;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.run.ScenarioReport;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The whole of a failed scenario level, for the Cucumber report: every difference, the expected answer (the accepted
 * golden master) and what the application answered - attached to the failing step, so that the step's message can stay
 * one screen long. Cucumber's HTML report shows a {@code text/plain} attachment as text and an
 * {@code application/json} one pretty-printed; its JSON report carries both. Nothing here decides anything: the
 * verdict is the runner's comparison, and the E2E run report holds the same data.
 */
final class FailureDetail {

    /** Characters of one attachment at most (the run report has the whole). */
    static final int ATTACHMENT_LIMIT = 5_000_000;
    /** Characters of the application's answer in a failure message. */
    static final int MESSAGE_ANSWER = 600;
    static final String TEXT = "text/plain";
    static final String JSON = "application/json";

    private FailureDetail() {
    }

    /** One attachment: its name, media type and content. */
    record Attachment(String name, String mediaType, String content) {
    }

    /** The attachments of one failed level; {@code suffix} tells levels apart when a scenario has several. */
    static List<Attachment> of(ScenarioReport report, GoldenMaster golden, String suffix) {
        ComparisonResult deciding = deciding(report);
        int count = deciding == null ? 0 : deciding.diffs().size();
        List<Attachment> found = new java.util.ArrayList<>();
        found.add(cut(new Attachment("All differences (" + count + ")" + suffix, TEXT, differences(report))));
        if (golden != null) {
            found.add(cut(new Attachment("Expected answer - the accepted golden master" + suffix, JSON,
                    expected(golden))));
        }
        if (report.target() != null) {
            found.add(cut(new Attachment("Actual answer - the application" + suffix, JSON, actual(report.target()))));
        }
        return found;
    }

    /** The comparison that decided the level's status (its verdict profile; else the one there is). */
    static ComparisonResult deciding(ScenarioReport report) {
        ComparisonResult chosen = "strict".equals(report.verdictProfile()) ? report.strict() : report.contract();
        return chosen != null ? chosen : report.strict() != null ? report.strict() : report.contract();
    }

    /** Every difference of the deciding comparison, its notes, and what only the other profile reports. */
    static String differences(ScenarioReport report) {
        ComparisonResult deciding = deciding(report);
        StringBuilder text = new StringBuilder(report.scenarioId() + " " + report.level() + " " + report.status());
        if (deciding == null) {
            return text.append(": ").append(report.message()).append('\n').toString();
        }
        text.append(" - the ").append(deciding.profile()).append(" comparison decided: ")
                .append(deciding.diffs().size()).append(" difference(s), ").append(deciding.compared())
                .append(" value(s) compared, ").append(deciding.matched()).append(" equal\n\n");
        deciding.diffs().forEach(d -> text.append(d.text()).append('\n'));
        if (!deciding.notes().isEmpty()) {
            text.append("\nNotes:\n");
            deciding.notes().forEach(n -> text.append("- ").append(n).append('\n'));
        }
        ComparisonResult other = deciding == report.contract() ? report.strict() : report.contract();
        if (other != null && other != deciding) {
            Set<String> shown = new HashSet<>();
            deciding.diffs().forEach(d -> shown.add(d.text()));
            List<FieldDiff> only = other.diffs().stream().filter(d -> !shown.contains(d.text())).toList();
            text.append("\nThe ").append(other.profile()).append(" comparison (not deciding): ")
                    .append(other.diffs().size()).append(" difference(s)");
            if (only.isEmpty()) {
                text.append(", none other than above\n");
            } else {
                text.append(", ").append(only.size()).append(" not above:\n");
                only.forEach(d -> text.append(d.text()).append('\n'));
            }
        }
        return text.toString();
    }

    /** The accepted golden master's answer: its scenario, unit and state, the outcome and the answer. */
    static String expected(GoldenMaster golden) {
        Observation observation = golden.observation();
        Map<String, Object> view = new LinkedHashMap<>();
        view.put("goldenMaster", golden.scenarioId() + " (" + golden.unit() + ", " + golden.state() + ")");
        view.put("outcome", observation.outcome());
        view.put("answer", observation.payload() != null ? observation.payload()
                : Map.of("fields", observation.fields(), "groups", observation.groups()));
        return pretty(JsonSupport.mapper().valueToTree(view));
    }

    /** What the application answered, as captured: the outcome, the capture's metadata and the whole answer. */
    static String actual(ScenarioReport.TargetAnswer target) {
        ObjectNode view = JsonSupport.mapper().createObjectNode();
        view.set("outcome", JsonSupport.mapper().valueToTree(target.outcome()));
        view.set("meta", JsonSupport.mapper().valueToTree(target.meta()));
        view.set("answer", target.payload() == null ? null : parsed(target.payload()));
        if (target.truncated()) {
            view.put("truncated", "the answer was cut after " + ScenarioReport.TargetAnswer.LIMIT + " characters");
        }
        return pretty(view);
    }

    private static JsonNode parsed(String payload) {
        try {
            return JsonSupport.mapper().readTree(payload);
        } catch (JsonProcessingException e) {
            return TextNode.valueOf(payload);           // an answer that is no JSON (or was cut): as text
        }
    }

    private static String pretty(JsonNode node) {
        try {
            return JsonSupport.mapper().writerWithDefaultPrettyPrinter().writeValueAsString(node);
        } catch (JsonProcessingException e) {
            return node.toString();
        }
    }

    /** An attachment beyond {@link #ATTACHMENT_LIMIT}: cut, as text, saying so. */
    static Attachment cut(Attachment attachment) {
        if (attachment.content().length() <= ATTACHMENT_LIMIT) {
            return attachment;
        }
        return new Attachment(attachment.name(), TEXT, attachment.content().substring(0, ATTACHMENT_LIMIT)
                + "\n... (cut after " + ATTACHMENT_LIMIT + " characters; the E2E run report holds the whole)");
    }
}
