package com.insurance.e2e.cucumber;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.run.E2eMode;
import com.insurance.e2e.core.run.E2eModule;
import com.insurance.e2e.core.spi.ExecutionContext;
import io.cucumber.core.plugin.HtmlFormatter;
import io.cucumber.core.plugin.JsonFormatter;
import io.cucumber.plugin.EventListener;
import io.cucumber.plugin.event.EventPublisher;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Locale;

/**
 * The Cucumber report of an MU's Behaviour Specification, one per run mode - the {@code cucumber.plugin} of the
 * generated suite class: {@code pretty,com.insurance.e2e.cucumber.BehaviourReports:<artifactId>}.
 *
 * <ul>
 *   <li>replay - {@code target/cucumber/<artifactId>.html} and {@code .json}: what the migrated application answered;</li>
 *   <li>record, live - {@code target/cucumber/<artifactId>-record.html} / {@code .json}, {@code -live} likewise;</li>
 *   <li>lint (the default profile) - none: a lint only checks the steps against the register and the golden masters
 *       and sends nothing, so every checked step would read "passed"; its result is the surefire report and
 *       {@code target/e2e-reports/e2e-lint.md}.</li>
 * </ul>
 *
 * A build in one mode therefore never replaces the report of another: with the plain {@code html:} / {@code json:}
 * plugins every build wrote the same two files, and a lint of the whole test solution (the engine stage of any MU)
 * turned every other module's replay report "all green". The directory is the module's ({@code -De2e.module.dir},
 * else the working directory - Surefire's is the module), as for the E2E run report.
 */
public final class BehaviourReports implements EventListener {

    /** The plugin's class name, as a suite class names it in {@code cucumber.plugin}. */
    public static final String PLUGIN = "com.insurance.e2e.cucumber.BehaviourReports";

    /** The reports' folder under the module. */
    public static final String DIRECTORY = "target/cucumber";

    private final List<Path> files;

    /** Cucumber's constructor: the argument after {@code BehaviourReports:} is the module's artifactId. */
    public BehaviourReports(String artifactId) {
        this(artifactId, ExecutionContext.fromSystem());
    }

    BehaviourReports(String artifactId, ExecutionContext context) {
        Path module = Paths.get(context.property(E2eModule.MODULE_DIR_PROPERTY, System.getProperty("user.dir")));
        this.files = files(module, artifactId, E2eMode.parse(context.property(E2eMode.PROPERTY)));
    }

    /** The HTML and the JSON report of a mode ({@code []} in lint). */
    static List<Path> files(Path module, String artifactId, E2eMode mode) {
        if (artifactId == null || !artifactId.matches("[A-Za-z0-9][A-Za-z0-9._-]*")) {
            throw new E2eException("BehaviourReports needs the module's artifactId as its argument "
                    + "(" + PLUGIN + ":<artifactId>), got '" + artifactId + "'");
        }
        if (mode == E2eMode.LINT) {
            return List.of();
        }
        String name = mode == E2eMode.REPLAY ? artifactId : artifactId + "-" + mode.name().toLowerCase(Locale.ROOT);
        Path folder = module.resolve(DIRECTORY);
        return List.of(folder.resolve(name + ".html"), folder.resolve(name + ".json"));
    }

    /** The files this build writes ({@code []} in lint). */
    List<Path> files() {
        return files;
    }

    @Override
    public void setEventPublisher(EventPublisher publisher) {
        if (files.isEmpty()) {
            return;
        }
        try {
            Files.createDirectories(files.get(0).getParent());
            new HtmlFormatter(open(files.get(0))).setEventPublisher(publisher);
            new JsonFormatter(open(files.get(1))).setEventPublisher(publisher);
        } catch (IOException e) {
            throw new UncheckedIOException("Cannot write the Cucumber report " + files, e);
        }
    }

    /** Both formatters close their stream when the run finishes. */
    private static OutputStream open(Path file) throws IOException {
        return new BufferedOutputStream(Files.newOutputStream(file));
    }
}
