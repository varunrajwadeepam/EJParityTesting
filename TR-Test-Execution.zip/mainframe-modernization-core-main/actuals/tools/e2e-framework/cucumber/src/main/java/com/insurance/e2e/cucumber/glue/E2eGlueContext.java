package com.insurance.e2e.cucumber.glue;

import io.cucumber.spring.CucumberContextConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;

/**
 * The Spring context cucumber-spring needs to create the generic steps - deliberately empty. The application under
 * validation is not this context: the target binding boots it, once per JVM and configuration, exactly as for the
 * register-driven tests. An MU module adds no second {@code @CucumberContextConfiguration} to its glue.
 */
@CucumberContextConfiguration
@ContextConfiguration(classes = E2eGlueContext.Empty.class)
public class E2eGlueContext {

    @Configuration(proxyBeanMethods = false)
    static class Empty {
    }
}
