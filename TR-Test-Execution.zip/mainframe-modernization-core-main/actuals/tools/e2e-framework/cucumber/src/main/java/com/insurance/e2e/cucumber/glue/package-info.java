/**
 * The generic step library of the Behaviour Specification.
 *
 * <p>{@link com.insurance.e2e.cucumber.glue.E2eSteps}: readable steps over the register and the golden masters,
 * executed through the same {@link com.insurance.e2e.core.run.ScenarioRunner}, bindings and comparator as the
 * register-driven tests; {@link com.insurance.e2e.cucumber.glue.E2eGlueContext}: the (empty) context cucumber-spring
 * needs. The features are generated from golden-master packages by the design stage ({@code e2e_package import}).
 * Business phrases (a phrasebook) and thin per-MU steps are later options, not part of this library.
 */
package com.insurance.e2e.cucumber.glue;
