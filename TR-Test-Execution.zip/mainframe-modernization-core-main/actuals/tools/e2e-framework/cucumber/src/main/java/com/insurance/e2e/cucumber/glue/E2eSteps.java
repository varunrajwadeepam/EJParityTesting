package com.insurance.e2e.cucumber.glue;

import com.fasterxml.jackson.databind.JsonNode;
import com.insurance.e2e.core.golden.GoldenMaster;
import com.insurance.e2e.core.junit.ScenarioSelection;
import com.insurance.e2e.core.observation.Outcome;
import com.insurance.e2e.core.run.E2eMode;
import com.insurance.e2e.core.run.ScenarioReport;
import com.insurance.e2e.core.scenario.DecidedAnswer;
import com.insurance.e2e.core.scenario.HttpRequestSpec;
import com.insurance.e2e.core.scenario.LevelBinding;
import com.insurance.e2e.core.scenario.Scenario;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.Before;
import io.cucumber.java.Status;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.opentest4j.TestAbortedException;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * The generic steps of the Behaviour Specification. A feature scenario is one register scenario, named by its
 * {@code @<scenarioId>} tag; every step states one fact of that scenario or of its golden master and is checked
 * against it in every mode (the lint that keeps the readable text and the executable assets one). When the run mode
 * is not {@code lint}, the When step executes the scenario through the {@link com.insurance.e2e.core.run.ScenarioRunner}
 * and the Then step decides on the runner's comparison with the accepted golden master - the one oracle; the lines
 * below it only repeat what the golden master holds.
 *
 * <pre>
 *   Given the fixture pack "UNIT/seed" and the clock 2024-08-16 10:30:00
 *   And the caller is the user "AB12"                                  (only for a call made as a user)
 *   When the client sends GET /lookups/KIND?searchValue=&amp;effectiveDate=20240816&amp;context[0].kind=DIRECT
 *   Then the answer matches the accepted golden master "TC-1"
 *   And the answer's rows are compared as a set, in any order          (only where the register says so)
 *   And the list "sources" is compared as a set, in any order          (one list of several)
 *   And the answer is decided by "PAR-510-05", the recording answers 500 (a decided answer: an accepted deviation)
 *   And the golden master holds status 200 and 3 items, starting with:
 *     | code | text  |
 *     | A    | ALPHA |
 *
 *   * the case is not applicable: the API has no such input      (or: the case is blocked: ...)
 * </pre>
 *
 * The When step names the request as sent ({@link HttpRequestSpec#target()}) or with the brackets of an indexed
 * parameter readable ({@link HttpRequestSpec#readableTarget()}). A declared not-applicable or blocked scenario is
 * skipped with its reason (and reported with it when executing), and so is one the runner finds BLOCKED (e.g. its
 * golden master disputed at the record gate); only a FAILED one fails.
 */
public class E2eSteps {

    private FeatureSession session;
    private io.cucumber.java.Scenario feature;
    private Scenario scenario;
    private String where;
    private boolean sent;
    private boolean callerStated;
    private boolean decided;
    private List<ScenarioReport> reports = List.of();

    @Before(order = 0)
    public void bind(io.cucumber.java.Scenario feature) {
        this.feature = feature;
        session = FeatureSession.forFeature(feature.getUri());
        where = fileName(feature.getUri()) + ":" + feature.getLine();
        Set<String> tags = new TreeSet<>();
        feature.getSourceTagNames().forEach(t -> tags.add(t.startsWith("@") ? t.substring(1) : t));
        List<Scenario> named = session.module().scenarios().stream().filter(s -> tags.contains(s.scenarioId())).toList();
        if (named.size() != 1) {
            throw new AssertionError(where + " '" + feature.getName() + "' "
                    + (named.isEmpty() ? "names no register scenario (tag it @<scenarioId>)"
                    : "names several register scenarios " + named.stream().map(Scenario::scenarioId).toList()));
        }
        scenario = named.get(0);
        ScenarioSelection selection = ScenarioSelection.fromContext(session.module().context());
        if (!selection.matches(scenario)) {                // a focused run never fails on what it did not select
            throw new TestAbortedException("not selected by " + selection);
        }
        Set<String> expected = new TreeSet<>(scenario.effectiveTags());
        expected.add(scenario.scenarioId());
        if (!expected.equals(tags)) {
            Set<String> missing = new TreeSet<>(expected);
            missing.removeAll(tags);
            Set<String> extra = new TreeSet<>(tags);
            extra.removeAll(expected);
            fail("its tags differ from the register's: missing " + missing + ", not in the register " + extra);
        }
        String name = scenario.scenarioId() + (scenario.title() == null || scenario.title().isBlank()
                ? "" : " " + scenario.title().strip());
        if (!name.equals(feature.getName())) {
            fail("the scenario is called '" + feature.getName() + "' but the register calls it '" + name + "'");
        }
    }

    @Given("the fixture pack {string} and the clock {}")
    public void fixtureAndClock(String pack, String clock) {
        fixture(pack);
        clock(clock);
    }

    @Given("the fixture pack {string}")
    public void fixture(String pack) {
        if (!pack.equals(scenario.fixture())) {
            fail("the feature names the fixture pack '" + pack + "' but the register '" + scenario.fixture() + "'");
        }
    }

    @Given("the clock {}")
    public void clock(String clock) {
        String digits = clock.replaceAll("[^0-9]", "");
        if (!digits.equals(scenario.clock())) {
            fail("the feature names the clock '" + clock + "' but the register '" + scenario.clock() + "'");
        }
    }

    /** Who calls: the legacy's user id the recording ran with ({@link HttpRequestSpec#principal()}). */
    @Given("the caller is the user {string}")
    public void caller(String user) {
        String principal = scenario.http() == null ? null : scenario.http().principal();
        if (!user.equals(principal)) {
            fail("the feature calls as the user '" + user + "' but the register's request is made "
                    + (principal == null ? "with no caller" : "as '" + principal + "'"));
        }
        callerStated = true;
    }

    @When("the client sends {word} {}")
    public void sends(String method, String target) {
        requireRunnable("When");
        HttpRequestSpec http = scenario.http();
        if (http == null) {
            fail("the register gives this scenario no HTTP request");
        }
        if (!http.method().equals(method) || !(http.target().equals(target) || http.readableTarget().equals(target))) {
            fail("the feature sends " + method + " " + target + " but the register's request is " + http.method()
                    + " " + http.readableTarget());
        }
        if (http.principal() != null && !callerStated) {
            fail("the register's request is made as the user '" + http.principal() + "' but the feature does not say "
                    + "so (Given the caller is the user \"" + http.principal() + "\")");
        }
        sent = true;
        if (session.executes()) {
            reports = session.run(scenario);
        }
    }

    @Then("the answer matches the accepted golden master {string}")
    public void matches(String goldenId) {
        requireRunnable("Then");
        if (!scenario.scenarioId().equals(goldenId)) {
            fail("the feature compares with the golden master '" + goldenId + "' of another scenario");
        }
        if (!sent) {
            fail("no request was sent: a When step comes before the Then");
        }
        if (session.mode() != E2eMode.RECORD) {
            golden();
        }
        decided = true;
        if (session.executes()) {
            verdict();
        }
    }

    @Then("the answer's rows are compared as a set, in any order")
    public void rowsAsSet() {
        requireRunnable("Then");
        if (!scenario.compare().rowsAsSet()) {
            fail("the feature says the answer's rows are compared as a set but the register compares them in order");
        }
    }

    @Then("the list {string} is compared as a set, in any order")
    public void listAsSet(String list) {
        requireRunnable("Then");
        if (!scenario.compare().rowsAsSet(list)) {
            fail("the feature says the list '" + list + "' is compared as a set but the register compares it in order");
        }
    }

    @Then("the field {string} is not compared")
    public void notCompared(String path) {
        requireRunnable("Then");
        if (!scenario.compare().ignoredPaths().contains(path)) {
            fail("the feature says the field '" + path + "' is not compared but the register compares it (it leaves out "
                    + scenario.compare().ignoredPaths() + ")");
        }
    }

    /**
     * The expected answer is a decision of the architecture (the register's {@code decided}): the register row that
     * decides it and the status the legacy recording gives - an accepted deviation, reported apart.
     */
    @Then("the answer is decided by {string}, the recording answers {int}")
    public void decidedBy(String source, int recordedStatus) {
        decidedBy(source);
        Integer recorded = scenario.decided().recordedStatus();
        if (recorded == null || recorded != recordedStatus) {
            fail("the feature says the recording answers " + recordedStatus + " but the register's decided answer "
                    + "names " + (recorded == null ? "no recorded status" : "the recorded status " + recorded));
        }
    }

    @Then("the answer is decided by {string}")
    public void decidedBy(String source) {
        requireRunnable("Then");
        DecidedAnswer decided = scenario.decided();
        if (decided == null) {
            fail("the feature says the answer is decided by " + source + " but the register expects the recording's "
                    + "answer (no decided answer)");
        }
        if (!source.equals(decided.source())) {
            fail("the feature says the answer is decided by " + source + " but the register names "
                    + decided.source());
        }
    }

    @Then("the golden master holds status {int}")
    public void holdsStatus(int status) {
        if (session.mode() == E2eMode.RECORD) {
            return;
        }
        Outcome outcome = golden().observation().outcome();
        if (outcome.exitState() == null || outcome.exitState() != status) {
            fail("the feature says the golden master holds status " + status + " but it holds "
                    + outcome.exitState());
        }
    }

    @Then("the golden master holds status {int} and no {word}")
    public void holdsNoItems(int status, String list) {
        holdsItems(status, 0, list);
    }

    @Then("the golden master holds status {int} and {int} {word}")
    public void holdsItems(int status, int count, String list) {
        holdsStatus(status);
        if (session.mode() == E2eMode.RECORD) {
            return;
        }
        JsonNode items = items(list);
        if (items.size() != count) {
            fail("the feature says the golden master holds " + count + " " + list + " but it holds " + items.size());
        }
    }

    @Then("the golden master holds status {int} and {int} {word}, starting with:")
    public void holdsItemsStartingWith(int status, int count, String list, DataTable rows) {
        holdsItems(status, count, list);
        if (session.mode() == E2eMode.RECORD) {
            return;
        }
        JsonNode items = items(list);
        String key = listKey(list);
        List<List<String>> cells = rows.cells();
        List<String> header = cells.isEmpty() ? List.of() : cells.get(0);
        if (cells.size() - 1 > items.size()) {
            fail("the feature shows " + (cells.size() - 1) + " " + key + " but the golden master holds " + items.size());
        }
        for (int row = 1; row < cells.size(); row++) {
            JsonNode item = items.get(row - 1);
            for (int column = 0; column < header.size(); column++) {
                String field = header.get(column);
                if (field == null || !item.has(field)) {
                    fail("the golden master's " + key + " have no field '" + field + "'");
                }
                String shown = cells.get(row).get(column) == null ? "" : cells.get(row).get(column);
                String held = text(item.get(field));
                if (!shown.equals(held)) {
                    fail(key + "[" + row + "]." + field + ": the feature shows '" + shown + "' but the golden master "
                            + "holds '" + held + "'");
                }
            }
        }
    }

    /** The request's JSON body as the register holds it (a POST / PUT of a golden-master package of format 3). */
    @Given("the request body:")
    public void requestBody(String docString) {
        HttpRequestSpec http = scenario.http();
        JsonNode shown;
        try {
            shown = com.insurance.e2e.core.json.JsonSupport.mapper().readTree(docString);
        } catch (java.io.IOException e) {
            fail("the feature's request body is not JSON: " + e.getMessage());
            return;
        }
        if (http == null || http.body() == null || !http.body().equals(shown)) {
            fail("the feature's request body differs from the register's " + (http == null ? null : http.body()));
        }
    }

    @Then("the golden master holds status {int} with an empty answer")
    public void holdsEmptyAnswer(int status) {
        holdsStatus(status);
        if (session.mode() == E2eMode.RECORD) {
            return;
        }
        JsonNode payload = golden().observation().payload();
        JsonNode empty = payload == null ? null : payload.get(com.insurance.e2e.core.run.TableCapture.EMPTY);
        if (!Boolean.TRUE.equals(scenario.answerEmpty()) || empty == null || !empty.asBoolean()) {
            fail("the feature says the answer is empty but the register / golden master do not");
        }
    }

    @Then("the golden master holds {int} row(s) in {word}")
    public void holdsRows(int count, String table) {
        if (scenario.tables().stream().noneMatch(t -> t.name().equals(table))) {
            fail("the feature names the table " + table + " but the register checks no such table");
        }
        if (session.mode() == E2eMode.RECORD) {
            return;
        }
        JsonNode payload = golden().observation().payload();
        JsonNode tables = payload == null ? null : payload.get(com.insurance.e2e.core.run.TableCapture.TABLES);
        JsonNode rows = tables == null ? null : tables.get(table);
        if (rows == null || !rows.isArray()) {
            fail("the golden master holds no rows for the table " + table);
        }
        if (rows.size() != count) {
            fail("the feature says the golden master holds " + count + " row(s) in " + table + " but it holds "
                    + rows.size());
        }
    }

    @Given("the case is not applicable: {}")
    public void notApplicable(String reason) {
        declared(Scenario.NOT_APPLICABLE, "not applicable", "N/A", reason);
    }

    @Given("the case is blocked: {}")
    public void blocked(String reason) {
        declared(Scenario.BLOCKED, "blocked", "BLOCKED", reason);
    }

    @After
    public void complete(io.cucumber.java.Scenario feature) {
        if (scenario != null && feature.getStatus() == Status.PASSED && !decided) {
            fail("states no outcome: a runnable scenario needs a When and a Then step, a declared one "
                    + "'* the case is not applicable: <reason>' or '* the case is blocked: <reason>'");
        }
    }

    /** End of the run: every executing module writes its run report. */
    @AfterAll
    public static void writeRunReports() {
        FeatureSession.finishAll();
    }

    private void declared(String status, String words, String shownAs, String reason) {
        if (!status.equals(scenario.status())) {
            fail("the feature says the case is " + words + " but the register declares it " + scenario.status());
        }
        if (!normalized(reason).equals(normalized(scenario.statusReason()))) {
            fail("the feature gives the reason '" + reason + "' but the register '" + scenario.statusReason() + "'");
        }
        decided = true;
        if (session.executes()) {
            session.run(scenario);
        }
        throw new TestAbortedException(shownAs + ": " + reason);
    }

    /**
     * A FAILED level fails the scenario (with every BLOCKED one beside it); a level BLOCKED at run time - e.g. its
     * golden master DISPUTED at the record gate - skips it with the reason, as a declared blocked case does: the
     * Cucumber report counts what the E2E run report counts, and no blocked recording reads as a product failure.
     */
    private void verdict() {
        List<String> failed = new ArrayList<>();
        List<String> blocked = new ArrayList<>();
        for (ScenarioReport report : reports) {
            switch (report.status()) {
                case PASSED, RECORDED -> {
                    // nothing to signal
                }
                case SKIPPED -> throw new TestAbortedException("SKIPPED: " + report.message());
                case NOT_APPLICABLE -> throw new TestAbortedException("N/A: " + report.message());
                case BLOCKED -> blocked.add(describe(report));
                case FAILED -> {
                    attach(report);
                    failed.add(describe(report));
                }
            }
        }
        if (!failed.isEmpty()) {
            failed.addAll(blocked);
            throw new AssertionError(String.join("\n", failed));
        }
        if (!blocked.isEmpty()) {
            throw new TestAbortedException(String.join("\n", blocked));
        }
    }

    /**
     * A failed level's whole detail - every difference, the expected and the actual answer - attached to this step
     * ({@link FailureDetail}); an attachment that cannot be written never changes the verdict (it is logged instead).
     */
    private void attach(ScenarioReport report) {
        if (feature == null) {
            return;
        }
        try {
            GoldenMaster golden = session.module().goldens().find(report.unit(), report.scenarioId()).orElse(null);
            String suffix = reports.size() > 1 ? " - " + report.unit() + " " + report.level() : "";
            for (FailureDetail.Attachment a : FailureDetail.of(report, golden, suffix)) {
                feature.attach(a.content(), a.mediaType(), a.name());
            }
        } catch (RuntimeException e) {
            feature.log("the failure's detail could not be attached (the E2E run report holds it): " + e);
        }
    }

    /**
     * The difference, the notes, the hypotheses and the start of what the target answered - one screen for whoever
     * reads the failure; a failed level's whole detail is attached to the step (the Cucumber report) and is in the E2E
     * run report.
     */
    static String describe(ScenarioReport report) {
        StringBuilder text = new StringBuilder(report.scenarioId() + " " + report.level() + " " + report.status() + ": "
                + report.message());
        if (!report.notes().isEmpty()) {
            text.append("\n  notes: ").append(String.join("; ", report.notes()));
        }
        if (!report.hypotheses().isEmpty()) {
            text.append("\n  hypotheses (anticipated, never the expected value): ")
                    .append(String.join("; ", report.hypotheses()));
        }
        if (report.target() != null) {
            Outcome outcome = report.target().outcome();
            text.append("\n  the target answered: ").append(outcome == null ? "-"
                    : outcome.kind() + (outcome.exitState() == null ? "" : " " + outcome.exitState()));
            if (report.target().payload() != null) {
                text.append(' ').append(report.target().excerpt(FailureDetail.MESSAGE_ANSWER));
            }
        }
        if (report.status() == ScenarioReport.Status.FAILED) {
            text.append("\n  the whole detail - every difference, the expected and the actual answer - is attached to "
                    + "this step (Cucumber report) and in the E2E run report");
        }
        return text.toString();
    }

    private void requireRunnable(String step) {
        if (!scenario.isRunnable()) {
            fail("the register declares this scenario " + scenario.status() + " ('" + scenario.statusReason()
                    + "'): instead of a " + step + " step its feature scenario says '* the case is "
                    + (scenario.isNotApplicable() ? "not applicable" : "blocked") + ": <reason>'");
        }
    }

    private GoldenMaster golden() {
        LevelBinding level = scenario.levels().isEmpty() ? null : scenario.levels().get(0);
        if (level == null) {
            fail("the register gives this scenario no level");
        }
        return session.module().goldens().find(level.legacyUnit(), scenario.scenarioId()).orElseThrow(() ->
                new AssertionError(where + " " + scenario.scenarioId() + ": no golden master golden/"
                        + level.legacyUnit() + "/" + scenario.scenarioId() + ".json (the design stage imports it)"));
    }

    private JsonNode items(String list) {
        JsonNode payload = golden().observation().payload();
        JsonNode items = payload == null ? null : payload.get(listKey(list));
        if (items == null || !items.isArray()) {
            fail("the golden master's answer has no list '" + list + "'");
        }
        return items;
    }

    /** The answer's list a step names: {@code items}, or {@code item} for one ("1 item"). */
    private String listKey(String list) {
        JsonNode payload = golden().observation().payload();
        return payload != null && !payload.has(list) && payload.has(list + "s") ? list + "s" : list;
    }

    private static String text(JsonNode value) {
        if (value == null || value.isNull()) {
            return "";
        }
        return value.isTextual() ? value.asText().strip() : value.toString();
    }

    private static String normalized(String text) {
        return text == null ? "" : text.strip().replaceAll("\\s+", " ");
    }

    private static String fileName(URI uri) {
        String path = uri.getSchemeSpecificPart();
        return path.substring(path.lastIndexOf('/') + 1);
    }

    private void fail(String message) {
        throw new AssertionError(where + " " + (scenario == null ? "" : scenario.scenarioId() + ": ") + message);
    }
}
