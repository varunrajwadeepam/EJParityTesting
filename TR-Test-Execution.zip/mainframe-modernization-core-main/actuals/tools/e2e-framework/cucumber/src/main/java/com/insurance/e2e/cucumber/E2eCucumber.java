package com.insurance.e2e.cucumber;

/**
 * Conventions of the Behaviour Specification (proposal §16). The generated suite class of an MU e2e module runs the
 * features under {@link #FEATURES} with the glue {@link #GLUE} plus the module's own package.
 *
 * <p>The features are generated from the golden-master packages by the design stage: one feature per package, a
 * {@code Rule:} per package rule, one scenario per register scenario (tagged {@code @<scenarioId>}), steps from the
 * generic library in {@link #GLUE}. They <strong>execute</strong> the module's scenarios in every run mode but lint;
 * in lint they are checked against the register and the golden masters.
 */
public final class E2eCucumber {

    /** Classpath directory of an MU module's features. */
    public static final String FEATURES = "e2e/features";

    /** Classpath location of an MU module's phrasebook (business phrases -> requests and checks; not used yet). */
    public static final String PHRASEBOOK = "e2e/phrasebook.yaml";

    /** Package of the generic step library. */
    public static final String GLUE = "com.insurance.e2e.cucumber.glue";

    /** Traceability tag prefixes a feature uses. */
    public static final String TAG_CAPABILITY = "@capability:";
    public static final String TAG_MU = "@mu:";
    public static final String TAG_LEGACY = "@legacy:";
    public static final String TAG_DECISION = "@decision:";
    public static final String TAG_RISK = "@risk:";
    public static final String TAG_CAVEAT = "@caveat:";
    /** A package rule the scenario proves ({@code @rule:R3}). */
    public static final String TAG_RULE = "@rule:";

    private E2eCucumber() {
    }
}
