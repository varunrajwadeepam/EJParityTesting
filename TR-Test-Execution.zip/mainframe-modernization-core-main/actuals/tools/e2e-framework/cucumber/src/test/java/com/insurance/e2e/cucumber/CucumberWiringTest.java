package com.insurance.e2e.cucumber;

import org.junit.jupiter.api.Test;
import org.junit.platform.testkit.engine.EngineTestKit;

import static io.cucumber.junit.platform.engine.Constants.GLUE_PROPERTY_NAME;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClasspathResource;

/**
 * Proves the hooks: the Cucumber engine runs on the JUnit Platform, finds features on the classpath and creates step
 * definitions through cucumber-spring; an MU module without features runs nothing and fails nothing.
 */
class CucumberWiringTest {

    @Test
    void aFeatureRunsWithSpringInjectedSteps() {
        EngineTestKit.engine("cucumber")
                .selectors(selectClasspathResource("wiring/features"))
                .configurationParameter(GLUE_PROPERTY_NAME, "com.insurance.e2e.cucumber.wiring")
                .execute()
                .testEvents()
                .assertStatistics(stats -> stats.started(1).succeeded(1).failed(0));
    }

    @Test
    void anEmptyFeaturesDirectoryRunsNothingAndFailsNothing() {
        EngineTestKit.engine("cucumber")
                .selectors(selectClasspathResource("wiring/empty"))
                .configurationParameter(GLUE_PROPERTY_NAME, E2eCucumber.GLUE)
                .execute()
                .testEvents()
                .assertStatistics(stats -> stats.started(0).failed(0));
    }
}
