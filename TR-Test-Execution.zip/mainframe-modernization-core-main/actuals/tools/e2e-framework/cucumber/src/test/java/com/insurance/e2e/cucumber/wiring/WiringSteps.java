package com.insurance.e2e.cucumber.wiring;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.spring.CucumberContextConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/** Synthetic steps proving that cucumber-spring injects beans into step definitions. */
@CucumberContextConfiguration
@ContextConfiguration(classes = WiringSteps.Config.class)
public class WiringSteps {

    @Configuration
    static class Config {
        @Bean
        List<String> colourCodes() {
            return List.of("B", "C", "P");
        }
    }

    @Autowired
    private List<String> colourCodes;

    private List<String> answer;

    @Given("the colour codes are configured")
    public void configured() {
        assertThat(colourCodes).isNotEmpty();
    }

    @When("an operator asks for codes starting at {string}")
    public void ask(String start) {
        answer = colourCodes.stream().filter(code -> code.compareTo(start) >= 0).toList();
    }

    @Then("the list shows {string}")
    public void shows(String expected) {
        assertThat(String.join(", ", answer)).isEqualTo(expected);
    }
}
