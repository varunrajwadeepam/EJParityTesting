package com.insurance.e2e.cucumber.fakes;

import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.observation.Outcome;
import com.insurance.e2e.core.spi.CapturePlugin;
import com.insurance.e2e.core.spi.EnvironmentPlugin;
import com.insurance.e2e.core.spi.ExecutionContext;
import com.insurance.e2e.core.spi.TriggerPlugin;
import com.insurance.e2e.core.scenario.Scenario;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** Synthetic target ({@code TGT-FAKE}): answers each scenario with the JSON a test put into {@link #ANSWERS}. */
public final class FakeTarget implements TriggerPlugin {

    public static final String KIND = "TGT-FAKE";
    public static final Map<String, String> ANSWERS = new ConcurrentHashMap<>();
    public static final List<String> CALLS = new java.util.concurrent.CopyOnWriteArrayList<>();

    @Override
    public String id() {
        return "fake-target";
    }

    @Override
    public Set<String> kinds() {
        return Set.of(KIND);
    }

    @Override
    public TriggerResult trigger(Request request) {
        String id = request.scenario().scenarioId();
        CALLS.add(id);
        try {
            return new TriggerResult(request.binding(), Observation.targetPayload(
                    JsonSupport.mapper().readTree(ANSWERS.getOrDefault(id, "{}")), Outcome.ok(200L)), null, Map.of());
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    /** Capture of the synthetic target: the trigger's payload already is the observation. */
    public static final class Capture implements CapturePlugin {
        @Override
        public String id() {
            return "fake-target-capture";
        }

        @Override
        public Set<String> kinds() {
            return Set.of(KIND);
        }

        @Override
        public Observation capture(Request request) {
            return (Observation) request.result().payload();
        }
    }

    /** A JDBC environment that loads nothing: one pack hash, one unchanged table state. */
    public static final class Environment implements EnvironmentPlugin {
        @Override
        public String id() {
            return "fake-environment";
        }

        @Override
        public Set<String> kinds() {
            return Set.of(JDBC);
        }

        @Override
        public FixtureState prepare(Scenario scenario, String fixture, ExecutionContext context) {
            return new FixtureState(fixture, "fx-1", "state-1", List.of("GREETING"));
        }

        @Override
        public String stateHash(List<String> tables, ExecutionContext context) {
            return "state-1";
        }
    }
}
