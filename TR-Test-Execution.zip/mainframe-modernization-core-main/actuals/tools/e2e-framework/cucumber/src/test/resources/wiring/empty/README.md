An MU module before its Behaviour Specification exists: no features, nothing runs, nothing fails.
