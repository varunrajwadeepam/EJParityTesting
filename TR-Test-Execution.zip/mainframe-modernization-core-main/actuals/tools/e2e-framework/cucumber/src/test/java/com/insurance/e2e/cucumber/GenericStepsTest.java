package com.insurance.e2e.cucumber;

import com.insurance.e2e.core.golden.GoldenMaster;
import com.insurance.e2e.core.golden.GoldenMasterStore;
import com.insurance.e2e.core.golden.Lifecycle;
import com.insurance.e2e.core.golden.LifecycleState;
import com.insurance.e2e.core.golden.Provenance;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.observation.Outcome;
import com.insurance.e2e.cucumber.fakes.FakeTarget;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.junit.platform.testkit.engine.EngineExecutionResults;
import org.junit.platform.testkit.engine.EngineTestKit;
import org.junit.platform.testkit.engine.Event;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import static io.cucumber.junit.platform.engine.Constants.GLUE_PROPERTY_NAME;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectDirectory;

/**
 * The generic steps over a synthetic e2e module: a feature written as the design stage generates it, run by the
 * Cucumber engine with the glue {@link E2eCucumber#GLUE} - linted in the default mode, executed in replay through the
 * core's runner (the run report is the execute stage's evidence), and every disagreement with the register or the
 * golden master failing the scenario.
 */
class GenericStepsTest {

    static final String LEVEL = """
            [ { "level": "L4", "lens": "service", "legacy": "LEG-FAKE:DEMO", "target": "TGT-FAKE:app", "mapping": "DEMO" } ]""";

    static final String REGISTER = """
            { "schemaVersion": "1.1", "mu": "MU-DEMO", "generatedBy": "test",
              "scenarios": [
                { "scenarioId": "DEMO-1", "title": "greet-world", "category": "Happy", "tags": ["rule:R1"],
                  "fixture": "DEMO/seed", "clock": "20240816103000", "levels": %1$s, "request": {},
                  "http": { "method": "GET", "path": "/greetings/WORLD", "query": { "punctuation": "!" } } },
                { "scenarioId": "DEMO-2", "title": "greet-other", "category": "Edge", "tags": ["hypothesis", "rule:R1"],
                  "hypotheses": ["the target punctuates differently"], "levels": %1$s, "request": {},
                  "http": { "method": "GET", "path": "/greetings/WORLD", "query": { "punctuation": "?" } } },
                { "scenarioId": "DEMO-3", "title": "greet-user", "status": "not-applicable",
                  "statusReason": "varies only an input the API lacks", "tags": ["not-applicable"], "levels": %1$s,
                  "request": {} },
                { "scenarioId": "DEMO-4", "status": "blocked", "statusReason": "the legacy unit could not be recorded",
                  "tags": ["blocked"], "levels": %1$s, "request": {} } ] }
            """.formatted(LEVEL);

    static final String FEATURE = """
            # Generated (synthetic) - the shape e2e_package import writes.
            @unit:DEMO @lens:service @level:L4
            Feature: DEMO - GET /greetings/{name}
              A synthetic package.

              @DEMO-3 @not-applicable
              Scenario: DEMO-3 greet-user
                * the case is not applicable: varies only an input the API lacks

              @DEMO-4 @blocked
              Scenario: DEMO-4
                * the case is blocked: the legacy unit could not be recorded

              Rule: R1 - Greetings end with the requested punctuation.

                @DEMO-1 @category:Happy @rule:R1
                Scenario: DEMO-1 greet-world
                  Given the fixture pack "DEMO/seed" and the clock 2024-08-16 10:30:00
                  When the client sends GET /greetings/WORLD?punctuation=%21
                  Then the answer matches the accepted golden master "DEMO-1"
                  And the golden master holds status 200 and 1 item, starting with:
                    | code | text     |
                    | G    | GREETING |

                @DEMO-2 @category:Edge @hypothesis @rule:R1
                Scenario: DEMO-2 greet-other
                  When the client sends GET /greetings/WORLD?punctuation=%3F
                  Then the answer matches the accepted golden master "DEMO-2"
                  And the golden master holds status 200 and no items
            """;

    static final String HELLO = "{ \"greeting\": \"HELLO WORLD!\", \"items\": [ { \"code\": \"G\", \"text\": \"GREETING\" } ] }";

    @TempDir
    Path module;

    Path e2e;

    @BeforeEach
    void writeModule() throws IOException {
        e2e = module.resolve("e2e");
        Files.createDirectories(e2e.resolve("scenarios"));
        Files.createDirectories(e2e.resolve("view-mappings"));
        Files.createDirectories(e2e.resolve("features"));
        Files.writeString(e2e.resolve("scenarios/demo.json"), REGISTER);
        Files.writeString(e2e.resolve("view-mappings/DEMO.json"), """
                { "schemaVersion": "1.0", "unit": "DEMO", "description": "the API response",
                  "fields": [ { "legacy": "greeting", "target": "greeting" } ],
                  "groups": [ { "name": "items", "target": "items",
                                "fields": [ { "legacy": "code", "target": "code" }, { "legacy": "text", "target": "text" } ] } ] }
                """);
        Files.writeString(e2e.resolve("profiles.json"), """
                { "schemaVersion": "1.0", "profiles": [ { "name": "contract", "rules": [
                  { "rule": "RTRIM", "decision": "PKG-CMP-DEMO" } ] } ] }""");
        GoldenMasterStore store = new GoldenMasterStore(e2e.resolve("golden"));
        accept(store, "DEMO-1", HELLO);
        accept(store, "DEMO-2", "{ \"greeting\": \"HELLO WORLD?\", \"items\": [] }");
        feature(FEATURE);
        FakeTarget.ANSWERS.clear();
        FakeTarget.CALLS.clear();
        System.setProperty("e2e.module.dir", module.toString());
    }

    @AfterEach
    void clearProperties() {
        for (String key : List.of("e2e.module.dir", "e2e.mode", "e2e.scenarios", "e2e.tags")) {
            System.clearProperty(key);
        }
    }

    @Test
    void lintChecksEveryStepAndExecutesNothing() {
        EngineExecutionResults results = run();

        results.testEvents().assertStatistics(s -> s.started(4).succeeded(2).aborted(2).failed(0));
        assertThat(messages(results, "aborted")).anyMatch(m -> m.contains("N/A: varies only an input the API lacks"))
                .anyMatch(m -> m.contains("BLOCKED: the legacy unit could not be recorded"));
        assertThat(FakeTarget.CALLS).isEmpty();
        assertThat(module.resolve("target/e2e-reports/e2e-lint.json")).doesNotExist();
    }

    @Test
    void replayExecutesThroughTheRunnerAndWritesTheRunReport() throws IOException {
        System.setProperty("e2e.mode", "replay");
        FakeTarget.ANSWERS.put("DEMO-1", HELLO);
        FakeTarget.ANSWERS.put("DEMO-2", "{ \"greeting\": \"HELLO WORLD!\", \"items\": [] }");

        EngineExecutionResults results = run();

        results.testEvents().assertStatistics(s -> s.started(4).succeeded(1).failed(1).aborted(2));
        assertThat(FakeTarget.CALLS).containsExactly("DEMO-1", "DEMO-2");
        assertThat(messages(results, "failed")).singleElement().asString()
                .contains("DEMO-2 L4 FAILED", "greeting", "hypotheses (anticipated, never the expected value): "
                        + "the target punctuates differently", "the target answered: OK 200", "HELLO WORLD!");
        String report = Files.readString(module.resolve("target/e2e-reports/e2e-replay.md"));
        assertThat(report).contains("| DEMO-1 | L4 | service | DEMO | PASSED |", "| DEMO-2 | L4 | service | DEMO | FAILED |",
                "| DEMO-3 | L4 | service | DEMO | NOT_APPLICABLE |", "| DEMO-4 | L4 | service | DEMO | BLOCKED |");
        assertThat(report.indexOf("DEMO-1 |")).as("register order, not feature order").isLessThan(report.indexOf("DEMO-3 |"));
        assertThat(Files.readString(module.resolve("target/e2e-reports/e2e-replay.json")))
                .contains("\"PASSED\" : 1", "\"FAILED\" : 1", "\"NOT_APPLICABLE\" : 1", "\"BLOCKED\" : 1");
    }

    @Test
    void aGoldenMasterDisputedAtTheRecordGateSkipsTheScenarioWithItsReasonAndAFailureStillFails() throws IOException {
        GoldenMasterStore store = new GoldenMasterStore(e2e.resolve("golden"));
        store.updateLifecycle(Lifecycle.transition(store.find("DEMO", "DEMO-1").orElseThrow(), LifecycleState.DISPUTED,
                "test reviewer", "record gate", "GM-2: the recording shows the test stack", "2026-10-12T02:00:00Z"));
        System.setProperty("e2e.mode", "replay");
        FakeTarget.ANSWERS.put("DEMO-1", HELLO);
        FakeTarget.ANSWERS.put("DEMO-2", "{ \"greeting\": \"HELLO WORLD!\", \"items\": [] }");

        EngineExecutionResults results = run();

        // the Cucumber counts are the run report's: a blocked recording is no product failure (U-117)
        results.testEvents().assertStatistics(s -> s.started(4).succeeded(0).failed(1).aborted(3));
        assertThat(messages(results, "aborted"))
                .anyMatch(m -> m.contains("DEMO-1 L4 BLOCKED: golden master is DISPUTED; only accepted golden masters"));
        assertThat(messages(results, "failed")).singleElement().asString().contains("DEMO-2 L4 FAILED");
        assertThat(Files.readString(module.resolve("target/e2e-reports/e2e-replay.json")))
                .contains("\"FAILED\" : 1", "\"BLOCKED\" : 2");
    }

    @Test
    void theCucumberReportIsTheRunModesAndALintLeavesTheReplaysAlone() throws IOException {
        String plugin = "pretty," + BehaviourReports.PLUGIN + ":demo-mu-e2e";
        Path html = module.resolve("target/cucumber/demo-mu-e2e.html");
        Path json = module.resolve("target/cucumber/demo-mu-e2e.json");

        run(plugin);
        assertThat(module.resolve("target/cucumber")).as("a lint writes no Cucumber report").doesNotExist();

        System.setProperty("e2e.mode", "replay");
        FakeTarget.ANSWERS.put("DEMO-1", HELLO);
        FakeTarget.ANSWERS.put("DEMO-2", "{ \"greeting\": \"HELLO WORLD!\", \"items\": [] }");
        run(plugin);
        String replayed = Files.readString(json);
        assertThat(replayed).contains("DEMO-2 greet-other", "\"failed\"", "DEMO-2 L4 FAILED");
        assertThat(Files.readString(html)).contains("DEMO-2 greet-other");

        System.setProperty("e2e.mode", "lint");
        run(plugin);
        assertThat(Files.readString(json)).as("the replay's report survives a lint").isEqualTo(replayed);

        System.setProperty("e2e.mode", "record");
        run(plugin);
        assertThat(module.resolve("target/cucumber/demo-mu-e2e-record.json")).exists();
        assertThat(module.resolve("target/cucumber/demo-mu-e2e-record.html")).exists();
        assertThat(Files.readString(json)).as("nor does another executing mode replace it").isEqualTo(replayed);
    }

    @Test
    void aFailedStepCarriesEveryDifferenceAndBothWholeAnswersAsAttachments() throws IOException {
        String plugin = "pretty," + BehaviourReports.PLUGIN + ":demo-mu-e2e";
        System.setProperty("e2e.mode", "replay");
        FakeTarget.ANSWERS.put("DEMO-1", HELLO);
        StringBuilder rows = new StringBuilder();
        for (int i = 0; i < 300; i++) {
            rows.append(i == 0 ? "" : ",").append("{\"code\":\"C").append(i).append("\",\"text\":\"ROW ").append(i)
                    .append("\"}");
        }
        FakeTarget.ANSWERS.put("DEMO-2", "{ \"greeting\": \"HELLO WORLD!\", \"items\": [" + rows + "] }");

        EngineExecutionResults results = run(plugin);

        String message = messages(results, "failed").get(0);
        assertThat(message).contains("DEMO-2 L4 FAILED", "the target answered: OK 200",
                "the whole detail - every difference, the expected and the actual answer - is attached to this step");
        assertThat(message).as("the message shows the answer's start only").doesNotContain("C299").contains("...");
        com.fasterxml.jackson.databind.JsonNode report = JsonSupport.mapper().readTree(
                module.resolve("target/cucumber/demo-mu-e2e.json").toFile());
        com.fasterxml.jackson.databind.JsonNode step = null;
        for (com.fasterxml.jackson.databind.JsonNode element : report.get(0).get("elements")) {
            if (element.get("name").asText().startsWith("DEMO-2")) {
                for (com.fasterxml.jackson.databind.JsonNode s : element.get("steps")) {
                    if (s.get("name").asText().startsWith("the answer matches the accepted golden master")) {
                        step = s;
                    }
                }
            }
        }
        assertThat(step).as("the failing step").isNotNull();
        Map<String, String> attached = new java.util.LinkedHashMap<>();
        Map<String, String> types = new java.util.LinkedHashMap<>();
        for (com.fasterxml.jackson.databind.JsonNode embedding : step.get("embeddings")) {
            String name = embedding.get("name").asText();
            attached.put(name, new String(java.util.Base64.getDecoder().decode(embedding.get("data").asText()),
                    java.nio.charset.StandardCharsets.UTF_8));
            types.put(name, embedding.get("mime_type").asText());
        }
        assertThat(attached).containsOnlyKeys("All differences (2)", "Expected answer - the accepted golden master",
                "Actual answer - the application");
        assertThat(types).containsValues("text/plain", "application/json");
        assertThat(attached.get("All differences (2)")).contains("the contract comparison decided: 2 difference(s)",
                "greeting VALUE legacy=", "items[] ROW_COUNT legacy='0' target='300'");
        com.fasterxml.jackson.databind.JsonNode expected = JsonSupport.mapper().readTree(
                attached.get("Expected answer - the accepted golden master"));
        assertThat(expected.get("goldenMaster").asText()).isEqualTo("DEMO-2 (DEMO, ACCEPTED)");
        assertThat(expected.get("answer").get("items")).isEmpty();
        com.fasterxml.jackson.databind.JsonNode actual = JsonSupport.mapper().readTree(
                attached.get("Actual answer - the application"));
        assertThat(actual.get("answer").get("items")).as("the whole answer").hasSize(300);
        assertThat(actual.get("answer").get("items").get(299).get("code").asText()).isEqualTo("C299");
        assertThat(actual.get("outcome").get("kind").asText()).isEqualTo("OK");
        assertThat(Files.readString(module.resolve("target/cucumber/demo-mu-e2e.html"))).contains("All differences (2)");
        String runReport = Files.readString(module.resolve("target/e2e-reports/e2e-replay.json"));
        assertThat(runReport).as("the run report keeps the whole answer too").contains("C299").doesNotContain(
                "\"truncated\" : true");
        com.fasterxml.jackson.databind.JsonNode passed = report.get(0).get("elements").get(0);
        assertThat(passed.toString()).as("a passing scenario attaches nothing").doesNotContain("embeddings");
    }

    @Test
    void theReportPluginNeedsTheModulesArtifactId() {
        assertThat(BehaviourReports.files(module, "demo-mu-e2e", com.insurance.e2e.core.run.E2eMode.LINT)).isEmpty();
        assertThat(BehaviourReports.files(module, "demo-mu-e2e", com.insurance.e2e.core.run.E2eMode.LIVE))
                .containsExactly(module.resolve("target/cucumber/demo-mu-e2e-live.html"),
                        module.resolve("target/cucumber/demo-mu-e2e-live.json"));
        org.assertj.core.api.Assertions.assertThatThrownBy(
                        () -> BehaviourReports.files(module, "../x", com.insurance.e2e.core.run.E2eMode.REPLAY))
                .hasMessageContaining(BehaviourReports.PLUGIN + ":<artifactId>");
    }

    @Test
    void theSelectionAppliesToTheFeaturesToo() throws IOException {
        System.setProperty("e2e.mode", "replay");
        System.setProperty("e2e.scenarios", "DEMO-1");
        FakeTarget.ANSWERS.put("DEMO-1", HELLO);
        // a scenario that is not selected is skipped before its lint: a focused run never fails on it
        feature(FEATURE.replace("@DEMO-2 @category:Edge @hypothesis @rule:R1", "@DEMO-2 @category:Happy @rule:R1"));

        EngineExecutionResults results = run();

        results.testEvents().assertStatistics(s -> s.started(4).succeeded(1).aborted(3).failed(0));
        assertThat(messages(results, "aborted")).anyMatch(m -> m.contains("not selected by e2e.scenarios=DEMO-1"));
        assertThat(FakeTarget.CALLS).containsExactly("DEMO-1");

        System.setProperty("e2e.scenarios", "DEMO-2");
        System.setProperty("e2e.mode", "lint");
        assertThat(messages(run(), "failed")).singleElement().asString().contains("its tags differ");
    }

    @Test
    void aStepThatDisagreesWithTheRegisterOrTheGoldenMasterFails() throws IOException {
        feature(FEATURE.replace("punctuation=%21", "punctuation=%3F")
                .replace("| G    | GREETING |", "| G    | GREETINGS |")
                .replace("lacks", "has")
                .replace("2024-08-16 10:30:00", "2031-01-01 10:30:00"));

        List<String> failures = messages(run(), "failed");

        assertThat(failures).hasSize(2)
                .anyMatch(m -> m.contains("the feature gives the reason 'varies only an input the API has'"))
                .anyMatch(m -> m.contains("the feature names the clock '2031-01-01 10:30:00'"));
        feature(FEATURE.replace("punctuation=%21", "punctuation=%3F"));
        assertThat(messages(run(), "failed")).singleElement().asString()
                .contains("demo.feature:17 DEMO-1: the feature sends GET /greetings/WORLD?punctuation=%3F but the "
                        + "register's request is GET /greetings/WORLD?punctuation=%21");
        feature(FEATURE.replace("| G    | GREETING |", "| G    | GREETINGS |")
                .replace("and no items", "and 2 items"));
        assertThat(messages(run(), "failed")).hasSize(2)
                .anyMatch(m -> m.contains("items[1].text: the feature shows 'GREETINGS' but the golden master holds 'GREETING'"))
                .anyMatch(m -> m.contains("holds 2 items but it holds 0"));
        feature(FEATURE.replace("status 200 and no items", "status 404"));
        assertThat(messages(run(), "failed")).singleElement().asString()
                .contains("the feature says the golden master holds status 404 but it holds 200");
    }

    @Test
    void theTagsTheNameAndTheShapeOfAScenarioAreChecked() throws IOException {
        feature(FEATURE.replace("@DEMO-2 @category:Edge @hypothesis @rule:R1", "@category:Edge @hypothesis @rule:R1")
                .replace("@DEMO-1 @category:Happy @rule:R1", "@DEMO-1 @category:Edge @rule:R1")
                .replace("Scenario: DEMO-3 greet-user", "Scenario: DEMO-3 greet-someone"));

        assertThat(messages(run(), "failed")).hasSize(3)
                .anyMatch(m -> m.contains("'DEMO-2 greet-other' names no register scenario"))
                .anyMatch(m -> m.contains("its tags differ from the register's: missing [category:Happy], not in the "
                        + "register [category:Edge]"))
                .anyMatch(m -> m.contains("is called 'DEMO-3 greet-someone' but the register calls it 'DEMO-3 greet-user'"));

        feature(FEATURE.replace("      Then the answer matches the accepted golden master \"DEMO-2\"\n", "")
                .replace("      And the golden master holds status 200 and no items\n", "")
                .replace("* the case is blocked: the legacy unit could not be recorded",
                        "When the client sends GET /greetings/WORLD"));
        assertThat(messages(run(), "failed")).hasSize(2)
                .anyMatch(m -> m.contains("DEMO-2: states no outcome"))
                .anyMatch(m -> m.contains("the register declares this scenario blocked"));
    }

    @Test
    void anIndexedQueryReadsWithItsBracketsAndASetComparisonIsAStatedStep() throws IOException {
        Files.writeString(e2e.resolve("scenarios/demo.json"), REGISTER.replace(
                "\"query\": { \"punctuation\": \"!\" } } },",
                "\"query\": { \"punctuation\": \"!\", \"context[0].kind\": \"DIRECT\" } },"
                        + " \"compare\": { \"rows\": \"set\", \"order\": \"report-only\" } },"));
        String readable = FEATURE.replace("punctuation=%21\n", "punctuation=%21&context[0].kind=DIRECT\n")
                .replace("golden master \"DEMO-1\"\n", "golden master \"DEMO-1\"\n"
                        + "      And the answer's rows are compared as a set, in any order\n");
        feature(readable);
        assertThat(messages(run(), "failed")).isEmpty();

        feature(readable.replace("context[0].kind", "context%5B0%5D.kind"));
        assertThat(messages(run(), "failed")).as("the request as sent reads too").isEmpty();

        feature(readable.replace("golden master \"DEMO-2\"\n", "golden master \"DEMO-2\"\n"
                + "      And the answer's rows are compared as a set, in any order\n"));
        assertThat(messages(run(), "failed")).singleElement().asString().contains("DEMO-2: the feature says the "
                + "answer's rows are compared as a set but the register compares them in order");

        System.setProperty("e2e.mode", "replay");
        System.setProperty("e2e.scenarios", "DEMO-1");
        FakeTarget.ANSWERS.put("DEMO-1", HELLO);
        feature(readable);
        assertThat(messages(run(), "failed")).isEmpty();
        assertThat(FakeTarget.CALLS).containsExactly("DEMO-1");
    }

    @Test
    void theCallerOfARequestAndAListComparedAsASetAreStatedStepsAndEachIsChecked() throws IOException {
        Files.writeString(e2e.resolve("scenarios/demo.json"), REGISTER.replace(
                "\"query\": { \"punctuation\": \"!\" } } },",
                "\"query\": { \"punctuation\": \"!\" }, \"principal\": \"AB12\" },"
                        + " \"compare\": { \"setPaths\": [\"items\"], \"order\": \"report-only\" } },"));
        String stated = FEATURE.replace("the clock 2024-08-16 10:30:00\n", "the clock 2024-08-16 10:30:00\n"
                        + "      And the caller is the user \"AB12\"\n")
                .replace("golden master \"DEMO-1\"\n", "golden master \"DEMO-1\"\n"
                        + "      And the list \"items\" is compared as a set, in any order\n");
        feature(stated);
        assertThat(messages(run(), "failed")).isEmpty();

        feature(stated.replace("the user \"AB12\"", "the user \"ab12\""));
        assertThat(messages(run(), "failed")).singleElement().asString()
                .contains("DEMO-1: the feature calls as the user 'ab12' but the register's request is made as 'AB12'");

        feature(stated.replace("      And the caller is the user \"AB12\"\n", ""));
        assertThat(messages(run(), "failed")).singleElement().asString()
                .contains("the register's request is made as the user 'AB12' but the feature does not say so");

        feature(stated.replace("the list \"items\"", "the list \"codes\""));
        assertThat(messages(run(), "failed")).singleElement().asString().contains(
                "DEMO-1: the feature says the list 'codes' is compared as a set but the register compares it in order");

        feature(stated.replace("golden master \"DEMO-2\"\n", "golden master \"DEMO-2\"\n"
                + "      And the caller is the user \"AB12\"\n"));
        assertThat(messages(run(), "failed")).singleElement().asString()
                .contains("DEMO-2: the feature calls as the user 'AB12' but the register's request is made with no caller");
    }

    @Test
    void aFieldTheRegisterLeavesOutIsAStatedStepAndIsNotComparedUnderTheContract() throws IOException {
        Files.writeString(e2e.resolve("scenarios/demo.json"), REGISTER.replace(
                "\"query\": { \"punctuation\": \"?\" } } },",
                "\"query\": { \"punctuation\": \"?\" } }, \"compare\": { \"expectEmpty\": true, \"ignore\": "
                        + "[ { \"path\": \"greeting\", \"reason\": \"PAR-X-1: the echo is not compared\" } ] } },"));
        String stated = FEATURE.replace("golden master \"DEMO-2\"\n", "golden master \"DEMO-2\"\n"
                + "      And the field \"greeting\" is not compared\n");
        feature(stated);
        assertThat(messages(run(), "failed")).isEmpty();

        feature(stated.replace("golden master \"DEMO-1\"\n", "golden master \"DEMO-1\"\n"
                + "      And the field \"greeting\" is not compared\n"));
        assertThat(messages(run(), "failed")).singleElement().asString()
                .contains("DEMO-1: the feature says the field 'greeting' is not compared but the register compares it");

        System.setProperty("e2e.mode", "replay");
        FakeTarget.ANSWERS.put("DEMO-1", HELLO);
        FakeTarget.ANSWERS.put("DEMO-2", "{ \"greeting\": \"HELLO WORLD!\", \"items\": [] }");
        feature(stated);
        assertThat(messages(run(), "failed")).as("the greeting differs, but DEMO-2 does not compare it").isEmpty();
        assertThat(FakeTarget.CALLS).containsExactly("DEMO-1", "DEMO-2");
    }

    @Test
    void anAnswerTheArchitectureDecidedIsAStatedStepAndIsChecked() throws IOException {
        Files.writeString(e2e.resolve("scenarios/demo.json"), REGISTER.replace(
                "\"query\": { \"punctuation\": \"?\" } } },",
                "\"query\": { \"punctuation\": \"?\" } }, \"decided\": { \"source\": \"PAR-X-5\", \"status\": 200, "
                        + "\"recordedStatus\": 500, \"register\": \"parity/x.md:5\" } },"));
        String stated = FEATURE.replace("golden master \"DEMO-2\"\n", "golden master \"DEMO-2\"\n"
                + "      And the answer is decided by \"PAR-X-5\", the recording answers 500\n");
        feature(stated);
        assertThat(messages(run(), "failed")).isEmpty();

        feature(stated.replace("the recording answers 500", "the recording answers 503"));
        assertThat(messages(run(), "failed")).singleElement().asString()
                .contains("DEMO-2: the feature says the recording answers 503 but the register's decided answer names "
                        + "the recorded status 500");
        feature(stated.replace("decided by \"PAR-X-5\"", "decided by \"PAR-X-6\""));
        assertThat(messages(run(), "failed")).singleElement().asString()
                .contains("DEMO-2: the feature says the answer is decided by PAR-X-6 but the register names PAR-X-5");
        feature(stated.replace("golden master \"DEMO-1\"\n", "golden master \"DEMO-1\"\n"
                + "      And the answer is decided by \"PAR-X-5\"\n"));
        assertThat(messages(run(), "failed")).singleElement().asString()
                .contains("DEMO-1: the feature says the answer is decided by PAR-X-5 but the register expects the "
                        + "recording's answer");
    }

    @Test
    void aWriteScenarioStatesItsBodyItsEmptyAnswerAndItsRowsAndEachIsChecked() throws IOException {
        Files.writeString(e2e.resolve("scenarios/demo.json"), """
                { "schemaVersion": "1.1", "mu": "MU-DEMO", "generatedBy": "test",
                  "scenarios": [
                    { "scenarioId": "DEMO-5", "title": "remove-two", "levels": %s, "request": {},
                      "http": { "method": "POST", "path": "/things", "body": { "name": "A", "count": 2 } },
                      "tables": [ { "name": "THING", "query": "SELECT ID FROM THING ORDER BY ID", "columns": ["ID"] } ],
                      "answerEmpty": true } ] }
                """.formatted(LEVEL));
        accept(new GoldenMasterStore(e2e.resolve("golden")), "DEMO-5",
                "{ \"$empty\": true, \"$tables\": { \"THING\": [ { \"ID\": 1 }, { \"ID\": 2 } ] } }");
        String written = """
                @unit:DEMO @lens:service @level:L4
                Feature: DEMO - POST /things

                  @DEMO-5
                  Scenario: DEMO-5 remove-two
                    Given the request body:
                      \"\"\"json
                      { "name": "A", "count": 2 }
                      \"\"\"
                    When the client sends POST /things
                    Then the answer matches the accepted golden master "DEMO-5"
                    And the golden master holds status 200 with an empty answer
                    And the golden master holds 2 rows in THING
                """;
        feature(written);
        assertThat(messages(run(), "failed")).isEmpty();

        feature(written.replace("\"count\": 2", "\"count\": 3"));
        assertThat(messages(run(), "failed")).singleElement().asString()
                .contains("the feature's request body differs from the register's");
        feature(written.replace("2 rows in THING", "3 rows in THING"));
        assertThat(messages(run(), "failed")).singleElement().asString()
                .contains("holds 3 row(s) in THING but it holds 2");
        feature(written.replace("2 rows in THING", "2 rows in OTHER"));
        assertThat(messages(run(), "failed")).singleElement().asString()
                .contains("names the table OTHER but the register checks no such table");
        feature(written.replace("{ \"name\"", "{ \"name\": oops, \"x\""));
        assertThat(messages(run(), "failed")).singleElement().asString().contains("is not JSON");
    }

    private void feature(String text) throws IOException {
        Files.writeString(e2e.resolve("features/demo.feature"), text);
    }

    private EngineExecutionResults run() {
        return run("pretty");
    }

    private EngineExecutionResults run(String plugins) {
        return EngineTestKit.engine("cucumber")
                .selectors(selectDirectory(e2e.resolve("features").toFile()))
                .configurationParameter(GLUE_PROPERTY_NAME, E2eCucumber.GLUE)
                .configurationParameter("cucumber.plugin", plugins)
                .execute();
    }

    private static List<String> messages(EngineExecutionResults results, String kind) {
        return results.testEvents().list().stream()
                .filter(e -> e.getType().name().equals("FINISHED"))
                .map(Event::getPayload)
                .flatMap(p -> p.stream())
                .filter(p -> p instanceof org.junit.platform.engine.TestExecutionResult)
                .map(org.junit.platform.engine.TestExecutionResult.class::cast)
                .filter(r -> r.getStatus().name().equalsIgnoreCase(kind)
                        || "failed".equals(kind) && r.getStatus() == org.junit.platform.engine.TestExecutionResult.Status.FAILED)
                .map(r -> r.getThrowable().map(Throwable::getMessage).orElse(""))
                .toList();
    }

    private static void accept(GoldenMasterStore store, String id, String payload) throws IOException {
        Provenance provenance = new Provenance("gnucobol-emulated", "synthetic package", null, null, null, Map.of(),
                null, null, null, Map.of(), "logic", "2026-10-09", 1);
        GoldenMaster recorded = GoldenMaster.recorded(id, "DEMO", "L4", "service", Map.of(),
                Observation.targetPayload(JsonSupport.mapper().readTree(payload), Outcome.ok(200L)), Map.of(), provenance,
                "test", "2026-10-12T00:00:00Z", null);
        store.writeNew(recorded);
        store.updateLifecycle(Lifecycle.transition(recorded, LifecycleState.ACCEPTED, "test reviewer", "record gate",
                "PKG-CMP-DEMO", "2026-10-12T01:00:00Z"));
    }
}
