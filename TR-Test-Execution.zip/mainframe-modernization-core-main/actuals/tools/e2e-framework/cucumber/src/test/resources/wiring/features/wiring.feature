@capability:demo-lookup @mu:demo
Feature: Wiring of the Behaviour Specification hooks
  A synthetic feature that only proves the runtime: engine, glue and Spring injection.

  Rule: The list starts at the first code equal to or after the search value
    Example: A code that does not exist returns the codes after it
      Given the colour codes are configured
      When an operator asks for codes starting at "A"
      Then the list shows "B, C, P"
