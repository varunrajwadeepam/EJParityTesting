package com.insurance.e2e.cucumber.glue;

import com.insurance.e2e.core.compare.ComparisonResult;
import com.insurance.e2e.core.compare.FieldDiff;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.observation.Outcome;
import com.insurance.e2e.core.run.ScenarioReport;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

class FailureDetailTest {

    private static FieldDiff diff(String field, String legacy, String target) {
        return new FieldDiff(field, FieldDiff.Kind.VALUE, legacy, target, "VALUE", "U|" + field + "|VALUE:VALUE");
    }

    private static ComparisonResult result(String profile, List<FieldDiff> diffs, List<String> notes) {
        return new ComparisonResult("TC-1", "U", "L4", profile, ComparisonResult.Status.DIFF, 10, 10 - diffs.size(),
                diffs, notes, Set.of(), List.of());
    }

    private static ScenarioReport report(ComparisonResult strict, ComparisonResult contract, String verdict,
                                         ScenarioReport.TargetAnswer target) {
        return new ScenarioReport("TC-1", "L4", "U", "REPLAY", ScenarioReport.Status.FAILED, "DIFF under contract",
                strict, contract, verdict, List.of(), "service", "t", List.of(), target);
    }

    @Test
    void theDifferencesListTheDecidingComparisonWholeAndWhatOnlyTheOtherReports() {
        ComparisonResult contract = result("contract", List.of(diff("a", "1", "2"), diff("b", "x", "y")),
                List.of("not compared (profile contract): effectiveDate"));
        ComparisonResult strict = result("strict", List.of(diff("a", "1", "2"), diff("b", "x", "y"),
                diff("effectiveDate", "0", "20240816")), List.of());

        String text = FailureDetail.differences(report(strict, contract, "contract", null));

        assertThat(text).startsWith("TC-1 L4 FAILED - the contract comparison decided: 2 difference(s), 10 value(s) "
                + "compared, 8 equal\n\na VALUE legacy='1' target='2' (VALUE)\nb VALUE legacy='x' target='y' (VALUE)\n");
        assertThat(text).contains("Notes:\n- not compared (profile contract): effectiveDate\n");
        assertThat(text).endsWith("The strict comparison (not deciding): 3 difference(s), 1 not above:\n"
                + "effectiveDate VALUE legacy='0' target='20240816' (VALUE)\n");
        assertThat(FailureDetail.differences(report(strict, contract, "strict", null)))
                .as("strict decided: the contract's are all among them")
                .contains("the strict comparison decided: 3 difference(s)",
                        "The contract comparison (not deciding): 2 difference(s), none other than above");
        assertThat(FailureDetail.differences(new ScenarioReport("TC-1", "L4", "U", "REPLAY",
                ScenarioReport.Status.FAILED, "the target failed", null, null, null, List.of())))
                .isEqualTo("TC-1 L4 FAILED: the target failed\n");
    }

    @Test
    void theActualAnswerIsWholeJsonOrItsTextAndACutOneSaysSo() throws Exception {
        ScenarioReport.TargetAnswer json = new ScenarioReport.TargetAnswer(Outcome.ok(200L),
                Map.of("http.status", "200"), "{\"items\":[{\"code\":\"A\"}]}", false);
        ScenarioReport.TargetAnswer text = new ScenarioReport.TargetAnswer(Outcome.ok(200L), Map.of(),
                "{\"items\":[{\"code\":\"A\"", true);

        assertThat(JsonSupport.mapper().readTree(FailureDetail.actual(json)).get("answer").get("items").get(0)
                .get("code").asText()).isEqualTo("A");
        assertThat(FailureDetail.actual(json)).as("pretty-printed").contains("\n");
        var cut = JsonSupport.mapper().readTree(FailureDetail.actual(text));
        assertThat(cut.get("answer").asText()).isEqualTo("{\"items\":[{\"code\":\"A\"");
        assertThat(cut.get("truncated").asText()).contains("cut after");
        assertThat(FailureDetail.of(report(null, null, null, json), null, "")).extracting(FailureDetail.Attachment::name)
                .as("no golden master found: the other two").containsExactly("All differences (0)",
                        "Actual answer - the application");
    }

    @Test
    void anAttachmentBeyondItsLimitIsCutAsTextAndSaysSo() {
        String big = "x".repeat(FailureDetail.ATTACHMENT_LIMIT + 10);
        FailureDetail.Attachment cut = FailureDetail.cut(new FailureDetail.Attachment("n", FailureDetail.JSON, big));
        FailureDetail.Attachment kept = FailureDetail.cut(new FailureDetail.Attachment("n", FailureDetail.JSON, "{}"));

        assertThat(cut.mediaType()).isEqualTo(FailureDetail.TEXT);
        assertThat(cut.content().indexOf('\n')).as("cut exactly at the limit").isEqualTo(FailureDetail.ATTACHMENT_LIMIT);
        assertThat(cut.content()).endsWith("the E2E run report holds the whole)");
        assertThat(kept.content()).isEqualTo("{}");
        assertThat(kept.mediaType()).isEqualTo(FailureDetail.JSON);
    }
}
