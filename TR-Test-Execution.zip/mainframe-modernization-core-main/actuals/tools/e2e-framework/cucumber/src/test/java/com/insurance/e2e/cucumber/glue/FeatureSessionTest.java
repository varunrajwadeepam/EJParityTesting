package com.insurance.e2e.cucumber.glue;

import com.insurance.e2e.core.E2eException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class FeatureSessionTest {

    @Test
    void aFeatureBelongsToTheRootThatHoldsItsFeaturesFolder(@TempDir Path dir) throws Exception {
        Path nested = Files.createDirectories(dir.resolve("e2e/features/unit"));
        Path feature = Files.writeString(nested.resolve("a.feature"), "Feature: a\n");

        assertThat(FeatureSession.resourcesOf(feature.toUri())).isEqualTo(dir.resolve("e2e"));
        assertThat(FeatureSession.resourcesOf(URI.create("classpath:wiring/features/wiring.feature")).getFileName())
                .hasToString("wiring");
        assertThatThrownBy(() -> FeatureSession.resourcesOf(dir.resolve("loose.feature").toUri()))
                .isInstanceOf(E2eException.class).hasMessageContaining("is not under a features/ folder");
        assertThatThrownBy(() -> FeatureSession.resourcesOf(URI.create("classpath:no/features/such.feature")))
                .isInstanceOf(E2eException.class).hasMessageContaining("is not a file on the test classpath");
    }

    @Test
    void aReportDescribesTheFailureForItsReader() {
        assertThat(E2eSteps.describe(new com.insurance.e2e.core.run.ScenarioReport("TC-1", "L4", "U", "REPLAY",
                com.insurance.e2e.core.run.ScenarioReport.Status.BLOCKED, "golden master is RECORDED", null, null, null,
                java.util.List.of("a note"))))
                .isEqualTo("TC-1 L4 BLOCKED: golden master is RECORDED\n  notes: a note");
    }
}
