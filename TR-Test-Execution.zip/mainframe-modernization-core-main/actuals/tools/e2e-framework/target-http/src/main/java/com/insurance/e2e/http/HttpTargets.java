package com.insurance.e2e.http;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.spi.Availability;
import com.insurance.e2e.core.spi.ExecutionContext;
import com.insurance.e2e.spring.SpringContexts;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URI;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Where the HTTP binding sends its requests: a configured base URL - {@code e2e.http.<ref>.base-url}, then
 * {@value #BASE_URL} (a deployed instance of the product) - or the product's real application, booted in the test JVM
 * by {@link SpringContexts} with a servlet web server on a random port. A boot that failed is remembered, so one
 * broken start explains every scenario instead of being retried for each.
 *
 * <p>A scenario's path is relative to the application's base path, as a contract's paths are relative to its server
 * URL: the booted application is called under its own {@code server.servlet.context-path} (e.g. {@code /api/shop}),
 * so the replay runs the configuration that is deployed. A configured base URL is used as it is.
 */
final class HttpTargets {

    static final String BASE_URL = "e2e.http.base-url";

    private static final Map<String, String> BOOT_FAILURES = new ConcurrentHashMap<>();

    private HttpTargets() {
    }

    static Optional<String> explicitBaseUrl(String ref, ExecutionContext context) {
        String value = ref == null ? null : context.property("e2e.http." + ref + ".base-url");
        if (value == null) {
            value = context.property(BASE_URL);
        }
        return Optional.ofNullable(value).map(v -> v.endsWith("/") ? v.substring(0, v.length() - 1) : v);
    }

    static String baseUrl(String ref, ExecutionContext context) {
        Optional<String> explicit = explicitBaseUrl(ref, context);
        if (explicit.isPresent()) {
            return explicit.get();
        }
        Environment environment = boot(context).getEnvironment();
        String port = environment.getProperty("local.server.port");
        if (port == null) {
            throw new E2eException("The booted application has no web server (no local.server.port): is it a web "
                    + "application?");
        }
        return "http://localhost:" + port + contextPath(environment.getProperty("server.servlet.context-path"));
    }

    /** The application's base path as a URL prefix: {@code /api/shop}; empty for none, {@code ""} or {@code /}. */
    static String contextPath(String value) {
        String path = value == null ? "" : value.trim();
        while (path.endsWith("/")) {
            path = path.substring(0, path.length() - 1);
        }
        return path.isEmpty() || path.startsWith("/") ? path : "/" + path;
    }

    static ConfigurableApplicationContext boot(ExecutionContext context) {
        String main = SpringContexts.mainClass(context);
        String failure = main == null ? null : BOOT_FAILURES.get(main);
        if (failure != null) {
            throw new E2eException(failure);
        }
        try {
            return SpringContexts.resolve(context, "SERVLET");
        } catch (RuntimeException e) {
            String reason = "the application " + main + " did not start: " + rootMessage(e);
            if (main != null) {
                BOOT_FAILURES.put(main, reason);
            }
            throw new E2eException(reason, e);
        }
    }

    static Availability availability(ExecutionContext context) {
        Optional<String> explicit = explicitBaseUrl(null, context);
        if (explicit.isPresent()) {
            return reachable(explicit.get());
        }
        if (SpringContexts.mainClass(context) == null) {
            return Availability.down("no target: set " + BASE_URL + " (E2E_HTTP_BASE_URL) or add the test basement ("
                    + SpringContexts.BASEMENT_PROPERTIES + ") so that the real application can be booted");
        }
        boolean databaseRequired = !"false".equalsIgnoreCase(context.property("e2e.target.db.required", "true"));
        if (databaseRequired && context.property("e2e.db.url") == null) {
            return Availability.down("E2E_DB_URL is not set: the real application needs the validation database "
                    + "(E2E_DB_URL, E2E_DB_USER, E2E_DB_PASSWORD, E2E_DB_SCHEMA)");
        }
        try {
            boot(context);
            return Availability.up();
        } catch (E2eException e) {
            return Availability.down(e.getMessage());
        }
    }

    static Availability reachable(String baseUrl) {
        try {
            URI uri = URI.create(baseUrl);
            int port = uri.getPort() != -1 ? uri.getPort() : ("https".equalsIgnoreCase(uri.getScheme()) ? 443 : 80);
            try (Socket socket = new Socket()) {
                socket.connect(new InetSocketAddress(uri.getHost(), port), 3000);
                return Availability.up();
            }
        } catch (IOException | IllegalArgumentException e) {
            return Availability.down("target " + baseUrl + " is not reachable: " + e.getMessage());
        }
    }

    static String rootMessage(Throwable error) {
        Throwable root = error;
        while (root.getCause() != null && root.getCause() != root) {
            root = root.getCause();
        }
        return root.getClass().getSimpleName() + (root.getMessage() == null ? "" : ": " + root.getMessage());
    }
}
