package com.insurance.e2e.http;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.TextNode;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.observation.Outcome;
import com.insurance.e2e.core.spi.CapturePlugin;
import com.insurance.e2e.core.spi.TriggerPlugin;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * Target capture of the service lens ({@code TGT-HTTP}): the response as a {@link Observation.Form#TARGET_PAYLOAD}
 * observation - the JSON body (text when it is not JSON) and the HTTP status as the outcome's exit state: kind
 * {@code OK} below 400, {@code BUSINESS_EXCEPTION} for 4xx, {@code TECHNICAL_FAILURE} for 5xx. A request without an
 * answer is a {@code TECHNICAL_FAILURE} without exit state.
 */
public final class HttpCapturePlugin implements CapturePlugin {

    @Override
    public String id() {
        return "http-capture";
    }

    @Override
    public Set<String> kinds() {
        return Set.of(HttpTriggerPlugin.KIND);
    }

    @Override
    public Observation capture(Request request) {
        TriggerPlugin.TriggerResult result = request.result();
        if (result.failure() != null || !(result.payload() instanceof HttpExchange exchange)) {
            Throwable failure = result.failure();
            return new Observation(Observation.Form.TARGET_PAYLOAD, Map.of(), Map.of(),
                    Outcome.failure(failure == null ? "NoResponse" : failure.getClass().getName(),
                            failure == null ? "no response" : HttpTargets.rootMessage(failure)), null, Map.of());
        }
        Map<String, String> meta = new LinkedHashMap<>();
        meta.put("http.status", Integer.toString(exchange.status()));
        meta.put("http.request", exchange.method() + " " + exchange.url());
        if (exchange.contentType() != null && !exchange.contentType().isBlank()) {
            meta.put("http.contentType", exchange.contentType());
        }
        return new Observation(Observation.Form.TARGET_PAYLOAD, Map.of(), Map.of(),
                new Outcome(kind(exchange.status()), (long) exchange.status(), null, null), body(exchange.body()), meta);
    }

    static Outcome.Kind kind(int status) {
        if (status >= 500) {
            return Outcome.Kind.TECHNICAL_FAILURE;
        }
        return status >= 400 ? Outcome.Kind.BUSINESS_EXCEPTION : Outcome.Kind.OK;
    }

    static JsonNode body(String text) {
        if (text == null || text.isBlank()) {
            return null;
        }
        try {
            return JsonSupport.mapper().readTree(text);
        } catch (IOException e) {
            return TextNode.valueOf(text);
        }
    }
}
