package com.insurance.e2e.http.identity;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.spi.ExecutionContext;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HexFormat;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * How the HTTP binding calls as a user: the constitution's {@code target.identity}, given to a run as the JSON of
 * {@value #PROPERTY} (environment {@code E2E_TARGET_IDENTITY}). Mode {@code issuer} makes E2E's own test issuer
 * ({@link TestIdentityIssuer}) sign a token per call; {@code none} (the default) sends no call that is made as a user.
 * It names the application's own settings - never a credential:
 * <pre>
 * { "mode": "issuer", "audience": "e2e-validation", "scope": "e2e.validation", "subject": "e2e-{hex}@e2e.invalid",
 *   "claims": { "scp": ["{scope}"], "uid": "{id}" },
 *   "properties": { "app.security.enabled": "true", "app.security.issuer-uri": "{issuer}",
 *                   "app.security.audience": "{audience}", "app.security.scope": "{scope}" },
 *   "callerMap": { "list": "app.r500.identity.mappings", "item": { "email": "{subject}", "user-id": "{id}" } } }
 * </pre>
 * Placeholders: {@code {issuer}} (the test issuer's URL, known once it runs), {@code {audience}}, {@code {scope}},
 * {@code {subject}} (a caller's token subject), {@code {id}} (the legacy's user id as recorded), {@code {hex}} (the
 * upper-case hex of the id's UTF-8 bytes: {@code AB12} and {@code ab12} stay two subjects for an application that
 * compares them without case) and {@code {index}} (the caller's position in {@code e2e/callers.json}).
 */
public record IdentitySettings(String mode, String audience, String scope, String subject, ObjectNode claims,
                               Map<String, String> properties, String callerList, Map<String, String> callerItem) {

    public static final String PROPERTY = "e2e.target.identity";
    public static final String ISSUER_MODE = "issuer";
    static final String DEFAULT_AUDIENCE = "e2e-validation";
    static final String DEFAULT_SCOPE = "e2e.validation";
    static final String DEFAULT_SUBJECT = "e2e-{hex}@e2e.invalid";
    private static final Pattern PLACEHOLDER = Pattern.compile("\\{([a-z]+)}");

    /** The settings of this run, or empty when no call is made as a user ({@code mode} none or nothing configured). */
    public static Optional<IdentitySettings> of(ExecutionContext context) {
        String json = context.property(PROPERTY);
        return json == null ? Optional.empty() : parse(json);
    }

    static Optional<IdentitySettings> parse(String json) {
        JsonNode tree;
        try {
            tree = JsonSupport.mapper().readTree(json);
        } catch (IOException e) {
            throw new E2eException(PROPERTY + " is not a JSON object (the constitution's target.identity): " + json, e);
        }
        if (tree == null || !tree.isObject()) {
            throw new E2eException(PROPERTY + " must be a JSON object (the constitution's target.identity), got: " + json);
        }
        String mode = text(tree, "mode", "none");
        if (!ISSUER_MODE.equals(mode)) {
            if (!"none".equals(mode)) {
                throw new E2eException(PROPERTY + ".mode must be issuer or none, got: " + mode);
            }
            return Optional.empty();
        }
        ObjectNode claims;
        if (tree.get("claims") instanceof ObjectNode given) {
            claims = given.deepCopy();
        } else {
            claims = JsonNodeFactory.instance.objectNode();
            claims.putArray("scp").add("{scope}");
        }
        JsonNode callerMap = tree.path("callerMap");
        IdentitySettings settings = new IdentitySettings(mode, text(tree, "audience", DEFAULT_AUDIENCE),
                text(tree, "scope", DEFAULT_SCOPE), text(tree, "subject", DEFAULT_SUBJECT), claims,
                strings(tree.path("properties")), text(callerMap, "list", null), strings(callerMap.path("item")));
        if (settings.properties().isEmpty()) {
            throw new E2eException(PROPERTY + ".properties is empty: name the application's settings that make it trust "
                    + "the test issuer ({issuer}, {audience}, {scope})");
        }
        if (settings.callerList() == null || settings.callerItem().isEmpty()) {
            throw new E2eException(PROPERTY + ".callerMap needs the application's caller map: its list property and "
                    + "the fields of one entry ({subject}, {id})");
        }
        return Optional.of(settings);
    }

    /** The upper-case hex of a user id's UTF-8 bytes - one subject per id, also where case is ignored. */
    static String hex(String id) {
        return HexFormat.of().withUpperCase().formatHex(id.getBytes(StandardCharsets.UTF_8));
    }

    /** A template with its placeholders replaced; an unknown placeholder is an error, never left in. */
    static String resolve(String template, Map<String, String> values) {
        Matcher found = PLACEHOLDER.matcher(template);
        StringBuilder out = new StringBuilder();
        while (found.find()) {
            String value = values.get(found.group(1));
            if (value == null) {
                throw new E2eException(PROPERTY + ": the placeholder {" + found.group(1) + "} of '" + template
                        + "' is not one of " + values.keySet());
            }
            found.appendReplacement(out, Matcher.quoteReplacement(value));
        }
        found.appendTail(out);
        return out.toString();
    }

    /** The claims with their text values resolved (also the text elements of an array). */
    ObjectNode resolvedClaims(Map<String, String> values) {
        ObjectNode out = JsonNodeFactory.instance.objectNode();
        for (Iterator<Map.Entry<String, JsonNode>> it = claims.fields(); it.hasNext(); ) {
            Map.Entry<String, JsonNode> claim = it.next();
            JsonNode value = claim.getValue();
            if (value.isTextual()) {
                out.put(claim.getKey(), resolve(value.asText(), values));
            } else if (value.isArray()) {
                ArrayNode array = out.putArray(claim.getKey());
                value.forEach(e -> {
                    if (e.isTextual()) {
                        array.add(resolve(e.asText(), values));
                    } else {
                        array.add(e);
                    }
                });
            } else {
                out.set(claim.getKey(), value);
            }
        }
        return out;
    }

    private static String text(JsonNode node, String field, String fallback) {
        JsonNode value = node.get(field);
        return value == null || value.isNull() || value.asText().isBlank() ? fallback : value.asText().trim();
    }

    private static Map<String, String> strings(JsonNode node) {
        Map<String, String> out = new LinkedHashMap<>();
        if (node.isObject()) {
            node.fields().forEachRemaining(e -> out.put(e.getKey(), JsonSupport.scalarText(e.getValue())));
        }
        return out;
    }

    @Override
    public String toString() {
        return "IdentitySettings[" + mode.toLowerCase(Locale.ROOT) + ", audience=" + audience + ", scope=" + scope + "]";
    }
}
