package com.insurance.e2e.http.identity;

import com.fasterxml.jackson.databind.JsonNode;
import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.spi.ExecutionContext;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The HTTP binding's caller identity of one run: the {@link IdentitySettings} (the constitution's
 * {@code target.identity}), the users the MU module's calls are made as ({@value #CALLERS}, written by the design
 * import from the packages' {@code request.principal}) and E2E's {@link TestIdentityIssuer}.
 *
 * <p>It gives the application the properties of one boot - its own settings pointed at the test issuer, and its caller
 * map with one entry per user ({@code <list>[<index>].<field>}) - and, per call, the {@code Authorization} header of a
 * token whose subject the application maps to that user. A user id is used exactly as the legacy recorded it.
 */
public final class TestIdentity {

    public static final String CALLERS = "e2e/callers.json";
    private static final Map<String, TestIdentity> CACHE = new ConcurrentHashMap<>();

    private final IdentitySettings settings;
    private final TestIdentityIssuer issuer;
    private final List<String> callers;
    private final Map<String, String> subjects = new LinkedHashMap<>();

    TestIdentity(IdentitySettings settings, List<String> callers, TestIdentityIssuer issuer) {
        this.settings = settings;
        this.issuer = issuer;
        this.callers = List.copyOf(callers);
        Map<String, String> byLowerCase = new LinkedHashMap<>();
        for (int i = 0; i < this.callers.size(); i++) {
            String id = this.callers.get(i);
            String subject = IdentitySettings.resolve(settings.subject(), values(id, i, null));
            String earlier = byLowerCase.putIfAbsent(subject.toLowerCase(Locale.ROOT), id);
            if (earlier != null) {
                throw new E2eException("the users '" + earlier + "' and '" + id + "' would share the token subject '"
                        + subject + "' (an application may compare it without case): put {hex} or {index} into "
                        + IdentitySettings.PROPERTY + ".subject");
            }
            subjects.put(id, subject);
        }
    }

    /** This run's caller identity, or empty when no call is made as a user (no settings, mode none). */
    public static Optional<TestIdentity> of(ExecutionContext context) {
        String json = context.property(IdentitySettings.PROPERTY);
        if (json == null) {
            return Optional.empty();
        }
        ClassLoader loader = loader();
        String key = System.identityHashCode(loader) + "|" + json;
        TestIdentity known = CACHE.get(key);
        if (known != null) {
            return Optional.of(known);
        }
        Optional<IdentitySettings> settings = IdentitySettings.parse(json);
        if (settings.isEmpty()) {
            return Optional.empty();
        }
        TestIdentity identity = new TestIdentity(settings.get(), callers(loader), TestIdentityIssuer.get());
        CACHE.put(key, identity);
        return Optional.of(identity);
    }

    /** Whether calls can be made as this user (it is among the callers). */
    public boolean knows(String principal) {
        return subjects.containsKey(principal);
    }

    public List<String> callers() {
        return callers;
    }

    public String subject(String principal) {
        return subjects.get(principal);
    }

    /** The {@code Authorization} header value of one call made as this user: a fresh token of the test issuer. */
    public String authorization(String principal) {
        int index = callers.indexOf(principal);
        if (index < 0) {
            throw new E2eException("the user '" + principal + "' is not among the callers of " + CALLERS);
        }
        return "Bearer " + issuer.mint(subjects.get(principal), settings.audience(),
                settings.resolvedClaims(values(principal, index, subjects.get(principal))));
    }

    /**
     * The application's properties of a boot: its settings ({@code properties}, placeholders resolved) and the caller
     * map, one entry per user. They win over the run's overrides ({@code target.properties}).
     */
    public Map<String, String> bootProperties() {
        Map<String, String> out = new LinkedHashMap<>();
        Map<String, String> run = values(null, -1, null);
        settings.properties().forEach((key, template) -> out.put(key, IdentitySettings.resolve(template, run)));
        for (int i = 0; i < callers.size(); i++) {
            String id = callers.get(i);
            Map<String, String> values = values(id, i, subjects.get(id));
            for (Map.Entry<String, String> field : settings.callerItem().entrySet()) {
                out.put(settings.callerList() + "[" + i + "]." + field.getKey(),
                        IdentitySettings.resolve(field.getValue(), values));
            }
        }
        return out;
    }

    private Map<String, String> values(String id, int index, String subject) {
        Map<String, String> values = new LinkedHashMap<>();
        values.put("issuer", issuer.issuer());
        values.put("audience", settings.audience());
        values.put("scope", settings.scope());
        if (id != null) {
            values.put("id", id);
            values.put("hex", IdentitySettings.hex(id));
            values.put("index", Integer.toString(index));
        }
        if (subject != null) {
            values.put("subject", subject);
        }
        return values;
    }

    /** The users of {@value #CALLERS} on the test classpath, in order (none when the module has no such file). */
    static List<String> callers(ClassLoader loader) {
        try (InputStream in = loader.getResourceAsStream(CALLERS)) {
            if (in == null) {
                return List.of();
            }
            JsonNode tree = JsonSupport.mapper().readTree(in);
            List<String> ids = new ArrayList<>();
            tree.path("callers").forEach(c -> {
                String id = c.isTextual() ? c.asText() : c.path("id").asText(null);
                if (id != null && !id.isBlank() && !ids.contains(id)) {
                    ids.add(id);
                }
            });
            return ids;
        } catch (IOException e) {
            throw new E2eException("Cannot read " + CALLERS + ": " + e.getMessage(), e);
        }
    }

    private static ClassLoader loader() {
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        return loader == null ? TestIdentity.class.getClassLoader() : loader;
    }
}
