package com.insurance.e2e.http.identity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.json.JsonSupport;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.Signature;
import java.security.interfaces.RSAPublicKey;
import java.util.Arrays;
import java.util.Base64;
import java.util.UUID;
import java.util.concurrent.Executors;

/**
 * E2E's own test issuer: an RSA key made in memory when the first call as a user needs it (never written, never
 * reused by another JVM) and an OpenID provider's two documents on {@code 127.0.0.1} - the discovery
 * ({@code <issuer>/.well-known/openid-configuration}) and the key set ({@code <issuer>/jwks}) - so that an application
 * configured with this issuer validates the tokens it signs with its own, unchanged resource-server chain (issuer,
 * audience, signature, expiry). One per JVM, until the JVM ends.
 *
 * <p>Tokens are signed {@code RS256} and dated on the <strong>real</strong> time, never on the scenario's pinned
 * clock: the application's timestamp validator reads the system clock, not a bean the E2E clock replaces.
 */
public final class TestIdentityIssuer {

    static final String PATH = "/e2e-issuer";
    private static final Base64.Encoder B64 = Base64.getUrlEncoder().withoutPadding();
    private static final ObjectWriter COMPACT = JsonSupport.mapper().writer().without(SerializationFeature.INDENT_OUTPUT);
    private static TestIdentityIssuer instance;

    private final KeyPair keys;
    private final String keyId;
    private final HttpServer server;
    private final String issuer;

    private TestIdentityIssuer() {
        try {
            KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
            generator.initialize(2048);
            keys = generator.generateKeyPair();
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(unsigned(publicKey().getModulus()));
            keyId = "e2e-" + B64.encodeToString(digest).substring(0, 16);
            server = HttpServer.create(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0), 0);
        } catch (GeneralSecurityException | IOException e) {
            throw new E2eException("E2E's test issuer cannot start: " + e.getMessage(), e);
        }
        issuer = "http://127.0.0.1:" + server.getAddress().getPort() + PATH;
        byte[] discovery = JsonSupport.toJson(discovery()).getBytes(StandardCharsets.UTF_8);
        byte[] jwks = JsonSupport.toJson(jwks()).getBytes(StandardCharsets.UTF_8);
        server.createContext(PATH + "/.well-known/openid-configuration", exchange -> send(exchange, discovery));
        server.createContext(PATH + "/jwks", exchange -> send(exchange, jwks));
        server.setExecutor(Executors.newCachedThreadPool(task -> {
            Thread thread = new Thread(task, "e2e-test-issuer");
            thread.setDaemon(true);
            return thread;
        }));
        server.start();
        Runtime.getRuntime().addShutdownHook(new Thread(() -> server.stop(0), "e2e-test-issuer-stop"));
    }

    /** The issuer of this JVM, started on first use. */
    public static synchronized TestIdentityIssuer get() {
        if (instance == null) {
            instance = new TestIdentityIssuer();
        }
        return instance;
    }

    /** The issuer URL: the {@code iss} of its tokens and the base of its two documents (no trailing slash). */
    public String issuer() {
        return issuer;
    }

    public RSAPublicKey publicKey() {
        return (RSAPublicKey) keys.getPublic();
    }

    String keyId() {
        return keyId;
    }

    /**
     * A signed token for one subject: {@code iss}, {@code aud} (the audience as a one-element list), {@code sub},
     * {@code iat}, {@code nbf} (5 s before now), {@code exp} (an hour after), {@code jti}, then the given claims.
     */
    public String mint(String subject, String audience, ObjectNode claims) {
        long now = System.currentTimeMillis() / 1000;
        ObjectNode header = JsonNodeFactory.instance.objectNode().put("alg", "RS256").put("typ", "JWT").put("kid", keyId);
        ObjectNode payload = JsonNodeFactory.instance.objectNode();
        payload.put("iss", issuer);
        payload.putArray("aud").add(audience);
        payload.put("sub", subject);
        payload.put("iat", now);
        payload.put("nbf", now - 5);
        payload.put("exp", now + 3600);
        payload.put("jti", UUID.randomUUID().toString());
        claims.fields().forEachRemaining(e -> payload.set(e.getKey(), e.getValue()));
        String signingInput = part(header) + "." + part(payload);
        try {
            Signature signature = Signature.getInstance("SHA256withRSA");
            signature.initSign(keys.getPrivate());
            signature.update(signingInput.getBytes(StandardCharsets.US_ASCII));
            return signingInput + "." + B64.encodeToString(signature.sign());
        } catch (GeneralSecurityException e) {
            throw new E2eException("E2E's test issuer cannot sign a token: " + e.getMessage(), e);
        }
    }

    ObjectNode discovery() {
        ObjectNode doc = JsonNodeFactory.instance.objectNode();
        doc.put("issuer", issuer);
        doc.put("jwks_uri", issuer + "/jwks");
        doc.putArray("id_token_signing_alg_values_supported").add("RS256");
        doc.putArray("subject_types_supported").add("public");
        doc.putArray("response_types_supported").add("token");
        return doc;
    }

    ObjectNode jwks() {
        ObjectNode doc = JsonNodeFactory.instance.objectNode();
        doc.putArray("keys").addObject()
                .put("kty", "RSA").put("use", "sig").put("alg", "RS256").put("kid", keyId)
                .put("n", B64.encodeToString(unsigned(publicKey().getModulus())))
                .put("e", B64.encodeToString(unsigned(publicKey().getPublicExponent())));
        return doc;
    }

    private static String part(ObjectNode node) {
        try {
            return B64.encodeToString(COMPACT.writeValueAsBytes(node));
        } catch (JsonProcessingException e) {
            throw new E2eException("E2E's test issuer cannot write a token part: " + e.getMessage(), e);
        }
    }

    /** A big integer's bytes without the sign byte (JWK's base64url "n" / "e"). */
    static byte[] unsigned(BigInteger value) {
        byte[] bytes = value.toByteArray();
        return bytes.length > 1 && bytes[0] == 0 ? Arrays.copyOfRange(bytes, 1, bytes.length) : bytes;
    }

    private static void send(HttpExchange exchange, byte[] body) throws IOException {
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        exchange.sendResponseHeaders(200, body.length);
        try (OutputStream out = exchange.getResponseBody()) {
            out.write(body);
        }
    }
}
