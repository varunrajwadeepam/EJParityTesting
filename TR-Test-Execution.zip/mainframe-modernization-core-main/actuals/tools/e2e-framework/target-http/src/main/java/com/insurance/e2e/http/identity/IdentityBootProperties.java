package com.insurance.e2e.http.identity;

import com.insurance.e2e.core.spi.ExecutionContext;
import com.insurance.e2e.spring.BootProperties;

import java.util.Map;

/**
 * The test identity's part of a boot with a web server (the HTTP binding): the application's settings pointed at E2E's
 * test issuer and its caller map ({@link TestIdentity#bootProperties()}). Nothing for a bean binding's boot, and
 * nothing when no call is made as a user.
 */
public final class IdentityBootProperties implements BootProperties {

    @Override
    public Map<String, String> properties(ExecutionContext context, String web) {
        if ("NONE".equalsIgnoreCase(web)) {
            return Map.of();
        }
        return TestIdentity.of(context).map(TestIdentity::bootProperties).orElse(Map.of());
    }
}
