package com.insurance.e2e.http;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.scenario.HttpRequestSpec;
import com.insurance.e2e.core.scenario.Scenario;
import com.insurance.e2e.core.spi.Availability;
import com.insurance.e2e.core.spi.BlockedCall;
import com.insurance.e2e.core.spi.ExecutionContext;
import com.insurance.e2e.core.spi.TriggerPlugin;
import com.insurance.e2e.http.identity.TestIdentity;
import com.insurance.e2e.spring.E2eClock;
import com.insurance.e2e.spring.SpringContexts;
import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.util.Map;
import java.util.Set;

/**
 * Target trigger of the service lens ({@code TGT-HTTP}): sends the scenario's {@code http} request to the migrated
 * application's API (see {@link HttpTargets} for where) and hands the status and body to the capture.
 *
 * <ul>
 *   <li>the path is sent exactly as the scenario writes it (already percent-encoded); query names and values are
 *       raw in the scenario and encoded here, in order; nothing else is added to the request;</li>
 *   <li>before the request the {@link E2eClock} is pinned to the scenario's {@code clock} (released when it has
 *       none) - effective for an application booted in this JVM;</li>
 *   <li>a request that gets no answer (connection refused, timeout) is a result with a failure - the comparison shows
 *       it - never an exception that would end the run.</li>
 * </ul>
 */
public final class HttpTriggerPlugin implements TriggerPlugin {

    public static final String KIND = "TGT-HTTP";
    static final String TIMEOUT_SECONDS = "e2e.http.timeout.seconds";

    @Override
    public String id() {
        return "http-trigger";
    }

    @Override
    public Set<String> kinds() {
        return Set.of(KIND);
    }

    @Override
    public Availability availability(ExecutionContext context) {
        return HttpTargets.availability(context);
    }

    @Override
    public TriggerResult trigger(Request request) {
        Scenario scenario = request.scenario();
        HttpRequestSpec http = scenario.http();
        if (http == null) {
            throw new E2eException("Scenario " + scenario.scenarioId() + " has no http request: a " + KIND
                    + " level needs one");
        }
        String authorization = authorization(scenario, request.context());
        String base = HttpTargets.baseUrl(request.binding().ref(), request.context());
        pinClock(scenario, request.context());
        String target = http.target();
        try {
            RequestSpecification spec = RestAssured.given()
                    .config(config(request.context()))
                    .urlEncodingEnabled(false)
                    .baseUri(base)
                    .redirects().follow(false);
            http.headers().forEach(spec::header);
            if (authorization != null) {
                spec.header("Authorization", authorization);
            }
            if (http.body() != null && !http.body().isNull()) {
                spec.contentType(ContentType.JSON).body(http.body().toString());
            }
            Response response = spec.request(http.method(), target);
            return new TriggerResult(request.binding(), new HttpExchange(http.method(), base + target,
                    response.statusCode(), response.contentType(), response.asString()), null, Map.of());
        } catch (Exception e) { // REST-assured (Groovy) also throws checked exceptions such as ConnectException
            return new TriggerResult(request.binding(), null, e, Map.of());
        }
    }

    /**
     * The {@code Authorization} header of a call made as a user ({@link HttpRequestSpec#principal()}): a token of E2E's
     * test identity for that user; {@code null} for a call with no caller. A call that is made as a user is never sent
     * without its user (anonymously, or as another): with no caller identity configured, or a user missing from the
     * MU module's callers, the scenario is BLOCKED.
     */
    static String authorization(Scenario scenario, ExecutionContext context) {
        String principal = scenario.http().principal();
        if (principal == null) {
            return null;
        }
        TestIdentity identity = TestIdentity.of(context).orElseThrow(() -> new BlockedCall("needs the caller identity: "
                + "the call is made as the user '" + principal + "' (request.principal) and no caller identity is "
                + "configured - it is never sent without its user", "/e2e.constitution (target.identity)"));
        if (!identity.knows(principal)) {
            throw new BlockedCall("needs the caller identity: the user '" + principal + "' is not among the callers of "
                    + TestIdentity.CALLERS, "the design stage (e2e_package import writes " + TestIdentity.CALLERS + ")");
        }
        return identity.authorization(principal);
    }

    /** The encoded query string, {@code ?a=1&b=} - empty when there are no parameters (one encoding for all). */
    static String query(Map<String, String> parameters) {
        return HttpRequestSpec.encodedQuery(parameters);
    }

    static void pinClock(Scenario scenario, ExecutionContext context) {
        if (!SpringContexts.pinClock(context)) {
            return;
        }
        if (scenario.clock() == null) {
            E2eClock.instance().release();
        } else {
            E2eClock.instance().pin(scenario.clock(), SpringContexts.frozenClock(context));
        }
    }

    private static RestAssuredConfig config(ExecutionContext context) {
        int millis = Integer.parseInt(context.property(TIMEOUT_SECONDS, "120")) * 1000;
        return RestAssuredConfig.config().httpClient(HttpClientConfig.httpClientConfig()
                .setParam("http.connection.timeout", 10_000)
                .setParam("http.socket.timeout", millis));
    }
}
