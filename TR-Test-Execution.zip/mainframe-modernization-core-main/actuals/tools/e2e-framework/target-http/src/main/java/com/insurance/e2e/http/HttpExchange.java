package com.insurance.e2e.http;

/**
 * One HTTP request and its answer, as the trigger hands it to the capture.
 *
 * @param url         the request as sent (base URL, path and encoded query)
 * @param contentType the response's content type, if any
 * @param body        the response body as text
 */
public record HttpExchange(String method, String url, int status, String contentType, String body) {
}
