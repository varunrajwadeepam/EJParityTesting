package com.insurance.e2e.http;

import com.insurance.e2e.core.scenario.Scenario;
import com.insurance.e2e.core.spi.ExecutionContext;

/** Test access to the HTTP trigger's caller rule from the identity package's tests. */
public final class HttpTriggerPluginAccess {

    private HttpTriggerPluginAccess() {
    }

    public static String authorization(Scenario scenario, ExecutionContext context) {
        return HttpTriggerPlugin.authorization(scenario, context);
    }
}
