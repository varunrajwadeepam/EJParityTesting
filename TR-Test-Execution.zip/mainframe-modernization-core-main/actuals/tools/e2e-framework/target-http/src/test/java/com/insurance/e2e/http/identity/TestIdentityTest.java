package com.insurance.e2e.http.identity;

import com.fasterxml.jackson.databind.JsonNode;
import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.scenario.HttpRequestSpec;
import com.insurance.e2e.core.scenario.Scenario;
import com.insurance.e2e.core.spi.BlockedCall;
import com.insurance.e2e.core.spi.ExecutionContext;
import org.junit.jupiter.api.Test;
import org.springframework.security.oauth2.core.DelegatingOAuth2TokenValidator;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtClaimNames;
import org.springframework.security.oauth2.jwt.JwtClaimValidator;
import org.springframework.security.oauth2.jwt.JwtException;
import org.springframework.security.oauth2.jwt.JwtValidators;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;

import java.math.BigInteger;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.Signature;
import java.time.Instant;
import java.util.Base64;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class TestIdentityTest {

    static final String R500 = """
            { "mode": "issuer", "claims": { "scp": ["{scope}"], "uid": "{id}" },
              "properties": { "app.security.enabled": "true", "app.security.issuer-uri": "{issuer}",
                              "app.security.audience": "{audience}", "app.security.scope": "{scope}" },
              "callerMap": { "list": "app.r500.identity.mappings", "item": { "email": "{subject}", "user-id": "{id}" } } }""";

    private static IdentitySettings settings(String json) {
        return IdentitySettings.parse(json).orElseThrow();
    }

    private static TestIdentity identity(String json, String... callers) {
        return new TestIdentity(settings(json), List.of(callers), TestIdentityIssuer.get());
    }

    @Test
    void settingsHaveDefaultsAndNoneMeansNoCallAsAUser() {
        IdentitySettings r500 = settings(R500);
        assertThat(r500.audience()).isEqualTo("e2e-validation");
        assertThat(r500.scope()).isEqualTo("e2e.validation");
        assertThat(r500.subject()).isEqualTo("e2e-{hex}@e2e.invalid");
        assertThat(IdentitySettings.parse("{\"mode\":\"none\"}")).isEmpty();
        assertThat(IdentitySettings.parse("{}")).isEmpty();
        assertThatThrownBy(() -> IdentitySettings.parse("{\"mode\":\"oidc\"}")).hasMessageContaining("issuer or none");
        assertThatThrownBy(() -> IdentitySettings.parse("{\"mode\":\"issuer\",\"callerMap\":{\"list\":\"a\",\"item\":{\"b\":\"{id}\"}}}"))
                .hasMessageContaining("properties is empty");
        assertThatThrownBy(() -> IdentitySettings.parse("{\"mode\":\"issuer\",\"properties\":{\"a\":\"{issuer}\"}}"))
                .hasMessageContaining("callerMap");
        assertThatThrownBy(() -> IdentitySettings.parse("[1]")).isInstanceOf(E2eException.class);
    }

    @Test
    void theHexOfAUserIdKeepsUsersApartThatDifferOnlyInCase() {
        assertThat(IdentitySettings.hex("AB12")).isEqualTo("41423132");
        assertThat(IdentitySettings.hex("ab12")).isEqualTo("61623132");
        TestIdentity both = identity(R500, "AB12", "ab12");
        assertThat(both.subject("AB12")).isEqualTo("e2e-41423132@e2e.invalid");
        assertThat(both.subject("ab12")).isEqualTo("e2e-61623132@e2e.invalid");
        assertThatThrownBy(() -> identity(R500.replace("\"mode\": \"issuer\",", "\"mode\": \"issuer\", \"subject\": \"{id}@x\","),
                "AB12", "ab12")).hasMessageContaining("would share the token subject");
        assertThatThrownBy(() -> IdentitySettings.resolve("{nope}", Map.of("id", "x")))
                .hasMessageContaining("placeholder {nope}");
    }

    @Test
    void theBootPropertiesPointTheApplicationAtTheTestIssuerAndMapEveryCaller() {
        TestIdentity identity = identity(R500, "AB12", "ab12");
        Map<String, String> properties = identity.bootProperties();

        assertThat(properties).containsEntry("app.security.enabled", "true")
                .containsEntry("app.security.issuer-uri", TestIdentityIssuer.get().issuer())
                .containsEntry("app.security.audience", "e2e-validation")
                .containsEntry("app.security.scope", "e2e.validation")
                .containsEntry("app.r500.identity.mappings[0].email", "e2e-41423132@e2e.invalid")
                .containsEntry("app.r500.identity.mappings[0].user-id", "AB12")
                .containsEntry("app.r500.identity.mappings[1].user-id", "ab12");
        assertThat(TestIdentityIssuer.get().issuer()).startsWith("http://127.0.0.1:").endsWith("/e2e-issuer");
    }

    @Test
    void aTokenIsSignedByTheTestIssuerOnTheRealTimeForTheCallersSubject() throws Exception {
        TestIdentity identity = identity(R500, "AB12");
        String token = identity.authorization("AB12").substring("Bearer ".length());
        String[] parts = token.split("\\.");

        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initVerify(TestIdentityIssuer.get().publicKey());
        signature.update((parts[0] + "." + parts[1]).getBytes(StandardCharsets.US_ASCII));
        assertThat(signature.verify(Base64.getUrlDecoder().decode(parts[2]))).isTrue();

        JsonNode header = JsonSupport.mapper().readTree(Base64.getUrlDecoder().decode(parts[0]));
        JsonNode payload = JsonSupport.mapper().readTree(Base64.getUrlDecoder().decode(parts[1]));
        assertThat(header.path("alg").asText()).isEqualTo("RS256");
        assertThat(header.path("kid").asText()).isEqualTo(TestIdentityIssuer.get().keyId());
        assertThat(payload.path("iss").asText()).isEqualTo(TestIdentityIssuer.get().issuer());
        assertThat(payload.path("aud").get(0).asText()).isEqualTo("e2e-validation");
        assertThat(payload.path("sub").asText()).isEqualTo("e2e-41423132@e2e.invalid");
        assertThat(payload.path("scp").get(0).asText()).isEqualTo("e2e.validation");
        assertThat(payload.path("uid").asText()).isEqualTo("AB12");
        assertThat(payload.path("exp").asLong()).isGreaterThan(Instant.now().getEpochSecond());
        assertThat(token).doesNotContain(" ").as("compact parts");
        assertThatThrownBy(() -> identity.authorization("ZZ99")).hasMessageContaining("not among the callers");
    }

    @Test
    void theIssuerPublishesItsDiscoveryAndItsKeySet() throws Exception {
        TestIdentityIssuer issuer = TestIdentityIssuer.get();
        HttpClient client = HttpClient.newHttpClient();
        JsonNode discovery = JsonSupport.mapper().readTree(client.send(HttpRequest.newBuilder(
                URI.create(issuer.issuer() + "/.well-known/openid-configuration")).build(),
                HttpResponse.BodyHandlers.ofString()).body());
        assertThat(discovery.path("issuer").asText()).isEqualTo(issuer.issuer());
        JsonNode keys = JsonSupport.mapper().readTree(client.send(HttpRequest.newBuilder(
                URI.create(discovery.path("jwks_uri").asText())).build(), HttpResponse.BodyHandlers.ofString()).body());
        JsonNode key = keys.path("keys").get(0);
        assertThat(key.path("kid").asText()).isEqualTo(issuer.keyId());
        assertThat(new BigInteger(1, Base64.getUrlDecoder().decode(key.path("n").asText())))
                .isEqualTo(issuer.publicKey().getModulus());
    }

    @Test
    void aResourceServerConfiguredWithTheTestIssuerAcceptsItsTokensAndRefusesAnotherAudience() {
        String issuer = TestIdentityIssuer.get().issuer();
        String token = identity(R500, "AB12").authorization("AB12").substring("Bearer ".length());
        Jwt jwt = decoder(issuer, "e2e-validation").decode(token);       // as the product's JwtDecoderConfig decodes

        assertThat(jwt.getSubject()).isEqualTo("e2e-41423132@e2e.invalid");
        assertThat(jwt.getClaimAsStringList("scp")).containsExactly("e2e.validation");
        assertThatThrownBy(() -> decoder(issuer, "api://another").decode(token)).isInstanceOf(JwtException.class);
    }

    private static NimbusJwtDecoder decoder(String issuer, String audience) {
        NimbusJwtDecoder decoder = NimbusJwtDecoder.withIssuerLocation(issuer).build();
        decoder.setJwtValidator(new DelegatingOAuth2TokenValidator<>(JwtValidators.createDefaultWithIssuer(issuer),
                new JwtClaimValidator<List<String>>(JwtClaimNames.AUD, aud -> aud != null && aud.contains(audience))));
        return decoder;
    }

    @Test
    void aCallMadeAsAUserIsNeverSentWithoutItsUser() {
        Scenario asUser = scenario("AB12");
        ExecutionContext none = ExecutionContext.builder().environment(Map.of()).build();
        assertThatThrownBy(() -> com.insurance.e2e.http.HttpTriggerPluginAccess.authorization(asUser, none))
                .isInstanceOf(BlockedCall.class).hasMessageContaining("needs the caller identity")
                .satisfies(e -> assertThat(((BlockedCall) e).owner()).contains("target.identity"));
        ExecutionContext configured = ExecutionContext.builder().environment(Map.of("E2E_TARGET_IDENTITY", R500)).build();
        assertThatThrownBy(() -> com.insurance.e2e.http.HttpTriggerPluginAccess.authorization(asUser, configured))
                .as("no e2e/callers.json on this classpath").isInstanceOf(BlockedCall.class)
                .hasMessageContaining("not among the callers");
        assertThat(com.insurance.e2e.http.HttpTriggerPluginAccess.authorization(scenario(null), none)).isNull();
    }

    private static Scenario scenario(String principal) {
        return new Scenario("S", null, null, null, null, null, null, null, null, null, null, null, null, null, null,
                null, null, null, null, null, null, null, null, null,
                new HttpRequestSpec("GET", "/x", null, null, null, principal), null, null);
    }
}
