package com.insurance.e2e.http.demo;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.Clock;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Synthetic web application for the HTTP-binding tests (stands in for a product's REST API). */
@SpringBootApplication
public class DemoWebApplication {

    @Configuration
    public static class ClockConfiguration {
        @Bean
        public Clock clock() {
            return Clock.systemDefaultZone();
        }
    }

    @RestController
    public static class CodesController {

        private final Clock clock;
        private final String flag;

        public CodesController(Clock clock, @Value("${demo.flag:off}") String flag) {
            this.clock = clock;
            this.flag = flag;
        }

        @GetMapping("/codes/{table}")
        public ResponseEntity<Map<String, Object>> codes(@PathVariable String table,
                                                         @RequestParam(defaultValue = "") String searchValue,
                                                         HttpServletRequest request) {
            if ("DOWN".equals(table)) {
                return ResponseEntity.status(503).body(Map.of("status", 503, "error", "Service Unavailable"));
            }
            if ("BAD".equals(table)) {
                return ResponseEntity.badRequest().body(Map.of("status", 400, "error", "Bad Request"));
            }
            Map<String, Object> body = new LinkedHashMap<>();
            body.put("table", table);
            body.put("searchValue", searchValue);
            body.put("today", LocalDate.now(clock).toString());
            body.put("flag", flag);
            body.put("uri", request.getRequestURI());
            body.put("query", request.getQueryString());
            body.put("items", List.of(Map.of("code", "A    ", "text", "ANNUAL"), Map.of("code", "C    ", "text", "CONTINUOUS")));
            return ResponseEntity.ok(body);
        }

        @GetMapping(value = "/text", produces = "text/plain")
        public String text() {
            return "plain words";
        }
    }
}
