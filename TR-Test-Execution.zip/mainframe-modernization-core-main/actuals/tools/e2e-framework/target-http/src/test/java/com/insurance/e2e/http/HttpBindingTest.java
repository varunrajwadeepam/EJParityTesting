package com.insurance.e2e.http;

import com.fasterxml.jackson.databind.JsonNode;
import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.compare.FieldComparePlugin;
import com.insurance.e2e.core.compare.FieldMapping;
import com.insurance.e2e.core.compare.FieldType;
import com.insurance.e2e.core.compare.GroupMapping;
import com.insurance.e2e.core.compare.MappingRepository;
import com.insurance.e2e.core.compare.ProfileSet;
import com.insurance.e2e.core.compare.ViewMapping;
import com.insurance.e2e.core.golden.GoldenMaster;
import com.insurance.e2e.core.golden.GoldenMasterStore;
import com.insurance.e2e.core.golden.Lifecycle;
import com.insurance.e2e.core.golden.LifecycleState;
import com.insurance.e2e.core.golden.Provenance;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.observation.Outcome;
import com.insurance.e2e.core.run.E2eMode;
import com.insurance.e2e.core.run.ProvenanceSource;
import com.insurance.e2e.core.run.ScenarioReport;
import com.insurance.e2e.core.run.ScenarioRunner;
import com.insurance.e2e.core.scenario.BindingRef;
import com.insurance.e2e.core.scenario.CompareSpec;
import com.insurance.e2e.core.scenario.HttpRequestSpec;
import com.insurance.e2e.core.scenario.LevelBinding;
import com.insurance.e2e.core.scenario.Scenario;
import com.insurance.e2e.core.spi.CapturePlugin;
import com.insurance.e2e.core.spi.ExecutionContext;
import com.insurance.e2e.core.spi.PluginRegistry;
import com.insurance.e2e.core.spi.TriggerPlugin;
import com.insurance.e2e.http.demo.DemoWebApplication;
import com.insurance.e2e.spring.E2eClock;
import com.insurance.e2e.spring.SpringContexts;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class HttpBindingTest {

    static final LevelBinding LEVEL = new LevelBinding(null, BindingRef.parse("LEG-SP:DEMO0001"),
            BindingRef.parse("TGT-HTTP:app"), "DEMO0001");

    /** Not a web application: a servlet boot of it fails. */
    @Configuration
    public static class BrokenApplication {
    }

    private final HttpTriggerPlugin trigger = new HttpTriggerPlugin();
    private final HttpCapturePlugin capture = new HttpCapturePlugin();

    @AfterEach
    void releaseClock() {
        E2eClock.instance().release();
    }

    @AfterAll
    static void close() {
        SpringContexts.closeAll();
    }

    static ExecutionContext booting(Map<String, String> extra) {
        Map<String, String> properties = new LinkedHashMap<>();
        properties.put(SpringContexts.MAIN_CLASS, DemoWebApplication.class.getName());
        properties.put(SpringContexts.PROPERTIES, "{\"demo.flag\":\"on\"}");
        properties.put("e2e.target.db.required", "false");
        properties.putAll(extra);
        return ExecutionContext.builder().properties(properties).environment(Map.of()).build();
    }

    static Scenario scenario(String id, String path, Map<String, String> query, String clock) {
        return new Scenario(id, null, null, null, null, null, null, null, null, List.of(LEVEL), null, clock, null,
                Map.of(), null, null, null, id, null, null, null, null, List.of("anticipated: none"), null,
                new HttpRequestSpec("GET", path, query, null, null));
    }

    Observation call(Scenario scenario, ExecutionContext context) {
        TriggerPlugin.TriggerResult result = trigger.trigger(new TriggerPlugin.Request(LEVEL.target(), scenario, null, context));
        return capture.capture(new CapturePlugin.Request(LEVEL.target(), result, scenario, null, context));
    }

    @Test
    void theRequestGoesOverTheWireExactlyAsTheScenarioWritesItAndTheClockIsPinned() {
        Map<String, String> query = new LinkedHashMap<>();
        query.put("searchValue", "");
        query.put("effectiveDate", "0");
        query.put("ctx[0].kind", "DIRECT");
        query.put("text", "A B&C");
        Observation observation = call(scenario("TC-1", "/codes/%20A", query, "20240816103000"), booting(Map.of()));

        JsonNode body = observation.payload();
        assertThat(observation.form()).isEqualTo(Observation.Form.TARGET_PAYLOAD);
        assertThat(observation.outcome().kind()).isEqualTo(Outcome.Kind.OK);
        assertThat(observation.outcome().exitState()).isEqualTo(200L);
        assertThat(body.get("uri").asText()).isEqualTo("/codes/%20A");
        assertThat(body.get("table").asText()).isEqualTo(" A");
        assertThat(body.get("query").asText()).isEqualTo("searchValue=&effectiveDate=0&ctx%5B0%5D.kind=DIRECT&text=A+B%26C");
        assertThat(body.get("searchValue").asText()).isEmpty();
        assertThat(body.get("today").asText()).isEqualTo("2024-08-16");
        assertThat(body.get("flag").asText()).isEqualTo("on");
        assertThat(observation.meta()).containsEntry("http.status", "200").containsKey("http.contentType");
        assertThat(observation.meta().get("http.request")).startsWith("GET http://localhost:").endsWith("/codes/%20A?"
                + "searchValue=&effectiveDate=0&ctx%5B0%5D.kind=DIRECT&text=A+B%26C");

        Observation unpinned = call(scenario("TC-2", "/codes/KIND", Map.of(), null), booting(Map.of()));
        assertThat(unpinned.payload().get("today").asText()).isEqualTo(java.time.LocalDate.now().toString());
        assertThat(unpinned.payload().get("query").isNull()).isTrue();
    }

    @Test
    void theScenarioPathIsRelativeToTheApplicationsContextPath() {
        ExecutionContext underBasePath = booting(Map.of(SpringContexts.PROPERTIES,
                "{\"demo.flag\":\"on\",\"server.servlet.context-path\":\"/api/x/\"}"));
        Observation observation = call(scenario("TC-CP", "/codes/KIND", Map.of(), null), underBasePath);

        assertThat(observation.outcome().exitState()).isEqualTo(200L);
        assertThat(observation.payload().get("uri").asText()).isEqualTo("/api/x/codes/KIND");
        assertThat(observation.meta().get("http.request")).startsWith("GET http://localhost:").endsWith("/api/x/codes/KIND");
        assertThat(HttpTargets.contextPath(null)).isEmpty();
        assertThat(HttpTargets.contextPath("")).isEmpty();
        assertThat(HttpTargets.contextPath("/")).isEmpty();
        assertThat(HttpTargets.contextPath("api/shop/")).isEqualTo("/api/shop");
    }

    @Test
    void errorStatusesBecomeOutcomesAndNonJsonBodiesStayText() {
        ExecutionContext context = booting(Map.of());

        Observation down = call(scenario("TC-3", "/codes/DOWN", Map.of(), null), context);
        Observation bad = call(scenario("TC-4", "/codes/BAD", Map.of(), null), context);
        Observation text = call(scenario("TC-5", "/text", Map.of(), null), context);

        assertThat(down.outcome().kind()).isEqualTo(Outcome.Kind.TECHNICAL_FAILURE);
        assertThat(down.outcome().exitState()).isEqualTo(503L);
        assertThat(bad.outcome().kind()).isEqualTo(Outcome.Kind.BUSINESS_EXCEPTION);
        assertThat(bad.outcome().exitState()).isEqualTo(400L);
        assertThat(text.payload().isTextual()).isTrue();
        assertThat(text.payload().asText()).isEqualTo("plain words");
        assertThat(HttpCapturePlugin.body(" ")).isNull();
    }

    @Test
    void anExplicitBaseUrlIsUsedAndCheckedAndAMissingAnswerIsAFailureOutcome() {
        String booted = HttpTargets.baseUrl("app", booting(Map.of()));
        ExecutionContext deployed = ExecutionContext.builder().property("e2e.http.app.base-url", booted + "/")
                .property(SpringContexts.PIN_CLOCK, "false").environment(Map.of()).build();
        ExecutionContext closed = ExecutionContext.builder().property(HttpTargets.BASE_URL, "http://localhost:1")
                .environment(Map.of()).build();

        assertThat(HttpTargets.explicitBaseUrl("app", deployed)).contains(booted);
        assertThat(call(scenario("TC-6", "/codes/KIND", Map.of(), "20240816103000"), deployed)
                .payload().get("table").asText()).isEqualTo("KIND");
        assertThat(E2eClock.instance().pinned()).isFalse();
        assertThat(trigger.availability(closed).available()).isFalse();
        assertThat(trigger.availability(closed).reason()).contains("not reachable");
        assertThat(HttpTargets.reachable("not a url").available()).isFalse();

        Observation noAnswer = call(scenario("TC-7", "/codes/KIND", Map.of(), null), closed);
        assertThat(noAnswer.outcome().kind()).isEqualTo(Outcome.Kind.TECHNICAL_FAILURE);
        assertThat(noAnswer.outcome().exitState()).isNull();
        assertThat(noAnswer.payload()).isNull();
    }

    @Test
    void availabilityExplainsWhatIsMissingAndRemembersAFailedBoot() {
        ExecutionContext nothing = ExecutionContext.builder().environment(Map.of()).build();
        ExecutionContext noDatabase = ExecutionContext.builder()
                .property(SpringContexts.MAIN_CLASS, DemoWebApplication.class.getName()).environment(Map.of()).build();
        ExecutionContext broken = ExecutionContext.builder()
                .property(SpringContexts.MAIN_CLASS, BrokenApplication.class.getName())
                .property("e2e.target.db.required", "false").environment(Map.of()).build();

        assertThat(trigger.availability(nothing).reason()).contains("e2e.http.base-url", "basement");
        assertThat(trigger.availability(noDatabase).reason()).contains("E2E_DB_URL");
        assertThat(trigger.availability(booting(Map.of())).available()).isTrue();
        String first = trigger.availability(broken).reason();
        assertThat(first).contains("did not start", BrokenApplication.class.getName());
        assertThat(trigger.availability(broken).reason()).isEqualTo(first);
        assertThat(trigger.id()).isEqualTo("http-trigger");
        assertThat(capture.id()).isEqualTo("http-capture");
        assertThat(capture.kinds()).containsExactly("TGT-HTTP");
    }

    @Test
    void aScenarioWithoutAnHttpRequestIsRefused() {
        Scenario bare = new Scenario("TC-8", null, null, null, null, null, null, null, null, List.of(LEVEL), null,
                null, null, Map.of(), null, null, null);
        assertThatThrownBy(() -> trigger.trigger(new TriggerPlugin.Request(LEVEL.target(), bare, null, booting(Map.of()))))
                .isInstanceOf(E2eException.class).hasMessageContaining("no http request");
        assertThat(HttpTriggerPlugin.query(Map.of())).isEmpty();
    }

    @Test
    void replayComparesTheApiWithAnAcceptedHttpShapedGoldenMasterUnderTheSignedProfile(@TempDir Path dir) throws IOException {
        GoldenMasterStore store = new GoldenMasterStore(dir.resolve("golden"));
        accept(store, "TC-OK", Observation.targetPayload(read("""
                { "searchValue": "", "today": "2024-08-16",
                  "items": [ { "code": "A", "text": "ANNUAL" }, { "code": "C", "text": "CONTINUOUS" } ] }"""),
                Outcome.ok(200L)));
        accept(store, "TC-DOWN", Observation.targetPayload(read("{ \"status\": 503, \"error\": \"Service Unavailable\" }"),
                new Outcome(Outcome.Kind.TECHNICAL_FAILURE, 503L, null, null)));
        accept(store, "TC-DIFF", Observation.targetPayload(read("""
                { "searchValue": "", "today": "2024-08-16", "items": [ { "code": "A", "text": "ANNUAL" } ] }"""),
                Outcome.ok(200L)));
        JsonSupport.write(dir.resolve("view-mappings").resolve("DEMO0001.json"), new ViewMapping("1.0", "DEMO0001",
                "the API response", List.of(),
                List.of(new FieldMapping("searchValue", "searchValue", FieldType.STRING, true, null),
                        new FieldMapping("today", "today", FieldType.STRING, false, null)),
                List.of(new GroupMapping("items", "items", null,
                        List.of(new FieldMapping("code", "code", FieldType.CODE, false, null),
                                new FieldMapping("text", "text", FieldType.TEXT, false, null)))),
                List.of(), List.of(), null));
        Path profiles = dir.resolve("profiles.json");
        Files.writeString(profiles, """
                { "schemaVersion": "1.0", "profiles": [ { "name": "contract", "rules": [
                  { "rule": "RTRIM", "decision": "PKG-CMP-DEMO0001" },
                  { "rule": "NULL_AS_BLANK", "decision": "PKG-CMP-DEMO0001" },
                  { "rule": "OUTCOME_ONLY_ON_ERROR", "decision": "PKG-CMP-DEMO0001" } ] } ] }""");
        ScenarioRunner runner = new ScenarioRunner(new PluginRegistry().register(trigger).register(capture)
                .register(new FieldComparePlugin()), store, MappingRepository.load(dir.resolve("view-mappings")),
                ProfileSet.load(profiles), booting(Map.of()), ProvenanceSource.fromContext());

        ScenarioReport ok = runner.run(E2eMode.REPLAY, scenario("TC-OK", "/codes/KIND", Map.of(), "20240816103000"), LEVEL);
        ScenarioReport down = runner.run(E2eMode.REPLAY, scenario("TC-DOWN", "/codes/DOWN", Map.of(), "20240816103000"), LEVEL);
        ScenarioReport diff = runner.run(E2eMode.REPLAY, scenario("TC-DIFF", "/codes/KIND", Map.of(), "20240816103000"), LEVEL);

        assertThat(ok.status()).as(ok.message()).isEqualTo(ScenarioReport.Status.PASSED);
        assertThat(ok.strict().status().name()).isEqualTo("DIFF");
        assertThat(down.status()).as(down.message()).isEqualTo(ScenarioReport.Status.PASSED);
        assertThat(down.notes()).anyMatch(n -> n.contains("OUTCOME_ONLY_ON_ERROR"));
        assertThat(diff.status()).isEqualTo(ScenarioReport.Status.FAILED);
        assertThat(diff.message()).contains("items[]", "ROW_COUNT");
        assertThat(diff.hypotheses()).containsExactly("anticipated: none");
        assertThat(diff.lens()).isEqualTo("service");
        assertThat(diff.target().meta()).containsEntry("http.status", "200");
        assertThat(diff.target().meta().get("http.request")).contains("/codes/KIND");
        assertThat(diff.target().payload()).as("the answer the target gave, for triage").contains("\"items\"");
        assertThat(ok.target()).isNull();
    }

    private static void accept(GoldenMasterStore store, String id, Observation expected) {
        Provenance provenance = new Provenance("gnucobol-emulated", "synthetic", null, null, null, Map.of(), null, null,
                "20240816103000", Map.of(), "logic", "2026-10-09", 1);
        GoldenMaster recorded = GoldenMaster.recorded(id, "DEMO0001", "L4", "service", Map.of(), expected, Map.of(),
                provenance, "e2e_package import", "2026-10-12T00:00:00Z", null);
        store.writeNew(recorded);
        store.updateLifecycle(Lifecycle.transition(recorded, LifecycleState.ACCEPTED, "architect", "record gate",
                "PKG-CMP-DEMO0001", "2026-10-12T01:00:00Z"));
    }

    private static JsonNode read(String json) {
        try {
            return JsonSupport.mapper().readTree(json);
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }
}
