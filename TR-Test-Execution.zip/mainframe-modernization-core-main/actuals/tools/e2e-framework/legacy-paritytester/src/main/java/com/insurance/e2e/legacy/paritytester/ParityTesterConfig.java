package com.insurance.e2e.legacy.paritytester;

import com.insurance.e2e.core.spi.ExecutionContext;

import java.net.URI;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Configuration of the parity-tester binding, read from the execution context (properties, then system properties,
 * then the environment: {@code e2e.pt.runner.url} = {@code E2E_PT_RUNNER_URL}).
 *
 * <table>
 *   <tr><th>Property</th><th>Default</th><th>Meaning</th></tr>
 *   <tr><td>{@code e2e.pt.runner.url}</td><td>{@code http://localhost:8080}</td><td>cobol-runner</td></tr>
 *   <tr><td>{@code e2e.pt.catalogue.url}</td><td>{@code http://localhost:8091}</td><td>E2E's own catalogue server</td></tr>
 *   <tr><td>{@code e2e.pt.catalogue.dir}</td><td>-</td><td>the own catalogue on disk (units, sources, drivers)</td></tr>
 *   <tr><td>{@code e2e.pt.shims}</td><td>{@code cagen}</td><td>comma-separated shim trees</td></tr>
 *   <tr><td>{@code e2e.pt.db2.*}</td><td>dsn/database {@code TESTDB}, port {@code 50000}, user {@code db2inst1}</td>
 *       <td>hostname and password have no default: credentials come from the environment only</td></tr>
 *   <tr><td>{@code e2e.pt.exit-state-field}</td><td>{@code PSMGR-EXIT-STATE}</td><td>numeric exit state</td></tr>
 *   <tr><td>{@code e2e.pt.connect.timeout.seconds} / {@code run.timeout.seconds}</td><td>5 / 300</td><td></td></tr>
 * </table>
 */
public record ParityTesterConfig(URI runnerUrl, URI catalogueUrl, Path catalogueDir, List<String> shims,
                                 Db2Connection db2, String exitStateField, Duration connectTimeout,
                                 Duration runTimeout, Map<String, String> env) {

    public ParityTesterConfig {
        shims = shims == null ? List.of() : List.copyOf(shims);
        env = env == null ? Map.of() : Map.copyOf(env);
    }

    public static ParityTesterConfig from(ExecutionContext context) {
        String catalogueDir = context.property("e2e.pt.catalogue.dir");
        Map<String, String> env = new LinkedHashMap<>();
        env.put("GIXSQL_AUTOCOMMIT", context.property("e2e.pt.autocommit", "off"));
        return new ParityTesterConfig(
                URI.create(context.property("e2e.pt.runner.url", "http://localhost:8080")),
                URI.create(context.property("e2e.pt.catalogue.url", "http://localhost:8091")),
                catalogueDir == null ? null : Path.of(catalogueDir),
                Arrays.stream(context.property("e2e.pt.shims", "cagen").split(",")).map(String::trim)
                        .filter(s -> !s.isEmpty()).toList(),
                new Db2Connection(
                        context.property("e2e.pt.db2.dsn", "TESTDB"),
                        context.property("e2e.pt.db2.database", "TESTDB"),
                        context.property("e2e.pt.db2.hostname"),
                        context.property("e2e.pt.db2.port", "50000"),
                        context.property("e2e.pt.db2.user", "db2inst1"),
                        context.property("e2e.pt.db2.password")),
                context.property("e2e.pt.exit-state-field", "PSMGR-EXIT-STATE"),
                Duration.ofSeconds(Long.parseLong(context.property("e2e.pt.connect.timeout.seconds", "5"))),
                Duration.ofSeconds(Long.parseLong(context.property("e2e.pt.run.timeout.seconds", "300"))),
                env);
    }
}
