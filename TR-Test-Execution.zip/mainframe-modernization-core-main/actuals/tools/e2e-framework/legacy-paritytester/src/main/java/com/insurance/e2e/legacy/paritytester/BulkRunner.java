package com.insurance.e2e.legacy.paritytester;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.observation.Outcome;
import com.insurance.e2e.core.scenario.Scenario;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Runs many scenarios of one unit as ONE bulk bundle ({@code tests:}): one build, N sequential runs. The runner does
 * not re-seed between tests, so every scenario of a bulk run must share one fixture and must not write; write paths
 * get one bundle per scenario instead.
 */
public final class BulkRunner {

    private final ParityTesterConfig config;

    public BulkRunner(ParityTesterConfig config) {
        this.config = config;
    }

    /** Scenario ID -> raw legacy observation, in scenario order. */
    public Map<String, Observation> run(String entry, List<Scenario> scenarios) {
        if (scenarios.isEmpty()) {
            return Map.of();
        }
        String fixture = scenarios.get(0).fixture();
        if (scenarios.stream().anyMatch(s -> !Objects.equals(fixture, s.fixture()))) {
            throw new E2eException("A bulk bundle runs on one database state: all scenarios must share one fixture");
        }
        List<BundleSpec.Test> tests = new ArrayList<>();
        for (Scenario scenario : scenarios) {
            tests.add(new BundleSpec.Test(scenario.scenarioId(), scenario.request(),
                    ParityTesterTriggerPlugin.env(config, scenario), List.of()));
        }
        CatalogueUnit unit = new CatalogueUnit(config.catalogueDir(), entry);
        BundleSpec spec = new BundleSpec(entry, entry, null, config.shims(), config.db2(), Map.of(), Map.of(), tests);
        RunResult result = RunnerClient.from(config).run(unit.bundle().spec(spec).build());

        Map<String, Observation> observations = new LinkedHashMap<>();
        for (int i = 0; i < scenarios.size(); i++) {
            String id = scenarios.get(i).scenarioId();
            if (i < result.tests().size()) {
                observations.put(id, result.tests().get(i).toObservation(config.exitStateField()));
            } else {
                observations.put(id, Observation.rawLegacy(Map.of(), Outcome.failure("legacy-run",
                        "not run: " + (result.error() == null ? "the bulk run stopped early" : result.error()))));
            }
        }
        return observations;
    }
}
