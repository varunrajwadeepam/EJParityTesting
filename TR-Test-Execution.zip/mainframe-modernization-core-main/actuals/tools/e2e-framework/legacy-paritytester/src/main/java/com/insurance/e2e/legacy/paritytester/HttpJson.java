package com.insurance.e2e.legacy.paritytester;

import com.fasterxml.jackson.databind.JsonNode;
import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.json.JsonSupport;

import java.io.IOException;
import java.net.ConnectException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.time.Duration;

/** Minimal JSON-over-HTTP helper shared by the runner and catalogue clients (JDK HttpClient, no extra library). */
final class HttpJson {

    /** A response: status, body text, and the body parsed as JSON when it is JSON. */
    record Response(int status, String body, JsonNode json) {
    }

    private final URI base;
    private final HttpClient client;
    private final Duration requestTimeout;

    HttpJson(URI base, Duration connectTimeout, Duration requestTimeout) {
        this.base = base;
        this.requestTimeout = requestTimeout;
        this.client = HttpClient.newBuilder().connectTimeout(connectTimeout).build();
    }

    URI base() {
        return base;
    }

    Response get(String path, Duration timeout) {
        return send(HttpRequest.newBuilder(resolve(path)).timeout(timeout).GET().build());
    }

    Response get(String path) {
        return get(path, requestTimeout);
    }

    Response post(String path, String contentType, byte[] body, Duration timeout) {
        HttpRequest.Builder request = HttpRequest.newBuilder(resolve(path)).timeout(timeout)
                .POST(body == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofByteArray(body));
        if (contentType != null) {
            request.header("Content-Type", contentType);
        }
        return send(request.build());
    }

    Response post(String path, String contentType, byte[] body) {
        return post(path, contentType, body, requestTimeout);
    }

    private URI resolve(String path) {
        String root = base.toString().endsWith("/") ? base.toString().substring(0, base.toString().length() - 1) : base.toString();
        return URI.create(root + path);
    }

    private Response send(HttpRequest request) {
        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            JsonNode json = null;
            String body = response.body();
            if (body != null && !body.isBlank() && (body.startsWith("{") || body.startsWith("["))) {
                try {
                    json = JsonSupport.mapper().readTree(body);
                } catch (IOException ignored) {
                    json = null;
                }
            }
            return new Response(response.statusCode(), body, json);
        } catch (ConnectException e) {
            throw new Unreachable(request.uri() + " refused the connection", e);
        } catch (HttpTimeoutException e) {
            throw new Unreachable(request.uri() + " timed out", e);
        } catch (IOException e) {
            throw new Unreachable(request.uri() + ": " + e.getMessage(), e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new E2eException("Interrupted calling " + request.uri(), e);
        }
    }

    /** The service did not answer at all (connection refused, timeout, I/O). */
    static final class Unreachable extends E2eException {
        Unreachable(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
