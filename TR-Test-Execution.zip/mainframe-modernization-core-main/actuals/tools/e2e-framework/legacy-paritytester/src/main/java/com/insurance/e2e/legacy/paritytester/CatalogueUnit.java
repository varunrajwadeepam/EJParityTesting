package com.insurance.e2e.legacy.paritytester;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.json.JsonSupport;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

/**
 * One unit of E2E's own catalogue on disk - the parity-tester layout {@code <catalogue>/<ENTRY>/sources/*.CBL} and
 * {@code <ENTRY>/driver.cbl}. Bundles are built from here, so a run never depends on the server and the legacy source
 * never enters the test solution.
 */
public record CatalogueUnit(Path catalogue, String entry) {

    public Path dir() {
        return catalogue.resolve(entry);
    }

    public Path sourcesDir() {
        return dir().resolve("sources");
    }

    public Path driverFile() {
        return dir().resolve("driver.cbl");
    }

    /** Problems that prevent building a bundle; empty when the unit is complete. */
    public List<String> problems() {
        if (!Files.isDirectory(dir())) {
            return List.of("unit " + entry + " is not in the catalogue " + catalogue);
        }
        if (members().isEmpty()) {
            return List.of("unit " + entry + " has no sources in " + sourcesDir());
        }
        if (!Files.isRegularFile(driverFile())) {
            return List.of("unit " + entry + " has no generated driver (" + driverFile() + ")");
        }
        return List.of();
    }

    public List<Path> members() {
        if (!Files.isDirectory(sourcesDir())) {
            return List.of();
        }
        try (Stream<Path> files = Files.list(sourcesDir())) {
            return files.filter(Files::isRegularFile).filter(BundleBuilder::isMember).sorted().toList();
        } catch (IOException e) {
            throw new E2eException("Cannot list " + sourcesDir(), e);
        }
    }

    /** Member name -> SHA-256, for the golden masters' provenance. */
    public Map<String, String> sourceHashes() {
        Map<String, String> hashes = new LinkedHashMap<>();
        members().forEach(m -> hashes.put(m.getFileName().toString(), JsonSupport.sha256Hex(m)));
        return hashes;
    }

    public String driverHash() {
        return JsonSupport.sha256Hex(driverFile());
    }

    /** A builder pre-loaded with this unit's sources and driver. */
    public BundleBuilder bundle() {
        List<String> problems = problems();
        if (!problems.isEmpty()) {
            throw new E2eException("Unit " + entry + " cannot be bundled", problems);
        }
        try {
            return new BundleBuilder().sourcesFrom(sourcesDir()).driver(Files.readAllBytes(driverFile()));
        } catch (IOException e) {
            throw new E2eException("Cannot read the driver of " + entry, e);
        }
    }
}
