package com.insurance.e2e.legacy.paritytester;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.scenario.Scenario;
import com.insurance.e2e.core.spi.Availability;
import com.insurance.e2e.core.spi.ExecutionContext;
import com.insurance.e2e.core.spi.TriggerPlugin;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Legacy trigger: runs a unit of E2E's own catalogue through the cobol-runner with the scenario's request as the
 * driver inputs and the scenario's clock pinned ({@code CAGENSHIM_CLOCK}). Serves {@code LEG-SP} (a service point)
 * and {@code LEG-CMP} (an action block onboarded as its own unit). The binding ref is the unit's entry name.
 */
public final class ParityTesterTriggerPlugin implements TriggerPlugin {

    public static final String CLOCK_ENV = "CAGENSHIM_CLOCK";

    @Override
    public String id() {
        return "paritytester-trigger";
    }

    @Override
    public Set<String> kinds() {
        return Set.of("LEG-SP", "LEG-CMP");
    }

    @Override
    public Availability availability(ExecutionContext context) {
        ParityTesterConfig config = ParityTesterConfig.from(context);
        if (config.catalogueDir() == null) {
            return Availability.down("e2e.pt.catalogue.dir is not set (E2E's own parity-tester catalogue)");
        }
        List<String> missing = config.db2().missing();
        if (!missing.isEmpty()) {
            return Availability.down("legacy database connection incomplete: set " + missing.stream()
                    .map(k -> "E2E_PT_DB2_" + k.toUpperCase(java.util.Locale.ROOT)).toList());
        }
        return RunnerClient.from(config).availability();
    }

    @Override
    public TriggerResult trigger(Request request) {
        ParityTesterConfig config = ParityTesterConfig.from(request.context());
        if (config.catalogueDir() == null) {
            throw new E2eException("e2e.pt.catalogue.dir is not set");
        }
        CatalogueUnit unit = new CatalogueUnit(config.catalogueDir(), request.binding().ref());
        BundleSpec spec = new BundleSpec(unit.entry(), unit.entry(), null, config.shims(), config.db2(),
                request.scenario().request(), env(config, request.scenario()), List.of());
        byte[] bundle = unit.bundle().spec(spec).build();
        RunResult result = RunnerClient.from(config).run(bundle);
        return new TriggerResult(request.binding(), result, null, provenance(unit));
    }

    static Map<String, String> env(ParityTesterConfig config, Scenario scenario) {
        Map<String, String> env = new LinkedHashMap<>(config.env());
        if (scenario.clock() != null) {
            env.put(CLOCK_ENV, scenario.clock());
        }
        return env;
    }

    static Map<String, String> provenance(CatalogueUnit unit) {
        Map<String, String> provenance = new LinkedHashMap<>();
        unit.sourceHashes().forEach((member, hash) -> provenance.put("source:" + member, hash));
        provenance.put("driver", unit.driverHash());
        provenance.put("platform", "gnucobol-emulated");
        return provenance;
    }
}
