package com.insurance.e2e.legacy.paritytester;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The database connection the runner puts into a bundle's {@code spec.yaml} (all six keys are required there).
 *
 * <p>{@code hostname} is seen <em>from inside the runner container</em>: it must resolve there (a host IP or a
 * compose service name), which is usually not what the Java side uses ({@code localhost}).
 */
public record Db2Connection(String dsn, String database, String hostname, String port, String user, String password) {

    /** Names of the keys that are not set; empty when the connection is complete. */
    public List<String> missing() {
        List<String> missing = new ArrayList<>();
        Map<String, String> keys = asSpecMap();
        keys.forEach((key, value) -> {
            if (value == null || value.isBlank()) {
                missing.add(key);
            }
        });
        return missing;
    }

    /** The {@code db2:} block of {@code spec.yaml}, in the runner's key order. */
    public Map<String, String> asSpecMap() {
        Map<String, String> map = new LinkedHashMap<>();
        map.put("dsn", dsn);
        map.put("database", database);
        map.put("hostname", hostname);
        map.put("port", port);
        map.put("user", user);
        map.put("password", password);
        return map;
    }

    @Override
    public String toString() {
        return "Db2Connection[" + user + "@" + hostname + ":" + port + "/" + database + ", password=***]";
    }
}
