package com.insurance.e2e.legacy.paritytester;

import com.insurance.e2e.core.E2eException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Builds the zip the runner takes: {@code sources/<MEMBER>} (the unit as delivered, never edited),
 * {@code driver.cbl} and {@code spec.yaml}. Shims are not part of a bundle - they live in the runner image and the
 * spec only names them.
 */
public final class BundleBuilder {

    private final Map<String, byte[]> sources = new TreeMap<>();
    private byte[] driver;
    private BundleSpec spec;

    /** Adds every COBOL member ({@code .CBL}, {@code .CPY}, any case) of {@code dir}, by base name. */
    public BundleBuilder sourcesFrom(Path dir) {
        try (Stream<Path> files = Files.list(dir)) {
            for (Path file : files.filter(Files::isRegularFile).filter(BundleBuilder::isMember).sorted().toList()) {
                source(file.getFileName().toString(), Files.readAllBytes(file));
            }
        } catch (IOException e) {
            throw new E2eException("Cannot read legacy sources in " + dir, e);
        }
        return this;
    }

    public BundleBuilder source(String member, byte[] content) {
        if (member.contains("/") || member.contains("\\") || member.contains("..") || member.isBlank()) {
            throw new E2eException("Unsafe source member name '" + member + "'");
        }
        if (sources.put(member, content) != null) {
            throw new E2eException("Source member '" + member + "' added twice");
        }
        return this;
    }

    public BundleBuilder driver(byte[] content) {
        this.driver = content;
        return this;
    }

    public BundleBuilder spec(BundleSpec value) {
        this.spec = value;
        return this;
    }

    public byte[] build() {
        if (sources.isEmpty()) {
            throw new E2eException("A bundle needs the unit's sources");
        }
        if (driver == null) {
            throw new E2eException("A bundle needs the generated driver (driver.cbl)");
        }
        if (spec == null) {
            throw new E2eException("A bundle needs a spec");
        }
        String yaml = SpecYamlWriter.write(spec);
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (ZipOutputStream zip = new ZipOutputStream(bytes)) {
            for (Map.Entry<String, byte[]> member : sources.entrySet()) {
                put(zip, "sources/" + member.getKey(), member.getValue());
            }
            put(zip, "driver.cbl", driver);
            put(zip, "spec.yaml", yaml.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            throw new E2eException("Cannot build the bundle zip", e);
        }
        return bytes.toByteArray();
    }

    public Map<String, byte[]> sources() {
        return Map.copyOf(sources);
    }

    static boolean isMember(Path file) {
        String name = file.getFileName().toString().toUpperCase(java.util.Locale.ROOT);
        return name.endsWith(".CBL") || name.endsWith(".CPY") || name.endsWith(".COB");
    }

    private static void put(ZipOutputStream zip, String name, byte[] content) throws IOException {
        ZipEntry entry = new ZipEntry(name);
        entry.setTime(0L); // reproducible bundles: the same inputs give the same bytes
        zip.putNextEntry(entry);
        zip.write(content);
        zip.closeEntry();
    }
}
