package com.insurance.e2e.legacy.paritytester;

import com.fasterxml.jackson.databind.JsonNode;
import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.spi.Availability;

import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Client of a parity-tester <em>server</em> instance - for E2E, the second instance whose {@code WORKSPACE_DIR} is
 * E2E's own catalogue ({@code validation/engine/catalogue/}). The owner's catalogue is never written through this.
 *
 * <p>Routes (parity-tester {@code server/routes/*.js}): {@code GET /health}, {@code GET /api/cases},
 * {@code POST /api/run?case=}, {@code GET /program/list}, {@code POST /program/upload?name=} (raw zip),
 * {@code GET /program/<E>}, {@code GET /program/<E>/sources/<M>}, {@code GET|POST /program/<E>/driver[/generate]},
 * {@code GET /program/<E>/schema}, {@code POST /program/<E>/schema/generate}, {@code GET /program/<E>/tests}.
 */
public final class CatalogueClient {

    /** {@code GET /health}: which catalogue the server serves and whether it can see the runner. */
    public record Health(boolean ok, String workspace, boolean runnerOk) {
    }

    private final HttpJson http;

    public CatalogueClient(URI baseUrl, Duration connectTimeout, Duration requestTimeout) {
        this.http = new HttpJson(baseUrl, connectTimeout, requestTimeout);
    }

    public static CatalogueClient from(ParityTesterConfig config) {
        return new CatalogueClient(config.catalogueUrl(), config.connectTimeout(), config.runTimeout());
    }

    public Health health() {
        HttpJson.Response response = http.get("/health", Duration.ofSeconds(10));
        JsonNode json = expectJson(response, 200, "health");
        return new Health(json.path("ok").asBoolean(false), json.path("workspace").asText(null),
                json.path("runner").path("ok").asBoolean(false));
    }

    /**
     * Up when the server answers and serves {@code expectedWorkspace} (when given) - the guard against talking to
     * the owner's instance by mistake.
     */
    public Availability availability(String expectedWorkspace) {
        try {
            Health health = health();
            if (!health.ok()) {
                return Availability.down("catalogue server at " + http.base() + " reports not ok");
            }
            if (expectedWorkspace != null && !samePath(expectedWorkspace, health.workspace())) {
                return Availability.down("catalogue server at " + http.base() + " serves " + health.workspace()
                        + ", not E2E's own catalogue " + expectedWorkspace);
            }
            return Availability.up();
        } catch (HttpJson.Unreachable e) {
            return Availability.down("catalogue server not reachable at " + http.base() + " (" + e.getMessage() + ")");
        } catch (E2eException e) {
            return Availability.down(e.getMessage());
        }
    }

    public List<String> programs() {
        List<String> ids = new ArrayList<>();
        expectJson(http.get("/program/list"), 200, "program list").forEach(n -> ids.add(n.asText()));
        return ids;
    }

    public JsonNode program(String id) {
        return expectJson(http.get("/program/" + encode(id)), 200, "program " + id);
    }

    /** Creates a unit from a zip of members (flattened and upper-cased by the server); 409 when it exists. */
    public JsonNode upload(String entry, byte[] zip) {
        HttpJson.Response response = http.post("/program/upload?name=" + encode(entry), "application/zip", zip);
        if (response.status() == 409) {
            throw new E2eException("unit " + entry + " already exists in the catalogue");
        }
        return expectJson(response, 201, "upload of " + entry);
    }

    public Optional<String> driver(String id) {
        HttpJson.Response response = http.get("/program/" + encode(id) + "/driver");
        if (response.status() == 404) {
            return Optional.empty();
        }
        expectStatus(response, 200, "driver of " + id);
        return Optional.of(response.body());
    }

    /** Regenerates and returns the driver (overwrites {@code driver.cbl} in the catalogue). */
    public String generateDriver(String id) {
        HttpJson.Response response = http.post("/program/" + encode(id) + "/driver/generate", null, null);
        expectStatus(response, 200, "driver generation for " + id);
        return response.body();
    }

    public JsonNode schema(String id) {
        return expectJson(http.get("/program/" + encode(id) + "/schema"), 200, "schema of " + id);
    }

    public JsonNode generateSchema(String id) {
        return expectJson(http.post("/program/" + encode(id) + "/schema/generate", null, null), 200,
                "schema generation for " + id);
    }

    public String source(String id, String member) {
        HttpJson.Response response = http.get("/program/" + encode(id) + "/sources/" + encode(member));
        expectStatus(response, 200, "source " + member + " of " + id);
        return response.body();
    }

    public List<String> tests(String id) {
        List<String> files = new ArrayList<>();
        expectJson(http.get("/program/" + encode(id) + "/tests"), 200, "tests of " + id).forEach(n -> files.add(n.asText()));
        return files;
    }

    public JsonNode cases() {
        return expectJson(http.get("/api/cases"), 200, "case list");
    }

    /** Re-verifies a curated case with the owner's semantics (always HTTP 200; the result says how it went). */
    public JsonNode runCase(String caseId) {
        return expectJson(http.post("/api/run?case=" + encode(caseId), null, null), 200, "run of case " + caseId);
    }

    private static JsonNode expectJson(HttpJson.Response response, int status, String what) {
        expectStatus(response, status, what);
        if (response.json() == null) {
            throw new E2eException(what + ": expected JSON, got " + abbreviate(response.body()));
        }
        return response.json();
    }

    private static void expectStatus(HttpJson.Response response, int status, String what) {
        if (response.status() != status) {
            String error = response.json() != null && response.json().has("error")
                    ? response.json().get("error").asText() : abbreviate(response.body());
            throw new E2eException(what + ": HTTP " + response.status() + " " + error);
        }
    }

    private static String encode(String value) {
        return URLEncoder.encode(value, StandardCharsets.UTF_8).replace("+", "%20");
    }

    private static String abbreviate(String text) {
        return text == null ? "" : text.length() > 200 ? text.substring(0, 200) + "..." : text;
    }

    static boolean samePath(String a, String b) {
        if (b == null) {
            return false;
        }
        String left = a.replace('\\', '/').replaceAll("/+$", "");
        String right = b.replace('\\', '/').replaceAll("/+$", "");
        return left.equalsIgnoreCase(right);
    }
}
