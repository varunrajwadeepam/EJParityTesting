package com.insurance.e2e.legacy.paritytester;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.spi.Availability;

import java.net.URI;
import java.time.Duration;

/**
 * Client of the parity-tester's cobol-runner: {@code GET /health} and {@code POST /api/run} (the bundle zip as the
 * raw body; always HTTP 200, with {@code ok:false} when the bundle built or ran badly).
 */
public final class RunnerClient {

    private final HttpJson http;
    private final Duration runTimeout;

    public RunnerClient(URI baseUrl, Duration connectTimeout, Duration runTimeout) {
        this.http = new HttpJson(baseUrl, connectTimeout, runTimeout);
        this.runTimeout = runTimeout;
    }

    public static RunnerClient from(ParityTesterConfig config) {
        return new RunnerClient(config.runnerUrl(), config.connectTimeout(), config.runTimeout());
    }

    /**
     * Up only when {@code /health} answers with a {@code workRoot}: that proves it is the runner and not some other
     * service on the port.
     */
    public Availability availability() {
        try {
            HttpJson.Response response = http.get("/health", Duration.ofSeconds(5));
            if (response.status() != 200 || response.json() == null || !response.json().has("workRoot")) {
                return Availability.down("cobol-runner at " + http.base() + " answered HTTP " + response.status()
                        + " without a workRoot - not the parity-tester runner");
            }
            return Availability.up();
        } catch (HttpJson.Unreachable e) {
            return Availability.down("cobol-runner not reachable at " + http.base() + " (" + e.getMessage()
                    + "); start the parity-tester stack (docker compose up -d)");
        }
    }

    public RunResult run(byte[] bundle) {
        HttpJson.Response response = http.post("/api/run", "application/zip", bundle, runTimeout);
        if (response.status() != 200 || response.json() == null) {
            throw new E2eException("cobol-runner refused the bundle: HTTP " + response.status() + " " + response.body());
        }
        return RunResult.parse(response.json());
    }
}
