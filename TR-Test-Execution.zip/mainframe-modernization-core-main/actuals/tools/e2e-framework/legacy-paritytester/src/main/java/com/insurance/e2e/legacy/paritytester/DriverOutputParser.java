package com.insurance.e2e.legacy.paritytester;

import com.insurance.e2e.core.observation.Observation;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses a generated driver's report lines exactly as the runner does ({@code config/cobol-runner/run-driver.js}):
 *
 * <pre>
 * &#64;IN  FIELD [value]          what was applied
 * &#64;OUT FIELD [value]          what came back
 * &#64;OUT FIELD(nnn) [value]     occurrence nnn of a repeating group
 * &#64;ERR text                   refused to run, and why
 * </pre>
 *
 * The value is taken between the first {@code [} and the <em>last</em> {@code ]} and is never trimmed: in COBOL the
 * blanks are the answer. A report line that cannot be read is kept as "other", never dropped.
 */
public final class DriverOutputParser {

    private static final Pattern LINE = Pattern.compile("^@(IN|OUT|ERR)(?:\\s+(\\S+))?\\s*(.*)$");
    private static final Pattern OCCURRENCE = Pattern.compile("^(.*)\\((\\d+)\\)$");

    /** One parsed report line. {@code occurrence} is {@code null} for a scalar field. */
    public record DriverLine(Type type, String field, Integer occurrence, String value, String raw) {
        public enum Type { IN, OUT, ERR, OTHER }

        /** {@code NAME} or {@code NAME(nnn)} - the key a golden master stores. */
        public String key() {
            return occurrence == null ? field : Observation.occurrenceKey(field, occurrence);
        }
    }

    private DriverOutputParser() {
    }

    public static List<DriverLine> parse(String stdout) {
        List<DriverLine> lines = new ArrayList<>();
        if (stdout == null) {
            return lines;
        }
        for (String line : stdout.split("\n", -1)) {
            Matcher m = LINE.matcher(line);
            if (!m.matches()) {
                if (!line.isEmpty()) {
                    lines.add(new DriverLine(DriverLine.Type.OTHER, null, null, line, line));
                }
                continue;
            }
            String kind = m.group(1);
            if ("ERR".equals(kind)) {
                lines.add(new DriverLine(DriverLine.Type.ERR, null, null,
                        line.substring("@ERR".length()).replaceFirst("^\\s", ""), line));
                continue;
            }
            String field = m.group(2);
            String rest = m.group(3);
            int open = rest.indexOf('[');
            int close = rest.lastIndexOf(']');
            if (open == -1 || close < open) {
                lines.add(new DriverLine(DriverLine.Type.OTHER, null, null, line, line));
                continue;
            }
            String value = rest.substring(open + 1, close);
            Matcher occ = field == null ? null : OCCURRENCE.matcher(field);
            boolean isOccurrence = occ != null && occ.matches();
            lines.add(new DriverLine("IN".equals(kind) ? DriverLine.Type.IN : DriverLine.Type.OUT,
                    isOccurrence ? occ.group(1) : field,
                    isOccurrence ? Integer.valueOf(occ.group(2)) : null,
                    value, line));
        }
        return lines;
    }

    /** The {@code @OUT} fields of a report, keyed as {@code NAME} / {@code NAME(nnn)}, in report order. */
    public static Map<String, String> outputs(List<DriverLine> lines) {
        Map<String, String> fields = new LinkedHashMap<>();
        lines.stream().filter(l -> l.type() == DriverLine.Type.OUT).forEach(l -> fields.put(l.key(), l.value()));
        return fields;
    }

    public static List<String> errors(List<DriverLine> lines) {
        return lines.stream().filter(l -> l.type() == DriverLine.Type.ERR).map(DriverLine::value).toList();
    }
}
