package com.insurance.e2e.legacy.paritytester;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The content of a bundle's {@code spec.yaml}.
 *
 * <p>Either the single-test form ({@code inputs} / {@code env} at the top) or the bulk form ({@code tests}: one build,
 * N sequential runs on one database, <em>no re-seeding between them</em> - so only read-only scenarios sharing one
 * fixture belong in one bulk bundle).
 *
 * @param driver PROGRAM-ID of the driver; {@code null} means the runner's default ({@code DRIVER})
 */
public record BundleSpec(String unit, String program, String driver, List<String> shims, Db2Connection db2,
                         Map<String, String> inputs, Map<String, String> env, List<Test> tests) {

    /** One test of a bulk bundle; {@code shims} overrides the bundle's when not empty. */
    public record Test(String name, Map<String, String> inputs, Map<String, String> env, List<String> shims) {
        public Test {
            inputs = ordered(inputs);
            env = ordered(env);
            shims = shims == null ? List.of() : List.copyOf(shims);
        }
    }

    public BundleSpec {
        shims = shims == null ? List.of() : List.copyOf(shims);
        inputs = ordered(inputs);
        env = ordered(env);
        tests = tests == null ? List.of() : List.copyOf(tests);
    }

    public boolean isBulk() {
        return !tests.isEmpty();
    }

    static Map<String, String> ordered(Map<String, String> source) {
        return source == null ? Map.of() : Collections.unmodifiableMap(new LinkedHashMap<>(source));
    }
}
