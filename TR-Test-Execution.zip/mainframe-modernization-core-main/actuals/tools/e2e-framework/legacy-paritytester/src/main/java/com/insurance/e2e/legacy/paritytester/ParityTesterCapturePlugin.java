package com.insurance.e2e.legacy.paritytester;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.observation.Outcome;
import com.insurance.e2e.core.spi.CapturePlugin;

import java.util.Map;
import java.util.Set;

/**
 * Legacy capture: the complete reported export view of a runner run as a raw legacy observation (every
 * {@code @OUT} field, occurrences flattened as {@code NAME(nnn)}), with the numeric exit state.
 */
public final class ParityTesterCapturePlugin implements CapturePlugin {

    @Override
    public String id() {
        return "paritytester-capture";
    }

    @Override
    public Set<String> kinds() {
        return Set.of("LEG-SP", "LEG-CMP");
    }

    @Override
    public Observation capture(Request request) {
        if (!(request.result().payload() instanceof RunResult result)) {
            throw new E2eException("paritytester-capture expects a runner result, got "
                    + (request.result().payload() == null ? "null" : request.result().payload().getClass().getName()));
        }
        ParityTesterConfig config = ParityTesterConfig.from(request.context());
        if (result.tests().isEmpty()) {
            return Observation.rawLegacy(Map.of(), Outcome.failure("legacy-run",
                    result.error() == null ? "the runner reported no test" : result.error()));
        }
        return result.single().toObservation(config.exitStateField());
    }
}
