package com.insurance.e2e.legacy.paritytester;

import com.fasterxml.jackson.databind.JsonNode;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.observation.Outcome;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The runner's answer to {@code POST /api/run} (always HTTP 200; {@code ok:false} when the bundle built or ran
 * badly). The runner reports every test in {@code tests[]}; a single-test bundle repeats that test at the top level.
 *
 * @param error  the request-level failure ({@code unit build failed}, {@code invalid spec.yaml}, ...)
 * @param tests  one entry per test of the bundle, in spec order
 * @param raw    the full response, kept for diagnosis
 */
public record RunResult(String runId, boolean ok, String error, List<TestRun> tests, JsonNode raw) {

    /**
     * One test of a bundle. {@code ok} is the runner's: the driver executed, reported fields and refused nothing -
     * never a statement about whether the values are right.
     */
    public record TestRun(String name, boolean ok, String error, Integer exitCode, boolean timedOut,
                          String stdout, String stderr, Map<String, String> outputs, List<String> driverErrors,
                          JsonNode coverage) {

        public TestRun {
            outputs = outputs == null ? Map.of() : java.util.Collections.unmodifiableMap(new LinkedHashMap<>(outputs));
            driverErrors = driverErrors == null ? List.of() : List.copyOf(driverErrors);
        }

        /**
         * The complete raw legacy observation: every reported field. A failed run is a technical failure with the
         * runner's reason; otherwise the numeric exit state is read from {@code exitStateField}.
         *
         * <p>Nothing run-specific (run id, timings) goes into the observation: identical behaviour must give
         * identical observations, or the determinism check (EQ-6) could never pass.
         */
        public Observation toObservation(String exitStateField) {
            Outcome outcome;
            if (!ok) {
                String reason = error != null ? error
                        : !driverErrors.isEmpty() ? String.join("; ", driverErrors)
                        : timedOut ? "timed out"
                        : "driver run failed (exit code " + exitCode + ", " + outputs.size() + " fields)";
                outcome = Outcome.failure("legacy-run", reason);
            } else {
                outcome = Outcome.ok(parseLong(exitStateField == null ? null : outputs.get(exitStateField)));
            }
            return Observation.rawLegacy(outputs, outcome);
        }
    }

    public static RunResult parse(JsonNode node) {
        List<TestRun> tests = new ArrayList<>();
        JsonNode list = node.path("tests");
        if (list.isArray()) {
            for (JsonNode test : list) {
                tests.add(parseTest(test));
            }
        } else if (node.has("outputs")) {
            tests.add(parseTest(node));
        }
        return new RunResult(text(node, "runId"), node.path("ok").asBoolean(false), text(node, "error"), tests, node);
    }

    /** The only test of a single-test bundle. */
    public TestRun single() {
        if (tests.size() != 1) {
            throw new IllegalStateException("expected exactly one test in run " + runId + " but got " + tests.size()
                    + (error == null ? "" : " (" + error + ")"));
        }
        return tests.get(0);
    }

    private static TestRun parseTest(JsonNode test) {
        Map<String, String> outputs = new LinkedHashMap<>();
        for (JsonNode out : test.path("outputs")) {
            String field = out.path("field").asText();
            JsonNode occurrence = out.path("occurrence");
            String key = occurrence.isNumber() ? Observation.occurrenceKey(field, occurrence.asInt()) : field;
            outputs.put(key, out.path("value").asText());
        }
        List<String> driverErrors = new ArrayList<>();
        test.path("driverErrors").forEach(e -> driverErrors.add(e.asText()));
        JsonNode run = test.path("run");
        return new TestRun(text(test, "name"), test.path("ok").asBoolean(false), text(test, "error"),
                run.has("exitCode") && !run.get("exitCode").isNull() ? run.get("exitCode").asInt() : null,
                run.path("timedOut").asBoolean(false), text(run, "stdout"), text(run, "stderr"), outputs,
                driverErrors, test.get("coverage"));
    }

    private static String text(JsonNode node, String field) {
        JsonNode value = node.get(field);
        return value == null || value.isNull() ? null : value.asText();
    }

    static Long parseLong(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        try {
            return Long.parseLong(value.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
