package com.insurance.e2e.legacy.paritytester;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.observation.Outcome;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.URI;
import java.time.Duration;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ClientsTest {

    static final String SINGLE_RUN = """
            { "runId": "r1", "ok": true, "build": { "unit": { "ok": true } },
              "tests": [ { "name": null, "ok": true,
                "run": { "exitCode": 0, "signal": null, "timedOut": false, "stdout": "@OUT EXIT-STATE [0]", "stderr": "" },
                "outputs": [ { "field": "EXIT-STATE", "occurrence": null, "value": "0" },
                             { "field": "TEXT-0003", "occurrence": 1, "value": "BLUE " } ],
                "driverErrors": [], "coverage": { "DEMO0001": [[1, 3]] } } ],
              "outputs": [ { "field": "EXIT-STATE", "occurrence": null, "value": "0" } ] }""";

    @Test
    void parsesSingleBulkAndFailedRuns() throws IOException {
        RunResult single = RunResult.parse(JsonSupport.mapper().readTree(SINGLE_RUN));
        Observation observation = single.single().toObservation("EXIT-STATE");

        assertThat(single.ok()).isTrue();
        assertThat(single.runId()).isEqualTo("r1");
        assertThat(observation.form()).isEqualTo(Observation.Form.RAW_LEGACY);
        assertThat(observation.fields()).containsEntry("TEXT-0003(001)", "BLUE ");
        assertThat(observation.outcome().exitState()).isZero();
        assertThat(single.single().coverage()).isNotNull();

        RunResult bulk = RunResult.parse(JsonSupport.mapper().readTree("""
                { "runId": "r2", "ok": false, "error": "timeout",
                  "tests": [ { "name": "S-1", "ok": true, "run": { "exitCode": 0 }, "outputs": [], "driverErrors": [] },
                             { "name": "S-2", "ok": false, "run": { "exitCode": 12, "timedOut": true }, "outputs": [],
                               "driverErrors": ["unsupported key [X]"] } ] }"""));
        assertThat(bulk.tests()).hasSize(2);
        assertThat(bulk.tests().get(1).toObservation("EXIT-STATE").outcome().message()).contains("unsupported key");
        assertThatThrownBy(bulk::single).isInstanceOf(IllegalStateException.class).hasMessageContaining("timeout");

        RunResult failed = RunResult.parse(JsonSupport.mapper().readTree("{\"runId\":\"r3\",\"ok\":false,\"error\":\"unit build failed\"}"));
        assertThat(failed.tests()).isEmpty();
        assertThat(failed.error()).isEqualTo("unit build failed");

        RunResult.TestRun timedOut = new RunResult.TestRun("t", false, null, null, true, null, null, null, null, null);
        assertThat(timedOut.toObservation(null).outcome().message()).isEqualTo("timed out");
        RunResult.TestRun silent = new RunResult.TestRun("t", false, null, 3, false, null, null, null, null, null);
        assertThat(silent.toObservation(null).outcome().message()).contains("exit code 3");
        RunResult.TestRun errored = new RunResult.TestRun("t", false, "boom", 3, false, null, null, null, null, null);
        assertThat(errored.toObservation(null).outcome().kind()).isEqualTo(Outcome.Kind.TECHNICAL_FAILURE);
        assertThat(RunResult.parseLong("x")).isNull();
        assertThat(RunResult.parseLong(" 7 ")).isEqualTo(7L);

        RunResult legacyShape = RunResult.parse(JsonSupport.mapper().readTree(
                "{\"runId\":\"r4\",\"ok\":true,\"outputs\":[{\"field\":\"A\",\"value\":\"1\"}]}"));
        assertThat(legacyShape.single().outputs()).containsEntry("A", "1");
    }

    @Test
    void runnerHealthProvesItIsTheRunner() throws IOException {
        try (FakeHttp runner = new FakeHttp().on("GET /health", 200, "{\"ok\":true,\"workRoot\":\"/tmp/parity\"}")
                .on("POST /api/run", 200, SINGLE_RUN)) {
            RunnerClient client = new RunnerClient(runner.uri(), Duration.ofSeconds(2), Duration.ofSeconds(5));

            assertThat(client.availability().available()).isTrue();
            RunResult result = client.run(new byte[]{1, 2, 3});
            assertThat(result.runId()).isEqualTo("r1");
            assertThat(runner.received).anyMatch(r -> r.path().equals("/api/run") && "application/zip".equals(r.contentType())
                    && r.body().length == 3);
        }
        try (FakeHttp other = new FakeHttp().on("GET /health", 200, "{\"ok\":true}").on("POST /api/run", 413, "{\"error\":\"too big\"}")) {
            RunnerClient client = new RunnerClient(other.uri(), Duration.ofSeconds(2), Duration.ofSeconds(5));
            assertThat(client.availability().reason()).contains("not the parity-tester runner");
            assertThatThrownBy(() -> client.run(new byte[1])).isInstanceOf(E2eException.class).hasMessageContaining("413");
        }
        RunnerClient nobody = new RunnerClient(URI.create("http://127.0.0.1:" + freePort()), Duration.ofSeconds(1), Duration.ofSeconds(1));
        assertThat(nobody.availability().available()).isFalse();
        assertThat(nobody.availability().reason()).contains("docker compose up -d");
    }

    @Test
    void catalogueClientCoversTheServerRoutes() throws IOException {
        try (FakeHttp server = new FakeHttp()
                .on("GET /health", 200, "{\"ok\":true,\"workspace\":\"C:\\\\ws\\\\validation\\\\engine\\\\catalogue\",\"runner\":{\"ok\":true}}")
                .on("GET /program/list", 200, "[\"DEMO0001\"]")
                .on("GET /program/DEMO0001", 200, "{\"sources\":[\"DEMO0001.CBL\"],\"has_driver\":true}")
                .on("POST /program/upload?name=DEMO0001", 201, "{\"unit\":\"DEMO0001\",\"warnings\":[]}")
                .on("POST /program/upload?name=DEMO0002", 409, "{\"error\":\"exists\"}")
                .on("GET /program/DEMO0001/driver", 200, "       IDENTIFICATION DIVISION.")
                .on("POST /program/DEMO0001/driver/generate", 200, "       PROGRAM-ID. DRIVER.")
                .on("GET /program/DEMO0001/schema", 200, "{\"unit\":\"DEMO0001\",\"inputs\":[],\"outputs\":[]}")
                .on("POST /program/DEMO0001/schema/generate", 200, "{\"unit\":\"DEMO0001\"}")
                .on("GET /program/DEMO0001/sources/DEMO0001.CBL", 200, "       PROCEDURE DIVISION.")
                .on("GET /program/DEMO0001/tests", 200, "[\"case-1.yaml\"]")
                .on("GET /api/cases", 200, "{\"units\":[],\"cases\":[]}")
                .on("POST /api/run?case=case-1", 200, "{\"passed\":true}")) {
            CatalogueClient client = new CatalogueClient(server.uri(), Duration.ofSeconds(2), Duration.ofSeconds(5));

            assertThat(client.health().runnerOk()).isTrue();
            assertThat(client.availability("C:/ws/validation/engine/catalogue/").available()).isTrue();
            assertThat(client.availability("C:/owner/workspace").reason()).contains("not E2E's own catalogue");
            assertThat(client.availability(null).available()).isTrue();
            assertThat(client.programs()).containsExactly("DEMO0001");
            assertThat(client.program("DEMO0001").path("has_driver").asBoolean()).isTrue();
            assertThat(client.upload("DEMO0001", new byte[]{9}).path("unit").asText()).isEqualTo("DEMO0001");
            assertThatThrownBy(() -> client.upload("DEMO0002", new byte[]{9})).hasMessageContaining("already exists");
            assertThat(client.driver("DEMO0001")).contains("       IDENTIFICATION DIVISION.");
            assertThat(client.driver("DEMO0009")).isEmpty();
            assertThat(client.generateDriver("DEMO0001")).contains("DRIVER");
            assertThat(client.schema("DEMO0001").path("unit").asText()).isEqualTo("DEMO0001");
            assertThat(client.generateSchema("DEMO0001").path("unit").asText()).isEqualTo("DEMO0001");
            assertThat(client.source("DEMO0001", "DEMO0001.CBL")).contains("PROCEDURE");
            assertThat(client.tests("DEMO0001")).containsExactly("case-1.yaml");
            assertThat(client.cases().has("cases")).isTrue();
            assertThat(client.runCase("case-1").path("passed").asBoolean()).isTrue();
            assertThatThrownBy(() -> client.program("NOPE")).isInstanceOf(E2eException.class).hasMessageContaining("HTTP 404");
            assertThatThrownBy(() -> client.source("DEMO0001", "X.CBL")).isInstanceOf(E2eException.class);
        }
        try (FakeHttp sick = new FakeHttp().on("GET /health", 200, "{\"ok\":false}").on("GET /program/list", 200, "not json")) {
            CatalogueClient client = new CatalogueClient(sick.uri(), Duration.ofSeconds(2), Duration.ofSeconds(5));
            assertThat(client.availability(null).reason()).contains("reports not ok");
            assertThatThrownBy(client::programs).hasMessageContaining("expected JSON");
        }
        try (FakeHttp broken = new FakeHttp().on("GET /health", 500, "oops")) {
            assertThat(new CatalogueClient(broken.uri(), Duration.ofSeconds(2), Duration.ofSeconds(5)).availability(null).reason())
                    .contains("HTTP 500");
        }
        CatalogueClient nobody = new CatalogueClient(URI.create("http://127.0.0.1:" + freePort()), Duration.ofSeconds(1), Duration.ofSeconds(1));
        assertThat(nobody.availability(null).reason()).contains("not reachable");
        assertThat(CatalogueClient.samePath("a\\b\\", "A/B")).isTrue();
        assertThat(CatalogueClient.samePath("a", null)).isFalse();
    }

    static int freePort() throws IOException {
        try (ServerSocket socket = new ServerSocket(0)) {
            return socket.getLocalPort();
        }
    }
}
