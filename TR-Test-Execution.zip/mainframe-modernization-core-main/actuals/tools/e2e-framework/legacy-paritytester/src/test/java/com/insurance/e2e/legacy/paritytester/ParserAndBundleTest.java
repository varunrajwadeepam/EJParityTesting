package com.insurance.e2e.legacy.paritytester;

import com.insurance.e2e.core.E2eException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ParserAndBundleTest {

    static final Db2Connection DB2 = new Db2Connection("TESTDB", "TESTDB", "db-host", "50000", "user1", "secret");

    @Test
    void parsesReportLinesLikeTheRunner() {
        String stdout = String.join("\n",
                "@IN  TABLE-NAME-0001 [COLOUR]",
                "@OUT EXIT-STATE [0]",
                "@OUT TEXT-0003(001) [BLUE   ]",
                "@OUT ODD-0004 [a]b]",
                "@OUT EMPTY-0005 []",
                "@ERR unsupported key [X] -- not an import field of DEMO0001",
                "@OUT BROKEN-0006 no brackets",
                "plain output",
                "");

        List<DriverOutputParser.DriverLine> lines = DriverOutputParser.parse(stdout);

        Map<String, String> outputs = DriverOutputParser.outputs(lines);
        assertThat(outputs).containsExactly(Map.entry("EXIT-STATE", "0"), Map.entry("TEXT-0003(001)", "BLUE   "),
                Map.entry("ODD-0004", "a]b"), Map.entry("EMPTY-0005", ""));
        assertThat(DriverOutputParser.errors(lines)).containsExactly("unsupported key [X] -- not an import field of DEMO0001");
        assertThat(lines).filteredOn(l -> l.type() == DriverOutputParser.DriverLine.Type.IN)
                .singleElement().satisfies(l -> assertThat(l.value()).isEqualTo("COLOUR"));
        assertThat(lines).filteredOn(l -> l.type() == DriverOutputParser.DriverLine.Type.OTHER)
                .extracting(DriverOutputParser.DriverLine::raw).containsExactly("@OUT BROKEN-0006 no brackets", "plain output");
        assertThat(DriverOutputParser.parse(null)).isEmpty();
    }

    @Test
    void writesASingleTestSpecWithEveryValueQuoted() {
        Map<String, String> inputs = new LinkedHashMap<>();
        inputs.put("TABLE-NAME-0001", "COLOUR");
        inputs.put("SEARCH-VALUE-0001", "00123");
        inputs.put("QUOTED-0001", "say \"hi\" \\ bye\t");
        BundleSpec spec = new BundleSpec("DEMO0001", "DEMO0001", null, List.of("cagen"), DB2, inputs,
                Map.of("CAGENSHIM_CLOCK", "20240101120000"), null);

        String yaml = SpecYamlWriter.write(spec);

        assertThat(yaml).contains("unit: \"DEMO0001\"\nprogram: \"DEMO0001\"\nshims: [\"cagen\"]\ndb2:\n  dsn: \"TESTDB\"")
                .contains("  password: \"secret\"")
                .contains("env:\n  \"CAGENSHIM_CLOCK\": \"20240101120000\"")
                .contains("  \"SEARCH-VALUE-0001\": \"00123\"")
                .contains("  \"QUOTED-0001\": \"say \\\"hi\\\" \\\\ bye\\t\"")
                .doesNotContain("tests:");
        assertThat(spec.isBulk()).isFalse();
        assertThat(DB2.toString()).doesNotContain("secret");
    }

    @Test
    void writesABulkSpec() {
        BundleSpec spec = new BundleSpec("DEMO0001", "DEMO0001", "DRIVER", List.of("cagen"), DB2, null, Map.of("GIXSQL_AUTOCOMMIT", "off"),
                List.of(new BundleSpec.Test("S-1", Map.of("A", "1"), Map.of(), List.of()),
                        new BundleSpec.Test("S-2", Map.of(), Map.of("CAGENSHIM_CLOCK", "20240101000000"), List.of("cagen-trace"))));

        String yaml = SpecYamlWriter.write(spec);

        assertThat(yaml).contains("driver: \"DRIVER\"", "tests:\n  - name: \"S-1\"\n    env: {}\n    inputs:\n      \"A\": \"1\"",
                "  - name: \"S-2\"\n    shims: [\"cagen-trace\"]", "inputs: {}", "env:\n  \"GIXSQL_AUTOCOMMIT\": \"off\"");
        assertThat(spec.isBulk()).isTrue();
    }

    @Test
    void refusesSpecsTheRunnerWouldRefuse() {
        BundleSpec bad = new BundleSpec("bad unit", "P", "bad_driver", List.of(), new Db2Connection("D", "D", null, "1", "u", ""),
                Map.of("bad key!", "x", "OK", "two\nlines"), Map.of("1BAD", "x"),
                List.of(new BundleSpec.Test(" ", Map.of(), Map.of(), List.of("Bad_Shim"))));

        assertThatThrownBy(() -> SpecYamlWriter.write(bad))
                .isInstanceOfSatisfying(E2eException.class, e -> assertThat(e.problems()).anyMatch(p -> p.startsWith("unit"))
                        .anyMatch(p -> p.startsWith("driver")).anyMatch(p -> p.contains("shim tree is required"))
                        .anyMatch(p -> p.contains("db2.hostname")).anyMatch(p -> p.contains("db2.password"))
                        .anyMatch(p -> p.contains("bad key!")).anyMatch(p -> p.contains("spans lines"))
                        .anyMatch(p -> p.contains("1BAD")).anyMatch(p -> p.contains("needs a name"))
                        .anyMatch(p -> p.contains("Bad_Shim")));
        assertThat(SpecYamlWriter.problems(new BundleSpec("U", "U", null, List.of("cagen"), null, null, null, null)))
                .contains("db2 connection is required");
        assertThat(SpecYamlWriter.quote("\u0001")).isEqualTo("\"\\x01\"");
        Map<String, String> nullValue = new java.util.HashMap<>();
        nullValue.put("F", null);
        assertThat(SpecYamlWriter.problems(new BundleSpec("U", "U", null, List.of("cagen"), DB2, nullValue, null, null)))
                .contains("value of F is null");
    }

    @Test
    void buildsAReproducibleBundle(@TempDir Path dir) throws IOException {
        Files.writeString(dir.resolve("DEMO0001.CBL"), "       IDENTIFICATION DIVISION.");
        Files.writeString(dir.resolve("DEMO0101.cbl"), "       PROGRAM-ID. DEMO0101.");
        Files.writeString(dir.resolve("README.md"), "not a member");
        BundleSpec spec = new BundleSpec("DEMO0001", "DEMO0001", null, List.of("cagen"), DB2, Map.of(), Map.of(), null);

        byte[] first = new BundleBuilder().sourcesFrom(dir).driver("DRIVER".getBytes(StandardCharsets.UTF_8)).spec(spec).build();
        byte[] second = new BundleBuilder().sourcesFrom(dir).driver("DRIVER".getBytes(StandardCharsets.UTF_8)).spec(spec).build();

        assertThat(first).isEqualTo(second);
        assertThat(entries(first)).containsExactly("sources/DEMO0001.CBL", "sources/DEMO0101.cbl", "driver.cbl", "spec.yaml");
    }

    @Test
    void refusesIncompleteOrUnsafeBundles(@TempDir Path dir) {
        BundleSpec spec = new BundleSpec("U", "U", null, List.of("cagen"), DB2, Map.of(), Map.of(), null);

        assertThatThrownBy(() -> new BundleBuilder().source("../evil.CBL", new byte[0])).isInstanceOf(E2eException.class);
        assertThatThrownBy(() -> new BundleBuilder().source("A.CBL", new byte[0]).source("A.CBL", new byte[0]))
                .isInstanceOf(E2eException.class);
        assertThatThrownBy(() -> new BundleBuilder().driver(new byte[1]).spec(spec).build()).hasMessageContaining("sources");
        assertThatThrownBy(() -> new BundleBuilder().source("A.CBL", new byte[1]).spec(spec).build()).hasMessageContaining("driver");
        assertThatThrownBy(() -> new BundleBuilder().source("A.CBL", new byte[1]).driver(new byte[1]).build()).hasMessageContaining("spec");
        assertThatThrownBy(() -> new BundleBuilder().sourcesFrom(dir.resolve("missing"))).isInstanceOf(E2eException.class);
        assertThat(new BundleBuilder().source("A.CBL", new byte[1]).sources()).containsKey("A.CBL");
    }

    static String entryText(byte[] zip, String name) throws IOException {
        try (ZipInputStream in = new ZipInputStream(new ByteArrayInputStream(zip))) {
            for (ZipEntry e = in.getNextEntry(); e != null; e = in.getNextEntry()) {
                if (e.getName().equals(name)) {
                    return new String(in.readAllBytes(), StandardCharsets.UTF_8);
                }
            }
        }
        throw new IllegalStateException(name + " not in the bundle");
    }

    static List<String> entries(byte[] zip) throws IOException {
        List<String> names = new java.util.ArrayList<>();
        try (ZipInputStream in = new ZipInputStream(new ByteArrayInputStream(zip))) {
            for (ZipEntry e = in.getNextEntry(); e != null; e = in.getNextEntry()) {
                names.add(e.getName());
            }
        }
        return names;
    }
}
