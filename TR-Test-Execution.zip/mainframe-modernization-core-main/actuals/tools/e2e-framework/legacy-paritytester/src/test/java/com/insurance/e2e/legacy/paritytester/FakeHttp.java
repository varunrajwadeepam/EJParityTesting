package com.insurance.e2e.legacy.paritytester;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** A local HTTP server answering canned responses per "METHOD path?query"; records every request body. */
final class FakeHttp implements AutoCloseable {

    record Canned(int status, String body) {
    }

    record Received(String method, String path, String query, String contentType, byte[] body) {
    }

    private final HttpServer server;
    private final Map<String, Canned> routes = new ConcurrentHashMap<>();
    final List<Received> received = new ArrayList<>();

    FakeHttp() throws IOException {
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/", this::handle);
        server.start();
    }

    FakeHttp on(String methodAndPath, int status, String body) {
        routes.put(methodAndPath, new Canned(status, body));
        return this;
    }

    URI uri() {
        return URI.create("http://127.0.0.1:" + server.getAddress().getPort());
    }

    private void handle(HttpExchange exchange) throws IOException {
        byte[] body = exchange.getRequestBody().readAllBytes();
        String path = exchange.getRequestURI().getRawPath();
        String query = exchange.getRequestURI().getRawQuery();
        synchronized (received) {
            received.add(new Received(exchange.getRequestMethod(), path, query,
                    exchange.getRequestHeaders().getFirst("Content-Type"), body));
        }
        String key = exchange.getRequestMethod() + " " + path + (query == null ? "" : "?" + query);
        Canned canned = routes.getOrDefault(key, new Canned(404, "{\"error\":\"no route " + key + "\"}"));
        byte[] bytes = canned.body().getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(canned.status(), bytes.length == 0 ? -1 : bytes.length);
        if (bytes.length > 0) {
            try (OutputStream out = exchange.getResponseBody()) {
                out.write(bytes);
            }
        }
        exchange.close();
    }

    @Override
    public void close() {
        server.stop(0);
    }
}
