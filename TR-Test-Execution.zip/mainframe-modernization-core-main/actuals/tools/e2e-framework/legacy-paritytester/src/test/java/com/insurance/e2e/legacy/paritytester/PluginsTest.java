package com.insurance.e2e.legacy.paritytester;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.scenario.BindingRef;
import com.insurance.e2e.core.scenario.LevelBinding;
import com.insurance.e2e.core.scenario.Scenario;
import com.insurance.e2e.core.spi.CapturePlugin;
import com.insurance.e2e.core.spi.ExecutionContext;
import com.insurance.e2e.core.spi.PluginRegistry;
import com.insurance.e2e.core.spi.TriggerPlugin;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class PluginsTest {

    @TempDir
    Path catalogue;

    static final BindingRef LEG = BindingRef.parse("LEG-SP:DEMO0001");

    static Scenario scenario(String id, String fixture) {
        return new Scenario(id, null, null, null, "P0", null, null, null, null,
                List.of(new LevelBinding(null, LEG, null, null)), fixture, "20240101120000", null,
                Map.of("TABLE-NAME-0001", "COLOUR"), null, null, null);
    }

    void unit() throws IOException {
        Path sources = catalogue.resolve("DEMO0001").resolve("sources");
        Files.createDirectories(sources);
        Files.writeString(sources.resolve("DEMO0001.CBL"), "       PROGRAM-ID. DEMO0001.");
        Files.writeString(catalogue.resolve("DEMO0001").resolve("driver.cbl"), "       PROGRAM-ID. DRIVER.");
    }

    ExecutionContext context(FakeHttp runner, boolean withPassword) {
        ExecutionContext.Builder builder = ExecutionContext.builder()
                .property("e2e.pt.runner.url", runner.uri().toString())
                .property("e2e.pt.catalogue.dir", catalogue.toString())
                .property("e2e.pt.db2.hostname", "db-host")
                .property("e2e.pt.exit-state-field", "EXIT-STATE")
                .environment(Map.of());
        if (withPassword) {
            builder.property("e2e.pt.db2.password", "secret");
        }
        return builder.build();
    }

    @Test
    void triggerBuildsTheBundleFromTheOwnCatalogueAndCaptureReadsTheReport() throws IOException {
        unit();
        try (FakeHttp runner = new FakeHttp().on("GET /health", 200, "{\"ok\":true,\"workRoot\":\"/w\"}")
                .on("POST /api/run", 200, ClientsTest.SINGLE_RUN)) {
            ExecutionContext context = context(runner, true);
            ParityTesterTriggerPlugin trigger = new ParityTesterTriggerPlugin();

            assertThat(trigger.availability(context).available()).isTrue();
            TriggerPlugin.TriggerResult result = trigger.trigger(new TriggerPlugin.Request(LEG, scenario("S-1", null), null, context));

            assertThat(result.provenance()).containsKeys("source:DEMO0001.CBL", "driver").containsEntry("platform", "gnucobol-emulated");
            byte[] bundle = runner.received.stream().filter(r -> r.path().equals("/api/run")).findFirst().orElseThrow().body();
            assertThat(ParserAndBundleTest.entries(bundle)).containsExactly("sources/DEMO0001.CBL", "driver.cbl", "spec.yaml");

            Observation observation = new ParityTesterCapturePlugin().capture(new CapturePlugin.Request(LEG, result,
                    scenario("S-1", null), null, context));
            assertThat(observation.fields()).containsEntry("EXIT-STATE", "0");
            assertThat(observation.outcome().exitState()).isZero();
        }
    }

    @Test
    void availabilityExplainsWhatIsMissing() throws IOException {
        try (FakeHttp runner = new FakeHttp()) {
            assertThat(new ParityTesterTriggerPlugin().availability(context(runner, false)).reason())
                    .contains("E2E_PT_DB2_PASSWORD");
            ExecutionContext noCatalogue = ExecutionContext.builder().environment(Map.of()).build();
            assertThat(new ParityTesterTriggerPlugin().availability(noCatalogue).reason()).contains("e2e.pt.catalogue.dir");
            assertThatThrownBy(() -> new ParityTesterTriggerPlugin().trigger(new TriggerPlugin.Request(LEG, scenario("S", null), null, noCatalogue)))
                    .isInstanceOf(E2eException.class);
        }
    }

    @Test
    void captureHandlesFailedRunsAndWrongPayloads() {
        ExecutionContext context = ExecutionContext.builder().environment(Map.of()).build();
        RunResult failed = new RunResult("r", false, "unit build failed", List.of(), null);

        Observation observation = new ParityTesterCapturePlugin().capture(new CapturePlugin.Request(LEG,
                new TriggerPlugin.TriggerResult(LEG, failed, null, Map.of()), scenario("S", null), null, context));
        assertThat(observation.outcome().message()).isEqualTo("unit build failed");
        assertThatThrownBy(() -> new ParityTesterCapturePlugin().capture(new CapturePlugin.Request(LEG,
                new TriggerPlugin.TriggerResult(LEG, "text", null, Map.of()), scenario("S", null), null, context)))
                .isInstanceOf(E2eException.class);
    }

    @Test
    void bulkRunsShareOneBuildAndOneFixture() throws IOException {
        unit();
        try (FakeHttp runner = new FakeHttp().on("POST /api/run", 200, """
                { "runId": "b1", "ok": false, "error": "stopped",
                  "tests": [ { "name": "S-1", "ok": true, "run": { "exitCode": 0 },
                               "outputs": [ { "field": "EXIT-STATE", "value": "0" } ], "driverErrors": [] } ] }""")) {
            ParityTesterConfig config = ParityTesterConfig.from(context(runner, true));
            Map<String, Observation> observations = new BulkRunner(config).run("DEMO0001",
                    List.of(scenario("S-1", "f.sql"), scenario("S-2", "f.sql")));

            assertThat(observations).containsOnlyKeys("S-1", "S-2");
            assertThat(observations.get("S-1").outcome().exitState()).isZero();
            assertThat(observations.get("S-2").outcome().message()).contains("stopped");
            String spec = ParserAndBundleTest.entryText(runner.received.get(0).body(), "spec.yaml");
            assertThat(spec).contains("tests:").contains("- name: \"S-2\"");
            assertThatThrownBy(() -> new BulkRunner(config).run("DEMO0001", List.of(scenario("A", "x.sql"), scenario("B", "y.sql"))))
                    .hasMessageContaining("share one fixture");
            assertThat(new BulkRunner(config).run("DEMO0001", List.of())).isEmpty();
        }
    }

    @Test
    void catalogueUnitsReportWhatIsMissing() throws IOException {
        CatalogueUnit unit = new CatalogueUnit(catalogue, "DEMO0001");
        assertThat(unit.problems()).singleElement().asString().contains("not in the catalogue");
        Files.createDirectories(unit.sourcesDir());
        assertThat(unit.problems()).singleElement().asString().contains("no sources");
        Files.writeString(unit.sourcesDir().resolve("DEMO0001.CBL"), "x");
        assertThat(unit.problems()).singleElement().asString().contains("no generated driver");
        assertThatThrownBy(unit::bundle).isInstanceOf(E2eException.class);
        Files.writeString(unit.driverFile(), "d");
        assertThat(unit.problems()).isEmpty();
        assertThat(unit.sourceHashes()).containsOnlyKeys("DEMO0001.CBL");
        assertThat(unit.driverHash()).hasSize(64);
    }

    @Test
    void configurationHasSafeDefaultsAndPluginsAreDiscoverable() {
        ParityTesterConfig config = ParityTesterConfig.from(ExecutionContext.builder().environment(Map.of()).build());

        assertThat(config.runnerUrl().toString()).isEqualTo("http://localhost:8080");
        assertThat(config.catalogueUrl().toString()).isEqualTo("http://localhost:8091");
        assertThat(config.catalogueDir()).isNull();
        assertThat(config.shims()).containsExactly("cagen");
        assertThat(config.db2().missing()).containsExactly("hostname", "password");
        assertThat(config.exitStateField()).isEqualTo("PSMGR-EXIT-STATE");
        assertThat(config.env()).containsEntry("GIXSQL_AUTOCOMMIT", "off");
        assertThat(ParityTesterTriggerPlugin.env(config, scenario("S", null))).containsEntry("CAGENSHIM_CLOCK", "20240101120000");
        assertThat(PluginRegistry.discover().trigger("LEG-CMP")).isInstanceOf(ParityTesterTriggerPlugin.class);
        assertThat(PluginRegistry.discover().capture("LEG-SP")).isInstanceOf(ParityTesterCapturePlugin.class);
        assertThat(new ParityTesterCapturePlugin().id()).isEqualTo("paritytester-capture");
    }
}
