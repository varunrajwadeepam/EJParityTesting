package com.insurance.e2e.fixtures.jdbc;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Splits a fixture script into statements on {@code ;}, respecting {@code '...'} strings ({@code ''} escapes),
 * {@code "..."} identifiers, {@code --} line comments and block comments.
 */
public final class SqlScript {

    private static final Pattern TABLE = Pattern.compile(
            "(?i)^\\s*(?:DELETE\\s+FROM|INSERT\\s+INTO|UPDATE)\\s+([A-Za-z0-9_$#@.\"]+)");

    private SqlScript() {
    }

    public static List<String> split(String script) {
        List<String> statements = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        int n = script.length();
        int i = 0;
        while (i < n) {
            char c = script.charAt(i);
            char next = i + 1 < n ? script.charAt(i + 1) : '\0';
            if (c == '-' && next == '-') {
                while (i < n && script.charAt(i) != '\n') {
                    i++;
                }
                continue;
            }
            if (c == '/' && next == '*') {
                int end = script.indexOf("*/", i + 2);
                i = end < 0 ? n : end + 2;
                current.append(' ');
                continue;
            }
            if (c == '\'' || c == '"') {
                int start = i;
                i++;
                while (i < n) {
                    if (script.charAt(i) == c) {
                        if (i + 1 < n && script.charAt(i + 1) == c) {
                            i += 2;
                            continue;
                        }
                        break;
                    }
                    i++;
                }
                current.append(script, start, Math.min(i + 1, n));
                i++;
                continue;
            }
            if (c == ';') {
                add(statements, current);
                i++;
                continue;
            }
            current.append(c);
            i++;
        }
        add(statements, current);
        return statements;
    }

    /** The tables a script deletes from, inserts into or updates, in first-mention order (upper case). */
    public static List<String> tables(List<String> statements) {
        Set<String> tables = new LinkedHashSet<>();
        for (String statement : statements) {
            Matcher m = TABLE.matcher(statement);
            if (m.find()) {
                tables.add(m.group(1).replace("\"", "").toUpperCase(Locale.ROOT));
            }
        }
        return new ArrayList<>(tables);
    }

    private static void add(List<String> statements, StringBuilder current) {
        String statement = current.toString().strip();
        if (!statement.isEmpty()) {
            statements.add(statement);
        }
        current.setLength(0);
    }
}
