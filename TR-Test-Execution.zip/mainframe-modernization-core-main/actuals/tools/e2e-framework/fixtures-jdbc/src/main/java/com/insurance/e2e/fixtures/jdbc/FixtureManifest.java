package com.insurance.e2e.fixtures.jdbc;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.json.JsonSupport;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * The fixture manifest of an MU module ({@code fixtures/manifest.json}): every pack, the files it loads in order,
 * the tables it touches and its hash - and, when the module validates on an E2E-owned schema, the table definitions
 * that schema is built from. Written by the {@code fixtures} stage; a pack is part of the oracle (P15), so its hash
 * goes into every golden master recorded on it.
 *
 * <p>{@code reset} says what a pack starts from: none (default) - the pack's own statements decide, as the recordings
 * of a lookup ran; {@value #RESET_ALL_TABLES} - every table of the schema is emptied first, then the pack loads, as a
 * golden master of format 3 was recorded (its table checks read whole tables).
 */
public record FixtureManifest(String schemaVersion, List<Pack> packs, SchemaPack schema, String reset) {

    public static final String RESET_ALL_TABLES = "all-tables";

    /**
     * @param id     the name scenarios use in {@code fixture}
     * @param files  scripts relative to the fixtures directory, loaded in this order
     * @param tables the tables whose state is hashed; derived from the scripts when empty
     * @param sha256 the pack hash ({@link #packHash})
     */
    public record Pack(String id, List<String> files, List<String> tables, String sha256) {
        public Pack {
            files = files == null ? List.of() : List.copyOf(files);
            tables = tables == null ? List.of() : List.copyOf(tables);
        }
    }

    /**
     * The table definitions of the E2E-owned validation schema ({@link SchemaBuilder}).
     *
     * @param file   DDL script relative to the fixtures directory: {@code CREATE TABLE} / {@code CREATE INDEX}, parents
     *               first, unqualified
     * @param tables the tables it creates, in creation order (dropped in reverse order before)
     * @param source where the definitions were taken from (the schema the recordings were made on)
     * @param sha256 the file's hash
     */
    public record SchemaPack(String file, List<String> tables, String source, String sha256) {
        public SchemaPack {
            tables = tables == null ? List.of() : List.copyOf(tables);
        }
    }

    public FixtureManifest {
        packs = packs == null ? List.of() : List.copyOf(packs);
    }

    /** A manifest without a schema of its own (the fixtures load into the connection's schema). */
    public FixtureManifest(String schemaVersion, List<Pack> packs) {
        this(schemaVersion, packs, null, null);
    }

    /** A manifest whose packs load on top of what the tables hold. */
    public FixtureManifest(String schemaVersion, List<Pack> packs, SchemaPack schema) {
        this(schemaVersion, packs, schema, null);
    }

    /** Whether every table of the schema is emptied before a pack loads. */
    public boolean resetsAllTables() {
        return RESET_ALL_TABLES.equals(reset) && schema != null && !schema.tables().isEmpty();
    }

    public static Optional<FixtureManifest> load(Path fixturesDir) {
        Path file = fixturesDir.resolve("manifest.json");
        return Files.isRegularFile(file) ? Optional.of(JsonSupport.read(file, FixtureManifest.class)) : Optional.empty();
    }

    public Optional<Pack> pack(String id) {
        return packs.stream().filter(p -> p.id().equals(id)).findFirst();
    }

    /** Problems of every pack and of the schema: missing files and hash mismatches (a file changed after hashing). */
    public List<String> verify(Path fixturesDir) {
        List<String> problems = new ArrayList<>();
        if (schema != null) {
            Path file = fixturesDir.resolve(schema.file());
            if (!Files.isRegularFile(file)) {
                problems.add("schema: file " + schema.file() + " is missing");
            } else if (schema.sha256() != null && !schema.sha256().equals(JsonSupport.sha256Hex(withLfLineEndings(file)))) {
                problems.add("schema: hash mismatch - " + schema.file() + " changed after it was hashed");
            }
        }
        for (Pack pack : packs) {
            for (String file : pack.files()) {
                if (!Files.isRegularFile(fixturesDir.resolve(file))) {
                    problems.add("pack " + pack.id() + ": file " + file + " is missing");
                }
            }
            if (problems.isEmpty() && pack.sha256() != null && !pack.sha256().equals(packHash(fixturesDir, pack.files()))) {
                problems.add("pack " + pack.id() + ": hash mismatch - the pack changed after it was recorded");
            }
        }
        return problems;
    }

    /**
     * Hash of a pack: its files' names and content hashes, in load order. Each file is hashed with its line endings
     * normalized (CRLF as LF), so a checkout with other line endings has the same pack - and the same golden masters.
     */
    public static String packHash(Path fixturesDir, List<String> files) {
        StringBuilder identity = new StringBuilder();
        for (String file : files) {
            Path path = fixturesDir.resolve(file);
            if (!Files.isRegularFile(path)) {
                throw new E2eException("Fixture file " + path + " does not exist");
            }
            identity.append(file.replace('\\', '/')).append('\n')
                    .append(JsonSupport.sha256Hex(withLfLineEndings(path))).append('\n');
        }
        return JsonSupport.sha256Hex(identity.toString().getBytes(StandardCharsets.UTF_8));
    }

    /** The file's bytes with every CRLF pair as LF (a lone CR stays). */
    static byte[] withLfLineEndings(Path path) {
        byte[] data;
        try {
            data = Files.readAllBytes(path);
        } catch (IOException e) {
            throw new UncheckedIOException("Cannot read " + path, e);
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream(data.length);
        for (int i = 0; i < data.length; i++) {
            if (data[i] != '\r' || i + 1 >= data.length || data[i + 1] != '\n') {
                out.write(data[i]);
            }
        }
        return out.toByteArray();
    }
}
