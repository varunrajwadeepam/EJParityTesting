package com.insurance.e2e.fixtures.jdbc;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.junit.E2eScenarioTests;
import com.insurance.e2e.core.scenario.Scenario;
import com.insurance.e2e.core.spi.Availability;
import com.insurance.e2e.core.spi.EnvironmentPlugin;
import com.insurance.e2e.core.spi.ExecutionContext;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The JDBC environment binding: the validation database over JDBC ({@code E2E_DB_URL}, {@code E2E_DB_USER},
 * {@code E2E_DB_PASSWORD}, optional {@code E2E_DB_SCHEMA}).
 *
 * <p>A scenario's {@code fixture} names a pack of {@code fixtures/manifest.json} or, without a manifest entry, a
 * script relative to the fixtures directory ({@code e2e.fixtures.dir}, default {@code <module resources>/fixtures}).
 * A pack whose files no longer match the manifest hash is refused: the golden masters recorded on it would be stale.
 *
 * <ul>
 *   <li>When the manifest declares a {@code schema}, the E2E-owned schema ({@code E2E_DB_SCHEMA}, a name starting
 *       with {@code E2E}) is built from it once per run (JVM), before the first pack loads.</li>
 *   <li>A pack is loaded once and kept while the tables still hold exactly what it loaded (table-state hash): the
 *       scenarios of one fixture share one load, and a scenario that wrote data makes the next one reload.</li>
 * </ul>
 */
public final class JdbcEnvironmentPlugin implements EnvironmentPlugin {

    private record Loaded(String packHash, String stateHash, List<String> tables) {
    }

    private static final Set<String> BUILT = ConcurrentHashMap.newKeySet();
    private static final Map<String, Loaded> LOADED = new ConcurrentHashMap<>();

    @Override
    public String id() {
        return "jdbc-environment";
    }

    @Override
    public Set<String> kinds() {
        return Set.of(JDBC);
    }

    @Override
    public Availability availability(ExecutionContext context) {
        String url = context.property("e2e.db.url");
        if (url == null) {
            return Availability.down("E2E_DB_URL is not set (the validation database)");
        }
        Optional<FixtureManifest.SchemaPack> schema = schemaPack(context);
        if (schema.isPresent()) {
            try {
                SchemaBuilder.requireOwned(context.property("e2e.db.schema"));
            } catch (E2eException e) {
                return Availability.down(e.getMessage());
            }
        }
        try (Connection ignored = connect(context, schema.isEmpty())) {
            return Availability.up();
        } catch (SQLException | E2eException e) {
            return Availability.down("validation database not reachable at " + url + ": " + e.getMessage());
        }
    }

    @Override
    public FixtureState prepare(Scenario scenario, String fixture, ExecutionContext context) {
        Path dir = fixturesDir(context);
        Optional<FixtureManifest> manifest = FixtureManifest.load(dir);
        buildSchemaOnce(manifest.map(FixtureManifest::schema), dir, context);
        Optional<FixtureManifest.Pack> pack = manifest.flatMap(m -> m.pack(fixture));
        List<String> files = pack.map(FixtureManifest.Pack::files).orElse(List.of(fixture));
        String packHash = FixtureManifest.packHash(dir, files);
        if (pack.isPresent() && pack.get().sha256() != null && !pack.get().sha256().equals(packHash)) {
            throw new E2eException("Fixture pack " + fixture + " changed after it was hashed in the manifest");
        }
        String key = databaseKey(context);
        boolean reset = manifest.map(FixtureManifest::resetsAllTables).orElse(false);
        try (Connection connection = connect(context)) {
            Loaded last = LOADED.get(key);
            if (last != null && last.packHash().equals(packHash)) {
                String now = TableStateHasher.hash(connection, last.tables()).combined();
                if (now.equals(last.stateHash())) {
                    return new FixtureState(fixture, packHash, now, last.tables());
                }
            }
            List<String> all = reset ? manifest.get().schema().tables() : List.of();
            if (reset) {                      // format 3: every recording started from empty tables plus its fixture
                SchemaBuilder.emptyAll(connection, context.property("e2e.db.schema"), all);
            }
            List<String> statements = FixtureLoader.load(connection, dir, files);
            List<String> tables = reset ? all : pack.filter(p -> !p.tables().isEmpty()).map(FixtureManifest.Pack::tables)
                    .orElse(SqlScript.tables(statements));
            String state = TableStateHasher.hash(connection, tables).combined();
            LOADED.put(key, new Loaded(packHash, state, tables));
            return new FixtureState(fixture, packHash, state, tables);
        } catch (SQLException e) {
            throw new E2eException("Cannot load fixture " + fixture + ": " + e.getMessage(), e);
        }
    }

    @Override
    public String stateHash(List<String> tables, ExecutionContext context) {
        try (Connection connection = connect(context)) {
            return TableStateHasher.hash(connection, tables).combined();
        } catch (SQLException e) {
            throw new E2eException("Cannot hash table state: " + e.getMessage(), e);
        }
    }

    @Override
    public List<Map<String, Object>> rows(String query, ExecutionContext context) {
        try (Connection connection = connect(context);
             Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery(query)) {
            ResultSetMetaData meta = result.getMetaData();
            List<Map<String, Object>> rows = new ArrayList<>();
            while (result.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                for (int i = 1; i <= meta.getColumnCount(); i++) {
                    row.put(meta.getColumnLabel(i), typed(result.getObject(i)));
                }
                rows.add(row);
            }
            return rows;
        } catch (SQLException e) {
            throw new E2eException("Cannot read the table check (" + e.getMessage() + "): "
                    + (query.length() > 200 ? query.substring(0, 200) + "..." : query), e);
        }
    }

    /** A JDBC value in the form a golden master's typed row holds it. */
    static Object typed(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof BigDecimal || value instanceof String || value instanceof Boolean) {
            return value;
        }
        if (value instanceof Integer || value instanceof Short || value instanceof Byte || value instanceof Long) {
            return ((Number) value).longValue();
        }
        if (value instanceof Number number) {
            return new BigDecimal(number.toString());
        }
        if (value instanceof java.sql.Date date) {
            return date.toLocalDate().toString();
        }
        if (value instanceof java.sql.Timestamp stamp) {
            return stamp.toLocalDateTime().toString();
        }
        if (value instanceof java.sql.Time time) {
            return time.toLocalTime().toString();
        }
        if (value instanceof java.time.temporal.TemporalAccessor temporal) {
            return temporal.toString();
        }
        return value.toString();
    }

    private static void buildSchemaOnce(Optional<FixtureManifest.SchemaPack> schema, Path dir, ExecutionContext context) {
        if (schema.isEmpty()) {
            return;
        }
        Path file = dir.resolve(schema.get().file());
        if (!Files.isRegularFile(file)) {
            throw new E2eException("Schema file " + file + " does not exist");
        }
        String hash = JsonSupport.sha256Hex(FixtureManifest.withLfLineEndings(file));      // as the manifest hashes it
        if (schema.get().sha256() != null && !schema.get().sha256().equals(hash)) {
            throw new E2eException("Schema file " + schema.get().file() + " changed after it was hashed in the manifest");
        }
        String key = databaseKey(context) + "|" + hash;
        if (!BUILT.add(key)) {
            return;
        }
        try (Connection connection = connect(context, false)) {
            String ddl = Files.readString(file, StandardCharsets.UTF_8);
            SchemaBuilder.rebuild(connection, context.property("e2e.db.schema"), SqlScript.split(ddl),
                    schema.get().tables());
            LOADED.remove(databaseKey(context));
        } catch (SQLException | IOException | RuntimeException e) {
            BUILT.remove(key);
            throw e instanceof E2eException ee ? ee
                    : new E2eException("Cannot build the validation schema: " + e.getMessage(), e);
        }
    }

    private static Optional<FixtureManifest.SchemaPack> schemaPack(ExecutionContext context) {
        try {
            return FixtureManifest.load(fixturesDir(context)).map(FixtureManifest::schema);
        } catch (E2eException e) {
            return Optional.empty();
        }
    }

    private static String databaseKey(ExecutionContext context) {
        return context.property("e2e.db.url") + "|" + context.property("e2e.db.schema");
    }

    static Connection connect(ExecutionContext context) throws SQLException {
        return connect(context, true);
    }

    private static Connection connect(ExecutionContext context, boolean switchSchema) throws SQLException {
        String url = context.property("e2e.db.url");
        if (url == null) {
            throw new E2eException("E2E_DB_URL is not set");
        }
        DriverManager.setLoginTimeout(Integer.parseInt(context.property("e2e.db.login.timeout.seconds", "5")));
        Connection connection = DriverManager.getConnection(url, context.property("e2e.db.user"),
                context.property("e2e.db.password"));
        if (switchSchema) {
            SchemaSwitch.apply(connection, context.property("e2e.db.schema"));
        }
        return connection;
    }

    static Path fixturesDir(ExecutionContext context) {
        String explicit = context.property("e2e.fixtures.dir");
        if (explicit != null) {
            return Path.of(explicit);
        }
        return context.attribute(E2eScenarioTests.RESOURCES_DIR_ATTRIBUTE, Path.class)
                .map(root -> root.resolve("fixtures"))
                .orElseThrow(() -> new E2eException("No fixtures directory: set e2e.fixtures.dir or run through"
                        + " E2eScenarioTests"));
    }
}
