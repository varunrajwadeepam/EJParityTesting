package com.insurance.e2e.fixtures.jdbc;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.json.JsonSupport;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Hashes the content of tables, independently of row order, so that the harness can prove both legs of a comparison
 * started from identical rows - and refuse to compare when they did not.
 */
public final class TableStateHasher {

    /** Per-table hashes and the combined hash over all of them. */
    public record TableState(Map<String, String> tables, String combined) {
    }

    private static final char NULL = (char) 0x2400; // SYMBOL FOR NULL: never a real column value
    private static final char SEPARATOR = (char) 0x1F; // UNIT SEPARATOR

    private TableStateHasher() {
    }

    public static TableState hash(Connection connection, List<String> tables) {
        Map<String, String> hashes = new TreeMap<>();
        for (String table : tables) {
            hashes.put(table, hashTable(connection, Identifiers.require(table)));
        }
        StringBuilder combined = new StringBuilder();
        hashes.forEach((table, hash) -> combined.append(table).append('=').append(hash).append('\n'));
        return new TableState(hashes, JsonSupport.sha256Hex(combined.toString().getBytes(StandardCharsets.UTF_8)));
    }

    private static String hashTable(Connection connection, String table) {
        List<String> rows = new ArrayList<>();
        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery("SELECT * FROM " + table)) {
            ResultSetMetaData meta = result.getMetaData();
            int columns = meta.getColumnCount();
            while (result.next()) {
                StringBuilder row = new StringBuilder();
                for (int c = 1; c <= columns; c++) {
                    if (c > 1) {
                        row.append(SEPARATOR);
                    }
                    row.append(render(result.getObject(c)));
                }
                rows.add(row.toString());
            }
        } catch (SQLException e) {
            throw new E2eException("Cannot read table " + table + " to hash its state: " + e.getMessage(), e);
        }
        rows.sort(String::compareTo);
        return JsonSupport.sha256Hex((table + "\n" + String.join("\n", rows)).getBytes(StandardCharsets.UTF_8));
    }

    static String render(Object value) {
        if (value == null) {
            return String.valueOf(NULL);
        }
        if (value instanceof BigDecimal decimal) {
            return decimal.toPlainString();
        }
        if (value instanceof byte[] bytes) {
            return HexFormat.of().formatHex(bytes);
        }
        return value.toString();
    }
}
