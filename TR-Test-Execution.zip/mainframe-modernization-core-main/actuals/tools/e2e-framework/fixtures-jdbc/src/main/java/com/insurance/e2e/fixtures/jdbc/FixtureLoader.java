package com.insurance.e2e.fixtures.jdbc;

import com.insurance.e2e.core.E2eException;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

/**
 * Loads a fixture pack: every statement of every file in one transaction, committed at the end and rolled back on
 * the first failure (so a broken pack never leaves a half-seeded database behind).
 */
public final class FixtureLoader {

    private FixtureLoader() {
    }

    /** @return the statements executed, in order */
    public static List<String> load(Connection connection, Path fixturesDir, List<String> files) {
        StringBuilder all = new StringBuilder();
        for (String file : files) {
            try {
                all.append(Files.readString(fixturesDir.resolve(file), StandardCharsets.UTF_8)).append("\n;\n");
            } catch (IOException e) {
                throw new E2eException("Cannot read fixture file " + fixturesDir.resolve(file), e);
            }
        }
        List<String> statements = SqlScript.split(all.toString());
        execute(connection, statements);
        return statements;
    }

    public static void execute(Connection connection, List<String> statements) {
        boolean autoCommit = true;
        int index = 0;
        try {
            autoCommit = connection.getAutoCommit();
            connection.setAutoCommit(false);
            try (Statement statement = connection.createStatement()) {
                for (String sql : statements) {
                    index++;
                    statement.execute(sql);
                }
            }
            connection.commit();
        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException ignored) {
                // the original failure is what matters
            }
            String sql = index > 0 && index <= statements.size() ? statements.get(index - 1) : "";
            throw new E2eException("Fixture statement " + index + " failed (" + e.getMessage() + "): "
                    + (sql.length() > 200 ? sql.substring(0, 200) + "..." : sql), e);
        } finally {
            try {
                connection.setAutoCommit(autoCommit);
            } catch (SQLException ignored) {
                // connection is about to be closed by the caller
            }
        }
    }
}
