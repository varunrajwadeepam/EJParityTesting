package com.insurance.e2e.fixtures.jdbc;

import com.insurance.e2e.core.E2eException;

import java.util.regex.Pattern;

/** SQL identifiers that end up in statement text are validated, never quoted blindly. */
final class Identifiers {

    private static final Pattern IDENTIFIER = Pattern.compile("^[A-Za-z_$#@][A-Za-z0-9_$#@]*(\\.[A-Za-z_$#@][A-Za-z0-9_$#@]*)?$");

    private Identifiers() {
    }

    static String require(String identifier) {
        if (identifier == null || !IDENTIFIER.matcher(identifier).matches()) {
            throw new E2eException("Not a plain SQL identifier: '" + identifier + "'");
        }
        return identifier;
    }
}
