package com.insurance.e2e.fixtures.jdbc;

import com.insurance.e2e.core.E2eException;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Points a connection at a schema. The legacy tables are unqualified (current schema = the connection's), so the
 * target side must use the same current schema to read the same rows.
 */
public final class SchemaSwitch {

    private SchemaSwitch() {
    }

    public static void apply(Connection connection, String schema) {
        if (schema == null || schema.isBlank()) {
            return;
        }
        String name = Identifiers.require(schema.trim());
        try (Statement statement = connection.createStatement()) {
            statement.execute("SET SCHEMA " + name);
        } catch (SQLException e) {
            throw new E2eException("Cannot switch to schema " + name + ": " + e.getMessage(), e);
        }
    }

    public static String current(Connection connection) {
        try {
            return connection.getSchema();
        } catch (SQLException e) {
            throw new E2eException("Cannot read the current schema: " + e.getMessage(), e);
        }
    }
}
