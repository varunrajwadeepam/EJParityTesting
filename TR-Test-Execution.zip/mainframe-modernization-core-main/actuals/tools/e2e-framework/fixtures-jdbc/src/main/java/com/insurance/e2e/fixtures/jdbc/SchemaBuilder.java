package com.insurance.e2e.fixtures.jdbc;

import com.insurance.e2e.core.E2eException;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Builds the E2E-owned validation schema from the table definitions the recordings were made on (a DDL file written
 * by the {@code fixtures} stage), so the target reads the fixtures in the table shapes the legacy ran on.
 *
 * <p>Destructive by design - the listed tables are dropped and created again - so it refuses every schema whose name
 * does not start with {@value #PREFIX}: a product schema is never touched. The schema itself is created when missing.
 */
public final class SchemaBuilder {

    public static final String PREFIX = "E2E";

    private SchemaBuilder() {
    }

    /** @throws E2eException unless {@code schema} names an E2E-owned schema */
    public static String requireOwned(String schema) {
        if (schema == null || schema.isBlank()) {
            throw new E2eException("No validation schema: set E2E_DB_SCHEMA to the E2E-owned schema (its name starts with "
                    + PREFIX + ")");
        }
        String name = Identifiers.require(schema.trim()).toUpperCase(Locale.ROOT);
        if (!name.startsWith(PREFIX) || name.contains(".")) {
            throw new E2eException("Refusing to build schema " + name + ": only an E2E-owned schema (a name starting with "
                    + PREFIX + ") is ever dropped and created");
        }
        return name;
    }

    /**
     * Drops the listed tables (reverse order) where they exist and runs the DDL statements in the schema.
     *
     * @param tables the tables the statements create, parents first
     */
    public static void rebuild(Connection connection, String schema, List<String> statements, List<String> tables) {
        String name = requireOwned(schema);
        ensureSchema(connection, name);
        SchemaSwitch.apply(connection, name);
        List<String> reversed = new ArrayList<>(tables);
        Collections.reverse(reversed);
        String current = "";
        try (Statement statement = connection.createStatement()) {
            for (String table : reversed) {
                String plain = Identifiers.require(table.trim()).toUpperCase(Locale.ROOT);
                if (exists(connection, name, plain)) {
                    current = "DROP TABLE " + plain;
                    statement.execute(current);
                }
            }
            for (String sql : statements) {
                current = sql;
                statement.execute(sql);
            }
        } catch (SQLException e) {
            throw new E2eException("Cannot build schema " + name + " (" + e.getMessage() + "): "
                    + (current.length() > 200 ? current.substring(0, 200) + "..." : current), e);
        }
    }

    /**
     * Deletes every row of the listed tables (reverse order: children before parents) in the E2E-owned schema - the
     * empty start a golden master of format 3 was recorded from.
     *
     * @param tables the schema's tables, parents first
     */
    public static void emptyAll(Connection connection, String schema, List<String> tables) {
        String name = requireOwned(schema);
        SchemaSwitch.apply(connection, name);
        List<String> reversed = new ArrayList<>(tables);
        Collections.reverse(reversed);
        String current = "";
        try (Statement statement = connection.createStatement()) {
            for (String table : reversed) {
                current = "DELETE FROM " + Identifiers.require(table.trim()).toUpperCase(Locale.ROOT);
                statement.execute(current);
            }
            if (!connection.getAutoCommit()) {
                connection.commit();
            }
        } catch (SQLException e) {
            throw new E2eException("Cannot empty the tables of " + name + " (" + e.getMessage() + "): " + current, e);
        }
    }

    static void ensureSchema(Connection connection, String name) {
        try {
            try (ResultSet schemas = connection.getMetaData().getSchemas(null, name)) {
                if (schemas.next()) {
                    return;
                }
            }
            try (Statement statement = connection.createStatement()) {
                statement.execute("CREATE SCHEMA " + name);
            }
        } catch (SQLException e) {
            throw new E2eException("Cannot create schema " + name + ": " + e.getMessage(), e);
        }
    }

    /** No table-type filter: the names differ per database ({@code TABLE} on Db2, {@code BASE TABLE} on H2 2). */
    static boolean exists(Connection connection, String schema, String table) throws SQLException {
        try (ResultSet found = connection.getMetaData().getTables(null, schema, table, null)) {
            return found.next();
        }
    }
}
