package com.insurance.e2e.fixtures.jdbc;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.junit.E2eScenarioTests;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.spi.EnvironmentPlugin;
import com.insurance.e2e.core.spi.ExecutionContext;
import com.insurance.e2e.core.spi.PluginRegistry;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class FixturesTest {

    static final String SEED = """
            -- synthetic colour codes; the ; inside the text is data
            DELETE FROM COLOUR_CODE;
            INSERT INTO COLOUR_CODE (CODE, TEXT, AMOUNT) VALUES ('B', 'BLUE; LIGHT', 1.50);
            /* block comment with ; */ INSERT INTO COLOUR_CODE (CODE, TEXT, AMOUNT) VALUES ('C', 'CYAN ''DEEP''', NULL);
            """;

    @TempDir
    Path dir;
    String url;

    @BeforeEach
    void database() throws SQLException {
        url = "jdbc:h2:mem:e2e" + UUID.randomUUID().toString().replace("-", "") + ";DB_CLOSE_DELAY=-1";
        try (Connection c = DriverManager.getConnection(url, "sa", ""); Statement s = c.createStatement()) {
            s.execute("CREATE TABLE COLOUR_CODE (CODE VARCHAR(5) PRIMARY KEY, TEXT VARCHAR(35), AMOUNT DECIMAL(9,2))");
            s.execute("CREATE SCHEMA OTHER");
            s.execute("CREATE TABLE OTHER.COLOUR_CODE (CODE VARCHAR(5) PRIMARY KEY, TEXT VARCHAR(35), AMOUNT DECIMAL(9,2))");
        }
    }

    ExecutionContext context(Map<String, String> extra) {
        return ExecutionContext.builder().environment(Map.of())
                .property("e2e.db.url", url).property("e2e.db.user", "sa").property("e2e.db.password", "")
                .property("e2e.fixtures.dir", dir.toString()).properties(extra).build();
    }

    @Test
    void scriptsSplitOnSemicolonsOutsideStringsAndComments() {
        List<String> statements = SqlScript.split(SEED + "\n  ;\n");

        assertThat(statements).hasSize(3);
        assertThat(statements.get(1)).endsWith("('B', 'BLUE; LIGHT', 1.50)");
        assertThat(statements.get(2)).startsWith("INSERT INTO COLOUR_CODE").contains("'CYAN ''DEEP'''");
        assertThat(SqlScript.tables(statements)).containsExactly("COLOUR_CODE");
        assertThat(SqlScript.split("SELECT \"A;B\" FROM T /* unterminated")).containsExactly("SELECT \"A;B\" FROM T");
        assertThat(SqlScript.tables(List.of("update \"X\".\"T\" set a = 1", "SELECT 1"))).containsExactly("X.T");
    }

    @Test
    void loadingCommitsAndAFailureRollsBack() throws Exception {
        Files.writeString(dir.resolve("seed.sql"), SEED);
        Files.writeString(dir.resolve("broken.sql"), "DELETE FROM COLOUR_CODE; INSERT INTO NO_SUCH_TABLE VALUES (1);");
        try (Connection c = DriverManager.getConnection(url, "sa", "")) {
            assertThat(FixtureLoader.load(c, dir, List.of("seed.sql"))).hasSize(3);
            assertThat(count(c)).isEqualTo(2);
            assertThatThrownBy(() -> FixtureLoader.load(c, dir, List.of("broken.sql")))
                    .isInstanceOf(E2eException.class).hasMessageContaining("statement 2");
            assertThat(count(c)).isEqualTo(2);
            assertThatThrownBy(() -> FixtureLoader.load(c, dir, List.of("missing.sql"))).isInstanceOf(E2eException.class);
        }
    }

    @Test
    void tableStateIgnoresRowOrderButNotContent() throws Exception {
        try (Connection c = DriverManager.getConnection(url, "sa", ""); Statement s = c.createStatement()) {
            s.execute("INSERT INTO COLOUR_CODE VALUES ('B', 'BLUE', 1.50), ('C', NULL, NULL)");
            String first = TableStateHasher.hash(c, List.of("COLOUR_CODE")).combined();
            s.execute("DELETE FROM COLOUR_CODE");
            s.execute("INSERT INTO COLOUR_CODE VALUES ('C', NULL, NULL), ('B', 'BLUE', 1.50)");
            assertThat(TableStateHasher.hash(c, List.of("COLOUR_CODE")).combined()).isEqualTo(first);
            s.execute("UPDATE COLOUR_CODE SET TEXT = '' WHERE CODE = 'C'");
            assertThat(TableStateHasher.hash(c, List.of("COLOUR_CODE")).combined()).isNotEqualTo(first);
            assertThatThrownBy(() -> TableStateHasher.hash(c, List.of("COLOUR_CODE; DROP TABLE X"))).isInstanceOf(E2eException.class);
            assertThatThrownBy(() -> TableStateHasher.hash(c, List.of("NO_SUCH"))).isInstanceOf(E2eException.class);
        }
        assertThat(TableStateHasher.render(new byte[]{1, 15})).isEqualTo("010f");
        assertThat(TableStateHasher.render(new java.math.BigDecimal("1.50"))).isEqualTo("1.50");
    }

    @Test
    void schemaSwitchPointsUnqualifiedNamesAtTheSchema() throws Exception {
        try (Connection c = DriverManager.getConnection(url, "sa", "")) {
            SchemaSwitch.apply(c, "OTHER");
            assertThat(SchemaSwitch.current(c)).isEqualTo("OTHER");
            SchemaSwitch.apply(c, " ");
            assertThat(SchemaSwitch.current(c)).isEqualTo("OTHER");
            assertThatThrownBy(() -> SchemaSwitch.apply(c, "OTHER; DROP")).isInstanceOf(E2eException.class);
            assertThatThrownBy(() -> SchemaSwitch.apply(c, "MISSING")).isInstanceOf(E2eException.class);
        }
    }

    @Test
    void manifestsHashPacksAndDetectChanges() throws IOException {
        Files.writeString(dir.resolve("seed.sql"), SEED);
        String hash = FixtureManifest.packHash(dir, List.of("seed.sql"));
        FixtureManifest manifest = new FixtureManifest("1.0", List.of(
                new FixtureManifest.Pack("base", List.of("seed.sql"), List.of("COLOUR_CODE"), hash),
                new FixtureManifest.Pack("gone", List.of("missing.sql"), null, null)));
        JsonSupport.write(dir.resolve("manifest.json"), manifest);

        FixtureManifest loaded = FixtureManifest.load(dir).orElseThrow();
        assertThat(loaded.pack("base")).isPresent();
        assertThat(loaded.pack("none")).isEmpty();
        assertThat(loaded.verify(dir)).containsExactly("pack gone: file missing.sql is missing");
        Files.writeString(dir.resolve("seed.sql"), SEED + "\n-- edited\n");
        FixtureManifest onlyBase = new FixtureManifest("1.0", List.of(loaded.pack("base").orElseThrow()));
        assertThat(onlyBase.verify(dir)).singleElement().asString().contains("hash mismatch");
        assertThat(FixtureManifest.load(dir.resolve("absent"))).isEmpty();
        assertThatThrownBy(() -> FixtureManifest.packHash(dir, List.of("missing.sql"))).isInstanceOf(E2eException.class);
    }

    @Test
    void aPackHashesTheSameWhateverItsLineEndingsAndAsPythonHashesIt() throws IOException {
        Files.createDirectories(dir.resolve("crlf/P"));
        Files.createDirectories(dir.resolve("lf/P"));
        Files.writeString(dir.resolve("crlf/P/seed.sql"), "INSERT INTO T VALUES (1);\r\nINSERT INTO T VALUES (2);\r\n");
        Files.writeString(dir.resolve("lf/P/seed.sql"), "INSERT INTO T VALUES (1);\nINSERT INTO T VALUES (2);\n");
        String python = "5e0cdcaa28fa490e47ceaeb36a0b24a084f485a5a86d68652bc21bed1c2df1cc";  // e2elib.package.pack_hash

        assertThat(FixtureManifest.packHash(dir.resolve("crlf"), List.of("P/seed.sql"))).isEqualTo(python);
        assertThat(FixtureManifest.packHash(dir.resolve("lf"), List.of("P/seed.sql"))).isEqualTo(python);
        Files.writeString(dir.resolve("lf/P/seed.sql"), "INSERT INTO T VALUES (1);\rINSERT INTO T VALUES (2);\n");
        assertThat(FixtureManifest.packHash(dir.resolve("lf"), List.of("P/seed.sql"))).as("a lone CR is content")
                .isNotEqualTo(python);
    }

    @Test
    void thePluginLoadsPacksAndRawScriptsAndHashesTheResultingState() throws IOException {
        Files.writeString(dir.resolve("seed.sql"), SEED);
        JdbcEnvironmentPlugin plugin = new JdbcEnvironmentPlugin();
        ExecutionContext ctx = context(Map.of());

        assertThat(plugin.availability(ctx).available()).isTrue();
        EnvironmentPlugin.FixtureState raw = plugin.prepare(null, "seed.sql", ctx);
        assertThat(raw.tables()).containsExactly("COLOUR_CODE");
        assertThat(raw.stateHash()).isEqualTo(plugin.stateHash(List.of("COLOUR_CODE"), ctx));

        String hash = FixtureManifest.packHash(dir, List.of("seed.sql"));
        JsonSupport.write(dir.resolve("manifest.json"), new FixtureManifest("1.0", List.of(
                new FixtureManifest.Pack("base", List.of("seed.sql"), List.of("COLOUR_CODE"), hash),
                new FixtureManifest.Pack("stale", List.of("seed.sql"), null, "0".repeat(64)))));
        EnvironmentPlugin.FixtureState pack = plugin.prepare(null, "base", ctx);
        assertThat(pack.packHash()).isEqualTo(hash).isEqualTo(raw.packHash());
        assertThat(pack.stateHash()).isEqualTo(raw.stateHash());
        assertThatThrownBy(() -> plugin.prepare(null, "stale", ctx)).hasMessageContaining("changed after it was hashed");

        assertThat(PluginRegistry.discover().environment(EnvironmentPlugin.JDBC)).isInstanceOf(JdbcEnvironmentPlugin.class);
        assertThat(plugin.id()).isEqualTo("jdbc-environment");
    }

    @Test
    void availabilityAndConfigurationErrorsAreExplained() {
        JdbcEnvironmentPlugin plugin = new JdbcEnvironmentPlugin();
        ExecutionContext none = ExecutionContext.builder().environment(Map.of()).build();
        assertThat(plugin.availability(none).reason()).contains("E2E_DB_URL");
        ExecutionContext wrong = ExecutionContext.builder().environment(Map.of())
                .property("e2e.db.url", "jdbc:nosuchdriver://x").build();
        assertThat(plugin.availability(wrong).reason()).contains("not reachable");
        assertThatThrownBy(() -> plugin.stateHash(List.of("T"), wrong)).isInstanceOf(E2eException.class);
        assertThatThrownBy(() -> plugin.prepare(null, "x.sql", none)).hasMessageContaining("No fixtures directory");
        assertThatThrownBy(() -> JdbcEnvironmentPlugin.connect(none)).hasMessageContaining("E2E_DB_URL");

        ExecutionContext fromHelper = ExecutionContext.builder().environment(Map.of())
                .attribute(E2eScenarioTests.RESOURCES_DIR_ATTRIBUTE, dir).build();
        assertThat(JdbcEnvironmentPlugin.fixturesDir(fromHelper)).isEqualTo(dir.resolve("fixtures"));
        ExecutionContext schema = context(Map.of("e2e.db.schema", "OTHER"));
        assertThat(plugin.availability(schema).available()).isTrue();
    }

    static final String DDL = """
            -- E2E schema subset (synthetic): parents first
            CREATE TABLE COLOUR_KEY (CODE VARCHAR(5) NOT NULL, CONSTRAINT COLOUR_KEY_PK PRIMARY KEY (CODE));
            CREATE TABLE COLOUR_CODE (CODE VARCHAR(5) NOT NULL, TEXT VARCHAR(35), AMOUNT DECIMAL(9,2),
              CONSTRAINT COLOUR_CODE_PK PRIMARY KEY (CODE),
              CONSTRAINT COLOUR_CODE_FK FOREIGN KEY (CODE) REFERENCES COLOUR_KEY (CODE));
            CREATE INDEX COLOUR_CODE_X1 ON COLOUR_CODE (TEXT);
            CREATE TABLE LOAD_LOG (N INTEGER);
            """;

    static final String COUNTED_SEED = """
            DELETE FROM COLOUR_CODE;
            DELETE FROM COLOUR_KEY;
            INSERT INTO COLOUR_KEY (CODE) VALUES ('B'), ('C');
            INSERT INTO COLOUR_CODE (CODE, TEXT, AMOUNT) VALUES ('B', 'BLUE', 1.50), ('C', 'CYAN', NULL);
            INSERT INTO LOAD_LOG (N) VALUES (1);
            """;

    @Test
    void theSchemaBuilderOnlyEverTouchesAnE2eOwnedSchema() throws Exception {
        assertThatThrownBy(() -> SchemaBuilder.requireOwned(null)).hasMessageContaining("No validation schema");
        assertThatThrownBy(() -> SchemaBuilder.requireOwned("APPSCHEMA")).hasMessageContaining("Refusing to build schema APPSCHEMA");
        assertThatThrownBy(() -> SchemaBuilder.requireOwned("E2E.X")).hasMessageContaining("Refusing");
        assertThatThrownBy(() -> SchemaBuilder.requireOwned("E2E; DROP")).isInstanceOf(E2eException.class);
        assertThat(SchemaBuilder.requireOwned(" e2e_p1 ")).isEqualTo("E2E_P1");

        List<String> tables = List.of("COLOUR_KEY", "COLOUR_CODE", "LOAD_LOG");
        try (Connection c = DriverManager.getConnection(url, "sa", ""); Statement s = c.createStatement()) {
            SchemaBuilder.rebuild(c, "E2E_T", SqlScript.split(DDL), tables);
            s.execute("INSERT INTO E2E_T.LOAD_LOG VALUES (7)");
            SchemaBuilder.rebuild(c, "E2E_T", SqlScript.split(DDL), tables);
            try (var r = s.executeQuery("SELECT COUNT(*) FROM E2E_T.LOAD_LOG")) {
                r.next();
                assertThat(r.getInt(1)).as("rebuilt empty").isZero();
            }
            assertThat(count(c)).as("the product's table outside the schema is untouched").isZero();
            assertThatThrownBy(() -> SchemaBuilder.rebuild(c, "E2E_T", List.of("CREATE TABLE BROKEN ("), List.of("BROKEN")))
                    .isInstanceOf(E2eException.class).hasMessageContaining("CREATE TABLE BROKEN");
            assertThatThrownBy(() -> SchemaBuilder.rebuild(c, "OTHER", SqlScript.split(DDL), tables))
                    .hasMessageContaining("Refusing");
        }
    }

    @Test
    void thePluginBuildsTheDeclaredSchemaOnceAndReusesALoadedPackUntilAScenarioWrites() throws Exception {
        Files.createDirectories(dir.resolve("schema"));
        Files.writeString(dir.resolve("schema").resolve("recording.sql"), DDL);
        Files.writeString(dir.resolve("seed.sql"), COUNTED_SEED);
        FixtureManifest.SchemaPack schema = new FixtureManifest.SchemaPack("schema/recording.sql",
                List.of("COLOUR_KEY", "COLOUR_CODE", "LOAD_LOG"), "synthetic recording schema",
                JsonSupport.sha256Hex(dir.resolve("schema").resolve("recording.sql")));
        FixtureManifest manifest = new FixtureManifest("1.0", List.of(new FixtureManifest.Pack("base",
                List.of("seed.sql"), List.of("COLOUR_KEY", "COLOUR_CODE"), FixtureManifest.packHash(dir, List.of("seed.sql")))),
                schema);
        JsonSupport.write(dir.resolve("manifest.json"), manifest);
        JdbcEnvironmentPlugin plugin = new JdbcEnvironmentPlugin();
        ExecutionContext ctx = context(Map.of("e2e.db.schema", "E2E_RUN"));

        assertThat(plugin.availability(context(Map.of())).reason()).contains("No validation schema");
        assertThat(plugin.availability(context(Map.of("e2e.db.schema", "OTHER"))).reason()).contains("Refusing");
        assertThat(plugin.availability(ctx).available()).isTrue();
        EnvironmentPlugin.FixtureState first = plugin.prepare(null, "base", ctx);
        EnvironmentPlugin.FixtureState reused = plugin.prepare(null, "base", ctx);
        assertThat(loads()).as("one load serves the scenarios of a fixture").isEqualTo(1);
        assertThat(reused.stateHash()).isEqualTo(first.stateHash());

        try (Connection c = DriverManager.getConnection(url, "sa", ""); Statement s = c.createStatement()) {
            s.execute("INSERT INTO E2E_RUN.COLOUR_KEY VALUES ('X')");
        }
        assertThat(plugin.stateHash(first.tables(), ctx)).isNotEqualTo(first.stateHash());
        EnvironmentPlugin.FixtureState reloaded = plugin.prepare(null, "base", ctx);
        assertThat(loads()).as("a scenario that wrote makes the next one reload").isEqualTo(2);
        assertThat(reloaded.stateHash()).isEqualTo(first.stateHash());
        assertThat(manifest.verify(dir)).isEmpty();

        Files.writeString(dir.resolve("schema").resolve("recording.sql"), DDL + "\n-- edited\n");
        assertThat(manifest.verify(dir)).singleElement().asString().contains("schema: hash mismatch");
        assertThatThrownBy(() -> plugin.prepare(null, "base", context(Map.of("e2e.db.schema", "E2E_OTHER"))))
                .hasMessageContaining("changed after it was hashed");
        Files.delete(dir.resolve("schema").resolve("recording.sql"));
        assertThat(manifest.verify(dir)).singleElement().asString().contains("schema: file schema/recording.sql is missing");
        assertThatThrownBy(() -> plugin.prepare(null, "base", context(Map.of("e2e.db.schema", "E2E_THIRD"))))
                .hasMessageContaining("does not exist");
    }

    private int loads() throws SQLException {
        try (Connection c = DriverManager.getConnection(url, "sa", ""); Statement s = c.createStatement();
             var r = s.executeQuery("SELECT COUNT(*) FROM E2E_RUN.LOAD_LOG")) {
            r.next();
            return r.getInt(1);
        }
    }

    private static int count(Connection c) throws SQLException {
        try (Statement s = c.createStatement(); var r = s.executeQuery("SELECT COUNT(*) FROM PUBLIC.COLOUR_CODE")) {
            r.next();
            return r.getInt(1);
        }
    }
}
