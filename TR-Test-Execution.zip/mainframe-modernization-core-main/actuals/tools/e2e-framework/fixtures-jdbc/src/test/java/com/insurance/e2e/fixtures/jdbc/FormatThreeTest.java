package com.insurance.e2e.fixtures.jdbc;

import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.spi.EnvironmentPlugin;
import com.insurance.e2e.core.spi.ExecutionContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Golden-master packages of format 3: every recording started from empty tables plus its fixture, and a table check
 * reads the rows a call left - typed as the package holds them.
 */
class FormatThreeTest {

    static final String DDL = """
            CREATE TABLE PARENT (ID CHAR(4) NOT NULL PRIMARY KEY, AMT DECIMAL(9,2), DT DATE);
            CREATE TABLE CHILD (PID CHAR(4) NOT NULL, SEQ SMALLINT NOT NULL, NOTE VARCHAR(10),
              CONSTRAINT CHILD_FK FOREIGN KEY (PID) REFERENCES PARENT (ID));
            """;

    @TempDir
    Path dir;
    String url;

    @BeforeEach
    void database() throws Exception {
        url = "jdbc:h2:mem:f3" + UUID.randomUUID().toString().replace("-", "") + ";DB_CLOSE_DELAY=-1";
        Files.writeString(dir.resolve("schema.sql"), DDL);
        Files.writeString(dir.resolve("one.sql"), "INSERT INTO PARENT (ID, AMT, DT) VALUES ('A1', 1000.00, DATE '2024-08-16');\n"
                + "INSERT INTO CHILD (PID, SEQ, NOTE) VALUES ('A1', 1, NULL);\n");
        FixtureManifest manifest = new FixtureManifest("1.0",
                List.of(new FixtureManifest.Pack("one", List.of("one.sql"), List.of(), null)),
                new FixtureManifest.SchemaPack("schema.sql", List.of("PARENT", "CHILD"), "unit/schema.sql", null),
                FixtureManifest.RESET_ALL_TABLES);
        JsonSupport.write(dir.resolve("manifest.json"), manifest);
    }

    ExecutionContext context() {
        return ExecutionContext.builder().environment(Map.of())
                .property("e2e.db.url", url).property("e2e.db.user", "sa").property("e2e.db.password", "")
                .property("e2e.db.schema", "E2E_F3").property("e2e.fixtures.dir", dir.toString()).build();
    }

    @Test
    void everyTableIsEmptiedBeforeThePackAndAWriteMakesTheNextScenarioReload() throws Exception {
        JdbcEnvironmentPlugin plugin = new JdbcEnvironmentPlugin();
        ExecutionContext context = context();
        EnvironmentPlugin.FixtureState first = plugin.prepare(null, "one", context);
        assertThat(first.tables()).containsExactly("PARENT", "CHILD");

        try (Connection c = DriverManager.getConnection(url, "sa", ""); Statement s = c.createStatement()) {
            s.execute("SET SCHEMA E2E_F3");
            s.execute("INSERT INTO PARENT (ID) VALUES ('ZZ')");                       // another case's leftover
            s.execute("INSERT INTO CHILD (PID, SEQ) VALUES ('ZZ', 9)");
        }
        EnvironmentPlugin.FixtureState second = plugin.prepare(null, "one", context);

        assertThat(second.stateHash()).isEqualTo(first.stateHash());
        assertThat(plugin.rows("SELECT ID FROM PARENT ORDER BY ID", context)).extracting(r -> r.get("ID"))
                .containsExactly("A1  ");
        assertThat(plugin.rows("SELECT COUNT(*) AS N FROM CHILD", context).get(0).get("N")).isEqualTo(1L);
    }

    @Test
    void theRowsOfATableCheckAreTypedAsAPackageHoldsThem() {
        JdbcEnvironmentPlugin plugin = new JdbcEnvironmentPlugin();
        ExecutionContext context = context();
        plugin.prepare(null, "one", context);

        List<Map<String, Object>> parent = plugin.rows("SELECT ID, AMT, DT FROM PARENT", context);
        List<Map<String, Object>> child = plugin.rows("SELECT PID, SEQ, NOTE FROM CHILD", context);

        assertThat(parent.get(0)).containsEntry("ID", "A1  ").containsEntry("DT", "2024-08-16");
        assertThat((BigDecimal) parent.get(0).get("AMT")).isEqualByComparingTo("1000");
        assertThat(child.get(0)).containsEntry("SEQ", 1L).containsEntry("NOTE", null);
    }

    @Test
    void withoutTheResetAPackLoadsOnTopOfTheTablesAsBefore() throws Exception {
        FixtureManifest manifest = JsonSupport.read(dir.resolve("manifest.json"), FixtureManifest.class);
        JsonSupport.write(dir.resolve("manifest.json"), new FixtureManifest(manifest.schemaVersion(), manifest.packs(),
                manifest.schema()));
        JdbcEnvironmentPlugin plugin = new JdbcEnvironmentPlugin();
        ExecutionContext context = context();
        EnvironmentPlugin.FixtureState state = plugin.prepare(null, "one", context);

        assertThat(state.tables()).containsExactly("PARENT", "CHILD");
        assertThat(new FixtureManifest("1.0", List.of()).resetsAllTables()).isFalse();
    }
}
