package com.insurance.e2e.spring.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/** Synthetic application for the target-binding tests (stands in for a product's application class). */
@Configuration
public class DemoApplication {

    public record DemoRequest(String tableName, String searchValue, Integer effectiveDate) {
    }

    public record DemoItem(String code, String text) {
    }

    public record DemoResponse(int responseCode, String message, List<DemoItem> items, BigDecimal amount,
                               LocalDate asOf) {
    }

    public static class DemoNotFoundException extends RuntimeException {
        public DemoNotFoundException(String message) {
            super(message);
        }
    }

    public static class SpecificNotFoundException extends DemoNotFoundException {
        public SpecificNotFoundException(String message) {
            super(message);
        }
    }

    public static class DemoLookupService {
        public DemoResponse lookup(DemoRequest request) {
            if ("NONE".equals(request.tableName())) {
                throw new SpecificNotFoundException("LOOKUP HELP NOT AVAILABLE FOR " + request.tableName());
            }
            if ("BOOM".equals(request.tableName())) {
                throw new IllegalStateException("database unavailable");
            }
            return new DemoResponse(0, "", List.of(new DemoItem("B", "BLUE"), new DemoItem("C", "CYAN")),
                    new BigDecimal("1.50"), LocalDate.of(2024, 1, 1));
        }

        public List<DemoItem> codes(String search) {
            return List.of(new DemoItem(search, "TEXT " + search));
        }

        public String join(String a, int b) {
            return a + "/" + b;
        }

        public String over(String a) {
            return a;
        }

        public String over(String a, String b) {
            return a + b;
        }

        public String nothing() {
            return "nothing";
        }

        public String twin(String value) {
            return value;
        }

        public String twin(Integer value) {
            return String.valueOf(value);
        }
    }

    @Bean
    public DemoLookupService demoLookupService() {
        return new DemoLookupService();
    }
}
