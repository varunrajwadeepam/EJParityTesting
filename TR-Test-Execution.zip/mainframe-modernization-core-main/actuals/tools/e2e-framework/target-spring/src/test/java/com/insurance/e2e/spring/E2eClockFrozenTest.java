package com.insurance.e2e.spring;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/** A key derived from the moment itself (seconds, microseconds) matches only on a clock frozen at the recorded instant. */
class E2eClockFrozenTest {

    @AfterEach
    void release() {
        E2eClock.instance().release();
    }

    @Test
    void aLegacyClockMayCarryFractionDigitsOfTheSecond() {
        assertThat(E2eClock.parse("20240816103000")).isEqualTo(LocalDateTime.of(2024, 8, 16, 10, 30, 0));
        assertThat(E2eClock.parse("2024081610300012").getNano()).isEqualTo(120_000_000);
        assertThat(E2eClock.parse("20240816103000123456").getNano()).isEqualTo(123_456_000);
        assertThatThrownBy(() -> E2eClock.parse("2024-08-16"))
                .isInstanceOf(java.time.format.DateTimeParseException.class);
    }

    @Test
    void aFrozenClockShowsExactlyTheRecordedInstant() throws InterruptedException {
        E2eClock clock = E2eClock.instance();
        clock.pin("20240816103000123456", true);
        LocalDateTime first = LocalDateTime.now(clock);
        Thread.sleep(15);
        assertThat(LocalDateTime.now(clock)).isEqualTo(first).isEqualTo(LocalDateTime.of(2024, 8, 16, 10, 30, 0, 123_456_000));
        assertThat(clock.pinned()).isTrue();

        clock.pin("20240816103000", false);
        LocalDateTime advancing = LocalDateTime.now(clock);
        Thread.sleep(15);
        assertThat(LocalDateTime.now(clock)).isAfter(advancing);
    }
}
