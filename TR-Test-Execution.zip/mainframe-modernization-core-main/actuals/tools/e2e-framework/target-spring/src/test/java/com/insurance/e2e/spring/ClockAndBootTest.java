package com.insurance.e2e.spring;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.spi.ExecutionContext;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeParseException;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ClockAndBootTest {

    /** A synthetic application with a clock bean (as products inject {@link Clock} to read "today"). */
    @Configuration
    public static class ClockApplication {

        public record TodayService(Clock clock, String greeting) {
            public LocalDate today() {
                return LocalDate.now(clock);
            }
        }

        @Bean
        public Clock clock() {
            return Clock.systemUTC();
        }

        @Bean
        public TodayService todayService(Clock clock, @Value("${demo.greeting:none}") String greeting) {
            return new TodayService(clock, greeting);
        }
    }

    @AfterEach
    void release() {
        E2eClock.instance().release();
    }

    @AfterAll
    static void close() {
        SpringContexts.closeAll();
    }

    static ExecutionContext context(Map<String, String> properties) {
        return ExecutionContext.builder().property(SpringContexts.MAIN_CLASS, ClockApplication.class.getName())
                .properties(properties).environment(Map.of()).build();
    }

    @Test
    void thePinnedClockShowsTheLegacyClockAndAdvancesFromThere() {
        E2eClock clock = E2eClock.instance();
        assertThat(clock.pinned()).isFalse();

        clock.pin("20240816103000");

        assertThat(clock.pinned()).isTrue();
        assertThat(LocalDate.now(clock)).isEqualTo(LocalDate.of(2024, 8, 16));
        assertThat(LocalDateTime.now(clock)).isBetween(LocalDateTime.of(2024, 8, 16, 10, 30),
                LocalDateTime.of(2024, 8, 16, 10, 31));
        Clock utc = clock.withZone(ZoneOffset.UTC);
        assertThat(utc.getZone()).isEqualTo(ZoneOffset.UTC);
        assertThat(utc.instant()).isCloseTo(clock.instant(), org.assertj.core.api.Assertions.within(1,
                java.time.temporal.ChronoUnit.SECONDS));
        assertThat(clock.withZone(clock.getZone())).isSameAs(clock);
        clock.release();
        assertThat(LocalDate.now(clock)).isEqualTo(LocalDate.now());
        assertThatThrownBy(() -> clock.pin("2024-08-16")).isInstanceOf(DateTimeParseException.class);
    }

    @Test
    void theBootedApplicationGetsTheE2eClockAndTheRunLevelOverrides() {
        ApplicationContext app = SpringContexts.resolve(context(Map.of(SpringContexts.PROPERTIES,
                "{\"demo.greeting\":\"hello\"}")));
        ClockApplication.TodayService service = app.getBean(ClockApplication.TodayService.class);

        assertThat(service.clock()).isSameAs(E2eClock.instance());
        assertThat(service.greeting()).isEqualTo("hello");
        E2eClock.instance().pin("20240816103000");
        assertThat(service.today()).isEqualTo(LocalDate.of(2024, 8, 16));

        ApplicationContext unpinned = SpringContexts.resolve(context(Map.of(SpringContexts.PIN_CLOCK, "false")));
        assertThat(unpinned).isNotSameAs(app);
        assertThat(unpinned.getBean(ClockApplication.TodayService.class).clock()).isNotInstanceOf(E2eClock.class);
    }

    @Test
    void argumentsCarryTheOverridesAndARandomPortForAWebServer() {
        ExecutionContext plain = context(Map.of());
        ExecutionContext withPort = context(Map.of(SpringContexts.PROPERTIES,
                "{\"server.port\":\"8181\",\"app.flag\":false}"));

        assertThat(SpringContexts.arguments(plain, "NONE")).isEmpty();
        assertThat(SpringContexts.arguments(plain, "SERVLET")).containsExactly("--server.port=0");
        assertThat(SpringContexts.arguments(withPort, "SERVLET")).containsExactly("--server.port=8181", "--app.flag=false");
        assertThat(SpringContexts.pinClock(plain)).isTrue();
        assertThatThrownBy(() -> SpringContexts.arguments(context(Map.of(SpringContexts.PROPERTIES, "{nope")), "NONE"))
                .isInstanceOf(E2eException.class).hasMessageContaining("JSON object");
        assertThatThrownBy(() -> SpringContexts.arguments(context(Map.of(SpringContexts.PROPERTIES, "[1]")), "NONE"))
                .isInstanceOf(E2eException.class).hasMessageContaining("must be a JSON object");
    }

    @Test
    void aBootPropertiesSourceWinsOverTheOverridesAndEachPropertyIsGivenOnce() {
        ExecutionContext both = context(Map.of(SpringContexts.PROPERTIES, "{\"app.security.enabled\":\"false\",\"app.x\":1}",
                TestBootProperties.SWITCH, "on"));

        assertThat(SpringContexts.arguments(both, "SERVLET")).containsExactly(
                "--app.security.enabled=true", "--app.x=1", "--app.issuer=http://127.0.0.1/e2e-issuer", "--server.port=0");
        assertThat(SpringContexts.arguments(context(Map.of(TestBootProperties.SWITCH, "on")), "NONE"))
                .as("the source decides by the boot's web type").isEmpty();
    }

    @Test
    void theBasementsLoggingConfigurationAppliesUnlessTheOverridesNameOne(@TempDir Path basement) throws Exception {
        Files.createDirectories(basement.resolve("e2e"));
        Files.writeString(basement.resolve(SpringContexts.LOGGING_CONFIG), "<configuration/>");
        ClassLoader previous = Thread.currentThread().getContextClassLoader();
        try (URLClassLoader withBasement = new URLClassLoader(new URL[] {basement.toUri().toURL()}, previous)) {
            Thread.currentThread().setContextClassLoader(withBasement);

            assertThat(SpringContexts.arguments(context(Map.of()), "NONE"))
                    .containsExactly("--logging.config=classpath:e2e/logback-e2e.xml");
            assertThat(SpringContexts.arguments(context(Map.of(SpringContexts.PROPERTIES,
                    "{\"logging.config\":\"file:own.xml\"}")), "NONE")).containsExactly("--logging.config=file:own.xml");
        } finally {
            Thread.currentThread().setContextClassLoader(previous);
        }
        assertThat(SpringContexts.arguments(context(Map.of()), "NONE")).as("no basement file, nothing added").isEmpty();
    }

    @Test
    void anUnknownApplicationClassIsExplained() {
        ExecutionContext missing = ExecutionContext.builder().property(SpringContexts.MAIN_CLASS, "org.example.Nope")
                .environment(Map.of()).build();

        assertThatThrownBy(() -> SpringContexts.resolve(missing, "none"))
                .isInstanceOf(E2eException.class).hasMessageContaining("not on the test classpath");
    }
}
