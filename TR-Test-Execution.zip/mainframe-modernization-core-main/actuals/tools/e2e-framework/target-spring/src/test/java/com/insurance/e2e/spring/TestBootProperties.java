package com.insurance.e2e.spring;

import com.insurance.e2e.core.spi.ExecutionContext;

import java.util.LinkedHashMap;
import java.util.Map;

/** A {@link BootProperties} source of the tests only (META-INF/services of the test classpath): off unless switched on. */
public final class TestBootProperties implements BootProperties {

    static final String SWITCH = "e2e.test.boot-properties";

    @Override
    public Map<String, String> properties(ExecutionContext context, String web) {
        if (context.property(SWITCH) == null || "NONE".equals(web)) {
            return Map.of();
        }
        Map<String, String> out = new LinkedHashMap<>();
        out.put("app.security.enabled", "true");
        out.put("app.issuer", "http://127.0.0.1/e2e-issuer");
        return out;
    }
}
