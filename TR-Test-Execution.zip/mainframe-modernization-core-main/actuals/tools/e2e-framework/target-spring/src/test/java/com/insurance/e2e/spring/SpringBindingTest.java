package com.insurance.e2e.spring;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.compare.FieldMapping;
import com.insurance.e2e.core.compare.FieldType;
import com.insurance.e2e.core.compare.GroupMapping;
import com.insurance.e2e.core.compare.OutcomeMapping;
import com.insurance.e2e.core.compare.ViewMapping;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.observation.Outcome;
import com.insurance.e2e.core.scenario.BindingRef;
import com.insurance.e2e.core.scenario.LevelBinding;
import com.insurance.e2e.core.scenario.Scenario;
import com.insurance.e2e.core.spi.CapturePlugin;
import com.insurance.e2e.core.spi.ExecutionContext;
import com.insurance.e2e.core.spi.PluginRegistry;
import com.insurance.e2e.core.spi.TriggerPlugin;
import com.insurance.e2e.spring.demo.DemoApplication;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class SpringBindingTest {

    static AnnotationConfigApplicationContext context;

    static final ViewMapping MAPPING = new ViewMapping("1.0", "DEMO0001", null,
            List.of(new FieldMapping("TABLE-NAME-0001", "tableName", FieldType.STRING, false, null),
                    new FieldMapping("SEARCH-VALUE-0001", "searchValue", FieldType.STRING, false, null),
                    new FieldMapping("EFF-DT-0001", "effectiveDate", FieldType.NUMBER, false, null)),
            List.of(new FieldMapping("RESPONSE-CODE-0002", "responseCode", FieldType.NUMBER, false, null),
                    new FieldMapping("AMOUNT-0002", "amount", FieldType.NUMBER, false, null)),
            List.of(new GroupMapping("rows", "items", null, List.of(new FieldMapping("CODE-0003", "code", FieldType.CODE, false, null)))),
            List.of(), List.of(), new OutcomeMapping("EXIT-STATE", null, List.of(
                    new OutcomeMapping.ExceptionRule("DemoNotFoundException", "BUSINESS_EXCEPTION", 1837641424L, "NOT AVAILABLE"))));

    @BeforeAll
    static void boot() {
        context = new AnnotationConfigApplicationContext(DemoApplication.class);
    }

    @AfterAll
    static void close() {
        context.close();
        SpringContexts.closeAll();
    }

    static Map<String, String> request(String table) {
        Map<String, String> request = new LinkedHashMap<>();
        request.put("TABLE-NAME-0001", table);
        request.put("SEARCH-VALUE-0001", "B");
        request.put("EFF-DT-0001", "20240101");
        request.put("UNMAPPED-0001", "ignored");
        return request;
    }

    static Scenario scenario(String table) {
        return new Scenario("S-" + table, null, null, null, "P0", null, null, null, null,
                List.of(new LevelBinding(null, BindingRef.parse("LEG-SP:DEMO0001"), BindingRef.parse("TGT-SP:DemoLookupService.lookup"), null)),
                null, null, null, request(table), null, null, null);
    }

    @Test
    void targetReferencesParse() {
        assertThat(TargetRef.parse("DemoLookupService.lookup")).satisfies(r -> {
            assertThat(r.type()).isEqualTo("DemoLookupService");
            assertThat(r.method()).isEqualTo("lookup");
            assertThat(r.byBeanName()).isFalse();
        });
        assertThat(TargetRef.parse("org.example.Service.call").type()).isEqualTo("org.example.Service");
        assertThat(TargetRef.parse("demoLookupService#codes").beanName()).isEqualTo("demoLookupService");
        assertThat(TargetRef.parse("bean#m")).hasToString("bean#m");
        assertThat(TargetRef.parse("T.m")).hasToString("T.m");
        assertThatThrownBy(() -> TargetRef.parse("nomethod")).isInstanceOf(E2eException.class);
        assertThatThrownBy(() -> TargetRef.parse(" ")).isInstanceOf(E2eException.class);
        assertThatThrownBy(() -> TargetRef.parse("Type.")).isInstanceOf(E2eException.class);
    }

    @Test
    void beansAreFoundByTypeNameOrBeanName() {
        assertThat(BeanLocator.locate(context, TargetRef.parse("DemoLookupService.lookup")))
                .isInstanceOf(DemoApplication.DemoLookupService.class);
        assertThat(BeanLocator.locate(context, TargetRef.parse(DemoApplication.DemoLookupService.class.getName() + ".lookup")))
                .isNotNull();
        assertThat(BeanLocator.locate(context, TargetRef.parse("demoLookupService#lookup"))).isNotNull();
        assertThatThrownBy(() -> BeanLocator.locate(context, TargetRef.parse("Missing.lookup"))).hasMessageContaining("No bean of type");
        assertThatThrownBy(() -> BeanLocator.locate(context, TargetRef.parse("nobean#lookup"))).hasMessageContaining("No bean named");
        try (AnnotationConfigApplicationContext twice = new AnnotationConfigApplicationContext()) {
            twice.registerBean("one", DemoApplication.DemoLookupService.class);
            twice.registerBean("two", DemoApplication.DemoLookupService.class);
            twice.refresh();
            assertThatThrownBy(() -> BeanLocator.locate(twice, TargetRef.parse("DemoLookupService.lookup")))
                    .hasMessageContaining("Several beans");
        }
        assertThat(BeanLocator.matches(java.util.ArrayList.class, "List")).isTrue();
    }

    @Test
    void requestsBindThroughTheMappingInputs() throws Exception {
        SpringTargetInvoker.Invocation invocation = SpringTargetInvoker.invoke(context,
                TargetRef.parse("DemoLookupService.lookup"), request("COLOUR"), MAPPING);

        assertThat(invocation.failure()).isNull();
        assertThat(((DemoApplication.DemoResponse) invocation.value()).items()).hasSize(2);

        ViewMapping scalar = mapping(List.of(new FieldMapping("SEARCH-VALUE-0001", "$", FieldType.STRING, false, null)));
        assertThat(SpringTargetInvoker.invoke(context, TargetRef.parse("DemoLookupService.codes"), request("X"), scalar).value())
                .asString().contains("TEXT B");

        ViewMapping positional = mapping(List.of(new FieldMapping("TABLE-NAME-0001", "arg0", FieldType.STRING, false, null),
                new FieldMapping("EFF-DT-0001", "arg1", FieldType.NUMBER, false, null)));
        assertThat(SpringTargetInvoker.invoke(context, TargetRef.parse("DemoLookupService.join"), request("T"), positional).value())
                .isEqualTo("T/20240101");
        assertThat(SpringTargetInvoker.invoke(context, TargetRef.parse("DemoLookupService.over"), request("T"), positional).value())
                .isEqualTo("T20240101");
        assertThat(SpringTargetInvoker.invoke(context, TargetRef.parse("DemoLookupService.nothing"), request("T"), null).value())
                .isEqualTo("nothing");

        ViewMapping tooFar = mapping(List.of(new FieldMapping("TABLE-NAME-0001", "arg3", FieldType.STRING, false, null)));
        assertThatThrownBy(() -> SpringTargetInvoker.invoke(context, TargetRef.parse("DemoLookupService.lookup"), request("T"), tooFar))
                .hasMessageContaining("addresses parameter 3");
        ViewMapping notANumber = mapping(List.of(new FieldMapping("TABLE-NAME-0001", "effectiveDate", FieldType.NUMBER, false, null)));
        assertThatThrownBy(() -> SpringTargetInvoker.invoke(context, TargetRef.parse("DemoLookupService.lookup"), request("T"), notANumber))
                .hasMessageContaining("not a number");
        assertThatThrownBy(() -> SpringTargetInvoker.invoke(context, TargetRef.parse("DemoLookupService.absent"), request("T"), MAPPING))
                .hasMessageContaining("No public method");
        ViewMapping wrongType = mapping(List.of(new FieldMapping("TABLE-NAME-0001", "arg1", FieldType.STRING, false, null)));
        assertThatThrownBy(() -> SpringTargetInvoker.invoke(context, TargetRef.parse("DemoLookupService.join"), request("T"), wrongType))
                .hasMessageContaining("Cannot bind parameter 1");
        assertThat(RequestBinder.arity(null)).isZero();
        assertThat(RequestBinder.put(null, "a.b.c", RequestBinder.value("1", FieldType.NUMBER)).toString()).isEqualTo("{\"a\":{\"b\":{\"c\":1}}}");
        assertThat(RequestBinder.value(null, FieldType.STRING).isNull()).isTrue();
    }

    @Test
    void anUnmappedRequestBindsAsItStands() {
        ViewMapping none = mapping(List.of());
        Map<String, String> request = Map.of("tableName", "COLOUR", "searchValue", "B");
        assertThat(SpringTargetInvoker.invoke(context, TargetRef.parse("DemoLookupService.lookup"), request, none).failure()).isNull();
        // no inputs: the one-parameter overload is chosen, and a map does not bind to a String
        assertThatThrownBy(() -> SpringTargetInvoker.invoke(context, TargetRef.parse("DemoLookupService.over"), request, none))
                .hasMessageContaining("Cannot bind parameter 0");
        ViewMapping one = mapping(List.of(new FieldMapping("tableName", "$", FieldType.STRING, false, null)));
        assertThatThrownBy(() -> SpringTargetInvoker.invoke(context, TargetRef.parse("DemoLookupService.twin"), request, one))
                .hasMessageContaining("overloaded");
    }

    @Test
    void exceptionsMapThroughTheOutcomeCatalogue() {
        Outcome business = OutcomeCatalogue.classify(new InvocationTargetException(
                new DemoApplication.SpecificNotFoundException("LOOKUP HELP NOT AVAILABLE FOR X")), MAPPING.outcome());
        assertThat(business.kind()).isEqualTo(Outcome.Kind.BUSINESS_EXCEPTION);
        assertThat(business.exitState()).isEqualTo(1837641424L);
        assertThat(business.exceptionType()).endsWith("SpecificNotFoundException");

        Outcome wrongMessage = OutcomeCatalogue.classify(new DemoApplication.DemoNotFoundException("other"), MAPPING.outcome());
        assertThat(wrongMessage.kind()).isEqualTo(Outcome.Kind.TECHNICAL_FAILURE);

        Outcome viaCause = OutcomeCatalogue.classify(new RuntimeException("wrapped",
                new DemoApplication.DemoNotFoundException("NOT AVAILABLE")), MAPPING.outcome());
        assertThat(viaCause.exitState()).isEqualTo(1837641424L);

        OutcomeMapping technical = new OutcomeMapping(null, null, List.of(
                new OutcomeMapping.ExceptionRule(IllegalStateException.class.getName(), "technical_failure", null, null),
                new OutcomeMapping.ExceptionRule("Other", null, 1L, " ")));
        assertThat(OutcomeCatalogue.classify(new IllegalStateException("x"), technical).kind()).isEqualTo(Outcome.Kind.TECHNICAL_FAILURE);
        assertThat(OutcomeCatalogue.classify(new IllegalArgumentException("x"), null).exceptionType()).isEqualTo(IllegalArgumentException.class.getName());
    }

    @Test
    void pluginsTriggerAndCaptureInsideTheContext() {
        ExecutionContext ctx = ExecutionContext.builder().environment(Map.of())
                .attribute(org.springframework.context.ApplicationContext.class.getName(), context).build();
        SpringTriggerPlugin trigger = new SpringTriggerPlugin();
        SpringCapturePlugin capture = new SpringCapturePlugin();
        BindingRef ref = BindingRef.parse("TGT-SP:DemoLookupService.lookup");

        assertThat(trigger.availability(ctx).available()).isTrue();
        TriggerPlugin.TriggerResult ok = trigger.trigger(new TriggerPlugin.Request(ref, scenario("COLOUR"), MAPPING, ctx));
        Observation observation = capture.capture(new CapturePlugin.Request(ref, ok, scenario("COLOUR"), MAPPING, ctx));
        Observation canonical = MAPPING.toCanonical(observation);
        assertThat(canonical.fields()).containsEntry("RESPONSE-CODE-0002", "0").containsEntry("AMOUNT-0002", "1.50");
        assertThat(canonical.groups().get("rows")).hasSize(2);
        assertThat(observation.payload().get("asOf").asText()).isEqualTo("2024-01-01");

        TriggerPlugin.TriggerResult notFound = trigger.trigger(new TriggerPlugin.Request(ref, scenario("NONE"), MAPPING, ctx));
        Observation failed = capture.capture(new CapturePlugin.Request(ref, notFound, scenario("NONE"), MAPPING, ctx));
        assertThat(failed.outcome().kind()).isEqualTo(Outcome.Kind.BUSINESS_EXCEPTION);
        assertThat(failed.payload().isNull()).isTrue();

        TriggerPlugin.TriggerResult boom = trigger.trigger(new TriggerPlugin.Request(ref, scenario("BOOM"), MAPPING, ctx));
        assertThat(capture.capture(new CapturePlugin.Request(ref, boom, scenario("BOOM"), null, ctx)).outcome().kind())
                .isEqualTo(Outcome.Kind.TECHNICAL_FAILURE);
        assertThat(PluginRegistry.discover().trigger("TGT-CMP")).isInstanceOf(SpringTriggerPlugin.class);
        assertThat(PluginRegistry.discover().capture("TGT-SP")).isInstanceOf(SpringCapturePlugin.class);
        assertThat(trigger.id()).isEqualTo("spring-trigger");
        assertThat(capture.id()).isEqualTo("spring-capture");
    }

    @Test
    void availabilityExplainsWhatTheRealApplicationNeeds() {
        ExecutionContext nothing = ExecutionContext.builder().environment(Map.of()).build();
        assertThat(new SpringTriggerPlugin().availability(nothing).reason()).contains(SpringContexts.MAIN_CLASS);

        ExecutionContext noDatabase = ExecutionContext.builder().environment(Map.of())
                .property(SpringContexts.MAIN_CLASS, DemoApplication.class.getName()).build();
        assertThat(new SpringTriggerPlugin().availability(noDatabase).reason()).contains("E2E_DB_URL");

        ExecutionContext noDatabaseNeeded = ExecutionContext.builder().environment(Map.of())
                .property(SpringContexts.MAIN_CLASS, DemoApplication.class.getName())
                .property("e2e.target.db.required", "false").build();
        assertThat(new SpringTriggerPlugin().availability(noDatabaseNeeded).available()).isTrue();
        assertThatThrownBy(() -> SpringContexts.resolve(nothing)).hasMessageContaining("No application to boot");
    }

    @Test
    void theRealApplicationIsBootedOnceFromTheConfiguredClass() {
        ExecutionContext ctx = ExecutionContext.builder().environment(Map.of())
                .property(SpringContexts.MAIN_CLASS, DemoApplication.class.getName())
                .property(SpringContexts.PROFILES, "e2e, extra").build();

        org.springframework.context.ApplicationContext booted = SpringContexts.resolve(ctx);
        assertThat(booted.getBean(DemoApplication.DemoLookupService.class)).isNotNull();
        assertThat(booted.getEnvironment().getActiveProfiles()).containsExactly("e2e", "extra");
        assertThat(SpringContexts.resolve(ctx)).isSameAs(booted);
        ExecutionContext again = ExecutionContext.builder().environment(Map.of())
                .property(SpringContexts.MAIN_CLASS, DemoApplication.class.getName())
                .property(SpringContexts.PROFILES, "e2e, extra").build();
        assertThat(SpringContexts.resolve(again)).isSameAs(booted);

        ExecutionContext missing = ExecutionContext.builder().environment(Map.of())
                .property(SpringContexts.MAIN_CLASS, "org.example.NoSuchApplication").build();
        assertThatThrownBy(() -> SpringContexts.resolve(missing)).hasMessageContaining("not on the test classpath");
    }

    @Test
    void theBasementNamesTheApplicationClass(@TempDir Path dir) throws IOException {
        Files.createDirectories(dir.resolve("e2e"));
        Files.writeString(dir.resolve("e2e").resolve("basement.properties"), "app.main-class = " + DemoApplication.class.getName() + "\n");
        ClassLoader previous = Thread.currentThread().getContextClassLoader();
        try (URLClassLoader loader = new URLClassLoader(new URL[]{dir.toUri().toURL()}, previous)) {
            Thread.currentThread().setContextClassLoader(loader);
            assertThat(SpringContexts.mainClass(ExecutionContext.builder().environment(Map.of()).build()))
                    .isEqualTo(DemoApplication.class.getName());
            Files.writeString(dir.resolve("e2e").resolve("basement.properties"), "other=1\n");
            assertThat(SpringContexts.mainClass(ExecutionContext.builder().environment(Map.of()).build())).isNull();
        } finally {
            Thread.currentThread().setContextClassLoader(previous);
        }
    }

    static ViewMapping mapping(List<FieldMapping> inputs) {
        return new ViewMapping("1.0", "DEMO0001", null, inputs, List.of(), List.of(), List.of(), List.of(), null);
    }
}
