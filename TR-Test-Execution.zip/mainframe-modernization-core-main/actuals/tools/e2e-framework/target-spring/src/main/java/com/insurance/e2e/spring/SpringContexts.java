package com.insurance.e2e.spring;

import com.fasterxml.jackson.databind.JsonNode;
import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.json.JsonSupport;
import com.insurance.e2e.core.spi.ExecutionContext;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.ServiceLoader;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The application context the target bindings run in.
 *
 * <ol>
 *   <li>an {@link ApplicationContext} already in the execution context (a Spring test, or a caller that booted it) -
 *       for the bean bindings;</li>
 *   <li>otherwise the product's <strong>real</strong> application class, booted once per JVM and configuration with
 *       the validation profile: the class comes from {@code e2e.target.main-class} or from the test basement's
 *       {@value #BASEMENT_PROPERTIES} ({@code app.main-class}), the profiles from {@code e2e.target.profiles}
 *       (default {@code e2e}).</li>
 * </ol>
 * The bean bindings boot without a web server ({@code e2e.target.web=NONE}); the HTTP binding boots with
 * {@code SERVLET} on a random port.
 *
 * <p>Run-level overrides reach the application as command-line arguments - the property source that wins over the
 * product's own {@code application.yml}: {@value #PROPERTIES} is a JSON object of property names and values (e.g.
 * {@code {"app.security.enabled":"false"}}, environment {@code E2E_TARGET_PROPERTIES}). Every {@link java.time.Clock}
 * bean of the booted application is replaced by the {@link E2eClock} unless {@value #PIN_CLOCK} is {@code false}.
 *
 * <p>The application logs through the test basement's {@value #LOGGING_CONFIG} (Logback) when it is on the classpath
 * and the overrides name no {@code logging.config}: a product's own configuration may attach appenders only to its own
 * profiles, and the application under validation would then log nothing.
 */
public final class SpringContexts {

    public static final String MAIN_CLASS = "e2e.target.main-class";
    public static final String PROFILES = "e2e.target.profiles";
    public static final String WEB = "e2e.target.web";
    public static final String PROPERTIES = "e2e.target.properties";
    public static final String PIN_CLOCK = "e2e.target.pin-clock";
    public static final String BASEMENT_PROPERTIES = "e2e/basement.properties";
    public static final String LOGGING_CONFIG = "e2e/logback-e2e.xml";

    private static final String NONE = "NONE";
    private static final Map<String, ConfigurableApplicationContext> BOOTED = new ConcurrentHashMap<>();

    private SpringContexts() {
    }

    /** The context for the bean bindings: a supplied one, or the real application booted without a web server. */
    public static ApplicationContext resolve(ExecutionContext context) {
        String web = context.property(WEB, NONE);
        if (!NONE.equalsIgnoreCase(web)) {
            return resolve(context, web);
        }
        return context.attribute(ApplicationContext.class).orElseGet(() -> {
            ConfigurableApplicationContext booted = boot(context, NONE);
            context.putAttribute(ApplicationContext.class.getName(), booted);
            return booted;
        });
    }

    /** The real application booted with the given web application type ({@code NONE}, {@code SERVLET}, ...). */
    public static ConfigurableApplicationContext resolve(ExecutionContext context, String web) {
        return boot(context, web.trim().toUpperCase(Locale.ROOT));
    }

    /** The application class to boot, or {@code null} when none is configured. */
    public static String mainClass(ExecutionContext context) {
        String explicit = context.property(MAIN_CLASS);
        if (explicit != null) {
            return explicit;
        }
        ClassLoader loader = loader();
        try (InputStream in = loader.getResourceAsStream(BASEMENT_PROPERTIES)) {
            if (in == null) {
                return null;
            }
            Properties properties = new Properties();
            properties.load(in);
            String main = properties.getProperty("app.main-class");
            return main == null || main.isBlank() ? null : main.trim();
        } catch (IOException e) {
            throw new E2eException("Cannot read " + BASEMENT_PROPERTIES, e);
        }
    }

    /**
     * The command-line arguments a boot gets: the run-level overrides and, winning over them, every
     * {@link BootProperties} source's (each property once: a property given twice would reach the application as
     * both values joined), a random port for a web server, and the basement's logging configuration unless the
     * overrides name one.
     */
    public static List<String> arguments(ExecutionContext context, String web) {
        Map<String, String> overrides = new LinkedHashMap<>();
        String json = context.property(PROPERTIES);
        if (json != null) {
            JsonNode tree;
            try {
                tree = JsonSupport.mapper().readTree(json);
            } catch (IOException e) {
                throw new E2eException(PROPERTIES + " is not a JSON object of property names and values: " + json, e);
            }
            if (tree == null || !tree.isObject()) {
                throw new E2eException(PROPERTIES + " must be a JSON object, got: " + json);
            }
            for (Iterator<Map.Entry<String, JsonNode>> it = tree.fields(); it.hasNext(); ) {
                Map.Entry<String, JsonNode> entry = it.next();
                overrides.put(entry.getKey(), JsonSupport.scalarText(entry.getValue()));
            }
        }
        for (BootProperties source : ServiceLoader.load(BootProperties.class, loader())) {
            overrides.putAll(source.properties(context, web));
        }
        List<String> arguments = new ArrayList<>();
        overrides.forEach((key, value) -> arguments.add("--" + key + "=" + value));
        if (!NONE.equals(web) && !overrides.containsKey("server.port")) {
            arguments.add("--server.port=0");
        }
        if (!overrides.containsKey("logging.config") && basementLogging(loader())) {
            arguments.add("--logging.config=classpath:" + LOGGING_CONFIG);
        }
        return arguments;
    }

    /** The basement's Logback configuration applies only where Logback is the logging system (Spring Boot's default). */
    static boolean basementLogging(ClassLoader loader) {
        if (loader.getResource(LOGGING_CONFIG) == null) {
            return false;
        }
        try {
            Class.forName("ch.qos.logback.classic.LoggerContext", false, loader);
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    public static boolean pinClock(ExecutionContext context) {
        return !"false".equalsIgnoreCase(context.property(PIN_CLOCK, "true"));
    }

    /** {@value #CLOCK_MODE} = {@code frozen}: a pinned clock stands still at the scenario's instant (default: advancing). */
    public static final String CLOCK_MODE = "e2e.target.clock";

    public static boolean frozenClock(ExecutionContext context) {
        return "frozen".equalsIgnoreCase(context.property(CLOCK_MODE, "advancing"));
    }

    /** Closes every context booted here (end of a test run). */
    public static void closeAll() {
        BOOTED.values().forEach(ConfigurableApplicationContext::close);
        BOOTED.clear();
    }

    private static ConfigurableApplicationContext boot(ExecutionContext context, String web) {
        String main = mainClass(context);
        if (main == null) {
            throw new E2eException("No application to boot: set " + MAIN_CLASS + " or put the test basement ("
                    + BASEMENT_PROPERTIES + ") on the classpath");
        }
        String profiles = context.property(PROFILES, "e2e");
        List<String> arguments = arguments(context, web);
        boolean pin = pinClock(context);
        String key = main + "|" + profiles + "|" + web + "|" + arguments + "|" + pin;
        return BOOTED.computeIfAbsent(key, k -> start(main, profiles, web, arguments, pin));
    }

    private static ConfigurableApplicationContext start(String mainClass, String profiles, String web,
                                                        List<String> arguments, boolean pinClock) {
        Class<?> application;
        try {
            application = Class.forName(mainClass, true, loader());
        } catch (ClassNotFoundException e) {
            throw new E2eException("Application class " + mainClass + " is not on the test classpath (is the product's"
                    + " app module a dependency of the basement?)", e);
        }
        SpringApplicationBuilder builder = new SpringApplicationBuilder(application)
                .profiles(Arrays.stream(profiles.split(",")).map(String::trim).filter(p -> !p.isEmpty())
                        .toArray(String[]::new))
                .web(WebApplicationType.valueOf(web));
        if (pinClock) {
            builder.initializers(ctx -> ctx.getBeanFactory().addBeanPostProcessor(new ClockPinning()));
        }
        return builder.run(arguments.toArray(String[]::new));
    }

    private static ClassLoader loader() {
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        return loader == null ? SpringContexts.class.getClassLoader() : loader;
    }
}
