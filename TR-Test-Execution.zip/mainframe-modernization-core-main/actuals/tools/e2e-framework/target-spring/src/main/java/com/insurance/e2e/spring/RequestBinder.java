package com.insurance.e2e.spring;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.compare.FieldMapping;
import com.insurance.e2e.core.compare.FieldType;
import com.insurance.e2e.core.compare.ViewMapping;

import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Binds one scenario request (legacy field names) to a target method's arguments through the view mapping's
 * {@code inputs}: each input names a legacy field and a target path. {@code argN.path} addresses parameter N of a
 * multi-parameter method; for a single parameter the path is relative to it, and {@code $} is the parameter itself
 * (a scalar argument). A legacy field the request does not carry is left unset.
 */
public final class RequestBinder {

    private static final Pattern ARG = Pattern.compile("^arg(\\d+)(?:\\.(.+))?$");

    private RequestBinder() {
    }

    /** The number of parameters the inputs address (0 when there are no inputs). */
    public static int arity(ViewMapping mapping) {
        if (mapping == null || mapping.inputs().isEmpty()) {
            return 0;
        }
        int max = 0;
        for (FieldMapping input : mapping.inputs()) {
            Matcher m = ARG.matcher(input.target() == null ? "" : input.target());
            max = Math.max(max, m.matches() ? Integer.parseInt(m.group(1)) + 1 : 1);
        }
        return max;
    }

    public static Object[] bind(Method method, Map<String, String> request, ViewMapping mapping) {
        int count = method.getParameterCount();
        if (count == 0) {
            return new Object[0];
        }
        JsonNode[] trees = new JsonNode[count];
        List<FieldMapping> inputs = mapping == null ? List.of() : mapping.inputs();
        for (FieldMapping input : inputs) {
            if (!request.containsKey(input.legacy()) || input.target() == null) {
                continue;
            }
            int index = 0;
            String path = input.target();
            Matcher m = ARG.matcher(path);
            if (m.matches()) {
                index = Integer.parseInt(m.group(1));
                path = m.group(2) == null ? ViewMapping.ROOT : m.group(2);
            }
            if (index >= count) {
                throw new E2eException("Input " + input.legacy() + " addresses parameter " + index + " but "
                        + method.getName() + " has " + count);
            }
            JsonNode value = value(request.get(input.legacy()), input.type());
            trees[index] = put(trees[index], path, value);
        }
        Type[] types = method.getGenericParameterTypes();
        Object[] args = new Object[count];
        for (int i = 0; i < count; i++) {
            JavaType type = TargetJson.mapper().getTypeFactory().constructType(types[i]);
            JsonNode tree = trees[i];
            if (tree == null && inputs.isEmpty() && count == 1) {
                tree = TargetJson.mapper().valueToTree(request); // no inputs mapped: the request as it stands
            }
            try {
                args[i] = tree == null ? null : TargetJson.mapper().convertValue(tree, type);
            } catch (IllegalArgumentException e) {
                throw new E2eException("Cannot bind parameter " + i + " of " + method.getName() + " ("
                        + type.getTypeName() + ") from " + tree, e);
            }
        }
        return args;
    }

    static JsonNode value(String raw, FieldType type) {
        if (type == FieldType.NUMBER && raw != null && !raw.isBlank()) {
            try {
                return JsonNodeFactory.instance.numberNode(new BigDecimal(raw.strip()));
            } catch (NumberFormatException e) {
                throw new E2eException("Input value '" + raw + "' is not a number");
            }
        }
        return raw == null ? JsonNodeFactory.instance.nullNode() : JsonNodeFactory.instance.textNode(raw);
    }

    static JsonNode put(JsonNode root, String path, JsonNode value) {
        if (ViewMapping.ROOT.equals(path)) {
            return value;
        }
        ObjectNode object = root instanceof ObjectNode existing ? existing : JsonNodeFactory.instance.objectNode();
        List<String> parts = new ArrayList<>(Arrays.asList(path.split("\\.")));
        String last = parts.remove(parts.size() - 1);
        ObjectNode current = object;
        for (String part : parts) {
            JsonNode next = current.get(part);
            if (!(next instanceof ObjectNode)) {
                next = current.putObject(part);
            }
            current = (ObjectNode) next;
        }
        current.set(last, value);
        return object;
    }
}
