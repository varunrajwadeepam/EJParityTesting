package com.insurance.e2e.spring;

import org.springframework.beans.factory.config.BeanPostProcessor;

import java.time.Clock;

/**
 * Puts the {@link E2eClock} in place of every {@link Clock} bean of the booted application, so a scenario's recorded
 * clock can be pinned without changing the product. Registered by {@link SpringContexts} unless
 * {@code e2e.target.pin-clock=false}.
 */
public final class ClockPinning implements BeanPostProcessor {

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) {
        return bean instanceof Clock ? E2eClock.instance() : bean;
    }
}
