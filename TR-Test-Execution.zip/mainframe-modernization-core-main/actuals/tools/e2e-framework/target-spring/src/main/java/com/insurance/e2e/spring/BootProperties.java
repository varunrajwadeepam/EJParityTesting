package com.insurance.e2e.spring;

import com.insurance.e2e.core.spi.ExecutionContext;

import java.util.Map;

/**
 * A source of properties a boot of the application under validation needs besides the run's overrides
 * ({@value SpringContexts#PROPERTIES}) - e.g. the HTTP binding's test identity: the security settings that make the
 * application trust E2E's own test issuer, and its caller map. Found with {@link java.util.ServiceLoader}
 * ({@code META-INF/services/com.insurance.e2e.spring.BootProperties}); its properties win over the run's overrides,
 * and every property reaches the application once.
 */
public interface BootProperties {

    /**
     * The properties of a boot in this context, in order; empty when this source does not apply.
     *
     * @param web the web application type of the boot ({@code NONE} for the bean bindings, {@code SERVLET} for HTTP)
     */
    Map<String, String> properties(ExecutionContext context, String web);
}
