package com.insurance.e2e.spring;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.concurrent.atomic.AtomicReference;

/**
 * The clock of a validation run. It is the system clock until a scenario pins it; then it shows the scenario's
 * recorded local date-time (in the system time zone) and, by default, advances in real time from there, so the
 * product's "today" is the legacy's "today" while durations still pass normally.
 *
 * <p>Frozen ({@link #pin(String, boolean)} with {@code frozenAt}): it shows exactly the recorded instant until it is
 * pinned again or released - what a legacy run under a fixed clock saw, needed where the product derives a key from
 * the moment itself (a number built from the seconds and microseconds).
 *
 * <p>A legacy clock value is {@code yyyyMMddHHmmss} with up to nine fraction digits of the second
 * ({@code 20240816103000123456} is 10:30:00.123456).
 *
 * <p>{@link ClockPinning} puts this clock in place of every {@link Clock} bean of the booted application. Code that
 * reads the system clock directly ({@code LocalDate.now()}) is not affected - a recorded difference there is a
 * finding for triage, not something the harness hides.
 */
public final class E2eClock extends Clock {

    private static final DateTimeFormatter LEGACY_CLOCK = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
    private static final E2eClock INSTANCE = new E2eClock(ZoneId.systemDefault(), new AtomicReference<>(Duration.ZERO),
            new AtomicReference<>());

    private final ZoneId zone;
    private final AtomicReference<Duration> offset;
    private final AtomicReference<Instant> frozen;

    private E2eClock(ZoneId zone, AtomicReference<Duration> offset, AtomicReference<Instant> frozen) {
        this.zone = zone;
        this.offset = offset;
        this.frozen = frozen;
    }

    public static E2eClock instance() {
        return INSTANCE;
    }

    /** Shows {@code local} from now on, advancing in real time. */
    public void pin(LocalDateTime local) {
        pin(local, false);
    }

    /** Shows {@code local} from now on: advancing in real time, or frozen at exactly that instant. */
    public void pin(LocalDateTime local, boolean frozenAt) {
        Instant at = local.atZone(zone).toInstant();
        frozen.set(frozenAt ? at : null);
        offset.set(Duration.between(Instant.now(), at));
    }

    /** Pins a legacy clock value ({@code yyyyMMddHHmmss[fraction]}, e.g. {@code 20240816103000}), advancing. */
    public void pin(String legacyClock) {
        pin(legacyClock, false);
    }

    public void pin(String legacyClock, boolean frozenAt) {
        pin(parse(legacyClock), frozenAt);
    }

    /** {@code yyyyMMddHHmmss} and up to nine fraction digits of the second, left-aligned. */
    public static LocalDateTime parse(String legacyClock) {
        String digits = legacyClock.trim();
        if (digits.length() < 14 || digits.length() > 23 || !digits.chars().allMatch(Character::isDigit)) {
            throw new DateTimeParseException("not a legacy clock (yyyyMMddHHmmss[fraction]): " + legacyClock,
                    legacyClock, 0);
        }
        LocalDateTime seconds = LocalDateTime.parse(digits.substring(0, 14), LEGACY_CLOCK);
        String fraction = digits.substring(14);
        if (fraction.isEmpty()) {
            return seconds;
        }
        return seconds.withNano(Integer.parseInt((fraction + "000000000").substring(0, 9)));
    }

    /** Back to the system clock. */
    public void release() {
        frozen.set(null);
        offset.set(Duration.ZERO);
    }

    public boolean pinned() {
        return frozen.get() != null || !offset.get().isZero();
    }

    @Override
    public ZoneId getZone() {
        return zone;
    }

    @Override
    public Clock withZone(ZoneId other) {
        return other.equals(zone) ? this : new E2eClock(other, offset, frozen);
    }

    @Override
    public Instant instant() {
        Instant at = frozen.get();
        return at != null ? at : Instant.now().plus(offset.get());
    }
}
