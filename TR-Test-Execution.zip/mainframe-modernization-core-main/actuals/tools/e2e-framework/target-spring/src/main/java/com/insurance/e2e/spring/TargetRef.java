package com.insurance.e2e.spring;

import com.insurance.e2e.core.E2eException;

/**
 * The ref of a {@code TGT-SP} / {@code TGT-CMP} binding: {@code Type.method} (simple or fully qualified type name)
 * or {@code beanName#method}.
 */
public record TargetRef(String type, String beanName, String method) {

    public static TargetRef parse(String ref) {
        if (ref == null || ref.isBlank()) {
            throw new E2eException("Empty target reference");
        }
        int hash = ref.indexOf('#');
        if (hash > 0 && hash < ref.length() - 1) {
            return new TargetRef(null, ref.substring(0, hash), ref.substring(hash + 1));
        }
        int dot = ref.lastIndexOf('.');
        if (dot <= 0 || dot == ref.length() - 1) {
            throw new E2eException("Target reference '" + ref + "' must be Type.method or beanName#method");
        }
        return new TargetRef(ref.substring(0, dot), null, ref.substring(dot + 1));
    }

    public boolean byBeanName() {
        return beanName != null;
    }

    @Override
    public String toString() {
        return (byBeanName() ? beanName + "#" : type + ".") + method;
    }
}
