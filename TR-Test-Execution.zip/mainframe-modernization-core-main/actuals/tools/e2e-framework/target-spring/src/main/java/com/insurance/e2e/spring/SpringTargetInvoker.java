package com.insurance.e2e.spring;

import com.insurance.e2e.core.E2eException;
import com.insurance.e2e.core.compare.ViewMapping;
import org.springframework.context.ApplicationContext;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Calls a target method on its bean (through the bean, so proxies, transactions and advice apply as in production)
 * with the arguments bound from the scenario request. A business exception is a result, not an error.
 */
public final class SpringTargetInvoker {

    /** The method's return value, or the exception it raised (unwrapped). */
    public record Invocation(Object value, Throwable failure, String method) {
    }

    private SpringTargetInvoker() {
    }

    public static Invocation invoke(ApplicationContext context, TargetRef ref, Map<String, String> request,
                                    ViewMapping mapping) {
        Object bean = BeanLocator.locate(context, ref);
        Method method = method(bean, ref.method(), RequestBinder.arity(mapping));
        Object[] args = RequestBinder.bind(method, request, mapping);
        try {
            return new Invocation(method.invoke(bean, args), null, method.toGenericString());
        } catch (InvocationTargetException e) {
            return new Invocation(null, OutcomeCatalogue.unwrap(e), method.toGenericString());
        } catch (IllegalAccessException e) {
            throw new E2eException("Cannot call " + method.toGenericString(), e);
        }
    }

    /** The public method {@code name}; an overload is chosen by the arity the inputs address. */
    static Method method(Object bean, String name, int arity) {
        List<Method> candidates = Arrays.stream(bean.getClass().getMethods())
                .filter(m -> m.getName().equals(name) && !m.isBridge() && !m.isSynthetic()
                        && !Modifier.isStatic(m.getModifiers()))
                .toList();
        if (candidates.isEmpty()) {
            throw new E2eException("No public method '" + name + "' on " + bean.getClass().getName());
        }
        if (candidates.size() == 1) {
            return candidates.get(0);
        }
        List<Method> byArity = candidates.stream().filter(m -> m.getParameterCount() == Math.max(arity, 1)).toList();
        if (byArity.size() == 1) {
            return byArity.get(0);
        }
        throw new E2eException("Method '" + name + "' is overloaded on " + bean.getClass().getName()
                + " and the mapping's inputs do not single one out: " + candidates);
    }
}
