package com.insurance.e2e.spring;

import com.insurance.e2e.core.compare.OutcomeMapping;
import com.insurance.e2e.core.observation.Outcome;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Maps a target exception to an outcome through the unit's outcome catalogue (the view mapping's
 * {@code outcome.exceptions}): the first rule matching the exception or one of its causes - by class or superclass
 * name, and by message pattern when given - decides the kind and the legacy exit state it stands for. Anything else is
 * a technical failure.
 */
public final class OutcomeCatalogue {

    private OutcomeCatalogue() {
    }

    public static Outcome classify(Throwable failure, OutcomeMapping mapping) {
        Throwable root = unwrap(failure);
        List<OutcomeMapping.ExceptionRule> rules = mapping == null ? List.of() : mapping.exceptions();
        for (Throwable current = root; current != null; current = current.getCause() == current ? null : current.getCause()) {
            for (OutcomeMapping.ExceptionRule rule : rules) {
                if (matches(rule, current)) {
                    return new Outcome(kind(rule.kind()), rule.exitState(), current.getClass().getName(), current.getMessage());
                }
            }
        }
        return new Outcome(Outcome.Kind.TECHNICAL_FAILURE, null, root.getClass().getName(), root.getMessage());
    }

    static Throwable unwrap(Throwable failure) {
        Throwable current = failure;
        while ((current instanceof InvocationTargetException || current instanceof UndeclaredThrowableException)
                && current.getCause() != null) {
            current = current.getCause();
        }
        return current;
    }

    private static boolean matches(OutcomeMapping.ExceptionRule rule, Throwable failure) {
        boolean typeMatches = false;
        for (Class<?> type = failure.getClass(); type != null && !typeMatches; type = type.getSuperclass()) {
            typeMatches = type.getName().equals(rule.exception()) || type.getSimpleName().equals(rule.exception());
        }
        if (!typeMatches) {
            return false;
        }
        if (rule.messagePattern() == null || rule.messagePattern().isBlank()) {
            return true;
        }
        return failure.getMessage() != null && Pattern.compile(rule.messagePattern()).matcher(failure.getMessage()).find();
    }

    private static Outcome.Kind kind(String kind) {
        if (kind == null || kind.isBlank()) {
            return Outcome.Kind.BUSINESS_EXCEPTION;
        }
        return Outcome.Kind.valueOf(kind.trim().toUpperCase(Locale.ROOT));
    }
}
