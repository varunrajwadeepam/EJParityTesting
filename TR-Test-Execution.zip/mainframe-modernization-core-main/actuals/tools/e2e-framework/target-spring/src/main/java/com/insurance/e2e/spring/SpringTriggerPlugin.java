package com.insurance.e2e.spring;

import com.insurance.e2e.core.spi.Availability;
import com.insurance.e2e.core.spi.BlockedCall;
import com.insurance.e2e.core.spi.ExecutionContext;
import com.insurance.e2e.core.spi.TriggerPlugin;
import org.springframework.context.ApplicationContext;

import java.util.Map;
import java.util.Set;

/**
 * Target trigger: invokes a component ({@code TGT-CMP}) or the service point ({@code TGT-SP}) inside the
 * application context. Unavailable - so the level is skipped, never failed - while there is no application to boot
 * or the validation database is not configured ({@code E2E_DB_URL}); set {@code e2e.target.db.required=false} for
 * units that need no database.
 */
public final class SpringTriggerPlugin implements TriggerPlugin {

    @Override
    public String id() {
        return "spring-trigger";
    }

    @Override
    public Set<String> kinds() {
        return Set.of("TGT-SP", "TGT-CMP");
    }

    @Override
    public Availability availability(ExecutionContext context) {
        if (context.attribute(ApplicationContext.class).isPresent()) {
            return Availability.up();
        }
        if (SpringContexts.mainClass(context) == null) {
            return Availability.down("no application to boot: set " + SpringContexts.MAIN_CLASS
                    + " or add the test basement (" + SpringContexts.BASEMENT_PROPERTIES + ") to the classpath");
        }
        boolean databaseRequired = !"false".equalsIgnoreCase(context.property("e2e.target.db.required", "true"));
        if (databaseRequired && context.property("e2e.db.url") == null) {
            return Availability.down("E2E_DB_URL is not set: the real application needs the validation database "
                    + "(E2E_DB_URL, E2E_DB_USER, E2E_DB_PASSWORD, E2E_DB_SCHEMA)");
        }
        return Availability.up();
    }

    @Override
    public TriggerResult trigger(Request request) {
        if (request.scenario().http() != null && request.scenario().http().principal() != null) {
            throw new BlockedCall("needs the caller identity: the call is made as the user '"
                    + request.scenario().http().principal() + "' and the bean lens calls a service with no caller",
                    "/e2e.constitution (target.mode http)");
        }
        ApplicationContext application = SpringContexts.resolve(request.context());
        SpringTargetInvoker.Invocation invocation = SpringTargetInvoker.invoke(application,
                TargetRef.parse(request.binding().ref()), request.scenario().request(), request.mapping());
        return new TriggerResult(request.binding(), invocation.value(), invocation.failure(),
                Map.of("target", invocation.method()));
    }
}
