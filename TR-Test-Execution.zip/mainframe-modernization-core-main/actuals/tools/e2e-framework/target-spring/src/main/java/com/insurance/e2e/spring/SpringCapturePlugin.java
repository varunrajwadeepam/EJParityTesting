package com.insurance.e2e.spring;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.NullNode;
import com.insurance.e2e.core.observation.Observation;
import com.insurance.e2e.core.observation.Outcome;
import com.insurance.e2e.core.spi.CapturePlugin;

import java.util.Set;

/**
 * Target capture: the returned object as a JSON tree (exact decimals, ISO dates) plus the outcome - a raised
 * exception is classified through the unit's outcome catalogue. The comparator projects the tree through the view
 * mapping.
 */
public final class SpringCapturePlugin implements CapturePlugin {

    @Override
    public String id() {
        return "spring-capture";
    }

    @Override
    public Set<String> kinds() {
        return Set.of("TGT-SP", "TGT-CMP");
    }

    @Override
    public Observation capture(Request request) {
        Object value = request.result().payload();
        JsonNode payload = value == null ? NullNode.getInstance() : TargetJson.mapper().valueToTree(value);
        Throwable failure = request.result().failure();
        Outcome outcome = failure == null ? Outcome.ok()
                : OutcomeCatalogue.classify(failure, request.mapping() == null ? null : request.mapping().outcome());
        return Observation.targetPayload(payload, outcome);
    }
}
