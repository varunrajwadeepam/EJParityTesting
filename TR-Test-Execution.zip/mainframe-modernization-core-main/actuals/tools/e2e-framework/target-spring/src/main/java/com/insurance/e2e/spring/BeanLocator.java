package com.insurance.e2e.spring;

import com.insurance.e2e.core.E2eException;
import org.springframework.context.ApplicationContext;
import org.springframework.util.ClassUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Finds the bean a target reference names: by bean name, or by its (user) class - simple or fully qualified name,
 * looking through CGLIB proxies and at the interfaces of JDK proxies. Exactly one bean must match.
 */
public final class BeanLocator {

    private BeanLocator() {
    }

    public static Object locate(ApplicationContext context, TargetRef ref) {
        if (ref.byBeanName()) {
            if (!context.containsBean(ref.beanName())) {
                throw new E2eException("No bean named '" + ref.beanName() + "' in the application context");
            }
            return context.getBean(ref.beanName());
        }
        List<String> matches = new ArrayList<>();
        for (String name : context.getBeanDefinitionNames()) {
            Class<?> type = context.getType(name);
            if (type != null && matches(ClassUtils.getUserClass(type), ref.type())) {
                matches.add(name);
            }
        }
        if (matches.isEmpty()) {
            throw new E2eException("No bean of type '" + ref.type() + "' in the application context - is the MU's"
                    + " module on the test classpath and inside the application's component scan?");
        }
        if (matches.size() > 1) {
            throw new E2eException("Several beans of type '" + ref.type() + "': " + matches
                    + " - use beanName#method in the binding");
        }
        return context.getBean(matches.get(0));
    }

    static boolean matches(Class<?> type, String wanted) {
        if (type.getName().equals(wanted) || type.getSimpleName().equals(wanted)) {
            return true;
        }
        for (Class<?> implemented : type.getInterfaces()) {
            if (implemented.getName().equals(wanted) || implemented.getSimpleName().equals(wanted)) {
                return true;
            }
        }
        return false;
    }
}
