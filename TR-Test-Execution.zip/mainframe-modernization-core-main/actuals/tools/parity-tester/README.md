# Parity Tester

Run real CA Gen COBOL against a real Db2, record what it did, and keep those
recordings as tests.

This is the characterization-test workbench for the COBOL → Java/.NET migration.
It is not a unit-test framework for the legacy code: it builds a program tree as
delivered, calls the entry program with inputs you choose, and prints every field
of its export view exactly as the program left it. What you do with that output is
the point — you save it as a case, and from then on the case tells you whether the
program still behaves the way it behaved when you recorded it. The same recorded
inputs and outputs are what a rewritten Java/.NET service has to reproduce.

There is no pass/fail opinion anywhere in the build and run path. A case passes
only when the fields *you* chose to assert come back with the values *you*
recorded from an actual run.

## What it consists of

| Piece | What it is | Where it runs |
| --- | --- | --- |
| `workspace/` | The catalog: one directory per unit — sources, driver, cases, fixture SQL, coverage | on disk |
| `server/` | The API over the catalog: runs a case's fixture SQL, builds bundles, compares results, writes files | host, `:8090` |
| `ui/` | React front end — Programs, Tests, DB Viewer | host, `:5310` |
| `cobol-runner` | GnuCOBOL 3.2 + GixSQL + Db2 CLI driver. Takes a zip, answers with the driver's raw output | container, `:8080` |
| `db2` | Db2 Community Edition, database `TESTDB` — its own image creates the tables (`config/db2/schema.sql`), no rows | container, `:50000` |

A run is: server runs the case's `db.before` SQL → zips up the unit's sources, the
driver and a generated `spec.yaml` → POSTs it to the cobol-runner → the runner
compiles and executes it → server runs `db.after` → server compares the report
against the case.

The `spec.yaml` carries the Db2 connection, from the server's `DB2_*` settings. The
runner has no database of its own and no default for one, so every run says what it
connected to.

The CA Gen **shim** — the `TIR*` stand-ins the generated code CALLs — lives in the
runner (`config/cobol-runner/shims/<name>/`), not in the bundle. A case names what
it wants (`shims: [cagen]`) and the runner resolves it, compiling each tree once per
container instead of once per run. `GET /api/shims` lists what may be named.

A bundle's `spec.yaml` may carry a `tests:` list instead of a single `inputs:`
block. The runner then builds once and runs the driver once per test, answering
with `tests: [...]` — each test's own report and coverage, plus the union in
`coverage`. No SQL runs between them, so the tests of one bundle see the database
in the order they are listed; see `config/cobol-runner/lib/spec.js`.

## Requirements

- Docker with enough memory for Db2 (2 GB shared memory is requested in
  `docker-compose.yml`). Both images are **linux/amd64**; on Apple Silicon they
  run under emulation, and the first Db2 boot takes several minutes to well over
  ten.
- Node.js 18+ on the host, for the server and the UI.

## Start it

The scripts do steps 1 and 2 with the Java App (`server_j/`, Java 21; Maven on the
first run): they start the containers, wait for Db2's schema, detect `DB2_HOSTNAME`,
and start the App. On Windows `start.bat` / `stop.bat`; on macOS `./start.sh` /
`./stop.sh`, which run the App in the background with its output in
`server_j/parity-server.log`. `DB2_HOSTNAME` and `WORKSPACE_DIR` set beforehand are
used as given. `stop` keeps the containers and their data (`docker compose stop`).

By hand:

```bash
cd parity-tester

# 1. the containers (first build is long: GnuCOBOL and GixSQL are built from source)
docker compose up -d
docker compose logs -f db2          # wait for "Setup has completed."
                                    # then "init-schema: 591 tables in TESTDB"

# 2. the API. DB2_HOSTNAME has to name Db2 from BOTH here and the runner container
#    (see Configuration), so it is this machine's own address, not localhost:
cd server && npm install
DB2_HOSTNAME=192.168.1.149 npm start         # http://localhost:8090

# 3. the UI
cd ../ui && npm install && npm run dev       # http://localhost:5310
```

Open http://localhost:5310. The header shows two health indicators: whether the
API answers, and whether the cobol-runner does. Both must be green before a run
can succeed — the runner comes up well after `docker compose up` returns, and Db2
later still.

`TESTDB` comes up **with its tables and no rows, and has no volume**. The db2 image
loads `config/db2/schema.sql` when it creates the database, so the DDL is the
container's business and never the server's. The ROWS are a case's: each names its
unit's own fixture script (`db.before: seed.sql`). A `docker compose down` throws
everything away and the next `up` builds the schema again.

Nothing here has authentication — it executes COBOL from a request body and runs
free-text `WHERE` clauses against Db2. Keep the published ports on localhost.

## The three tabs

### Programs

One unit at a time. A unit is `workspace/<ENTRY>/`, named after its entry
program (e.g. `P7549508`), and it has six sub-tabs:

- **Run** — the form for the program's inputs, built from `schema.yaml`. Fill it
  in, run, read the export view the driver reported. No verdict: there is nothing
  to compare against. This is where you work out what a case should assert.
  Under the inputs is **Environment**, with the defaults every recorded case uses
  (`CAGENSHIM_CLOCK=20240816103000` — the clock the CA Gen shim hands out, so a
  case does not go stale; `GIXSQL_AUTOCOMMIT=off`). **Create Test** writes the
  run you are looking at into a case file.
- **Sources** — the COBOL as delivered, member by member.
- **Schema** — `schema.yaml`, the input and output field lists. You can edit the
  `label` and the `hidden` flag; everything else is a reading of the COBOL the
  generator owns. **Generate** recomputes the file, keeping labels but resetting
  every `hidden` to the generator's verdict.
- **Driver** — the generated `driver.cbl`: the COBOL host that MOVEs your inputs
  into `GLOBDATA` and the import view, CALLs the entry program, and DISPLAYs every
  output field. **Generate** overwrites it, so hand-written commentary in it is
  lost.
- **Tests** — the unit's case files as forms: change a value, add or remove a
  field. Creating and deleting cases is deliberately not here (see below).
- **Coverage** — pick saved runs, merge them, and read the sources with the lines
  those runs executed highlighted. The percentage counts every non-blank,
  non-comment line in the denominator, including declarations the compiler emits
  no code for, so 100% is unreachable — read it as a floor. The grey stretches —
  the declarations, counted in neither half — are **folded shut**; each bar says
  which lines it holds and what they start with, and opens on a click.

Trailing blanks matter in a `PIC X` field, so every input and reported value is
shown in a box that draws each space as a dot.

**Upload** brings in a new unit: a zip of `.CBL` / `.CPY` members plus the name of
the entry program, typed (it cannot be guessed out of forty-eight members). The
zip is flattened to base names and upper-cased, so it can be nested however your
export tool nested it. The server generates `driver.cbl` and `schema.yaml` from
the entry program's own `W-IA` / `W-OA` declarations; if it cannot, the sources are
still committed and you get a warning — regenerate from the Driver and Schema tabs.

Neither the tables nor the shims are part of an upload: the tables come from the db2
image (`config/db2/schema.sql`) and the shim trees live in the runner
(`config/cobol-runner/shims/`). A new unit will list and browse immediately; whether
it *runs* depends on the database already having its tables, and whether its cases
are repeatable depends on you writing the `*.sql` fixture script they name.

### Tests

Every recorded case in the catalog, grouped by program. Pick one, run it, read the
comparison: which asserted fields matched, which differ, which were never
reported, plus the full step log (db.before → bundle → build → execute) and every
field the driver reported but the case does not assert. A case whose YAML the
server refused is shown struck through and cannot be run.

A case passes only if the build and run were clean, the driver reported no errors,
at least one assertion matched, and nothing differed or went missing. A case with
no assertions does not pass — it ran, which is not the same as having been checked.

### DB Viewer

The fixture database as it is right now: pick a table, narrow it with a `WHERE`
clause, look at the rows. Read-only. Useful before recording a case (what is
actually in there?) and after one — a case's fixture script runs *before* its run, so
a database a run dirtied survives to be inspected.

## The catalog on disk

```
workspace/
  <ENTRY>/
    sources/         the COBOL under test, as delivered
    driver.cbl       generated host: applies inputs, CALLs the program, reports the views
    schema.yaml      generated input/output field lists (feeds the Run form)
    seed.sql         fixture rows, named by a case's db.before — deletes, then inserts
    tests/*.yaml     one case per file
    coverage/        0001-<case-name>.json, one file per run, never overwritten
```

A unit's `*.sql` is the unit's own: the same file is not shared between units, and a
case may name one of them on each side. The TABLES are not in here at all —
`config/db2/schema.sql`, loaded by the db2 image. Editing it needs
`docker compose build db2 && docker compose up -d db2` (and a `down` first, since a
database that already has tables is left alone).

## A case file

```yaml
name: P7549508-list-kind-all       # what to call it; defaults to the file name
shims: [cagen]                     # which of the runner's shim trees to use — required
db:
  before: seed.sql                 # one of the unit's own *.sql, run before the run
  after:                           # ... and one after it (both default to none)
inputs:
  PSMGR-IEF-COMMAND: "RTNSLIST"    # GLOBDATA / import-view fields, applied in this order
  RV-LOOKUP-SEARCH-VALUE-0149: "001"
env:
  CAGENSHIM_CLOCK: "20240816103000"
  GIXSQL_AUTOCOMMIT: "off"
expected:
  RESPONSE-CODE-S-0154: "1"        # recorded export-view values to assert
```

Conventions that matter:

- **Quote every value.** Trailing blanks are significant and `"0149"` is not
  `149`.
- **Keys are the real COBOL field names**, as the driver printed them —
  `FIELD(001)` for an occurrence.
- **Assert the fields that carry the outcome**, not everything the driver
  reported. Unasserted fields still show in the UI; reported is not verified.
- **Unlisted inputs are not "don't care"** — everything not listed is reset
  before the call, so it is spaces, or zero if numeric.
- **`db.before` is about the rows.** It names ONE file in the unit's directory,
  run before the bundle is built; `db.after` is the same afterwards. A fixture
  that needs several steps says so inside the SQL, where a reader looking at the
  rows will be anyway. Naming nothing means "run against whatever the last run
  left", which is a legitimate thing for a case to say. The TABLES are never a
  case's business — the db2 image creates them.
- **Write down why.** Most of a good case file is comments: where the expected
  block was recorded (date, versions, seed), what each value selects, and what is
  still not understood. The Create Test button can write the values; only you can
  write that.

Cases are created from the Run tab (or by hand) and are never overwritten or
deleted by the tool — a case is evidence, and the commentary is what makes it
evidence.

## Configuration

Defaults are the local compose stack; a bare `npm start` needs no environment.

| Variable | Default | What it is |
| --- | --- | --- |
| `PORT` | `8090` | the API's port |
| `WORKSPACE_DIR` | `../workspace` | which catalog to serve |
| `RUN_TIMEOUT` | `600000` | ms for one bundle; a cold CA Gen build is the slow part |
| `COBOL_RUNNER_URL` | `http://localhost:8080` | the cobol-runner |
| `DB2_DSN` | `TESTDB` | the ODBC data source name written for the driver |
| `DB2_DATABASE`, `DB2_HOSTNAME`, `DB2_PORT` | `TESTDB`, `localhost`, `50000` | the database |
| `DB2_USER`, `DB2_PASSWORD` | `db2inst1`, `testenv` | credentials |
| `DB2_ALLOW_SEED` | `true` | `false` and no `db.before` / `db.after` script ever runs |

One set of variables, one instance: the server connects with them and every bundle
carries them to the runner, which has none of its own and no defaults for one. So the
address has to mean the same database from BOTH vantage points, and that is why the
default is not usable as it stands — `localhost` names it only for the server, `db2`
only for the runner. What works is the host's own address: on this setup
`DB2_HOSTNAME=192.168.1.149`, which the server reaches as the published port and the
runner reaches out through the container network. Point these at anything that speaks
DRDA — another LUW server, or Db2 for z/OS — and the `db2` container is not needed at
all.

`DB2_ALLOW_SEED=false` is the switch for that case: the fixture scripts are arbitrary
`DELETE`/`INSERT` written for a throwaway database, so aimed at one that matters they
are not a fixture load. With it off every run still builds, executes and compares; no
script runs, from any case.

## Troubleshooting

- **Runner health is red.** The container is still building or starting:
  `docker compose logs -f cobol-runner`.
- **A run fails with `SQL30081N` / `cannot connect to Db2`.** Db2 is not up yet
  (`docker compose logs -f db2`, wait for `Setup has completed.`) — or `DB2_HOSTNAME`
  is a name the runner's container cannot resolve. See Configuration.
- **A run fails with `SQL0204N` on a fixture script.** The database has no tables:
  the db2 image did not load its schema. `docker compose logs db2 | grep -i schema`,
  and `docker compose exec db2 cat /var/db2-init/schema.log`.
- **First run is very slow.** Nothing is cached on either side, on purpose: a
  cache keyed on less than the bundle's full content would eventually run a build
  that does not match the sources you are looking at. Cold CA Gen builds take
  minutes under emulation.
- **The Run tab says there is no form.** The unit has no `schema.yaml` —
  generate one from the Schema tab (which needs a `driver.cbl` first).
- **A case that passed once now fails everywhere after it.** Something leaked a
  commit. A case's `db.before` script is there to catch exactly this — it deletes
  before it inserts; the DB Viewer shows what was left behind.
- **`cobc` rejects a `CALL` with too many arguments.** The container raises the
  limit to 252, the compiler's ceiling. The CA Gen dialog managers (`M*`) exceed
  it and are deliberately not compiled — the driver calls the business program
  (`P*`) directly.
