// Build the named shims into loadable modules -- once each, then never again.
//
// Each <shim>/*.cbl becomes one .so in that shim's own output directory, resolved by
// name at CALL time via COB_LIBRARY_PATH (see run-driver.js). GLOBDATA.cpy is a
// copybook, not a program, so it is picked up through -I rather than compiled.
//
// The shims are compiled with the same dialect flags as the legacy tree on purpose:
// they declare GLOBDATA from the same copybook the generated programs use, so a
// dialect difference would show up as a silent layout mismatch across a CALL rather
// than as an error.
//
// COMPILED ONCE, AND WHY THAT IS SAFE HERE
// The rest of this service refuses to cache a build, because the sources arrive in
// the request body and a cache keyed on anything less than their full content would
// eventually run a build that does not match the bundle it was handed. Shim sources
// are not in the request body: they are the image's, the same for every caller, and
// nothing a request says can change them. So the objection does not apply, and the
// forty-odd cobc invocations they cost stop being paid per run -- which for a
// multi-test bundle was most of its build time.
//
// The cache is still keyed on the CONTENT, not on the name: SHIMS_DIR can be a
// development mount, and a shim edited between two requests must come out rebuilt.
// The flags are in the key for the same reason -- EXTRA_COBFLAGS=-ftraceall is a
// different build of the same source, and reusing the quiet one would silently
// ignore the thing that was being asked for.
//
// IN THE WORK ROOT, NOT NEXT TO THE SOURCE
// The output goes under <WORK_ROOT>/shims/<name>-<digest>, which is writable,
// disposable and shared by every run in the container's lifetime. Each build lands in
// a temporary directory and is renamed into place, so a reader (or a concurrent
// build) never sees a half-compiled shim: rename is atomic, and a directory that is
// there is a directory that finished.

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { run } from './lib/exec.js';
import { dialectFlags } from './lib/cobflags.js';
import { resolveShims, shimDigest } from './lib/shim-library.js';

// What this process has already built, so a second request does not even stat the
// sources again. Keyed by name+digest+flags, like the directory it points at.
//
// An in-process Map is enough to serialize the work as well: the compiles below are
// spawnSync, which blocks this thread, so two requests cannot be inside the same
// build at once no matter how they interleave elsewhere.
const built = new Map();

function cacheKey(shim, digest, extraFlags) {
  const flags = crypto.createHash('sha256').update(extraFlags.join(' ')).digest('hex').slice(0, 8);
  return `${shim.name}-${digest}-${flags}`;
}

// One shim -> one directory of .so files. `cached` says whether anything was
// compiled, which is the number worth seeing in a build log: a cold container pays
// for this once and every run after it does not.
function compileShim({ shim, outDir, extraFlags }) {
  const steps = [];
  const modules = [];
  let ok = true;

  // Built beside the target and renamed on top of it, so an interrupted build leaves
  // no directory rather than an incomplete one the next request would trust.
  const staging = `${outDir}.tmp-${process.pid}-${Date.now().toString(36)}`;
  fs.rmSync(staging, { recursive: true, force: true });
  fs.mkdirSync(staging, { recursive: true });

  for (const file of shim.modules) {
    const name = path.basename(file, path.extname(file));
    const so = path.join(staging, `${name}.so`);
    const r = run('cobc', [
      '-m', ...dialectFlags(shim.dir), ...extraFlags,
      '-o', so, path.join(shim.dir, file),
    ]);
    fs.writeFileSync(path.join(staging, `${name}.cobc.log`), r.stdout + r.stderr);
    steps.push({
      name: `${shim.name}/${name}`, ok: r.ok,
      output: (r.stdout + r.stderr).trim(), command: r.cmd,
    });
    if (r.ok) modules.push(`${name}.so`); else ok = false;
  }

  if (!ok) {
    // Left in place under its staging name: a failed shim build is something to go
    // and read the cobc log for, and it must not be renamed into the cache where the
    // next request would find a directory missing half its modules.
    return { ok, steps, modules, dir: staging };
  }
  fs.rmSync(outDir, { recursive: true, force: true });
  fs.renameSync(staging, outDir);
  return { ok, steps, modules, dir: outDir };
}

// The shims a bundle named, resolved and built.
//
//   names     every shim named anywhere in the spec, in order
//   perTest   the sets that will share one COB_LIBRARY_PATH, for the collision rules
//
// Returns { ok, steps, dirs, srcDirs, shims } where `dirs` maps a shim name to the
// directory its modules are in -- which is what a test's COB_LIBRARY_PATH is built
// from -- and `srcDirs` is the copy path the unit and the driver compile against.
function buildShims({ names, perTest, cacheRoot, extraFlags = [] }) {
  const { shims, errors } = resolveShims(names, perTest);
  if (errors.length) {
    return {
      ok: false,
      steps: errors.map((e) => ({ name: 'shims', ok: false, output: e })),
      dirs: {}, srcDirs: [], shims: [],
    };
  }

  fs.mkdirSync(cacheRoot, { recursive: true });

  const steps = [];
  const dirs = {};
  let ok = true;

  for (const shim of shims) {
    const key = cacheKey(shim, shimDigest(shim), extraFlags);
    const outDir = path.join(cacheRoot, key);

    // Built by an earlier request in this process, or by an earlier container that
    // shared the work root. The directory being there is the whole check: it is only
    // ever renamed into place complete.
    const done = built.get(key);
    if (done || fs.existsSync(outDir)) {
      built.set(key, outDir);
      dirs[shim.name] = outDir;
      steps.push({
        name: shim.name, ok: true, cached: true,
        output: `${shim.modules.length} modules, already built (${key})`,
      });
      continue;
    }

    const r = compileShim({ shim, outDir, extraFlags });
    steps.push(...r.steps);
    steps.push({
      name: shim.name, ok: r.ok, cached: false,
      output: `${r.modules.length}/${shim.modules.length} modules compiled into ${r.dir}`,
    });
    if (!r.ok) { ok = false; continue; }
    built.set(key, outDir);
    dirs[shim.name] = outDir;
  }

  return {
    ok,
    steps,
    dirs,
    // In the order named, because it is a search path: the first -I holding a
    // copybook wins, and resolveShims has already refused the case where that choice
    // would change anything.
    srcDirs: shims.map((s) => s.dir),
    shims: shims.map((s) => ({
      name: s.name, dir: s.dir, modules: s.modules, copybooks: s.copybooks,
    })),
  };
}

export { buildShims };
