// Build a bundle's COBOL sources into callable GnuCOBOL modules.
//
// Pipeline per program:
//
//   sources/X.CBL  --gixpp-->  X.cbl  --cobc-->  X.so
//
// The sources are fed to gixpp verbatim: there is no source pre-pass. There used
// to be one (pre-gixpp.awk), but every workaround in it has been migrated into the
// vendored GixSQL under gixsql/ -- see README section 4b. Everything is written to
// the out directory, so the unpacked bundle stays as delivered.
//
// Programs with no EXEC SQL skip gixpp and are compiled directly.
//
// CACHED, PER PROGRAM, ON CONTENT
// Both stages land in the object cache (lib/build-cache.js) and the run's module
// directory gets hard links to what came out. cobc is ~90% of a request's build time
// -- 27 of 31 seconds for a sixty-member tree -- and a bundle re-posted for the next
// test case is byte-identical to the last one, so this is the difference between
// paying that per case and paying it once per source change. The cache key is the
// source bytes plus everything else the compile reads; see build-cache.js for why
// that is the only key that can be trusted here.
//
// COVERAGE
// Both stages emit the extra artifacts that make line coverage possible, and both
// are needed because neither alone says anything about the delivered source:
//
//   gixpp -m      X.cbsql.map   preprocessed line -> delivered source line
//   cobc --coverage  X.so-X.gcno   the arcs, counted into X.so-X.gcda at run time
//
// gcov reports against X.cbl, the *preprocessed* file, so the map is what turns
// its line numbers back into the .CBL a reader can open. A program with no EXEC
// SQL has no map because X.cbl is a byte copy of the source -- the mapping there
// is the identity, which lib/coverage.js relies on.
//
// With the cache in play the two halves of that live in different places, and which
// is which matters:
//
//   preprocessed, mapFile   stay in the CACHE. gcov names the source by the path
//                           recorded in the notes file at compile time, and
//                           coverage.js matches on it.
//   gcno                    linked into the RUN's module directory, because the
//                           .gcda has to appear next to it and the .gcda is this
//                           run's -- see run-driver.js and GCOV_PREFIX.

import fs from 'node:fs';
import path from 'node:path';
import { run } from './lib/exec.js';
import { GIX_COPY, dialectFlags, coverageEnabled } from './lib/cobflags.js';
import {
  ensureCacheRoot, buildKey, copyPathDigest, withEntry, materialize,
} from './lib/build-cache.js';

// shimDirs is the copy path: every shim named anywhere in the bundle, in the order
// named. Only the copybooks matter here -- GLOBDATA is declared from the same file
// the shims declare it from, which is the point -- and the shim library has already
// refused a set where two of them would answer that -I differently.
function buildUnit({ srcDir, shimDirs = [], outDir, extraFlags = [] }) {
  const steps = [];
  const modules = [];
  const coverage = coverageEnabled();
  // Keyed by program, so lib/coverage.js does not have to re-derive which of the
  // two source shapes a program took or guess at gcc's artifact naming.
  const covSources = [];

  if (!fs.existsSync(srcDir)) {
    return {
      ok: false,
      steps: [{ name: 'sources', ok: false, output: `no sources directory: ${srcDir}` }],
      modules,
    };
  }
  fs.mkdirSync(outDir, { recursive: true });
  ensureCacheRoot();

  const sources = fs.readdirSync(srcDir)
    .filter((f) => /\.cbl$/i.test(f))
    .sort();
  if (sources.length === 0) {
    return {
      ok: false,
      steps: [{ name: 'sources', ok: false, output: `no *.CBL in ${srcDir}` }],
      modules,
    };
  }

  // The flags, as the cache sees them. Built once because they are the same for every
  // program in the bundle, and recorded in full rather than summarized: EXTRA_COBFLAGS
  // and --coverage both change the object, and a key that elided them would serve a
  // quiet build to a request that asked for a loud one.
  const dialect = dialectFlags(...shimDirs);
  const gixppOpts = ['-e', '-z', 'a', ...(coverage ? ['-m'] : [])];
  const flagSig = [
    'cobc', ...dialect, ...(coverage ? ['--coverage'] : []), ...extraFlags,
    'gixpp', ...gixppOpts, '-I', [...shimDirs, GIX_COPY].join(':'),
  ].join(' ');
  // The copybooks reachable through -I. A bundle's own sources/*.cpy are not on that
  // path today (srcDir is not an -I), so they are deliberately not in the key: what
  // the compile cannot read cannot change its output.
  const copyDigest = copyPathDigest([...shimDirs, GIX_COPY]);

  let ok = true;
  for (const file of sources) {
    const name = path.basename(file, path.extname(file));
    const src = path.join(srcDir, file);
    const srcBytes = fs.readFileSync(src);
    const hasSql = srcBytes.toString('latin1').includes('EXEC SQL');

    const key = buildKey(['unit', flagSig, copyDigest, srcBytes]);

    // One program: gixpp if it has EXEC SQL, then cobc, both into `dir`. Everything
    // below writes only there, so a cache entry is self-contained and the caller's
    // out directory holds nothing but links.
    const entry = withEntry({
      name,
      key,
      build: (dir) => {
        const pp = path.join(dir, `${name}.cbl`);

        if (hasSql) {
          // -z a  anonymous '?' parameter markers. gixpp defaults to -z d, which
          //       emits Postgres-style $1 -- Db2 reads that as a column name and
          //       every host-variable predicate fails with SQLCODE -206 at run
          //       time, not at build time.
          // -I    gixpp's own copy path. It must include the GixSQL copybooks, not
          //       just the shim: sources that still carry an unexpanded
          //       `EXEC SQL INCLUDE SQLCA END-EXEC` fail with "Cannot resolve copy
          //       file SQLCA" otherwise.
          // -m    emit the map file next to -o, as <basename>.cbsql.map.
          const g = run('gixpp', [
            ...gixppOpts,
            '-I', [...shimDirs, GIX_COPY].join(':'), '-i', src, '-o', pp,
          ]);
          fs.writeFileSync(path.join(dir, `${name}.gixpp.log`), g.stdout + g.stderr);
          if (!g.ok) {
            return {
              ok: false,
              steps: [{
                name, stage: 'gixpp', ok: false,
                output: (g.stdout + g.stderr).trim(), command: g.cmd,
              }],
            };
          }
          // gixpp exits 0 while leaving statements unrewritten, so check the output
          // rather than the status. Its own generated lines start with GIXSQL in the
          // sequence area and legitimately mention EXEC SQL.
          const left = fs.readFileSync(pp, 'latin1')
            .split('\n')
            .filter((l) => !l.startsWith('GIXSQL'))
            .some((l) => l.includes('EXEC SQL'));
          if (left) {
            return {
              ok: false,
              steps: [{
                name, stage: 'gixpp', ok: false,
                output: 'gixpp left EXEC SQL unrewritten', command: g.cmd,
              }],
            };
          }
        } else {
          fs.copyFileSync(src, pp);
        }

        const so = path.join(dir, `${name}.so`);
        const c = run('cobc', [
          '-m', ...dialect, ...(coverage ? ['--coverage'] : []),
          ...extraFlags, '-o', so, pp,
        ]);
        fs.writeFileSync(path.join(dir, `${name}.cobc.log`), c.stdout + c.stderr);
        return {
          ok: c.ok,
          steps: [{
            name, stage: 'cobc', ok: c.ok,
            output: (c.stdout + c.stderr).trim(), command: c.cmd,
          }],
        };
      },
    });

    if (!entry.ok) {
      // The entry directory, not the out directory: that is where the logs of the
      // compile that failed are, and it is kept unmarked so the next request retries.
      steps.push(...entry.steps.map((s) => ({ ...s, cacheDir: entry.dir })));
      ok = false;
      continue;
    }
    if (entry.cached) {
      steps.push({
        name, stage: 'cobc', ok: true, cached: true,
        output: `already built (${path.basename(entry.dir)})`,
      });
    } else {
      steps.push(...entry.steps.map((s) => ({ ...s, cached: false })));
    }

    const pp = path.join(entry.dir, `${name}.cbl`);
    const so = materialize(path.join(entry.dir, `${name}.so`), outDir, `${name}.so`);
    modules.push(so);

    if (coverage) {
      // gcc names the notes file after the LINK target plus the translation unit
      // (<target>-<tu>.gcno) when it compiles and links in one pass, which is what
      // cobc -m does. The <tu> part comes from cobc's temporary file and so differs
      // between two compiles of the same source -- which is why it is found by
      // listing rather than by building that string, and why the name is carried over
      // from the cache as it is rather than recomputed.
      const gcno = fs.readdirSync(entry.dir)
        .filter((f) => f.startsWith(`${name}.so-`) && f.endsWith('.gcno'))
        .map((f) => materialize(path.join(entry.dir, f), outDir, f));
      const map = path.join(entry.dir, `${name}.cbsql.map`);
      // Absent only if the gixpp in the image predates -m, which would otherwise
      // surface much later as a program silently reporting no coverage.
      const mapFile = hasSql && fs.existsSync(map) ? map : null;
      // sourcePath as well as the basename: coverage.js needs to read the delivered
      // member to find where its PROCEDURE DIVISION starts. That one is the bundle's,
      // not the cache's -- it is what a reader opens.
      covSources.push({ name, source: file, sourcePath: src, preprocessed: pp, mapFile, gcno });
    }
  }

  return { ok, steps, modules, coverage: coverage ? covSources : null };
}

export { buildUnit };
