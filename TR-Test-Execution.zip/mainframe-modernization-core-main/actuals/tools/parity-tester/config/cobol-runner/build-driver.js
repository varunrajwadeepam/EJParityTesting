// Build the bundle's driver into an executable.
//
// Two stages, same as build-unit.js:
//
//   driver.cbl --gixpp--> <name>.pp.cbl --cobc -x--> <name>
//
// The driver is the COBOL host that owns GLOBDATA and the import/export views
// across the CALL and reports every field of the export view by name. It is part
// of the bundle because those views are declared INSIDE the entry program and
// differ per unit: a driver names every field against the real declaration, so a
// wrong name is a build failure here rather than a plausible-looking wrong number
// at run time.
//
// Cached like the unit (lib/build-cache.js), on the driver source plus the copy path
// plus the flags. It is per UNIT rather than per case -- the cases vary in the case
// FILE, which the driver reads at run time -- so re-running a unit's second case
// rebuilds nothing. No coverage artifacts here: the driver is ours, excluded from
// coverage for the same reason the shims are, so the executable is simply linked into
// the run's module directory.

import fs from 'node:fs';
import path from 'node:path';
import { run } from './lib/exec.js';
import { GIX_COPY, dialectFlags } from './lib/cobflags.js';
import {
  ensureCacheRoot, buildKey, copyPathDigest, withEntry, materialize,
} from './lib/build-cache.js';

// shimDirs is the copy path: every shim named anywhere in the bundle, in the order
// named. The driver COPYs GLOBDATA from the same copybook the shims and the legacy
// tree use, which is why it is compiled against them rather than on its own.
function buildDriver({ driverSrc, driverName, shimDirs = [], outDir, extraFlags = [] }) {
  // The name comes from spec.yaml and becomes a path and an exec target. Allow
  // only what a COBOL PROGRAM-ID can be, so a bundle cannot point the build at an
  // arbitrary path. lib/spec.js checks this too; repeated because this module is
  // also runnable by hand.
  if (!/^[A-Za-z0-9-]+$/.test(driverName || '')) {
    return {
      ok: false,
      steps: [{
        name: 'driver', ok: false,
        output: `bad driver name "${driverName}" -- letters, digits and - only`,
      }],
    };
  }
  if (!fs.existsSync(driverSrc)) {
    return {
      ok: false,
      steps: [{ name: 'driver', ok: false, output: `no driver source: ${driverSrc}` }],
    };
  }
  fs.mkdirSync(outDir, { recursive: true });
  ensureCacheRoot();

  const srcDirI = path.dirname(driverSrc);
  // The flags, for the key. The bundle directory is on the copy path but its PATH is
  // a per-request run id, so it is left out here and its contents go in through
  // copyPathDigest instead -- otherwise the driver would never be a cache hit.
  const flagSig = [
    driverName,
    'gixpp', '-e', '-z', 'a', ...shimDirs.flatMap((d) => ['-I', d]), '-I', GIX_COPY,
    'cobc', '-x', '-fnot-reserved=COLOR', ...shimDirs.flatMap((d) => ['-I', d]),
    '-I', GIX_COPY, ...extraFlags, '-L/usr/local/lib', '-lgixsql',
  ].join(' ');
  const key = buildKey([
    'driver', flagSig,
    copyPathDigest([...shimDirs, GIX_COPY]),
    copyPathDigest([srcDirI], { includePaths: false }),
    fs.readFileSync(driverSrc),
  ]);

  const entry = withEntry({
    name: `driver-${driverName}`,
    key,
    build: (dir) => {
      const steps = [];
      const pp = path.join(dir, `${driverName}.pp.cbl`);

      // -z a: anonymous '?' parameter markers -- see build-unit.js for why the
      // default -z d breaks against Db2.
      const g = run('gixpp', [
        '-e', '-z', 'a',
        ...shimDirs.flatMap((d) => ['-I', d]),
        '-I', GIX_COPY, '-I', srcDirI,
        '-i', driverSrc, '-o', pp,
      ]);
      fs.writeFileSync(path.join(dir, `${driverName}.gixpp.log`), g.stdout + g.stderr);
      steps.push({
        name: driverName, stage: 'gixpp', ok: g.ok,
        output: (g.stdout + g.stderr).trim(), command: g.cmd,
      });
      if (!g.ok) return { ok: false, steps };

      // A driver is ours and written in strict fixed format, so it needs none of the
      // legacy dialect flags -- but it does COPY GLOBDATA, hence COLOR. libgixsql is
      // linked per invocation rather than through COB_LIBS, which would *replace*
      // cobc's library list and drop libcob; see the Dockerfile.
      const c = run('cobc', [
        '-x', '-fnot-reserved=COLOR',
        ...shimDirs.flatMap((d) => ['-I', d]),
        '-I', GIX_COPY, '-I', srcDirI,
        ...extraFlags,
        '-L/usr/local/lib', '-lgixsql',
        '-o', path.join(dir, driverName), pp,
      ]);
      fs.writeFileSync(path.join(dir, `${driverName}.cobc.log`), c.stdout + c.stderr);
      steps.push({
        name: driverName, stage: 'cobc', ok: c.ok,
        output: (c.stdout + c.stderr).trim(), command: c.cmd,
      });
      return { ok: c.ok, steps };
    },
  });

  if (!entry.ok) {
    return { ok: false, steps: entry.steps.map((s) => ({ ...s, cacheDir: entry.dir })) };
  }

  // Linked into the run's module directory under its own name: run-driver.js executes
  // it by path, and keeping it beside the modules it CALLs is what makes a kept
  // workdir readable.
  const exe = materialize(path.join(entry.dir, driverName), outDir, driverName);
  const steps = entry.cached
    ? [{
      name: driverName, stage: 'cobc', ok: true, cached: true,
      output: `already built (${path.basename(entry.dir)})`,
    }]
    : entry.steps.map((s) => ({ ...s, cached: false }));

  return { ok: true, steps, executable: exe };
}

export { buildDriver };

