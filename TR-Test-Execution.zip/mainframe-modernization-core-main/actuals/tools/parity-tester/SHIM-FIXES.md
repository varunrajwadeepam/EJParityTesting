# CA Gen shim fixes

Work list for the shims in `config/cobol-runner/shims/cagen/`, produced by diffing each
shim against its function card in
`../../mainframe-modernization-portfolios/RevDB-cagen-lib/inputs/cards/<NAME>.md`
and then verifying the disputed points against the generated callers in
`../original_files/*.CBL`.

Each item below is self-contained: what is wrong, the evidence, the change to make, and
how to prove it. Work them in the order given — section 1 first, it contains the only
items that can make a run silently wrong rather than merely imprecise.

## Ground rules

1. **The card is the documentation side, the callers are the authority side.** Where a
   card cites a Broadcom/CA Gen 8.6 page or a BMC Module-Help page, that is a *specified
   contract* and the shim must match it. Where a card and the generated code disagree
   about a call shape, the generated code wins.
2. **Do not invent behaviour.** Every shim header carries its own evidence trail; keep
   that discipline. If a fix below cannot be grounded, leave the code alone and only
   correct the header comment so the next reader is not misled.
3. **Keep the house conventions already established in this directory:** unimplemented
   or unparseable input returns the CA Gen null value (`0` / `'00000000'` / spaces) plus
   a `DISPLAY … UPON SYSERR` warning, and does **not** set `STATUS-FLAG`,
   `ERROR-ENCOUNTERED-SW` or `VIEW-OVERFLOW-SW` — the callers `GOBACK` on those, which
   would abandon the action block and lose the rest of the recorded output. See the
   divergence notes in `TIRFNUM.cbl` and `TIRFDDUR.cbl`.
4. **When you change a header comment, change it to the truth, not to a softer claim.**
   Several of the items below exist *because* a header asserts a universal prototype
   derived from a ten-site sample.
5. Shims are compiled one `.so` per program and resolved by name at `CALL` time
   (`build-shim.js`), so arity is a runtime property. `NUMBER-OF-CALL-PARAMETERS` is the
   supported way to branch on it — `TIRLGLOD.cbl` already does this and is the pattern to
   copy.
6. The 11 cards with no shim (`TIRADDR`, `TIRSETA`, `TIRMMFN`, `TIRCFID`, `TIRCFIN`,
   `TIRCSRM`, `TIRDCRYW`, `TIRERR`, `TIRLIPS`, `TIRPXMIT`, `TIRSECW`) are **out of
   scope**. Do not create shims for them.

Commands below assume `cd config/cobol-runner/shims/cagen` for shim paths and
`cd ../../../../../original_files` for caller evidence. Set `LC_ALL=C` before grepping the
legacy tree — some members contain non-UTF-8 bytes.

---

## 1. Functional defects

### FIX-01 — `TIRLGLOD.cbl`: operand-count cap silently skips calls

**Severity: high.** This is the only item that makes a dispatched action block vanish.

`TIRLGLOD` is CA Gen's dynamic dispatcher: operand 1 is the callee name, operands 2..N
are passed straight through. The `EVALUATE WS-COUNT` at `TIRLGLOD.cbl:85-137` handles
counts 2–16 (15 pass-through operands) and falls into `WHEN OTHER`, which warns and
**calls nothing**. The header claims arity tops out at 15.

Call sites above that cap exist in the tree:

| Operands | Site |
|---|---|
| 25 | `P754941D.CBL:11068`, `:11650`, `:11881` |
| 23 | `P7549101.CBL:5294` |
| 19 | `MRR14541.CBL:2036` |

`P754941D.CBL:11068` is `CALL 'TIRLGLOD' USING E7549RMQ-ID` followed by 24 pass-through
operands (`IEF-RUNTIME-PARM1`, `IEF-RUNTIME-PARM2`, `GLOBDATA`, then 21 export views and
repeating groups). Today that call returns without running `E7549RMQ`, and the caller's
`IF STATUS-FLAG … GOBACK` sees clean switches, so the run continues with unpopulated
export views — a wrong result, not a failed one.

**Change:** extend `LK-01`…`LK-15` to `LK-24` in the LINKAGE SECTION and the
`PROCEDURE DIVISION USING` list, and extend the `EVALUATE` with `WHEN 17` … `WHEN 25`
following the existing shape exactly. Keep `WHEN OTHER` as the loud failure path.

Re-derive the true maximum rather than trusting 25 — run this and use the largest value
it prints:

```sh
LC_ALL=C python3 - <<'EOF'
import glob, re
best = []
for fn in glob.glob('*.CBL'):
    lines = open(fn, encoding='latin-1').read().splitlines()
    code = [(i+1, l[6:72]) for i, l in enumerate(lines) if len(l) > 6 and l[6] not in '*/']
    for k, (ln, a) in enumerate(code):
        if "CALL 'TIRLGLOD'" not in a:
            continue
        buf, j = a, k
        while j + 1 < len(code):
            j += 1
            nx = code[j][1]
            if re.match(r"\s*(END-CALL|IF|MOVE|PERFORM|CALL|GOBACK|SET|COMPUTE)\b", nx) or not nx.strip():
                break
            buf += ' ' + nx
            if nx.rstrip().endswith('.'):
                break
        ops = [t for t in re.split(r'[\s,]+', buf.split('USING', 1)[-1].replace('.', ' ')) if t]
        best.append((len(ops), fn, ln))
best.sort(reverse=True)
for b in best[:8]:
    print(b)
EOF
```

**Verify:** the five sites above compile and dispatch; `WHEN OTHER` is no longer reached
for any site in `original_files`.

---

### FIX-02 — `TIRFAIL.cbl`: missing fifth operand

**Severity: high** (ABI mismatch on 160 call sites).

The shim declares 4 operands (`TIRFAIL.cbl:35-41`) and its header lists
`IEF-RUNTIME-PARM1, IEF-RUNTIME-PARM2, FAIL-CMCB, GLOBDATA`. The real shape is **5**:

```cobol
GENCHRGB.CBL:1253
       CALL 'TIRFAIL'         USING RUNTIME-PARM1
                                    RUNTIME-PARM2
                                    FAIL-CMCB
                                    GLOBDATA
                                    SAVE-SQLCA.
```

Also at `GENCHRGB.CBL:1264`. `TIRFAIL.md` §5.1 has this right —
`RUNTIME-PARM1 RUNTIME-PARM2 FAIL-CMCB GLOBDATA SAVE-SQLCA`, with `SAVE-SQLCA` as
`PIC X(255)` in GLOBDATA — and marks it `Unverified`; the grep above verifies it.

**Change:** add `01 LK-05 PIC X(1).` and extend `PROCEDURE DIVISION USING` to
`LK-01, LK-02, LK-03, LK-04, LK-05.` Update the header's operand list to name
`SAVE-SQLCA` as `LK-05` and cite `GENCHRGB.CBL:1253`. Keep the body a no-op warning —
see FIX-11 for the open question about whether it should terminate.

**Verify:** `LC_ALL=C grep -A6 "CALL 'TIRFAIL'" original_files/*.CBL` shows five operands
at every site, matching the new declaration.

---

### FIX-03 — `TIRFCHR.cbl`: sign overlay contradicts the documented contract

**Severity: high** (produces a wrong byte 1 on any negative input).

`TIRFCHR.cbl:111-119` writes the magnitude zero-filled and then overlays `'-'` on byte 1,
under a header block titled *"SIGN POLICY (UNVERIFIED, and unexercised in this tree)"*
that admits *"That is a guess."*

It does not have to be a guess. `TIRFCHR.md` §4 records, from CA Gen 8.6 p.3051
(`Textnum`): **"The sign is not processed: `-1234.456` returns `000000000001234`."**

So the vendor contract is: emit the integer portion of the magnitude, zero-filled to the
receiving field width, and never a sign character. The shim's output for `-1234` is
`-00000000001234`; it should be `000000000001234`.

**Change:** delete the `IF LK-NUMBER-FP < ZERO` block at `TIRFCHR.cbl:111-119`. The
`COMPUTE WS-DIGITS = LK-NUMBER-FP` into an unsigned `PIC 9(15)` already yields the
absolute value, which is exactly the documented behaviour. Replace the "SIGN POLICY
(UNVERIFIED)" header block with the p.3051 citation and the worked example.

Keep the zero-fill/right-alignment reasoning in the header — that part was derived
correctly from `M7549DTE.CBL:425-426` (`JUST RIGHT` receiving fields) and agrees with the
same card rule ("zero-filled from the left to the target field width").

**Verify:** `-1234` → `'000000000001234'`; `9` → `'000000000000009'`, which still survives
the `MOVE … TO R2---JUST` at `M7549DTE.CBL:1049` as `'09'`.

---

### FIX-04 — `TIRFTRIM.cbl`: trims both ends, should trim trailing only

**Severity: high** (shifts data left whenever input has leading blanks).

`TIRFTRIM.cbl:24` asserts *"CA Gen's Trim function is defined as removing leading and
trailing blanks"* and line 73 implements that with `FUNCTION TRIM`.

`TIRFTRIM.md` §4 has two independent sources saying otherwise:

- CA Gen 8.6 p.3055: *"`trim` removes **trailing** blanks from a character string."*
- `bmc_docs/TIRFTRIM.txt` (BMC iStrobe Module-Help), cited in the card's Business Value
  line as agreeing.

**Change:** at `TIRFTRIM.cbl:73-74`, replace `FUNCTION TRIM` with a trailing-only trim.
`FUNCTION TRIM (WS-WORK TRAILING)` is the direct equivalent; if the configured dialect
rejects the `TRAILING` phrase, fall back to scanning `WS-WORK` backwards from `WS-LEN`
for the last non-space and setting `WS-LEN` to that index. Leading blanks must be
preserved in both the payload and the returned `FL`.

Correct the header comment at line 24 to cite p.3055 and `bmc_docs/TIRFTRIM.txt`.

**Verify:** input `'  AB  '` with `FL=6` returns `FP = '  AB'`, `FL = 4` (today it returns
`'AB'`, `FL = 2`). An all-blank input must still return `FL = 0` — the caller branches on
`IF OUTPUT-STRING-0002FL = 0` (`MEH10021.CBL:1124`), so that path must not change.

---

### FIX-05 — `TIRFNUM.cbl`: `NUMVAL` matches neither documented reading

**Severity: medium-high**, but **blocked on a contradiction between two cards — resolve
before coding.**

`TIRFNUM.cbl:120` uses `FUNCTION NUMVAL (WS-TRIM)`, which keeps the sign and discards the
fraction: `"-12.34"` → `-12`.

The two cards disagree about what `numtext` should return:

- `TIRFNUM.md` §5.1, citing CA Gen 8.6 p.3004 (`Numtext`): *"The output is an integer
  with sign and decimal point dropped, e.g. `"-12.34"` → `1234`"* — i.e. digits
  concatenated, sign dropped.
- `TIRFCHR.md` §4, citing p.3051 for the inverse function `Textnum`: `-1234.456` →
  `000000000001234` — i.e. fraction digits **discarded**, sign dropped.

Both agree the **sign is dropped**. They disagree on the fraction. `NUMVAL` is wrong on
the sign under either reading, so that half can be fixed now.

**Change, part A (unambiguous, do this):** take the absolute value of the result so the
sign is dropped —

```cobol
COMPUTE LK-NUMBER-FP = FUNCTION NUMVAL (WS-TRIM)
IF LK-NUMBER-FP < ZERO
    COMPUTE LK-NUMBER-FP = 0 - LK-NUMBER-FP
END-IF
```

**Change, part B (blocked):** do **not** change the fraction handling until the
contradiction is settled against p.3004 directly. Record it in the header as an open
question with both readings and both page citations.

Note for context: the single observed call site feeds a `PIC X(3)` view field
(`A7549229.CBL:2508`, `DIR-PIF-CHG-SEQ-NBR-0018`) into an `X(17)` wrapper, so no real
call in this tree carries a sign or a decimal point. Neither half of this fix is
exercised by current fixtures — which is exactly why it must be grounded in the vendor
page rather than in a test.

**Verify:** `"-12"` → `12`. `"00012"` → `12` (unchanged). `"-12.34"` → leave whatever the
current truncation gives and say so in the header.

---

### FIX-06 — `TIRFDAYS.cbl`: epoch is documented, not unknown

**Severity: medium** (absolute values are wrong by a constant; dates before 1601 return 0).

`TIRFDAYS.cbl:22` uses `FUNCTION INTEGER-OF-DATE`, i.e. days since 1600-12-31, and the
header argues *"THE EPOCH DOES NOT MATTER"* because the only observed caller uses the
result in a difference, adding: *"If a future caller ever reports the raw count, the
origin has to be pinned down against the mainframe first."*

It is already pinned down. `TIRFDAYS.md` §5.1, citing CA Gen 8.6 p.2969 (and consistent
with `datedays(10)` = `00010110` on p.2966): **days since 31 December 0000, so
`00010101` → 1.** The card's worked example is `'19970319'` → `729102`.

Two consequences today:

1. Any caller that reports or stores the raw count gets a value short by the
   1601-01-01 offset (`INTEGER-OF-DATE('16010101')` = 1, where the documented answer is
   584389).
2. `TIRFDAYS.cbl:68-74` rejects `WS-YYYY < 1601` and returns 0, but the documented domain
   starts at `00010101`.

**Change:** compute the day count directly on the documented epoch instead of calling
`INTEGER-OF-DATE`. `TIRFDDUR.cbl` already contains a proleptic-Gregorian day-number
conversion (`TO-DAYNUM` / `FROM-DAYNUM`, epoch 0000-03-01) built for exactly this reason —
*"FUNCTION INTEGER-OF-DATE and most language date classes reject or misbehave below
1601"*. Reuse that arithmetic and add the constant offset that maps 0000-03-01 to
31-December-0000 origin, then drop the `< 1601` guard down to `< 1` (keep rejecting year
0 and impossible month/day combinations, returning 0 plus the SYSERR warning).

Replace the *"THE EPOCH DOES NOT MATTER"* header block with the p.2969 citation, the
`00010101` → 1 anchor, and the `19970319` → `729102` example.

**Verify:** `'00010101'` → 1; `'19970319'` → 729102; the existing difference-only caller
(`A7549010.CBL:1115`, `:1131`) is unaffected, because a constant offset cancels in
`TOTAL-INTEGER-0005 - TOTAL-INTEGER-0006`.

---

### FIX-07 — `TIRUPPR.cbl`: no-op where the card dispositions `implement`

**Severity: medium**, scoped by FIX-13 below.

`TIRUPPR.cbl` declares the right 6 operands and then does nothing but warn
(`TIRUPPR.cbl:44-48`), so the transaction code reaches dispatch un-uppercased.

`TIRUPPR.md` §5.1 states the contract: the exit receives a translation table name
(`TIRUPPR-TABLE PIC X(8)`), a length (`TIRUPPR-LTH PIC S9(9) COMP`, fixed at `+8` at
every observed site) and data (`TIRUPPR-DATA PIC X(8)`), and **uppercases the data in
place**. There is no return code. `index.md` dispositions it `implement`, overriding its
`framework` section.

Observed caller (`M7549500.CBL:3356-3370`, `P2000-PROF-SETUP`): `MOVE W-TRAN-CODE TO
TIRUPPR-DATA`, call, `MOVE TIRUPPR-DATA TO W-TRAN-CODE`.

**Change:** implement the in-place uppercase over the first `TIRUPPR-LTH` bytes of
`TIRUPPR-DATA`. Declare `LK-03` as `PIC X(8)`, `LK-04` as `PIC S9(9) COMP`, `LK-05` as
`PIC X(8)` (derived from the card's §5.1 Input list and the `MOVE +8 TO TIRUPPR-LTH` at
the call site) and `COPY GLOBDATA` for `LK-06`. Use `FUNCTION UPPER-CASE` on the
`LK-05 (1:LK-04)` reference-modified slice. Clamp the length to the declared 8 and warn
on SYSERR if it arrives outside 1..8 rather than reference-modifying out of bounds.

**Do not** attempt to honour `TIRUPPR-TABLE`. The card's own open question is
*"Has this site customised the exit or the dialect translation tables? … Java needs to
replicate the table (for example, non-Latin dialects) rather than use plain
`toUpperCase()`."* Record in the header that the table name is accepted and ignored, that
this is code-page-default uppercasing per p.563, and that a customised `TIRUPPRZ` at the
site would make this wrong.

**Verify:** `'abc1'` → `'ABC1'`; bytes 9-onwards of a wider caller field untouched.

---

### FIX-08 — `TIRMTQB.cbl`: no-op where the caller consumes the result unconditionally

**Severity: medium**, scoped by FIX-13 below.

`TIRMTQB.cbl` declares the right 6 operands and does nothing. The caller then moves the
(never written) return area into the user-visible feedback line:

```cobol
M7549508.CBL:2778-2800
       MOVE UNPACKAGED-PSTEP TO FAIL-MSG-NO TIRMTQ-MESSAGE-NO
       CALL 'TIRMTQB' USING RUNTIME-PARM1 RUNTIME-PARM2
                         TIRMTQ-MESSAGE-TABLE TIRMTQ-MESSAGE-NO
                         TIRMTQ-RETURN-MESSAGE GLOBDATA
       MOVE TIRMTQ-RETURN-MSG-TEXT TO W-FEEDBACK PSMGR-EXIT-INFOMSG
       MOVE 'W' TO PSMGR-EXIT-MSGTYPE
```

`TIRMTQB.md` §5.1 (CA Gen 8.6 pp.667-669): look up `MSG-NUMBER` in table
`MSG-TABLE-NAME`; return `TIRMTQ-RETURN-MSG-LTH PIC S9(4) COMP` and
`TIRMTQ-RETURN-MSG-TEXT PIC X(256)`; **if the number is not in the table, return a
default message**; the exit sets no return code. `index.md` singles it out as *"the gap
between 18 `implement` and the 19 routines to reimplement: it sits in a `framework`
section yet carries real behaviour."*

**Change:** the message table contents are site-customisable and are not in this repo, so
a faithful lookup is not available. Implement the documented **default-message** path for
every number, which is the one branch the vendor doc does specify: declare `LK-05` as the
`LTH` / `TEXT` group from the card, write a deterministic placeholder that carries the
message number (so a parity diff points at the right catalogue entry rather than at an
empty line), set `LTH` to its length, and warn once on SYSERR that no catalogue is
loaded. Leave the return code alone — there isn't one.

Do not invent message wording for specific numbers. Record in the header that
`TIRMTQ-MESSAGE-TABLE` is accepted and ignored, and that `P2000-PROF-SETUP`
(`M7549508.CBL:3209-3212`) overwrites the message-table name with the *translate*-table
name before the call — an open question already on the card.

**Verify:** `W-FEEDBACK` is deterministic and non-blank after the call, and contains the
message number passed in.

---

## 2. Documented divergences to make explicit, not to "fix"

These are places where the shim deliberately departs from a documented contract for a
reason that holds. The code is right; the header must say so against the card's citation,
so the next reader does not re-litigate it or quietly "correct" it.

### FIX-09 — `TIRFDTEC.cbl`: narrower input grammar than `datetext`

`TIRFDTEC.cbl:62-71` accepts ISO `YYYY-MM-DD` only. `TIRFDTEC.md` §5.1, citing CA Gen 8.6
p.2968, says `datetext` parses **`yyyy-mm-dd`, `mm/dd/yyyy`, `dd.mm.yyyy` or `yyyynnn`**.

The shim's narrowing is well evidenced (all 215 sites feed X(10) view fields that Db2
`DATE` columns land in; 12 sites prime them with `'0001-01-01'`), and the card's own open
question — *"Which input layouts actually occur in the portfolio? (`mm/dd` and `dd.mm` are
ambiguous for day ≤ 12.)"* — is answered by that evidence.

**Change: header only.** Cite p.2968's four layouts, state that only ISO occurs in this
portfolio with the `A7549033.CBL:598,729` evidence, and state that a non-ISO input returns
`'00000000'` with a SYSERR warning rather than being parsed. Note that implementing
`mm/dd/yyyy` and `dd.mm.yyyy` without caller evidence would introduce an ambiguity for
day ≤ 12 that cannot be resolved from the data.

### FIX-10 — `TIRFSSTR.cbl` / `TIRFNUMD.cbl` / `TIRFDDUR.cbl`: errors downgraded to warnings

Three shims return the CA Gen null value plus SYSERR where the documented contract raises:

| Shim | Documented (card) | Shim |
|---|---|---|
| `TIRFSSTR.cbl:79-85` | `TIRM132E` (length > input), `TIRM133E` (start > input), `TIRM134E` (start+length > input) — `TIRFSSTR.md` §5.1, p.3049 | clamps, or returns spaces with `FL = 0`, plus SYSERR |
| `TIRFNUMD.cbl:65-78` | *"For an incorrect date, `datenum` returns zero, which results in a runtime error"* — `TIRFNUMD.md` §4, p.2968 | `'00000000'` plus SYSERR |
| `TIRFDDUR.cbl` | with `SKIP-VAL = 'N'` the runtime validates the input date | `'00000000'` plus SYSERR (already documented in the shim) |

This is ground rule 3 and it is correct: setting `ERROR-ENCOUNTERED-SW` makes the caller
`GOBACK` out of the whole action block (`P7549500.CBL:1258-1262`), turning a data problem
into a silent early exit that looks like a code path.

**Change: header only**, in `TIRFSSTR.cbl` and `TIRFNUMD.cbl` — `TIRFDDUR.cbl` already has
this note and needs nothing. Name the documented error condition and the page, then state
the house convention and why. `TIRFSSTR.cbl` should additionally note that p.3049 defines
`length = 0` as *"a zero-length string with no error"*, so that path should not emit a
SYSERR warning at all — it is a documented normal case, not a diagnostic.

### FIX-11 — `TIRFAIL.cbl`: no-op vs a termination contract

`TIRFAIL.md` §5.1 (CA Gen 8.6 pp.673-675, 677): builds an error-message table, merges
`DSNTIAR` text for unrecoverable DB2 errors via `TIRTIARX`, then calls `TIRTERMA`;
*"the fatal path does not return to business code."* `index.md` keeps it `framework`
rather than `drop` precisely because *"`TIRFAIL` has a failure contract that the target
must meet"*, and flags that the sibling portfolio
(`RevDB-revol/cagen-lib-docs/cagen-utility-lib-instructions.md:32`) dispositions it as
dropped — a disagreement the index asks to be *"reconcile[d] explicitly rather than
treating it as a contradiction."*

The shim returns normally, so a unit that hits a fatal path keeps running.

**Change:** apply FIX-02 (the fifth operand), then **leave the body a no-op** and record
the question in the header: a `GOBACK` here resumes business code that the real runtime
would never have resumed, so a recorded case that reaches `TIRFAIL` is not comparable
either way. Note that `FAIL-CMCB`'s layout is unknown (card open question) and that
terminating the run instead would need a decision from the parity harness, not from this
file.

### FIX-12 — `TIRFDDUR.cbl`: `SKIP-VAL` reading is unsourced

`TIRFDDUR.cbl` states *"`PSMGR-TIRDATE-SKIP-VAL = 'N'` means the real runtime validates
the input date."* `TIRFDDUR.md` §6.3 lists this as an open question: *"What do
`PSMGR-TIRDATE-SKIP-VAL` and `PSMGR-FUNC-ERRMSG` do?"* The only source either way is the
`GLOBDATA.cpy:253-257` comment — *"Y = DON'T VALIDATE INPUT DATE AND/OR TIME YET; THIS
TIRDATE CALL IS FOR AN INTERMEDIATE RESULT, AND ANOTHER CALL FOLLOWS"* — which says what
`'Y'` means and leaves `'N'` to inference.

**Change: header only.** Downgrade the claim to an inference and cite
`GLOBDATA.cpy:253-257` as the basis.

Related, same file: the `*-MISS` flags are tested as the literal `'Y'`
(`DDURA-Y-MISS = 'Y'`). That is right for the observed caller
(`P7549500.CBL:81-82`, `DATA-PRESENT` = `'Y'`) and the header already explains the
backwards-reading names. Add one line noting the shim depends on that literal because
`GLOBDATA.cpy` does not define the `DATA-PRESENT` / `DATA-MISSING` condition names —
they live in each caller's WORKING-STORAGE — so a caller with different values would
break it silently.

---

## 3. Header-comment corrections (ABI claims that are provably too narrow)

Three shims declare a fixed prototype derived from a ten-to-twelve-site sample in
`units/P7549500`, and state that as universal. Hundreds of sites in the same tree
disagree. All three shims declare `GLOBDATA` as a trailing operand and **never
dereference it**, so they run today — the defect is the stated contract, plus a trap for
anyone who later adds a `GLOBDATA` reference to them.

### FIX-13 — `TIRD2VW.cbl`, `TIRVW2D.cbl`, `TIRDAT2.cbl`: variable arity

| Shim | Declares | Actual distribution in `original_files` | Card |
|---|---|---|---|
| `TIRD2VW.cbl:60` | 3 (`db2-date`, `view-date`, `GLOBDATA`) | **2 operands at 289 sites**, 3 at 1053 | `TIRD2VW.md:59` records both: S1 = 2 args (60 sites, `DRP10371`/`DRR*`), S2 = 3 args (12 sites, `A75492*`) |
| `TIRVW2D.cbl:73` | 3 | **2 operands at 155 sites**, 3 at 620 | `TIRVW2D.md:61` records both: S1 = 2 args (30 sites), S2 = 3 (7 sites) |
| `TIRDAT2.cbl:203` | 4 (`PARM1`, `PARM2`, `CMCB`, `GLOBDATA`) | **3 operands at 228 sites**, 4 at 115 | `TIRDAT2.md:539,547` records S1 = 3 args (30 sites), S2 = 4 (4 sites) |

Two-operand samples: `DRR12611.CBL:865` — `CALL 'TIRD2VW' USING EFF-DT-ID-001EF
EFF-DT-ID-0002`, no `GLOBDATA`; `DRR12611.CBL:852` and `DRR1309A.CBL:1104` for `TIRVW2D`.
Three-operand `TIRDAT2`: quoted on the card itself at `MRR13291.CBL:1103` —
`CALL 'TIRDAT2' USING IEF-RUNTIME-PARM1 IEF-RUNTIME-PARM2 PSMGR-TIRDATE-CMCB`.

Reproduce the distribution with:

```sh
LC_ALL=C grep -A5 "CALL 'TIRD2VW'" original_files/*.CBL | grep -c GLOBDATA
LC_ALL=C grep -hc "CALL 'TIRD2VW'" original_files/*.CBL | paste -sd+ | bc
```

**Change:**

1. **`TIRD2VW.cbl`** — replace *"All ten call sites agree on the same three-operand shape,
   so this is a fixed prototype"* with the real distribution: two shapes, 2 and 3
   operands, the 2-operand one dominant in the `DRR*`/`DRP*` units; cite
   `DRR12611.CBL:865`. Add: this shim never references `GLOBDATA`, which is the only
   reason the 2-operand sites are safe; **anything added here that touches `GLOBDATA`
   must first guard on `NUMBER-OF-CALL-PARAMETERS >= 3`**.
2. **`TIRVW2D.cbl`** — same, citing `DRR12611.CBL:852`.
3. **`TIRDAT2.cbl`** — same, citing `MRR13291.CBL:1103` for the 3-operand shape and
   `A7549269.CBL:759` for the 4-operand one. `TIRDAT2` is the riskiest of the three
   because its `COPY GLOBDATA` is live in the file; confirm by inspection that no
   paragraph reads a `GLOBDATA` field, and if one ever must, guard it.

Also correct the arity sentence in `TIRLGLOD.cbl`'s header (*"arity from 5 to 15"*) when
you do FIX-01.

### FIX-14 — `TIRDAT2.cbl`: `SKIP-VAL` ignored on `REQ=0`

`TIRDAT2.md` §3 lists `SKIP-VAL=Y` — *"DON'T VALIDATE INPUT DATE AND/OR TIME YET"* — as
part of the operation model. `TIRDAT2.cbl`'s `VALIDATE-INPUT` validates unconditionally.

No observed `REQ=0` site sets `SKIP-VAL`, so this is latent.

**Change: header only** — note that `SKIP-VAL` is not honoured, that no observed site sets
it, and that honouring it means returning `RC = 0` without validating.

---

## 4. Verified agreements — do not "fix" these

Recorded so a later pass does not churn code that is already right.

- **Date/time extractor offsets**, all confirmed against their cards' documented
  character positions: `TIRFDAY` `(7:2)`, `TIRFMTH` `(5:2)`, `TIRFYEAR` `(1:4)`,
  `TIRFHOUR` `(1:2)`, `TIRFMIN` `(3:2)`, `TIRFSEC` `(5:2)`, `TIRFMICR` `(15:6)` of the
  20-byte timestamp.
- **`TIRFDTEJ`** returns `YYYYDDD` (ordinal date), not a Julian Day Number —
  `TIRFDTEJ.md` §5.1, p.2990, worked example 1992-01-10 → `1992010`.
- **`TIRFDNUM` / `TIRFNUMD` directions are not swapped**: `TIRFDNUM` = `numdate`
  (date → number, p.3003); `TIRFNUMD` = `datenum` (number → date, p.2968). Both shims
  match. `index.md` warns that one extract description mislabels `TIRFDTEC` as
  "date-to-epoch" (that is `TIRFDAYS`); the shims do not fall for it.
- **`TIRD2VW` / `TIRVW2D` / `TIRS2VW` / `TIRVW2S` sentinel round-trip**: Db2
  `'0001-01-01'` ↔ view `0`, and `'0001-01-01-00.00.00.000000'` ↔ all-zero view
  timestamp. Consistent across all four and with `TIRFDTEC` / `TIRFNUMD`.
- **`*AT` group layouts**: text = `MA` / `FL` `S9(4) COMP` + `FP X(4096)`; numeric =
  `SV X(1)` + `FP S9(4) COMP`. Matches `TIRFTRIM.md` §4 and `TIRFSSTR.md` §5.1.
- **`TIRDAT2`** selector table (`REQ` 0-7, `DATEF` 0-2, `TIMEF` 0-2) and `CMCB` field
  order match `TIRDAT2.md` §3 and `GLOBDATA.cpy:219-258`. Implementing only `REQ=7` and
  `REQ=0` is right: the card records 0 of 34 sites using `REQ` 1-6.
- **`TIRTRCE`** 9-operand order `GLOBDATA, PADTEXT, STMT-NUM, IA, OA, LA, EA, PADVIEW,
  RET-CD` matches `TIRTRCE.md` §5.1 exactly.
- **Framework arities and operand order**, all matching their cards' quoted call sites:
  `TIRBTCH` 6, `TIRRETCD` 2, `TIRDLCT` 4, `TIRHSTG` 4, `TIRMOVEA` 6, `TIRMOVEP` 8,
  `TIRMSG` 8, `TIRPROF` 9, `TIRSECR` 4, `TIRSYSID` 4, `TIRUSRID` 5, `TIRMTQB` 6,
  `TIRUPPR` 6.
- **The remaining no-op framework shims** (`TIRBTCH`, `TIRRETCD`, `TIRDLCT`, `TIRHSTG`,
  `TIRMOVEA`, `TIRMOVEP`, `TIRMSG`, `TIRPROF`, `TIRSECR`, `TIRSYSID`, `TIRUSRID`) rest on
  *"NO NON-ROOT CALLER — every call site is in an M\* dialog driver or GEN\* batch driver
  shell."* That holds: every site for these is in a `GEN*`, `M*` or `P*` root member the
  harness replaces with a generated driver. **Validate the assumption before relying on
  it for FIX-07 and FIX-08** —

  ```sh
  LC_ALL=C grep -l "CALL 'TIRUPPR'" original_files/*.CBL
  LC_ALL=C grep -l "CALL 'TIRMTQB'" original_files/*.CBL
  ```

  If every hit is a root member the harness replaces, FIX-07 and FIX-08 are
  completeness work rather than parity-critical, and can be deprioritised below
  section 1's other items. If any hit is a compiled unit, they move to the top.
- **Card "Used by 0 programs, 0 call sites" lines are an artefact** of `docs/files/`
  scoping, not reality. Where a shim header cites a caller the card could not find
  (`A7549033`, `A7549005`, `A7549010`, `A7549282`, `P754928A`) the shim is the better
  evidence. Several card open questions are already answered in shim headers; do not
  reopen them.

---

## Suggested order

1. FIX-01 (`TIRLGLOD` cap) — only item that silently drops a call.
2. FIX-02 (`TIRFAIL` 5th operand) — one-line ABI correction.
3. FIX-03, FIX-04 (`TIRFCHR` sign, `TIRFTRIM` trailing-only) — documented contracts,
   small diffs, visible in output.
4. FIX-06 (`TIRFDAYS` epoch) — needs the day-number arithmetic from `TIRFDDUR.cbl`.
5. FIX-05 part A (`TIRFNUM` sign). Part B stays blocked.
6. Run the `grep -l` check at the end of section 4, then FIX-07 / FIX-08 at whatever
   priority it implies.
7. FIX-09 through FIX-14 — comment-only, batch them.
