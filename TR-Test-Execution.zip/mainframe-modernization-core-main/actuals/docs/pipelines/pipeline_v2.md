# Pipeline v2: COBOL migration of one Migration Unit

## Overview

One Migration Unit (MU) is migrated by running **four skills**: design, then implement and build-tests (in any order), then validate; **report** shows the test results at any point. The other skills support them.

| Skill | Does |
|---|---|
| `mu-design` | Extracts the COBOL logic, writes numbered business rules, records test cases against the real COBOL, produces `design/` (rules, dictionary, design, tests, stubs, interface). |
| `mu-implement` | Builds the Java code in `solution/` from `design/`, with unit and integration tests and a review. Never reads the COBOL. |
| `mu-build-tests` | Builds the test package in `tests/`: the `tests.md` cases plus an advanced set from `rules.md`, each recorded twice on the real COBOL, with rule and paragraph traceability and COBOL paragraph coverage. |
| `mu-validate` | Replays the package against `solution/` with the e2e framework (twice), in a test solution `validation/` beside it, and classifies every failure (BINDING, SOLUTION, ENVIRONMENT, PACKAGE, DECISION). |
| `mu-report` | Writes one HTML page per MU in `report/`: design and implement gates, the product's unit, contract and integration tests, the test package, the replay, every open question and the next move. Changes nothing the other skills produced; `--confirm` runs the product's own tests on a copy. |

Supporting skills, loaded by the two above: `cobol-logic-extractor`, `run-cobol`, `mflens-mcp` (design); `target-java-3tier`, `tir-java`, `java-code`, `java-solution` (target stack and code). Set-up skills: `mu-init` (new MU folder), `mflens-login` (MFLens sign-in).

The skills do not stop to ask: every gap becomes a question in an `*-open-questions.md` file. You answer, then re-run, and only the affected steps are redone.

All of it is the `pipelines` plugin (`actuals/pipelines/` of this repository). Claude Code can install it from git itself, or from a local clone of the repository. The local clone is preferred.

## 1. Once per machine

| Need | Check |
|---|---|
| Claude Code | `claude --version` |
| Read access to `git.epam.com/epm-aimm/mainframe-modernization-core` - an SSH key in `ssh-agent`, or HTTPS with a git credential helper | `git ls-remote git@git.epam.com:epm-aimm/mainframe-modernization-core.git` |
| Python 3 as `python`, with PyYAML | `python --version`, `python -c "import yaml"` |
| `docker` or `podman` on `PATH` | `docker ps` |
| Java 21 (`JAVA_HOME`) and Maven | `java -version`, `mvn -v` |
| An MFLens account | |

## 2. Set up the workspace

1. **Install the plugin.** Add the marketplace in one of two ways (not both), then install.

   **Marketplace - local clone (preferred).** The plugin is read from a folder on disk: no git access is needed at install time, you can read the skills, and you can try a change before releasing it.

   ```
   git clone --branch v2.0 git@git.epam.com:epm-aimm/mainframe-modernization-core.git <dir>/mainframe-modernization-core
   claude plugin marketplace add "<dir>/mainframe-modernization-core"
   ```

   **Marketplace - git.** Claude Code fetches only `.claude-plugin/` and `actuals/pipelines/` (about 1 MB) and keeps no clone:

   ```
   claude plugin marketplace add "git@git.epam.com:epm-aimm/mainframe-modernization-core.git#v2.0" --sparse .claude-plugin actuals/pipelines
   ```

   Then install, one of the two:
   - **A. For yourself, once per machine.** Available in every folder:

     ```
     claude plugin install pipelines@mainframe-modernization
     ```

     To enable it only for the workspace, run it from the workspace folder with `--scope project`.

   - **B. For the workspace, shared with the team** (git marketplace only). Create the workspace folder and in it `.claude/settings.json`, and commit it with the workspace. Everyone who opens the folder is offered the plugin, at the version the workspace pins. No `marketplace add` or `install` is needed:

     ```json
     {
       "extraKnownMarketplaces": {
         "mainframe-modernization": {
           "source": {
             "source": "git",
             "url": "git@git.epam.com:epm-aimm/mainframe-modernization-core.git",
             "ref": "v2.0",
             "sparsePaths": [".claude-plugin", "actuals/pipelines"]
           }
         }
       },
       "enabledPlugins": { "pipelines@mainframe-modernization": true }
     }
     ```

   Both marketplaces use this repository (`.claude-plugin/marketplace.json` at its root) and declare the name `mainframe-modernization`, and `v2.0` is the release tag. Do not mix the ways on one machine. To switch, first `claude plugin uninstall pipelines@mainframe-modernization` and `claude plugin marketplace remove mainframe-modernization`. Claude Code copies the plugin into `~/.claude/plugins/cache/`; it never puts it in the workspace.
2. **Start Claude Code** in the workspace folder: `claude`. With B, trust the folder and let it install the plugin. Approve the `mflens` MCP server (the shared MFLens).
3. **Sign in to MFLens:** `/pipelines:mflens-login`. Opens a browser; once per machine, valid 30 days.
4. **Get the parity-tester** (the COBOL runner and Db2): download `actuals/tools/parity-tester` from the repository (GitLab: open the folder, Code → Download this directory) and unzip it to `<workspace>/tools/parity-tester/`. Its first start builds images (about 15 min) and loads Db2 (several min).
   **Get the e2e framework** the same way: `actuals/tools/e2e-framework` to `<workspace>/tools/e2e-framework/` (used by `mu-validate`, built on its first run).
5. **Create the MU:** `/pipelines:mu-init mu/<MU>`. Writes `mu/<MU>/` and, when missing, `CLAUDE.md`, `.gitignore` and `solution/`, and lists what is left to fill in.

```
<workspace>/
  .claude/settings.json     B (or `--scope project`): enables the plugin for the team
  CLAUDE.md                 the MU layout, loaded in every session
  tools/parity-tester/      the COBOL runner and Db2
  tools/e2e-framework/      the replay test framework (mu-validate)
  solution/                 shared target codebase; may be empty
  mu/<MU>/                  one folder per MU
  validation/               mu-validate's test solution (generated; target/ not committed)
```

## 3. Steps

1. **Prepare the MU.** In `mu/<MU>/` fill every `<...>` that `mu-init` listed:
   - `mu.yaml`: `entry_points`, `portfolio_id`, `description`, `du`; `target` skills, archetype and `solution` have defaults. Schema: the plugin's `templates/mu.schema.yaml`.
   - `tools.yaml`: MFLens values are the shared MFLens already; parity-tester `home` defaults to `../../tools/parity-tester`; `start`/`stop` for your platform; `golden-db2` (recording schema of build-tests, required: without it build-tests stops) and optional `test-db2` (implement); `e2e-db2` (replay schema) is written by `mu-validate` on its first run. Secrets are `${NAME}`, from the environment or the `secrets:` file.
   - `inputs/target-state.md`: `# Target stack` (package root, module layout, port, time zone, security, ...) and `# SME notes`.
   - `inputs/db-schema/*.sql`: DDL of the tables touched (reference only).
   - `inputs/deps/`: `<mu>.interface.md` / `<mu>.usage.md` of MUs this one calls or builds on.
   - `inputs/cobol/`: optional; empty means design extracts it from MFLens.
2. **Run design.** From the workspace: `/pipelines:mu-design mu/<MU>`. About 1-1.5 h. Preflight checks the files, MFLens and the parity stack, and starts the parity stack if it is down.
3. **Answer the design questions.** Read `design/report.md`, then `design/design-open-questions.md`. Write each decision on its `Answer:` line, and re-run `/pipelines:mu-design mu/<MU>`.
4. **Run implement.** `/pipelines:mu-implement mu/<MU>`. It needs `design/` and `unit/` from step 2. Integration tests use `test-db2` (else `db2`) and never start the database. If it is down, start it and re-run.
5. **Answer the implement questions.** Read `implement/report.md`, then `implement/implement-open-questions.md`. Fill in `Answer:` lines and re-run `/pipelines:mu-implement mu/<MU>`.
6. **Review the result.** Check the code in `solution/`, `implement/traceability.md` (every COBOL paragraph against the code carrying it) and the review findings in `implement/report.md`.
7. **Build the tests.** `/pipelines:mu-build-tests mu/<MU>` (needs `design/` and `unit/`, the parity stack running). Read `tests/tests-report.md`, answer `tests/tests-open-questions.md` (`PQ-n`) and re-run until the state is `ready`.
8. **Validate.** `/pipelines:mu-validate mu/<MU>` (needs the package `ready`, `solution/` and the parity Db2). The first run stops for you twice: the replay-schema question `VQ-n` when the default schema already holds data, and the record gate `RG-n` (`approved by <First Last>`). Fill the `Answer:` line and say "resume"; the agent applies it.
9. **Act on the result.** Read `validation/validation-report.md` and `validation/failures.md` in `mu/<MU>/`. SOLUTION: re-run `/pipelines:mu-implement` with the failures, or decide the behaviour and re-run `/pipelines:mu-build-tests`; BINDING / PACKAGE: re-run `/pipelines:mu-build-tests`; ENVIRONMENT: fix the MU's settings and re-run. A crash of a command or tool, or an UNKNOWN failure, goes to the platform dev team.
10. **Report.** `/pipelines:mu-report mu/<MU>` at any point (seconds); `--confirm` also runs the product's unit, contract and integration tests on a copy against `test-db2` (about 2 min, reused for the same product), `--rebuild` runs them again. Open `mu/<MU>/report/test-results.html`; dated copies for the client are in `report/history/`.

For a dependent MU, copy this MU's `design/interface.md` and `implement/usage.md` to the other MU's `inputs/deps/` as `<mu>.interface.md` and `<mu>.usage.md`.

The parity-tester stays running after design. Stop it with its stop script.

## Updates

A release is a new `version` in `plugin.json` (normally 2.0.n+1) and a tag `v<version>`. An installed plugin stays on the version it was installed from until you update it. Check what you have: `claude plugin list`.

- **Local clone (preferred):**

  ```
  cd <dir>/mainframe-modernization-core
  git fetch --tags
  git checkout v2.0.n+1              # or `git pull` when the clone follows a branch
  claude plugin marketplace update mainframe-modernization
  claude plugin update pipelines@mainframe-modernization
  ```

  Then restart Claude Code (sessions already open keep the old version).
- **Git marketplace, A:** the marketplace is pinned to a tag, so re-add it with the new one:

  ```
  claude plugin uninstall pipelines@mainframe-modernization
  claude plugin marketplace remove mainframe-modernization
  claude plugin marketplace add "git@git.epam.com:epm-aimm/mainframe-modernization-core.git#v2.0.n+1" --sparse .claude-plugin actuals/pipelines
  claude plugin install pipelines@mainframe-modernization
  ```

  Then restart Claude Code.
- **B:** change `ref` in `.claude/settings.json` to the new tag, commit, and restart Claude Code (or `/plugin`, update `pipelines`).

If `plugin update` reports the plugin as already current although the files changed, the `version` in `plugin.json` was not bumped: bump it, or `claude plugin uninstall` and `claude plugin install` again.

## No access to git.epam.com

For a client environment that cannot reach the repository, declare the marketplace inline instead, with the plugin as a zip of `actuals/pipelines` hosted on any HTTPS server reachable from there:

```json
"extraKnownMarketplaces": {
  "mainframe-modernization": {
    "source": {
      "source": "settings",
      "name": "mainframe-modernization",
      "owner": { "name": "epm-aimm" },
      "plugins": [
        {
          "name": "pipelines",
          "source": {
            "source": "archive",
            "url": "https://<host>/v2.0.zip",
            "sha256": "<sha256 of the zip>"
          }
        }
      ]
    }
  }
}
```

## Developing the plugin

Load the working copy instead of the release: `claude --plugin-dir <repo>/actuals/pipelines`, from a workspace. To release:

1. Bump `version` in `actuals/pipelines/.claude-plugin/plugin.json`.
2. Tag the commit `v<version>` and push the tag.
3. Change the tag in `templates/workspace/.claude/settings.json` and in section 2 above (the git marketplace and B).
