# Pipelines v2 - quick review (package version 2.3.0)

COBOL / CA Gen migration of one Migration Unit (MU) at a time, from the COBOL to a tested Java solution.
Installation, workspace setup and updates: [pipeline_v2.md](pipeline_v2.md). An extended document follows later.

## Commands

| Command | Does | Writes |
|---|---|---|
| `/mu-init mu/<MU>` | creates the MU skeleton from the templates, lists the `<...>` values to fill | `mu/<MU>/mu.yaml`, `tools.yaml`, `inputs/` |
| `/mflens-login mu/<MU>` | signs in to MFLens (browser, valid 30 days) | token cache |
| `/mu-design mu/<MU>` | extracts the logic, builds the rule inventory, the target design and the basic test set recorded on the COBOL | `extracted-logic/`, `unit/`, `design/` |
| `/mu-implement mu/<MU>` | builds the Java code, unit and integration tests from the design | `solution/`, `implement/` |
| `/mu-build-tests mu/<MU>` | test package: `tests.md` basic set + advanced set from `rules.md`, each case recorded twice on the COBOL, rule and paragraph traceability, COBOL paragraph coverage | `tests/` |
| `/mu-validate mu/<MU>` | replays the package against the solution with the e2e framework (twice), classifies every failure (BINDING, SOLUTION, ENVIRONMENT, PACKAGE, DECISION) | `validation/` (test solution), `mu/<MU>/validation/` |
| `/mu-report mu/<MU> [--confirm] [--rebuild]` | one HTML page with the test results of the MU at any point of the migration: design and implement gates (L0), the product's unit, contract and integration tests (L1-L3), the test package (LC), the replay (L4), all open questions and the next move; `--confirm` runs the product's own tests on a copy (reused for the same product) | `mu/<MU>/report/` (`test-results.html`, dated copies in `history/`) |

Every command runs to the end, collects its questions in a `*-open-questions.md` file and prints a short summary.
A re-run applies the answers and redoes only what changed.

## Tools

| Tool | Used by | Where |
|---|---|---|
| **parity tester** - COBOL runner (GnuCOBOL + CA Gen shims) and Db2 | `mu-design`, `mu-build-tests` (through the `run-cobol` skill) | `actuals/tools/parity-tester` -> workspace `tools/parity-tester` (`tools.yaml` `parity-tester.home`) |
| **e2e framework** - replay engine (Cucumber, golden masters, fixtures, comparator) | `mu-validate` | `actuals/tools/e2e-framework` -> workspace `tools/e2e-framework` (`tools.yaml` `e2e-framework.path` if elsewhere) |

## Next release

1. `mu-ba-artifacts` - business documents from `rules.md` and the design (BA migration from e2e_v1).
2. Stabilisation and improvement of `mu-build-tests`, `mu-validate` and `mu-report`: strict per-case comparison, framework to-dos (decided answers, response headers, clock checks), shorter record gate.
3. SERVICE entry points (a Spring bean, not REST) testable end to end, besides REST.
4. Entry points and boundaries in `mu.yaml`, so one full MFLens portfolio profile serves all MUs.

## Preparing an MU

`mu/<MU>/` (created by `/mu-init`):

| Item | Content |
|---|---|
| `mu.yaml` | `name`, `description`, `du`, `entry_points`, `portfolio_id`, `target` (`architecture_skill`, `archetype`, `tir_skill`, `code_skill`, `solution_skill`), `solution` |
| `tools.yaml` | `mflens` (url, auth), `parity-tester` (home, start/stop), `cobol-runner`, `db2`, `golden-db2` (recording schema `GM_<MU>`, required by `mu-build-tests`); optional `test-db2` (implement), `e2e-db2` (replay schema `E2E_<MU>`, written by `mu-validate` on its first run), `e2e-framework` |
| `inputs/target-state.md` | `# Target stack` (versions, package root, port, time zone, security), `# SME notes` |
| `inputs/db-schema/*.sql` | DDL of the tables the programs touch |
| `inputs/deps/` | other MUs' `interface.md` / `usage.md`, libraries |
| `inputs/cobol/` | optional; extracted from MFLens when missing |

Secrets as `${NAME}` (environment, then the `secrets:` file).

## Run sequence and human interventions

| # | Step | You |
|---|---|---|
| 1 | `/mu-init mu/<MU>` | fill every `<...>` in `mu.yaml`, `tools.yaml`, `inputs/target-state.md`; add DDL and deps |
| 2 | `/mflens-login mu/<MU>` | sign in in the browser |
| 3 | `/mu-design mu/<MU>` | read `design/report.md`, `hld.md`; answer `design-open-questions.md` (`Answer:` lines); re-run until no blocking question |
| 4 | `/mu-implement mu/<MU>` | answer `implement-open-questions.md`; start the test database if asked; re-run |
| 5 | `/mu-build-tests mu/<MU>` | answer `tests-open-questions.md` (`PQ-n`, blocking ones first); accept regressions only by instruction; state must be `ready` |
| 6 | `/mu-validate mu/<MU>` | first run: answer the replay-schema question (`VQ-n`) if the default schema has data; approve the record gate `RG-n` (`approved by <First Last>`, optionally `disputed:`); re-run |
| 7 | read `mu/<MU>/validation/failures.md` and `validation-report.md` | SOLUTION -> re-run `/mu-implement` with the failures, or decide the behaviour (answer the question) and re-run `/mu-build-tests`; BINDING / PACKAGE -> re-run `/mu-build-tests`; ENVIRONMENT -> fix the MU's settings (`tools.yaml`, start the database) and re-run |
| 8 | `/mu-report mu/<MU>` (any time; `--confirm` to run the product's tests, `--rebuild` to run them again for the same product) | open `mu/<MU>/report/test-results.html`; act on its next move; hand a dated copy from `report/history/` to the client |

Steps 4 and 5 are independent once the design is done. Only the person deciding answers a question or the record gate; the agent never does.

You change only what belongs to the MU: `mu/<MU>/` (inputs, `mu.yaml`, `tools.yaml`, answers) and re-runs of the commands.
Never edit the commands, skills, scripts, templates or tools. A crash of a command or a tool, an UNKNOWN failure class, or a
result that looks wrong in the pipeline itself goes to the **platform dev team**, with the command's report, its open-questions
file and the logs in `mu/<MU>/**/.tmp/`.
