---
name: mflens-login
description: Signs in to MFLens once per machine (browser sign-in), for the MFLens MCP tools and the cobol-logic-extractor scripts. Optional argument - an MU folder whose tools.yaml gives the sign-in values.
argument-hint: "[mu/<MU>]"
disable-model-invocation: true
---

# Sign in to MFLens

    A="${CLAUDE_PLUGIN_ROOT}/skills/cobol-logic-extractor/scripts/mflens_mcp_auth.py"
    T="${CLAUDE_PLUGIN_ROOT}/scripts/tools_config.py"

1. **Sign-in values**: `python $T <folder> mflens auth.cognito_host`, `auth.client_id` and
   `auth.token_cache`, where `<folder>` is the `<mu>` argument, or `${CLAUDE_PLUGIN_ROOT}/templates`
   (the shared MFLens) without one or when that MU's `tools.yaml` has no `auth` block.
2. **Already signed in?** `python $A headers` with `MFLENS_MCP_AUTH_CACHE` set to the token
   cache. It prints an `Authorization` header: say so and stop.
3. **Sign in.** Tell the user a browser window opens and to complete the sign-in there, then
   run, with the same `MFLENS_MCP_AUTH_CACHE` and a 10-minute timeout:

       python $A login --cognito-host <cognito_host> --client-id <client_id>

   It waits for the browser on `http://localhost:8765/callback`. Never enter credentials for
   the user. On failure, show its message.
4. **Check** with `python $A headers` again, then tell the user to run `/mcp` and reconnect
   `mflens` (or restart Claude Code) so the MCP tools pick up the token.

The token is refreshed silently for 30 days; after that, run this again.
