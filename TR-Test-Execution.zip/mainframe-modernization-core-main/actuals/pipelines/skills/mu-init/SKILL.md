---
name: mu-init
description: Creates a new Migration Unit work folder (mu.yaml, tools.yaml, inputs/) in the current workspace, and the workspace files it lacks (CLAUDE.md, .gitignore, solution/).
argument-hint: "mu/<MU>"
disable-model-invocation: true
---

# Create one Migration Unit work folder

`<mu>` is the argument, normally `mu/<MU>`, relative to the workspace root: the current
folder. `<MU>` is its last path part. Templates are in
`${CLAUDE_PLUGIN_ROOT}/templates/` (`W` below is its `workspace/`). Creates files only; never
overwrites one.

1. **Stop** if `<mu>/mu.yaml` already exists: say so, change nothing.
2. **Workspace files**, each only when missing:
   - `CLAUDE.md` from `W/CLAUDE.md`, `.gitignore` from `W/.gitignore`;
   - `solution/` as an empty folder.
3. **The MU folder**: copy `W/mu/` to `<mu>/` (with the `.gitkeep` files) and
   `${CLAUDE_PLUGIN_ROOT}/templates/tools.yaml` to `<mu>/tools.yaml`. Then fill in:
   - `mu.yaml` `name`: `<MU>`;
   - `tools.yaml` `parity-tester.start` / `stop`: keep `start.bat` / `stop.bat` on Windows; on macOS
     `start.sh` / `stop.sh`; on any other platform, the start and stop scripts `tools/parity-tester/`
     has for it, if it has any.
   Remove the `#` header comment lines of `tools.yaml` that say to copy it.
4. **Check** with `python ${CLAUDE_PLUGIN_ROOT}/scripts/tools_config.py <mu> mflens url`: an
   error naming PyYAML means the user installs it (`python -m pip install pyyaml`).
5. **Report**, short:
   - what was created and what already existed;
   - when `.claude/settings.json` has no `pipelines@mainframe-modernization`: the plugin is
     installed for this user only. To share it with the team, copy `W/.claude/settings.json`
     into the workspace, after the user removes their own install
     (`claude plugin uninstall pipelines@mainframe-modernization`, then
     `claude plugin marketplace remove mainframe-modernization`). Never write or edit that file yourself;
   - every `<...>` value left, file and key (`grep -n '<[^>]*>' <mu>/mu.yaml <mu>/inputs/target-state.md`
     and `<mu>/tools.yaml`), and what goes there: `entry_points`, `portfolio_id`, `description`,
     `du`; `boundaries` when this MU calls other MUs' entry points; the target stack facts and SME notes; DDL into `inputs/db-schema/`; neighbor
     MUs' `<name>.usage.md` into `inputs/deps/`; COBOL into `inputs/cobol/` (optional);
   - whether `tools/parity-tester/` exists; if not: download that folder from the repository
     (`actuals/tools/parity-tester`, GitLab "Download this directory") and unzip it there, or
     point `parity-tester.home` at where it is;
   - next: `/pipelines:mflens-login <mu>` once per machine, then `/pipelines:mu-design <mu>`.
