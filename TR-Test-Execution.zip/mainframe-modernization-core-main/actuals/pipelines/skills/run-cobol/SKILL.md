---
name: run-cobol
description: >
  Use when a COBOL program's actual behaviour has to be observed rather than reasoned
  about - recording integration cases for a migration, checking what a tree does with
  particular inputs, or re-verifying values a document already claims. Builds the unit
  first - COBOL from the MU's inputs/cobol (extracted from MFLens when not provided),
  missing programs stubbed, driver from parity-tester - creates the tables the cases
  need, then runs each case from its cases file against
  the local parity cobol-runner with its fixture rows in place, and prints what the
  program actually produced. Use for "record these cases", "what does this program return
  for", "do these expected values still hold", or whenever a case would otherwise be
  written from reading the code.
user-invocable: false
---

# Running COBOL and recording what it did

A recorded value is evidence; a value worked out from reading the source is a guess that
looks like evidence, and nothing downstream can tell the two apart. So: run it.

This skill runs a program tree against the local parity stack and reports what came
back. It does not decide whether that is right - it tells you what happened, and the
document you are writing is where the judgement goes.

**Do not read `scripts/run_cobol.py`.** This file documents everything it does and every
option it takes; the source adds nothing but tokens. If something here turns out to be
wrong or missing, that is a defect in this file - say so rather than reading around it.

## What you need

A directory, the *unit*, with three things. In `mu-design` it is `<mu>/unit/<entry>/`,
one per entry point in `mu.yaml`:

    sources/      the COBOL tree, one or more *.CBL
    driver.cbl    the COBOL host that applies inputs and reports views
    cases.json    the cases - the only file you write

`sources/` and `driver.cbl` are built once by `build_unit.py` (below) and after that
**neither is modified**. Neither they nor `<mu>/inputs/cobol/` is read by the agent writing
the design (`mu-design`, hard rule); only a separate testing subagent may read them. They are
freight: they go into the bundle as they are. Modifying a driver breaks comparability -
it decides which fields are visible and how a value is applied, so a case recorded
against an altered one cannot be set beside any other; modifying the sources means
recording something nobody delivered. Reading them is a different objection: the driver
is not the system under study but the rig, and whatever it does that changes a
conclusion belongs in this file or in the script's output, not in a thousand lines of
`DISPLAY` somebody has to grep. If you find yourself needing to look, that is a gap
here - report it.

The `TIR*` runtime stand-ins the generated code calls are the runner's, not the unit's: a
case names a set (`shims`, which defaults to `cagen`) and the runner resolves it, so
"what did it run against" has one answer. `GET /api/shims` lists what may be named.

The stack is the parity-tester's: the COBOL runner and Db2, two containers on this PC.
**Every connection value comes from the MU's `tools.yaml`**, read with `tools_config.py`.
`<mu>` is relative to the workspace root, the folder holding `mu/`:

    T="${CLAUDE_PLUGIN_ROOT}/scripts/tools_config.py"
    S="${CLAUDE_PLUGIN_ROOT}/skills/run-cobol/scripts"
    RUNNER=$(python $T <mu> cobol-runner url)
    export RUN_COBOL_DB2_CONTAINER=$(python $T <mu> db2 container)
    export RUN_COBOL_DB2_DATABASE=$(python $T <mu> db2 database)
    export RUN_COBOL_DB2_HOSTNAME=$(python $T <mu> db2 runner_host)
    export RUN_COBOL_DB2_PORT=$(python $T <mu> db2 port)
    export RUN_COBOL_DB2_USER=$(python $T <mu> db2 user)
    export RUN_COBOL_DB2_PASSWORD=$(python $T <mu> db2 password)
    export RUN_COBOL_DB2_SCHEMA=$(python $T <mu> db2 schema)

| Script setting | From `tools.yaml` | What it is |
|---|---|---|
| `--runner` | `cobol-runner.url` | the runner that builds and runs the tree |
| `RUN_COBOL_DB2_CONTAINER` | `db2.container` | where fixture and verify SQL run, through `docker exec` |
| `RUN_COBOL_DB2_DATABASE` | `db2.database` | the database those statements connect to |
| `RUN_COBOL_DB2_HOSTNAME`, `_PORT` | `db2.runner_host`, `db2.port` | where the runner reaches Db2 |
| `RUN_COBOL_DB2_USER`, `_PASSWORD` | `db2.user`, `db2.password` | the login, for the runner and for the SQL scripts |
| `RUN_COBOL_DB2_SCHEMA` | `db2.schema` | the CURRENT SCHEMA of both connections; empty: the user's own |

Builds and runs go over HTTP; SQL (tables, fixtures, `verify`) goes through the container
CLI, because the App's database API is read-only. So `docker` or `podman` must be on the
`PATH` (or named in `RUN_COBOL_CONTAINER_CLI`) on any platform.

The runner and the SQL scripts connect with these `db2` values, in `db2.schema` (empty:
the user's own). Unset, the defaults equal the parity-tester's `docker-compose.yml`; a
cases file says nothing about `db2`.

The App (`parity-tester.url`), the runner and Db2 are checked at the command's
preflight. The App must work on this MU's units: started with `WORKSPACE_DIR` set to
`parity-tester.env.WORKSPACE_DIR`, and restarted when it serves another MU - its `/health`
answer names the `workspace` it uses. A tool that is down is started with
`<parity-tester.home>/<parity-tester.start>` when `tools.yaml` gives a start script, and
the first start takes several minutes while Db2 builds; otherwise, or if it still does not
answer, the user is asked to start it. A missing database is a thing to fix or to report,
never a reason to write a case without values.

Start: run `<home>/<start>` in the background from `<home>`, in the shell this platform
needs, with `WORKSPACE_DIR` (from `env`) and `PARITY_NONINTERACTIVE=1` set, output to
`<mu>/.tmp/start.log`. Then poll `/health` every 10 s, up to 15 min, until `workspace`
matches. Failure: tail `start.log`. Do not read the parity-tester folder.

## Building a unit

    python $S/build_unit.py <mu> <entry>

Once per entry point, before the first case. It walks the call tree from the entry over
`<mu>/inputs/cobol/`. When that folder holds no COBOL, it first extracts the tree from
MFLens (`mu.yaml` `portfolio_id`) into it, so `inputs/cobol/` is always the one copy.
Then it uploads the members to the parity-tester App, which writes `sources/`,
`driver.cbl` and `schema.yaml` into `<mu>/unit/<entry>/`. The script refuses if the App
works on another folder. An existing unit is left as it is. The walk ignores `mu.yaml`
`boundaries`: the unit is the real tree, so the recordings show the boundaries' real behaviour.

A called program that is not in `inputs/cobol/` - a neighbor's or an absent one - becomes
a **stub**: `<mu>/unit/stubs/<NAME>.CBL` when that file exists (`stub-file`: hand-written,
the most probable behaviour, not walked), else a `.CBL` that returns without changing
anything, so the case still runs. Never put a stub in `inputs/cobol/`: any program there
switches off the MFLens extraction. Each `STUB` or `stub-file` line is a row in `stubs.md` and a question asking the user to provide that
program's COBOL; once provided, the unit is rebuilt and the affected cases re-recorded. A
`STUB` whose reason is an MFLens error is not a missing program - fix MFLens and rebuild.

`TIR*` modules are the runner's shims and are never stubbed. A `NO SHIM` line names one
the runner lacks: a gap in the parity-tester, reported in `report.md` - not a stub and not
a question.

## The tables

The runner's Db2 must hold the tables the cases touch. `<mu>/inputs/db-schema/` is
reference material, not a script: it may be partial, inexact or not executable. Read it
(with MFLens `get_sql_table_structure` where it is silent), write the `CREATE TABLE`
statements the cases need into `<mu>/unit/schema.sql`, and run them:

    python $S/run_cobol.py --sql <mu>/unit/schema.sql

Tables are created **unqualified**, in the connection's current schema (`db2.schema`, else the user's): that is where the
generated COBOL's unqualified SQL finds them, whatever schema the DDL names. End every
statement with `;`. `SQL0601N` (exists) is fine; the last output line counts other
errors. A table that cannot be built from what is known is a question, and the cases that
need it wait.

## The database is shared

It is preloaded with rows in the MU's tables.

- Before the first case: save row counts of the touched tables to `<mu>/.tmp/`.
- Key every row a case writes with a reserved prefix (`ZT…`); scope every `DELETE`/`UPDATE` to it.
- After the last case: run a cleanup script from `<mu>/.tmp/`, check the counts match.

Refused in fixtures and `--sql`: `DELETE`/`UPDATE` without `WHERE` or with
`LIKE '%'`/`1 = 1`, `DROP`, `TRUNCATE`.

## Running the cases

    python $S/run_cobol.py <unit-dir> --runner $RUNNER [--changed] [--markdown] [--check]
    python $S/run_cobol.py <unit-dir> --runner $RUNNER --only <case> --only <case>
    python $S/run_cobol.py <unit-dir> --runner $RUNNER --fields A,B | --all | --no-sql
    python $S/run_cobol.py <unit-dir> --runner $RUNNER --cases <path> --out <dir>
    python $S/run_cobol.py --sql <file>

That is the whole interface. `--cases` defaults to `<unit-dir>/cases.json` and `--out` to
`<unit-dir>/.run-cobol`.

Per case, in order: the fixture SQL, the build-and-run, then the verify queries. One
request each, so no case sees another's export view; the runner caches compiles on
content, so only the first pays for the build - a second case costs a couple of seconds.

Everything the runner returned goes to `<unit-dir>/.run-cobol/<case>.json` - the build
logs, stdout, stderr, coverage, every reported field. The terminal gets a digest. When
something is unexplained, read that file rather than guessing.

What the driver prints, and what therefore reaches a case, is one line per field:

    @OUT <FIELD-NAME> [<value exactly as the program left it>]
    @OUT <FIELD-NAME>(nnn) [...]      one occurrence of a repeating group
    @IN  <name> [...]                 an input it applied
    @ERR <text>                       something it refused

Verbatim, including the trailing blanks of a fixed-width field - which is usually the
point. The digest shows values in brackets for the same reason.

The options that matter:

- `--changed` shows the fields whose value differs between the cases just run. That is
  the shortest honest answer to "which fields carry the outcome", and it is the step
  before choosing a case's `assert` list.
- `--markdown` prints each case as a ready-to-paste block with the values the run
  produced, plus a `Recording` preamble saying what it ran against.
- `--check` compares each case's `expect` block against this run, and fails if a
  recorded value no longer reproduces. This is how a document of recorded cases stays
  true after the sources change.

## The cases file

The whole format, with every key it has:

```json
{
  "unit":    "P7549510",                 // optional; defaults to the directory name
  "program": "P7549510",                 // optional; defaults to unit
  "shims":   ["cagen"],                  // optional; defaults to ["cagen"]
  "db2":     { "hostname": "db2" },      // optional; leave it out in mu-design
  "env":     { "CAGENSHIM_CLOCK": "20240816103000" },   // merged over the defaults

  "cases": [
    {
      "name":    "delete-missing-wip",
      "about":   "DELETE on a WIP number no row carries.",
      "fixture": "fixtures/seed.sql",    // relative to THIS file; runs before the case
      "env":     { },                    // merged over the top-level env, per case
      "inputs":  { "PSMGR-IEF-COMMAND": "DELETE", "RV-WIP-BE-NBR-ID-0036": "09999999999999" },
      "assert":  ["RESPONSE-CODE-S-0044", "PSMGR-ROLLBACK-RQSTED"],
      "verify":  { "ctrl": "select count(*) from REVOL_WIP_DIR_CTRL" },
      "expect":  { "RESPONSE-CODE-S-0044": "1", "PSMGR-ROLLBACK-RQSTED": "R" }
    }
  ]
}
```

Only `cases` and each case's `inputs` are required; `name` defaults to `case-<n>`. The
defaults for the rest are the local stack's and the script reports what it used, so a
cases file normally says nothing about `db2` at all. `CAGENSHIM_CLOCK` and
`GIXSQL_AUTOCOMMIT: "off"` are applied unless you override them.

`inputs` may also be a list of `[field, value]` pairs, which is the only way to set the
same field twice; the order is the order the driver applies them in. A field name may
carry an occurrence: `"DIR-CHRG-TYP-CD-0042(1)"`.

`assert` chooses the fields the digest shows for that case - it is the case's own answer
to "which fields carry the outcome", and `--fields` or `--all` override it on a run.
`verify` holds SELECTs only; anything else is refused. **Its output is the Db2 CLP's**,
not JDBC's: a `DATE` comes back as `MM/DD/YYYY` and a decimal carries the CLP's own
formatting, so a value recorded through a `verify` query is not character-for-character
what an application reading the same column will see. Record what it printed, and say in
the case that it is a CLP rendering. **Whether it can see this run's
writes depends on the driver**, and the script tells you: when a case has `verify` and
the driver ends in `ROLLBACK`, it says so before the first run. Under such a driver a
`verify` reports the fixture state rather than what the program wrote - a count of `0`
means "rolled back", not "nothing was inserted" - and what it is good for is the other
direction, confirming a fixture seeded the rows a case depends on. Take that from the
note; do not go and read the driver.

It is JSON rather than YAML because a value has to be exactly the characters written:
trailing blanks in a fixed-width field are data, `00123` is not 123, and there is no
quoting rule to get wrong. The script writes the runner's `spec.yaml` itself.

**`expect` is written from a run, never by hand.** Take it from `--markdown` output or
from the recorded values in the digest. Hand-filling it and then running `--check`
produces a document that agrees with itself and with nothing else.

**Fixtures.** Nothing is reseeded between cases: a case seeds the rows it depends on and
assumes nothing about what ran before it. `fixture` is a path relative to **the cases
file** - `fixtures/seed.sql` beside `cases.json` - because a fixture belongs with the
case that depends on it, and a path written relative to the unit instead has to climb
out of its own folder and back in by name. End every statement with `;`. It stops at the
first error and the case does not run (`FIXTURE FAILED`): a half-applied fixture is not a
state anything can be recorded against. Scope writes to the case's keys ("The database is
shared"). The unit directory is tried second, so an older cases file still works.

**Pin the clock.** `CAGENSHIM_CLOCK` is fixed by default, which is what makes a
generated identifier deterministic instead of something a case has to tolerate. A value
that still varies between runs is worth a sentence in the case saying why it cannot be
pinned.

## What this cannot tell you

- **Whether a row was written.** The driver reports the export view and never reads the
  database back. `verify` queries are the only way to make a row claim at all, and a
  driver that ends in `ROLLBACK` will show nothing through them - which is an answer,
  and it belongs in the case as a limit rather than being left out.
- **Whether the answer is correct.** The runner has no expected-value anything. It says
  what the program did.
- **Which fields matter.** Every field comes back. `--changed` narrows it; deciding is
  yours.

## Rules

1. A case has run or it does not exist. If it could not run, say which case, what
   failed, and what the obstacle was - never a predicted value, and never an obstacle
   you have not actually hit.
2. Record what the run printed, verbatim, trailing blanks included.
3. One case per outcome. A case that exercises two paths at once records neither.
4. Never read the COBOL to decide what a case should produce. The inputs that reach a path
   come from the extracted logic; where it cannot tell, or a case fails or does not build for
   a reason the output does not explain, a separate subagent may read the COBOL and returns
   only the test facts (`mu-design`, hard rule) - never into the design's context.
5. The connection values the script defaults to are the local stack's, and they are
   defaults of this script, not of the runner - every bundle sends the connection in
   full, so a result always says what it ran against. Record that line with the cases.
