"""Builds the run-cobol unit of one entry point: <mu>/unit/<ENTRY>/ with sources/ and driver.cbl.

    python build_unit.py <mu> <ENTRY>

Walks the call tree from ENTRY over the COBOL in <mu>/inputs/cobol/. When that folder
holds no COBOL, the tree is first extracted from MFLens (portfolio_id from mu.yaml)
into it, so either way inputs/cobol/ is the one copy the units are built from.
A called program that is not there is written as a stub: <mu>/unit/stubs/<NAME>.CBL when
that file exists (hand-written, the most probable behaviour; not walked), else one that
returns without changing anything. The walk ignores mu.yaml boundaries: the unit is the
real tree. TIR runtime modules are the runner's shims and are never stubbed here. The members are zipped and uploaded to the
parity-tester App, which writes sources/, driver.cbl and schema.yaml into the unit.

Prints one line per member - "local", "mflens", "stub-file <caller>" or
"STUB <caller> (<reason>)" - then
"NO SHIM <module> <caller>" for a runtime module the runner lacks, then the App's
warnings. A STUB whose reason is an MFLens error, not "not available", means MFLens
failed - fix that rather than stub.
"""
import io
import json
import sys
import urllib.request
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[2] / 'scripts'))
sys.path.insert(0, str(HERE.parents[1] / 'cobol-logic-extractor' / 'scripts'))
from tools_config import tool  # noqa: E402
from program_tree import targets, is_runtime_module  # noqa: E402
from mfanalyzer_facts import Facts, FactsError  # noqa: E402

STUB = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. {name}.
      * STUB: {name} was not available to this MU.
      * It returns without changing anything.
       PROCEDURE DIVISION.
           GOBACK.
"""
SUFFIXES = ('.CBL', '.COB', '.CPY')


class Members:
    """Member text by name, from inputs/cobol/ - or from MFLens into inputs/cobol/."""

    def __init__(self, mu):
        self.folder = mu / 'inputs' / 'cobol'
        files = self.folder.iterdir() if self.folder.is_dir() else []
        self.local = {f.stem.upper(): f for f in files if f.suffix.upper() in SUFFIXES}
        self.extract = not any(f.suffix.upper() != '.CPY' for f in self.local.values())
        self.mu, self.facts, self.text, self.errors = mu, None, {}, {}

    def _mflens(self):
        if self.facts is None:
            m = tool(self.mu, 'mflens')
            self.facts = Facts(portfolio=str(tool(self.mu, 'mu', 'portfolio_id')),
                               pds=m.get('pds', 'SRC'), cache_dir=Path(m['cache_dir']),
                               url=m['url'], auth='auth' in m)
        return self.facts

    def get(self, name):
        if name not in self.text:
            if name in self.local:
                self.text[name] = ('local', self.local[name].read_bytes())
            elif self.extract:
                try:
                    lines = self._mflens().source(name, 1, 99999)
                except FactsError as exc:
                    lines, self.errors[name] = [], str(exc)
                self.text[name] = None
                if lines:
                    text = ('\n'.join(lines) + '\n').encode('latin-1')
                    self.folder.mkdir(parents=True, exist_ok=True)
                    (self.folder / f'{name}.CBL').write_bytes(text)
                    self.text[name] = ('mflens', text)
            else:
                self.text[name] = None
        return self.text[name]

    def source(self, name, start, end):  # what program_tree.targets() reads
        got = self.get(name)
        return got[1].decode('latin-1').splitlines() if got else []


def shim_names(mu):
    home = Path(tool(mu, 'parity-tester', 'home'))
    shims = home / 'config' / 'cobol-runner' / 'shims' / 'cagen'
    return {f.stem.upper() for f in shims.glob('*.cbl')} if shims.is_dir() else None


def main(mu, entry):
    mu, entry = Path(mu).resolve(), entry.upper()
    if (mu / 'unit' / entry).exists():
        print(f'{entry}: unit exists - delete unit/{entry} to rebuild')
        return 0
    app = tool(mu, 'parity-tester')
    health = json.load(urllib.request.urlopen(app['url'] + app['health'], timeout=10))
    if Path(health.get('workspace', '')).resolve() != (mu / 'unit').resolve():
        sys.exit(f'parity-tester App works on {health.get("workspace")}, not {mu / "unit"}: '
                 f'restart it with WORKSPACE_DIR={mu / "unit"}')

    members, shims = Members(mu), shim_names(mu)
    if not members.get(entry):
        sys.exit(f'{entry}: not in inputs/cobol' + (' nor MFLens' if members.extract else ''))
    found, stubs, no_shim, queue = {}, {}, {}, [entry]
    while queue:
        name = queue.pop(0)
        if name in found:
            continue
        found[name] = members.get(name)
        for target in targets(members, name):
            if target in found or target in stubs or target in no_shim or target in queue:
                continue
            if is_runtime_module(target):
                if shims is not None and target not in shims:
                    no_shim[target] = name
            elif members.get(target):
                queue.append(target)
            else:
                stubs[target] = name

    data = io.BytesIO()
    with zipfile.ZipFile(data, 'w') as z:
        for name, (origin, text) in found.items():
            z.writestr(f'{name}.CBL', text)
            print(f'{name:10} {origin}')
        for name, caller in stubs.items():
            own = mu / 'unit' / 'stubs' / f'{name}.CBL'
            if own.is_file():
                z.writestr(f'{name}.CBL', own.read_bytes())
                print(f'{name:10} stub-file {caller}')
                continue
            z.writestr(f'{name}.CBL', STUB.format(name=name))
            print(f'{name:10} STUB {caller} ({members.errors.get(name, "not available")})')
        for name, path in members.local.items():   # copybooks travel as delivered
            if path.suffix.upper() == '.CPY':
                z.writestr(path.name.upper(), path.read_bytes())
    for name, caller in no_shim.items():
        print(f'NO SHIM {name} {caller}')
    request = urllib.request.Request(f'{app["url"]}/program/upload?name={entry}', data=data.getvalue(),
                                     headers={'Content-Type': 'application/zip'}, method='POST')
    reply = json.load(urllib.request.urlopen(request, timeout=300))
    for warning in reply.get('warnings', []):
        print(f'warning: {warning}')
    return 0


if __name__ == '__main__':
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    sys.exit(main(*sys.argv[1:]))
