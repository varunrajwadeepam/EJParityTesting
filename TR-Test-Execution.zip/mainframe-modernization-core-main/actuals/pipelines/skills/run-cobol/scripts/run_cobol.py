#!/usr/bin/env python3
"""Run a unit's cases against the parity cobol-runner and report what the COBOL did.

    run_cobol.py <unit-dir> [options]

<unit-dir> holds the material the runner needs and the cases to run:

    sources/      the COBOL tree, *.CBL, as delivered
    driver.cbl    the supplied driver
    cases.json    the cases (see --help-cases)

One request per case, each a fresh build-and-run of the same tree; the runner
caches compiles on content, so only the first pays for the build. Per case, in
order: the fixture SQL, the run, the verify queries. Everything the runner
returned is written to <out>/<case>.json - this script prints a digest of it and
never invents a value that is not in there.

Exit code is 0 when every case ran, 1 when one did not, and 1 when --check finds
a recorded value that no longer reproduces.

SKILL.md beside this directory is the documentation, and it is complete: anything
changed here has to be changed there too. Nobody should have to read this file to
use it.
"""

import argparse
import io
import json
import os
import re
import shutil
import subprocess
import sys
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

RUNNER = os.environ.get("RUN_COBOL_RUNNER", "http://localhost:8080")

# The local parity stack, which is what this script is pointed at unless a cases
# file says otherwise. The runner has no database of its own and no defaults for
# one - see lib/spec.js - so the connection is sent in full with every bundle, and
# these are the values the running container is actually wired to. `hostname` is
# resolved FROM the runner container, which is why it is a service name and not
# localhost.
DB2_DEFAULT = {
    "dsn": "TESTDB",
    "database": os.environ.get("RUN_COBOL_DB2_DATABASE", "TESTDB"),
    "hostname": os.environ.get("RUN_COBOL_DB2_HOSTNAME", "db2"),
    "port": os.environ.get("RUN_COBOL_DB2_PORT", "50000"),
    "user": os.environ.get("RUN_COBOL_DB2_USER", "db2inst1"),
    "password": os.environ.get("RUN_COBOL_DB2_PASSWORD", "testenv"),
    "schema": os.environ.get("RUN_COBOL_DB2_SCHEMA", ""),   # empty: the user's own schema
}

# How fixture and verify SQL reaches the same database: through the db2 container's
# own CLI, because this script has no Db2 client. Separate from DB2_DEFAULT on
# purpose - that one is how the RUNNER connects (service name on the compose
# network), this one is how THIS machine does (a container name).
DB2_CONTAINER = os.environ.get("RUN_COBOL_DB2_CONTAINER", "parity-db2")
DB2_DATABASE = os.environ.get("RUN_COBOL_DB2_DATABASE", "TESTDB")


def container_cli():
    """docker or podman, whichever this machine has. `docker` is a shell alias for
    podman on some of them, and an alias is not something subprocess can run."""
    named = os.environ.get("RUN_COBOL_CONTAINER_CLI")
    candidates = [named] if named else ["docker", "podman"]
    for name in candidates:
        found = shutil.which(name)
        if found:
            return found
    sys.exit(f"no container CLI on PATH ({', '.join(candidates)}), and fixture / "
             f"verify SQL goes through the db2 container; run with --no-sql to skip "
             f"both, or set RUN_COBOL_CONTAINER_CLI")

# Fixed by default, and that is the point: a clock reading is the usual reason a
# generated identifier is not reproducible, and a pinned one makes it assertable.
ENV_DEFAULT = {
    "CAGENSHIM_CLOCK": "20240816103000",
    "GIXSQL_AUTOCOMMIT": "off",
}

CASES_HELP = """cases.json - the cases for one unit

JSON rather than YAML so that a value is exactly the characters written: trailing
blanks in a fixed-width field are data, and there is no quoting rule to get wrong.
The script writes the runner's spec.yaml itself.

{
  "unit":    "P7549510",            // optional; defaults to the directory name
  "program": "P7549510",            // optional; defaults to unit
  "shims":   ["cagen"],             // optional; defaults to ["cagen"]
  "db2":     { "hostname": "db2" }, // optional; merged over the local defaults
  "env":     { "CAGENSHIM_CLOCK": "20240816103000" },

  "cases": [
    {
      "name":    "update-existing",
      "about":   "one sentence: which path, and why it matters",
      "fixture": "fixtures/update-existing.sql",   // relative to this cases file
      "env":     { },                              // merged over the top-level env
      "inputs":  { "PSMGR-IEF-COMMAND": "UPDATE", "USER-ID-0034": "GY18" },
      "assert":  ["PSMGR-RESPONSE-CD-0002"],       // the fields this case keeps
      "verify":  { "ctrl": "select count(*) from REVOL_WIP_DIR_CTRL" },
      "expect":  { "PSMGR-RESPONSE-CD-0002": "0" } // written by --markdown, read by --check
    }
  ]
}

inputs may also be a list of [field, value] pairs, which is the only way to set
the same field twice; the order is the order the driver applies them in.

fixture runs before the case, through the db2 container; path relative to this cases
file; every statement ends with `;`; stops at the first error and the case does not run.
Refused: DELETE/UPDATE without WHERE or with LIKE '%' / 1=1, DROP, TRUNCATE (the
database is shared). Nothing is reseeded between cases.

verify is SELECTs run after the case, against the same database. The driver
reports the export view and never reads a row back, so a claim that a row was
written has to be made here or not at all. A driver that ends in ROLLBACK will
show nothing - that is an answer too, and it belongs in the case.
"""


# ---------------------------------------------------------------- cases file

def load_cases(path):
    try:
        cfg = json.loads(path.read_text())
    except json.JSONDecodeError as e:
        sys.exit(f"{path}: {e}")
    if not isinstance(cfg, dict):
        sys.exit(f"{path}: top level must be an object")
    cases = cfg.get("cases")
    if not isinstance(cases, list) or not cases:
        sys.exit(f"{path}: 'cases' must be a non-empty list")
    names = set()
    for i, case in enumerate(cases):
        if not isinstance(case, dict):
            sys.exit(f"{path}: cases[{i}] must be an object")
        name = case.get("name") or f"case-{i + 1}"
        case["name"] = name
        if name in names:
            sys.exit(f"{path}: duplicate case name {name!r}")
        names.add(name)
    return cfg


def input_pairs(raw, where):
    """inputs -> [(field, value)], order preserved."""
    if raw is None:
        return []
    out = []
    if isinstance(raw, dict):
        out = [(k, v) for k, v in raw.items()]
    elif isinstance(raw, list):
        for item in raw:
            if isinstance(item, (list, tuple)) and len(item) == 2:
                out.append((item[0], item[1]))
            elif isinstance(item, dict) and len(item) == 1:
                out.extend(item.items())
            else:
                sys.exit(f"{where}: an input must be [field, value] or a one-key object")
    else:
        sys.exit(f"{where}: inputs must be an object or a list")
    pairs = []
    for field, value in out:
        if not isinstance(field, str):
            sys.exit(f"{where}: input field names must be strings")
        if value is None:
            value = ""
        if not isinstance(value, (str, int, float)):
            sys.exit(f"{where}: input {field} must be a string or a number")
        pairs.append((field, str(value)))
    return pairs


# ---------------------------------------------------------------- the bundle

def yaml_scalar(value):
    text = str(value)
    return '"' + text.replace("\\", "\\\\").replace('"', '\\"') + '"'


def spec_yaml(cfg, case):
    """The single-test spec.yaml for one case. Keys the runner does not know -
    about, fixture, assert, verify, expect - stay on this side."""
    unit = cfg["unit"]
    lines = [
        f"unit:    {yaml_scalar(unit)}",
        f"program: {yaml_scalar(cfg.get('program') or unit)}",
        "shims:   [" + ", ".join(yaml_scalar(s) for s in cfg.get("shims") or ["cagen"]) + "]",
        "",
        "db2:",
    ]
    db2 = {**DB2_DEFAULT, **(cfg.get("db2") or {})}
    for key in ("dsn", "database", "hostname", "port", "user", "password", "schema"):
        if key != "schema" or db2[key]:
            lines.append(f"  {key}: {yaml_scalar(db2[key])}")
    env = {**ENV_DEFAULT, **(cfg.get("env") or {}), **(case.get("env") or {})}
    if env:
        lines += ["", "env:"]
        for key, value in env.items():
            lines.append(f"  {key}: {yaml_scalar(value)}")
    pairs = input_pairs(case.get("inputs"), f"cases[{case['name']}]")
    lines += ["", "inputs:"] if pairs else ["", "inputs: {}"]
    for field, value in pairs:
        lines.append(f"  {yaml_scalar(field)}: {yaml_scalar(value)}")
    return "\n".join(lines) + "\n", db2, env, pairs


def bundle_zip(unit_dir, spec_text):
    sources = unit_dir / "sources"
    driver = unit_dir / "driver.cbl"
    if not sources.is_dir():
        sys.exit(f"{sources}: no sources/ directory")
    if not driver.is_file():
        sys.exit(f"{driver}: no driver.cbl - the driver is supplied with the unit, "
                 f"not written here")
    members = sorted(p for p in sources.rglob("*") if p.is_file())
    if not members:
        sys.exit(f"{sources}: empty")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in members:
            zf.write(path, f"sources/{path.relative_to(sources).as_posix()}")
        zf.write(driver, "driver.cbl")
        zf.writestr("spec.yaml", spec_text)
    return buf.getvalue(), [p.name for p in members]


def post_bundle(runner, payload):
    req = urllib.request.Request(
        runner.rstrip("/") + "/api/run",
        data=payload,
        headers={"Content-Type": "application/zip"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=600) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        return {"ok": False, "error": f"HTTP {e.code}: {e.read().decode()[:2000]}"}
    except urllib.error.URLError as e:
        sys.exit(f"cannot reach the runner at {runner}: {e.reason}\n"
                 f"  it is the parity-cobol-runner container; check `docker ps` "
                 f"and GET {runner}/health")


# ---------------------------------------------------------------- the database

# Message ids the CLP prints: SQLnnnnN is an SQL error and DBnnnnnE a CLP error; W and I
# are warnings and information. DB21034E only says "processed as an SQL statement" and
# always comes with the SQL's own message, so it is not counted twice.
ERROR_ID = re.compile(r"\b(SQL\d{4,5}N|DB2\d{4,5}E)\b")
NOT_AN_ERROR = {"DB21034E"}
# What --sql may meet while creating the tables: the table, or its key, already exists.
ALREADY_THERE = {"SQL0601N", "SQL0624N"}


def sql_errors(text, allowed=()):
    """The error message ids in the CLP's output, in order, less the allowed ones."""
    return [m for m in ERROR_ID.findall(text) if m not in NOT_AN_ERROR and m not in allowed]


def statements(sql):
    """The statements of a script with `--` comments dropped, split on `;`, and
    whether the last one is terminated."""
    body = "\n".join(line.split("--", 1)[0] for line in sql.splitlines())
    return [s.strip() for s in body.split(";") if s.strip()], body.rstrip().endswith(";")


def refuse_script(sql):
    """Why this script may not run against the shared Db2, or None.

    The runner's Db2 is shared and preloaded: the MU's own tables already hold rows
    nobody here created. So a statement that is not scoped to the keys it means is
    never sent, and neither is one that removes a table.
    """
    stmts, terminated = statements(sql)
    if stmts and not terminated:
        return ("the last statement has no terminating `;` - the CLP would read the "
                "whole file as one statement")
    for s in stmts:
        head = " ".join(s.split())[:80]
        if re.match(r"(DROP|TRUNCATE)\b", s, re.I):
            return f"refused: {head} - DROP and TRUNCATE are never run against the shared Db2"
        if re.match(r"(DELETE|UPDATE)\b", s, re.I):
            if not re.search(r"\bWHERE\b", s, re.I):
                return f"refused: {head} - a DELETE or UPDATE names the keys it touches"
            if re.search(r"\bWHERE\b.*(LIKE\s+'%+'|\b1\s*=\s*1\b)", s, re.I | re.S):
                return f"refused: {head} - a WHERE that matches every row is not a scope"
    return None


def db2_run(sql, quiet, stop=False, allowed=()):
    """Statements through the db2 container's CLI. Returns (ok, output).

    ok is false when the CLP fails or prints an error message not in `allowed`. With
    `stop` the CLP stops at the first failing statement.
    """
    # The same login and schema the runner uses (DB2_DEFAULT), so fixtures and tables land
    # where the COBOL's unqualified SQL looks.
    user, password, schema = DB2_DEFAULT["user"], DB2_DEFAULT["password"], DB2_DEFAULT["schema"]
    script = f"connect to {DB2_DATABASE} user {user} using {password};\n"
    if schema:
        script += f"set schema {schema};\n"
    script += f"{sql}\n"
    # The script goes to a file inside the container and the CLP reads that file:
    # piped stdin puts the CLP in interactive mode, and after `su -` db2inst1 may not
    # open the root-owned /dev/stdin (DB21005E). Bytes, not text, so no host turns
    # the newlines into CRLF. The CONNECT has to be in the script because each `db2`
    # invocation is its own back-end process, and its reply is stripped below.
    path = f"/tmp/run_cobol_{os.getpid()}.sql"
    flags = ("-s" if stop else "-") + (f"txf {path}" if quiet else f"tvf {path}")
    inner = (f"cat > {path} && chmod 644 {path} && su - db2inst1 -c 'db2 {flags}'; "
             f"rc=$?; rm -f {path}; exit $rc")
    try:
        proc = subprocess.run(
            [container_cli(), "exec", "-i", DB2_CONTAINER, "sh", "-c", inner],
            input=script.encode("utf-8"), capture_output=True, timeout=300,
        )
    except subprocess.TimeoutExpired:
        return False, "timed out after 300s"
    output = (proc.stdout + proc.stderr).decode("utf-8", errors="replace")
    text = strip_connect_reply(output).strip()
    # db2's CLI: 0 ok, 1 no rows selected, 2 warning, >=4 an error. The return code is
    # not enough on its own: a file the CLP cannot parse ends in DB21007E and a low rc.
    return proc.returncode < 4 and not sql_errors(output, allowed), text


def strip_connect_reply(text):
    """Drop the CONNECT statement's own output, so what comes back is the SQL's.
    Left in place if the connect failed - then it is the whole answer."""
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if "Local database alias" in line:
            rest = lines[i + 1:]
            # SET SCHEMA answers DB20000I too; it is not the SQL's output.
            if DB2_DEFAULT["schema"]:
                j = next((k for k, l in enumerate(rest) if "DB20000I" in l), None)
                if j is not None:
                    rest = rest[j + 1:]
            return "\n".join(rest)
    return text


def run_fixture(bases, case, quiet=True):
    """Apply this case's fixture script.

    `fixture` is relative to the cases file - a fixture belongs with the case that
    depends on it, and writing it relative to the unit instead produces paths that
    climb out of the design folder and back in by name. The unit directory is tried
    second, so a cases file written the old way still works.
    """
    rel = case.get("fixture")
    if not rel:
        return None
    path = next((base / rel for base in bases if (base / rel).is_file()), None)
    if path is None:
        return {"file": rel, "ok": False,
                "output": "no such file, relative to " +
                          " or ".join(str(base) for base in bases)}
    sql = path.read_text(encoding="utf-8")
    refused = refuse_script(sql)
    if refused:
        return {"file": rel, "ok": False, "output": refused}
    ok, text = db2_run(sql, quiet=quiet, stop=True)
    return {"file": rel, "ok": ok, "output": text}


def driver_rolls_back(unit_dir):
    """True when the supplied driver ends its run with ROLLBACK.

    It decides what a `verify` query can possibly show: after a rollback the rows the
    program inserted are gone, so a count comes back at its fixture value whether the
    insert happened or not. Worth saying out loud, because `0` then looks like
    evidence that nothing was written.
    """
    driver = unit_dir / "driver.cbl"
    if not driver.is_file():
        return False
    for raw in driver.read_text(errors="replace").splitlines():
        body = raw[6:72] if len(raw) > 6 else ""
        if body[0:1] in ("*", "/"):
            continue
        if "ROLLBACK" in body.upper() and "PSMGR-ROLLBACK" not in body.upper():
            return True
    return False


def run_verify(case):
    queries = case.get("verify") or {}
    if not isinstance(queries, dict):
        sys.exit(f"cases[{case['name']}]: verify must be an object of label -> SELECT")
    out = {}
    for label, sql in queries.items():
        sql = sql.strip().rstrip(";")
        if not sql.lower().startswith(("select", "with", "values")):
            sys.exit(f"cases[{case['name']}]: verify.{label} must be a SELECT")
        ok, text = db2_run(sql + ";", quiet=True)
        out[label] = {"ok": ok, "rows": [l.rstrip() for l in text.splitlines() if l.strip()]}
    return out


# ---------------------------------------------------------------- reporting

def key_of(entry):
    field = entry.get("field") or "?"
    occ = entry.get("occurrence")
    return f"{field}({occ})" if occ else field


def outputs_map(result):
    """field -> value, in report order. A later line wins, which only happens
    when a driver reports a field twice."""
    out = {}
    for entry in result.get("outputs") or []:
        out[key_of(entry)] = entry.get("value", "")
    return out


def pick_fields(case, recorded, explicit, show_all, varying):
    if explicit:
        return explicit
    if show_all:
        return list(recorded)
    # --changed before the case's own assert list: it is asked for when the
    # question is which fields carry the outcome at all, which is the step before
    # choosing them.
    if varying is not None:
        return varying
    asserted = case.get("assert")
    if asserted:
        return list(asserted)
    return list(recorded)


def varying_fields(runs):
    """The fields whose value is not the same in every case of this run. With one
    case there is nothing to compare, so None - and the caller shows everything."""
    maps = [r["recorded"] for r in runs if r["recorded"]]
    if len(maps) < 2:
        return None
    fields = []
    for field in maps[0]:
        values = {m.get(field) for m in maps}
        if len(values) > 1:
            fields.append(field)
    return fields


def print_run(run, fields, out_dir):
    name = run["case"]["name"]
    result = run["result"]
    status = "ok" if run["ok"] else "FAILED"
    print(f"\n## {name}  [{status}]")

    fixture = run.get("fixture")
    if fixture:
        mark = "" if fixture["ok"] else "  FIXTURE FAILED"
        print(f"fixture: {fixture['file']}{mark}")
        if not fixture["ok"]:
            print(indent(fixture["output"]))

    if result.get("error"):
        print(f"runner error: {result['error']}")
    for err in result.get("specErrors") or []:
        print(f"  spec: {err}")
    for err in result.get("driverErrors") or []:
        print(f"  @ERR {err}")

    recorded = run["recorded"]
    if recorded:
        print(f"outputs: {len(recorded)} fields reported, showing {len(fields)}")
        width = max((len(f) for f in fields), default=0)
        for field in fields:
            if field in recorded:
                print(f"  {field:<{width}}  [{recorded[field]}]")
            else:
                print(f"  {field:<{width}}  -- NOT REPORTED by the driver")
    else:
        print("outputs: none - the driver reported no fields")
        run_info = result.get("run") or {}
        if run_info.get("stderr"):
            print(indent(run_info["stderr"][-1500:]))

    for label, got in (run.get("verify") or {}).items():
        head = f"verify {label}:" if got["ok"] else f"verify {label}: FAILED"
        print(f"  {head} " + (" | ".join(got["rows"][:8]) or "(no rows)"))

    print(f"full result: {out_dir / (name + '.json')}")


def indent(text, prefix="    "):
    return "\n".join(prefix + line for line in text.splitlines())


def print_check(runs):
    """Compare each case's recorded `expect` against what this run produced."""
    bad = 0
    print("\n# check")
    for run in runs:
        case, recorded = run["case"], run["recorded"]
        expect = case.get("expect") or {}
        if not expect:
            print(f"  {case['name']}: no expect block - nothing recorded to check")
            continue
        diffs = [(f, v, recorded.get(f)) for f, v in expect.items() if recorded.get(f) != v]
        if not diffs:
            print(f"  {case['name']}: {len(expect)} field(s) reproduce")
            continue
        bad += 1
        print(f"  {case['name']}: {len(diffs)} of {len(expect)} do NOT reproduce")
        for field, want, got in diffs:
            shown = "NOT REPORTED" if got is None else f"[{got}]"
            print(f"    {field}\n      recorded [{want}]\n      now      {shown}")
    return bad


def print_markdown(runs, fields_for):
    """The cases as Markdown, values from this run.

    No preamble about the runner, the database or the clock: the values are the
    evidence, how they were collected is not the subject, and a recorded connection
    string is stale the moment the stack moves. What a case depends on - a pinned
    clock - is part of that case.
    """
    print("\n" + "=" * 70)
    print("# markdown - paste into tests.md, then write the prose lines")
    print("# every value below is what the run printed; a case whose values were not")
    print("# recorded does not belong in that file")
    for run in runs:
        case = run["case"]
        if not run["ok"]:
            print(f"\n## {case['name']}\n\nNOT RECORDED - the run failed. "
                  f"Fix the case or remove it; do not predict the values.")
            continue
        recorded, fields = run["recorded"], fields_for(run)
        print(f"\n## {case['name']}\n")
        print(case.get("about") or "<one or two sentences: which path this exercises, "
                                   "and why that path matters>")
        print(f"\nFixture: {case.get('fixture') or 'none'}")
        print("\nInputs:")
        for field, value in input_pairs(case.get("inputs"), case["name"]):
            print(f"  {field}: \"{value}\"")
        print("\nExpected Outputs:")
        for field in fields:
            if field in recorded:
                print(f"  {field}: \"{recorded[field]}\"")
        extra = len(recorded) - len([f for f in fields if f in recorded])
        print(f"\nNot asserted: the other {extra} fields the driver reported "
              f"<and why they do not carry this outcome>")
        print("Does not verify: <what a reader might assume this case proves, "
              "and it does not>")


# ---------------------------------------------------------------- main

def main():
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("unit_dir", nargs="?", help="directory with sources/, driver.cbl, cases.json")
    ap.add_argument("--cases", help="the cases file (default <unit-dir>/cases.json)")
    ap.add_argument("--only", action="append", default=[], metavar="NAME",
                    help="run just this case; repeatable")
    ap.add_argument("--fields", help="comma-separated fields to show, overriding assert")
    ap.add_argument("--all", action="store_true", help="show every field the driver reported")
    ap.add_argument("--changed", action="store_true",
                    help="show the fields whose value differs between the cases run")
    ap.add_argument("--markdown", action="store_true",
                    help="also emit the tests.md blocks with the recorded values")
    ap.add_argument("--check", action="store_true",
                    help="compare each case's expect block against this run")
    ap.add_argument("--no-sql", action="store_true",
                    help="skip fixture and verify SQL (the runs still happen)")
    ap.add_argument("--out", help="where the full results go (default <unit-dir>/.run-cobol)")
    ap.add_argument("--runner", default=RUNNER, help=f"runner base URL (default {RUNNER})")
    ap.add_argument("--help-cases", action="store_true", help="print the cases.json format")
    ap.add_argument("--sql", metavar="FILE",
                    help="run this SQL file in the db2 container and stop; no unit needed")
    args = ap.parse_args()

    if args.help_cases:
        print(CASES_HELP)
        return 0
    if args.sql:
        # Statement errors do not stop the file: an existing table answers SQL0601N
        # and the next statement runs. The last line says which ones failed.
        sql = Path(args.sql).read_text(encoding="utf-8")
        refused = refuse_script(sql)
        if refused:
            sys.exit(f"{args.sql}: {refused}")
        ok, output = db2_run(sql, quiet=False, allowed=ALREADY_THERE)
        print(output)
        errors = sql_errors(output, ALREADY_THERE)
        print(f"\n{args.sql}: " + (f"{len(errors)} error(s): {', '.join(errors)}"
                                   if errors else "no errors"))
        return 0 if ok else 1
    if not args.unit_dir:
        ap.error("unit_dir is required")

    unit_dir = Path(args.unit_dir).resolve()
    if not unit_dir.is_dir():
        sys.exit(f"{unit_dir}: not a directory")
    cases_path = Path(args.cases).resolve() if args.cases else unit_dir / "cases.json"
    if not cases_path.is_file():
        sys.exit(f"{cases_path}: no cases file - see --help-cases for its shape")

    cfg = load_cases(cases_path)
    cfg.setdefault("unit", unit_dir.name)
    cases = cfg["cases"]
    if args.only:
        wanted = set(args.only)
        unknown = wanted - {c["name"] for c in cases}
        if unknown:
            sys.exit(f"no such case: {', '.join(sorted(unknown))}")
        cases = [c for c in cases if c["name"] in wanted]

    out_dir = Path(args.out).resolve() if args.out else unit_dir / ".run-cobol"
    out_dir.mkdir(parents=True, exist_ok=True)

    if (not args.no_sql and any(c.get("verify") for c in cases)
            and driver_rolls_back(unit_dir)):
        print("note: driver.cbl ends in ROLLBACK, so a verify query cannot see what "
              "this run wrote - it reports the fixture state. Use verify to check the "
              "rows a fixture seeded, not the rows a case produced.", file=sys.stderr)

    # Where a case's `fixture` path is resolved from: beside the cases file first,
    # then the unit.
    fixture_bases = [cases_path.parent, unit_dir]

    runs = []
    for case in cases:
        spec_text, _, _, _ = spec_yaml(cfg, case)
        payload, _ = bundle_zip(unit_dir, spec_text)
        print(f"running {case['name']} ...", file=sys.stderr)

        fixture = None if args.no_sql else run_fixture(fixture_bases, case)
        if fixture and not fixture["ok"]:
            # A half-applied fixture is not a state anything can be recorded
            # against, so the case does not run.
            runs.append({"case": case, "fixture": fixture, "result": {},
                         "recorded": {}, "verify": {}, "ok": False})
            continue

        result = post_bundle(args.runner, payload)
        verify = {} if args.no_sql else run_verify(case)
        recorded = outputs_map(result)
        runs.append({
            "case": case, "fixture": fixture, "result": result,
            "recorded": recorded, "verify": verify,
            "ok": bool(result.get("ok")) and bool(recorded),
        })
        (out_dir / f"{case['name']}.json").write_text(json.dumps({
            "case": case, "spec": spec_text, "fixture": fixture,
            "verify": verify, "result": result,
        }, indent=2))

    varying = varying_fields(runs) if args.changed else None
    explicit = [f.strip() for f in args.fields.split(",")] if args.fields else None

    def fields_for(run):
        return pick_fields(run["case"], run["recorded"], explicit, args.all, varying)

    print(f"# {cfg['unit']}: {len(runs)} case(s) against {args.runner}")
    for run in runs:
        print_run(run, fields_for(run), out_dir)

    failed = [r["case"]["name"] for r in runs if not r["ok"]]
    bad_checks = print_check(runs) if args.check else 0
    if args.markdown:
        print_markdown(runs, fields_for)

    print(f"\n{len(runs) - len(failed)}/{len(runs)} ran" +
          (f"; failed: {', '.join(failed)}" if failed else ""))
    return 1 if failed or bad_checks else 0


if __name__ == "__main__":
    sys.exit(main())
