---
name: mflens-mcp
description: "How to discover and call the MFLens MCP server in mu-design - direct calls from the tool list (ToolSearch only when deferred), the portfolioId from the MU's mu.yaml, what the design may and may not take from MFLens, sourceEvidence citation format, tool selection by need, paging and truncation, and what to do when MFLens is unreachable. Read before making any MFLens MCP call."
user-invocable: false
---

# MFLens MCP in mu-design

MFLens serves the results of static code analysis already performed on the estate. The
`cobol-logic-extractor` scripts read it over HTTP to produce `<mu>/extracted-logic/`; this skill is for
the agent's **own** MCP calls.

## What MFLens is for here

The design is built from the extracted-logic documents, and that restriction is the point: it
proves they are sufficient. So use MFLens directly only for what the extracted-logic documents
do not carry:

- **discovery** - whether a called program is in this MU's portfolio (module
  classification: internal or not);
- **the call graph**, when a script's result needs checking;
- **table structure** - columns, types, keys - for writing case fixtures.

**Never take a business rule from MFLens.** Not from a summary, a PRD, a paragraph detail
or source code. A rule comes from an extracted-logic document, with its provenance; if the
extracted-logic document does not show it, that is a question, not an MFLens lookup.

**Hard rule: no tool that returns COBOL source in the design's context** -
`get_program_source_code`, `search_code`, `search_code_portfolio`,
`get_program_paragraph_details`, `get_program_export`. Only a separate testing subagent may
call them (`mu-design`, hard rule).

## Discovering and calling MFLens

1. MFLens tools come from this plugin's `mflens` server and are named
   `mcp__plugin_pipelines_mflens__<tool>` (`mcp__mflens__<tool>` when a project `.mcp.json`
   defines the server instead). When they are in your tool list, **call them directly**. When they are
   deferred and `ToolSearch` is available, discover them with `ToolSearch` query
   `mflens`, then `select:<tool_name>` before calling.
2. **The portfolio ID is `mu.yaml` `portfolio_id`**, the only source for every call:
   `python ${CLAUDE_PLUGIN_ROOT}/scripts/tools_config.py <mu> mu portfolio_id`. MFLens tools
   take that numeric `portfolioId`, not a portfolio name. Never search for another one;
   an entry point MFLens does not find there is a hard block. When the PDS is omitted,
   program tools resolve it where possible and otherwise fall back to `SRC`.
3. The MCP endpoint is the `url` in `${CLAUDE_PLUGIN_ROOT}/.mcp.json`; it must be
   `<mflens.url>/api/mcp` from `tools.yaml`. If they differ, the agent and the scripts are
   reading two servers - a hard block: the user corrects `tools.yaml`.
   Not signed in (the server or a script reports it) is a hard block too: the user runs
   `/pipelines:mflens-login <mu>`.
4. Attribute MFLens-derived facts to MFLens. For structured evidence use
   `sourceEvidence: "MFLens:<program>"`; for a human-readable citation include a line
   range when the response provides one, e.g. `MFLens:<PROGRAM>@Lstart-Lend`. Never invent
   line numbers.
5. **Unreachable is a conclusion drawn after trying**, never instead of it: check your
   tool list for `mcp__*mflens__*`, attempt `ToolSearch` discovery if none is listed, and
   treat MFLens as unavailable only when no tool is callable or the call fails at the
   transport or server level. A portfolio-disambiguation response is not a failure. Then:
   - if `<mu>/extracted-logic/` is complete, continue - nothing the rules need is lost - and
     record which checks could not be made;
   - if a step cannot be done without MFLens (extracting, classifying modules), that step
     is blocked: say so, name what was tried, and do not substitute anything for it.

## MFLens tools by need

Call each by its full name from point 1, e.g. `mcp__plugin_pipelines_mflens__<name>`. All are read-only.

| Need | MFLens tools |
|------|--------------|
| Portfolio discovery, inventory & overview | `search_program`, `search_component`, `get_portfolio_overview`, `get_portfolio_assets`, `get_portfolio_files` |
| Program purpose & requirements | `get_program_summary`, `get_program_prd` |
| Program structure & control flow | `get_program_paragraphs`, `get_program_dead_paragraphs`, `get_control_flow_graph` |
| Program and portfolio call graph | `get_portfolio_call_chain`, `get_portfolio_call_chain_statistics`, `find_portfolio_call_paths`, `get_program_deep_call_chain` |
| JCL search | `search_jcl_source` |
| SQL tables, statements & usage | `get_portfolio_sql_tables`, `get_program_sql_statements`, `get_sql_table_structure`, `get_sql_table_usage` |
| SQL table and column lineage | `get_table_lineage`, `get_table_column_usage` |
| Program outputs and data lineage | `get_program_outputs`, `list_lineage_targets`, `list_lineage_sources`, `trace_target_lineage`, `get_lineage_summary`, `get_field_lineage`, `trace_field_lineage`, `trace_output_structure` |
| Data structures (layouts and PIC clauses) | `list_data_structures`, `get_data_structure_details` |
| CICS, MQ, IBM i and IMS | `get_cics_usage`, `get_cics_usage_portfolio`, `get_cics_transactions`, `get_mq_usage_program`, `get_mq_usage_portfolio`, `get_ibmi_usage`, `get_ibmi_usage_portfolio`, `get_portfolio_ims_segments`, `get_ims_usage`, `get_ims_databases` |
| JCL jobs, execution, file lineage & data-structure mapping | `list_portfolio_jcl_jobs`, `get_jcl_job_execution_details`, `get_jcl_job_io`, `get_jcl_bottom_up_file_analysis`, `map_jcl_job_files_to_cobol_data_structures` |
| Complexity, capabilities & modernization | `get_complex_programs`, `get_business_capabilities`, `get_programs_by_capabilities`, `analyze_migration_impact`, `recommend_modernization_start` |
| COBOL IBM-to-ISO conversion guidance | `cobol_ibm_to_iso` |

The tools `update_program_summary`, `update_program_prd_documentation` and
`update_program_classification` change MFLens. **Never call them.**

The five source-returning tools of the hard rule above - `get_program_source_code`,
`search_code`, `search_code_portfolio`, `get_program_paragraph_details`,
`get_program_export` - are absent from this table deliberately. Only `mu-design`'s
separate testing subagent may call them, and it is briefed there.

**Choosing within a row** (tool descriptions give parameters and detailed usage):
- Existence of a called program: `search_program` in this portfolio.
- Call graph: one program → `get_program_deep_call_chain`; whole portfolio →
  `get_portfolio_call_chain_statistics`, then page through `get_portfolio_call_chain`;
  filtered or deep paths → `find_portfolio_call_paths`.
- Fixtures: `get_sql_table_structure` for columns and keys; `get_sql_table_usage` for
  which programs touch a table.

**Interpret results carefully.** `hasNext: true` or `hasMore: true` means more results must be
read; a returned `cursor` is a continuation token to pass on the next call; use `totalPages` to
fetch every page. For page-based tools, keep the original portfolio, program, and filter
arguments unchanged and increment the zero-based `page`. `get_complex_programs` instead uses
`offset` and `limit`; advance `offset` by `limit` and respect its maximum limit of 100. For
cursor-based lineage tools, pass the returned cursor unchanged as `cursor` and keep the original
program scope, anchor, direction, and `includeInternal` value unchanged. Continue until the
response indicates there is no next page/cursor or the last `totalPages` page has been read.

`truncated: true` means results were cut to fit the response token budget or a tool-specific
result cap, so the result is incomplete. Where supported, increase `maxTokens` or
`maxResultsPerProgram`; otherwise narrow or split the query. Keep all other filters stable
while recovering the omitted results. Do not conclude something is absent until all pages are
read and any truncation is resolved. `get_table_lineage` is based on statically parsed SQL and
does not resolve dynamic SQL; `get_table_column_usage` also reports programs whose column usage
is unknown, which must not be described as not using the column.
