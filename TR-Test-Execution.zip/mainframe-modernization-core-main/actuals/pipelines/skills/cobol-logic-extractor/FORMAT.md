# `<PROGRAM>.md` extracted-logic format specification

Audience: an agent reading the extracted logic of a CA Gen COBOL program. This document defines what
the format states, what it omits, and what you may not infer from an omission.

Produced by `scripts/extract_logic.py <PROGRAM>`, from the MF Analyzer source and
declarations. Regenerate rather than edit.

## Guarantees

1. Every statement shown is present in the member with its text unchanged; only the
   leading padding and anything past column 72 - the program-identification area the
   compiler ignores - are removed. A statement that wraps across lines in the member still
   wraps here. Statement-terminating periods sit on their own lines in generated code
   and are reproduced as they are, which is why a lone `.` sometimes appears.
2. Every `## Paragraph NAME (first-last)` range is a real line range in the member.
   Use it to fetch the original when this document is not enough.
3. Every line beginning `*> @` is **not** source. It is a marker inserted by the
   logic extractor, always at column 0.
4. No statement has been reordered, rewritten, or merged with another, except where a
   marker explicitly replaces a construct listed below.
5. The document is not valid COBOL and must not be compiled or parity-tested.
6. Where `--index` was passed, the index entry for this program states the same
   paragraphs with the same ranges. It is built from the same split the headings come
   from, so the two cannot disagree. See **The paragraph index** below.

## Sections, in order

| Section | Contents |
|---|---|
| `## Inputs` | The program's **filtered** contract inbound: fields something at or below this program actually reads. Includes fields of the shared control block. |
| `## Outputs` | The filtered contract outbound: fields something actually populates. |
| `## Dropped from the contract` | Parameter-view fields the statements name that the filter left out, with the type, the direction and the reason. Present only when there are any. A name met in a paragraph and found in this table is a **view field** - it arrives from the caller or leaves for it - whose value goes no further; it is not an undeclared local and it is not always zero. |
| `## Locals and constants` | Declarations outside the parameter views, restricted to names that still appear in the paragraphs. `Value` is the `VALUE` clause where one exists. |
| `## Initializers` | Each group the code clears, and the fields that clearing blanks. |
| `## Response states` | Every exit state the program declares, with the model's numeric code and its `Role`: `emitted` means the program reports it, `compared` means the program only tests for it - a result a callee produced. A program typically emits one and compares several. |
| `## Linkage` | The `PROCEDURE DIVISION USING` statement. |
| `## Paragraph …` | One section per paragraph, in source order. |

`Inputs` and `Outputs` are the filtered contract computed by `scripts/analyze_view_usage.py`
in this skill, which is why a field declared in a parameter view can be absent from them:
nothing reads it, or nothing populates it. Four groups of fields are excluded
unconditionally - the failure flags from `Inputs`, since every read of them is the
generated post-call check acting on a value the program itself produced; the diagnostic
fields `LAST-STATEMENT-NUM`, `CUR-AB-ID`, `CUR-AB-NAME` and `ACTION-ID` from `Outputs`,
since nothing in the batch reads them; the runtime date and time registers; and
`RV-SERVER-DATE`, which holds a clock reading rather than a value a caller decides.

`RV-SERVER-DATE` is the one exclusion whose field still does work in the code: the entry
program sets it from the date module and business rules then compare against it. It is
excluded because the value is the transaction's processing date, which a target platform
supplies - what has to be preserved is that the date is fixed once per transaction, not
the field. See *Behaviours to keep in mind* below. Read the statements, not the tables, for it.

A fifth restriction is about this program rather than about the field: a contract field
whose name appears nowhere in this program's own procedure division is in neither table.
The filtered contract is computed over the whole call tree, so a field can belong to it
because something several programs below reads it while this program never touches the
field itself - it forwards the view the field sits in. This document is about this
program, so those are dropped, and because the same test decides it they are absent from
`## Dropped from the contract` as well, which carries only fields the statements name.
The two tables therefore stay consistent with each other and with the paragraphs: every
name you meet below is in one of them. What is lost is reading `Inputs` as the whole
tree's input set - for a program that forwards a view at group level rather than field by
field it is shorter than its callees' tables put together. `*> @call` is what says what
actually crosses the boundary, and `analyze_view_usage.py --root <program>` is what
reports the tree.

Beyond those five, nothing is left out. In particular an input is **not** judged by whether a path
through the program reaches a decision with the caller's value intact: that test is
unsound. Measured over nine programs it removes eleven fields and is wrong about at
least nine of them - including every field `F7549T02`'s only decision reads, which
leaves that program's `Inputs` empty. An empty or short table is the one error a reader
cannot catch, so the tables err towards listing.

A field in a parameter view that the statements name but the tables do not carry is in
`## Dropped from the contract` with the reason, and a field of the shared control block
may be in no table at all - those are the only two ways a name in the body is missing
from above.

A `Repeats` value of `GROUP-X[200]` means the field is one column of a repeating group
holding up to 200 entries, not a single value: it is subscripted everywhere it is used.
`entry count of GROUP-X` marks the field that says how many entries are actually filled;
the rest of the allocation is untouched. An empty `Repeats` is a scalar.

Types are the COBOL picture restated: `char(n)` is a fixed-width, space-padded field of
n bytes; `int(n)` an n-digit zoned decimal; `decimal(p,s)` an implied-point number;
`signed` carries an operational sign; `group` is a record with no picture of its own;
`condition` is a level-88 name.

## Markers

| Marker | Replaced construct | What it asserts |
|---|---|---|
| `*> @validation` | the generated `PARA-*-INIT` paragraph and the `PERFORM` of it | On entry each input was checked and malformed content replaced: text holding binary junk became spaces, numerics holding non-digits became zero. **After this point the program has no concept of an absent input.** The scope is this program's **own import-view fields** and nothing else: not a work copy, not a field of a local entity view, not a field a callee's view received after the caller's own validation ran. So a later `IF … IS NUMERIC` on a work field is **not** made vacuous by this marker - `A7549229` normalises 15 import fields here and then guards 13 entity-view fields that are none of them. Read such a guard as live. |
| `*> @initialize <groups>[, cursor=<n>]` | `INITIALIZE <groups>`, and the move into the group's `...PS` cursor beside it | The groups were cleared to spaces and zeros. These are reused working storage, so a field the program does not set afterwards reaches its callee blank rather than holding a previous value. `cursor=0` means nothing is written yet and the first entry will land at position 1; `cursor=1` means the cursor already points at the first entry. The cursor lives outside the view, in a control block of its own, which is why it can appear on either side of the `INITIALIZE` in the source. |
| `*> @call <program>(<theirs>=<mine>, …) into <mine>=<theirs>, …` | a `CALL` to a generated program, its argument views expanded | Those fields were passed; those fields may have been written by the callee. Each pair reads as the assignment the shared storage performs - `theirs=mine` going in, `mine=theirs` coming back. A field with no `=` could not be paired. Empty brackets mean the callee's inbound view has no fields of its own, not that operands were elided; a missing `into` clause means the same for its outbound view. A call through the loader is resolved to the real target and appears in this form. |
| `*> @function <TIR…>(<inputs>) -> <result>` | a `CALL` to a runtime-library function | Inputs first, result last; a module that works in place reads as though its last operand were an output. What each module does is in **[`tir-cobol`](../tir-cobol/SKILL.md)** - including the four conversion routines that take no runtime parameters, the ones that answer through `GLOBDATA` instead of an operand, and the ones that do nothing at all. |
| `*> @date-add <date> ± <n> <unit> -> <target>` | the `TIRFDDUR` idiom: base date, duration component, missing-flags, call, read-back | Date arithmetic. The number and unit are business content. |
| `*> @fail` | `CALL 'TIRFAIL'` | The program raises a failure here and does not continue. Note what [`tir-cobol`](../tir-cobol/SKILL.md) says about `TIRFAIL` under the parity runner: the stub returns, so a recorded run carries on past a point the original would have abended. |
| `*> @exception-check` | `IF STATUS-FLAG … OR ERROR-ENCOUNTERED-SW … OR VIEW-OVERFLOW-SW … GOBACK END-IF` | If the preceding call failed, the program returns immediately. Treat as `if (failed) return;`. |
| `*> @response …` absent from a paragraph that returns | - | **The envelope keeps whatever was in it.** A terminal paragraph with no `@response` leaves `PSMGR-EXIT-STATE` and the rest holding the value a callee set, or the value an earlier `@response` in the same tree set. Do not assume every exit path reports an outcome of its own. |
| `*> @response state=…, level=…, message='…', rollback=…` | the four assignments that fill the response envelope: `PSMGR-EXIT-STATE`, `PSMGR-EXIT-MSGTYPE`, `PSMGR-EXIT-INFOMSG`, `PSMGR-ROLLBACK-RQSTED` | The outcome the program reports. `level` is `N` none, `I` info, `W` warning, `E` error. `rollback=false` means commit; any other value is the literal the code moves and means rollback was requested. A paragraph that fills only some of the slots - commonly the state alone - shows only those, and the slots it does not name keep whatever was in them. |
| `*> @paragraph <name>` | `PERFORM <name> THRU <name>-EXIT` | Control transfers to that paragraph and returns. Equivalent to a call to a local procedure. Also stands for a `PERFORM <name> THRU` whose operand is missing from the analysed source: a wrapped `THRU` loses its continuation line occasionally, and in generated code the range always ends at `<name>-EXIT`. |
| `*> @copy-array(<bound>) <src>:<dst>, …` | a `PERFORM VARYING` loop whose every statement copies one entry from one view's group to another's | The group was copied entry by entry, for as many entries as `<bound>` says. Every source:target pair is listed. A loop containing anything other than per-entry copies is not folded and appears in full. |
| `*> @escape returns from <p1>, <p2>, …` | a run of `MOVE 'Y' TO <name>-ESC-FLAG` | **An early return, and how far it reaches.** Every paragraph listed returns, innermost first; each is a paragraph that performed the one before it. Control resumes in whatever performed the *last* one listed, so nothing after that paragraph's own `*> @escape-check` runs. A paragraph not listed is unaffected. A raise that lists only the paragraph it sits in returns from that paragraph alone. |
| `*> @escape-check <paragraph>` | `IF <name>-ESC-FLAG = 'Y' GO TO PARA-…-EXIT END-IF` | **Control may stop here.** If an escape naming `<paragraph>` has been requested, that paragraph returns and the statements below do not run. Treat as `if (escaped) return;`. Do not read the statements after it as unconditional. Pair the two markers by paragraph name: an `@escape` that lists a paragraph is stopped by that paragraph's `@escape-check`, and an escape that does not list it passes straight through. |

### The callee's names on a `@call` line are inferred

A `CALL` binds by byte offset, not by name: the callee's declaration is laid over the
caller's storage, and nothing at the boundary compares the two sets of names. The name
shown on the callee's side of each pair is therefore **derived, not read from the call**.
It comes from pairing the argument view's fields with the callee's parameter view in
declaration order - which is how the binding itself works - and is omitted when the two
cannot be paired.

Measured over the batch to establish that the pairing is sound: 2209 call sites between
generated programs, 107111 field pairs. In 99.48% of pairs the two names agree once the
view occurrence number is stripped, confirming that both views come from one model
definition. The 0.52% that differ are the per-group control fields - the entry count,
its alias and the active-entry flag - whose names describe the group's role rather than a
model attribute, so there is no shared attribute name to agree on.

Treat a paired name as reliable for a field that carries data, and verify against the
callee's own document before relying on it for anything else. The sample is large, not
exhaustive: it covers calls where the argument count matched the callee's parameter
count, in member order.

## Dropped without a marker

Each row states what you must **not** conclude from the absence.

A line containing only `.` is a COBOL statement terminator left behind by dropped
statements. It carries no meaning; ignore it.

| Dropped | Reason | Do not conclude |
|---|---|---|
| Everything before `PROCEDURE DIVISION` | declarations; the tables above carry what matters | that a name is undeclared. Check `## Locals and constants` first, then the member. |
| All comments, and the trailing model-definition block | the trailer restates the logic in model language | that the model's wording is unavailable - it is in the member. |
| `COMPUTE LAST-STATEMENT-NUM = <n>` | write-only diagnostic breadcrumb; never read | that statement sequencing is lost. Line numbers serve that purpose. |
| `MOVE '<literal>' TO CUR-AB-ID` / `CUR-AB-NAME` | write-only diagnostics; never read | that the program does not identify itself. It does, for failure reporting only. |
| `MOVE SPACES TO ERROR-ENCOUNTERED-SW` before a call | generated reset of the error flag | that the flag is stale at `*> @exception-check`. It was cleared. |
| the escape reset: `MOVE 'N' TO <name>-ESC-FLAG` | paragraph entry initialisation; the raise and the check are kept as `*> @escape` and `*> @escape-check` | anything. A paragraph with no `*> @escape` does not request an early return and falls through to whatever follows its caller's `*> @escape-check`. |
| `PARA-*-INIT` and `PARA-*-INIT-EXIT` paragraphs | the normalisation block, now `*> @validation` | that inputs are unvalidated. |
| `-EXIT` paragraphs whose body is only `EXIT.` | landing pads for the dropped `GO TO`s | that an `-EXIT` paragraph never exists. One with a real statement is kept. |
| group-view loops of the form `PERFORM VARYING ADIMn FROM 1 BY 1 UNTIL ADIMn > <literal> / COMPUTE ADIMn = <literal> / END-PERFORM` | runs once, moves only the subscript, which is re-initialised before any read: no observable effect | that iteration was removed. Loops bounded by an entry count are kept. |
| a copy from an import view field to an export view field where at least one of the two is absent from `Inputs`/`Outputs` | a pass-through of a field the contract dropped: the program hands back something nothing reads | anything about copies in general. Every other copy is shown - import into a local view being prepared for a call, a callee's answer into an export view, and a pass-through whose two ends the tables both list. A repeating group copied entry by entry appears as `*> @copy-array`. |

## Reading rules

1. `## Inputs` and `## Outputs` are the **declared** contract. They do not say whether a
   field is used beyond this program. `scripts/analyze_view_usage.py --root <program>`
   reports a verdict per field across the whole call tree.
2. A field named in a paragraph but in no table is one of four things, and in every case
   the statement naming it is the authority:
   - **a group, where the tables list its leaves.** `PSMGR-IEF-COMMAND` is 80 bytes
     declared as `PSMGR-IEF-COMMAND-1` `char(8)` plus `PSMGR-IEF-COMMAND-2` `char(72)`;
     writing the group name writes both, left-justified and space-padded, so
     `MOVE 'RETURN' TO PSMGR-IEF-COMMAND` sets part 1 to `RETURN  ` and blanks part 2.
   - **a field of the shared control block that the contract excluded**: `STATUS-FLAG`,
     `ERROR-ENCOUNTERED-SW`, `VIEW-OVERFLOW-SW` (not inputs - see above),
     `LAST-STATEMENT-NUM`, `CUR-AB-ID`, `CUR-AB-NAME`, `ACTION-ID` (not outputs), and
     `PSMGR-EXIT-STATE`, which callees set and this program compares against.
   - **a generated control field**, recognisable by a two-letter suffix after the
     occurrence number: `...XX` a REDEFINES alias over the undecorated name, `...AS` a
     null flag, `...PS` a position counter, `...MA` an entry count, `...DR` a value
     exchanged with something outside the program - a record layout handed to a
     database access module, or a work field holding the result of a runtime
     function. `DURATION-0001DR` is the second kind: a date in eight characters.

     Names are truncated to 30 bytes, and the suffix is kept at the expense of the
     name, so an alias may not string-match the field it aliases:
     `RV-OPTIONS-ENABLE-CORRE-0009XX` is the alias of `RV-OPTIONS-ENABLE-CORRECT-0009`.
     Match on the occurrence number and the leading characters, not on equality.
   - **a parameter-view field the contract dropped** because nothing reads it or nothing
     populates it. `COUNT-0022` and `RV-OPTIONS-EDIT-CORRECT-S-0024` are of this kind:
     the program writes them, and no caller in the analysed tree consumes them. Look it
     up in `## Dropped from the contract`, which carries the type and the reason - the
     exception is a field of the shared control block, which is excluded by decision and
     is in no table at all.

   The full suffix catalogue:

   | Suffix | Meaning |
   |---|---|
   | `AS` | null flag beside an optional attribute, `X(1)` |
   | `AC` | a generated control field, excluded from the tables with the rest of the bookkeeping. What it holds is not established for this portfolio - if one carries a branch, read the statement and say so as a finding |
   | `XX` | `REDEFINES` alias over the field, same byte length |
   | `EV` | entity view |
   | `ET` | entity type group inside a view |
   | `RG` | repeating-group wrapper |
   | `MA` | entry counter of a repeating group - but the **declared maximum** inside an `AT` group, see below |
   | `MX` | `REDEFINES` alias over the counter |
   | `PS` | cursor into a repeating group, held outside the view |
   | `MM` | capacity of a repeating group |
   | `FL` | full flag of a repeating group - but the **current length** inside an `AT` group, see below |
   | `RF` | **group-referenced flag**, `X(1)`: `GROUP-REFD` `'Y'` when the generated code has touched this group's current entry, `DATA-MISSING` `'N'` when the cursor has moved past it. Three shapes and no others, measured over 122 members, 48 of which use it: set to `GROUP-REFD`, tested `= GROUP-REFD`, cleared to `DATA-MISSING`. The test decides whether an entry is counted, so it is a branch rather than bookkeeping - but check whether the assignment sits immediately above it, in which case the branch cannot fail. |
   | `AT` | an operand passed to a runtime module: a group of three fields, `…MA` the declared maximum, `…FL` the current length and `…FP` the value itself. Statements name the parts, so `MOVE X TO TIME-VALUE-0003FP` and `IF OUTPUT-STRING-0001FL = 0` are a value and a length - not a group entry count and not a full flag. The `AT` group is what the `CALL` passes; `*> @function` names the parts. |
   | `FP` | the value field of an `AT` group. `FL` beside it says how much of it is filled, and a runtime function that leaves `FL = 0` is reporting an empty result - which is what callers branch on. |
   | `NF` | **SQL null indicator** paired with a host variable: `0` means the value is present, `-1` that the column was null. Generated code sets it immediately before loading its host variable. A translation that expresses null some other way leaves these inert, and loses the distinction. |
   | `CN` | the same null indicator carried on a view rather than beside the host variable: generated code moves an `NF` into a `CN` when the value crosses a call. `X(4)` binary, same `0` / `-1`. |
   | `ES` | **entity state** of the row an access paragraph worked on: `EV-USABLE` `'OK'` or `EV-UNUSABLE` `'DU'`. This is how a failed read or insert suppresses the work that depends on it - the guard is `IF …ES = EV-UNUSABLE`, several paragraphs later. Not plumbing: dropping it removes a branch. |
   | `CD` | **entity command** the access paragraph performed: `PV-SELECT` `'SL'`, `PV-CREATE` `'CR'`, `PV-UPDATE` `'UP'`, `PV-DELETE` `'DL'`, `PV-SELEACH` `'SE'`, `PV-ASSOCIATE` `'AS'`, `PV-DISASSOCIATE` `'DA'`, `PV-TRANSFER` `'XF'`. Assigned at the top of the paragraph; usually read by nothing. |
   | `LK` | **lock state**: `EVW-UNLOCKED` `'UL'` or `EVW-LOCKED` `'LK'`. Assigned with the `CD`, usually read by nothing. |
   | `EN` / `TP` / `EF` / `CF` / `NT` | host variables and work fields exchanged with SQL or a runtime function |
   | `DR` | a value exchanged with something outside the program - a record layout handed to a database access module, or a work field holding the result of a runtime function |
3. Code blocks carry no line numbers. The `(first-last)` range on the paragraph heading
   is the only positional information; statements within it are in source order but not
   contiguous. A blank line is layout, not a gap.
4. `EX-<name><nnnn>` is an exit state constant. The code always names it; the numbers in
   `## Response states` never appear in the code and are useful only for matching the
   same outcome across two programs, where the name differs but the number does not.
5. A four-digit suffix on a field name is the view occurrence the generator emitted it
   for, not the attribute. `USER-ID-0013` and `USER-ID-0021` are the same model attribute
   in two different views.
6. Zero and spaces are meaningful values, not absences - see *Behaviours to keep in
   mind* before concluding that a field is unset.

## The paragraph index

`extract_logic.py --index PATH` writes, beside the documents, a machine-readable record
of every paragraph. It accumulates: one entry per program, so the MU's extract loop
builds one index for the whole MU, and re-extracting a program replaces its entry and
leaves the rest alone. A corrupt index is reported on stderr and replaced rather than
failing the extract - the document is the deliverable and the index is derived from it.

```json
{"programs": {"CRR14161": {
  "model": "CRR14161_FINBUSINESSEVENT_LIST",
  "business": 1, "mechanism": 1,
  "paragraphs": [
   {"name": "MAIN-0124663746", "lines": [564, 570], "kind": "mechanism",
    "statements": 0, "why": "no statement or business marker",
    "performs": ["PARA-0124663746"]},
   {"name": "PARA-0124663746", "lines": [573, 640], "kind": "business",
    "statements": 27, "functions": ["TIRDAT2"],
    "responses": ["EX-PROCESSING-OK-01-000000001", "EX-AUDIT-TRAIL-IND-21-21020002"]}]}}}
```

| Field | Meaning |
|---|---|
| `lines` | `[first, last]`, the same range as the `## Paragraph` heading |
| `kind` | `business` - carries behaviour, must be traceable. `mechanism` - generated plumbing, exempt |
| `why` | why it was judged mechanism, or judged business on a marker alone |
| `statements` | statements left once markers, lone periods and `GOBACK`/`CONTINUE`/`EXIT` are discounted |
| `sql`, `calls`, `functions`, `responses`, `performs` | SQL verbs, `@call` targets, `@function` modules, `@response` states, `@paragraph` targets. Absent when empty, never `[]` |

**The index holds nothing the documents do not already state.** It exists so that a tool
can read them without parsing Markdown, and so the migration can be checked rather than
attested: `mu-design` checks every `business` paragraph against the `From` cells of
`rules.md` (`${CLAUDE_PLUGIN_ROOT}/scripts/check_rule_coverage.py`), and the architecture skill checks
them against the citations in the code. The records carry names, counts and markers and
never statement text, which is why the index is readable under `mu-design`'s rule that
the COBOL stays out of the design's context.

### How `kind` is decided, and where it errs

Structurally. A paragraph is `business` if it holds a statement, or if it holds a
`@response`, `@fail`, `@call`, `@function`, `@date-add` or `@copy-array` marker. The
remaining markers - `@validation`, `@initialize`, `@exception-check`, `@escape`,
`@escape-check`, `@paragraph` - are plumbing and do not make a paragraph business on
their own. `SUBSTR-ERROR-*` is always mechanism. An `EXEC SQL DECLARE … END-EXEC` counts
as a statement: the DECLARE is where the query text lives, so the table, the columns and
the predicate are all inside it.

Tuned against 910 paragraphs of a 104-program tree classified by hand, which split
715 business / 195 mechanism. Scored against the 898 with a usable hand disposition it
agrees on 685. Of the 213 it does not:

| Direction | Count | What they are |
|---|---:|---|
| calls `business`, reviewer exempted | 197 | cursor `-OPEN`/`-FETCH`/`-CLOSE`/`-MOVEA` families and MAIN shells holding a cursor DECLARE, exempted because one repository method covers the family. Costs one citation each |
| calls `mechanism`, reviewer called behaviour | 16 | every one a paragraph whose whole body is a single `*> @escape` - the escape stub of a skip. The decision that performs it is business and cited, so the behaviour stays reachable |

**The bias towards `business` is deliberate.** A paragraph wrongly called `business` asks
for a citation it did not need. A paragraph wrongly called `mechanism` is dropped from
the check that would have caught it never being migrated. Do not correct it by
reclassifying - exempt the paragraph where a reviewer can see it, in `rules.md`
"Paragraphs that produced no rule" or an `--allow` file.

## Behaviours to keep in mind

These are properties of the generated code that a reader of this document will not see
stated anywhere in it, and that a port can diverge from without failing loudly.

**An unset input arrives as a value, not as an absence.** `*> @validation` replaces
malformed content on entry - binary junk becomes spaces, non-digits become zero - so
after that point the program has no concept of an absent input. "The caller supplied no
effective date" is the number `0`, and business logic compares against it. A port that
models absence as null, or rejects unparseable input at the boundary, never reaches the
branch the original takes.

**The processing date is read once per transaction, not once per component.** The entry
program reads the clock once and the whole call tree works from that one value, stamping
it on rows and comparing against it. A port in which each component asks the platform
for "now" writes two different dates on a run that crosses midnight.

**Failure travels in a status flag, and only generated code checks it.** There are no
exceptions between generated programs: after a call the caller tests three flags and
returns if any is set. Within generated code the convention is absolute. Hand-written
modules - a message-queue interface, a call made through a variable holding a program
name - do not participate and report failure their own way, so a port that maps the flag
onto exceptions leaves those paths unguarded. A few places clear the flag deliberately
and continue; those are the only catch blocks in the system.

**Fixed-width semantics are not optional.** Every character field is space-padded to its
declared length and every numeric field is a fixed number of digits. A value assembled
into a field without filling the whole width leaves the remaining bytes as they were.
