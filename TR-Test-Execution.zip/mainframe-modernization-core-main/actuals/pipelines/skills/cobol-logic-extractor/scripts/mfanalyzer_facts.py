"""Cached access to the MF Analyzer facts needed for view-usage analysis.

Everything here comes from the local MF Analyzer instance - nothing is read from
the filesystem. Two interfaces are involved, because neither covers the whole
need on its own:

* the REST lineage endpoints (``/api/v2/lineage/s2t`` and ``.../s2t/trace``)
  carry the byte-accurate linkage layout, per-field write lineage, and the trace
  chains with their guard conditions;
* the MCP server (``/api/mcp``) is the only interface that exposes source text,
  data-structure inventories and code search.

Responses are cached as JSON under ``--cache-dir`` so repeated runs and the
per-field trace fan-out cost one round trip each at most.
"""

from __future__ import annotations

import json
import os
import re
import urllib.parse
from pathlib import Path

from mfanalyzer_client import (DEFAULT_BASE_URL, MCP_PATH, HelperAuth, HttpError,
                               McpClient, McpError, fetch)

REST_PATH = "/api/v2/lineage"


def normalize_base_url(url: str) -> str:
    """Server root from whatever was supplied: drop a trailing slash and a trailing
    ``/api/mcp`` or ``/api/v2/lineage`` so both interfaces derive from one root."""
    url = url.strip().rstrip("/")
    for suffix in (MCP_PATH, REST_PATH):
        if url.endswith(suffix):
            url = url[: -len(suffix)]
    return url


def add_url_argument(parser) -> None:
    parser.add_argument(
        "--url", default=DEFAULT_BASE_URL,
        help="MF Analyzer / MFLens server root; MCP is <url>/api/mcp and REST lineage "
             f"is <url>{REST_PATH} (default: %(default)s)")
    parser.add_argument(
        "--auth", action="store_true",
        help="sign requests with the bearer token from the bundled mflens_mcp_auth.py "
             "(sign in once with 'mflens_mcp_auth.py login'); omit for a server that "
             "needs no credentials")


def mu_boundaries(mu: Path | None) -> frozenset[str]:
    """`mu.yaml` `boundaries` of the MU folder; none without `--mu` or the key.

    A boundary is another MU's entry point: its tree is that MU's to analyse, so a walk
    records the call into it and goes no further.
    """
    if mu is None:
        return frozenset()
    import sys  # noqa: PLC0415
    sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "scripts"))
    from tools_config import tool  # noqa: PLC0415 - PyYAML only when --mu is given
    manifest = tool(mu, "mu")
    return frozenset(str(name).upper() for name in manifest.get("boundaries") or [])


class FactsError(RuntimeError):
    pass


class Facts:
    def __init__(self, portfolio: str = "2", pds: str = "SRC",
                 cache_dir: Path | None = None, url: str = DEFAULT_BASE_URL,
                 auth: bool = False) -> None:
        self.portfolio = portfolio
        self.pds = pds
        self.cache_dir = cache_dir
        self.base_url = normalize_base_url(url)
        self.auth = HelperAuth() if auth else None
        self.client = McpClient(self.base_url + MCP_PATH, auth=self.auth)
        self._memo: dict[str, object] = {}
        if cache_dir:
            cache_dir.mkdir(parents=True, exist_ok=True)
            self._check_stamp()

    # -- caching ------------------------------------------------------------ #
    def _check_stamp(self) -> None:
        """Refuse a cache directory that was filled from another portfolio.

        A cache entry is keyed by what was asked - ``src-P7549500-1-99999`` - and not
        by who was asked, so answers about one portfolio are indistinguishable from
        answers about another. One mistyped ``--portfolio`` would otherwise be
        invisible: the run reports a program's fields from whatever happens to be
        cached. The directory records what filled it, and a disagreement is an error
        rather than a silent substitution.
        """
        # The leading dot keeps the stamp out of the key namespace: no cache key
        # starts with one, so it can never be mistaken for a cached response.
        stamp = self.cache_dir / ".source.json"
        mine = {"url": self.base_url, "portfolio": str(self.portfolio),
                "pds": self.pds}
        try:
            theirs = json.loads(stamp.read_text())
        except FileNotFoundError:
            stamp.write_text(json.dumps(mine))
            return
        except ValueError:
            stamp.write_text(json.dumps(mine))
            return
        if theirs != mine:
            raise FactsError(
                f"{self.cache_dir} caches {theirs.get('pds')} of portfolio "
                f"{theirs.get('portfolio')} on {theirs.get('url')}, not "
                f"{mine['pds']} of portfolio {mine['portfolio']} on {mine['url']}. "
                "Point --cache-dir at a directory of its own, or delete that one.")

    def _cached(self, key: str, produce):
        if key in self._memo:
            return self._memo[key]
        path = self.cache_dir / f"{_safe(key)}.json" if self.cache_dir else None
        value = _unset = object()
        if path and path.exists():
            try:
                value = json.loads(path.read_text())
            except ValueError:
                # An interrupted run leaves a half-written entry behind. Without
                # this it is a hard failure on every later run, reported as bad
                # JSON with nothing to say which file or what to do about it.
                path.unlink(missing_ok=True)
                value = _unset
        if value is _unset:
            value = produce()
            if path:
                # Written through a temporary and moved into place, so an
                # interrupted write cannot leave a truncated entry at all. The
                # temporary carries the process id because several extractions of
                # one tree can run at once against the same cache directory.
                temporary = path.parent / f"{path.name}.{os.getpid()}.part"
                temporary.write_text(json.dumps(value))
                temporary.replace(path)
        self._memo[key] = value
        return value

    # -- REST lineage ------------------------------------------------------- #
    def _rest(self, path: str, **params) -> dict:
        query = urllib.parse.urlencode(
            {"portfolio": self.portfolio, "pds": self.pds, **params})
        url = f"{self.base_url}{REST_PATH}/{path}?{query}"
        try:
            return json.loads(fetch(url, headers={"Accept": "application/json"},
                                    timeout=120, auth=self.auth)[1])
        except HttpError as exc:  # already names the URL
            raise FactsError(str(exc)) from exc
        except ValueError as exc:
            raise FactsError(f"{url}: not JSON: {exc}") from exc

    def lineage(self, program: str) -> dict:
        """Source-to-target lineage for one program at FULL detail."""
        return self._cached(f"s2t-{program}", lambda: self._rest(
            "s2t", programName=program, detail="FULL", format="json"))

    def trace(self, program: str, ref: str) -> dict:
        """Chains behind one lineage row: origins, steps, guard conditions."""
        return self._cached(f"trace-{program}-{ref}", lambda: self._rest(
            "s2t/trace", programName=program, ref=ref))

    def mappings(self, program: str) -> list[dict]:
        rows: list[dict] = []
        for chapter in self.lineage(program).get("chapters", []):
            for section in chapter.get("sections", []):
                rows.extend(section.get("fieldMapping", []))
        return rows

    # -- MCP ---------------------------------------------------------------- #
    def _mcp(self, tool: str, **arguments):
        try:
            return self.client.call(
                tool, portfolioId=self.portfolio, pds=self.pds, **arguments)
        except McpError as exc:
            raise FactsError(str(exc)) from exc

    def structures(self, program: str) -> list[dict]:
        result = self._cached(f"structs-{program}", lambda: self._mcp(
            "list_data_structures", programName=program))
        return result.get("dataStructures", []) if isinstance(result, dict) else []

    def structure(self, program: str, name: str) -> list[dict]:
        """Every field under one level-01 group, with level, PIC and owner path."""
        result = self._cached(f"struct-{program}-{name}", lambda: self._mcp(
            "get_data_structure_details", programName=program, structureName=name))
        return result.get("fields", []) if isinstance(result, dict) else []

    def written_targets(self, program: str) -> list[list[str]]:
        """Every field one program writes as ``[endpoint kind, node id]``.

        These are the anchors for the hop-by-hop flow graph. Linkage fields are
        included even though ``s2t`` also describes them, because the ``s2t`` trace
        enumerates at most 25 chains per target and silently drops the rest, while
        a hop reports every immediate source. A field absent from this list is
        never assigned anywhere in the program. The kind is carried along because a
        write to a ``DB2_TABLE`` column means its sources are SQL inputs, which is
        the only evidence that a field feeds an INSERT or a WHERE clause.

        The listing is paged at 200 items and reports the next page in ``cursor``
        (with ``truncated`` set), so every page has to be drained: a large
        procedure step keeps the views it passes to its callees past that
        boundary, and stopping at the first page severs the whole call tree.
        """
        def build():
            found, cursor, pages = [], None, 0
            while True:
                result = self._mcp("list_lineage_targets", programName=program,
                                   includeInternal=True,
                                   **({"cursor": cursor} if cursor else {}))
                for group in (result or {}).get("groups", []):
                    kind = group.get("endpointKind") or ""
                    found.extend([kind, item["id"]]
                                 for item in group.get("items", []))
                cursor, pages = (result or {}).get("cursor"), pages + 1
                if not cursor or pages > 200:
                    return found
        return self._cached(f"targets-{program}", build)

    def hop(self, program: str, anchor: str) -> dict:
        """One backward hop of flow into a node: its immediate sources."""
        def build():
            nodes, edges, cursor = {}, [], None
            while True:
                result = self._mcp("trace_target_lineage", programName=program,
                                   anchor=anchor, direction="backward",
                                   **({"cursor": cursor} if cursor else {}))
                for node in (result or {}).get("nodes", []):
                    nodes[node["id"]] = node
                edges.extend((result or {}).get("edges", []))
                cursor = (result or {}).get("fanoutCursor")
                if not cursor:
                    return {"nodes": list(nodes.values()), "edges": edges}
        return self._cached(f"hop-{program}-{anchor}", build)

    def field_index(self, program: str) -> list[dict]:
        """Every field of every level-01 structure, in declaration order.

        ``get_data_structure_details`` only answers for level-01 names, but CA Gen
        passes nested groups as arguments, so the whole program is indexed once
        and groups are resolved by their owner path.
        """
        def build():
            fields = []
            for struct in self.structures(program):
                for entry in self.structure(program, struct["name"]):
                    fields.append({
                        "name": entry["name"],
                        "pic": (entry.get("dataType") or "").replace("PIC ", ""),
                        "level": entry.get("level"),
                        "owner": entry.get("ownerName") or entry["name"],
                        "line": entry.get("srcLine") or 0,
                        "root": struct["name"],
                    })
            return fields
        return self._cached(f"fields-{program}", build)

    def parameters(self, program: str) -> list[str]:
        """``PROCEDURE DIVISION USING`` names in declaration order.

        The lineage engine numbers each parameter endpoint (``ep:param:N:NAME``),
        which is the order argument matching needs and is more dependable than
        re-reading the header text.
        """
        def build():
            result = self._mcp("list_lineage_targets", programName=program,
                               includeInternal=False)
            found = []
            for group in (result or {}).get("groups", []):
                for item in group.get("items", []):
                    match = re.match(r"ENDPOINT_SLICE:ep:param:(\d+):(.+)",
                                     item.get("id", ""))
                    if match:
                        found.append((int(match.group(1)), match.group(2)))
            return [name for _, name in sorted(found)]
        return self._cached(f"params-{program}", build)

    def source(self, program: str, start: int, end: int) -> list[str]:
        result = self._cached(f"src-{program}-{start}-{end}", lambda: self._mcp(
            "get_program_source_code", programName=program,
            startLine=start, endLine=end))
        return result.get("sourceCode", []) if isinstance(result, dict) else []

    def paragraphs(self, program: str) -> list[dict]:
        """Paragraph names with their line ranges.

        Needed to read one named paragraph without pulling the whole procedure
        division: the generated ``PARA-<id>-INIT`` is the only place that states
        what the program substitutes for an import the caller left unset.
        """
        result = self._cached(f"paras-{program}", lambda: self._mcp(
            "get_program_paragraphs", programName=program))
        if isinstance(result, dict):
            return result.get("paragraphs", [])
        return result if isinstance(result, list) else []

    def code_matches(self, program: str, query: str) -> list[dict]:
        result = self._cached(f"grep-{program}-{query}", lambda: self._mcp(
            "search_code", programName=program, searchQuery=query))
        return result.get("matches", []) if isinstance(result, dict) else []

    def program_exists(self, program: str) -> bool:
        key = f"exists-{program}"
        def probe():
            try:
                return bool(self.structures(program))
            except FactsError:
                return False
        return bool(self._cached(key, probe))


def _safe(key: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]", "_", key)
