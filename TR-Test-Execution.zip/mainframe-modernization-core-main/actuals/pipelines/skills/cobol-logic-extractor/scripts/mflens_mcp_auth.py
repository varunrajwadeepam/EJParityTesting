#!/usr/bin/env python3
"""Cognito sign-in for MFlens MCP clients (Claude Code headersHelper).

  mflens_mcp_auth.py login     one-time: browser sign-in (auth code + PKCE), caches tokens
  mflens_mcp_auth.py headers   prints {"Authorization": "Bearer <id token>"}; refreshes silently
  mflens_mcp_auth.py logout    forgets the cached tokens

Settings come from `terraform output mcp` and are saved by `login`, so `headers` needs no
arguments. The ID token (1h) is refreshed with the refresh token (30 days); after that,
run `login` again. Python 3 standard library only.
"""
import argparse
import base64
import hashlib
import http.server
import json
import os
import secrets
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser

CACHE = os.path.expanduser(os.environ.get("MFLENS_MCP_AUTH_CACHE", "~/.config/mflens/mcp-auth.json"))
REFRESH_MARGIN = 300  # seconds before expiry to refresh


def die(msg):
    print(f"mflens_mcp_auth: {msg}", file=sys.stderr)
    sys.exit(1)


def load():
    try:
        with open(CACHE) as f:
            return json.load(f)
    except FileNotFoundError:
        return None


def save(data):
    os.makedirs(os.path.dirname(CACHE), exist_ok=True)
    fd = os.open(CACHE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(data, f)


def jwt_exp(token):
    payload = token.split(".")[1]
    payload += "=" * (-len(payload) % 4)
    return json.loads(base64.urlsafe_b64decode(payload))["exp"]


def token_request(cfg, fields):
    body = urllib.parse.urlencode({"client_id": cfg["client_id"], **fields}).encode()
    req = urllib.request.Request(f"https://{cfg['cognito_host']}/oauth2/token", data=body,
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            return json.load(resp)
    except urllib.error.HTTPError as e:
        die(f"token endpoint returned {e.code}: {e.read().decode(errors='replace')}")


def login(args):
    cached = load() or {}
    cfg = {
        "cognito_host": args.cognito_host or cached.get("cognito_host"),
        "client_id": args.client_id or cached.get("client_id"),
        "port": args.port or cached.get("port") or 8765,
    }
    if not cfg["cognito_host"] or not cfg["client_id"]:
        die("first login needs --cognito-host and --client-id (see `terraform output mcp`)")

    redirect_uri = f"http://localhost:{cfg['port']}/callback"
    verifier = secrets.token_urlsafe(64)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    state = secrets.token_urlsafe(16)
    url = f"https://{cfg['cognito_host']}/oauth2/authorize?" + urllib.parse.urlencode({
        "response_type": "code", "client_id": cfg["client_id"], "redirect_uri": redirect_uri,
        "scope": "openid email profile", "state": state,
        "code_challenge": challenge, "code_challenge_method": "S256",
    })

    result = {}

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            if urllib.parse.urlparse(self.path).path != "/callback":
                self.send_response(404)
                self.end_headers()
                return
            ok = q.get("state", [""])[0] == state and "code" in q
            result["code"] = q["code"][0] if ok else None
            result["error"] = None if ok else q.get("error_description", q.get("error", ["state mismatch"]))[0]
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            msg = "Signed in to MFlens. You can close this tab." if ok else f"Sign-in failed: {result['error']}"
            self.wfile.write(f"<html><body><p>{msg}</p></body></html>".encode())

        def log_message(self, *a):
            pass

    server = http.server.HTTPServer(("127.0.0.1", cfg["port"]), Handler)
    server.timeout = 300
    print(f"Opening browser for Cognito sign-in. If it does not open, visit:\n{url}\n", file=sys.stderr)
    webbrowser.open(url)
    while "code" not in result:
        server.handle_request()
        if "code" not in result:
            die("timed out waiting for the sign-in redirect")
    server.server_close()
    if not result["code"]:
        die(f"sign-in failed: {result['error']}")

    tokens = token_request(cfg, {"grant_type": "authorization_code", "code": result["code"],
                                 "redirect_uri": redirect_uri, "code_verifier": verifier})
    save({**cfg, "id_token": tokens["id_token"], "refresh_token": tokens["refresh_token"]})
    print(f"Signed in; tokens cached in {CACHE}", file=sys.stderr)


def headers(_args):
    data = load()
    if not data or "refresh_token" not in data:
        die("not signed in; run: mflens_mcp_auth.py login")
    if jwt_exp(data["id_token"]) - time.time() < REFRESH_MARGIN:
        tokens = token_request(data, {"grant_type": "refresh_token", "refresh_token": data["refresh_token"]})
        data["id_token"] = tokens["id_token"]
        save(data)
    print(json.dumps({"Authorization": f"Bearer {data['id_token']}"}))


def logout(_args):
    try:
        os.remove(CACHE)
    except FileNotFoundError:
        pass
    print("Signed out (local tokens removed)", file=sys.stderr)


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    lp = sub.add_parser("login")
    lp.add_argument("--cognito-host", help="e.g. mflens-xxxxxx.auth.us-east-1.amazoncognito.com")
    lp.add_argument("--client-id", help="Cognito CLI app client id (terraform output mcp)")
    lp.add_argument("--port", type=int, help="callback port registered in Cognito (default 8765)")
    lp.set_defaults(fn=login)
    sub.add_parser("headers").set_defaults(fn=headers)
    sub.add_parser("logout").set_defaults(fn=logout)
    args = p.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()
