#!/usr/bin/env python3
"""Strip one analysed COBOL program down to its interface and its logic.

A generated member is mostly declaration: a thousand lines of view layouts, null
flags and REDEFINES aliases before the first statement. What is worth reading is the
contract and the procedure division. This prints that, and nothing else:

* the filtered input and output contract, each field with its type and its place in
  any repeating group, plus the view fields the filter dropped and why;
* the locals and constants the surviving statements still name, the groups the code
  clears, and the exit states the program declares;
* the procedure division, one section per paragraph carrying the line range it
  occupies in the member, so anything found here can be pointed at in the original.

The result is Markdown, and the code in it is deliberately not valid COBOL.
``FORMAT.md``, beside this directory, specifies the document and is the thing to read
before interpreting one.

Source and declarations come from the local MF Analyzer, never the filesystem.

Parameter direction is read from the view name - the two generated schemes
(``IMPORT-nnnnEV`` / ``EXPORT-nnnnEV`` and ``IN-nnnnEV`` / ``OUT-nnnnEV``) plus the
procedure-step wrappers ``W-IA`` / ``W-OA`` - using the same vocabulary as
``analyze_view_usage``, so the two agree. The runtime parameters and the shared
control block ``GLOBDATA`` are left out of the header: the first carry nothing, and
the second is one copy threaded through the whole tree rather than this program's own
contract. Null flags, REDEFINES aliases and the other generated control fields are
left out for the same reason they are left out of a contract - they describe a field
rather than being one.

``--index`` additionally records every paragraph of the program in a JSON index beside
the documents - its line range, whether it carries behaviour that has to be traceable,
and the SQL, calls, functions and outcomes in it. It states nothing the document does
not; it exists so the migration can be checked rather than attested. See ``FORMAT.md``.

Usage:
    extract_logic.py P7549500 [--portfolio 2] [--pds SRC] [-o FILE] [--index FILE]
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from analyze_view_usage import (  # noqa: E402
    EXPORT_VIEW, INBOUND_WORDS, OUTBOUND_WORDS, RUNTIME_PARAMS, REPEATING_WRAPPER,
    INFRASTRUCTURE_FIELDS, SCRATCH_FAMILIES, SHARED_PARAM, VIEW_SUFFIX, Analyzer,
    base_name, is_plumbing, is_runtime_module, pseudo_type, view_contract)
from mfanalyzer_facts import (  # noqa: E402
    Facts, FactsError, add_url_argument, mu_boundaries)

PROCEDURE_DIVISION = "PROCEDURE DIVISION"

# The generator closes each member with the model definition reproduced as comments -
# the action block's imports and exports, then its procedure statements in model
# language, opening on a `+->  <name>  <date>` line and closing on `+---`. It is the
# CA Gen source the COBOL was generated from, and it restates the whole program: for
# P7549500 that is 214 of 869 lines. Dropped here because it duplicates the logic
# below it in a second language; it is still the only place the model's own wording
# survives, so read the member itself when that wording is what is wanted.
DESIGN_BLOCK_OPEN = "+->"
DESIGN_BLOCK_CLOSE = "+---"

# The generator sets a statement-number breadcrumb before nearly every statement, so
# that a failure can report which one it died on. Measured over the batch: 52173 of
# these, and the value is never read by anything except one program that saves and
# restores it around a call to the trace module. It carries no logic, and the line
# numbers kept here say the same thing more precisely. Only the literal assignment is
# dropped - an assignment from another field is a real read and stays.
BREADCRUMB = re.compile(r"^COMPUTE\s+LAST-STATEMENT-NUM\s*=\s*\d+$")

# The same bookkeeping at action-block level: each paragraph announces which block is
# running so that termination can report where a failure happened. 9990 statements in
# 1088 members, every one of them a literal assignment - nothing in the batch, generated
# or runtime, ever reads either field. The paragraph headings in this output say the
# same thing.
IDENTITY = re.compile(r"^MOVE\s+'[^']*'\s+TO\s+CUR-AB-(?:ID|NAM|NAME)(?:\s+OF\s+GLOBDATA)?$")

# A paragraph name stands alone on its line in area A, which is what separates it from
# a one-word statement like `GOBACK.` sitting out in area B.
PARAGRAPH_NAME = re.compile(r"^[A-Z0-9][A-Z0-9#@$-]*\.$")
AREA_A_END = 8

# Code ends at column 72. Columns 73-80 are the program identification the compiler
# ignores and the generator may stamp on every line. Nothing here may read past this
# point: a declaration carrying a stamp never reaches its terminating period, so the
# parse swallows every line after it, and every fold regex below is anchored with `$`
# and would stop matching. The leading six columns are not cut - they are the sequence
# area, blank in generated members, and the indentation that `is_paragraph` reads to
# tell area A from area B is measured from column 1.
CODE_END = 72


def is_paragraph(text: str) -> bool:
    return (len(text) - len(text.lstrip()) < AREA_A_END
            and bool(PARAGRAPH_NAME.match(text.strip())))


# Every generated program opens by normalising its whole import view: one guarded
# substitution per field, replacing binary junk with spaces and non-numeric digits with
# zero, then initialising the locals and export views. It is the same paragraph in every
# member and says nothing specific to the program, so it collapses to `@validation` at
# the point it runs. What it substitutes per field is reported by `analyze_view_usage`
# as the field's default; the behaviour it implies is recorded in
# FORMAT.md, under Behaviours to keep in mind. All 846 call sites are a single line.
VALIDATION_PARAGRAPH = re.compile(r"^PARA-\S+-INIT(?:-EXIT)?\.$")
VALIDATION_PERFORM = re.compile(
    r"^PERFORM\s+PARA-\S+-INIT\s+THRU\s+PARA-\S+-INIT-EXIT$")
VALIDATION_MARKER = "*> @validation"


def fold_validation(body: list[tuple[int, str]]) -> list[tuple[int | None, str]]:
    """Drop the generated normalisation paragraph, marking where it is performed."""
    kept: list[tuple[int, str]] = []
    skipping = False
    for number, text in body:
        stripped = text.strip()
        if is_paragraph(text):
            skipping = bool(VALIDATION_PARAGRAPH.match(stripped))
        if skipping:
            continue
        if VALIDATION_PERFORM.match(stripped):
            # No line number and no indent: the marker stands for a paragraph that is
            # no longer here, not for the one statement that performed it.
            kept.append((None, VALIDATION_MARKER))
            continue
        kept.append((number, text))
    return kept


# Failure propagation: after a call that can fail, the caller tests the three status
# flags and returns if any is set. It is the generated stand-in for an exception, the
# only shape it ever takes, and it follows every call to a generated program - 5380
# occurrences in the batch, with no target ever checked at one call site and not
# another. Folded to one marker. The variant that performs a local `-ERROR` paragraph
# first is left in place: it records a diagnostic before returning, so it is not purely
# plumbing. See FORMAT.md, under Behaviours to keep in mind.
EXCEPTION_CHECK = re.compile(
    r"^IF\s+STATUS-FLAG(?:\s+OF\s+GLOBDATA)?\s+NOT\s*=\s*SPACES\s+OR"
    r"\s+ERROR-ENCOUNTERED-SW(?:\s+OF\s+GLOBDATA)?\s+NOT\s*=\s*SPACES\s+OR"
    r"\s+VIEW-OVERFLOW-SW(?:\s+OF\s+GLOBDATA)?\s+NOT\s*=\s*SPACES"
    r"\s+GOBACK\s+END-IF$")
EXCEPTION_MARKER = "*> @exception-check"
CHECK_MAX_LINES = 8


# CA Gen numbers each view it emits and suffixes every leaf with that number, so the
# same model attribute is a different name in the import view and in the export view
# beside it. Copying one to the other is the generator marshalling a value across a
# view boundary, not the program doing anything with it - which is why the contract
# analysis reports such a field as ECHOED and drops it. They are dropped here entirely,
# marker included: knowing that a copy happened somewhere adds nothing to the reading of
# a program, and which fields travel is already in the contract tables above. A
# loop whose whole body is copies goes with them.
SUBSCRIPTED = r"[A-Z0-9#@$-]+(?:\s*\([^)]*\))?"
ECHO_MOVE = re.compile(rf"^MOVE\s+(?P<src>{SUBSCRIPTED})\s+TO\s+(?P<dst>{SUBSCRIPTED})$")
ECHO_COMPUTE = re.compile(rf"^COMPUTE\s+(?P<dst>{SUBSCRIPTED})\s*=\s*(?P<src>{SUBSCRIPTED})$")
OCCURRENCE = re.compile(r"-?\d{4}(?:[A-Z]{2})?$")

# CA Gen's early return. A COBOL paragraph cannot return out of a nested PERFORM, so
# each action-block invocation gets a flag: setting it is the model's ESCAPE action, and
# every enclosing paragraph checks its own flag after the PERFORM returns and jumps to
# its exit. Measured over the batch: 8430 sets, 7773 entry initialisations and 3999
# post-PERFORM checks, of which 3173 go to the paragraph exit and 539 to an init bypass.
#
# Only the entry reset goes. The raise and the check are both kept, as markers, because
# they are only useful together: the check says control may stop here, the raise says
# which paragraph asks it to. With the raise hidden, whether a dispatched branch returns
# or falls through into the statements below the dispatch is unresolvable - and that is
# the difference between a response code surviving and being overwritten.
#
# A run of raises is one escape unwinding through its nesting: it sets the flag of each
# enclosing paragraph in turn, and that chain is exactly how far control returns. The
# run folds to one marker, which names every paragraph in it - without the names a
# reader can see that an escape was raised but not whether it stops at the paragraph
# above or carries past it, and those two readings produce different results.
ESCAPE_OWNER = re.compile(r"^(?:FUNC|REPEAT|READ-EACH|FOR-EACH)-(?P<id>\d+)$")
ESCAPE_FLAG = r"[A-Z-]*\d+-ESC-FLAG"
ESCAPE_RAISE = re.compile(rf"^MOVE\s+'Y'\s+TO\s+(?P<flag>{ESCAPE_FLAG})$")
ESCAPE_RESET = re.compile(rf"^MOVE\s+'N'\s+TO\s+(?:{ESCAPE_FLAG}|ESCAPE-SW)$")
ESCAPE_MARKER = "*> @escape"
ESCAPE_CHECK_MARKER = "*> @escape-check"
ESCAPE_CHECK = re.compile(
    rf"^IF\s+{ESCAPE_FLAG}\s*=\s*'Y'\s+GO\s+TO\s+(?P<target>PARA-\S+?)(?:-EXIT|-INIT-BYPASS)"
    rf"\s+END-IF$")
STATEMENT_WORDS = {
    "IF", "ELSE", "END-IF", "EVALUATE", "WHEN", "END-EVALUATE", "MOVE", "COMPUTE",
    "ADD", "SUBTRACT", "MULTIPLY", "DIVIDE", "INITIALIZE", "SET", "PERFORM",
    "END-PERFORM", "CALL", "END-CALL", "GOBACK", "GO", "EXIT", "CONTINUE", "STOP",
    "SEARCH", "END-SEARCH", "INSPECT", "STRING", "UNSTRING", "ACCEPT", "DISPLAY",
    "EXEC", "READ", "WRITE", "REWRITE", "DELETE", "OPEN", "CLOSE", "RETURN",
}


def starts_statement(text: str) -> bool:
    # A verb can carry the statement-terminating period - `GOBACK.` - so the period is
    # stripped before the word is recognised. Without that, the line reads as a
    # continuation and gets joined onto the statement above it.
    stripped = text.strip()
    # A marker or a rewritten PERFORM stands on its own: neither is a COBOL verb, and
    # joining the line after it onto one of them would merge two statements.
    if stripped.startswith(("*>", "@")):
        return True
    first = stripped.split(" ", 1)[0].rstrip(".")
    return first in STATEMENT_WORDS or is_paragraph(text) or not first


def view_directions(facts: Facts, program: str) -> dict[str, str]:
    """``field -> "in" | "out"`` for the fields of this program's parameter views.

    Only the parameter views count. A field of a local view - the caller's copy of a
    callee's contract - is neither, which is what separates a pass-through from the
    marshalling around a call.
    """
    parameters = set(facts.parameters(program))
    found: dict[str, str] = {}
    for entry in facts.field_index(program):
        root = entry["root"]
        if root not in parameters or root in RUNTIME_PARAMS or root == SHARED_PARAM:
            continue
        found[entry["name"]] = "out" if is_outbound(root) else "in"
    return found


def same_field(left: str, right: str) -> bool:
    """True when two references name the same model attribute in different views.

    The occurrence number and any REDEFINES decoration are what differ between the
    two copies, so both are stripped; a subscript has to match as it stands, since
    copying one entry of a group to another is a move, not an echo.
    """
    def split(reference: str) -> tuple[str, str]:
        name, _, subscript = reference.partition("(")
        return OCCURRENCE.sub("", name.strip()), subscript.replace(" ", "")
    source, target = split(left), split(right)
    return source == target and left.strip() != right.strip()


def is_echo(statement: str, direction: dict[str, str], contracted: set[str]) -> bool:
    """True for a pass-through that carries a field the contract dropped.

    Two tests, both required. The copy has to run from an import view field to an
    export view field - the program handing back what it was given. And at least one
    of the two fields has to be absent from the contract tables above, meaning the
    analysis found that nothing reads it or nothing populates it.

    A pass-through between two fields the contract keeps is left in place: both ends are
    listed, and this statement is the only thing that connects them. Nothing else folds
    either - a copy out of a local view into an export is the callee's answer becoming
    this program's answer, and a copy of an import into a local view is the value a
    callee will receive.
    """
    match = ECHO_MOVE.match(statement) or ECHO_COMPUTE.match(statement)
    if not match:
        return False
    source = match.group("src").split("(")[0].strip()
    target = match.group("dst").split("(")[0].strip()
    if direction.get(source) != "in" or direction.get(target) != "out":
        return False
    return not (source in contracted and target in contracted)


def statement_text(body: list[tuple[int | None, str]], index: int, span: int) -> str:
    return re.sub(r"\s+", " ", " ".join(text.strip() for _, text
                                        in body[index:index + span]))


def fold_echoes(body: list[tuple[int | None, str]], direction: dict[str, str],
                contracted: set[str]) -> list[tuple[int | None, str]]:
    """Remove the import-to-export pass-throughs, loops included."""
    kept: list[tuple[int | None, str]] = []
    index = 0
    while index < len(body):
        span = statement_length(body, index)
        statement = re.sub(r"\s+", " ",
                           " ".join(text.strip()
                                    for _, text in body[index:index + span]))
        if not is_echo(statement, direction, contracted):
            kept.extend(body[index:index + span])
        index += span
    return kept


# Before returning, a program fills the response envelope: the named outcome, the
# message to show, whether to roll back, and how severe it is. 4176 runs in 520
# members, always these four slots and always adjacent. Unlike the mechanisms folded
# above, the values carry the result - 292 distinct combinations - so they are kept and
# only the four `MOVE`s collapse into one line.
RESPONSE_SLOTS = {
    "PSMGR-EXIT-STATE": "state",
    "PSMGR-EXIT-MSGTYPE": "level",
    "PSMGR-EXIT-INFOMSG": "message",
    "PSMGR-ROLLBACK-RQSTED": "rollback",
}
RESPONSE_SET = re.compile(
    rf"^MOVE\s+(?P<value>'[^']*'|[A-Z0-9#@$-]+)\s+TO\s+"
    rf"(?P<field>{'|'.join(RESPONSE_SLOTS)})(?:\s+OF\s+GLOBDATA)?\.?$")
RESPONSE_MARKER = "*> @response"

# A call to a generated program passes the runtime parameters, the shared control
# block, and one view per direction - the caller's local copy of the callee's contract.
# The view names are generated ids that say nothing, so the fields inside them are
# listed instead. The `MOVE SPACES TO ERROR-ENCOUNTERED-SW` that precedes every call is
# the generated reset of the error flag: all 5267 of them sit immediately before a CALL.
PRE_CALL = re.compile(
    r"^MOVE\s+SPACES\s+TO\s+ERROR-ENCOUNTERED-SW(?:\s+OF\s+GLOBDATA)?\.?$")
CALL_STATEMENT = re.compile(
    r"^CALL\s+'?(?P<target>[A-Z0-9#@$-]+)'?(?:\s+USING\s+(?P<args>.*?))?\.?$")
CALL_MARKER = "*> @call"

# `INITIALIZE <group>` sets every field in the group to its category default - text to
# spaces, numbers to zero - and skips REDEFINES aliases. The local views are working
# storage reused by every call, so this is what makes each request fresh rather than
# cumulative: a field the caller does not set reaches the callee blank because of this
# statement, which is where "unset" is manufactured. Kept as a marker, with what each
# group contains listed once in its own section.
INITIALIZE_STATEMENT = re.compile(r"^INITIALIZE\s+(?P<groups>[A-Z0-9#@$ -]+?)\.?$")
INITIALIZE_MARKER = "*> @initialize"

# Emptying a repeating group takes two statements, in either order: `INITIALIZE` on the
# `...RG` wrapper clears the slots and the filled count, and a move into the `...PS`
# cursor says where the next write lands. The cursor lives outside the view, in a
# control block of its own, which is why the order does not matter.
#
# The value is the part worth keeping. Measured over the batch: 5986 sites set it to
# zero and 856 to one, and the difference is the idiom that follows - zero goes with
# `ADD 1 TO <cursor>` before each write, one goes with writing at `(<cursor>)` directly.
# So zero means "nothing written yet, first entry lands at 1" and one means "pointing at
# the first entry".
GROUP_CURSOR = re.compile(r"^MOVE\s+(?P<value>ZERO|ZEROS|ZEROES|\d+)\s+TO\s+"
                          r"(?P<group>[A-Z0-9#@$-]+?)PS\.?$")


def merge_group_cursors(body: list[tuple[int | None, str]]
                        ) -> list[tuple[int | None, str]]:
    """Fold a group's cursor reset into the `@initialize` marker beside it."""
    kept: list[tuple[int | None, str]] = []
    index = 0
    while index < len(body):
        cursor = GROUP_CURSOR.match(body[index][1].strip())
        group = cursor.group("group") if cursor else ""
        if group:
            value = "0" if cursor.group("value").startswith("ZERO") \
                else cursor.group("value")
            # The marker may be either side of the cursor move.
            if kept and kept[-1][1] == f"{INITIALIZE_MARKER} {group}RG":
                kept[-1] = (None, f"{kept[-1][1]}, cursor={value}")
                index += 1
                continue
            following = body[index + 1][1] if index + 1 < len(body) else ""
            if following == f"{INITIALIZE_MARKER} {group}RG":
                kept.append((None, f"{following}, cursor={value}"))
                index += 2
                continue
        kept.append(body[index])
        index += 1
    return kept


def fold_initializers(body: list[tuple[int | None, str]]
                      ) -> list[tuple[int | None, str]]:
    """Rewrite each `INITIALIZE` as a marker naming the groups it clears."""
    kept: list[tuple[int | None, str]] = []
    index = 0
    while index < len(body):
        span = statement_length(body, index)
        match = INITIALIZE_STATEMENT.match(statement_text(body, index, span))
        if match:
            groups = " ".join(match.group("groups").split())
            kept.append((None, f"{INITIALIZE_MARKER} {groups}"))
        else:
            kept.extend(body[index:index + span])
        index += span
    return kept


def initialized_groups(body: list[tuple[int | None, str]],
                       declared: dict[str, tuple[str, str, str, tuple[str, ...]]]
                       ) -> list[tuple[str, list[str]]]:
    """``(group, fields)`` for each group the surviving code initialises."""
    order: list[str] = []
    for _, text in body:
        if not text.startswith(INITIALIZE_MARKER):
            continue
        # The marker may carry a trailing `, cursor=n`, which is not a group.
        named = text[len(INITIALIZE_MARKER):].split(",")[0]
        for group in named.split():
            if group not in order:
                order.append(group)
    rows = []
    for group in order:
        fields = [name for name, (_, kind, _, path) in declared.items()
                  if group in path and kind not in ("group", "condition")
                  and not is_plumbing(name)]
        rows.append((group, fields))
    return rows

# A group-view loop with an empty body: `COMPUTE ADIMn = <capacity>` is how the
# generator leaves such a loop early, so with nothing else inside, the construct runs
# its body once and exits with the subscript one past the end. Nothing else is touched,
# and the subscript is re-initialised by the next `PERFORM VARYING` before it is read,
# so the whole thing has no observable effect - 6251 of them, concentrated in 88 of the
# larger procedure steps.
EMPTY_GROUP_LOOP = re.compile(
    r"^PERFORM\s+VARYING\s+(?P<index>ADIM\d)\s+FROM\s+1\s+BY\s+1"
    r"\s+UNTIL\s+(?P=index)\s*>\s*(?P<bound>\d+)"
    r"\s+COMPUTE\s+(?P=index)\s*=\s*(?P=bound)\s+END-PERFORM\.?$")


def drop_empty_loops(body: list[tuple[int | None, str]]
                     ) -> list[tuple[int | None, str]]:
    """Remove the group-view loops that only move the subscript past the end."""
    kept: list[tuple[int | None, str]] = []
    index = 0
    while index < len(body):
        span = loop_length(body, index)
        if not span:
            kept.append(body[index])
        index += span or 1
    return kept


LOOP_MAX_LINES = 6


def loop_length(body: list[tuple[int | None, str]], index: int) -> int:
    """How many lines the empty loop at this position spans, or 0 if it is not one."""
    if not body[index][1].strip().startswith("PERFORM VARYING"):
        return 0
    parts = []
    for offset in range(min(LOOP_MAX_LINES, len(body) - index)):
        parts.append(body[index + offset][1].strip())
        if parts[-1].rstrip(".") == "END-PERFORM":
            statement = re.sub(r"\s+", " ", " ".join(parts))
            return offset + 1 if EMPTY_GROUP_LOOP.match(statement) else 0
    return 0


def group_fields(facts: Facts, program: str) -> dict[str, list[str]]:
    """Every group name in the program mapped to the fields inside it.

    A call site can name a level-01 or a group nested inside one, so each field is
    registered against every group it sits under, in declaration order.
    """
    found: dict[str, list[str]] = {}
    for entry in sorted(facts.field_index(program), key=lambda f: f["line"]):
        if not entry["pic"] or is_plumbing(entry["name"]):
            continue
        for owner in entry["owner"].split(".")[:-1]:
            found.setdefault(owner, []).append(entry["name"])
    return found


def callee_names(facts: Facts, caller: str, target: str,
                 arguments: list[str]) -> dict[str, str]:
    """``caller's field -> the callee's name for it``, paired positionally.

    The binding across a CALL is by byte offset, not by name: the callee's declaration
    is laid over the caller's storage. Both views are generated from one model
    definition, so pairing the leaves in declaration order gives each field the name the
    callee knows it by - measured over 2209 call sites between generated programs,
    107111 field pairs, the two names agree on their base in 99.5% of cases, the
    exceptions being the per-group control fields whose names describe the group rather
    than an attribute.
    """
    try:
        parameters = facts.parameters(target)
    except FactsError:
        return {}
    if len(parameters) != len(arguments):
        return {}
    paired: dict[str, str] = {}
    here, there = group_fields(facts, caller), group_fields(facts, target)
    for argument, parameter in zip(arguments, parameters):
        source, destination = here.get(argument, []), there.get(parameter, [])
        if len(source) == len(destination):
            paired.update(zip(source, destination))
    return paired


def fold_calls(body: list[tuple[int | None, str]], fields: dict[str, list[str]],
               facts: Facts, caller: str) -> list[tuple[int | None, str]]:
    """Rewrite each CALL as `@call target(inputs) into outputs`."""
    kept: list[tuple[int | None, str]] = []
    index = 0
    while index < len(body):
        span = statement_length(body, index)
        statement = re.sub(r"\s+", " ", " ".join(
            text.strip() for _, text in body[index:index + span]))
        match = CALL_STATEMENT.match(statement)
        if match:
            if (index + span < len(body)
                    and body[index + span][1].strip().rstrip(".") == "END-CALL"):
                span += 1
            kept.append((body[index][0],
                         call_marker(match, fields, facts, caller)))
        else:
            kept.extend(body[index:index + span])
        index += span
    return kept


# The runtime library is reached by CALL as well, but a call to one of its functions is
# not a call to a program: the operands are plain fields and the last one is the result.
# That convention is inferred from stub implementations of the runtime library
# - `GLOBDATA, LK-DATE-VALUE-AT, LK-YEAR-AT` and the like - which are themselves
# inferred from call sites, so a module that works in place (TIRUPPR) will read as
# though its last operand were an output.
#
# Three targets are not functions. `TIRFAIL` raises a failure. `TIRLGLOD` is the loader:
# it performs a dynamic program call, with the real target named by its first operand as
# `<TARGET>-ID`. Anything whose operands live in GLOBDATA slots - `TIRFDDUR` - has no
# operands left to show once the control block is dropped.
# `TIRFDDUR` adds a duration to a date, and its operands are GLOBDATA slots rather than
# call arguments: the lines before it set the base date and one duration component, the
# three `-MISS` flags say which component that is, and the line after it reads the
# answer back out. Nothing survives the general rules - the call shows empty brackets
# and the setup reads as four unexplained assignments - so the whole idiom folds here.
# 18 call sites in 13 members; the components used are years, months and days, with
# values 1, -1, 3 and -15.
FUNCTION_MARKER = "*> @function"
DURATION_MODULE = "TIRFDDUR"
DURATION_UNITS = {"YYYY": "years", "MM": "months", "DD": "days",
                  "HH": "hours", "SS": "seconds"}
DURATION_BASE = re.compile(r"^MOVE\s+(?P<source>\S+)\s+TO\s+PSMGR-FUNC-IN-DATE\.?$")
DURATION_AMOUNT = re.compile(
    r"^COMPUTE\s+[DT]DURA-(?P<unit>YYYY|MM|DD|HH|SS)\s*=\s*(?P<amount>[-\s()\d]+)$")
DURATION_SETUP = re.compile(
    r"^(?:MOVE\s+DATA-(?:MISSING|PRESENT)\s+TO\s+[DT]DURA-\S+"
    r"|MOVE\s+'N'\s+TO\s+PSMGR-TIRDATE-SKIP-VAL(?:\s+OF\s+GLOBDATA)?"
    r"|INITIALIZE\s+PSMGR-FUNC-OUT-\S+"
    r"|COMPUTE\s+[DT]DURA-\S+\s*=.*)\.?$")
DURATION_RESULT = re.compile(
    r"^MOVE\s+PSMGR-FUNC-OUT-\S+\s+TO\s+(?P<target>\S+?)\.?$")
DURATION_MARKER = "*> @date-add"


def fold_durations(body: list[tuple[int | None, str]]
                   ) -> list[tuple[int | None, str]]:
    """Collapse the date-duration idiom into one expression."""
    kept: list[tuple[int | None, str]] = []
    index = 0
    while index < len(body):
        span = statement_length(body, index)
        statement = statement_text(body, index, span)
        if DURATION_MODULE not in statement or not statement.startswith("CALL"):
            kept.append(body[index])
            index += 1
            continue
        base, amount, unit = "", "", ""
        # The setup sits immediately above the call, in whatever order.
        while kept:
            previous = kept[-1][1].strip()
            found = DURATION_BASE.match(previous)
            if found:
                base = found.group("source")
            elif DURATION_AMOUNT.match(previous):
                found = DURATION_AMOUNT.match(previous)
                amount = re.sub(r"[\s()]", "", found.group("amount"))
                unit = DURATION_UNITS.get(found.group("unit"), found.group("unit"))
            elif not DURATION_SETUP.match(previous):
                break
            kept.pop()
        index += span
        trailing: list[tuple[int | None, str]] = []
        target = ""
        while index < len(body):
            statement = statement_text(body, index, statement_length(body, index))
            if statement.rstrip(".") == "END-CALL":
                index += 1
                continue
            if statement.startswith(EXCEPTION_MARKER):
                trailing.append(body[index])
                index += 1
                continue
            found = DURATION_RESULT.match(statement)
            if found:
                target = found.group("target")
                index += statement_length(body, index)
            break
        amount = f"{amount} {unit}".strip() or "?"
        expression = f"{base or '?'} + {amount}" if not amount.startswith("-") \
            else f"{base or '?'} - {amount.lstrip('-')}"
        kept.append((None, f"{DURATION_MARKER} {expression}"
                     + (f" -> {target}" if target else "")))
        kept.extend(trailing)
    return kept
FAIL_MARKER = "*> @fail"
LOADER = "TIRLGLOD"
FAIL_MODULE = "TIRFAIL"
LOADER_ALIAS = re.compile(r"^(?P<target>[A-Z0-9#@$]+)-ID$")


def call_marker(match: re.Match, fields: dict[str, list[str]],
                facts: Facts, caller: str) -> str:
    """One call, each field paired with the name the callee knows it by.

    Written in the direction the data moves: `theirs=mine` for what is passed, and
    `mine=theirs` for what comes back, so each pair reads as the assignment the shared
    storage performs. Where the two views cannot be paired - argument count disagrees,
    leaf counts differ - only the caller's name is shown.
    """
    target = match.group("target")
    # Pairing needs the list as written - the callee's parameters include the runtime
    # ones, and dropping them here would put the two lists out of step.
    declared = [part.strip(" ,.") for part in
                re.split(r"[,\s]+", (match.group("args") or "").strip())
                if part.strip(" ,.")]
    if target == FAIL_MODULE:
        return FAIL_MARKER
    # The loader's first operand names the real target and is not one of that
    # target's parameters, so it has to leave the list `callee_names` pairs against -
    # `declared`, not just the display list. Leaving it there put the arguments one
    # ahead of the callee's parameters, and `callee_names` answers nothing when the
    # two counts disagree, so every call through the loader lost its callee-side
    # names - which in a generated tree is most calls. The operand is read from
    # `declared` rather than from the filtered list because the id comes first, ahead
    # of the runtime parameters (`../tir-cobol/SKILL.md`, "The call shape"), which is also
    # where `program_tree.py` and `analyze_view_usage.py` look for it.
    if target == LOADER and declared:
        alias = LOADER_ALIAS.match(declared[0])
        if alias:
            target, declared = alias.group("target"), declared[1:]
    operands = [name for name in declared
                if name not in RUNTIME_PARAMS and name != SHARED_PARAM]
    if is_runtime_module(target):
        inputs = ", ".join(operands[:-1]) if len(operands) > 1 else ""
        marker = f"{FUNCTION_MARKER} {target}({inputs})"
        return f"{marker} -> {operands[-1]}" if operands else marker
    pairing = callee_names(facts, caller, target, declared)
    passed, returned = [], []
    for name in operands:
        # `-IA` / `-OA` are the procedure-step wrappers a caller builds for an action
        # block; anything else is read by the same rule the interface header uses.
        outbound = name.endswith("-OA") or is_outbound(name)
        for field in fields.get(name) or [name]:
            theirs = pairing.get(field)
            if theirs is None or theirs == field:
                (returned if outbound else passed).append(field)
            elif outbound:
                returned.append(f"{field}={theirs}")
            else:
                passed.append(f"{theirs}={field}")
    marker = f"{CALL_MARKER} {target}({', '.join(passed)})"
    return f"{marker} into {', '.join(returned)}" if returned else marker
BLANK_VALUES = {"SPACES", "SPACE", "ZERO", "ZEROS", "ZEROES", "''"}


def response_value(slot: str, value: str) -> str:
    """One slot of the response, as it reads in the marker.

    A blank is spelled out per slot rather than passed through: an empty message and a
    rollback that was not requested are the two things a reader checks for first.
    """
    blank = value.strip("'") == "" or value in BLANK_VALUES
    if slot == "rollback":
        # The two non-blank values in the batch are `A` and `R`; they are reported as
        # they stand rather than flattened to true, since nothing here establishes that
        # they mean the same thing.
        return "rollback=false" if blank else f"rollback={value.strip(chr(39))}"
    if slot == "message":
        return f"message='{'' if blank else value.strip(chr(39))}'"
    return f"{slot}={value.strip(chr(39))}"


def fold_responses(body: list[tuple[int | None, str]]
                   ) -> list[tuple[int | None, str]]:
    """Collapse a run of response assignments into one `@response` line."""
    kept: list[tuple[int | None, str]] = []
    index = 0
    while index < len(body):
        found: list[tuple[str, str]] = []
        cursor = index
        while cursor < len(body):
            span = statement_length(body, cursor)
            statement = re.sub(r"\s+", " ", " ".join(
                text.strip() for _, text in body[cursor:cursor + span]))
            match = RESPONSE_SET.match(statement)
            if not match:
                break
            found.append((RESPONSE_SLOTS[match.group("field")],
                          match.group("value")))
            cursor += span
        # A run of one counts. The four slots are usually adjacent, but a paragraph
        # that only names its outcome assigns `PSMGR-EXIT-STATE` alone - and with no
        # marker for it, `state_roles` cannot see the state being reported and the
        # Response states table calls it `compared`, which reads as "a callee produced
        # this, the program only tests for it". A reader following FORMAT.md's rule for
        # a terminal paragraph with no `@response` also concludes the envelope was left
        # alone. The marker carries whichever slots the run assigns; the rest keep
        # whatever was in them.
        if found:
            order = list(RESPONSE_SLOTS.values())
            parts = sorted(found, key=lambda pair: order.index(pair[0]))
            kept.append((body[index][0], f"{RESPONSE_MARKER} " + ", ".join(
                response_value(slot, value) for slot, value in parts)))
            index = cursor
            continue
        kept.append(body[index])
        index += 1
    return kept


# Relaying a repeating group is a loop over the filled entries whose body copies the
# same attributes one by one, from one view's entry to another's. The loop says one
# thing - this group was copied, this many entries - so it folds to one line carrying
# the bound and every source:target pair, which keeps the link between the two views
# that a reader needs and removes the per-field volume. A loop with a nested loop or any
# statement that is not a per-entry copy is doing structural work and is left alone.
COPY_LOOP_HEAD = re.compile(
    r"^PERFORM\s+VARYING\s+(?P<index>ADIM\d)\s+FROM\s+1\s+BY\s+1"
    r"\s+UNTIL\s+(?P=index)\s*>\s*(?P<bound>\S+)$")
COPY_MARKER = "*> @copy-array"


def entry_copy(statement: str, loop_index: str) -> tuple[str, str] | None:
    """``(source, target)`` if the statement copies one entry, else None."""
    match = ECHO_MOVE.match(statement) or ECHO_COMPUTE.match(statement)
    if not match:
        return None
    source, target = match.group("src"), match.group("dst")
    subscripts = [re.search(r"\(([^)]*)\)", side) for side in (source, target)]
    if not all(found and found.group(1).strip() == loop_index for found in subscripts):
        return None
    return (source.split("(")[0].strip(), target.split("(")[0].strip())


def fold_copy_arrays(body: list[tuple[int | None, str]]
                     ) -> list[tuple[int | None, str]]:
    """Collapse a per-entry copy loop into one `@copy-array` line."""
    kept: list[tuple[int | None, str]] = []
    index = 0
    while index < len(body):
        span = statement_length(body, index)
        head = COPY_LOOP_HEAD.match(statement_text(body, index, span))
        pairs, cursor = [], index + span
        if head:
            while cursor < len(body):
                inner = statement_length(body, cursor)
                statement = statement_text(body, cursor, inner)
                if statement.rstrip(".") == "END-PERFORM":
                    cursor += inner
                    break
                pair = entry_copy(statement, head.group("index"))
                if pair is None:
                    pairs = []
                    break
                pairs.append(pair)
                cursor += inner
        if head and pairs:
            copies = ", ".join(f"{source}:{target}" for source, target in pairs)
            kept.append((None, f"{COPY_MARKER}({head.group('bound')}) {copies}"))
            index = cursor
            continue
        kept.extend(body[index:index + span])
        index += span
    return kept


# A paragraph is invoked as `PERFORM <name> THRU <name>-EXIT`, where the `-EXIT`
# paragraph exists only to be the range's end and holds a single `EXIT.`. Naming it at
# the call site says nothing, and the paragraph itself is a landing pad rather than
# code. The call becomes `@paragraph <name>`, and the landing pad goes - but only when
# its body really is just `EXIT.`: 104 of them in the batch carry a statement of their
# own, and those stay.
PARAGRAPH_PERFORM = re.compile(
    r"^PERFORM\s+(?P<name>[A-Z0-9#@$-]+)\s+THRU\s+(?P=name)-EXIT$")
# The same statement with its operand missing. That is not COBOL: the analyzer's
# source occasionally loses the continuation line a wrapped `THRU` sits on - measured
# on this tree, four statements and one `-ERROR-EXIT` paragraph - and what reaches
# here is `PERFORM <name> THRU` with nothing after it. Folded like the others, because
# a `THRU` range in generated code always ends at `<name>-EXIT` and leaving a truncated
# statement in the output is indistinguishable from a syntax error in the member.
TRUNCATED_PERFORM = re.compile(r"^PERFORM\s+(?P<name>[A-Z0-9#@$-]+)\s+THRU$")
PARAGRAPH_MARKER = "*> @paragraph"
EXIT_PARAGRAPH = re.compile(r"^[A-Z0-9#@$-]+-EXIT\.$")
EXIT_BODY = {"EXIT.", "EXIT", "."}


def fold_paragraph_performs(body: list[tuple[int | None, str]]
                            ) -> list[tuple[int | None, str]]:
    """Rewrite each `PERFORM x THRU x-EXIT` as `@paragraph x`.

    The statement wraps onto a second line in 93 places, so it is joined before being
    matched. The line number stays: unlike the folded mechanisms, this is still a real
    statement at that line.
    """
    kept: list[tuple[int | None, str]] = []
    index = 0
    while index < len(body):
        span = statement_length(body, index)
        number, text = body[index]
        statement = re.sub(r"\s+", " ", " ".join(line.strip() for _, line
                                                 in body[index:index + span]))
        match = PARAGRAPH_PERFORM.match(statement) or TRUNCATED_PERFORM.match(statement)
        if match:
            if not PARAGRAPH_PERFORM.match(statement):
                print(f"  note: `{statement}` has no THRU operand in the analysed "
                      f"source (line {number}); folded as "
                      f"{PARAGRAPH_MARKER} {match.group('name')}", file=sys.stderr)
            kept.append((number, f"{PARAGRAPH_MARKER} {match.group('name')}"))
        else:
            kept.extend(body[index:index + span])
        index += span
    return kept


def drop_exit_paragraphs(body: list[tuple[int | None, str]]
                         ) -> list[tuple[int | None, str]]:
    """Remove the `-EXIT` landing pads whose whole body is `EXIT.`."""
    kept: list[tuple[int | None, str]] = []
    index = 0
    while index < len(body):
        number, text = body[index]
        if is_paragraph(text) and EXIT_PARAGRAPH.match(text.strip()):
            end = index + 1
            while end < len(body) and not is_paragraph(body[end][1]):
                end += 1
            if all(line.strip() in EXIT_BODY for _, line in body[index + 1:end]):
                index = end
                continue
        kept.append(body[index])
        index += 1
    return kept


def fold_escapes(body: list[tuple[int | None, str]]) -> list[tuple[int | None, str]]:
    """Drop the entry reset; keep the raise and the check as markers."""
    kept: list[tuple[int | None, str]] = []
    labels = paragraph_labels(body)
    index = 0
    while index < len(body):
        kind, span, name = escape_at(body, index, labels)
        if kind == "check":
            # The generator emits the check after every branch, without noticing that
            # the branch just raised. A check standing immediately after an escape that
            # names the same paragraph can never fire - that paragraph has already
            # returned - so it is dropped rather than left for a reader to puzzle over.
            if not (kept and kept[-1][1].startswith(ESCAPE_MARKER)
                    and name in kept[-1][1]):
                kept.append((None, f"{ESCAPE_CHECK_MARKER} {name}"))
        elif kind == "raise":
            raised = [name]
            while index + span < len(body):
                following, next_span, next_name = escape_at(body, index + span, labels)
                if following != "raise":
                    break
                raised.append(next_name)
                span += next_span
            kept.append((None, f"{ESCAPE_MARKER} returns from "
                               + ", ".join(raised)))
        elif kind is None:
            kept.append(body[index])
        index += span or 1
    return kept


ESCAPE_MAX_LINES = 5


def paragraph_labels(body: list[tuple[int | None, str]]) -> set[str]:
    """Every paragraph name in this body, as the member writes it."""
    return {text.strip().rstrip(".") for number, text in body
            if number is not None and is_paragraph(text)}


def resolve_label(name: str, labels: set[str]) -> str:
    """The paragraph this escape refers to, as a name the document actually has.

    A flag is named after the construct that owns it, and the paragraph is usually
    `PARA-<id>` - but not always: the generator sometimes emits the construct's body
    as `PARA-<id>-INIT-BYPASS` and no plain `PARA-<id>` exists at all. Naming the one
    that is not there makes the marker a dangling reference, and a reader cannot then
    tell whether the paragraph was folded away or never existed.
    """
    if not labels or name in labels:
        return name
    near = sorted(label for label in labels if label.startswith(name + "-"))
    return near[0] if len(near) == 1 else name


def owning_paragraph(flag: str, labels: set[str] | None = None) -> str:
    """The paragraph an escape flag belongs to, named as the member names it."""
    owner = ESCAPE_OWNER.match(flag[:-len("-ESC-FLAG")])
    name = f"PARA-{owner.group('id')}" if owner else flag[:-len("-ESC-FLAG")]
    return resolve_label(name, labels or set())


def escape_at(body: list[tuple[int | None, str]], index: int,
              labels: set[str] | None = None) -> tuple[str | None, int, str]:
    """``(kind, lines, name)`` for the escape construct here, else ``(None, 0, "")``.

    ``name`` is the paragraph the construct refers to: for a raise, the one whose flag
    is being set; for a check, the one it returns from.
    """
    text = body[index][1].strip()
    if text.startswith("IF ") and "-ESC-FLAG" in text:
        parts = []
        for offset in range(min(ESCAPE_MAX_LINES, len(body) - index)):
            parts.append(body[index + offset][1].strip())
            if parts[-1] == "END-IF":
                statement = re.sub(r"\s+", " ", " ".join(parts))
                found = ESCAPE_CHECK.match(statement)
                if not found:
                    return None, 0, ""
                return ("check", offset + 1,
                        resolve_label(found.group("target"), labels or set()))
        return None, 0, ""
    span = statement_length(body, index)
    statement = re.sub(r"\s+", " ", " ".join(line.strip() for _, line
                                             in body[index:index + span]))
    if ESCAPE_RESET.match(statement):
        return "reset", span, ""
    raised = ESCAPE_RAISE.match(statement)
    if raised:
        return "raise", span, owning_paragraph(raised.group("flag"), labels)
    return None, 0, ""


def statement_length(body: list[tuple[int | None, str]], index: int) -> int:
    """How many lines the statement at this position spans, continuations included."""
    span = 1
    while (index + span < len(body)
           and not starts_statement(body[index + span][1])
           and body[index + span][0] is not None):
        span += 1
    return span


def fold_exception_checks(body: list[tuple[int | None, str]]
                          ) -> list[tuple[int | None, str]]:
    """Collapse each generated status check to one marker.

    The check spans five physical lines, so a window is joined and matched as one
    statement; anything that is not the canonical shape is left exactly as it was.
    """
    kept: list[tuple[int | None, str]] = []
    index = 0
    while index < len(body):
        consumed = check_length(body, index)
        if consumed:
            kept.append((None, EXCEPTION_MARKER))
        else:
            kept.append(body[index])
        index += consumed or 1
    return kept


def check_length(body: list[tuple[int | None, str]], index: int) -> int:
    """How many lines the canonical status check occupies here, or 0 if it is not one."""
    first = body[index][1].strip()
    if not first.startswith("IF ") or "STATUS-FLAG" not in first:
        return 0
    parts = []
    for offset in range(min(CHECK_MAX_LINES, len(body) - index)):
        parts.append(body[index + offset][1].strip())
        if parts[-1] == "END-IF":
            statement = re.sub(r"\s+", " ", " ".join(parts))
            return offset + 1 if EXCEPTION_CHECK.match(statement) else 0
    return 0


def is_comment(text: str) -> bool:
    body = text[6:7] if len(text) > 6 else ""
    return body in ("*", "/") or text.lstrip().startswith(("*", "/"))


def drop_design_trailer(lines: list[str]) -> list[str]:
    """Cut the trailing model-definition comment block, if the member has one.

    It is a contiguous run of comments at the end of the member, so the run is found
    from the end and cut at the line that opens the block. A member without one - any
    hand-written module - is returned untouched.
    """
    end = len(lines)
    while end and (not lines[end - 1].strip() or is_comment(lines[end - 1])):
        end -= 1
    trailer = range(end, len(lines))
    start = next((index for index in trailer
                  if DESIGN_BLOCK_OPEN in lines[index]), None)
    if start is None or not any(DESIGN_BLOCK_CLOSE in lines[index]
                                for index in trailer):
        return lines
    return lines[:start]


def is_outbound(view: str) -> bool:
    """True when a parameter view carries data back out of the program."""
    words = set(view.split("-"))
    return view == EXPORT_VIEW or bool(
        VIEW_SUFFIX.search(view) and words & OUTBOUND_WORDS
        and not words & INBOUND_WORDS)


OCCURS_DECLARATION = re.compile(
    r"^\d\d\s+(?P<name>[A-Z0-9#@$][A-Z0-9#@$-]*)\b.*\bOCCURS\s+(?P<times>\d+)")


def parse_occurs(lines: list[str]) -> dict[str, int]:
    """``group -> how many entries it holds`` for every repeating element declared."""
    found: dict[str, int] = {}
    for line in lines:
        if re.search(r"\bPROCEDURE\s+DIVISION\b", line):
            break
        if is_comment(line):
            continue
        entry = OCCURS_DECLARATION.match(line[:CODE_END].strip())
        if entry:
            found[entry.group("name")] = int(entry.group("times"))
    return found


def array_of(owner: str) -> str:
    """The repeating element a field sits inside, from its owner path, or "".

    CA Gen wraps a repeating group in a `...RG` level holding an entry counter beside
    the element that carries the `OCCURS`. The element has to be a strict ancestor of
    the field: the counter is declared directly under the wrapper and counts entries
    rather than having one.
    """
    parts = owner.split(".")
    for index in range(len(parts) - 3, -1, -1):
        if REPEATING_WRAPPER.search(parts[index]):
            return parts[index + 1]
    return ""


_ANALYZERS: dict[tuple[int, str], tuple[Facts, Analyzer]] = {}
# `mu.yaml` `boundaries` of the run's `--mu`: the analysis stops at them.
_BOUNDARIES: frozenset[str] = frozenset()


def analyzer_for(facts: Facts, program: str) -> Analyzer:
    """The view-usage analysis of one program, computed once per run.

    `Analyzer.run()` discovers and walks the whole call tree below `program`, which
    is the expensive part of an extraction. Three places need its verdicts - the
    contract tables, the dropped-field table and the echo fold - and each used to
    build and run its own, so every document cost three walks of the same tree.
    The HTTP responses were already cached; the graph was not.
    """
    key = (id(facts), program)
    found = _ANALYZERS.get(key)
    if found is not None and found[0] is facts:
        return found[1]
    analyzer = Analyzer(facts, program, quiet=True, stop=_BOUNDARIES)
    analyzer.run()
    # The Facts object is kept beside the analyzer so that a recycled `id()` cannot
    # hand back an analysis built from a different server.
    _ANALYZERS[key] = (facts, analyzer)
    return analyzer


def contract(facts: Facts, program: str) -> list[tuple[str, str, str, str]]:
    """``(direction, field, type, repeats)`` for the program's contract.

    This is the *filtered* contract - the same answer `analyze_view_usage` publishes in
    `analyze_view_usage.py`, with the fields nothing reads and the fields nothing
    populates already dropped, and with the shared control block included. The declared
    list is a different thing and is not what a reader of this document wants: it
    carries request-header fields that no code below ever looks at.

    `repeats` places a field in its repeating group - `GROUP-EXPORT-WIP-0004[200]` - or
    marks the group's entry counter, so one entry of a 200-row array is not presented as
    a single value.
    """
    occurs = parse_occurs(facts.source(program, 1, 99999))
    counters = {element + "MA": element for element in occurs}
    analyzer = analyzer_for(facts, program)
    rows = []
    # A field can be in the contract because something far below reads it while this
    # program never touches it: declared in a view, never moved, computed or tested.
    # The document is about this program, so those are left out.
    handled = statement_names(facts, program)
    # `caller_reach` used to prune here: an input no path reaches a decision with was
    # dropped as carrying nothing. It is not used for that any more. Measured over nine
    # programs it removed eleven fields and was wrong about at least nine of them -
    # including all five of `F7549T02`'s cascade flags, which its whole logic is a
    # decision on, leaving that program's `Inputs` table empty. A walk over flattened
    # generated COBOL mis-parses one paragraph and then reports a confident "dead", and
    # a contract table is the wrong place to carry that risk: a reader who trusts an
    # empty table gives the program no input at all.
    for direction in ("import", "export"):
        for leaf, verdict in view_contract(analyzer, program, direction):
            if not verdict.used:
                continue
            element = array_of(leaf.path)
            if leaf.name in counters:
                repeats = f"entry count of `{counters[leaf.name]}`"
            elif element:
                repeats = f"`{element}[{occurs.get(element, '?')}]`"
            else:
                repeats = ""
            if leaf.name not in handled:
                continue
            rows.append(("in" if direction == "import" else "out",
                         leaf.name, pseudo_type(leaf.pic), repeats))
    return rows


def state_roles(body: list[tuple[int | None, str]]) -> dict[str, str]:
    """Which exit states the program reports, as against those it only tests.

    A state named by `@response` is an outcome this program produces. Every other
    declared state is a comparand - the answer a callee gave, which this program maps
    to something of its own - and reading them as possible outcomes gets the program
    backwards.
    """
    emitted = set()
    for _, text in body:
        found = re.search(r"state=(?P<state>EX-\S+?)(?:,|$)", text)
        if text.startswith(RESPONSE_MARKER) and found:
            emitted.add(found.group("state"))
    return {state: "emitted" for state in emitted}


def exit_states(facts: Facts, program: str) -> list[tuple[str, str]]:
    """``(name, code)`` for each exit state the program declares, in declaration order.

    An exit state is a generated level-01 constant holding the number the model
    assigned to a named outcome - `EX-PROCESSING-OK0001 PIC S9(10) VALUE 174326164`.
    The name documents it and the number is what travels, so both are reported: a
    caller comparing against the number is comparing against this name.
    """
    found = []
    for struct in facts.structures(program):
        if not struct["name"].startswith("EX-"):
            continue
        for entry in facts.structure(program, struct["name"]):
            if entry["name"] == struct["name"]:
                found.append((entry["name"], entry.get("defaultValues") or "",
                              entry.get("srcLine") or 0))
    return [(name, code) for name, code, _ in sorted(found, key=lambda e: e[2])]


# A doubled hyphen is not a typo: a generated name truncated to 30 bytes keeps its
# suffix and loses the middle, so `OTHER-INC-EXP-FINANC-AMT--0030` and `R4---JUST`
# are ordinary names. A pattern that allows only single hyphens matches the first
# segment and stops, and the field then reads as one the code never mentions.
NAME_IN_CODE = re.compile(r"[A-Z][A-Z0-9#@$]*(?:-+[A-Z0-9#@$]+)*")

# The SQL communication area, which `EXEC SQL INCLUDE SQLCA` brings in: `SQLCA`
# itself, `SQLCODE`, `SQLERRD` and the rest. Left out of the locals table for the same
# reason the parameter views are - it is not this program's declaration - and because
# it only appears at all when the analyzer expanded the include, which varies between
# members. Matched on the name rather than on the parse's parentage: the expanded block
# has no explicit end, so the declarations that follow it are read as its children and
# excluding by parent would take the program's own host variables with it.
SQLCA_FIELD = re.compile(r"^SQL[A-Z0-9-]*$")

# The declarations are parsed from the member rather than taken from the analyzer's
# structure inventory, which does not report the generated runtime working-storage
# block: `DATA-PRESENT`, `DATA-MISSING`, `ESCAPE-SW`, the `ADIM` subscripts and the
# other registers are all missing from it, and the surviving code names several of
# them. Parsing also picks up level-88 condition names, which is where constants like
# `FATAL-ERROR` and `SUCCEEDS` get their values.
DECLARATION = re.compile(
    r"^(?P<level>\d\d)\s+(?P<name>[A-Z0-9#@$][A-Z0-9#@$-]*)(?P<rest>\s.*)?$")
PIC_CLAUSE = re.compile(r"\bPIC(?:TURE)?\s+(?:IS\s+)?(?P<pic>[^\s.]+)")
VALUE_CLAUSE = re.compile(r"\bVALUE\s+(?:IS\s+)?(?P<value>'[^']*'|[^\s.]+)")


def parse_declarations(lines: list[str]
                       ) -> dict[str, tuple[str, str, str, tuple[str, ...]]]:
    """``name -> (root, type, value)`` for every field the member declares.

    A declaration runs to its terminating period and wraps freely, so lines are
    accumulated until one ends with it. The level numbers give the nesting, which is
    what identifies the level-01 a field belongs to - needed to tell a parameter view's
    field from a local one.
    """
    found: dict[str, tuple[str, str, str, tuple[str, ...]]] = {}
    stack: list[tuple[int, str]] = []
    buffer: list[str] = []
    for line in lines:
        if re.search(r"\bPROCEDURE\s+DIVISION\b", line):
            break
        if is_comment(line) or not line[:CODE_END].strip():
            continue
        buffer.append(line[:CODE_END].strip())
        if not buffer[-1].endswith("."):
            continue
        statement = re.sub(r"\s+", " ", " ".join(buffer)).rstrip(".")
        buffer = []
        entry = DECLARATION.match(statement)
        if not entry:
            continue
        level, name = int(entry.group("level")), entry.group("name")
        rest = entry.group("rest") or ""
        if level != 88:
            while stack and stack[-1][0] >= level:
                stack.pop()
        pic = PIC_CLAUSE.search(rest)
        value = VALUE_CLAUSE.search(rest)
        root = stack[0][1] if stack else name
        if name != "FILLER" and name not in found:
            kind = ("condition" if level == 88
                    else pseudo_type(pic.group("pic")) if pic else "group")
            found[name] = (root, kind, (value.group("value") if value else ""),
                           tuple(parent for _, parent in stack))
        if level != 88 and not pic:
            stack.append((level, name))
    return found


MODEL_NAME = re.compile(r"MOVE\s+'(?P<name>[A-Z0-9_]+)'\s+TO\s+CUR-AB-NAME")


def model_name(facts: Facts, program: str) -> str:
    """The name the model gave this program, or "".

    Every generated program announces itself for diagnostics -
    `MOVE 'REVOL_DIR_WIP_MAINT_S' TO CUR-AB-NAME` - and that literal is the only place
    the member says what the program is called in the model. The statement itself is
    dropped as write-only bookkeeping, so the name is lifted out before it goes: it is
    what a reader, or a translation, needs in order to call the program something other
    than its number.
    """
    for raw in facts.source(program, 1, 99999):
        found = MODEL_NAME.search(raw.upper())
        if found:
            return found.group("name")
    return ""


def statement_names(facts: Facts, program: str) -> set[str]:
    """Every name the procedure division mentions, before any folding.

    Taken from the member rather than from the extracted body: a statement this tool
    folds away - a pass-through copy, a cleared group - still proves the program handles
    the field, and the question here is whether it does anything with it at all.
    """
    names: set[str] = set()
    started = False
    for raw in facts.source(program, 1, 99999):
        body = raw[6:72] if len(raw) > 6 else ""
        if not body.strip() or body[0:1] in ("*", "/"):
            continue
        text = (body[1:] if body[0:1] == "-" else body).upper()
        if not started:
            started = bool(re.search(r"\bPROCEDURE\s+DIVISION\b", text))
            continue
        for name in NAME_IN_CODE.findall(text):
            names.add(name)
            if name.endswith(("XX", "AS")) and len(name) > 2:
                names.add(name[:-2])          # the alias stands for its field
    return names


def used_names(body: list[tuple[int | None, str]]) -> set[str]:
    """Names that appear in a statement, not in a marker.

    A marker's field list is this tool's own expansion: the source named a view, and
    `@call` and `@copy-array` spell out what is inside it. Counting those as the code
    mentioning a field made the locals table describe the callee's contract instead of
    this program's work - 249 of P7549509's 323 rows, against about 30 that its
    statements actually handle. `@initialize` is excluded for a different reason: the
    Initializers section already reports each group and the fields it blanks.

    A field that only travels through a call therefore has no type here. It has one in
    the callee's own extracted-logic document, where it is an input or an output - which is
    where a reader should look for it, since it is the callee's field.
    """
    names: set[str] = set()
    for _, text in body:
        if text.lstrip().startswith("*>"):
            continue
        names.update(NAME_IN_CODE.findall(text.upper()))
    return names


def declarations(facts: Facts, program: str,
                 body: list[tuple[int | None, str]]) -> list[tuple[str, str, str, str]]:
    """``(name, type, value, repeats)`` for each local or constant the surviving code names.

    Everything a program declares beyond its parameter views is local: working storage,
    the local views the generator builds to marshal a call, the constants it compares
    against. Most of it goes unmentioned once the generated mechanisms are folded away,
    so only names that still appear are listed - a declaration nothing refers to tells
    a reader nothing, and the point of this document is that it can be read.

    Parameter fields are already in the interface tables, `GLOBDATA` is the shared
    control block rather than this program's own storage, and the exit states have a
    table of their own.
    """
    used = used_names(body)
    parameters = set(facts.parameters(program)) | {SHARED_PARAM}
    lines = facts.source(program, 1, 99999)
    declared = parse_declarations(lines)
    occurs = parse_occurs(lines)
    counters = {element + "MA": element for element in occurs}
    rows = []
    for name, (root, kind, value, path) in declared.items():
        if (name not in used or root in parameters or name.startswith("EX-")
                or is_plumbing(name) or SQLCA_FIELD.match(name)):
            continue
        element = array_of(".".join(path + (name,)))
        if name in counters:
            repeats = f"entry count of `{counters[name]}`"
        elif element:
            repeats = f"`{element}[{occurs.get(element, '?')}]`"
        else:
            repeats = ""
        rows.append((name, kind, value, repeats))
    return rows


def dropped_fields(facts: Facts, program: str, kept: set[str],
                   handled: set[str]) -> list[tuple[str, str, str, str]]:
    """``(name, type, direction, why)`` for view fields the statements name and the
    contract left out.

    A field can be in a parameter view, be moved or computed by this program, and
    still carry nothing: the value reaches no read anywhere in the analysed tree, or
    nothing ever fills it. The contract tables are about what travels, so those are
    not in them - but a reader of the paragraphs below meets the name and has no way
    to tell a dropped view field from an undeclared local, and the two have different
    consequences. One arrives from the caller; the other is always zero.

    The shared control block is left out: its diagnostics and failure flags are
    excluded from the contract by decision rather than by measurement, and listing
    them here would put them back in front of a reader who was told they do not
    matter. Same for the clock and the runtime scratch families.
    """
    analyzer = analyzer_for(facts, program)
    rows: list[tuple[str, str, str, str]] = []
    seen: set[tuple[str, str]] = set()
    for direction in ("import", "export"):
        for leaf, verdict in view_contract(analyzer, program, direction):
            root = leaf.path.split(".")[0] if leaf.path else leaf.view
            way = "in" if direction == "import" else "out"
            if (verdict.used or leaf.name in kept or leaf.name not in handled
                    or root in RUNTIME_PARAMS or root == SHARED_PARAM
                    or is_plumbing(leaf.name)
                    or SCRATCH_FAMILIES.match(leaf.name)
                    or base_name(leaf.name) in INFRASTRUCTURE_FIELDS
                    or (leaf.name, way) in seen):
                continue
            seen.add((leaf.name, way))
            rows.append((leaf.name, pseudo_type(leaf.pic), way, verdict.reason))
    return rows


def procedure_division(facts: Facts, program: str,
                       contracted: set[str]) -> list[tuple[int | None, str]]:
    """The procedure division, as ``(line number, text)`` pairs.

    The whole member is fetched in one request and cut at the division header, which
    keeps the line numbers honest: they are the numbers the member itself uses, not an
    offset into what was returned. That matters more once comments and blank lines are
    gone, since the result no longer reads as a continuous listing - a jump in the
    numbers is where the generator's banners were.

    ``contracted`` is the set of field names the contract tables carry, which is what
    decides whether a pass-through copy is folded away; it is passed in rather than
    recomputed, since computing it analyses the whole call tree.
    """
    lines = drop_design_trailer(facts.source(program, 1, 99999))
    start = next((index for index, text in enumerate(lines)
                  if PROCEDURE_DIVISION in text and not is_comment(text)),
                 None)
    if start is None:
        raise FactsError(f"{program}: no {PROCEDURE_DIVISION} found")
    body = [(index + 1, code) for index, code in
            ((index, lines[index][:CODE_END].rstrip())
             for index in range(start, len(lines)))
            if code.strip() and not is_comment(lines[index])
            and not BREADCRUMB.match(code.strip())
            and not IDENTITY.match(code.strip())
            and not PRE_CALL.match(code.strip())]
    fields = group_fields(facts, program)
    direction = view_directions(facts, program)
    folds = (fold_validation, fold_exception_checks, fold_escapes,
             lambda lines_in: fold_echoes(lines_in, direction, contracted),
             fold_responses, drop_empty_loops, fold_copy_arrays,
             fold_durations, fold_initializers, merge_group_cursors,
             lambda lines_in: fold_calls(lines_in, fields, facts, program),
             fold_paragraph_performs, drop_exit_paragraphs)
    for fold in folds:
        body = fold(body)
    return body


def paragraphs(body: list[tuple[int | None, str]]
               ) -> list[tuple[str, int | None, list[tuple[int | None, str]]]]:
    """The body split into ``(heading, heading line, lines)`` sections, one per paragraph.

    The heading's own line number travels with the section. Looking it up afterwards by
    searching the body for the name is what produced ranges that overlapped: a wrapped
    `PERFORM x THRU` puts the target's name alone on its continuation line, and
    `PARA-0668885894-0668885871-INX` was found at the continuation 43 lines above the
    paragraph it names.
    """
    sections: list[tuple[str, int | None, list[tuple[int | None, str]]]] = []
    for number, text in body:
        if number is not None and is_paragraph(text):
            sections.append((text.strip().rstrip("."), number, []))
        elif sections:
            sections[-1][2].append((number, text))
        else:
            sections.append(("", None, [(number, text)]))
    return sections


def span_of(first: int | None, lines: list[tuple[int | None, str]]) -> str:
    """The source line range a paragraph covers, as it reads in the member."""
    if first is None:
        return ""
    numbers = [number for number, _ in lines if number is not None]
    last = max([first] + numbers)
    return f"{first}-{last}" if last != first else str(first)


# ---------------------------------------------------------------------------
# `--index` writes a machine-readable record of every paragraph beside the
# extracted-logic documents: its line range, whether it carries business content, and
# the SQL, calls, functions and outcomes in it. It holds nothing the documents do not
# already state - it exists so that a tool can read them without parsing Markdown.
#
# Three things consume it. `mu-design` checks that every business paragraph ends in a
# `From` cell of `rules.md` or in its exempt list, which is the mechanical form of
# "Paragraphs that produced no rule". An implementer copies the member, paragraph and
# line range out of it into the citation on the code - the range is the one part of a
# citation nobody can recall and the part that goes stale silently. And the
# architecture skill's `validate_traceability.py` checks the citations in the code
# against it, which is what makes "all of it is migrated" a claim someone can check
# rather than assert.
#
# The records carry names, counts and markers, never statement text, so the index is
# readable under `mu-design`'s rule that the COBOL stays out of the design's context.
# ---------------------------------------------------------------------------

# A word that is a whole statement and does nothing a reader has to trace.
NOOP_WORDS = {"GOBACK", "CONTINUE", "EXIT", "", "."}

# A marker standing for business content: an outcome reported, a failure raised, a
# callee invoked, a computation performed. A paragraph holding one of these and no
# statement at all still does something, and 37 paragraphs in the measured tree are
# exactly that - most of them a lone `@response`, which is a response code the caller
# receives. Classifying those as mechanism is the one error that matters here, because
# it excuses a live outcome from the check.
BUSINESS_MARKERS = ("@response", "@fail", "@call", "@function", "@date-add",
                    "@copy-array")

# The rest of the vocabulary in `FORMAT.md` is generated plumbing and is not content on
# its own: `@validation` and `@initialize` are setup, `@exception-check` and
# `@escape-check` are the generated stand-in for an exception, `@paragraph` is a
# transfer of control, and `@escape` is an early return. A paragraph whose whole body
# is one `@escape` is the escape stub of a skip - 16 of them in the measured tree - and
# the decision that performs it lives in the performing paragraph, which carries
# statements and is therefore business. The behaviour stays traceable through that one.

# `INDEX_` because the folds above already own `CALL_MARKER`, `FUNCTION_MARKER` and
# `RESPONSE_MARKER` as the literal strings they emit. These read the emitted markers
# back; they are the other direction and must not shadow them.
INDEX_SQL = re.compile(r"^EXEC\s+SQL\s+(?P<verb>[A-Z]+)")
INDEX_CALL = re.compile(r"@call\s+(?P<target>[A-Z0-9#@$]+)")
INDEX_FUNCTION = re.compile(r"@function\s+(?P<module>[A-Z0-9]+)")
INDEX_RESPONSE = re.compile(r"@response\s+state=(?P<state>[^,\s]+)")
INDEX_PERFORM = re.compile(r"@paragraph\s+(?P<name>\S+)")


def effective_statements(lines: list[tuple[int | None, str]]) -> list[str]:
    """The statements left once markers, periods and no-ops are discounted.

    An `EXEC SQL DECLARE … END-EXEC` counts. It reads like a declaration rather than
    an effect, and discounting it turned every generated MAIN shell that carries a
    cursor DECLARE into mechanism - but the DECLARE is where the query text lives, so
    the table, the columns and the predicate are all inside it. That is the most
    traceable content a cursor family has, and the shell is where it sits.
    """
    out: list[str] = []
    for _, text in lines:
        stripped = text.strip()
        if not stripped or stripped.startswith("*>"):
            continue
        if stripped.rstrip(".").strip() in NOOP_WORDS:
            continue
        out.append(stripped)
    return out


def paragraph_kind(name: str, lines: list[tuple[int | None, str]]) -> tuple[str, str]:
    """`business` or `mechanism`, and why, for one paragraph.

    Structural and deliberately biased: anything holding a statement or a business
    marker is `business`. Scored against 898 paragraphs classified by hand over a
    104-program tree, this agrees on 686 and errs towards `business` on 196 of the
    remaining 212 - cursor `-OPEN`/`-FETCH`/`-CLOSE` families and MAIN shells carrying
    a cursor DECLARE, which a reviewer exempts because one repository method covers the
    family. Those cost a citation each. The other 16 are the escape stubs above.

    The bias is the point. A paragraph wrongly called `business` asks the implementer
    for a citation it did not need; a paragraph wrongly called `mechanism` is dropped
    from the check that would have noticed it was never migrated. Do not correct the
    bias by reclassifying - exempt the paragraph where a reviewer can see it, in
    `rules.md` "Paragraphs that produced no rule" or an `--allow` file.
    """
    if name.startswith("SUBSTR-ERROR-"):
        return "mechanism", "substring bound error landing pad"
    if effective_statements(lines):
        return "business", ""
    markers = sorted({marker for _, text in lines
                      for marker in BUSINESS_MARKERS if marker in text})
    if markers:
        return "business", "marker only: " + ", ".join(markers)
    return "mechanism", "no statement or business marker"


def paragraph_record(name: str, first: int | None,
                     lines: list[tuple[int | None, str]]) -> dict:
    """One paragraph's index entry: where it is, what it does, whether it must trace."""
    kind, why = paragraph_kind(name, lines)
    text = [stripped for _, raw in lines if (stripped := raw.strip())]
    statements = effective_statements(lines)
    record: dict = {
        "name": name,
        "lines": [first, max([first] + [n for n, _ in lines if n is not None])]
                 if first is not None else None,
        "kind": kind,
        "statements": len(statements),
    }
    if why:
        record["why"] = why
    sql = [m.group("verb") for line in statements if (m := INDEX_SQL.match(line))]
    for key, found in (
            ("sql", sql),
            ("calls", [m.group("target") for line in text
                       if (m := INDEX_CALL.search(line))]),
            ("functions", [m.group("module") for line in text
                           if (m := INDEX_FUNCTION.search(line))]),
            ("responses", [m.group("state") for line in text
                           if (m := INDEX_RESPONSE.search(line))]),
            ("performs", [m.group("name") for line in text
                          if (m := INDEX_PERFORM.search(line))])):
        if found:
            record[key] = sorted(set(found))
    return record


def index_entry(program: str, model: str,
                body: list[tuple[int | None, str]]) -> dict:
    """The index record for one program.

    Built from the same `paragraphs(body)` the document is rendered from, so the ranges
    here and the `## Paragraph NAME (a-b)` headings cannot disagree.
    """
    records = [paragraph_record(name, first, lines)
               for name, first, lines in paragraphs(body) if name]
    return {
        "model": model,
        "paragraphs": records,
        "business": sum(1 for r in records if r["kind"] == "business"),
        "mechanism": sum(1 for r in records if r["kind"] == "mechanism"),
    }


def merge_index(path: Path, program: str, entry: dict) -> None:
    """Add one program to the index, keeping whatever other programs are in it.

    An MU is extracted one program per process, so the index has to accumulate across
    runs rather than be written once. Re-extracting a program replaces its entry and
    leaves the rest of the MU alone. A corrupt index is reported and replaced rather
    than failing the extract: the document is the deliverable, the index is derived
    from it and can always be rebuilt by re-extracting the MU.
    """
    index: dict = {"programs": {}}
    if path.exists():
        try:
            loaded = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(loaded.get("programs"), dict):
                index = loaded
        except (json.JSONDecodeError, OSError) as exc:
            print(f"{path}: unreadable, starting a new index ({exc})",
                  file=sys.stderr)
    index["programs"][program] = entry
    index["programs"] = dict(sorted(index["programs"].items()))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(index, indent=1) + "\n", encoding="utf-8")


# Closing a block is the one place the flat generated code changes subject, so the
# extracted form breathes there.
BLOCK_END = ("END-EVALUATE", "END-PERFORM", "END-IF")
BLOCK_START = ("IF", "EVALUATE", "PERFORM")


def dedent_block(lines: list[tuple[int | None, str]]) -> list[str]:
    """Remove the fixed area-B padding, keeping whatever nesting a line really has.

    Generated code sits flat - the body of an `IF` is at the same column as the `IF` -
    so there is nothing to lose there, but a hand-written module indents for real.
    Taking the common prefix off every line rather than stripping each one keeps that
    structure. Markers start at column 0 already and are not counted.
    """
    code = [text for _, text in lines
            if text.strip() and not text.lstrip().startswith("*>")]
    padding = min((len(text) - len(text.lstrip()) for text in code), default=0)
    out: list[str] = []
    for _, text in lines:
        line = text if text.lstrip().startswith("*>") else text[padding:].rstrip()
        if (line.strip().split(" ", 1)[0] in BLOCK_START
                and out and out[-1].strip()):
            out.append("")
        out.append(line)
        if line.strip().rstrip(".") in BLOCK_END:
            out.append("")
    return out


def render(program: str, model: str, rows: list[tuple[str, str, str, str]],
           dropped: list[tuple[str, str, str, str]],
           states: list[tuple[str, str]], roles: dict[str, str],
           locals_used: list[tuple[str, str, str, str]],
           initialisers: list[tuple[str, list[str]]],
           body: list[tuple[int | None, str]]) -> list[str]:
    title = f"# {program}" + (f" - {model}" if model else "")
    out = [title, "",
           "Extracted from the member: declarations, comments, the model-definition "
           "trailer and the generated bookkeeping are gone. Each paragraph carries the "
           "line range it occupies in the source. `*> @...` marks a generated mechanism "
           "that was folded away.", ""]
    for direction, title in (("in", "Inputs"), ("out", "Outputs")):
        fields = [row[1:] for row in rows if row[0] == direction]
        out.extend([f"## {title}", ""])
        if not fields:
            out.extend(["(none)", ""])
            continue
        out.append("| Name | Type | Repeats |")
        out.append("|---|---|---|")
        out.extend(f"| `{name}` | {kind} | {repeats} |"
                   for name, kind, repeats in fields)
        out.append("")
    if dropped:
        out.extend([
            "## Dropped from the contract", "",
            "Parameter-view fields the statements below name, left out of the tables "
            "above because nothing in the analysed tree consumes the value or fills "
            "it. They are view fields all the same: an input arrives from the caller "
            "and goes no further, an output is written and read by nobody. Meeting "
            "one in a paragraph and taking it for an undeclared local is the mistake "
            "this table exists to prevent.", "",
            "| Name | Type | Direction | Why |", "|---|---|---|---|"])
        out.extend(f"| `{name}` | {kind} | {way} | {why} |"
                   for name, kind, way, why in dropped)
        out.append("")
    out.extend(["## Locals and constants", ""])
    if locals_used:
        out.append("| Name | Type | Value | Repeats |")
        out.append("|---|---|---|---|")
        out.extend(f"| `{name}` | {kind} | {value} | {repeats} |"
                   for name, kind, value, repeats in locals_used)
    else:
        out.append("(none)")
    out.append("")
    out.extend(["## Initializers", "",
                "`@initialize <group>` clears the group before it is filled: text "
                "fields become spaces, numeric fields become zero. These are working "
                "storage reused by every call, so a field the program does not set "
                "reaches the callee blank rather than holding the previous call's "
                "value.", ""])
    if initialisers:
        out.append("| Group | Fields cleared |")
        out.append("|---|---|")
        out.extend(f"| `{group}` | {', '.join(f'`{f}`' for f in fields) or '(none)'} |"
                   for group, fields in initialisers)
    else:
        out.append("(none)")
    out.append("")
    out.extend(["## Response states", ""])
    if states:
        out.append("| State | Code | Role |")
        out.append("|---|---|---|")
        out.extend(f"| `{name}` | {code} | {roles.get(name, 'compared')} |"
                   for name, code in states)
    else:
        out.append("(none)")
    out.append("")
    for name, first, lines in paragraphs(body):
        heading = f"## Paragraph {name} ({span_of(first, lines)})" if name else \
            "## Linkage"
        out.extend([heading, "", "```cobol"])
        out.extend(dedent_block(lines))
        out.extend(["```", ""])
    return out


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("program", help="program name, e.g. P7549500")
    add_url_argument(parser)
    parser.add_argument("--portfolio", default="2")
    parser.add_argument("--pds", default="SRC")
    parser.add_argument("--cache-dir", default=Path(".cache/mfanalyzer"), type=Path)
    parser.add_argument("-o", "--out", type=Path,
                        help="write here instead of standard output")
    parser.add_argument("--index", type=Path,
                        help="add this program to the traceability index at this "
                             "path, creating or extending it; one index per MU")
    parser.add_argument("--mu", type=Path,
                        help="MU folder: do not analyse through its mu.yaml boundaries")
    args = parser.parse_args()

    global _BOUNDARIES  # noqa: PLW0603 - one run, one MU
    _BOUNDARIES = mu_boundaries(args.mu)
    program = args.program.upper()
    try:
        facts = Facts(portfolio=args.portfolio, pds=args.pds,
                      cache_dir=args.cache_dir, url=args.url, auth=args.auth)
        rows = contract(facts, program)
        kept = {row[1] for row in rows}
        body = procedure_division(facts, program, kept)
        model = model_name(facts, program)
        text = "\n".join(render(program, model, rows,
                                dropped_fields(facts, program, kept,
                                               statement_names(facts, program)),
                                exit_states(facts, program),
                                state_roles(body),
                                declarations(facts, program, body),
                                initialized_groups(
                                    body, parse_declarations(
                                        facts.source(program, 1, 99999))),
                                body)) + "\n"
    except FactsError as exc:
        print(f"{program}: {exc}", file=sys.stderr)
        return 1

    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(text)
        print(f"wrote {args.out}", file=sys.stderr)
    else:
        sys.stdout.write(text)

    if args.index:
        entry = index_entry(program, model, body)
        merge_index(args.index, program, entry)
        print(f"indexed {program}: {entry['business']} business, "
              f"{entry['mechanism']} mechanism -> {args.index}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
