#!/usr/bin/env python3
"""Check the folds and the markers against hand-written generated-COBOL fragments.

    python selftest.py

No MFLens, no network, no cache: every case here is a literal source fragment and the
marker it has to produce, so this runs on a machine that is not signed in. What it
covers is the half of the skill that is pure text - the folds in `extract_logic`, the
`@call` pairing, the response envelope, the declaration parse - which is where a
regression is silent. A fold that stops matching does not fail: it leaves the generated
mechanism in the output, or drops a marker a reader is told to rely on, and the
document still looks right.

What it cannot cover is the half that depends on the server: the lineage verdicts
behind `Inputs` and `Outputs`, and the layout of the analyzer's responses. A fake
stands in for the data-structure inventory where a fold needs one.

Add a case whenever a marker changes shape, and run this before committing a script.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import extract_logic as E  # noqa: E402

AREA_B = " " * 11
failures: list[str] = []


def check(what: str, got, want) -> None:
    if got != want:
        failures.append(f"{what}\n     got: {got!r}\n    want: {want!r}")


def lines(*texts: str) -> list[tuple[int | None, str]]:
    """Source fragment as the body pairs the folds work on, numbered from 100."""
    return [(100 + offset, AREA_B + text) for offset, text in enumerate(texts)]


def markers(body: list[tuple[int | None, str]]) -> list[str]:
    return [text.strip() for _, text in body]


# --------------------------------------------------------------------------- #
# A stand-in for the data-structure inventory
# --------------------------------------------------------------------------- #

class FakeFacts:
    """Two programs, each with one inbound and one outbound view of two leaves.

    Enough for `@call`: the pairing needs the callee's `USING` order and the leaves
    of both sides' views in declaration order, and nothing else.
    """

    VIEWS = {
        "CALLER": [("LOCAL-THING-0007EV", ["DIR-BUS-UNIT-0007", "DIR-NAME-0007"]),
                   ("LOCAL-OUT-0008EV", ["RESULT-CODE-0008", "RESULT-TEXT-0008"])],
        "CALLEE": [("IMPORT-THING-0001EV", ["DIR-BUS-UNIT-0001", "DIR-NAME-0001"]),
                   ("EXPORT-THING-0002EV", ["RESULT-CODE-0002", "RESULT-TEXT-0002"])],
    }

    def parameters(self, program: str) -> list[str]:
        return ["IEF-RUNTIME-PARM1", "IEF-RUNTIME-PARM2", "GLOBDATA",
                *(view for view, _ in self.VIEWS[program])]

    def field_index(self, program: str) -> list[dict]:
        found, line = [], 0
        for root, names in self.VIEWS[program]:
            for name in names:
                line += 1
                found.append({"name": name, "pic": "X(10)", "level": 5,
                              "owner": f"{root}.{name}", "line": line, "root": root})
        return found


def call_marker_of(statement: str) -> str:
    facts = FakeFacts()
    match = E.CALL_STATEMENT.match(statement)
    assert match, statement
    return E.call_marker(match, E.group_fields(facts, "CALLER"), facts, "CALLER")


ARGUMENTS = ("IEF-RUNTIME-PARM1, IEF-RUNTIME-PARM2, GLOBDATA, "
             "LOCAL-THING-0007EV, LOCAL-OUT-0008EV")
PAIRED = ("*> @call CALLEE(DIR-BUS-UNIT-0001=DIR-BUS-UNIT-0007, "
          "DIR-NAME-0001=DIR-NAME-0007) into "
          "RESULT-CODE-0008=RESULT-CODE-0002, RESULT-TEXT-0008=RESULT-TEXT-0002")

# A call named in the statement, and the same call reached through the loader, have to
# produce the same marker. Most calls in a generated tree are the second kind, so a
# regression here is a regression in nearly every document.
check("direct call", call_marker_of(f"CALL 'CALLEE' USING {ARGUMENTS}"), PAIRED)
check("loader call",
      call_marker_of(f"CALL 'TIRLGLOD' USING CALLEE-ID, {ARGUMENTS}"), PAIRED)
check("runtime function",
      call_marker_of("CALL 'TIRFDAYS' USING IEF-RUNTIME-PARM1, IEF-RUNTIME-PARM2, "
                     "GLOBDATA, DATE-VALUE-AT, DAYS-VALUE-AT"),
      "*> @function TIRFDAYS(DATE-VALUE-AT) -> DAYS-VALUE-AT")
check("failure", call_marker_of("CALL 'TIRFAIL' USING GLOBDATA"), "*> @fail")

# --------------------------------------------------------------------------- #
# The response envelope
# --------------------------------------------------------------------------- #

four = lines("MOVE EX-WIP-NOT-FOUND0002 TO PSMGR-EXIT-STATE",
             "MOVE 'E' TO PSMGR-EXIT-MSGTYPE",
             "MOVE SPACES TO PSMGR-EXIT-INFOMSG",
             "MOVE 'R' TO PSMGR-ROLLBACK-RQSTED")
check("four-slot response", markers(E.fold_responses(four)),
      ["*> @response state=EX-WIP-NOT-FOUND0002, level=E, message='', rollback=R"])
check("four-slot response is emitted", E.state_roles(E.fold_responses(four)),
      {"EX-WIP-NOT-FOUND0002": "emitted"})

# A paragraph that only names its outcome. Left unfolded, the state reads as one the
# program merely compares against - the opposite of what happens.
one = lines("MOVE EX-PROCESSING-OK0001 TO PSMGR-EXIT-STATE")
check("one-slot response", markers(E.fold_responses(one)),
      ["*> @response state=EX-PROCESSING-OK0001"])
check("one-slot response is emitted", E.state_roles(E.fold_responses(one)),
      {"EX-PROCESSING-OK0001": "emitted"})

# --------------------------------------------------------------------------- #
# Escapes, the status check, validation, paragraph performs
# --------------------------------------------------------------------------- #

check("status check", markers(E.fold_exception_checks(lines(
    "IF STATUS-FLAG OF GLOBDATA NOT = SPACES OR",
    "ERROR-ENCOUNTERED-SW OF GLOBDATA NOT = SPACES OR",
    "VIEW-OVERFLOW-SW OF GLOBDATA NOT = SPACES",
    "GOBACK",
    "END-IF"))), ["*> @exception-check"])

# The raise names every paragraph it unwinds through; the check that sits straight
# after a raise of the same paragraph can never fire and goes.
escape = [*lines("MOVE 'Y' TO FUNC-0012-ESC-FLAG",
                 "MOVE 'Y' TO REPEAT-0011-ESC-FLAG"),
          (102, "PARA-0012."),
          *lines("IF FUNC-0012-ESC-FLAG = 'Y' GO TO PARA-0012-EXIT", "END-IF")]
check("escape run then check", markers(E.fold_escapes(escape)),
      ["*> @escape returns from PARA-0012, PARA-0011", "PARA-0012.",
       "*> @escape-check PARA-0012"])
check("escape reset drops", markers(E.fold_escapes(
    lines("MOVE 'N' TO FUNC-0012-ESC-FLAG"))), [])

check("validation", markers(E.fold_validation(
    [*lines("PERFORM PARA-0012-INIT THRU PARA-0012-INIT-EXIT"),
     (102, "PARA-0012-INIT."),
     *lines("MOVE SPACES TO DIR-NAME-0007"),
     (104, "PARA-0012-INIT-EXIT."),
     (105, "PARA-0013.")])),
      ["*> @validation", "PARA-0013."])

check("paragraph perform", markers(E.fold_paragraph_performs(
    lines("PERFORM PARA-0012 THRU PARA-0012-EXIT"))), ["*> @paragraph PARA-0012"])
check("exit landing pad drops", markers(E.drop_exit_paragraphs(
    [(100, "PARA-0012-EXIT."), *lines("EXIT.")])), [])

# --------------------------------------------------------------------------- #
# Initialisers, cursors, array copies, empty loops, date arithmetic
# --------------------------------------------------------------------------- #

check("initialize with cursor", markers(E.merge_group_cursors(E.fold_initializers(
    lines("INITIALIZE GROUP-EXPORT-WIP-0004RG",
          "MOVE ZERO TO GROUP-EXPORT-WIP-0004PS")))),
      ["*> @initialize GROUP-EXPORT-WIP-0004RG, cursor=0"])
check("cursor before initialize", markers(E.merge_group_cursors(E.fold_initializers(
    lines("MOVE 1 TO GROUP-EXPORT-WIP-0004PS",
          "INITIALIZE GROUP-EXPORT-WIP-0004RG")))),
      ["*> @initialize GROUP-EXPORT-WIP-0004RG, cursor=1"])

check("copy array", markers(E.fold_copy_arrays(lines(
    "PERFORM VARYING ADIM1 FROM 1 BY 1 UNTIL ADIM1 > GROUP-WIP-0004MA",
    "MOVE DIR-NAME-0004(ADIM1) TO DIR-NAME-0009(ADIM1)",
    "MOVE DIR-CODE-0004(ADIM1) TO DIR-CODE-0009(ADIM1)",
    "END-PERFORM"))),
      ["*> @copy-array(GROUP-WIP-0004MA) DIR-NAME-0004:DIR-NAME-0009, "
       "DIR-CODE-0004:DIR-CODE-0009"])
# A loop body that is not purely per-entry copies is structural work and stays whole.
kept = lines("PERFORM VARYING ADIM1 FROM 1 BY 1 UNTIL ADIM1 > GROUP-WIP-0004MA",
             "ADD 1 TO COUNT-0022",
             "END-PERFORM")
check("copy array leaves other loops", markers(E.fold_copy_arrays(kept)),
      markers(kept))

check("empty group loop drops", markers(E.drop_empty_loops(lines(
    "PERFORM VARYING ADIM1 FROM 1 BY 1 UNTIL ADIM1 > 200",
    "COMPUTE ADIM1 = 200",
    "END-PERFORM"))), [])

check("date-add", markers(E.fold_durations(lines(
    "MOVE DATA-MISSING TO DDURA-YYYY-MISS",
    "MOVE DATA-PRESENT TO DDURA-MM-MISS",
    "COMPUTE DDURA-MM = 3",
    "MOVE EFFECTIVE-DATE-0009 TO PSMGR-FUNC-IN-DATE",
    "CALL 'TIRFDDUR' USING IEF-RUNTIME-PARM1, GLOBDATA",
    "MOVE PSMGR-FUNC-OUT-DATE TO EXPIRY-DATE-0009"))),
      ["*> @date-add EFFECTIVE-DATE-0009 + 3 months -> EXPIRY-DATE-0009"])

# --------------------------------------------------------------------------- #
# Pass-throughs
# --------------------------------------------------------------------------- #

direction = {"DIR-NAME-0001": "in", "DIR-NAME-0002": "out",
             "DIR-CODE-0001": "in", "DIR-CODE-0002": "out"}
# One end outside the contract: the program hands back something nothing reads.
check("echo of a dropped field drops", markers(E.fold_echoes(
    lines("MOVE DIR-NAME-0001 TO DIR-NAME-0002"), direction, set())), [])
# Both ends in the contract: this statement is the only thing connecting them.
both = lines("MOVE DIR-CODE-0001 TO DIR-CODE-0002")
check("echo between kept fields stays", markers(E.fold_echoes(
    both, direction, {"DIR-CODE-0001", "DIR-CODE-0002"})), markers(both))

# --------------------------------------------------------------------------- #
# Declarations, and the columns they are read from
# --------------------------------------------------------------------------- #

# Columns 73-80 are the program identification, not code. A declaration carrying one
# never reaches its terminating period, so a parse that reads the whole line swallows
# every line after it.
stamped = "       05  DIR-NAME-0007 PIC X(30).".ljust(72) + "P7549500"
check("declaration past column 72", E.parse_declarations([stamped]),
      {"DIR-NAME-0007": ("DIR-NAME-0007", "char(30)", "", ())})
check("occurs past column 72",
      E.parse_occurs(["       05  GROUP-WIP-0004 OCCURS 200.".ljust(72) + "P7549500"]),
      {"GROUP-WIP-0004": 200})
# A level-88 name is a constant in its own right and is recorded as one, with the
# value the code compares against. It gets no parent: only levels without a PIC go on
# the nesting stack, and the field a condition qualifies has one. That is why a
# condition on a parameter-view field still reaches `Locals and constants` - which is
# where a reader looks for what `SUCCEEDS` equals - rather than being filtered out
# with the view it was declared under.
check("level 88 condition", E.parse_declarations(
    ["       05  STATE-0007 PIC X(2).", "           88  SUCCEEDS VALUE 'OK'."]),
      {"STATE-0007": ("STATE-0007", "char(2)", "", ()),
       "SUCCEEDS": ("SUCCEEDS", "condition", "'OK'", ())})

# A one-word statement sits in area B; a paragraph name sits in area A. Telling them
# apart is what keeps `GOBACK.` from being read as a paragraph heading.
check("GOBACK is not a paragraph", E.is_paragraph(AREA_B + "GOBACK."), False)
check("paragraph name is", E.is_paragraph("       PARA-0012."), True)

# --------------------------------------------------------------------------- #
# The traceability index: which paragraphs have to be traceable
# --------------------------------------------------------------------------- #
# `kind` decides whether a paragraph is exempt from the traceability gate, so an error
# here is not a wrong document - it is a live behaviour silently excused from the check
# that would have noticed it was never migrated. The bias is towards `business`: see
# `paragraph_kind`.


def kind_of(*texts: str) -> str:
    return E.paragraph_kind("PARA-1955993943", lines(*texts))[0]


# A statement is content, whatever else is in the paragraph.
check("statement is business", kind_of("MOVE DIR-CODE-0001 TO WS-CODE"), "business")

# Nothing but the generated shell: the validation performed on entry and the return.
check("validation and GOBACK is mechanism",
      kind_of("*> @validation", "GOBACK."), "mechanism")
check("initialize only is mechanism",
      kind_of("*> @initialize EXPORT-0004"), "mechanism")
check("transfer of control only is mechanism",
      kind_of("*> @paragraph PARA-1955993950"), "mechanism")

# The error that matters. A paragraph holding only a `@response` reports an outcome the
# caller receives - a live response code. A first version of the classifier discounted
# marker-only paragraphs and exempted 50 of these from the gate.
check("response only is business",
      kind_of("*> @response state=EX-PROCESSING-OK, level=N"), "business")
check("failure only is business", kind_of("*> @fail"), "business")
check("call only is business",
      kind_of("*> @call A7549229(DIR-CODE-0001=WS-CODE)"), "business")

# An escape stub: the whole body is one early return. The decision that performs it is
# in the performing paragraph, which carries statements and is cited; the behaviour
# stays reachable through that one. 16 paragraphs of the measured tree are this.
check("escape stub is mechanism",
      kind_of("*> @escape returns from PARA-1955993943"), "mechanism")

# The substring landing pad is never anything but a landing pad.
check("substring landing pad is mechanism",
      E.paragraph_kind("SUBSTR-ERROR-1", lines("MOVE 1 TO WS-X"))[0], "mechanism")

# A cursor DECLARE is where the query text lives - the table, the columns and the
# predicate are all inside it - so it counts as a statement. Discounting it turned
# every generated MAIN shell carrying a cursor into mechanism.
check("cursor DECLARE counts as a statement", len(E.effective_statements(lines(
    "EXEC SQL DECLARE C1 CURSOR FOR SELECT A FROM T WHERE B = :X END-EXEC"))), 1)
check("lone period and GOBACK count for nothing",
      E.effective_statements(lines(".", "GOBACK.", "CONTINUE.")), [])

# The record carries the range the heading carries, and the content a reader of the
# index navigates by. `lines` numbers from 100.
record = E.paragraph_record("PARA-1955993943", 100, lines(
    "*> @response state=EX-PROCESSING-OK, level=N",
    "EXEC SQL SELECT A INTO :B FROM T END-EXEC",
    "*> @call A7549229(X=Y)", "*> @function TIRDAT2(A) -> B",
    "*> @paragraph PARA-1955993950"))
check("record range", record["lines"], [100, 104])
check("record kind", record["kind"], "business")
check("record sql", record.get("sql"), ["SELECT"])
check("record calls", record.get("calls"), ["A7549229"])
check("record functions", record.get("functions"), ["TIRDAT2"])
check("record responses", record.get("responses"), ["EX-PROCESSING-OK"])
check("record performs", record.get("performs"), ["PARA-1955993950"])
# Absent when empty, never `[]` - a reader must not have to tell the two apart.
check("empty lists are absent",
      [key for key in ("sql", "calls", "functions", "responses", "performs")
       if key in E.paragraph_record("PARA-1", 100, lines("MOVE 1 TO WS-X"))], [])

# The index is built from the same `paragraphs()` the document is rendered from, so a
# record's range and its `## Paragraph` heading cannot disagree.
body = [(100, "       PARA-1955993943."), (101, AREA_B + "MOVE 1 TO WS-X"),
        (None, "*> @fail"), (103, AREA_B + "GOBACK.")]
entry = E.index_entry("A7549229", "A7549229_MODEL", body)
check("index entry counts", (entry["business"], entry["mechanism"]), (1, 0))
check("index range equals the heading",
      entry["paragraphs"][0]["lines"],
      [int(part) for part in E.span_of(100, body[1:]).split("-")])

# --------------------------------------------------------------------------- #
# The walk stops at a boundary: the boundary and what only it reaches stay out, a
# program also reached on another path stays in.

import program_tree as T  # noqa: E402


class TreeFacts:
    CALLS = {"P1": ["A1", "C1"], "A1": ["X1", "X2"], "C1": ["X2"], "X1": [], "X2": []}

    def source(self, program, start, end):
        return ["       PROCEDURE DIVISION."] + [
            f"           CALL '{callee}' USING W-X." for callee in self.CALLS[program]]

    def program_exists(self, program):
        return program in self.CALLS


check("tree without boundaries", T.tree(TreeFacts(), "P1")[0],
      ["P1", "A1", "C1", "X1", "X2"])
check("tree stops at a boundary", T.tree(TreeFacts(), "P1", frozenset({"A1"})),
      (["P1", "C1", "X2"], [], [("P1", "A1")]))

# --------------------------------------------------------------------------- #

print(f"{len(failures)} failed")
for failure in failures:
    print(f"  FAIL {failure}")
raise SystemExit(1 if failures else 0)
