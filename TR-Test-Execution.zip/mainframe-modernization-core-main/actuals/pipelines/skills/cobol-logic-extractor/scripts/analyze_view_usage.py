#!/usr/bin/env python3
"""Collect a CA Gen procedure step's import/export view fields and keep the ones
that are genuinely used - by the program itself or anywhere down its call chain.

All facts come from the local MF Analyzer instance; nothing is read from the
filesystem. Where source text is needed (the ``PROCEDURE DIVISION USING`` header
and the argument list of each ``CALL``) it is fetched through the MCP server too.

Four stages:

1. **Inventory.** For every program in scope, reconstruct the linkage views from
   the s2t lineage rows, which carry byte offset, byte length and PIC for each
   field. The full leaf list comes from the data-structure inventory, because
   lineage omits fields that nothing ever touches - and for this tool, absence
   from lineage is itself the finding.

2. **Aliasing.** Join each ``CALL`` argument to the matching callee parameter by
   relative byte offset. Caller and callee name the same view differently, so
   names are useless here; ``BY REFERENCE`` means one piece of storage under two
   names, which is what matching on offset reproduces.

3. **Evidence.** Walk every lineage row and its trace chains to record, per leaf:
   what writes it (a literal, a blanking move, a DB2 fetch, a callee), what reads
   it (guard conditions name their fields, and a row's sources are reads), and the
   conditions under which either happens.

4. **Verdict.** An import survives if its value can reach a real read; an export
   survives if real information can reach it. A field whose only writers are the
   generated view initialisation, or whose only sources are themselves never
   populated, is dropped.

Usage:

    scripts/analyze_view_usage.py --root P7549509
    scripts/analyze_view_usage.py --root P7549509 --out-dir data \
        --cache-dir .cache/mfanalyzer

Outputs ``<ROOT>-call-contract.md`` under --out-dir.
"""

from __future__ import annotations

import argparse
import re
import sys
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, field as dc_field, replace
from itertools import groupby
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from mfanalyzer_facts import (  # noqa: E402
    Facts, FactsError, add_url_argument, mu_boundaries)

# --------------------------------------------------------------------------- #
# Vocabulary
# --------------------------------------------------------------------------- #

IMPORT_VIEW = "W-IA"
EXPORT_VIEW = "W-OA"

# Words that mark the direction of a parameter view - see contract_views. Checked
# against the generated `START OF IMPORT/EXPORT VIEWS` banners over every member in
# original_files: 2528 of 2545 parameters declared in one of those regions carry one of
# these words and none of them contradicts its banner. See
# FORMAT.md.
INBOUND_WORDS = {"IMPORT", "IMP", "IN", "INPUT"}
OUTBOUND_WORDS = {"EXPORT", "EXP", "OUT", "OUTPUT"}

# A generated view carries the number of the view it was emitted for and says what kind
# of view it is. Without that suffix the parameter is not a view: it is runtime
# plumbing, a DB2 record layout passed to an access module, or hand-written linkage.
VIEW_SUFFIX = re.compile(r"\d(?:EV|RG)$")

# Runtime plumbing passed to every generated program; never part of the contract.
RUNTIME_PARAMS = {"IEF-RUNTIME-PARM1", "IEF-RUNTIME-PARM2"}

# The shared control block, passed to every generated program and threaded unchanged
# through the whole tree. It is not a view - the generator declares it under a LOCAL,
# CASCADE ROUTINE or ENTITY ACTION banner - but it is not plumbing either: it carries
# the command that selects which operation an entry program performs, the exit state
# it returns, and the flags that propagate failure in place of exceptions. Because
# caller and callee share the one copy, a field of it is read and written in both
# directions, so it enters the contract as both an import and an export and the
# ordinary verdicts decide which of its fields survive.
SHARED_PARAM = "GLOBDATA"

# Slots inside the shared control block that the generated code uses as the argument
# and result registers of the runtime date and time functions: it fills them, calls
# the module, and reads the answer back, all within one statement sequence. Checked
# over every member of the batch - 1028 uses in 160 members, not one of them read
# before the program or the runtime module had written it, and not one left holding a
# program's value across a call to a generated program. They carry nothing between
# programs, so they belong to no interface. See `scripts/globdata_scratch_check.py`
# and `data/globdata-scratch-usage.csv`.
SCRATCH_FAMILIES = re.compile(r"^(?:PSMGR-FUNC|PSMGR-TIRDATE|DDURA|TDURA)-")


def is_scratch(leaf: Leaf) -> bool:
    """True for a runtime-function register inside the shared control block."""
    return leaf.view == SHARED_PARAM and bool(SCRATCH_FAMILIES.match(leaf.name))


# Request-header fields that hold a clock reading rather than business data. The entry
# program reads the clock once and the whole tree works from that one value, so the
# field is how the date is propagated, not something a caller decides. The target
# platform supplies the date; what has to survive the migration is that it is fixed
# once per transaction, which is recorded in FORMAT.md instead of
# as an interface field.
INFRASTRUCTURE_FIELDS = {"RV-SERVER-DATE"}


def is_infrastructure(leaf: Leaf) -> bool:
    """True for a field that carries platform state rather than business data."""
    return base_name(leaf.name) in INFRASTRUCTURE_FIELDS


# The failure channel. Every read of these is the generated check that follows a call -
# `IF STATUS-FLAG ... OR ERROR-ENCOUNTERED-SW ... OR VIEW-OVERFLOW-SW ... GOBACK` - and
# the value it tests was produced by a call the program itself made, a few lines above.
# Nothing a caller supplies can reach that test, so they are not inputs, however the
# flow graph reads them: it has no notion of statement order and cannot see that the
# write precedes the read. They stay in the export direction, where a callee setting
# one of them genuinely does propagate upwards.
FAILURE_FLAGS = {"STATUS-FLAG", "ERROR-ENCOUNTERED-SW", "VIEW-OVERFLOW-SW"}

# Diagnostics. Each is written continuously so that termination processing can report
# where a failure happened - the statement being executed, the action block running, the
# database statement attempted - and measured over the batch, nothing ever reads any of
# them: 52173 literal assignments to the statement number and 9990 to the two action
# block fields, with no read outside one program that saves and restores the number
# around a call to the trace module. They are not results a caller consumes.
DIAGNOSTIC_FIELDS = {"LAST-STATEMENT-NUM", "CUR-AB-ID", "CUR-AB-NAME", "CUR-AB-NAM",
                     "ACTION-ID"}

# Words that can only open a new statement, and so close an argument list that was
# never terminated - see using_args. Generated argument names are view and group
# names carrying digits and hyphens, so none of them collides with a verb.
STATEMENT_WORDS = {
    "IF", "ELSE", "END-IF", "EVALUATE", "WHEN", "END-EVALUATE", "MOVE", "COMPUTE",
    "ADD", "SUBTRACT", "MULTIPLY", "DIVIDE", "INITIALIZE", "SET", "PERFORM",
    "END-PERFORM", "CALL", "GOBACK", "GO", "EXIT", "CONTINUE", "STOP", "SEARCH",
    "END-SEARCH", "INSPECT", "STRING", "UNSTRING", "ACCEPT", "DISPLAY", "EXEC",
    "READ", "WRITE", "REWRITE", "DELETE", "OPEN", "CLOSE", "START", "RETURN",
    "END-READ", "END-CALL", "NEXT", "ALTER", "CANCEL", "TRANSFORM",
}

# CA Gen runtime modules - date conversion, view marshalling, string handling.
# They are shipped with the generator, not generated from the model, so there is
# no source to analyse and no reason to look for one: whatever is passed to one of
# them is consumed by it.
RUNTIME_PREFIX = "TIR"


def is_runtime_module(name: str) -> bool:
    """True for a CA Gen runtime module rather than a generated program."""
    return name.startswith(RUNTIME_PREFIX)


# Fields of the generated request/response header (the `RV-SERVER` entity type)
# that the entry program both echoes to its response and then tests. The test is
# real code, but it is not a contract input: the INIT block defaults the field to
# zero whenever the caller supplies anything non-numeric, every dispatch branch
# overwrites it, and only the fall-through branch can still see what came in. So
# in the entry program a read of one of these is not evidence that a caller has to
# supply it, and it is ignored - see `special_case_note`, which reports every read
# that was set aside this way.
ROOT_IGNORED_READS = {"RESPONSE-CODE-S"}


def base_name(name: str) -> str:
    """A view field without its generator-assigned occurrence number.

    CA Gen numbers each view it emits and suffixes every leaf with that number, so
    the same model attribute is ``RESPONSE-CODE-S-0142`` in the import view and
    ``RESPONSE-CODE-S-0150`` in the export view of the same program. Only the base
    name is stable enough to recognise a field by.
    """
    return re.sub(r"-\d{4}$", "", name)


# The generated ``PARA-<id>-INIT`` paragraph opens with one guarded substitution per
# import leaf: a character field that arrives as HIGH-VALUES or LOW-VALUES is replaced
# by spaces, a numeric field that is not numeric by zero. That substitution is what a
# caller gets when it leaves the field unset, so it is the field's default.
#
# Only the guarded form counts. The same paragraph goes on to initialise locals and
# export views unconditionally (`MOVE ZERO TO ...PS`, `INITIALIZE ...EV`), and reading
# those as defaults would claim every field has one.
INIT_PARAGRAPH = re.compile(r"PARA-.*-INIT$")
INIT_SUBSTITUTE = re.compile(
    r"\bIF\s+(?P<cond>(?:(?!\bEND-IF\b|\bMOVE\b).)+?)"
    r"\bMOVE\s+(?P<value>'[^']*'|[A-Z0-9-]+)\s+TO\s+(?P<field>[A-Z0-9-]+)\s+END-IF\b")
VALIDITY_GUARD = re.compile(r"HIGH-VALUES|LOW-VALUES|NOT\s+NUMERIC")

# A guard that tests a field for emptiness rather than for a particular value. Where a
# read sits behind one of these the program has a path for the field being absent.
EMPTY_VALUES = r"(?:SPACES?|ZEROE?S?|LOW-VALUES|HIGH-VALUES)"
NEGATED = re.compile(r"NOT\s*\([^)]*\)")


def tests_own_emptiness(condition: str, leaf: Leaf) -> bool:
    """True if a read guard asks whether this very field came in empty.

    The guard a verdict carries is the whole accumulated path condition, so it names
    every field tested on the way to the read - including the generated status flags
    and the keys of unrelated lookups. Only a test on the field itself says anything
    about that field being optional, and only a positive one: ``NOT (X = SPACES)``
    guards the path where the caller *did* supply it.
    """
    stem = re.escape(base_name(leaf.name))
    return bool(re.search(rf"\b{stem}(?:-\d{{4}})?\s*=\s*{EMPTY_VALUES}\b",
                          NEGATED.sub("", condition)))

# How a substituted literal is reported. Figurative constants vary by generator mood
# (`ZERO`, `ZEROS`, `0`) while meaning the same thing.
DEFAULT_NAMES = {"SPACES": "spaces", "SPACE": "spaces",
                 "ZERO": "0", "ZEROS": "0", "ZEROES": "0", "0": "0"}

# CA Gen view bookkeeping suffixes: null flags, attribute sets, occurs counters,
# REDEFINES aliases and assorted switches.
PLUMBING_SUFFIXES = ("AS", "AT", "AC", "MX", "PS", "RF", "MM", "FL", "CD", "LK",
                     "ES", "XX")

FIGURATIVE = {"SPACE", "SPACES", "ZERO", "ZEROS", "ZEROES", "HIGH-VALUE",
              "HIGH-VALUES", "LOW-VALUE", "LOW-VALUES", "QUOTE", "QUOTES",
              "NULL", "NULLS"}

# Origin kinds the lineage engine reports for a write, mapped to what they mean
# as evidence. `OPERATION` needs its label inspected: CA Gen emits a generated
# view initialisation that blanks every field in the contract, and the engine
# reports it as `OPERATION / "INIT @ <line>"`. Counting that as a write would
# make every field look populated, so it is discounted like any other blanking.
INIT_LABEL_RE = re.compile(r"^INIT\b")

# How the engine spells an endpoint that lives outside the program: `DB2(TABLE)`,
# as against the bare `Linkage section` it uses for the program's own parameters.
EXTERNAL_SYSTEM_RE = re.compile(r"^[A-Z0-9]+\(.+\)$")

# Endpoint kinds that sit outside the program. A write to one of these consumes
# its sources: the value leaves for a table, a file or a queue.
EXTERNAL_ENDPOINTS = {"DB2_TABLE", "FILE", "MQ_QUEUE"}

# How far behind an external write to look for declared storage. CA Gen uses one
# host variable per column, so the field is one hop back; a couple of spare hops
# cover a value that was staged through another temporary first.
SQL_HOST_HOPS = 3

ORIGIN_WRITE_KIND = {
    "INITIAL_VALUE": "INITIAL",
    "CALL_RESULT": "CALL",      # the callee is analyzed on its own terms
    "DB2_TABLE": "SQL-OUT",
    "FILE": "SQL-OUT",
    "MQ_QUEUE": "SQL-OUT",
    "ENDPOINT": "FLOW",         # value arrives from another linkage view
    "SYSTEM_VARIABLE": "COMPUTED",
    "PROGRAM_PARAMETER": "FLOW",
}


# CA Gen opens every procedure step with a generated check over the whole import
# view: each leaf is tested for an unset null flag (`<field>XX = HIGH_VALUES OR
# <field>XX = LOW_VALUES`) or, for numeric leaves, for garbage (`NOT (<field> IS
# NUMERIC)`). Both only ask whether the caller supplied the field, so counting
# them as reads would make every import used and the filter vacuous.
VALIDITY_NULL_RE = re.compile(
    r"^\s*(?P<alias>[A-Z0-9#@$-]+)(?P<sub>\s*\([^)]*\))?\s*=\s*(HIGH|LOW)_VALUES"
    r"\s+OR\s+(?P=alias)(?P=sub)?\s*=\s*(HIGH|LOW)_VALUES\s*$")
VALIDITY_NUMERIC_RE = re.compile(
    r"^\s*NOT\s*\(\s*[A-Z0-9#@$-]+(\s*\([^)]*\))?\s+IS\s+NUMERIC\s*\)\s*$")


def is_validity_check(text: str | None) -> bool:
    """True when a condition only asks whether a field was supplied at all."""
    if not text:
        return False
    return bool(VALIDITY_NULL_RE.match(text) or VALIDITY_NUMERIC_RE.match(text))


def parent_of(path: str) -> str:
    """The group a field is declared under."""
    return path.rsplit(".", 1)[0]


def is_plumbing(name: str) -> bool:
    match = re.search(r"-?\d{4}([A-Z]{2})$", name)
    return bool(match and match.group(1) in PLUMBING_SUFFIXES)


# CA Gen declares a repeating group as a `...RG` wrapper holding an entry counter
# (`...MA`, with an `...MX` alias over it) beside an element group that carries the
# `OCCURS`. Only a leaf inside that element exists once per occurrence - the counter
# sits outside it and is a single number - so the element is what makes a field an
# array rather than the wrapper or the counter.
REPEATING_WRAPPER = re.compile(r"\d+RG$")
OCCURS_RE = re.compile(r"([A-Z0-9#@$-]+)\s+OCCURS\s+(\d+)")


def array_element(leaf: Leaf) -> str:
    """The repeating element a leaf belongs to, or "" for a plain field.

    The element has to be a strict ancestor of the leaf: the entry counter is itself
    declared directly under the wrapper, and it counts the occurrences rather than
    having one.
    """
    parts = leaf.path.split(".")
    for index in range(len(parts) - 3, -1, -1):
        if REPEATING_WRAPPER.search(parts[index]):
            return parts[index + 1]
    return ""


def is_figurative_only(sources: str | None) -> bool:
    """True when every source of a write is SPACES / ZEROS / a zero literal.

    Such a write clears the field; it does not put information in it.
    """
    if not sources:
        return False
    parts = [p.strip().upper() for p in sources.split(",") if p.strip()]
    if not parts:
        return False
    return all(p in FIGURATIVE or re.fullmatch(r"[-+]?0+(\.0+)?", p)
               for p in parts)


# --------------------------------------------------------------------------- #
# Linkage model
# --------------------------------------------------------------------------- #


@dataclass
class Leaf:
    program: str
    view: str          # level-01 group it lives under
    name: str
    path: str
    pic: str
    offset: int        # bytes from the start of the view, or a declaration ordinal
    size: int
    origin: str = "lineage"

    @property
    def located(self) -> bool:
        """True when this leaf has a byte offset the lineage engine vouched for."""
        return self.origin == "lineage"


@dataclass
class Program:
    name: str
    params: list[str] = dc_field(default_factory=list)   # USING order
    leaves: dict[str, list[Leaf]] = dc_field(default_factory=dict)  # view -> leaves

    def leaves_of(self, view: str) -> list[Leaf]:
        return self.leaves.get(view, [])


PIC_PART_RE = re.compile(r"([X9AVSP])(?:\((\d+)\))?")


def pic_bytes(pic: str) -> int:
    """Display length of a PIC clause; sign and the implied point take no byte."""
    total = 0
    for symbol, count in PIC_PART_RE.findall(pic.upper()):
        if symbol in "SVP":
            continue
        total += int(count) if count else 1
    return total


def build_working_view(facts: Facts, program: str, root: str) -> list[Leaf]:
    """Leaves of one level-01 working-storage group, in declaration order.

    The lineage endpoint only describes linkage views, but CA Gen marshals every
    call through a local copy of the callee's view, so those copies have to come
    from the data-structure inventory instead. There is no byte offset there, so
    the declaration ordinal stands in: within a group the order is the layout.
    """
    fields = [f for f in facts.field_index(program)
              if f["root"] == root and f["pic"]]
    fields.sort(key=lambda f: f["line"])
    return [Leaf(program=program, view=root, name=f["name"], path=f["owner"],
                 pic=f["pic"], offset=index, size=pic_bytes(f["pic"]),
                 origin="struct")
            for index, f in enumerate(fields)]


def depth_of(target_name: str) -> int:
    """Lineage rows encode nesting as a two-dot prefix per level."""
    stripped = target_name.lstrip(".")
    return (len(target_name) - len(stripped)) // 2


def build_linkage(facts: Facts, program: str, warnings: list[str]) -> Program:
    """Reconstruct every linkage view of one program from analyzer facts.

    Offsets and byte lengths come from the lineage rows; the leaf inventory is
    completed from the data-structure listing, since lineage only mentions fields
    that something touches.
    """
    rows = facts.mappings(program)
    stack: list[str] = []
    by_view: dict[str, list[Leaf]] = defaultdict(list)
    seen: set[tuple[str, str]] = set()

    for row in rows:
        name = row["targetName"]
        bare = name.lstrip(".")
        level = depth_of(name)
        stack[level:] = [bare]
        view = stack[0]
        if not row.get("declaredType"):
            continue  # group item: it only contributes structure
        if row.get("byteOffset") is None:
            continue
        key = (view, bare)
        if key in seen:
            continue
        seen.add(key)
        by_view[view].append(Leaf(
            program=program, view=view, name=bare, path=".".join(stack),
            pic=row["declaredType"].replace("PIC ", ""),
            offset=int(row["byteOffset"]), size=int(row["byteLength"]),
        ))

    # Fields with no lineage row at all are untouched by definition. They are
    # still part of the contract, so they belong in the inventory - without an
    # offset they cannot be aliased across a call, which is harmless for a field
    # nothing reads or writes.
    for view in list(by_view) or []:
        known = {leaf.name for leaf in by_view[view]}
        for entry in facts.structure(program, view):
            if not entry.get("dataType") or entry["name"] in known:
                continue
            by_view[view].append(Leaf(
                program=program, view=view, name=entry["name"],
                path=entry.get("ownerName") or entry["name"],
                pic=entry["dataType"].replace("PIC ", ""),
                offset=-1, size=0, origin="untouched",
            ))

    for view in by_view:
        by_view[view].sort(key=lambda leaf: (leaf.offset, leaf.name))

    # The lineage engine numbers the parameter endpoints, which is exactly the
    # positional order argument matching needs.
    params = facts.parameters(program)
    if not params:
        warnings.append(f"{program}: no parameter endpoints reported")
    return Program(name=program, params=params, leaves=dict(by_view))


def strip_comments(text: str) -> str:
    """Remove CA Gen's ``*>`` inline comments, which it indents arbitrarily."""
    return re.sub(r"\*>[^\n]*", " ", text)


# --------------------------------------------------------------------------- #
# Evidence
# --------------------------------------------------------------------------- #

# What counts as consuming a field's value. A plain move into another field is
# deliberately absent: copying a value is propagation, not use, and the flow edge
# already carries it onwards - counting it would make every echoed field look read.
READ_KINDS = {"COND", "SQL-IN", "EXTERNAL"}
WRITE_REAL = {"LITERAL", "SQL-OUT", "EXTERNAL", "COMPUTED"}
WRITE_EMPTY = {"BLANK", "INITIAL", "INIT"}


@dataclass
class Use:
    kind: str
    program: str
    line: int | None = None
    detail: str = ""
    condition: str = ""

    def __str__(self) -> str:
        where = f"{self.program}:{self.line}" if self.line else self.program
        return f"{self.kind} @ {where}" + (f" ({self.detail})" if self.detail else "")


class Graph:
    """Leaf-level flow graph whose nodes are pieces of storage, not names.

    Arguments passed ``BY REFERENCE`` make caller and callee leaves the same node,
    so union-find models them as one identity rather than as an edge.
    """

    def __init__(self) -> None:
        self.parent: dict[tuple, tuple] = {}
        self.edges: dict[tuple, set[tuple]] = defaultdict(set)
        self.rev: dict[tuple, set[tuple]] = defaultdict(set)
        self.reads: dict[tuple, list[Use]] = defaultdict(list)
        self.writes: dict[tuple, list[Use]] = defaultdict(list)
        self.labels: dict[tuple, str] = {}

    def key(self, leaf: Leaf) -> tuple:
        # The origin belongs in the identity because ``offset`` means two different
        # things: a byte offset for a leaf the lineage engine located, a declaration
        # ordinal for one read from the structure inventory. Without it the two
        # scales collide - one field's ordinal equals another's byte offset at the
        # same length - and two unrelated fields become one piece of storage. The
        # two descriptions of a field that really are the same are merged by name in
        # ``struct_leaves``, deliberately, which is where that belongs.
        raw = (leaf.program, leaf.view, leaf.offset, leaf.size, leaf.origin)
        if raw not in self.parent:
            self.parent[raw] = raw
            self.labels[raw] = leaf.name
        return self.find(raw)

    def find(self, node: tuple) -> tuple:
        root = node
        while self.parent[root] != root:
            root = self.parent[root]
        while self.parent[node] != root:
            self.parent[node], node = root, self.parent[node]
        return root

    def union(self, left: Leaf, right: Leaf) -> None:
        a, b = self.key(left), self.key(right)
        if a == b:
            return
        self.parent[b] = a
        for store in (self.edges, self.rev):
            if b in store:
                store[a] |= store.pop(b)
        for store in (self.reads, self.writes):
            if b in store:
                store[a].extend(store.pop(b))
        # Prefer a name that is not a REDEFINES alias for display.
        if is_plumbing(self.labels.get(a, "")) and not is_plumbing(self.labels.get(b, "")):
            self.labels[a] = self.labels[b]

    def add_edge(self, src: Leaf, dst: Leaf) -> None:
        a, b = self.key(src), self.key(dst)
        if a != b:
            self.edges[a].add(b)
            self.rev[b].add(a)

    def add_read(self, leaf: Leaf, use: Use) -> None:
        self.reads[self.key(leaf)].append(use)

    def add_write(self, leaf: Leaf, use: Use) -> None:
        self.writes[self.key(leaf)].append(use)


# --------------------------------------------------------------------------- #
# Analyzer
# --------------------------------------------------------------------------- #

CALL_TARGET_RE = re.compile(r"CALL\s+(?:'([A-Z0-9#@$]+)'|([A-Z0-9#@$-]+))", re.I)


class Analyzer:
    def __init__(self, facts: Facts, root: str, quiet: bool = False,
                 stop: frozenset[str] = frozenset()) -> None:
        self.facts = facts
        self.root = root
        self.quiet = quiet
        # Other MUs' entry points (`mu.yaml` `boundaries`): called, never loaded.
        self.stop = stop
        self.programs: dict[str, Program] = {}
        self.graph = Graph()
        self.warnings: list[str] = []
        self.unresolved: dict[str, int] = defaultdict(int)
        self.ignored_reads: dict[str, dict[tuple, Use]] = defaultdict(dict)
        self.call_edges: dict[str, set[str]] = defaultdict(set)
        self.views: dict[tuple[str, str], list[Leaf]] = {}
        self.structs: dict[tuple[str, str], list[Leaf]] = {}
        self.root_of: dict[str, dict[str, str]] = {}
        self.by_path: dict[str, dict[str, list[Leaf]]] = {}
        self.defaults: dict[str, dict[str, str]] = {}
        self.nullable: dict[str, set[str]] = {}
        self.occurs: dict[str, dict[str, int]] = {}
        self.groups: dict[str, dict[str, list[str]]] = {}
        self.group_reads: dict[str, dict[str, set[str]]] = defaultdict(
            lambda: defaultdict(set))
        self.direct_reads: dict[str, set[str]] = defaultdict(set)

    def log(self, message: str) -> None:
        if not self.quiet:
            print(message, file=sys.stderr)

    # -- scope -------------------------------------------------------------- #
    def discover(self) -> None:
        """Load the entry program and everything it calls, transitively.

        Only downward: a caller above the entry program passes the views as one
        opaque buffer and says nothing about which fields matter.

        A boundary is not loaded: its tree belongs to another MU. The call edge stays,
        so `alias_calls` treats the target as opaque and keeps what is passed to it.
        """
        queue = deque([self.root])
        while queue:
            name = queue.popleft()
            if name in self.programs:
                continue
            self.log(f"  loading {name}")
            self.programs[name] = build_linkage(self.facts, name, self.warnings)
            self.prime(name)
            for target, _line, _args in self.call_sites(name):
                self.call_edges[name].add(target)
                if target in self.programs or target in self.stop:
                    continue
                if not is_runtime_module(target) and self.facts.program_exists(target):
                    queue.append(target)

    def call_sites(self, program: str) -> list[tuple[str, int, list[str]]]:
        """Every CALL in the procedure division, with its argument names.

        The statement text is fetched rather than inferred: lineage reports a
        call's effect on the fields it touches, not the full argument list, and
        positional matching needs the whole list.
        """
        sites: list[tuple[str, int, list[str]]] = []
        for match in self.facts.code_matches(program, "CALL "):
            if match.get("division") != "PROCEDURE":
                continue
            line = match["lineNumber"]
            text = strip_comments(" ".join(self.facts.source(program, line, line + 12)))
            statement = text.split("END-CALL")[0]
            found = CALL_TARGET_RE.search(statement)
            if not found:
                continue
            target = (found.group(1) or found.group(2) or "").upper()
            args = self.using_args(statement)
            # CA Gen reaches an indirect target through the loader, and also
            # through a data item holding the program name; in both shapes the
            # real target is spelled `<TARGET>-ID`.
            if target == "TIRLGLOD" and args:
                alias = re.fullmatch(r"([A-Z0-9#@$]+)-ID", args[0])
                if alias:
                    target, args = alias.group(1), args[1:]
            else:
                alias = re.fullmatch(r"([A-Z0-9#@$]+)-ID", target)
                if alias:
                    target = alias.group(1)
            sites.append((target, line, args))
        return sites

    @staticmethod
    def using_args(statement: str) -> list[str]:
        """The argument names of one CALL, in order.

        A generated CALL commonly ends with neither a period nor ``END-CALL`` - the
        next statement simply begins on the following line - so the list has to be
        closed at the first word that can only start a new statement. Without that
        stop the accumulation runs straight into the status check that follows every
        call and reports its fields as arguments, which both inflates the argument
        count and marks those fields as consumed by the callee.
        """
        split = re.split(r"\bUSING\b", statement, maxsplit=1)
        if len(split) < 2:
            return []
        tail = re.split(r"\bEND-CALL\b|\.\s", split[1])[0]
        names = []
        for token in re.split(r"[,\s]+", tail):
            token = token.strip().upper()
            if token in STATEMENT_WORDS:
                break
            if token in ("BY", "REFERENCE", "CONTENT", "VALUE", "LENGTH", "OF", ""):
                continue
            if re.fullmatch(r"[A-Z0-9#@$][A-Z0-9#@$-]*", token):
                names.append(token)
            else:
                break
        return names

    # -- aliasing ----------------------------------------------------------- #
    def alias_calls(self) -> None:
        for caller in list(self.programs):
            for target, line, args in self.call_sites(caller):
                callee = self.programs.get(target)
                if callee is None or is_runtime_module(target):
                    self.unresolved[f"{caller} -> {target}"] += 1
                    self.external_call(caller, target, line, args)
                    continue
                if not callee.params:
                    self.unresolved[f"{caller} -> {target}"] += 1
                    continue
                if len(args) != len(callee.params):
                    self.warnings.append(
                        f"{caller}:{line} CALL {target} passes {len(args)} arguments "
                        f"but {target} declares {len(callee.params)} - treated as external")
                    self.external_call(caller, target, line, args)
                    continue
                for arg, param in zip(args, callee.params):
                    if param in RUNTIME_PARAMS or arg in RUNTIME_PARAMS:
                        continue
                    if param == SHARED_PARAM and arg == SHARED_PARAM:
                        self.join_shared(caller, target)
                        continue
                    self.join(caller, arg, target, param, line)

    def join_shared(self, caller: str, callee: str) -> None:
        """Alias the shared control block between caller and callee, by name.

        ``GLOBDATA`` is a copybook rather than a generated view, and the copy each
        program was generated against differs - the batch holds layouts of 108 to 125
        leaves - so position cannot pair them and a length check would only report
        every call site as opaque. Its field names carry no occurrence number and are
        stable across programs, which makes the name the identity here. ``FILLER``
        repeats and identifies nothing, so it is left alone.
        """
        src = {leaf.name: leaf for leaf in self.view_leaves(caller, SHARED_PARAM)
               if leaf.name != "FILLER"}
        for leaf in self.view_leaves(callee, SHARED_PARAM):
            twin = src.get(leaf.name)
            if twin is not None and twin.pic == leaf.pic:
                self.graph.union(twin, leaf)

    def join(self, caller: str, arg: str, callee: str, param: str,
             line: int) -> None:
        """Alias an argument view onto the callee's parameter view, leaf by leaf.

        Both sides are taken from the data-structure inventory, never from the
        lineage layout: a caller's local copy of a view and the callee's own
        declaration are generated from the same model, so they agree leaf for leaf
        in declaration order and in PIC - only the numeric suffix differs. Lineage
        describes only linkage views and omits the REDEFINES aliases, so mixing
        the two sources would compare lists of different lengths.

        Position identifies the pairs and equal PICs confirm it. A disagreement
        means the assumption does not hold for this call, so the arguments are
        treated conservatively rather than fused into the wrong partners.
        """
        src_leaves = self.view_leaves(caller, arg)
        dst_leaves = self.view_leaves(callee, param)
        if not src_leaves or not dst_leaves:
            return
        if len(src_leaves) != len(dst_leaves):
            self.warnings.append(
                f"{caller}:{line} CALL {callee}: {arg} has {len(src_leaves)} leaves "
                f"but {param} has {len(dst_leaves)} - treated as opaque")
            self.external_call(caller, callee, line, [arg])
            return
        mismatch = [(a.name, b.name) for a, b in zip(src_leaves, dst_leaves)
                    if a.pic != b.pic]
        if mismatch:
            self.warnings.append(
                f"{caller}:{line} CALL {callee}: {arg}/{param} disagree at "
                f"{mismatch[0][0]}/{mismatch[0][1]} - treated as opaque")
            self.external_call(caller, callee, line, [arg])
            return
        for src, dst in zip(src_leaves, dst_leaves):
            self.graph.union(src, dst)

    def view_leaves(self, program: str, view: str) -> list[Leaf]:
        """Leaves under one group name, in declaration order.

        Any group can be named at a call site - a level-01 or a view nested inside
        one - so the whole program is indexed and the group is found by owner path.
        """
        cached = self.views.get((program, view))
        if cached is not None:
            return cached
        root = self.roots(program).get(view)
        leaves = [] if root is None else [
            leaf for leaf in self.struct_leaves(program, root)
            if view == root or f".{view}." in f".{leaf.path}."]
        self.views[(program, view)] = leaves
        return leaves

    def struct_leaves(self, program: str, root: str) -> list[Leaf]:
        """Declared leaves of one level-01 group, bridged to their lineage twins.

        A struct leaf and the lineage leaf of the same name in the same program are
        the same field seen through two interfaces, so they are merged on sight:
        that is what lets a write the lineage engine recorded on a linkage field
        travel through an alias chain built from declarations.

        A field's REDEFINES alias is merged with it for the same reason. CA Gen
        declares the alias immediately after the field, in the same group and with
        the same PIC, and marshals view-to-view moves through the alias rather than
        the field - ``MOVE DIR-BUS-UNIT-0009XX TO DIR-BUS-UNIT-0019XX`` - so unless
        the two names are one node the data flow stops at the view boundary.
        """
        key = (program, root)
        if key in self.structs:
            return self.structs[key]
        leaves = build_working_view(self.facts, program, root)
        self.structs[key] = leaves
        previous: Leaf | None = None
        for leaf in leaves:
            if (previous is not None and leaf.name.endswith("XX")
                    and leaf.pic == previous.pic
                    and parent_of(leaf.path) == parent_of(previous.path)):
                self.graph.union(previous, leaf)
            previous = leaf
        prog = self.programs.get(program)
        if prog is not None:
            twins = Counter(leaf.name for view in prog.leaves
                            for leaf in prog.leaves_of(view))
            located = {leaf.name: leaf for view in prog.leaves
                       for leaf in prog.leaves_of(view) if leaf.located}
            for leaf in leaves:
                twin = located.get(leaf.name)
                # FILLER is the one name that repeats, so it identifies nothing.
                if leaf.name == "FILLER":
                    continue
                if twin is not None and twins[leaf.name] == 1:
                    self.graph.union(twin, leaf)
        return leaves

    def prime(self, program: str) -> None:
        """Materialise every declared group of one program.

        Trace steps name their endpoints by field name, and a name can belong to
        any group - working storage included - so the whole declaration has to be
        in the index before the evidence pass runs.
        """
        for root in {entry["root"] for entry in self.facts.field_index(program)}:
            self.struct_leaves(program, root)

    def roots(self, program: str) -> dict[str, str]:
        """Every group name in a program mapped to the level-01 it belongs to."""
        if program in self.root_of:
            return self.root_of[program]
        index: dict[str, str] = {}
        for entry in self.facts.field_index(program):
            for part in entry["owner"].split("."):
                index.setdefault(part, entry["root"])
        self.root_of[program] = index
        return index

    def import_defaults(self, program: str) -> dict[str, str]:
        """The value each import field takes when the caller leaves it unset.

        Read from the generated INIT paragraph rather than inferred: see
        ``INIT_SUBSTITUTE``. A field absent from the result has no substitution, so
        whatever the caller passes is what the program works with.
        """
        if program in self.defaults:
            return self.defaults[program]
        found: dict[str, str] = {}
        for para in self.facts.paragraphs(program):
            if not INIT_PARAGRAPH.match(para.get("name") or ""):
                continue
            body = self.facts.source(program, para["startLine"], para["endLine"])
            text = " ".join(strip_comments(line).strip() for line in body)
            for match in INIT_SUBSTITUTE.finditer(text):
                if not VALIDITY_GUARD.search(match.group("cond")):
                    continue
                value = match.group("value").strip("'")
                found[match.group("field")] = DEFAULT_NAMES.get(
                    value, f"'{value}'" if not value.isdigit() else value)
        self.defaults[program] = found
        return found

    def null_flagged(self, program: str) -> set[str]:
        """Fields that have a null-flag sibling, and so may legitimately be absent.

        CA Gen emits a ``<field>AS`` flag only for an attribute the model marks as
        optional, so the flag's presence is the model's own statement about whether a
        caller has to supply the field.
        """
        if program in self.nullable:
            return self.nullable[program]
        names = {entry["name"] for entry in self.facts.field_index(program)}
        self.nullable[program] = {name[:-2] for name in names
                                  if name.endswith("AS") and name[:-2] in names}
        return self.nullable[program]

    def capacities(self, program: str) -> dict[str, int]:
        """How many occurrences each repeating element can hold.

        The structure inventory reports the nesting but not the ``OCCURS`` count, so
        the declarations are searched for once per program. A count that cannot be
        read - the clause is wrapped onto the next line - leaves the element an array
        of unstated size rather than a scalar.
        """
        if program in self.occurs:
            return self.occurs[program]
        found: dict[str, int] = {}
        for match in self.facts.code_matches(program, "OCCURS"):
            clause = OCCURS_RE.search(match.get("lineContent") or "")
            if clause:
                found[clause.group(1)] = int(clause.group(2))
        self.occurs[program] = found
        return found

    def external_call(self, caller: str, target: str, line: int,
                      args: list[str]) -> None:
        """A target with no analyzed source could do anything to its arguments.

        Treating them as both read and written keeps every field passed to a
        runtime utility, which is the safe direction for a filter.

        The shared control block is the exception, for every unanalysed target and not
        only for the generator's runtime modules. It is passed at every call site, so
        assuming a callee could touch any of it makes all ~125 of its fields both a used
        input and a used output of any program that calls anything opaque. The
        assumption instead is that a callee touches only what it is declared to touch,
        which leaves the evidence about those fields to come from the generated code.

        That assumption is visible in the artifact: a target with no source is listed,
        with the note that this is what was assumed of it. Without it one missing member
        changes a whole tree's contract - `CRR14062`, absent from this batch, was the
        sole reason four GLOBDATA flags appeared as outputs of P7549508 and of nothing
        else.
        """
        use = Use("EXTERNAL", caller, line, f"CALL {target}")
        for arg in args:
            if arg in RUNTIME_PARAMS:
                continue
            if arg == SHARED_PARAM:
                continue
            for leaf in self.view_leaves(caller, arg):
                self.read(caller, leaf, use)
                self.graph.add_write(leaf, use)

    def read(self, program: str, leaf: Leaf, use: Use) -> None:
        """Record that a field's value is consumed, unless it is a special case.

        One kind of read is deliberately discarded: a status-header field tested in
        the entry program itself (``ROOT_IGNORED_READS``). Keeping it would report
        the whole header as a required input on the strength of a test the caller
        cannot meaningfully influence.
        """
        if program == self.root and base_name(leaf.name) in ROOT_IGNORED_READS:
            # The same test arrives once per lineage edge that is guarded by it,
            # so the note records each distinct site rather than each sighting.
            site = (use.kind, use.line, use.condition)
            if site not in self.ignored_reads[leaf.name]:
                self.ignored_reads[leaf.name][site] = use
            return
        self.graph.add_read(leaf, use)

    # -- evidence ----------------------------------------------------------- #
    def gather(self) -> None:
        for name in self.programs:
            self.log(f"  evidence for {name}")
            self.gather_program(name)
            self.local_flow(name)

    def name_index(self, program: str) -> dict[str, Leaf]:
        """Leaves of one program by field name, linkage views taking precedence.

        The working-storage groups in here are the ones aliasing already pulled in,
        so a MOVE between a local copy of a view and the linkage view itself - the
        hop CA Gen puts around every call - resolves on both ends.
        """
        prog = self.programs[program]
        index = {leaf.name: leaf for view in prog.leaves
                 for leaf in prog.leaves_of(view)}
        for (owner, _root), leaves in self.structs.items():
            if owner == program:
                for leaf in leaves:
                    index.setdefault(leaf.name, leaf)
        index.pop("FILLER", None)
        return index

    def gather_program(self, program: str) -> None:
        index = self.name_index(program)
        for row in self.facts.mappings(program):
            target = row["targetName"].lstrip(".")
            leaf = index.get(target)
            ref = row.get("traceRef")
            if leaf is None or not ref:
                continue
            chains = self.facts.trace(program, ref).get("chains", [])
            self.record_write(program, leaf, row, chains)
            self.record_reads(program, index, chains)
            for chain in chains:
                self.record_flow(program, index,
                                 chain.get("nodes", []), chain.get("steps", []))

    def record_write(self, program: str, leaf: Leaf, row: dict,
                     chains: list[dict]) -> None:
        """Record one write per chain, so each origin is judged on its own label.

        A field is often written from several places - a real DB2 fetch and the
        generated initialisation both land on it - and collapsing them would let
        the weakest evidence decide.
        """
        if not chains:
            return
        for chain in chains:
            kind = classify_origin(chain)
            condition = (chain.get("conditions") or [{}])[0].get("text", "")
            line = next((step.get("line") for step in chain.get("steps", [])
                         if step.get("line")), None)
            self.graph.add_write(leaf, Use(
                kind, program, line,
                detail=origin_detail(chain, row), condition=condition))

    def record_reads(self, program: str, index: dict[str, Leaf],
                     chains: list[dict]) -> None:
        """A field named in a guard is read; so is a field used as a source."""
        for chain in chains:
            for condition in chain.get("conditions", []):
                self.record_condition(program, index, condition)
            for step in chain.get("steps", []):
                for condition in step.get("conditions", []):
                    self.record_condition(program, index, condition)

    def record_condition(self, program: str, index: dict[str, Leaf],
                         condition: dict) -> None:
        if is_validity_check(condition.get("text")):
            return
        use = Use("COND", program, condition.get("line"),
                  detail=condition.get("kind") or "IF",
                  condition=condition.get("text", ""))
        for name in condition.get("fields", []):
            leaf = index.get(name)
            if leaf is not None:
                self.direct_reads[program].add(name)
                self.read(program, leaf, use)
                continue
            # A condition can name a group rather than a field: `EVALUATE
            # PSMGR-IEF-COMMAND` tests 80 bytes declared as two leaves, and the
            # dispatch of every entry program is written that way. The index holds
            # leaves only, so without this the most-read field in the program is
            # dropped - 1874 sightings of that one group in P7549500 alone. Reading a
            # group reads everything in it.
            members = self.group_members(program).get(name, ())
            if members:
                self.group_reads[program][name].update(members)
            for member in members:
                leaf = index.get(member)
                if leaf is not None:
                    self.read(program, leaf, use)

    def group_values(self, program: str) -> dict[str, tuple[str, int]]:
        """``leaf -> (group, bytes)`` for groups the program only ever reads whole.

        A group read at group level whose leaves are never named on their own is one
        value in the program's eyes, and reporting its parts separately misleads:
        `PSMGR-IEF-COMMAND` is `X(8)` plus `X(72)`, the command and its padding, and
        every statement in the batch that tests it tests all 80 bytes. Such a group is
        reported as one field of its full width.
        """
        found: dict[str, tuple[str, int]] = {}
        for group, members in self.group_reads[program].items():
            if members & self.direct_reads[program]:
                continue
            index = self.name_index(program)
            leaves = [index[name] for name in members if name in index]
            if len(leaves) < 2:
                continue
            width = sum(leaf.size for leaf in leaves)
            for leaf in leaves:
                found[leaf.name] = (group, width)
        return found

    def group_members(self, program: str) -> dict[str, list[str]]:
        """``group -> the fields inside it``, for every group the program declares.

        A field is registered against every group it sits under, so a condition naming
        any level of the hierarchy resolves to the leaves it covers.
        """
        if program in self.groups:
            return self.groups[program]
        found: dict[str, list[str]] = defaultdict(list)
        for entry in self.facts.field_index(program):
            if not entry["pic"]:
                continue
            for owner in entry["owner"].split(".")[:-1]:
                found[owner].append(entry["name"])
        self.groups[program] = found
        return found

    # -- flow within a program ---------------------------------------------- #
    def record_flow(self, program: str, index: dict[str, Leaf],
                    nodes: list[dict], edges: list[dict]) -> None:
        """Turn lineage edges into flow edges between leaves.

        Each edge names the storage it moved value between, so this already is the
        intra-program data flow - there is nothing to infer. Edges whose endpoints
        are whole views rather than fields are skipped: an edge between two groups
        says nothing about which field reached which.

        When the destination is storage the inventory does not describe, the value
        has left the model and the move has to count as consuming it. In practice
        that destination is a CA Gen SQL host variable - generated outside the data
        structures - so this is how a field used in a WHERE clause or an INSERT is
        recognised.
        """
        by_id = {node["id"]: node for node in nodes}
        for edge in edges:
            sources = self.leaves_under(program, by_id.get(edge.get("from")))
            target_node = by_id.get(edge.get("to"))
            targets = self.leaves_under(program, target_node)
            if not sources:
                continue
            if not targets:
                for source in sources:
                    self.read(program, source, Use(
                        "SQL-IN", program, edge.get("line"),
                        detail=f"-> {(target_node or {}).get('label') or '?'}",
                        condition=edge.get("condition") or ""))
                continue
            if len(sources) != len(targets):
                continue
            # A field-to-field move may truncate or convert, so PICs are expected
            # to differ there. Pairing the leaves of two groups by position only
            # holds if the groups really are the same shape, so that is checked.
            if len(sources) > 1 and any(a.pic != b.pic
                                        for a, b in zip(sources, targets)):
                continue
            for source, target in zip(sources, targets):
                if source is target:
                    continue
                self.graph.add_edge(source, target)
            for condition in edge.get("conditions", []):
                self.record_condition(program, index, condition)

    def leaves_under(self, program: str, node: dict | None) -> list[Leaf]:
        """The leaves one lineage node stands for, in declaration order.

        CA Gen moves whole entity views - ``MOVE LOCAL-REINTYP-0003EV TO
        IMPORT-REINTYP-0049EV`` - so most flow edges join two groups rather than
        two fields. Both groups are generated from the same model, so their leaves
        correspond by position, which is how a group move becomes field-level flow.
        The node's qualified name is used rather than its label, because a bare
        view name can occur under more than one level-01 group.
        """
        if node is None:
            return []
        qualified = node.get("qualifiedName") or node.get("label") or ""
        path = ".".join(reversed(qualified.split(" OF ")))
        return self.path_index(program).get(path, [])

    def path_index(self, program: str) -> dict[str, list[Leaf]]:
        """Every group path in a program mapped to the leaves beneath it."""
        if program in self.by_path:
            return self.by_path[program]
        index: dict[str, list[Leaf]] = defaultdict(list)
        for (owner, _root), leaves in self.structs.items():
            if owner != program:
                continue
            for leaf in leaves:
                parts = leaf.path.split(".")
                for depth in range(1, len(parts) + 1):
                    index[".".join(parts[:depth])].append(leaf)
        self.by_path[program] = dict(index)
        return self.by_path[program]

    def local_flow(self, program: str) -> None:
        """Recover every assignment inside one program as flow edges.

        Each written field is expanded one hop backwards; since every source of a
        hop is itself a written field, one hop per target reconstructs the whole
        flow graph without walking any path twice. This is what carries the moves
        between a program's own working-storage views - where CA Gen marshals every
        call - which ``s2t`` never reports, and it is also the only complete view of
        a linkage field's writers, because the ``s2t`` trace stops after 25 chains.
        """
        index = self.name_index(program)
        for kind, anchor in self.facts.written_targets(program):
            if kind in EXTERNAL_ENDPOINTS:
                self.record_sql_write(program, index, anchor)
                continue
            hop = self.facts.hop(program, anchor)
            self.record_flow(program, index, hop["nodes"], hop["edges"])

    def record_sql_write(self, program: str, index: dict[str, Leaf],
                         anchor: str) -> None:
        """Mark every field that feeds one write to a table, file or queue.

        The value does not go straight from a declared field into the statement:
        CA Gen copies it into a generated SQL host variable, which is not part of
        any data structure and so cannot be matched to a leaf. Such intermediates
        are followed backwards until declared storage is reached, and that is the
        field the statement really consumes.
        """
        seen: set[str] = set()
        queue = deque([(anchor, 0)])
        while queue:
            node_id, depth = queue.popleft()
            if node_id in seen or depth > SQL_HOST_HOPS:
                continue
            seen.add(node_id)
            hop = self.facts.hop(program, node_id)
            by_id = {node["id"]: node for node in hop["nodes"]}
            for edge in hop["edges"]:
                source = by_id.get(edge.get("from"))
                leaves = self.leaves_under(program, source)
                target = by_id.get(edge.get("to")) or {}
                for leaf in leaves:
                    self.read(program, leaf, Use(
                        "SQL-IN", program, edge.get("line"),
                        detail=f"-> {target.get('label') or '?'}",
                        condition=edge.get("condition") or ""))
                if not leaves and source is not None:
                    queue.append((source["id"], depth + 1))
                for condition in edge.get("conditions", []):
                    self.record_condition(program, index, condition)

    def run(self) -> None:
        self.log("discovering call tree")
        self.discover()
        self.log(f"aliasing arguments across {len(self.programs)} programs")
        self.alias_calls()
        self.log("gathering lineage evidence")
        self.gather()


def classify_origin(chain: dict) -> str:
    """What one lineage chain proves about the value that reaches the target."""
    kind = chain.get("originKind") or ""
    label = str(chain.get("originLabel") or "")
    if kind == "OPERATION":
        return "INIT" if INIT_LABEL_RE.match(label.strip()) else "COMPUTED"
    if kind == "LITERAL":
        return "BLANK" if is_figurative_only(label) else "LITERAL"
    if kind == "ENDPOINT":
        # An endpoint is either a column of an external system - a real value
        # arriving from outside, spelled `DB2(TABLE)` - or this program's own
        # linkage, in which case the value belongs to the caller and aliasing
        # already accounts for it.
        return "SQL-OUT" if EXTERNAL_SYSTEM_RE.match(
            str(chain.get("originSystem") or "")) else "FLOW"
    return ORIGIN_WRITE_KIND.get(kind, "COMPUTED")


def origin_detail(chain: dict, row: dict) -> str:
    kind = chain.get("originKind") or "?"
    label = str(chain.get("originLabel") or "").strip()
    system = str(chain.get("originSystem") or "").strip()
    head = f"{system}.{label}" if system and label else (system or f"{kind} {label}")
    return head.strip() or summarize(row.get("sourceName"))


def summarize(sources: str | None) -> str:
    if not sources:
        return ""
    parts = [p.strip() for p in sources.split(",") if p.strip()]
    head = ", ".join(parts[:2])
    return head + (" ..." if len(parts) > 2 else "")


# --------------------------------------------------------------------------- #
# Verdicts
# --------------------------------------------------------------------------- #


@dataclass
class Verdict:
    status: str
    used: bool
    reason: str
    witness: str = ""
    condition: str = ""


def real_reads(graph: Graph, node: tuple) -> list[Use]:
    return [u for u in graph.reads.get(node, []) if u.kind in READ_KINDS]


def real_writes(graph: Graph, node: tuple) -> list[Use]:
    return [u for u in graph.writes.get(node, []) if u.kind in WRITE_REAL]


def search(graph: Graph, start: tuple, forward: bool, accept,
           stop: set[tuple] | None = None) -> tuple[list[tuple], object]:
    """Breadth-first walk returning the first accepted node and the path to it.

    ``stop`` nodes are examined but not walked past. The other side of this
    program's own contract is such a boundary: a value that has reached the export
    view has left this program, and whatever happens to it after that is the
    caller's doing, not evidence about this program. Without the boundary the walk
    crosses into the caller - caller and callee share the storage - and reports the
    caller's database read as if this program had produced the value.
    """
    store = graph.edges if forward else graph.rev
    blocked = stop or set()
    seen = {start}
    queue = deque([(start, [start])])
    while queue:
        node, path = queue.popleft()
        hit = accept(node)
        if hit:
            return path, hit
        if node in blocked and node != start:
            continue
        for nxt in store.get(node, ()):  # noqa: B007
            if nxt not in seen:
                seen.add(nxt)
                queue.append((nxt, path + [nxt]))
    return [], None


def classify_import(graph: Graph, node: tuple, exports: set[tuple]) -> Verdict:
    """An import leaf survives if its value can influence anything.

    A genuine read is looked for first, so a field that is both echoed to the
    response and consumed somewhere is reported by what it is actually for. A field
    that is *only* echoed carries no information of its own - the caller already has
    the value it would get back - so it is dropped rather than kept.
    """
    path, hit = search(graph, node, True,
                       lambda n: (real_reads(graph, n) or [None])[0], exports)
    if hit:
        return Verdict("USED", True, str(hit), render(graph, path), hit.condition)
    path, hit = search(graph, node, True, lambda n: n in exports and n != node)
    if hit:
        return Verdict("ECHOED", False, "only copied through to an export field",
                       render(graph, path))
    return Verdict("UNUSED", False, "never read, and never reaches the export view")


def classify_export(graph: Graph, node: tuple, imports: set[tuple]) -> Verdict:
    """An export leaf survives if real information can reach it."""
    path, hit = search(graph, node, False,
                       lambda n: (real_writes(graph, n) or [None])[0], imports)
    if hit:
        return Verdict("USED", True, str(hit), render(graph, path), hit.condition)
    path, hit = search(graph, node, False, lambda n: n in imports and n != node)
    if hit:
        return Verdict("ECHOED", False, "only echoed back from an import field",
                       render(graph, path))
    writes = graph.writes.get(node, [])
    if not writes or all(w.kind in WRITE_EMPTY for w in writes):
        return Verdict("NEVER-WRITTEN", False,
                       "only ever blanked by the generated view initialisation")
    return Verdict("ALWAYS-EMPTY", False,
                   "only assigned from fields that are themselves never populated")


def render(graph: Graph, path: list[tuple]) -> str:
    if len(path) < 2:
        return ""
    return " -> ".join(f"{node[0]}.{graph.labels.get(node, '?')}" for node in path)


# --------------------------------------------------------------------------- #
# Output
# --------------------------------------------------------------------------- #

def view_contract(analyzer: Analyzer, program: str, direction: str,
                  include_plumbing: bool = False) -> list[tuple[Leaf, Verdict]]:
    """One program's import or export view, every leaf with its verdict.

    The verdict is relative to the program itself: an import survives if its value
    can influence something at or below this program, an export if information can
    reach it from below. For the entry program that is the migration contract; for
    a program further down it is what its own call sites really have to pass in and
    take back out.
    """
    graph = analyzer.graph
    prog = analyzer.programs[program]
    opposite = "export" if direction == "import" else "import"
    across = {graph.key(leaf) for view in contract_views(prog, opposite)
              for leaf in prog.leaves_of(view) if leaf.located}

    contract: list[tuple[Leaf, Verdict]] = []
    best: dict[tuple, Leaf] = {}
    for view in contract_views(prog, direction):
        for leaf in prog.leaves_of(view):
            if not include_plumbing and (is_plumbing(leaf.name) or is_scratch(leaf)
                                         or is_infrastructure(leaf)):
                continue
            if direction == "import" and base_name(leaf.name) in FAILURE_FLAGS:
                continue
            if direction == "export" and base_name(leaf.name) in DIAGNOSTIC_FIELDS:
                continue
            if not leaf.located:
                contract.append((leaf, Verdict(
                    "UNUSED", False,
                    "no lineage recorded: nothing reads or writes it")))
                continue
            node = graph.key(leaf)
            current = best.get(node)
            if current is None or (is_plumbing(current.name)
                                  and not is_plumbing(leaf.name)):
                best[node] = leaf
    for node, leaf in best.items():
        verdict = (classify_import(graph, node, across) if direction == "import"
                   else classify_export(graph, node, across))
        contract.append((leaf, with_own_name(verdict, program, leaf)))
    contract.sort(key=lambda pair: (pair[0].view, pair[0].offset))
    return collapse_group_values(analyzer, program, contract)


def collapse_group_values(analyzer: Analyzer, program: str,
                          contract: list[tuple[Leaf, Verdict]]
                          ) -> list[tuple[Leaf, Verdict]]:
    """Report a group the program only reads whole as one field, not as its parts."""
    whole = analyzer.group_values(program)
    collapsed: list[tuple[Leaf, Verdict]] = []
    seen: set[str] = set()
    for leaf, verdict in contract:
        found = whole.get(leaf.name)
        if found is None:
            collapsed.append((leaf, verdict))
            continue
        group, width = found
        if group in seen:
            continue
        seen.add(group)
        collapsed.append((replace(leaf, name=group, pic=f"X({width})"), verdict))
    return collapsed


def with_own_name(verdict: Verdict, program: str, leaf: Leaf) -> Verdict:
    """Start the witness path at the field being reported.

    Fields that share storage are one node in the flow graph, and the graph keeps
    one label per node - whichever leaf was seen first. That label is a correct
    name for the storage but not necessarily the name asked about, so a path can
    open on a sibling of the field it explains. The rest of the path is unaffected:
    only the first hop is this field's own view.
    """
    if not verdict.witness:
        return verdict
    _, _, rest = verdict.witness.partition(" -> ")
    opening = f"{program}.{leaf.name}"
    return replace(verdict, witness=f"{opening} -> {rest}" if rest else opening)


def contract_views(prog: Program, direction: str) -> list[str]:
    """The parameter views of one program that carry data in the given direction.

    A procedure step wraps its whole contract in ``W-IA`` / ``W-OA``, but the
    service tiers below it declare one level-01 per entity view and pass them as
    separate arguments, so the direction has to come from the view name. Two naming
    schemes are in use for those, in roughly equal measure - ``IMPORT-nnnnEV`` /
    ``EXPORT-nnnnEV`` and ``IN-nnnnEV`` / ``OUT-nnnnEV`` - and a word has to match
    whole: ``LAYOUT`` is not an outbound view.

    ``GLOBDATA`` is in both lists: it is one copy shared by the whole tree, so a field
    of it can carry data in either direction and only its verdict can say which.

    A name claiming both directions (``IMPORT-EXPORT-GROUP-BE-0004RG``) is read as an
    import, which is where the generator declares all 14 of them. Anything else
    unrecognised also counts as an import, which keeps its fields rather than silently
    dropping them; the known gap is a view named after its function id
    (``S0124562072-0002EV``), which is an export the name cannot distinguish.
    """
    views = []
    for view in prog.params:
        if view in RUNTIME_PARAMS or view not in prog.leaves:
            continue
        if view == SHARED_PARAM:
            # One shared copy, read and written by caller and callee alike, so it
            # belongs to both directions and the verdicts sort out which fields matter.
            views.append(view)
            continue
        words = set(view.split("-"))
        outbound = view == EXPORT_VIEW or bool(
            VIEW_SUFFIX.search(view) and words & OUTBOUND_WORDS
            and not words & INBOUND_WORDS)
        if outbound == (direction == "export"):
            views.append(view)
    return views


def special_case_note(analyzer: Analyzer) -> list[str]:
    """Spell out the status-header reads that were deliberately not counted.

    The filter is a judgement about CA Gen's generated response handling rather
    than something the lineage facts say, so the artifact has to carry its own
    justification and name the exact lines that were set aside.
    """
    if not analyzer.ignored_reads:
        return []
    note = [f"## Special case: `{'`, `'.join(sorted(ROOT_IGNORED_READS))}-*`", "",
            f"These fields of the generated request/response header are read inside "
            f"`{analyzer.root}` itself, but the read is not counted and the import "
            f"side is therefore reported as echoed rather than used.", "",
            "The entry program copies the import occurrence into its export twin, "
            "dispatches on the requested table, and then tests the export twin. "
            "Every dispatch branch assigns the field first, so only the "
            "fall-through branch can still observe what the caller passed. On top "
            "of that the generated INIT block replaces anything non-numeric with "
            "zero, so a caller that does not set the field deliberately gets the "
            "normal path. Counting that test would present the status header as a "
            "required input on the strength of behaviour no caller is expected to "
            "rely on.", "",
            "The export occurrence is unaffected: it is kept on its own merits, "
            "because the program assigns it a response code directly.", "",
            "| Field | Read that was set aside |", "|---|---|"]
    for name, uses in sorted(analyzer.ignored_reads.items()):
        for use in uses.values():
            where = f"{use.program}:{use.line}"
            detail = f" `{use.condition}`" if use.condition else ""
            note.append(f"| `{name}` | {use.kind} @ {where}{detail} |")
    note.append("")
    return note


def write_tree(path: Path, analyzer: Analyzer, include_plumbing: bool) -> None:
    """The call tree with the contract each call actually needs.

    Every program appears with the import fields that have to be passed down to it
    and the export fields that carry information back up; fields that nothing below
    reads, and fields nothing ever populates, are left out. A program is expanded
    once - the second call site onto the same program shows the same contract, so
    it is only referred back to.
    """
    contracts: dict[str, dict[str, list[tuple[Leaf, Verdict]]]] = {}

    def contract_of(program: str) -> dict[str, list[tuple[Leaf, Verdict]]]:
        if program not in contracts:
            contracts[program] = {
                direction: view_contract(analyzer, program, direction,
                                         include_plumbing)
                for direction in ("import", "export")}
        return contracts[program]

    lines: list[str] = []
    expanded: set[str] = set()
    order: list[str] = []

    def emit(program: str, depth: int, stack: tuple[str, ...]) -> None:
        pad = "   " * depth
        kept = contract_of(program)
        seen = program in expanded
        expanded.add(program)
        if not seen:
            order.append(program)
        head = f"{pad}-> {program}" if depth else program
        lines.extend(wrap_fields(head, used_names(kept["import"])))
        if not seen:
            for target in sorted(analyzer.call_edges.get(program, ())):
                if is_runtime_module(target):
                    # A runtime module still consumes whatever it is passed, so it
                    # keeps its arguments in the contract; it is just not a step in
                    # the application's own call tree and only adds noise here.
                    continue
                if target in stack:
                    lines.append(f"{pad}   -> {target} (recursive call)")
                elif target in analyzer.programs:
                    emit(target, depth + 1, stack + (program,))
                elif target in analyzer.stop:
                    lines.append(f"{pad}   -> {target} (boundary: another MU's entry point)")
                else:
                    lines.append(f"{pad}   -> {target} (no analyzed source)")
        lines.extend(wrap_fields(f"{pad}<- {program}", used_names(kept["export"])))

    emit(analyzer.root, 0, ())

    body = [f"# {analyzer.root} - call tree contract", "",
            f"What each call in the tree below `{analyzer.root}` has to pass down "
            f"(`->`) and what it brings back (`<-`), after dropping the fields "
            f"nothing below reads and the fields nothing ever populates.", "",
            "```", *lines, "```", "",
            *interfaces_note(analyzer, order, contracts),
            *special_case_note(analyzer),
            *opaque_targets_note(analyzer), *warnings_note(analyzer)]
    path.write_text("\n".join(body))


def interfaces_note(analyzer: Analyzer, order: list[str],
                    contracts: dict[str, dict[str, list[tuple[Leaf, Verdict]]]]
                    ) -> list[str]:
    """A typed signature per program, each with what it drops and why.

    The tree answers which fields cross each call; this answers what they are and
    accounts for the rest. Programs appear in the order the tree expands them, once
    each. Fields are listed in declaration order within their direction, so the
    block reads as the record a caller passes rather than as a set.
    """
    if not order:
        return []
    note = ["## Interfaces", "",
            "The filtered contract of each program, with declared types. Types are "
            "the COBOL picture restated: `char(n)` is a fixed-width, space-padded "
            "field of n bytes, `int(n)` an n-digit zoned decimal, and "
            "`decimal(p,s)` an implied-point number of p digits with s of them "
            "after the point. `signed` carries an operational sign.", "",
            "`array[n] of:` is a repeating group: the fields indented under it exist "
            "once per entry, up to n entries. The count beside it - the field ending "
            "in `MA`, marked `entry count` - says how many of those entries are "
            "actually filled; the rest of the allocation is untouched.", "",
            "Inputs also carry whether a caller has to supply them. `optional` means "
            "two things were found together: the model allows the field to be absent "
            "(the generator emitted a null flag for it) and the code has a path for "
            "it being absent (the read that keeps the field sits behind a test of that "
            "field for emptiness). `required` is the absence of that evidence, not "
            "proof of the opposite - the field is either not nullable in the model or "
            "is consumed with no empty-value path of its own. `default` is what the generated INIT paragraph "
            "puts in the field when the caller leaves it unset; it applies either way, "
            "and for a required field it is what the program will proceed with rather "
            "than a value to rely on.", "",
            "One behaviour is common to every generated program and is therefore not "
            "repeated per field below: on entry each input is checked for malformed "
            "content and replaced - a character field holding binary junk becomes "
            "spaces, a numeric field holding non-digits becomes zero - and the output "
            "views are cleared. That check is a test of the field, but it asks only "
            "whether the caller supplied something usable, so it is not counted as a "
            "use of the value. A field reported as dropped below can still come back "
            "normalised in this way; what the report means is that nothing examines, "
            "stores or computes from the value it carries.", "",
            "Fields of the shared control block `GLOBDATA` are part of the contract "
            "too. One copy is threaded through the whole tree, so a field of it can "
            "carry data in either direction and appears in whichever of the two its "
            "verdict supports. Its runtime-function registers are excluded - the "
            "`PSMGR-FUNC-*`, `PSMGR-TIRDATE-*`, `DDURA-*` and `TDURA-*` slots the "
            "generated code fills, hands to a date or time module, and reads back "
            "within one statement sequence. Over the whole batch none of them is ever "
            "read before being written locally and none is ever left holding a value "
            "across a call, so they carry nothing between programs.", "",
            "`RV-SERVER-DATE` is excluded for a different reason: it holds a clock "
            "reading. The entry program reads the date once and the whole tree works "
            "from that one value, stamping it on rows and comparing against it, so the "
            "field is how the date travels rather than something a caller decides. The "
            "behaviour that has to survive a migration is that the date is fixed once "
            "per transaction - recorded in the format specification - not the "
            "field itself.", ""]
    for program in order:
        note.extend([f"### {program}", "", "```"])
        contract = contracts.get(program, {})
        for direction, keyword in (("import", "IN"), ("export", "OUT")):
            kept = [(leaf, verdict) for leaf, verdict in contract.get(direction, [])
                    if verdict.used]
            if not kept:
                note.append(f"{keyword}: (none)")
                continue
            note.append(f"{keyword}:")
            rows = [(leaf, pseudo_type(leaf.pic),
                     obligation(analyzer, program, leaf, verdict)
                     if direction == "import" else "")
                    for leaf, verdict in kept]
            note.extend(interface_rows(analyzer, program, rows))
        note.extend(["```", ""])
        note.extend(dropped_table(contract))
    return note


def interface_rows(analyzer: Analyzer, program: str,
                   rows: list[tuple[Leaf, str, str]]) -> list[str]:
    """One interface block, with repeating groups shown as arrays.

    Fields arrive in declaration order, so the members of a repeating group are
    already adjacent and a run of them becomes one indented block under its element.
    The entry counter is declared beside the element rather than inside it, so it
    stays a field of its own and is labelled for what it counts.
    """
    capacity = analyzer.capacities(program)
    # A counter is labelled from the declaration, not from the rows kept: the group it
    # counts can be dropped in full and the counter still survive on its own.
    counters = {element + "MA" for element in capacity}
    lines: list[str] = []
    for element, run in groupby(rows, key=lambda row: array_element(row[0])):
        members = [(leaf.name, pic, tail) for leaf, pic, tail in run]
        if not element:
            lines.extend(column_rows(members, "    ", counters))
            continue
        size = capacity.get(element)
        lines.append(f"    {element}  array[{size if size else '?'}] of:")
        lines.extend(column_rows(members, "        ", counters))
    return lines


def column_rows(members: list[tuple[str, str, str]], pad: str,
                counters: set[str]) -> list[str]:
    name_width = max(len(name) for name, _, _ in members)
    type_width = max(len(pic) for _, pic, _ in members)
    lines = []
    for name, pic, tail in members:
        if name in counters:
            tail = f"{tail}, entry count" if tail else "entry count"
        lines.append(f"{pad}{name:<{name_width}}  {pic:<{type_width}}  {tail}".rstrip())
    return lines


def obligation(analyzer: Analyzer, program: str, leaf: Leaf,
               verdict: Verdict) -> str:
    """Whether a caller has to supply one input field, and what it gets if not."""
    nullable = leaf.name in analyzer.null_flagged(program)
    absent_path = tests_own_emptiness(verdict.condition, leaf)
    default = analyzer.import_defaults(program).get(leaf.name)
    status = "optional" if nullable and absent_path else "required"
    return f"{status}, default {default}" if default else status


def dropped_table(contract: dict[str, list[tuple[Leaf, Verdict]]]) -> list[str]:
    """The fields left out of one program's interface, with the reason.

    Carried next to the interface rather than in a separate artifact, because the
    omissions are the part of the result that needs justifying: a field is only
    absent because no evidence was found that anything consumes or produces it,
    and that claim should be reviewable where it is made.
    """
    rows = [(direction, leaf, verdict)
            for direction in ("import", "export")
            for leaf, verdict in contract.get(direction, [])
            if not verdict.used]
    if not rows:
        return []
    table = [f"Dropped ({len(rows)}):", "",
             "| Field | Dir | Type | Verdict | Why |", "|---|---|---|---|---|"]
    for direction, leaf, verdict in rows:
        table.append(f"| `{leaf.name}` | {'in' if direction == 'import' else 'out'} "
                     f"| `{pseudo_type(leaf.pic)}` | {verdict.status} "
                     f"| {verdict.reason} |")
    table.append("")
    return table


def pseudo_type(pic: str) -> str:
    """A COBOL picture as a language-neutral type.

    Nothing is inferred beyond what the picture states: the width, the digit count
    and the implied decimal position are what a target language has to reproduce to
    stay byte-compatible with the mainframe layout, so they are preserved verbatim
    rather than rounded up to a native type.
    """
    text = (pic or "").strip().upper()
    # A character picture states its width either as a count or by repeating the
    # symbol - `X(2)` and `XX` are the same two bytes.
    match = re.fullmatch(r"(X+)(?:\((\d+)\))?", text)
    if match:
        repeated, count = match.groups()
        return f"char({count or len(repeated)})"
    match = re.fullmatch(r"(S?)(?:9\((\d+)\)|(9+))?"
                         r"(?:V(?:9\((\d+)\)|(9+)))?", text)
    if match and text:
        sign, digits, repeated, frac_digits, frac_repeated = match.groups()
        whole = int(digits) if digits else len(repeated or "")
        frac = int(frac_digits) if frac_digits else len(frac_repeated or "")
        prefix = "signed " if sign else ""
        if frac:
            return f"{prefix}decimal({whole + frac},{frac})"
        return f"{prefix}int({whole})"
    # Anything the mapping does not cover is reported as itself rather than
    # guessed at, so an unexpected picture is visible instead of silently wrong.
    return f"PIC {pic}" if pic else "group"


def opaque_targets_note(analyzer: Analyzer) -> list[str]:
    """Call targets whose source was not available to analyse.

    CA Gen runtime modules are left out: that they are opaque, and that their
    arguments therefore count as used, is a property of the generator rather than
    of this call tree. What is worth reporting is an application program that
    should have been analysable and was not, because every field passed to it has
    to be kept on the conservative assumption that it is read.
    """
    by_target: dict[str, dict[str, int]] = defaultdict(dict)
    for name, count in analyzer.unresolved.items():
        caller, _, target = name.partition(" -> ")
        target = target or name
        if is_runtime_module(target):
            continue
        by_target[target][caller] = count
    if not by_target:
        return []
    note = ["## Targets with no analyzed source", "",
            "Every field passed to one of these is treated as both read and written, "
            "and so is kept - except the shared control block `GLOBDATA`, which is "
            "passed to everything. These targets are assumed to touch nothing beyond "
            "what they are declared to touch, the same assumption made of the "
            "generator's runtime modules. Where a target is a generated program, its "
            "absence from the batch is the reason it could not be analysed.", "",
            "| Target | Calls | Called from |", "|---|---|---|"]
    for target in sorted(by_target, key=lambda t: (-sum(by_target[t].values()), t)):
        callers = by_target[target]
        names = ", ".join(f"`{c}`" for c in sorted(callers) if c)
        note.append(f"| `{target}` | {sum(callers.values())} | {names} |")
    note.append("")
    return note


def warnings_note(analyzer: Analyzer) -> list[str]:
    """Places where an assumption about argument matching did not hold."""
    if not analyzer.warnings:
        return []
    return ["## Warnings", "",
            *(f"- {w}" for w in analyzer.warnings[:200]), ""]


def used_names(contract: list[tuple[Leaf, Verdict]]) -> list[str]:
    """The field names of one direction that survived the filter."""
    return [leaf.name for leaf, verdict in contract if verdict.used]


def wrap_fields(head: str, names: list[str], note: str = "") -> list[str]:
    """`head (a, b, c)` folded onto continuation lines when the list is long."""
    if not names:
        return [f"{head} (none){note}"]
    indent = " " * (len(head) - len(head.lstrip()) + 3)
    out, current = [], f"{head} ("
    for index, name in enumerate(names):
        piece = name + ("," if index < len(names) - 1 else "")
        if len(current) + len(piece) > 96 and current.strip() != "(":
            out.append(current.rstrip())
            current = indent
        current += piece + " "
    out.append(current.rstrip() + f"){note}")
    return out


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--root", required=True, help="entry procedure step, e.g. P7549509")
    add_url_argument(parser)
    parser.add_argument("--portfolio", default="2")
    parser.add_argument("--pds", default="SRC")
    parser.add_argument("--out-dir", default="data", type=Path)
    parser.add_argument("--cache-dir", default=Path(".cache/mfanalyzer"), type=Path,
                        help="where analyzer responses are cached")
    parser.add_argument("--no-cache", action="store_true")
    parser.add_argument("--include-plumbing", action="store_true",
                        help="also report CA Gen null flags, counters and aliases")
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument("--mu", type=Path,
                        help="MU folder: do not walk into its mu.yaml boundaries")
    args = parser.parse_args(argv)

    try:
        facts = Facts(portfolio=args.portfolio, pds=args.pds,
                      cache_dir=None if args.no_cache else args.cache_dir,
                      url=args.url, auth=args.auth)
        analyzer = Analyzer(facts, args.root.upper(), quiet=args.quiet,
                            stop=mu_boundaries(args.mu))
        analyzer.run()
    except FactsError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    root = analyzer.programs[analyzer.root]
    if not root.leaves_of(IMPORT_VIEW) and not root.leaves_of(EXPORT_VIEW):
        print(f"error: {analyzer.root} has no {IMPORT_VIEW}/{EXPORT_VIEW} views - "
              "it does not look like a CA Gen procedure step", file=sys.stderr)
        return 2

    args.out_dir.mkdir(parents=True, exist_ok=True)
    tree_path = args.out_dir / f"{analyzer.root}-call-contract.md"
    write_tree(tree_path, analyzer, args.include_plumbing)

    if not args.quiet:
        for direction in ("import", "export"):
            contract = view_contract(analyzer, analyzer.root, direction,
                                     args.include_plumbing)
            kept = sum(1 for _leaf, verdict in contract if verdict.used)
            print(f"{direction:<7} {kept} of {len(contract)} used")
        print(f"programs in scope: {len(analyzer.programs)}")
        print(f"unresolved call targets: {len(analyzer.unresolved)}")
        print(f"warnings: {len(analyzer.warnings)}")
    print(f"wrote {tree_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
