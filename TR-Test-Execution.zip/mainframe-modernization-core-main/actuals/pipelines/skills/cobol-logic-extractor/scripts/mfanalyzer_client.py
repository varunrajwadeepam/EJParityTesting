"""Minimal client for the MF Analyzer MCP server over Streamable HTTP.

The server at ``<base url>/api/mcp`` (local default ``http://localhost:8989``) is the documented way to read
analyzed facts, and it is the only interface that exposes source code and data
structures - the REST surface has no discoverable path for either. It speaks
JSON-RPC over HTTP with a session id handed out by ``initialize``, so a plain
script can use it without an MCP runtime.

A hosted server wants ``Authorization: Bearer <token>`` on every request. The token is
minted here: ``mflens_mcp_auth.py``, bundled next to this file, owns the sign-in and
prints the header as JSON,

    python mflens_mcp_auth.py headers   ->  {"Authorization": "Bearer <id token>"}

(run its ``login`` once). ``HelperAuth`` asks it for the header, reuses it until it nears
expiry and asks again when the server rejects it. ``fetch`` is the one HTTP call both
this client and the REST lineage reader in ``mfanalyzer_facts`` go through.

Responses come back as a ``content`` list of text parts; ``call`` re-parses them
as JSON when it can, because every tool here returns a JSON document as text.
"""

from __future__ import annotations

import base64
import json
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

DEFAULT_BASE_URL = "http://localhost:8989"
MCP_PATH = "/api/mcp"
PROTOCOL_VERSION = "2024-11-05"


class McpError(RuntimeError):
    pass


AUTH_SCRIPT = Path(__file__).with_name("mflens_mcp_auth.py")
REFRESH_MARGIN = 120  # seconds before expiry at which the helper is asked again


class HttpError(RuntimeError):
    pass


class HelperAuth:
    """Authorization header obtained from ``mflens_mcp_auth.py headers``."""

    def __init__(self, helper: str | Path = AUTH_SCRIPT) -> None:
        self.helper = Path(helper)
        self._value: str | None = None
        self._exp = 0.0
        self._lock = threading.Lock()

    def header(self) -> str:
        with self._lock:
            if not self._value or self._exp - time.time() < REFRESH_MARGIN:
                self._value = self._fetch()
                self._exp = _expiry(self._value)
            return self._value

    def invalidate(self) -> None:
        with self._lock:
            self._value = None

    def _fetch(self) -> str:
        if not self.helper.is_file():
            raise HttpError(f"auth helper not found: {self.helper}")
        proc = subprocess.run([sys.executable, str(self.helper), "headers"],
                              capture_output=True, text=True)
        if proc.returncode != 0:
            raise HttpError(proc.stderr.strip()
                            or f"{self.helper} headers failed ({proc.returncode})")
        try:
            return json.loads(proc.stdout)["Authorization"]
        except (json.JSONDecodeError, KeyError, TypeError) as exc:
            raise HttpError(f"{self.helper} headers printed no Authorization "
                            f"header: {proc.stdout[:120]!r}") from exc


def _expiry(authorization: str) -> float:
    """``exp`` of a bearer JWT; an opaque token is trusted for a few minutes."""
    try:
        payload = authorization.split(" ", 1)[1].split(".")[1]
        payload += "=" * (-len(payload) % 4)
        return float(json.loads(base64.urlsafe_b64decode(payload))["exp"])
    except (IndexError, ValueError, KeyError, TypeError):
        return time.time() + 300


def fetch(url: str, *, headers: dict, timeout: int, data: bytes | None = None,
          auth: HelperAuth | None = None):
    """One request. Returns ``(response headers, body text)``.

    With ``auth`` the header is attached, and a 401/403 is retried once on a fresh one.
    A hosted edge answers an unauthenticated call with a redirect to a browser login that
    urllib follows into an HTML page, so an HTML body is reported for what it is rather
    than left to fail later as bad JSON.
    """
    def attempt():
        sent = dict(headers)
        if auth:
            sent["Authorization"] = auth.header()
        request = urllib.request.Request(url, data=data, headers=sent)
        with urllib.request.urlopen(request, timeout=timeout) as response:
            ctype = (response.headers.get("content-type") or "").split(";")[0].strip()
            if ctype == "text/html":
                raise HttpError(
                    f"{url}: redirected to a login page; "
                    + (f"the token was rejected - sign in again: python {AUTH_SCRIPT} login"
                       if auth else "the server needs credentials - pass --auth"))
            return response.headers, response.read().decode("utf-8", "replace")

    try:
        try:
            return attempt()
        except urllib.error.HTTPError as exc:
            if not (auth and exc.code in (401, 403)):
                raise
            auth.invalidate()
            return attempt()
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")[:200]
        hint = " - pass --auth" if exc.code in (401, 403) and not auth else ""
        raise HttpError(f"{url}: HTTP {exc.code}: {detail}{hint}") from exc
    except urllib.error.URLError as exc:
        raise HttpError(f"cannot reach {url}: {exc}") from exc


class McpClient:
    def __init__(self, url: str = DEFAULT_BASE_URL + MCP_PATH, timeout: int = 120,
                 auth: HelperAuth | None = None) -> None:
        self.url = url
        self.timeout = timeout
        self.auth = auth
        self.session: str | None = None
        self.protocol: str | None = None
        self._next_id = 0

    # -- transport ---------------------------------------------------------- #
    def _post(self, payload: dict, want_session: bool = False):
        body = json.dumps(payload).encode()
        headers = {
            "Content-Type": "application/json",
            # The server negotiates between a plain JSON body and an SSE stream;
            # it rejects the request unless both are offered.
            "Accept": "application/json, text/event-stream",
        }
        if self.session:
            headers["mcp-session-id"] = self.session
        if self.protocol:
            headers["MCP-Protocol-Version"] = self.protocol
        try:
            response_headers, raw = fetch(self.url, headers=headers, data=body,
                                          timeout=self.timeout, auth=self.auth)
        except HttpError as exc:
            raise McpError(str(exc)) from exc
        if want_session:
            self.session = response_headers.get("mcp-session-id")
        return parse_response(raw)

    def connect(self) -> None:
        reply = self._post({
            "jsonrpc": "2.0", "id": self._id(), "method": "initialize",
            "params": {
                "protocolVersion": PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {"name": "trvs-mega-scripts", "version": "1"},
            },
        }, want_session=True)
        if not self.session:
            raise McpError("server did not return an mcp-session-id")
        # A hosted server expects the version it negotiated echoed on later requests.
        self.protocol = ((reply or {}).get("result") or {}).get("protocolVersion")
        self._post({"jsonrpc": "2.0", "method": "notifications/initialized"})

    def _id(self) -> int:
        self._next_id += 1
        return self._next_id

    # -- tools -------------------------------------------------------------- #
    def call(self, tool: str, **arguments):
        if self.session is None:
            self.connect()
        message = self._post({
            "jsonrpc": "2.0", "id": self._id(), "method": "tools/call",
            "params": {"name": tool, "arguments": arguments},
        })
        if message is None:
            raise McpError(f"{tool}: empty response")
        if "error" in message:
            raise McpError(f"{tool}: {message['error'].get('message')}")
        result = message.get("result", {})
        if result.get("isError"):
            raise McpError(f"{tool}: {_text_of(result)[:400]}")
        text = _text_of(result)
        try:
            return json.loads(text)
        except (json.JSONDecodeError, TypeError):
            return text

    def tool_names(self) -> list[str]:
        if self.session is None:
            self.connect()
        message = self._post({"jsonrpc": "2.0", "id": self._id(),
                              "method": "tools/list"})
        return [t["name"] for t in (message or {}).get("result", {}).get("tools", [])]


def parse_response(raw: str):
    """Read one JSON-RPC message out of a plain or SSE-framed body."""
    raw = raw.strip()
    if not raw:
        return None
    # An SSE frame opens with any of `id:` / `event:` / `data:`, so the payload
    # is found by looking for the `data:` line rather than by sniffing the first
    # byte of the body.
    data_lines = [line[5:].strip() for line in raw.splitlines()
                  if line.startswith("data:")]
    if not data_lines:
        return json.loads(raw)
    for chunk in data_lines:
        if chunk:
            return json.loads(chunk)
    return None


def _text_of(result: dict) -> str:
    parts = [part.get("text", "") for part in result.get("content", [])
             if part.get("type") == "text"]
    return "\n".join(parts)
