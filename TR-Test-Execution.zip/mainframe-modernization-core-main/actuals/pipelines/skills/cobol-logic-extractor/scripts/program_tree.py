#!/usr/bin/env python3
"""Every program a tree reaches, from an entry point.

    program_tree.py P7549509 [--portfolio 2] [--pds SRC] [--mu <mu>]

Prints one program name per line, the entry first, in breadth-first order - the set to
extract. Nothing else: pipe it into a loop.

With `--mu`, the walk stops at the programs in that MU's `mu.yaml` `boundaries`: other
MUs' entry points. A boundary is not printed and nothing is walked through it; a program
reached on another path is still printed. Each stop is reported on stderr.

WHY THIS EXISTS, AND WHY NOT A GREP
A generated program does not name most of its callees in the `CALL` statement. CA Gen
reaches an action block through its loader, with the name in a data item:

    01  IRR14921-ID  PIC X(8) VALUE 'IRR14921'.
    ...
    CALL 'TIRLGLOD' USING IRR14921-ID ...

so a scan for `CALL '<literal>'` sees `TIRLGLOD`, treats the caller as a leaf, and
reports a tree one layer deep. That mistake is silent: the documents it produces are
correct about the programs they cover and say nothing about the layer below. Measured on
P7549509 it found 15 of 60 members, and the 45 it missed were the ones holding the SQL.

The resolution here is the same one `analyze_view_usage` and `extract_logic` use - a
target spelled `<NAME>-ID`, whether it is the loader's first operand or the call target
itself, is a call to `<NAME>`.

SOURCE COMES FROM THE ANALYZER, NEVER FROM DISK
Like the rest of this skill: `Facts.source` fetches the member from the local MF
Analyzer and caches the response. A tree computed from whatever `.CBL` files happen to
be in a working directory would describe that directory rather than the portfolio - and
a runner bundle is a link set, which is not the same thing as a call tree.
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from analyze_view_usage import (  # noqa: E402
    CALL_TARGET_RE, is_runtime_module)
from mfanalyzer_facts import (  # noqa: E402
    Facts, FactsError, add_url_argument, mu_boundaries)

LOADER = "TIRLGLOD"
LOADER_ALIAS = re.compile(r"^(?P<target>[A-Z0-9#@$]+)-ID$")
USING = re.compile(r"\bUSING\b(?P<args>.*)$", re.S)


def statements(lines: list[str]) -> list[str]:
    """The procedure division's statements, continuations joined.

    Crude on purpose: a call's operands can wrap, and all this needs is the first one.
    """
    out: list[str] = []
    started = False
    for raw in lines:
        body = raw[6:72] if len(raw) > 6 else ""
        if not body.strip() or body[0:1] in ("*", "/"):
            continue
        text = body.strip()
        if not started:
            started = bool(re.search(r"\bPROCEDURE\s+DIVISION\b", text.upper()))
            continue
        if re.match(r"^(CALL|MOVE|IF|PERFORM|EVALUATE|COMPUTE|GO|EXEC)\b", text.upper()):
            out.append(text)
        elif out:
            out[-1] += " " + text
    return out


def targets(facts: Facts, program: str) -> list[str]:
    """The programs this one calls, loader indirection resolved, runtime modules out."""
    found: list[str] = []
    for statement in statements(facts.source(program, 1, 99999)):
        match = CALL_TARGET_RE.search(statement)
        if not match:
            continue
        target = (match.group(1) or match.group(2) or "").upper()
        args = []
        using = USING.search(statement)
        if using:
            args = [part.strip(" ,.") for part in
                    re.split(r"[,\s]+", using.group("args")) if part.strip(" ,.")]
        if target == LOADER and args:
            alias = LOADER_ALIAS.match(args[0])
            if alias:
                target = alias.group("target")
        else:
            alias = LOADER_ALIAS.match(target)
            if alias:
                target = alias.group("target")
        if target and target not in found:
            found.append(target)
    return found


def tree(facts: Facts, entry: str, stop: frozenset[str] = frozenset()
         ) -> tuple[list[str], list[tuple[str, str]], list[tuple[str, str]]]:
    """``(programs, unresolved, stopped)`` - the closure, the targets that are not
    members, and the calls into a program of `stop`.

    `unresolved` is not an error: a target can be a runtime module this skill does not
    model, or a program the analyzer does not hold. It is reported so that a tree with a
    hole in it says so rather than looking complete.
    """
    seen: list[str] = []
    unresolved: list[tuple[str, str]] = []
    stopped: list[tuple[str, str]] = []
    queue = [entry.upper()]
    while queue:
        program = queue.pop(0)
        if program in seen:
            continue
        seen.append(program)
        for target in targets(facts, program):
            if target in seen or target in queue:
                continue
            if is_runtime_module(target):
                continue
            if target in stop:
                if (program, target) not in stopped:
                    stopped.append((program, target))
                continue
            try:
                if not facts.program_exists(target):
                    unresolved.append((program, target))
                    continue
            except FactsError:
                unresolved.append((program, target))
                continue
            queue.append(target)
    return seen, unresolved, stopped


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("entry", help="entry program, e.g. P7549509")
    add_url_argument(parser)
    parser.add_argument("--portfolio", default="2")
    parser.add_argument("--pds", default="SRC")
    parser.add_argument("--cache-dir", default=Path(".cache/mfanalyzer"), type=Path)
    parser.add_argument("--mu", type=Path,
                        help="MU folder: stop at its mu.yaml boundaries")
    args = parser.parse_args()

    stop = mu_boundaries(args.mu)
    if args.entry.upper() in stop:
        print(f"{args.entry}: is both the entry and a boundary in {args.mu / 'mu.yaml'}",
              file=sys.stderr)
        return 1
    try:
        facts = Facts(portfolio=args.portfolio, pds=args.pds,
                      cache_dir=args.cache_dir, url=args.url, auth=args.auth)
        programs, unresolved, stopped = tree(facts, args.entry, stop)
    except FactsError as exc:
        print(f"{args.entry}: {exc}", file=sys.stderr)
        return 1

    for program in programs:
        print(program)
    print(f"{len(programs)} programs", file=sys.stderr)
    for caller, target in unresolved:
        print(f"  unresolved: {caller} -> {target}", file=sys.stderr)
    for caller, target in stopped:
        print(f"  boundary: {caller} -> {target}", file=sys.stderr)
    for target in sorted(stop - {target for _, target in stopped}):
        print(f"  boundary not reached from {args.entry.upper()}: {target}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
