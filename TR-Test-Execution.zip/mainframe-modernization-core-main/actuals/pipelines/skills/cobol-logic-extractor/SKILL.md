---
name: cobol-logic-extractor
description: >
  Use when a generated CA Gen COBOL program has to be read, reviewed, ported or
  explained and the member itself is too large to work with. Produces an extracted-logic
  Markdown document per program - the filtered input/output contract, the locals and
  constants still in use, the repeating-group initialisers, the declared exit states,
  and the procedure division with the generated mechanisms folded into markers. Also
  computes the per-field contract of a whole call tree. Use for questions of the form
  "what does this program do", "what does it take and return", "which fields does the
  caller have to supply", or when translating a program tree into another language.
user-invocable: false
---

# COBOL logic extractor

Turns a generated CA Gen COBOL member into a document a person or an agent can read.
In `mu-design` it produces `<mu>/extracted-logic/`, the only view of the COBOL the design reads.
`P7549500` goes from 1839 source lines to about 280; a six-program tree from 11,440 to
3,400.

`FORMAT.md` in this directory is the specification of the
output: read it before interpreting an extracted-logic document, and hand it to anyone - or any
agent - that has to work from one. The [`tir-cobol`](../tir-cobol/SKILL.md) skill is the companion registry of CA Gen's
runtime modules - what each `TIR*` a `*> @function` names actually does. Read it, never copy it.

**`<mu>/extracted-logic/` holds only what this skill's scripts write**: one `<PROGRAM>.md`
per internal program, and `paragraph-index.json` when `--index` is passed. Put nothing
else there.

## What it needs

The MFLens server that holds the MU's portfolio, reached over HTTP. Source and
declarations are read from there, never from the filesystem. Nothing is written anywhere
except the output file you name and the response cache.

**Every connection value comes from the MU's `tools.yaml`, `mflens` section, and the
portfolio from `mu.yaml`**, read with `tools_config.py`, never typed by hand. `<mu>` is
relative to the workspace root, the folder holding `mu/`:

    T="${CLAUDE_PLUGIN_ROOT}/scripts/tools_config.py"
    S="${CLAUDE_PLUGIN_ROOT}/skills/cobol-logic-extractor/scripts"
    URL=$(python $T <mu> mflens url)
    PORTFOLIO=$(python $T <mu> mu portfolio_id)
    PDS=$(python $T <mu> mflens pds)
    CACHE=$(python $T <mu> mflens cache_dir)
    export MFLENS_MCP_AUTH_CACHE=$(python $T <mu> mflens auth.token_cache)

| Script parameter | From `mflens` | Note |
|---|---|---|
| `--url` | `url` | server root; MCP is `<url>/api/mcp`, REST lineage `<url>/api/v2/lineage` |
| `--portfolio` | `mu.yaml` `portfolio_id` | |
| `--pds` | `pds` | |
| `--cache-dir` | `cache_dir` | **always pass it**: the script default `.cache/mfanalyzer` lands outside the MU's `.tmp/` |
| `--auth` | `auth.method: bearer-helper` | add the flag; omit it only when the section has no `auth` |

Pass the same values on every script call in a run - `extract_logic.py`,
`program_tree.py` and `analyze_view_usage.py`. A cache entry is keyed by what was
asked, not by who was asked, so one cache directory holds the answers of one server
and one portfolio: the directory records which, and a run that disagrees with the
record stops and says so rather than reading another portfolio's answers.

`MFLENS_MCP_AUTH_CACHE` is exported above because the auth helper takes the token path
from the environment and nothing reads `tools.yaml` on its behalf; unset, it falls back
to its own default and `auth.token_cache` has no effect. `auth.helper` is for the
reader: the scripts always run the copy bundled in `$S`.

With `--auth` the scripts call the bundled `$S/mflens_mcp_auth.py headers`, send the
`Authorization` header it prints, and fetch a fresh one when the server answers 401/403.
Tokens are cached in `MFLENS_MCP_AUTH_CACHE` and refreshed silently for 30 days. If it
reports that the user is not signed in, that is a hard block for this step: the user
runs `/pipelines:mflens-login <mu>` once per machine (it opens a browser). Do not try to
sign in on the user's behalf.

## Extracting one program

    python $S/extract_logic.py P7549500 --url $URL --portfolio $PORTFOLIO --pds $PDS --cache-dir $CACHE --auth --mu <mu> -o <mu>/extracted-logic/P7549500.md --index <mu>/extracted-logic/paragraph-index.json

Without `-o` the document goes to standard output.

**Pass `--mu` on every call** (`extract_logic.py`, `program_tree.py`,
`analyze_view_usage.py`): the field analysis stops at the `mu.yaml` `boundaries`. A
boundary's tree is not fetched or analysed - it is another MU's - and what is passed to
it counts as used.

**Pass `--index` whenever the program is going to be translated**, which in `mu-design`
is always. It adds this program to a JSON record of every paragraph - its line range,
whether it carries behaviour that has to be traceable, and the SQL, calls, functions and
outcomes in it. It states nothing the document does not; what it is for is that the
migration can then be *checked* rather than attested, by `check_rule_coverage.py` in the
design and by the architecture skill's gate over the code. `FORMAT.md` specifies it,
including how `kind` is decided and where it errs. Leaving `--index` off leaves both
checks with nothing to read.

## The whole MU

Extract **every** program the MU's entry points reach (`entry_points` in `mu.yaml`) up to
its `boundaries`, and get the list from the analyzer rather than by eye. Extract only the
programs the command classified as **internal**; a boundary, a neighbor or an absent
program is not this MU's to document. The list comes from:

    python $S/program_tree.py P7549509 --url $URL --portfolio $PORTFOLIO --pds $PDS --cache-dir $CACHE --auth --mu <mu> > <mu>/.tmp/tree-P7549509.txt

`--mu` stops the walk at the `mu.yaml` `boundaries`: a boundary and what only it reaches
are not listed (stderr `boundary: <caller> -> <target>`); a program reached on a path
without a boundary is listed, and internal, even if another MU has it too.

once per entry point, then `extract_logic.py` once per name in the union of the lists,
every call passing the same `--index` path so the whole MU lands in one index:

    for p in $(tr -d '\r' < <mu>/.tmp/tree-P7549510.txt); do \
        python $S/extract_logic.py $p <connection parameters> --mu <mu> \
        -o <mu>/extracted-logic/$p.md \
        --index <mu>/extracted-logic/paragraph-index.json; done

`tr -d '\r'` because the tree file is written with the platform's line endings: on
Windows a `while read p` loop keeps the carriage return, the program name goes to the
server as `P7549510%0D`, and every member fails with `Illegal char <\r>` - five
identical errors that look like a server fault and are not.

The index is the MU's, not a tree's: one file beside the documents, holding exactly the
internal programs. A neighbor or an absent program has no entry, which is what lets the
checks tell a member with no provenance document from one that was never this MU's.

`program_tree.py` walks the calls from an entry program to closure and prints one name per
line. It resolves CA Gen's loader the way the logic extractor does, and **that is the whole
reason it exists**: a generated program names most of its callees in a data item, not in
the `CALL`,

    01  IRR14921-ID  PIC X(8) VALUE 'IRR14921'.
    CALL 'TIRLGLOD' USING IRR14921-ID ...

so a scan for `CALL '<literal>'` sees the loader, calls the program a leaf, and reports a
tree one layer deep. The failure is silent - the documents are right about what they
cover and say nothing about the layer below. On `P7549509` that mistake yields 15 members
instead of 60, and the 45 it drops are the ones holding the SQL. Both trees measured here
come out equal to the unit's link set, which is the check worth doing: if the closure and
the bundle disagree, one of them is wrong.

It reports any target it could not resolve to a member on stderr rather than skipping it
quietly, so a tree with a hole in it says so. Those are the candidates for neighbor or
absent modules.

Do not compute a tree from `.CBL` files in a directory. A directory is whatever someone
copied there; the call graph is a property of the portfolio, and like every other input
in this skill it comes from MFLens. `<mu>/inputs/cobol/` is the runner's, not this skill's. The scripts read the source from
MFLens into the cache, not into your context: do not open the cache (`mu-design`, hard rule:
the COBOL stays out of the design's context).

## The per-field contract of a call tree

    python $S/analyze_view_usage.py --root P7549510 --out-dir <mu>/.tmp <same connection parameters> --mu <mu>

Writes `<root>-call-contract.md`: the call tree with the fields that cross each call, a
typed interface per program, and a verdict per field - `USED`, `ECHOED`, `UNUSED`,
`NEVER-WRITTEN`, `ALWAYS-EMPTY` - with the evidence for it. The logic extractor uses this for
its `Inputs` and `Outputs` tables, so the two always agree.

## What the logic extractor removes, and what it keeps

Removed outright: the declarations, every comment, the trailing model-definition block,
the statement-number breadcrumbs, the action-block identity fields, the pre-call error
reset, the escape reset, the generated validation paragraph, the `-EXIT` landing pads
and the group-view loops that have no effect.

Folded into markers: validation, initialisation, calls, runtime-library functions, date
arithmetic, failure, the status check, the response envelope, paragraph performs, early
returns, array copies and import-to-export pass-throughs.

`FORMAT.md` defines every marker, states what each one asserts, and - for each thing
removed - what you must not conclude from its absence. That last part matters: a reader
who assumes "not shown" means "does not happen" will get the program wrong.

## Checking the scripts before trusting them

    python $S/selftest.py

No server, no cache, no sign-in: hand-written source fragments and the marker each one
has to produce. Run it after changing a script, and when a document looks wrong in a way
that would be a fold rather than the COBOL. A broken fold does not fail loudly - it
leaves a generated mechanism in the output, or drops a marker `FORMAT.md` tells a reader
to rely on, and the document still reads as if it were right. It covers only the text
side; the lineage verdicts behind `Inputs` and `Outputs` need the server.

## Limits worth knowing

- The callee names on a `@call` line are **inferred** by pairing views positionally, not
  read from the call. Measured over 2209 call sites and 107,111 field pairs, the two
  names agree on their base in 99.48% of cases; the exceptions are per-group control
  fields. `FORMAT.md` records this.
- Repeating-group capacities come from the `OCCURS` clause; an unreadable one renders as
  `[?]` rather than being omitted.
- A program whose source is absent from the portfolio is reported as a target with no
  analysed source, and is assumed to touch nothing beyond what it is declared to touch.
- The extracted-logic document is not valid COBOL. Do not compile it or parity-test it.
