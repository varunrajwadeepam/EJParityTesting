---
name: mu-design
description: Design phase of the COBOL migration - turns a prepared MU workspace into the design artifacts an implementer needs.
argument-hint: "mu/<MU>"
disable-model-invocation: true
---

# Design one Migration Unit

The design keeps the **behaviour** of the original and nothing else about it. The
business rules survive, the outcomes survive, the data the database ends up holding
survives. The shape of the original does not have to.

The only way back to the original is a **rule inventory**: every behaviour, numbered,
with the member, paragraph and line range it came from, and the target home that now
carries it. Build that first. A design without it cannot be reviewed against the
original, and the original is the only specification there is.

This command produces the design. It does not write the implementation.

`<mu>` below is the argument: the MU work folder, normally `mu/<MU>`. Its layout
is described in `${CLAUDE_PLUGIN_ROOT}/templates/workspace/CLAUDE.md`. `<mu>` and the
`mu.yaml` `solution` folder are relative to the workspace root, the folder holding `mu/`;
the command runs from there.

## Inputs, and nothing else

- `<mu>/mu.yaml` - the manifest. Without it, stop. `boundaries`: other MUs' entry points;
  this MU stops there (*Boundaries* below).
- `<mu>/tools.yaml` - tool access. Read your section with
  `python ${CLAUDE_PLUGIN_ROOT}/scripts/tools_config.py <mu> <tool> [key]`, never the file itself.
- `<mu>/inputs/` - `target-state.md` (target stack, SME notes), neighbor MUs' `deps/<name>.usage.md`, and
  `db-schema/`: DDL as reference, possibly partial or not executable. `inputs/cobol/` is the
  runner's: provided, or extracted from MFLens by `run-cobol` and saved there for execution.
- The file names in the `mu.yaml` `solution` folder, to say what already exists there -
  never their content, except a boundary MU's public contract (*Boundaries*).
- **The extracted-logic documents** in `<mu>/extracted-logic/`, one per program, and
  `paragraph-index.json` beside them - the record of every paragraph and whether it
  carries behaviour that has to be traceable - plus the `cobol-logic-extractor` skill's
  `FORMAT.md` for the markers and the index, and the `tir-cobol` skill for what a
  `*> @function` runtime module does. `extracted-logic/` holds only what the skill's scripts
  write; put nothing else there.
- **The architecture skill** named in `mu.yaml` `target.architecture_skill`: its `SKILL.md`
  (the target, common to both phases) and its design files (`SKILL.md` names them: the
  stack-specific part of the rules, dictionary, design and tests templates) - and its archetype
  file for `mu.yaml` `target.archetype`, common part and "Design part", which says what kind of
  solution this MU is (`REST`, ...) and how to build that kind.
- **The TIR skill** named in `mu.yaml` `target.tir_skill`.
- **The templates** in `${CLAUDE_PLUGIN_ROOT}/skills/mu-design/templates/`, one per artifact.
- **The `run-cobol` skill**, for recording cases against the real COBOL.
- **The `mflens-mcp` skill**, for direct MFLens calls: discovery, module classification,
  table structure for fixtures. Never a source of business rules.

That is all. Do not read a previous design or translation of the same programs. Do not
write target code; the snippets a design needs are part of the design.

**Hard rule: the COBOL stays out of the design's context.** You, and every subagent that
writes or reviews an artifact, never open `inputs/cobol/`, `unit/*/sources/`, `driver.cbl` or
any `*.CBL`, nor call an MFLens tool that returns source (`get_program_source_code`,
`search_code`, `search_code_portfolio`, `get_program_paragraph_details`,
`get_program_export`). Rules, design and expectations come from `extracted-logic/` only; put
this in every such subagent's brief.
The one exception is **testing**: a question the extracted logic cannot settle - which inputs
reach a path, what a fixture needs, why a case fails or does not build - goes to a separate
subagent that may read the COBOL. Its brief: answer only that question, return the test facts
(inputs, fixture rows, the cause), never source text and never a rule. What it returns is used
for the case only; a behaviour it reports that the extracted logic does not show is a question
and an extracted-logic defect, not a rule.

The restriction is the point: the design has to be buildable from the extracted-logic
documents. When something is unclear, decide, record the decision as a question, and
continue.

## Boundaries

`mu.yaml` `boundaries` are other MUs' entry points. This MU is its entry points (included)
and what they reach up to a boundary (excluded); a program reached on a path without a
boundary is internal here, even if another MU has it too. A boundary and what only it
reaches are never extracted and never read.

What a boundary does, first source that has it:

1. its MU's `inputs/deps/<name>.usage.md`;
2. its MU's public contract in the `solution` folder - `api/`, `api/model/`, `exception/`
   of its module; never its implementation;
3. none: the `@call` line in this MU's extracted logic and the recordings only; the boundary
   becomes a stub in the solution (step 5) and a question.

The COBOL run is not cut: `run-cobol` builds the full tree.

## What to produce

All into `<mu>/design/` unless stated otherwise. Before writing an artifact, read its template and,
for rules, dictionary, design and tests, the architecture skill's template of the same
name, then that artifact's part of the archetype file: each layer's sections add to the
sections with the same heading, and its forms replace the generic placeholders.

| Artifact | Content | Template |
|---|---|---|
| `rules.md` | every business rule, numbered, with member, paragraph, line range and target home | `rules.md` |
| `dictionary.md` | every surviving COBOL attribute mapped to its domain name | `dictionary.md` |
| `design.md` | the target application: structure, entry points, outcome mapping, transactions, persistence, behaviours preserved exactly | `design.md` |
| `tests.md` + `unit/<entry>/cases.json`, `fixtures/` | cases recorded from the real COBOL, restated as target expectations | `tests.md`; recording: `run-cobol` |
| `stubs.md` | one row per called program that is not internal | `stubs.md` |
| `interface.md` | this MU's contract; stays here, the source of mu-implement's `<name>.usage.md` | `interface.md` |
| `design-open-questions.md` | decisions taken where the documents are silent | `open-questions.md` |
| `hld.md` | the human-readable summary of the design for the business; **not an input of any later phase** | `hld.md` |
| `report.md` | the run report | `report.md` |

Every value a case asserts about the legacy side comes out of a run. A case that could
not be run is a question - not a predicted value.

## Order of work

0. **Preflight.** Check, before any work, and stop only on a hard block - saying exactly
   what is missing:
   - `mu.yaml` exists, has every field `${CLAUDE_PLUGIN_ROOT}/templates/mu.schema.yaml`
     requires and no `<...>` value left (`/pipelines:mu-init` writes one), the skills it names exist, and the architecture skill has a file for its
     `archetype`; no boundary is also an entry point;
   - `tools.yaml` exists (template: `${CLAUDE_PLUGIN_ROOT}/templates/tools.yaml`) and no `<...>`
     value is left in a section a step needs;
   - MFLens answers for `portfolio_id` and finds the entry points and boundaries there, through the
     scripts and through the MCP tools (the plugin's `mflens` server, see `mflens-mcp`);
     not signed in is a hard block: the user runs `/pipelines:mflens-login <mu>`;
   - the parity-tester App, the cobol-runner and Db2 answer their health checks, and the
     App's `workspace` is `<mu>/unit` (see `run-cobol`). A tool that is down, or serves
     another folder, is started or restarted with its start script when `tools.yaml` gives
     one; otherwise ask the user to start it, saying exactly how, and stop.
   Anything else missing (an SME notes block, a neighbor's usage file, a boundary with no
   contract) is a question, not a block.
   Load the architecture and TIR skills and the archetype file. On a re-run, read the user's answers in
   `design-open-questions.md` first and redo only the steps they affect.
1. **Context.**
   - **Classify** every program the entry points reach (`program_tree.py --mu <mu>`, per the
     `cobol-logic-extractor` skill) before extracting anything:

     | Class | Recognised by | Treatment |
     |---|---|---|
     | boundary | in `mu.yaml` `boundaries` (wins over internal) | not walked past; used as *Boundaries* says; a `neighbor` row in `stubs.md` |
     | internal | in this MU's portfolio (`mu.yaml` `portfolio_id`) | logic extracted, rules written here |
     | neighbor | not internal, an entry point of an `inputs/deps/*.usage.md` | used through that file; a `neighbor` row in `stubs.md` |
     | absent | neither | an `absent` row in `stubs.md` and a question |

   - **Extract** the internal programs into `extracted-logic/` with the `cobol-logic-extractor` skill,
     unless they are already there. **Pass `--index <mu>/extracted-logic/paragraph-index.json`
     on every call**: the index is what step 2's coverage check and the whole implement
     phase's traceability read, and without it both fall back to being read by eye.
     Its paragraph count per program is also the first check that the extract worked.
   - **Runtime calls**: list the `*> @function TIR…` modules the extracted-logic documents use;
     what each does is in the `tir-cobol` skill, what it becomes is in the TIR skill. One the
     TIR skill does not cover is a question.
   - Read every extracted-logic document. The call graph does not decide the structure, but it
     tells you which program owns which rule.
2. **Rules first.** Work through each program's paragraphs and write down every decision,
   computation, ordering constraint and database effect as a numbered rule. This step
   cannot be skipped: it is the specification and the only traceability the target has.
   A neighbor is used only through its `usage.md`; an absent module only through its stub.
   A boundary's behaviour is never a rule here; what this MU does with its answer is.

   Every `business` paragraph of the index ends, by full name and range, in a rule's
   `From` cell or in the "Paragraphs that produced no rule" table. Work the list rather
   than your memory of it, and take member, paragraph and range from the index rather
   than retyping them:

       python ${CLAUDE_PLUGIN_ROOT}/scripts/check_rule_coverage.py \
           --index <mu>/extracted-logic/paragraph-index.json --rules <mu>/design/rules.md \
           --external <mu>/design/stubs.md --warn-only

   Run it as soon as there is a `rules.md` to run it against, not only at review: every
   paragraph comes back `UNCITED` to begin with, and working that list down **is** this
   step. `--coverage-out` writes the exempt table to fill in. `mechanism` paragraphs are
   already exempt - `FORMAT.md` says how that is decided and that it is biased towards
   `business`, so a paragraph it asks you to account for that really is plumbing gets a
   row in the table with that as its reason, never a reclassification.
3. **Cases**, against the real COBOL, while the rules are fresh, per entry point with
   the `run-cobol` skill: build the unit, create the tables the cases need, then record.
   Every `STUB` the build reports goes into `stubs.md` with a question asking the user for
   that program's COBOL; a `NO SHIM` goes into `report.md` as a parity-tester gap. The unit
   is the full tree, boundaries included. Where the default stub would make a run unlike
   production, the testing subagent writes `unit/stubs/<NAME>.CBL` with the most probable
   behaviour (from the boundary's contract or the recordings; default success), the unit is
   rebuilt, `stubs.md` says what it returns, and its cases list it under `Does not verify`. A rule
   you cannot produce a case for is a rule to be suspicious of. Db2 is shared: follow
   `run-cobol` "The database is shared".
4. **Dictionary**, over the attributes the rules actually mention.
5. **Design**, assigning every rule to exactly one target home, following the
   architecture skill and the archetype. Say which rules are unit-testable without the database.
   A boundary with no contract is a stub collaborator in the solution that answers as its
   run stub does (`unit/stubs/<NAME>.CBL`, else the default), so the target answers as the
   recordings do; replaced by the real call later.
6. **Tests**, restating each recorded case as the target's expected outcome.
7. **Interface and stubs.** Write `interface.md` from the design; complete `stubs.md`.
8. **Review.**
   - Do the mechanical checks in `review-checklist.md` yourself; fix every miss.
   - Then fresh reviewers in parallel, one focus each, all with
     `${CLAUDE_PLUGIN_ROOT}/skills/mu-design/templates/review-checklist.md`, none told how the artifacts were
     made:
     1. **re-derive** - rules from the extracted-logic documents without reading `rules.md`,
        then diff against it;
     2. **implementer** - per entry point, every point an implementer would have to guess;
     3. **architecture** - design against the architecture skill and archetype;
     4. **tests** - tests against recordings and `tests.md` "What to cover".
   - Each finding: severity (High/Medium/Low), evidence. Fix what has evidence; the rest
     becomes a question.
   - Check the fixes: regenerate generated artifacts, re-run `--check` if cases changed,
     redo the mechanical checks, and send each High back to its reviewer once.
   - Log every finding's outcome in `report.md`.
9. **HLD.** After every other artifact is final (review fixes included), start a **forked
   subagent** (`Agent` with `subagent_type: "fork"`) to write `hld.md`, so that it works from
   the same knowledge as this run. Brief: write `<mu>/design/hld.md` from
   `${CLAUDE_PLUGIN_ROOT}/skills/mu-design/templates/hld.md`, following its audience, facts-only and length
   rules; read nothing but the final design artifacts (never the COBOL, see the hard rule);
   change no other file; return the questions for the business it wrote. `hld.md` is for
   people only: no later phase reads it, nothing in `rules.md`, `design.md` or the other
   artifacts refers to it, and a gap it shows is fixed in the source artifact, then `hld.md`
   rewritten. Check that it is at most 200 lines and that every store in "Data consumed and
   produced" appears in `design.md` or `rules.md`.
10. **Report.** Write `report.md` from its template, with a row for the HLD step, and print a short summary:
   counts of rules, cases, stubs and questions, tool gaps, and anything that blocked a step.

Record questions in `design-open-questions.md` as you go, in every step.

## Open questions

An entry only where the documents are silent **and** the wrong reading changes
behaviour. If `FORMAT.md` or the `tir-cobol` skill answers it, it is not a question; if
nothing observable depends on it, it is at most a note. State what you assumed and why,
so the user can confirm or correct it and re-run.

## Working

- Do the work yourself. Use subagents when work is isolated or can run in parallel - for
  example rules for unrelated programs, or the review. Give each the files to read, its
  template, the architecture skill's template of the same name, `SKILL.md` and the archetype file's common and "Design part", its output file, and the rules of "Inputs, and nothing
  else" and "What not to do" - a subagent does not see this command. Subagents return questions to you; only you record them.
- Do not stop to ask. Everything short of a hard block becomes a question.
- Prefer a script to judgment for anything deterministic. You may write your own scripts
  into `<mu>/.tmp/`.
- Write only inside `<mu>` (and nowhere else); temp files go to `<mu>/.tmp/`.

## What not to do

- **Do not change behaviour while restructuring.** If the original regenerates a key on
  update, mints an identifier from a clock reading digit by digit, or writes child rows
  before parent aggregates, the design does the same and says so. Improving a rule is a
  product decision and belongs in the questions as a proposal, not in the design as a fact.
- **Do not invent a rule the documents do not show**, and do not fill a silence with
  something reasonable. That is an open question.
- **Do not emulate the COBOL** in the target. What that means for this target is in the
  architecture skill and the archetype file.
