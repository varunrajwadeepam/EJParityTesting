# dictionary.md - the domain names

A lookup table. Someone holding a COBOL name finds the domain name; someone holding a
domain name finds where it came from. Everything that is not that belongs elsewhere.

**Form.** Tables, sorted by COBOL name, except `Use cases` which follows the order of
`rules.md`. One line per rule under `Rules`. No prose, no call graph, no counts.

**Only what survives.** Unlike a line-for-line target, this one keeps a fraction of the
names: an attribute that reaches the database, a request, a response or a decision in
`rules.md` gets a row, and everything else - views, aliases, echoes, carriers, flags,
cursors, indicators, exit states - does not. A name you cannot point at a rule or a
column for does not belong in the dictionary at all.

**Keyed by attribute.** The four-digit suffix is the view a field was emitted for, so
`DIR-CONTR-NBR-0037`, `-0019` and `-0018` are one attribute, one row, keyed
`DIR-CONTR-NBR-*`, with every spelling in the `COBOL` cell.

## Sections, in this order

### `## Rules`

One line each, no justification:

- Names: from the business meaning, not from the COBOL spelling.
- Abbreviations: expanded per the glossary.
- Occurrence numbers and suffix families: dropped.
- Prefixes that encode a system or a model (`RV-`, `DIR-`, `PSMGR-`): dropped unless the
  business uses the word.
- Collisions: one line each, naming both sides and the resolution.

### `## Glossary`

| Abbreviation | Expands to |
|---|---|
| `BE` | business event |
| `CD` | code |

Every abbreviation that appears in a COBOL name you kept. One expansion per
abbreviation; where the COBOL spells one thing two ways, both rows give the same answer.

### `## Attributes`

| COBOL | Domain name | Target type | Column | Rules | Note |
|---|---|---|---|---|---|
| `DIR-CONTR-NBR-*` | `contractNumber` | `<target type>` (8 wide) | `CONTR_NBR` | 7, 12 | |
| `GROUP-IMPORT-DIR-DETAIL-*MA` | *(dropped)* | - | - | - | list size replaces the count |

`Column` is where it lands, or `-` for a value that never reaches the database. `Rules`
is the rule numbers that mention it, which is what makes the row justified. A dropped
mechanism field gets a row **only** when a reader would otherwise look for it - the
entry-count fields, the null indicators - and then the `Note` says what replaced it.

Where the width matters - a padded comparison, a fixed-length key - say so in the type
cell. That is a `rules.md` rule too, and this is the cross-reference.

### `## Use cases`

| Use case | Entry point | Target home | From |
|---|---|---|---|
| delete a WIP business event | `<entry point>` | `<target home>` | `P7549510` dispatch arm 1, `A7549212` |

One row per entry point, in `rules.md` order. `From` names the COBOL programs whose rules
it absorbed - which is how a reader finds out that six programs became three entry points.

### `## Dropped programs`

| COBOL | What it was | Where it went |
|---|---|---|
| `E7549T05` | cascade delete of the association rows | `<target home>`, the schema's own cascade |
| `A7549019` | the WIP number algorithm | `<identifier generator>`, rules 20-26 |

Every program in the MU appears either here or in `Use cases`. A neighbor or stubbed
program goes here, and `Where it went` names the neighbor operation or the stub. A program in neither is
behaviour nobody accounted for, and this table is the check that finds it.

### `## Constants`

| COBOL | Value | Becomes |
|---|---|---|
| `EV-USABLE` | `'OK'` | *(dropped - the state it guarded is now an exception)* |
| `FATAL-ERROR` | `'FE'` | `<processing-failed outcome>` |

Named literals the rules depend on, with what each becomes. A constant the documents
name but never define is a question, and its row says `undefined`.
