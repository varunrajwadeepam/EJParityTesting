# hld.md - <mu>

The one document a business stakeholder reads about this MU: what the unit of work does
today, and what it becomes. It is the alignment artifact - the reader confirms that the
behaviour described is the behaviour the business wants to keep, and answers the
questions at the end.

**Audience.** People who know the mainframe and the COBOL by name, and own the business
process. So: name the programs, the tables and the queues, and explain what they are
*for*. No paragraph names, no line ranges, no field-level COBOL layouts, no Java class
structure beyond the interface the caller sees, no rule numbers.

**Facts only.** Every statement here is already in `rules.md`, `design.md`,
`dictionary.md` or `stubs.md`. This document says nothing that those do not, and it is
not where anything is decided. It is **not a work log**: no record of what was extracted,
reviewed, recorded or considered, no mention of these documents, these commands, MFLens,
the runner or the review.

At most 200 lines, so that it is read. Prose in short paragraphs and tables; a sentence
a stakeholder has to re-read is a sentence to cut.

## 1. Current state

### What this unit of work does

Three to six sentences. The business purpose, in the business's words: what event or
request it serves, who or what triggers it, what the business has after it runs that it
did not have before. Then, in one sentence, the mainframe side: which programs make it
up and which is the entry point a caller reaches.

### Inputs and outputs

What the caller supplies and what it gets back, by domain name - the `dictionary.md`
name, not the COBOL field - with the business meaning, not the picture clause. One table
per entry point where there is more than one.

| Direction | Name | Meaning | Required |
|---|---|---|---|

If the unit of work reports a business outcome rather than succeeding or failing - not
found, already exists, not permitted - list those outcomes here in business terms, with
what the caller is expected to do about each.

### Data consumed and produced

Every store the unit of work touches. One row per store; nothing left out, and no store
listed that the rules do not show.

| Store | Kind | Read / Written | What it holds, and what this unit of work does with it |
|---|---|---|---|

`Kind` is `Db2 table`, `VSAM file`, `sequential file`, `MQ queue`, `other system`.
For an `MQ queue` say which message and what the receiver does with it; for `other
system` name the service or the neighbouring application and what is asked of it.

Where a store is read only to validate something, say so - a stakeholder reads "written"
as "the business data changes".

### How it runs today

One diagram, from the business user's point of view: the trigger, the decisions the
business would recognise, the data stores, the outcomes. Not the call graph, not the
paragraph flow - a reader who knows the process must recognise their own process in it.

```mermaid
flowchart TD
  A[<trigger: what the user or system does>] --> B{<business decision>}
  B -->|<outcome in business words>| C[<what happens to the data>]
  B -->|<other outcome>| D[<what the caller is told>]
  C --> E[(<table or queue>)]
```

Keep it to one screen. A unit of work with several entry points gets one diagram per
entry point, or one diagram with the entry points as separate starting nodes - whichever
is shorter.

## 2. Target state

### What changes and what does not

Say plainly, in one short paragraph: the business behaviour is kept as it is today,
including the outcomes and the data the stores end up holding; what changes is how the
unit of work is reached and the technology it runs on. Name the target stack in one
sentence, from `target-state.md`.

Then, where anything observable to the business *does* change - a response that arrives
differently, a limit, a message no longer shown, a step a neighbouring system must now
take - list it. One line each. This list is short or empty; if it is not, each line
traces to a decision in `design.md`.

### The interface the caller sees

The contract, in the form the architecture skill and the archetype give - an HTTP method
and path per operation for a REST target, a Java interface for a library. One operation
per thing a caller can ask for, named for the business action. Field names are the
dictionary's.

Show it as the caller would be handed it:

| Business action | Operation | Caller supplies | Caller receives |
|---|---|---|---|

Then one code block per operation shape - the request and response bodies, or the
interface declaration - with no implementation.

### Outcomes

Every business outcome the caller can tell apart, and how the target reports it. The
mapping is `design.md`'s; this is the same mapping with the business meaning in front.

| Business outcome | Target reports | What the caller does |
|---|---|---|

### What this unit of work depends on

The neighbouring applications, services and shared programs it needs, one line each,
with what it asks of them - and, where one is not yet available, what is assumed in the
meantime. A stakeholder reading this must be able to see whose cooperation the migration
needs.

## 3. Questions for the business

Omit this paragraph if there are no questions.
Only questions a business owner can answer: a behaviour whose intent is unclear, a rule
that looks like it encodes a policy that may have changed, a limit nobody can explain, a
consumer of an output nobody can name. Technical gaps belong in
`design-open-questions.md` and are not repeated here.

| # | Question | Why it matters | What is assumed until answered |
|---|---|---|---|

Each question is answerable without reading any other document here. Where an assumption
is already recorded, state it as the assumption, not as a fact.
