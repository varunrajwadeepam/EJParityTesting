# design.md - the target application

Instructions for the implementation stage, in the imperative. Do not justify, do not
compare alternatives, do not report what you considered - the reasons are in this
template and in the architecture skill, and repeating them in the artifact turns an
instruction into a suggestion.

**This document stands alone.** Do not cite `design-open-questions.md` by number for a
decision an implementer needs - state the decision here, in full. That file is for a
reader deciding whether to *change* a decision, and it does not always travel with the
design: an implementer who meets "see OQ-3" and has no OQ-3 has a hole where an
instruction should be.

Every section below has a counterpart in the architecture skill, which says what it
holds for this target. Write each section the way the skill says.

## What the target is

Say it at the top: what the target is, in the architecture skill's words, and that **the
structure of the COBOL is deliberately not preserved.** What is preserved is the
behaviour in `rules.md`, every rule of it.

So the implementation stage is free to - and should - name things for the domain, group
code by responsibility, use the target's ordinary types, and delete every mechanism the
original needed and the target does not. It is not free to change what the application
does.

## Starting point

Two lists, no prose. Exactly what the implementation stage will find, and exactly what it
has to write:

```
Exists            <what the solution folder already holds>
To be written     everything else in this document
```

Name here every value an implementer cannot derive from anything else - the
architecture skill lists them. If a file is not in the `Exists` list, it does not exist -
say so. If the solution folder already holds other MUs' code, `Exists` names what this
MU reuses.

## Structure, and what may not cross

The target's layers or components, as the architecture skill defines them, each with
what it holds and what it may not hold. The prohibitions are the design: state each one,
with the failure it prevents.

## Use cases are not programs

The COBOL's programs are not the target's units, and its paragraphs are not its
functions. The unit of design is the **use case**: one home per thing a caller can ask
for, named for what it does. A program that exists only to be called by one other
program - a delete helper, a cascade, an identifier generator - is a private part of a
use case, or a small collaborator of its own if `rules.md` gives it rules worth
isolating.

Equally, one COBOL program may split: a 600-line paragraph that both derives an
identifier and formats it is two homes if the rules divide that way.

**Every rule in `rules.md` has exactly one home**, and the inventory records which. The
code records the other half of that link: where in the original the behaviour came from.

## Comments

Four rules, and they are about what ships.

1. **A comment cites the COBOL, and nothing else.** The member, the paragraph, the line
   range the extracted-logic document gives, in the target's documentation-comment form. That
   is the only route from the code back to the original: the names are chosen for the
   domain, so nothing in the target resembles anything in the COBOL any more.
2. **A comment never names one of these documents.** No "rule 14", no "see rules.md",
   no "per design.md". Those files are the working material of a migration and do not
   ship with the application. State the behaviour instead, in a clause.
3. **A comment belongs on a declaration, not in the body.** An inline comment only where
   the business logic is genuinely surprising - an ordering that looks wrong, a key
   regenerated where a reader expects it preserved - and then one or two lines saying
   what the original does.
4. **Short.** One sentence on what it does, one line of provenance.

## The command dispatch becomes entry points

A procedure step that dispatches on a command field - `DELETE`, `ADDWIP`, `UPDATE` - is
not one entry point with a `command` parameter. It is one entry point per arm, in the
form the architecture skill gives, and the unrecognised-command arm disappears entirely.

State the full list in this document, with the home each one calls.

## Legacy outcomes become target outcomes

The original reports its outcome in a response code, an exit state, a message and a
message level, all travelling in a successful reply. **None of those exist in the
target.** The design carries the complete mapping - every response code and every exit
state in every extracted-logic document's `Response states` table, with no "and so on":

| Legacy outcome | Target outcome | Error code | When |
|---|---|---|---|

Rules for the mapping, all of them load-bearing:

- **Preserve the distinctions and invent none.** Two legacy outcomes that a caller could
  tell apart must map to outcomes a caller can still tell apart. Two that the original
  makes identical must stay identical here - inventing a distinction is a new contract.
- **A message becomes part of the error, not the outcome.** The exit message and its
  level say what to tell a person; they do not decide the outcome.
- **The rollback advisory is not an instruction.** Where the original sets a
  rollback-requested flag and returns normally, the target's transaction boundary already
  decides the rollback. Map the outcome; do not expose the flag.
- **An unmapped outcome is an error, and the design says so** rather than leaving a gap.

## Neighbors, stubs and the runtime

- **A neighbor MU** is called through the operation its `usage.md` names, behind an
  abstraction the business logic owns; the business logic never sees how the neighbor is
  reached.
- **Every row in `stubs.md`** is an explicit collaborator with a stub implementation that
  gives the behaviour the row states. List them here; they are not hidden fakes.
- **A TIR runtime call** becomes what the TIR skill says. One the TIR skill does not
  cover is a question, never an invented replacement.

## Transactions

One unit of work per use case, at the use-case boundary and nowhere else, the whole of
the work inside it, a failure out of it rolling the whole thing back.

If the original's unit of work is larger than one call - a procedure step driven in a
loop by something outside the tree - say so here and say what the target does instead.

## Persistence

The mechanism is the architecture skill's. Whatever it is:

**A cursor is not a list, and fetching everything is not a substitute for one.** The
original reads a cursor row by row and usually stops - when a group fills, when a count
is reached, when the row it wanted arrived. Decide per read, from what the rule says the
limit is about:

- **The limit is on rows** - "the first 100 rows", "one row" - so put it in the
  statement: `FETCH FIRST n ROWS ONLY`. The database stops; nothing crosses the wire to
  be thrown away.
- **The limit is on entries after a reduction** - "a hundred codes, keeping the latest
  revision of each" - so the count is not known until rows have been examined. Read the
  rows as a stream and stop when the entries fill, which is what the original does.
- **There is no limit** and the whole result is genuinely wanted - then a list is right,
  and say so, so the next reader knows it was a decision.

**`OPTIMIZE FOR n ROWS` is a hint, not a limit.** Keep the clause only where the code
really does stop at `n`.

And always:

- **The schema is not the target's to own.** No DDL, no migration tool. The tables are
  delivered; the application reads and writes them.
- **Fixed width.** Say how the target treats `CHAR(n)` values, as the architecture skill
  states. A `rules.md` rule phrased as a fixed-width comparison - `IF X = SPACES` on a
  14-byte field - is a rule about **absence**, and is implemented as one. Say which rules
  it affects.
- **A string input may be absent or empty**, and both mean not supplied. Say which
  fields are optional, and that the two forms are equivalent.
- **Null means absent.** A column the original tests for null becomes a value something
  actually checks, never a silent default.

## What may be deleted

Freely, and without a note: the views and their copies, the `XX` aliases, the echoes,
the carriers that only carry, the control block, the status flags, the exit-state
constants as data, the escape flags, the cursors, the null indicators as fields, the
statement-number breadcrumbs, the action-block identity moves, the paragraph structure,
the per-program contracts, the per-program classes, and the dispatch table.

Everything in `rules.md` stays. That is the whole boundary.

## Testing

**Both kinds, and they test different things.**

**Unit tests are required.** Every rule with logic in it - a computation, a derivation,
a condition with more than one arm, a mapping - gets a unit test over the home that owns
it, with persistence mocked. A rule that can only be exercised through the full call and
four tables is a rule whose home is wrong. Name in this document which rules are
unit-testable; that list and the test class list should match.

**Integration tests** on the delivered schema, seeded per case, assert what `tests.md`
says. The legacy recordings are the source of truth for *what happened*; this document's
mapping decides *how it is reported*.

**A test leaves the database as it found it.** Each case seeds what it needs and removes
what it wrote, in an order the foreign keys permit. The suite has to pass twice in a row
against the same database.

**The test database is shared; the MU's tests are kept apart from other MUs'.** Name how,
as `java-solution` *Integration tests* says.

**Name what a fallback test database would do differently:** each Db2-only clause the
MU's statements keep, as `java-solution` *Integration tests* says.
