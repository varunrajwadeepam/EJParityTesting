# tests.md - the recorded behaviour, restated for the target

Every case here is a recording from the real COBOL, restated as what the new design must
produce. Two halves per case, and the distinction is the whole point of the file:

- **what happened** - recorded from a run of the original, verbatim. Evidence.
- **what the target answers** - the outcome, the error code and the row effects that the
  mapping in `design.md` turns that into, in the form the architecture skill gives. A decision, taken in this file's left-hand
  column and nowhere else.

A case with no recording does not belong here. Not with a predicted value, not marked
unrecorded. Use the `run-cobol` skill: it builds the tree, seeds the fixtures, runs the
case and prints what the program did. `unit/<entry>/cases.json` re-runs them all.

**If a case cannot be run, that is a finding** - which case, what you tried, what
stopped you - recorded as a question. Do not report an obstacle you have not hit.

## Paths

Every path in this file is relative to the MU folder: `unit/P7549508/fixtures/seed.sql`,
never absolute.

## What to cover

One case per rule that can be reached, and at minimum:

- every entry point's success path;
- every error outcome the mapping table produces, each one reached by the condition that
  produces it in the original;
- the orderings and the ordering-dependent failures, where a case can show them;
- the empty cases: no detail lines, a group with zero entries;
- any rule whose arithmetic produces a value a caller can see - a derived identifier
  above all, because it is the one thing a restructuring silently changes.

Close the file with **Not covered**: the rules no case reaches, and why. Cross-check it
against `rules.md`'s own coverage list; two lists that disagree mean one is stale.

## Format

Cases are grouped by entry point, one `# <entry>` heading each. A case that reaches a
neighbor or a stub says which stand-in the run used, under `Does not verify`.

```markdown
## <case-name>

<One or two sentences: which rule or rules this exercises, and why it matters.>

Fixture: <unit/<entry>/fixtures/<name>.sql, or "none">

Request: <the call to the target, in the form the architecture skill gives>

Recorded from the COBOL:
  RESPONSE-CODE-S-0044: "1"
  PSMGR-EXIT-STATE: "1837673936"
  PSMGR-ROLLBACK-RQSTED: "R"

Expected outcome: <the target's answer, in the form the architecture skill gives>

Expected rows: none written - no REVOL_WIP_DIR_BE row under the generated number.

Rules: 7, 12
Not asserted: <what the run returned that this case ignores, and why>
Does not verify: <what a reader might assume this case proves, and it does not>
```

`Recorded from the COBOL` is copied from the run, trailing blanks included, and is
**not** what the target returns - it is the evidence that the target's answer is the
right one. Keep it: without it the expected outcome is just an assertion somebody made.

`Expected rows` is where this target's cases do their real work. The legacy driver
reports an export view; what matters now is what the database holds, and that is a query
the case states. Where the recording itself could not show it - a driver that rolls back
- say so under `Does not verify` rather than claiming it.

`Rules` ties the case to the inventory. A rule with no case is in `Not covered`; a case
with no rule is testing something nobody wrote down.

## Cleanliness

A case seeds what it needs and **removes what it wrote**. The runner's driver may commit,
in which case a recorded run leaves rows behind, and so does the target's own suite: a
fixture that only inserts makes the second run of the suite fail for a reason that has
nothing to do with the code. Delete in an order the foreign keys permit - children before
parents where the delete rule is `RESTRICT` - and state in each case what it removes.

The test of this is mechanical: the suite passes twice in a row against the same
database, and the row counts afterwards match the row counts before.

The database is shared with other MUs' tests: a fixture's delete names its exact keys
(`java-solution` *Integration tests*).

## Order the database decides

Rows the database orders itself (`java-solution` *Integration tests*) get a `Does not verify`
line: "the order of rows with equal <key>".

## Unit tests, alongside these

This file is the integration suite: a call in, rows out. It is not the whole test
obligation. Every rule with logic in it also gets a unit test with persistence mocked -
see `design.md`, Testing - and a derived identifier gets one per component. A rule that
can only be reached through the full call and four tables is a rule whose home is wrong,
and the unit test is what reveals that while it is still cheap to move.

## Which values to keep

From the legacy side: the fields that carry the outcome. `run-cobol --changed` lists the
fields whose value differs between the cases you ran, and that list is where the choice
starts. Drop the rest and say so.

From the target side: the outcome, the error code, the fields of the answer a caller
acts on, and the row effects. Not the message text - pin that in one case and reference
it, or a wording change breaks twelve tests for no behavioural reason.

**Pin what varies.** A derived identifier built from a clock is deterministic once the
clock is fixed: fix it on both sides - the recordings used a pinned clock, and the target
has to let a test do the same. A value you tolerate instead of pinning is a value you
have stopped testing.
