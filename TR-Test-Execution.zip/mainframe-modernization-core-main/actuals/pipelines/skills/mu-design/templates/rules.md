# rules.md - the behaviour inventory

The specification for the target, and the only way back to the original once the
structure is gone. One numbered rule per behaviour, each carrying where it came from and
where it is going.

**Form.** A table per use case, plus one line of prose per rule where the rule needs a
condition spelled out. No narrative, no analysis of the COBOL, no commentary on whether
a rule is sensible - a doubt about a rule is a question.

## What counts as a rule

Anything that would change an observable outcome if it were missing:

- **a decision** - a condition and what each arm does;
- **a computation** - an amount, a count, a derived identifier, a date;
- **an ordering constraint** - two effects where doing them in the other order is visible;
- **a database effect** - a row written, deleted or read, and under which key;
- **an outcome** - what the caller is told;
- **a width or format that reaches the database or a comparison** - a fixed-width field
  padded to its length, a date as `'YYYY-MM-DD'`, a number of decimal places.

What is **not** a rule: a view copy, an echo, a status flag, an exit state as a value, a
cursor, a null indicator as a field, a work variable, a paragraph boundary, a call. Those
are mechanism. The decision a null indicator *drives* is a rule; the indicator is not.

A call into a neighbor MU or an absent module is a rule only for what this MU does with
the result. What the callee does is in its `usage.md` or in `stubs.md`, not here.

## Format

```markdown
## <use case> - <the entry point it becomes>

| # | Rule | From | Target home |
|---|---|---|---|
| 14 | A duplicate written-premium control row abandons the rest of the creation: the surcharge and other-income rows are not attempted. | `A7549229` PARA-1956030950 (2010-2043) | `<target home>` |
| 15 | The detail rows are written **before** the three control rows. | `A7549229` PARA-1955993943 (1960-2180) | `<target home>` |
```

`From` is the member, the paragraph, and the line range - **taken from
`extracted-logic/paragraph-index.json`, not from memory**. The range is the one part of a
citation nobody can recall and the part that goes stale silently; it is checked, so a
mistyped one is a finding here rather than a wrong pointer in the delivered code later.
The implementer copies this cell into the comment on the code, so a wrong range is
copied forward.

Two paragraphs for one rule is fine; no paragraph is not - a rule with no provenance is
something you decided, and that belongs in the questions.

`Target home` is the one place in the target that carries the rule; the architecture skill
says what that place is. A rule that needs two homes is two rules, or the boundary is
wrong.

**The link is one-directional on purpose.** This file names the target home; the code
does **not** name the rule. A comment citing "rule 14" is a reference to a file that
does not ship with the application - see `design.md`, Comments. What the code carries is
the COBOL provenance, which is the same `From` cell, and that is what lets a reviewer
line the two up.

## Rules that are easy to lose

Give each of these a numbered rule of its own wherever the tree has one, because every
one of them has been dropped by a restructuring at least once:

- **A derived identifier's algorithm.** If a key is assembled from a clock reading, or
  from components in an unusual order, or with digits reversed, the algorithm *is* the
  rule - the keys already in the database were made that way. **One rule per component**,
  each stating its width, its fill and whether its digits are reversed, and then one rule
  carrying a worked example taken from a recording:

  ```
  clock 20240816103000 -> "00000003019220"
    0000  microseconds, 4 wide, zero-filled, not reversed
    00    second 0,  2 wide, zero-filled, reversed
    03    minute 30, 2 wide, zero-filled, reversed
    01    hour 10,   2 wide, zero-filled, reversed
    922   day 229,   3 wide, reversed
    0     constant
  ```

  A general statement that "the two-character components are reversed" leaves the
  four-character one undecided, and no case will settle it if the component is zero in
  every recording. The worked example is what closes that.
- **An update that is not an update.** Delete-then-insert under a new key is a rule, and
  a reviewer will "fix" it unless the rule says so explicitly.
- **Which outcomes are distinguishable.** If two different failures produce the same
  legacy response code, the new design must not invent a distinction between them, and
  if one legacy code covers two situations, say which.
- **An ordering a foreign key or a cascade depends on.**
- **A limit, and what it counts.** The original reads a cursor and stops somewhere, and
  the rule has to say *where*: at the hundredth **row** the query returned, or at the
  hundredth **entry** after a reduction that may consume many rows per entry. The two
  produce the same answer and a different query - the first is `FETCH FIRST n ROWS ONLY`,
  the second cannot be expressed in SQL alone and has to stop while reading. A rule that
  says only "at most 100" leaves the implementer to materialise everything and cut the
  list afterwards, which is the reading that quietly scales with the table instead of
  with the answer. Say which, and say what happens to the surplus: dropped silently,
  reported, or an error.
- **A null decision.** Where the original reads a null indicator and branches, that is a
  rule about an absent value, and a value that is silently defaulted loses it.
- **A comparison against spaces.** `IF X = SPACES` on a 14-byte field means "the caller
  supplied nothing". Write the rule as the test for absence it is, not as a width: the
  rule reads "when no contract number is supplied". How the target represents "not
  supplied" is the architecture skill's business.
- **The processing date.** If the original reads the clock once and stamps one value
  everywhere, that is a rule - a target that reads the clock per row writes two dates
  on a run that crosses midnight.

## Rules that make other rules unreachable

Where one rule means another can never fire - a rule that the caller's value is always
blanked before a rule that tests it - say so **on both**, naming the other's number.
Otherwise the implementer writes the unreachable one, discovers nothing calls it, and
cannot tell a dead rule from a missed call site.

## Coverage

Close the file with three lists:

- **Rules no recorded case exercises.** Behaviour the implementation will be trusted on.
  Name them; do not leave the reader to work it out.
- **Rules no test could ever exercise.** Different, and worth separating: an ordering
  between two writes that no query can observe, an arm reachable only under a concurrent
  change. These look covered and are not, and a reader needs to know which is which.
- **Paragraphs that produced no rule**, as a table, in the form below. Every `business`
  paragraph of the index that no rule cites, with one clause saying why it produced
  none - the validation block, the view copies, a cursor family one query covers. A
  paragraph in neither this table nor a `From` cell is an oversight.

### Paragraphs that produced no rule

**Generated, then filled in.** `check_rule_coverage.py --coverage-out` writes a row for
every business paragraph no rule cites, carrying over whatever reasons are already
there; paste it back and write the missing reasons. Do not compile the list by reading
the documents - that is the reading the index exists to replace - and do not widen what
counts as mechanism to shorten it.

```markdown
| Member | Paragraph | Lines | Why no rule |
|---|---|---|---|
| `A7549229` | `MAIN-1955993749` | 1650-1673 | generated shell: validation and the return |
| `A7549212` | `PARA-1956025480-MOVEA` | 765-768 | cursor family, one repository method covers it |
```

A row with an empty reason is a finding, not an omission: exempting a paragraph is a
judgement, and the whole point of the table is that someone can see it. These rows are
also what `mu-implement` exempts from the gate over the code, so a reason written here
is not written twice.
