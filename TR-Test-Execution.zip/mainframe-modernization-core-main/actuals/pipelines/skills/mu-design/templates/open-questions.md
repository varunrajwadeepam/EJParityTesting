# design-open-questions.md

An entry only where the documents are silent and the wrong reading changes behaviour.

## Settled

- <decision, one line>

## OQ-<n> - <title>

Step: <step> · Status: open | answered | settled
Question: <what the documents do not say>
Decision taken: <what the design assumes>, because <why>
Affects: rules <n>, cases <name>
Answer: <filled by the user; the next run applies it>
