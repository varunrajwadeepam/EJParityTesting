# stubs.md

One row per called program that is not internal: what the design calls it through, and
what the runs used in its place.

| Program | Kind | Caller (paragraph, lines) | In | Out | Stub behaviour | Question | Cases |
|---|---|---|---|---|---|---|---|

Kind: `neighbor` (designed through its `usage.md`; a `mu.yaml` boundary is one) or
`absent`. For a boundary, `In` / `Out` also say where its contract came from: `deps`,
`solution` or `none` (a stub in the solution). Stub behaviour: what the runs used when its
COBOL was not in `inputs/cobol/` - `unit/stubs/<NAME>.CBL` and what it returns, by default
success, empty outputs - or `real COBOL`. TIR runtime modules are not listed.
