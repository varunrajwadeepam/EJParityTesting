# Review checklist

Read-only. Sources: extracted-logic documents, the `cobol-logic-extractor` skill's `FORMAT.md`
and the `tir-cobol` skill, `unit/*/.run-cobol/`, the skills. Never the COBOL. Each finding:
severity, artifact + rule/line, evidence, fix.

## Mechanical (the command, before the reviewers)

Every check in this section is a set comparison over text the artifacts already carry:
run a script, rather than reading the files against each other. A miss a script reports
is exact; a miss read by eye is a sample. The first two are one shipped script; write
your own into `<mu>/.tmp/` for the rest.

- Traceability, both checks at once - every `From` paragraph and range against the
  index, and every `business` paragraph in a `From` or in "Paragraphs that produced no
  rule" with a reason. No finding, and no `--warn-only`:

      python ${CLAUDE_PLUGIN_ROOT}/scripts/check_rule_coverage.py \
          --index <mu>/extracted-logic/paragraph-index.json --rules <mu>/design/rules.md \
          --external <mu>/design/stubs.md

  `UNCITED` is a behaviour the design is silent about; `STALE_RANGE` and `MISSING_RANGE`
  are a pointer the implementer will copy into the code; `NO_REASON` is an exemption
  nobody signed. A `WRONG_PROGRAM` or `UNKNOWN_PARAGRAPH` means a rule cites a paragraph
  that is not where it says, which also makes the rule's own derivation worth re-reading.
- Every rule number cited in design, tests, dictionary exists in `rules.md`.
- Cases in `tests.md` = cases in `cases.json`; recorded values = `.run-cobol` outputs.
- Every rule is in a case's `Rules` or in "Not covered"; the coverage lists of `rules.md`
  and `tests.md` agree.

## Rules
- Behaviour in a paragraph with no rule; a rule the paragraph does not show.
- Derived identifier: every component, worked example, uniqueness and collisions.
- Each date's source; sentinels (zero, max).
- What the original does not check; check order; stop vs continue per failure arm.
- Zero-row update/delete; limits and what they count.

## Sources
- A decision against a recording or the `tir-cobol` skill because a skill table says so.
- A question the extracted-logic documents, `FORMAT.md` or the `tir-cobol` skill already answer.
- An assumed value (package, port, zone, ...) not raised as a question.

## Design
- Every deviation from the recorded or documented behaviour is stated, with its rule.
- One outcome for two causes: no invented distinction.
- Every rule has one home; outcome decisions are not in persistence.
- Every error reaches the caller in the archetype's one error form, including unmapped ones.

## Tests
- `tests.md` "What to cover"; each case's `Rules` really exercised by it.
- "Expected rows" claims no wider than its verify queries.
- Cases the driver's commit makes inconclusive say so.

## Implementer
- Every point where building an entry point needs a guess: names, types, SQL, config.
