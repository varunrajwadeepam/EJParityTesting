# interface.md - <mu>

This MU's contract - the operations, the domain names and the error codes. Stays in this
MU; clients get mu-implement's `<name>.usage.md`.

## Programs covered

## Operations

| Operation | Inputs | Outputs | Error codes |
|---|---|---|---|

## Domain names

## Shared programs

## Stubs
