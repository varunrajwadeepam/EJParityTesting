# report.md - <mu>

| Step | Status | Note |
|---|---|---|

Steps 0 to 9 of the command, one row each (9 is `hld.md`).

Rules <n> · cases <n> · stubs <n> · open questions <n>

Paragraph coverage, from `check_rule_coverage.py` rather than by eye: `<n>` business
paragraphs of `<n>`, `<n>` with a rule, `<n>` exempt with a reason, `<n>` findings left.
Anything left is named in "Blocked" or is a question - a design that ends with an
`UNCITED` paragraph nobody decided about is a behaviour on its way to being lost.

## Blocked

## Tool gaps

## Review findings

| # | Reviewer | Severity | Finding | applied / rejected / open | Where / why |
|---|---|---|---|---|---|

## Left behind

Running services; contents of `<mu>/.tmp/`.


## Waiting for the user
