---
name: tir-cobol
description: "What each CA Gen TIR runtime module (`*> @function TIRxxxx`, `*> @fail`) does in COBOL, as the local parity runner implements it - the call shape, per-module behaviour and quirks. Use when reading an extracted-logic document, designing (mu-design) or implementing (mu-implement) code that replaces a program calling TIR modules, or when a recording shows a TIR result."
user-invocable: false
---

# The `TIR*` runtime modules

`TIR*` is CA Gen's runtime library: date arithmetic, type conversion, string handling
and a handful of environment services. Generated code calls them like any other
program, which is why they show up as `*> @function` and `*> @fail` in an
extracted-logic document.

**What this registry is.** The behaviour the local parity runner implements, read off
the `cagen` shim set it compiles. It is a *reconstruction*, not Broadcom's specification:
each stub's ABI was derived from the generated call sites in this portfolio and most of
its semantics from what the caller does with the result. Each stub's own header says
which call sites it was derived from and how confident the mapping is - read it before
relying on a detail, and record a difference as a finding.

**Why it is authoritative anyway, for a migration.** Recorded cases run against these
stubs. A translation has to reproduce the recordings, so what these modules do *is* the
behaviour the target must match, whatever the mainframe library did. Where the two could
differ and it matters, the right move is a case that pins the value, not a better guess.

## The call shape

Almost every one of them is

    CALL '<TIRxxxx>' USING IEF-RUNTIME-PARM1, IEF-RUNTIME-PARM2, GLOBDATA,
                           <operand>, …

so the first two operands carry nothing and the third is the shared control block. The
operands after that are the function's own, **inputs first and the result last** - which
is the convention `*> @function <TIR…>(<inputs>) -> <result>` reports. A module that
works in place reads as though its last operand were an output.

Each operand is an `...AT` group: a wrapper holding the value plus its own length and
flags. Errors come back through `GLOBDATA`: the caller clears `ERROR-ENCOUNTERED-SW`
before the call and leaves (`GOBACK`) if `STATUS-FLAG`, `ERROR-ENCOUNTERED-SW` or
`VIEW-OVERFLOW-SW` is non-blank afterwards - that is the `@exception-check`.

The exceptions to the shape:

- `TIRD2VW`, `TIRVW2D`, `TIRS2VW`, `TIRVW2S` - value pair only, `GLOBDATA` last when passed.
- `TIRDAT2` - third operand is its own control block `PSMGR-TIRDATE-CMCB`, `GLOBDATA` optionally fourth.
- `TIRLGLOD` - the target program id comes *first*, then the usual three, then the target's views.
- The online/batch harness modules (services section) - `RUNTIME-PARM1, RUNTIME-PARM2`, then
  their own control block or fields, and `GLOBDATA` **last**; they report through their own
  return-code field, not the `GLOBDATA` switches, and mostly nothing is tested after the call.

**Read `catalogue.md` (in this skill's directory) for the details of any module** - what it
does, its operands, its quirks, one row per module. A module that is wrong or missing is fixed
there, not described again here.

## Common behaviour

Blank or invalid input is mostly **not** diagnosed: it lands on the zero date or zero
rather than raising anything (`TIRFNUMD` is the documented exception). The caller's
`@exception-check` after the call therefore passes, and the wrong value travels on. This
is the single most common way a date bug hides in generated code.

The zero date is `'0001-01-01'` on the Db2 side and `0` (`00000000`, Gen's null date) on
the view side, and the generated code itself writes that literal - it is a sentinel, not
a real date. `99991231` is the open-ended "max date".

A varying-text operand carries `MA` (maximum length, set to 4096 by the caller), `FL`
(current length) and `FP` (the bytes); only `FP (1:FL)` is meaningful afterwards.

The modules that **return without doing anything** say so on stderr when called.

That matters in two directions. A recording made against them pins *no effect*, so a
case that reaches one is not evidence about what the mainframe does - and `TIRFAIL` in
particular **returns** here, where the real one terminates, so a run that calls it keeps
going and reports a result the original would never have produced. If a case's output
depends on one of these, say so in the case.

`TIRTRCE` (the trace hook), `TIRMTQB` (message retrieval) and `TIRDAT2` return a neutral
answer rather than nothing, which is enough for the generated code around them.
