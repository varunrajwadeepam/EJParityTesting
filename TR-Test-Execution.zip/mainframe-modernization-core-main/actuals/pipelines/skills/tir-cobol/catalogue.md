# TIR modules → COBOL behaviour

What each module does under the local parity runner; the common call shape and the rules
that hold for all of them are in `SKILL.md`. A new or corrected module goes here.

## Date and time

| Module | Does | Operands after `GLOBDATA` |
|---|---|---|
| `TIRDAT2` | date/time service selected by `PSMGR-TIRDATE-REQ`; everything travels in `PSMGR-TIRDATE-CMCB` (the `PSMGR-TIRDATE-*` fields, part of `GLOBDATA`), not in an `...AT` operand | see below |
| `TIRFDAY` | day of month from `YYYYMMDD` | date `X(8)` → day `S9(4) COMP` |
| `TIRFMTH` | month from `YYYYMMDD` | date `X(8)` → month `S9(4) COMP` |
| `TIRFYEAR` | year from `YYYYMMDD` | date `X(8)` → year `S9(4) COMP` |
| `TIRFHOUR` | hour from `HHMMSS` | time `X(6)` → hour `S9(4) COMP` |
| `TIRFMIN` | minute from `HHMMSS` | time `X(6)` → minute `S9(4) COMP` |
| `TIRFSEC` | second from `HHMMSS` | time `X(6)` → second `S9(4) COMP` |
| `TIRFMICR` | microseconds from the `X(20)` timestamp `YYYYMMDDHHMISSNNNNNN`, bytes 15-20 | timestamp → microsecond `S9(9) COMP` |
| `TIRFDTEJ` | `YYYYMMDD` → Julian `YYYYDDD`, i.e. `year * 1000 + day-of-year` | date `X(8)` → julian `S9(9) COMP` |
| `TIRFDAYS` | `YYYYMMDD` → **days since 31 December 0000**: `'00010101'` is 1, `'19970319'` is 729102; callers subtract two of them for a term in days | date `X(8)` → days `S9(9) COMP` |
| `TIRFDNUM` | Gen `numdate`: date → the number `YYYYMMDD` (digits reinterpreted, no arithmetic); the null date gives `0`, which callers test | date `X(8)` → number `S9(9) COMP` |
| `TIRFNUMD` | Gen `datenum`: number `YYYYMMDD` → date; `0` gives the null date, `99991231` the max date - callers build both sentinels this way and compare business dates to them; an invalid date returns 0 and raises a runtime error | number `S9(9) COMP` → date `X(8)` |
| `TIRFDTEC` | Gen `datetext`: text date → `YYYYMMDD`; accepts `yyyy-mm-dd`, `mm/dd/yyyy`, `dd.mm.yyyy` and `yyyynnn`; unparseable text comes back as the zero date | string `X(10)` → date `X(8)` |
| `TIRFDDUR` | date ± labelled duration. Reads `PSMGR-FUNC-IN-DATE` and the duration `DDURA-YYYY`/`-MM`/`-DD`, each with a `-MISS` flag (`DATA-MISSING` = component absent), writes `PSMGR-FUNC-OUT-DATE` `X(8)` - all in `GLOBDATA`'s `PSMGR-FUNCTION-DATA` | none - everything travels in `GLOBDATA` |

`TIRDAT2` requests: `0` validate `PSMGR-TIRDATE-DATE` (format `DATEF`: 0 `YYYYMMDD`, 1
`CYYMMDD`, 2 `YYMMDD`) and/or `-TIME` (`TIMEF`: 0 `HHMMSSTH`, 1 `HHMMSST`, 2 `HHMMSS`); a zero
field is not validated; the only answer is `PSMGR-TIRDATE-RC` (0 OK, 4 warning, 8 error, text in
`-RETMSG`). `7` current timestamp: fills `-DATE`, `-TIME` and `-TSTAMP` `X(20)`
`YYYYMMDDHHMISSNNNNNN` - this is `CURRENT_DATE`/`CURRENT_TIMESTAMP`, typically called only when
an import date equals the null date. Declared but unused here: `1` system date/time, `2`/`3` add
`-INC` days to input/system date, `4`/`5` reformat a date, `6` validate a timestamp.

## Conversion between view and Db2 types

| Module | Does | Operands |
|---|---|---|
| `TIRD2VW` | Db2 date `X(10)` ISO `'YYYY-MM-DD'` → view date `S9(8)` `YYYYMMDD`, after a fetch; `'0001-01-01'` → `0` | db2-date, view-date [, `GLOBDATA`] |
| `TIRVW2D` | the inverse, before the value is used as an SQL host variable; `0` → `'0001-01-01'` | view-date, db2-date [, `GLOBDATA`] |
| `TIRS2VW` | Db2 timestamp `X(26)` `YYYY-MM-DD-HH.MM.SS.ffffff` → view timestamp `9(8)`+`9(12)` (`YYYYMMDDHHMMSSffffff`); the Db2 low value → all zeros | db2-tstamp, view-tstamp, `GLOBDATA` |
| `TIRVW2S` | the inverse (separators inserted); input is usually `TIRDAT2`'s `TSTAMP` | view-tstamp, db2-tstamp, `GLOBDATA` |

These four take **no** `IEF-RUNTIME-PARM`s: the value pair comes first and `GLOBDATA`, when
passed at all, last. Mixing them up with the usual shape is a byte-offset error, not a
type error, so nothing would report it. Nothing is tested after them, and a Db2 NULL never
reaches `TIRD2VW`: the caller tests the null indicator (`...NF = -1`) first and sets the view
date to zero itself.

## Numbers and strings

| Module | Does | Operands after `GLOBDATA` |
|---|---|---|
| `TIRFCHR` | Gen `textnum`: number → text `X(15)`; integer part only, **sign and decimals dropped**, right-justified and zero-filled (`-1234.456` → `'000000000001234'`) | number `S9(15) COMP-3` → string `X(15)` |
| `TIRFNUM` | Gen `numtext`: text → number, the inverse; surrounding blanks stripped. Callers test for an all-blank input themselves and use 0 instead of calling | string → number `S9(15) COMP-3` |
| `TIRFSSTR` | Gen `substr`: `length` characters from 1-based `start`; length `0` → empty string. Start or start+length beyond the input is a runtime error (`TIRM132E`-`134E`), surfaced through the switches | in, start, length → out (varying text) |
| `TIRFTRIM` | Gen `trim`: removes **trailing** blanks only; the result length is in the output's `FL`, and an all-blank input returns `0`, which is what callers branch on | in → out, both varying `X(4096)` with `MA`/`FL` |
| `TIRUPPR` | translates `data` in place through the named table (the dialect's translation/upper-case table), for `length` bytes - in practice the 8-byte transaction code; no status test | table, length, data, `GLOBDATA` |

`TIRFCHR`'s 15-character result is why generated code moves it through a right-justified
REDEFINES (`R2---JUST`, `R4---JUST`, `R7---JUST`) before using it: that keeps the rightmost
digits, so day 7 becomes `"07"`, while a plain `MOVE` into `X(2)` would give `"00"`.

## Services, and the ones that do nothing

`TIRLGLOD` is the **dynamic dispatcher**: first operand is the target program id (a `VALUE`
literal), then the two runtime parms and `GLOBDATA`, then that program's own views, passed
through untouched; only the `GLOBDATA` switches are tested after it. The logic extractor resolves
these to the real target, so a `@call` through the loader reads as a direct call.

`TIRFAIL` is the **abend**: abend recovery and error reporting. Generated code calls it
where a model-level failure is raised, and `*> @fail` marks it: the program does not
continue past it.

These stubs **return without doing anything**:

    TIRBTCH    TIRDLCT    TIRFAIL    TIRHSTG    TIRMOVEA   TIRMOVEP

What the real modules do. None of them carries business logic; they appear in the batch
harness (`TIRBTCH`, `TIRRETCD`, `TIRFAIL`) and in the online / screen-manager harness of the
generated load modules, not in action-block code.

| Module | Real behaviour | Answer comes back in |
|---|---|---|
| `TIRBTCH` | Batch Manager service, selector `TIRBATCH-REQUEST`: `WRITEMSG` (line to the message log), `OPENIOVO`/`CLOSEIOV` (inter-step view file), `ENDOFJOB`; also declares `COMMIT`/`ROLLBACK` | `TIRBATCH-RETURN-CODE`: spaces OK, `'SF'` switch failed, `'F '` fatal; usually untested |
| `TIRRETCD` | batch step return-code exit: given current/next load module and procedure step and the default code (e.g. `+1000`), may override it; the JCL selects the next step on it | `TIRRETCD-RETURN-CODE`, adopted (and logged via `TIRBTCH`) if changed |
| `TIRDLCT` | dialect for a user id, terminal id and system id | `TIRDLCT-RETURN-DIALECT` |
| `TIRHSTG` | allocates heap storage for the global work area and the common-format buffer | `TIRHSTG-RC` (0 OK; else heap failure) |
| `TIRMOVEA` | moves `length` bytes (operand 3) from operand 5 into operand 4 | target operand |
| `TIRMOVEP` | same with offsets: length, target, target offset, source, source offset | target operand |
| `TIRMSG` | screen-manager message service, `SCMGR-REQUEST` (`GURB` get the input message, `ROLB` roll back, map/help/prompt requests…) | `SCMGR-RETURN-CODE`, `SCMGR-MESSAGE`, `MSG-GOT-SW` |
| `TIRPROF` | user/application profile stack, `IET-PROF-FUNC` `GET`/`POP`/`PUT`/`PUSH`/`RESET`/`RESTART` | `IET-PROF-STAT`; error texts copied to the failure area |
| `TIRSECR` | security exit: may this user run this transaction (user, trancode, terminal, system, load module, step, dialect)? | `TIRSECR-RETURN-CODE` spaces = allowed, `TIRSECR-FAILURE-MSG` `X(80)` |
| `TIRSYSID` | current system id | `IET-SYSTEM-ID` `X(8)` |
| `TIRUSRID` | current user id | `IET-USER-ID`, `IET-USER-ID2` (caller defaults the second to the first) |
| `TIRMTQB` | message number → text, from the dialect's message table | `TIRMTQ-RETURN-MESSAGE`: text `X(256)` + length |
| `TIRTRCE` | Diagram Trace Facility hook, present only when built with debug support; uses the trace save area in `GLOBDATA` | nothing |

The remaining harness modules - plumbing for the screen manager, memory and the
client/server wire format. Nothing in business logic depends on them:

| Module | Does | Answer comes back in |
|---|---|---|
| `TIRADDR` | registers the addresses of up to 250 field operands in a data-definition table (operand 3: type, length, decimals, address per field; operand 4: field count) | the table; no status |
| `TIRSETA` | sets the pointer in operand 3 to the address of operand 4 | operand 3 |
| `TIRMMFN` | memory manager, `MMRT-FN`: 1 INIT, 2 ALLOCATE, 4 INQUIRE, 8 EXTEND, 16 TRIM, 32 DISCARD, 128 TERM, 256 INQALL | `MMRT-RETURN-CODE` + an address the caller `SET`s a buffer to |
| `TIRCFID` | identifies which view the common-format buffer holds | `IET-PROF-COMM-ID` `X(8)` |
| `TIRCFIN` | translates data out of the common-format buffer, `UA-VIEW-FLAG`: `V` view data, `U` user area, `D` dialect, `E` exit state | `TIRCFIN-RC` (non-zero → dialog failure) |
| `TIRCSRM` | client/server request manager: passes the GURB buffer with flow mode and current/next procedure-step locations | nothing tested |
| `TIRDCRYW` | decrypts the inbound buffer | `TIRDCRYW-RC` 0 OK, 1 size exceeded, 2 not used, 3 appl error, 4 memory error; encrypted/security flags |
| `TIRSECW` | client security validation for the transaction code | `TIRSECW-RC` 0 OK, 1 parse failure, 2 not used; client user id/password `X(64)` |
| `TIRLIPS` | looks up a procedure step in the `LIPS-ENTRY` table: 1 step from trancode, 2 trancode from step, 3 current step, 4 next step | the located entry (step, load module, trancodes), `LIPS-RC` |
| `TIRERR` | screen-manager failure handler, from `FAIL-TYPE` (profile, exec, dialog, commit, heap), trancode, message number + suffix, profile errors | `FAIL-TERM-STAT` (sent message, did all, retry, put profile) |
| `TIRPXMIT` | transmits the GURB buffer back to the client | nothing |
