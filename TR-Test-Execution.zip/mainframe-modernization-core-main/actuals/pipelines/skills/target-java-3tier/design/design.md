# Three-tier Java - design

Read with `SKILL.md` and the common part of `archetype/<archetype>.md`.

## Templates

`design/templates/` holds the Java part of each of the command's templates, under the same
file name: `rules.md`, `dictionary.md`, `design.md`, `tests.md`.

To write or review an artifact, read the command's template
(`${CLAUDE_PLUGIN_ROOT}/skills/mu-design/templates/<artifact>`) and this skill's template of the same name
together. Each section here belongs to the section with the **same heading** in the
command's template:

- it **adds** to that section - its rules apply on top of the generic ones;
- its forms, tables and examples **replace** the generic placeholders (`<target home>`,
  `<entry point>`, `Target outcome`, ...);
- a section not named here is used as the command's template states it.

The sections of `SKILL.md` and of the archetype's common part belong to `design.md` the same
way, under the same headings: state them there in full - `design.md` is all the
implementation reads of the target's shape.

## Archetypes

The archetype file's "Design part" is laid out by artifact, and under each artifact its
sections belong to the sections with the same heading in this skill's template - or the
command's, for an artifact this skill has no template of - adding to them and replacing
their placeholders as above.

Where the generic template and this skill seem to disagree, the generic rule states what
must hold and this skill states how it holds in Java; between this skill's templates and
the archetype, the archetype is the more specific. A real conflict is a question.

## What not to do

- **Do not write `.java` files.** The snippets a design needs are part of the design.
