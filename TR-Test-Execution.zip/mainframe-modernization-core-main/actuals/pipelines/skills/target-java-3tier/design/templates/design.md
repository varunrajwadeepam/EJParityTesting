<!-- Three-tier Java part of the command's `design.md` template. Each section belongs to the
section with the same heading there: it adds to it, and its forms and examples replace
the generic placeholders. A section not named here is used as the template states it.
The other target sections (Structure, Use cases, Comments, entry points, outcomes,
Neighbors, Transactions, Persistence, Testing) are in `SKILL.md`: state them in
`design.md` in full. -->
# design.md - three-tier Java

## What the target is

**A conventional three-tier Java application**, of the archetype `mu.yaml` names
(`archetype/<archetype>.md`). The archetype decides how the use cases are reached from
outside and how an outcome reaches the caller; `SKILL.md` holds what is the same for all.

## Starting point

```
Exists            Application.java, the build file (Spring Boot and JDBC),
                  config/DatabaseConfig.java with a DataSource wired to Db2 from
                  supplied properties, application.yml, the empty package layout below
                  <root>.gen.GenDates, if the solution folder already has it
To be written     everything else in this document, and GenDates (tir-java lib.md)
                  when the solution folder does not have it
```

Name the **Java package root**, and whatever the archetype adds; none of it is derivable
from anything else, and an implementer who has to guess guesses once and then everything
is named around the guess.
