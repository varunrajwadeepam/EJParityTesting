<!-- Three-tier Java part of the command's `dictionary.md` template. Each section belongs to
the section with the same heading there: it adds to it, and its forms and examples
replace the generic placeholders. A section not named here is used as the template
states it. -->
# dictionary.md - three-tier Java

## `## Attributes`

`Target type` is the Java type; where the width matters - a padded comparison, a
fixed-length key - say so in the cell. A date is `LocalDate`, a timestamp
`LocalDateTime`, an amount `BigDecimal` with its scale.

| COBOL | Domain name | Target type | Column | Rules | Note |
|---|---|---|---|---|---|
| `DIR-CONTR-NBR-*` | `contractNumber` | `String` (8) | `CONTR_NBR` | 7, 12 | |

## `## Use cases`

`Entry point` is in the archetype's form; `Target home` is the service method.

## `## Dropped programs`

`Where it went` names the class and method: `WipDao.delete`, the schema's own cascade;
`WipNumberGenerator`, rules 20-26.

## `## Constants`

A constant that guarded a failure becomes an exception: `FATAL-ERROR` `'FE'` →
`ProcessingFailedException`. One that guarded a usable state is dropped.
