<!-- Three-tier Java part of the command's `tests.md` template. Each section belongs to the
section with the same heading there: it adds to it, and its forms and examples replace
the generic placeholders. A section not named here is used as the template states it.
The archetype file (`archetype/<archetype>.md`) adds the case format and the outcomes. -->
# tests.md - three-tier Java

## What to cover

Every domain exception the outcome mapping produces gets a case, each reached by the
condition that produces it in the original.

## Unit tests, alongside these

Unit tests mock the DAOs. A rule that can only be reached through the entry layer and
four tables is a rule whose home is wrong.

## Which values to keep

From the target side: the outcome, the error code and the returned fields a caller acts
on. Pin the message text in one case only.
