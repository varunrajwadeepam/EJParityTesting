<!-- Three-tier Java part of the command's `rules.md` template. Each section belongs to the
section with the same heading there: it adds to it, and its forms and examples replace
the generic placeholders. A section not named here is used as the template states it. -->
# rules.md - three-tier Java

## Format

`Target home` is **one service method**:

| # | Rule | From | Target home |
|---|---|---|---|
| 14 | A duplicate written-premium control row abandons the rest of the creation: the surcharge and other-income rows are not attempted. | `A7549229` PARA-1956030950 (2010-2043) | `WipCreationService.createControlTotals` |
| 15 | The detail rows are written **before** the three control rows. | `A7549229` PARA-1955993943 (1960-2180) | `WipCreationService.create` |

A rule that needs two methods is two rules, or the method boundary is wrong. The Java
does not name the rule; its Javadoc carries the `From` cell verbatim, range included,
and `validate_traceability.py` checks it against the index - so a range mistyped here
becomes a finding over the code later.

## Rules that are easy to lose

- **A null decision** that an `Optional` silently defaults is a lost rule.
- **A comparison against spaces**: this target strips trailing blanks and has no
  padding, so "not supplied" is `null` and `""`, both. A leading blank is data.
