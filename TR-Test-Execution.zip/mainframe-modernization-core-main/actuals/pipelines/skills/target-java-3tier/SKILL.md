---
name: target-java-3tier
description: "Architecture skill for a conventional three-tier Java target - Controller, Service, DAO - rather than a line-for-line translation. Common rules here and in archetype/<archetype>.md (selected by mu.yaml target.archetype: REST, SERVICE); design/ for mu-design (the Java parts of the rules, dictionary, design and tests templates), implement/ for mu-implement (building the code from the design). Use when writing or reviewing those artifacts or that code, by either command or a subagent it starts."
user-invocable: false
---

# Three-tier Java target

The target is a conventional three-tier Java application. The structure of the original
does not survive: no views, no control block, no status flags, no exit states, no
per-paragraph methods, no per-program classes, no per-program contracts.

The original is seen only as `extracted-logic/` and the design artifacts, never as COBOL.
`extracted-logic/paragraph-index.json` is an input to both phases: it is where a citation's
member, paragraph and line range are taken from, and what *Checking that all of it is
migrated* below reads.

## Phases

This file and the common part of `archetype/<archetype>.md` hold in every phase. Each phase
reads them and its own files, and nothing of the other phase's:

| Phase | Also reads |
|---|---|
| `mu-design` | `design/design.md`, `design/templates/*`, the archetype file's "Design part" |
| `mu-implement` | `implement/implement.md`, the archetype file's "Implement part", `scripts/validate_traceability.py` |

## Archetypes

`mu.yaml` `target.archetype` says what kind of solution this MU is within the target - how it
is reached and by whom. `archetype/<archetype>.md` holds that kind: a common part, then a
"Design part" and an "Implement part". Its common part adds to this file, section by
heading; its `What not to do` adds to this file's.

| Archetype | File | The MU is |
|---|---|---|
| `REST` | `archetype/REST.md` | exposed to external callers as an HTTP API |
| `SERVICE` | `archetype/SERVICE.md` | called in-process by other parts of the target, as a Spring bean |

An archetype with no file here is a hard block: the target shape is not a phase's to invent.

## Structure, and what may not cross

```
service/    <Name>Service             the rules. No entry-layer types, no SQL.
dao/        <Name>Dao (or Repository) SQL. No business decisions.
domain/     <Name>                    the business objects the layers pass
exception/  <Name>Exception           the domain exceptions the service and the DAO raise
client/     <Neighbor>Client          implementations of the neighbor interfaces
```

The archetype adds the entry layer on top - the only layer that knows how the MU is
called - with the packages it needs.

`exception/` is its own package, not a corner of `domain/`: the service raises these, the
DAO raises these, and the entry layer maps them, so no one layer owns them.

- **The service sees no entry layer and no SQL.** No type of the archetype's entry layer,
  no `JdbcTemplate`, no SQL string, no `SQLException`. It takes domain objects, applies
  rules, calls DAOs, and throws domain exceptions.
- **The DAO decides nothing.** One DAO per table or aggregate root. It takes and returns
  domain objects, and the SQL lives in it and nowhere else. It translates database
  conditions into Java ones at its own boundary: a not-found read is `Optional.empty()`,
  a duplicate key is a domain exception, a multi-row hit on a singleton read is a domain
  exception. No `SQLCODE` reaches a service.
- **The domain object is not the row and not the entry layer's input.** Three similar shapes is the
  price of the layering; one shared shape re-creates the coupling the layers exist to
  remove.

## Use cases are not programs

A use case is **one service method**. A helper program is a private method, or a small
collaborator class of its own.

## Comments

Javadoc on the class, the field, the method:

```java
/**
 * Creates the WIP business event and its totals.
 *
 * <p>From {@code A7549229} PARA-1955993943 (2572-2754), PARA-1956030950 (2010-2043).
 */
@Transactional
public WipCreationResult create(WipCreationCommand command) { … }
```

A class whose Javadoc runs longer than its first method is a design document in the
wrong place.

**The member, the paragraph and the range come from the index** - through the `From`
cell of `rules.md`, which was itself taken from it - and never from memory. Several
paragraphs of one member share the one `{@code …}` that precedes them, as above. The
range is required, and it is checked: see below.

## Checking that all of it is migrated

A three-tier target cannot be reviewed against the member a line at a time. The names
are chosen for the domain, so nothing here resembles anything in the COBOL, and the
citation is the only route back. `scripts/validate_traceability.py` checks that the
route exists and leads somewhere real - every `business` paragraph of the index named by
some comment, and every citation resolving to the paragraph and range the index gives:

    python ${CLAUDE_PLUGIN_ROOT}/skills/target-java-3tier/scripts/validate_traceability.py \
        --index <mu>/extracted-logic/paragraph-index.json \
        --java <solution>/src/main/java --external <mu>/design/stubs.md \
        --allow <mu>/implement/.tmp/allow.txt \
        --report <mu>/implement/traceability.md

`UNCITED` is the finding that matters: the paragraph had statements or reported an
outcome, and nothing in the code claims to carry it. That is the shape of a behaviour
that was never migrated, which is otherwise invisible - the code compiles, the tests
pass, and the rule is simply absent. The rest - `STALE_RANGE`, `WRONG_PROGRAM`,
`NO_PROGRAM`, `UNKNOWN_PARAGRAPH`, `UNKNOWN_PROGRAM` - are citations that send a reader
somewhere other than the code they are about.

- **`--allow` is `rules.md`'s own exempt list**, not a second judgement. Generate it with
  `check_rule_coverage.py --allow-out`; a paragraph the design accounted for is not
  accounted for again here. Exempting a paragraph that the design did not is a question
  for the design, not an entry in this file.
- **`--external <mu>/design/stubs.md`** keeps the neighbors and absent modules out of the
  findings: they have no extracted-logic document because they are not this MU's, and
  that is already recorded. A member in neither the index nor `stubs.md` is a real
  `UNKNOWN_PROGRAM` - code depending on a member with no provenance at all, where
  nothing, this check included, can say whether that part was migrated faithfully.
- Mechanism paragraphs are exempt and citing one is never an error. Which they are is
  `FORMAT.md`'s call, biased towards `business`; do not reclassify to pass the gate.

## The command dispatch becomes entry points

One entry point per arm, in the archetype's form, each calling one service method.

## Legacy outcomes become target outcomes

Inside the application a non-zero outcome is a **domain exception** in `exception/`, one
per outcome a caller can tell apart; how it reaches the caller is the archetype's.

## Neighbors, stubs and the runtime

A neighbor is a Java interface the service owns, implemented in `client/`. A neighbor that
is a `SERVICE` MU of the solution is its `<Name>Api` bean (its `<name>.usage.md`), wrapped by
`client/<Neighbor>Client`. A stub is an interface with a stub implementation; a boundary
with no contract is `client/<Neighbor>StubClient`, answering as its run stub does, swapped
for the real client later without touching the service. A TIR call is listed one line per module with its
`tir-java` resolution; LIB modules name the `GenDates` method.

## Transactions

`@Transactional` on the service method that is the use case, and nowhere else - not in
the entry layer, not on a DAO, not on a private helper.

## Persistence

`JdbcTemplate` with prepared statements, or Spring Data JDBC if `rules.md` has no
statement-level rules to preserve; not JPA, unless `design.md` argues the case and
accounts for every place the original's SQL behaviour is observable.

- A row limit is `FETCH FIRST n ROWS ONLY`, or `setMaxRows(n)` where the original's
  cursor declared it; `jdbcTemplate.query(...)` alone materialises every matching row.
- A limit on entries after a reduction streams with `jdbcTemplate.queryForStream`, opened
  in try-with-resources inside the transactional method and never returned across a
  layer.
- **Trailing blanks only, and no padding.** COBOL compares fixed-width values with
  trailing blanks ignored and leading blanks significant, so the Java keeps exactly that:
  - a DAO strips **trailing** blanks from every `CHAR` it reads, and the entry layer
    strips trailing blanks from every string it accepts - `s.replaceAll(" +$", "")`;
  - **never** `trim()` or `strip()`: `" 123"` is not `"123"` to the original;
  - nothing pads on write: Db2 pads a `CHAR` on store and compares `CHAR` values
    blank-padded, so a value written through a prepared statement lands and matches as a
    padded one does. There is no `FixedWidth` helper;
  - absence is `value == null || value.isBlank()`;
  - where the original cuts a value to a shorter field and the cut is observable, that is
    a rule in `rules.md` with its width, not a general helper.
- **Dates are `LocalDate` / `LocalDateTime`**, read with `getObject(col, LocalDate.class)`
  and bound with `setObject`; never `java.sql.Date`. The zero and max dates are
  `GenDates.ZERO` / `GenDates.MAX` (`tir-java`).
- **Null means absent**: `Optional`, or a nullable field something actually checks.

## Testing

Unit tests over the service or the collaborator that owns the rule, **with the DAOs
mocked**: this target is free of the original's structure precisely so that its rules
are reachable without a database. Integration tests go through the entry layer, as the
archetype states, and assert the outcome, the returned fields and the row effects.

## What not to do

- **Do not emulate the COBOL in the services.** No context object, no `GlobData`, no
  status flag, no exit-state enum, no escape mechanism, no paragraph-named methods, no
  class per program, no 400-field request record, and **no fixed-width helper**: this
  target trims trailing blanks and pads nothing (Persistence).
- **Do not return a business outcome as a success.** A legacy response code, exit state,
  message and message level are a domain exception here, and the archetype says how it
  reaches the caller.
