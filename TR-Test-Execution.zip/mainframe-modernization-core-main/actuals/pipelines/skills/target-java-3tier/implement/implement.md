# Three-tier Java - implement

Read with `SKILL.md` and `archetype/<archetype>.md` (common part and "Implement part").
`design/` of the MU is the specification: `design.md` states the target's shape for this MU
in full. This file says how to build it and fills silences only; a conflict is a question
and `design.md` wins. Code style is the `code_skill`'s, build and tests the
`solution_skill`'s.

## Code

- Packages, classes and homes exactly as `design.md` and `rules.md` name them. Domain names;
  no program id, no generated COBOL name.
- Every class and method carries the `From` cells of the rules it holds (`rules.md`) -
  member, paragraph and range copied, not recalled, and the range always. Checked by
  `scripts/validate_traceability.py` (`SKILL.md`, *Checking that all of it is migrated*);
  run it while coding rather than discovering 500 uncited paragraphs at review.
- TIR calls as `design.md` lists them (`tir-java`); `GenDates` reused if the solution has it.

## Config

Clock and zone as beans; connection and secrets from the environment; DB schema set at the
pool only; nothing hardcoded that `target-state.md` or `design.md` defines.

## Tests

- Unit test per rule with logic, over its home, DAOs mocked; one per component of a derived
  identifier.
- Integration test per `tests.md` case through the entry layer, seeded from
  `unit/<entry>/fixtures`. Never edit an expectation; a doubt is a question.
- ArchUnit test for the layer rules of `SKILL.md`, Structure.
- A test removes what it wrote; the suite passes twice in a row. Message text pinned in one
  case only.

## Missing facts

A required value neither `design.md` nor `target-state.md` gives (package root, port, zone,
module layout) = question with the assumed value.
