<!-- Archetype SERVICE of the three-tier Java target: the MU is a Java service other parts of
the target call in-process, as a Spring bean. The common part adds to SKILL.md, section by
heading; each phase also reads its own part below. -->
# Archetype SERVICE

The MU's entry points are called from inside the target, in the caller's process. Each use
case is a method of a published Java interface; each legacy outcome is a published
exception; the interface, its records and its exceptions are what other MUs see. There is
no HTTP, no port and no `main`.

## What not to do

- **Do not return a business outcome as a value.** No response code, status field or
  "result with an error" in a returned record: a legacy outcome is an exception here.
- **Do not put logic in a facade.** A facade that decides anything is a fourth place rules
  live.
- **Do not let `api/` types past the facade.** No `<Name>Command` or `<Name>Result` in a
  service.
- **Do not own what the caller owns.** No `DataSource`, no pool, no `main`, no web,
  security, actuator or OpenAPI; no bean a caller's context may already have unless it
  backs off (`@ConditionalOnMissingBean`).

## Structure, and what may not cross

Three layers on top of the skill's structure:

```
api/        <Name>Api                   the published interface: one method per use case
api/model/  <Name>Command/<Name>Result  records, the in-process contract
facade/     <Name>Facade                implements <Name>Api. No business logic.
config/     <Name>Configuration         the one class a caller imports
```

- **A caller sees `api/`, `api/model/` and `exception/`, and nothing else.** Services, DAOs,
  domain objects and clients are package-private or undocumented to callers.
- **The facade holds no logic.** It accepts the command, maps it to a domain object or a
  service argument, calls one service method, and maps the result to a record. Exceptions
  pass through unchanged.
- **The record is not the domain object.** The facade strips trailing blanks from every
  string it accepts (Persistence), and nothing else.
- `<Name>Configuration` is a `@Configuration` that scans or declares this MU's beans; a
  caller wires the MU with `@Import(<Name>Configuration.class)`.

## The command dispatch becomes entry points

One **interface method** per arm, named for the business action: `create`, `find`,
`update`, `delete`. Name each as the method signature. An unknown arm has no method and
needs no rule.

## Legacy outcomes become target outcomes

A non-zero outcome is an **exception the caller catches**, never a returned value.

Unchecked, under one base class `<Mu>Exception` with `code`, `message` and `severity` -
the one error form; one subclass per outcome a caller can tell apart. Inventing a
subclass for one of two identical legacy outcomes is a new contract. An unmapped outcome
is `UnexpectedOutcomeException`; the status flag set (`FE` / `DB`) is
`ProcessingFailedException`.

## Transactions

The use-case method **joins the caller's transaction** (`@Transactional`, propagation
`REQUIRED`), as the original joined its caller's unit of work. Not on the facade.

Rollback follows the original, per outcome: an outcome recorded with
`PSMGR-ROLLBACK-RQSTED` = `R` rolls back - Spring's default for an unchecked exception,
which marks the caller's transaction rollback-only; an outcome recorded without it is
listed in `noRollbackFor`. Silence here rolls back the caller's work on an outcome the
original let it keep.

## Testing

Integration tests call the `<Name>Api` bean, in a Spring context the test builds, and
assert the returned fields or the exception and its code, the rollback and the row effects.

# Design part

Each section belongs to the section with the same heading in this skill's template of the
artifact named above it, or in the command's where this skill has none: it adds to it, and
its forms and examples replace the generic placeholders. A section not named here is used
as the templates state it.

## design.md

### Starting point

This block **replaces** the template's `Exists` / `To be written`:

```
Exists            the build file: a jar module of the reactor with Spring Boot (no
                  repackaging, no Spring Web) and JDBC; the empty package layout below;
                  <root>.gen.GenDates, if the solution folder already has it
To be written     everything else in this document, and GenDates (tir-java lib.md)
                  when the solution folder does not have it
Caller provides   the DataSource (schema set at its pool), the transaction manager,
                  a Clock bean (ours is @ConditionalOnMissingBean)
```

Name the **module coordinates** and the **configuration class**.

### Legacy outcomes become target outcomes

| Legacy outcome | Exception | Code | Rollback | When |
|---|---|---|---|---|
| response `0` | - (returns) | - | - | the work was done |
| response `1`, `EX-…-NF0005` | `WipNotFoundException` | `WIP_NOT_FOUND` | no | the row the caller named is not there |
| response `2`, `EX-…-AE0002` | `WipAlreadyExistsException` | `WIP_ALREADY_EXISTS` | yes | the row the caller is creating exists |
| response `9999` from an unmapped exit state | `UnexpectedOutcomeException` | `UNEXPECTED_OUTCOME` | yes | a callee reported something no arm handles |
| the status flag set (`FE` / `DB`) | `ProcessingFailedException` | `PROCESSING_FAILED` | yes | the original abandons and unwinds |

`Rollback` is the recording's `PSMGR-ROLLBACK-RQSTED`, never a guess; an outcome no
recording shows is a question.

## tests.md

### What to cover

Every exception the mapping produces gets a case, each reached by the condition that
produces it in the original; and one case per `Rollback` value, run inside a caller's
transaction.

### Format

```
Call: wipApi.create(new WipCreationCommand("41554099", "GY18", …))

Expected outcome: throws UserProfileNotFoundException
  code USER_PROFILE_NOT_FOUND, severity E, message "…"
  caller's transaction: rollback-only
```

A success is `returns WipCreationResult(wipNumber = "…", …)`.

### Which values to keep

From the target side: the exception and its code, or the returned fields a caller acts
on; the rollback. Pin the message text in one case only.

## dictionary.md

### `## Use cases`

`Entry point` is the interface method:

| Use case | Entry point | Target home | From |
|---|---|---|---|
| delete a WIP business event | `WipApi.delete(WipKey)` | `WipService.delete` | `P7549510` dispatch arm 1, `A7549212` |

## interface.md

### Operations

`Operation` is the interface method; `Inputs` and `Outputs` are the command's and the
result's fields by domain name; `Error codes` are the exception and code pairs, with the
rollback.

# Implement part

- `api/`, `api/model/` and `exception/` exactly as `design.md` names them; nothing else
  public to callers.
- One facade per interface in `facade/`: command to domain object or service argument, one
  service call, result to record; strips trailing blanks; never reaches a service.
- `config/<Name>Configuration` as `design.md` names it; no `DataSource`, no `main`, no
  `application.yml` in `src/main`; a `Clock` bean only `@ConditionalOnMissingBean`.
- Every exception's rollback exactly as `design.md` maps it (`noRollbackFor` on the
  use-case method).
- ArchUnit, on top of `SKILL.md` Structure: `api` depends on nothing of this MU but
  `api.model` and `exception`; only `facade` uses `api.model` types; nothing uses
  `org.springframework.web`.
- Integration tests: a test-only `@SpringBootApplication` that imports the configuration
  and provides the `DataSource` from `test-db2`; `@SpringBootTest`, calls through the
  `<Name>Api` bean; rollback cases inside a `TransactionTemplate` the test owns.
- `<name>.usage.md`: `Wiring` is the Maven dependency, `@Import(<Name>Configuration.class)`,
  the `<Name>Api` bean to inject and what the caller provides; an operation is the
  interface method, its inputs and outputs the command's and the result's fields, an
  outcome the exception with its code, severity and rollback.
