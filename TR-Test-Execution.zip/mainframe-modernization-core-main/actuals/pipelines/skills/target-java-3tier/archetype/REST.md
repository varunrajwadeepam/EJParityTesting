<!-- Archetype REST of the three-tier Java target: the MU is exposed to external callers as a
REST API. The common part adds to SKILL.md, section by heading; each phase also reads its
own part below. -->
# Archetype REST

The MU's entry points are called from outside, over HTTP. Each use case is an HTTP
endpoint; each legacy outcome is an HTTP status with an error body; the HTTP contract is
what other systems and other MUs see.

## What not to do

- **Do not return a business outcome in a `200`.** A legacy response code, exit state,
  message and message level are an HTTP status and an error body here.
- **Do not put logic in a controller.** A controller that decides anything is a fourth
  place rules live.
- **Do not let HTTP types past the controller.** No `ResponseEntity`, `HttpStatus` or
  `@RequestBody` type in a service.

## Structure, and what may not cross

Two layers on top of the skill's structure:

```
web/        <Name>Controller          HTTP in, HTTP out. No business logic.
dto/        <Name>Request/Response    the HTTP contract
```

- **The controller holds no logic.** It accepts the request, maps it to a domain object
  or a service argument, calls one service method, and maps the result or the exception
  to a response.
- **The DTO is not the domain object.** The request mapping strips trailing blanks from
  every string it accepts (Persistence), and nothing else.
- Exceptions are mapped to responses in one place, a `@RestControllerAdvice` in `web/`.

## The command dispatch becomes entry points

One **endpoint** per arm, with the HTTP method that matches what the arm does: a read is
`GET`, a creation `POST`, an update `PUT`, a deletion `DELETE`. Name each as method and
path. An unknown path is a `404` from the framework and needs no rule.

## Legacy outcomes become target outcomes

A non-zero outcome is an **HTTP error with a body**, never a `200`.

One error body for every error: `{"code": …, "message": …, "severity": …}`. Inventing a
`422` for one of two identical legacy outcomes is a new contract. An unmapped outcome is
a `500`: silence here becomes a `200` with a null body at the first surprise.

## Transactions

Not on the controller.

## Testing

Integration tests go through HTTP and assert the status, the error code, the response
fields and the row effects.

# Design part

Each section belongs to the section with the same heading in this skill's template of the
artifact named above it, or in the command's where this skill has none: it adds to it, and
its forms and examples replace the generic placeholders. A section not named here is used
as the templates state it.

## design.md

### Starting point

```
Exists            the build file includes Spring Web
```

Name the **port** and the **base path**.

### Legacy outcomes become target outcomes

| Legacy outcome | HTTP | Error code | When |
|---|---|---|---|
| response `0` | `200` / `201` | - | the work was done |
| response `1`, `EX-…-NF0005` | `404` | `WIP_NOT_FOUND` | the row the caller named is not there |
| response `2`, `EX-…-AE0002` | `409` | `WIP_ALREADY_EXISTS` | the row the caller is creating exists |
| response `9999` from an unmapped exit state | `500` | `UNEXPECTED_OUTCOME` | a callee reported something no arm handles |
| the status flag set (`FE` / `DB`) | `500` | `PROCESSING_FAILED` | the original abandons and unwinds |

## tests.md

### What to cover

Every error status the mapping produces gets a case - a `404`, a `409` - each reached by
the condition that produces it in the original.

### Format

```
Request: POST /wip
  {"contractNumber": "41554099", "userId": "GY18", …}

Expected response: 404
  {"code": "USER_PROFILE_NOT_FOUND", "message": "…", "severity": "E"}
```

### Which values to keep

From the target side: the HTTP status, the error code and the response fields a caller
acts on. Pin the message text in one case only.

## dictionary.md

### `## Use cases`

`Entry point` is the HTTP method and path:

| Use case | Entry point | Target home | From |
|---|---|---|---|
| delete a WIP business event | `DELETE /wip/{number}` | `WipService.delete` | `P7549510` dispatch arm 1, `A7549212` |

## interface.md

### Operations

`Operation` is the HTTP method and path; `Inputs` and `Outputs` are the request and
response bodies' fields by domain name; `Error codes` are the HTTP status and error code
pairs.

# Implement part

- Endpoints, statuses and error codes exactly as `design.md` maps them; `201` with
  `Location` for a creation where `design.md` says `201`.
- Controllers in `web/`: request to domain object or service argument, one service call,
  result or exception to response.
- Request DTOs in `dto/`: strip trailing blanks; never reach a service.
- One `@RestControllerAdvice` in `web/` maps every domain exception, and every framework
  error, to the one error body.
- Security, OpenAPI and actuator as `target-state.md` says.
- Integration tests with REST Assured against the running entry layer.
- `<name>.usage.md`: `Wiring` is the base URL, authentication and the service's
  deployment; an operation is the method and path, its inputs and outputs the request
  and response JSON fields, an outcome the HTTP status with the error body's `code`.
