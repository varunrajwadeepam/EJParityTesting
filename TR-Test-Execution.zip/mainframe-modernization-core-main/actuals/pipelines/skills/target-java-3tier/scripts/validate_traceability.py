#!/usr/bin/env python3
"""Check the Java against the paragraph index: is all of the MU migrated?

A three-tier target cannot be reviewed against the member a line at a time - the names
are chosen for the domain, so nothing in the Java resembles anything in the COBOL any
more. The citation on the code - `{@code A7549229} PARA-1955993943 (2572-2754)` - is
the only route back to what it came from. This checks that the route exists and leads
somewhere real:

  UNCITED           a business paragraph no comment names. The check that matters: the
                    paragraph had statements or reported an outcome, and nothing in the
                    Java claims to carry it.
  UNKNOWN_PARAGRAPH a citation naming a paragraph in no extracted-logic document.
  WRONG_PROGRAM     the paragraph exists, under a different member than the one cited.
  NO_PROGRAM        a paragraph cited with no member named before it. The weakest of
                    the findings: a name carries the CA Gen model id and was unique
                    across all 910 paragraphs of the measured tree, so the member is
                    recoverable and the paragraph counts as cited. It is still
                    reported, because recovering it takes the index - which is what a
                    reader of the delivered code does not have.
  STALE_RANGE       the cited line range is not the range the document gives. Ranges
                    move when a member is re-extracted, and a wrong one sends the next
                    reader to the wrong place - the failure a citation is supposed to
                    prevent.
  UNKNOWN_PROGRAM   a member id cited that the index does not hold, and that `stubs.md`
                    does not register as a neighbor or an absent module either. A
                    member the code depends on with no provenance document: nothing,
                    this check included, can say whether that part was migrated
                    faithfully. Pass `--external <mu>/design/stubs.md` so that the
                    non-internal members this MU is designed to call stay out of it.

Mechanism paragraphs are exempt: generated plumbing, nothing to carry. Citing one is
not an error. Which paragraphs those are is the extractor's call, recorded as `kind` in
the index and biased towards `business` - see `paragraph_kind` in `extract_logic.py`.

Exits non-zero when anything is found, so it can gate a build. A paragraph the design
has decided needs no citation goes in `--allow` with a reason, where a reviewer can see
it; that is the only way to pass the gate without a citation, and it is deliberately
more visible than widening the classifier. `rules.md` "Paragraphs that produced no rule"
is the design's own form of that list, and `check_rule_coverage.py --allow-out` writes
it in this file's format.

    python validate_traceability.py --index <mu>/extracted-logic/paragraph-index.json \
        --java solution/src/main/java --external <mu>/design/stubs.md \
        --report <mu>/implement/traceability.md
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

# A paragraph name as CA Gen generates it: an uppercase prefix, the model's numeric id,
# and sometimes a suffix naming the part - `PARA-1956031843-FETCH`. The suffix takes a
# run of dashes, not one: four paragraphs of the measured tree are
# `PARA-1955996229---RGVC`, and a single-dash suffix cut the name short at the model id
# and then reported the correctly-cited full name as a paragraph in no document.
PARAGRAPH = re.compile(r"\b[A-Z][A-Z0-9]*(?:-[A-Z][A-Z0-9]*)*-\d{4,}(?:-+[A-Z0-9]+)*\b")
# The range that may follow it, in either of the two forms a citation uses.
RANGE = re.compile(r"\A\s*(?:\(|,\s*)(\d+)\s*-\s*(\d+)")
# `{@code A7549229}`, `A7549229.CBL` or the bare id.
CODE_TAG = re.compile(r"\{@code\s+([A-Z][A-Z0-9]{3,10})\s*\}")
BARE_ID = re.compile(r"\b([A-Z][A-Z0-9]{3,10})(?:\.CBL)?\b")
DIGITS = re.compile(r"\d+")


def shapes(index: dict) -> tuple[set[int], set[int]]:
    """The id shapes this MU actually uses, read off the index rather than assumed.

    Two tokens in a comment look like a citation and are not. A view field carries a
    four-digit view number - `RV-LOOKUP-CD-ID-0147` - and matches any pattern loose
    enough to accept a paragraph suffix. And a Javadoc writes SQL and COBOL verbs as
    `{@code DELETE}`, which is the shape of a member id. Both appear in the measured
    tree, 10 field references and 4 verbs, and both were reported as findings until
    these two shapes were derived instead of guessed.

    Returns the digit-run lengths of real paragraph names - every one in the measured
    tree is the 10-digit CA Gen model id - and the lengths of real member ids.
    """
    runs = {len(m) for entry in index.values() for para in entry["paragraphs"]
            for m in DIGITS.findall(para["name"])}
    return runs or {6, 7, 8, 9, 10}, {len(name) for name in index} or {8}


def is_member_id(token: str, lengths: set[int], programs: set[str]) -> bool:
    """A member id, not a verb a Javadoc put in `{@code …}`.

    A known id is one; an unknown token has to be the right length *and* carry a digit
    to be treated as a misspelt one. Every member id in the measured tree has a digit;
    `DELETE` and `EVALUATE` do not, which is what separates them.
    """
    return token in programs or (len(token) in lengths and any(c.isdigit() for c in token))


def comments(source: str) -> list[tuple[int, str]]:
    """Every comment in a Java file, as `(line number, text)`.

    String and character literals are stepped over rather than stripped, so a `"//"`
    inside a literal does not open a comment and a literal does not lose its content
    to one. Written as a scan because a regex cannot tell the two contexts apart.
    """
    out: list[tuple[int, str]] = []
    i, line, n = 0, 1, len(source)
    while i < n:
        ch = source[i]
        if ch == "\n":
            line += 1
            i += 1
        elif ch in "\"'":
            quote, i = ch, i + 1
            while i < n and source[i] != quote:
                if source[i] == "\\":
                    i += 1
                elif source[i] == "\n":
                    line += 1
                i += 1
            i += 1
        elif source.startswith("//", i):
            end = source.find("\n", i)
            end = n if end < 0 else end
            out.append((line, source[i:end]))
            i = end
        elif source.startswith("/*", i):
            end = source.find("*/", i + 2)
            end = n if end < 0 else end + 2
            text = source[i:end]
            out.append((line, text))
            line += text.count("\n")
            i = end
        else:
            i += 1
    return out


def citations(text: str, programs: set[str], para_runs: set[int],
              id_lengths: set[int]) -> list[dict]:
    """The paragraph citations in one comment, each with the member it is under.

    A comment names the member once and then its paragraphs, so the scan carries the
    last member id it saw forward - that is the form the architecture skill specifies
    and the only one that lets several paragraphs of one program share a citation. A
    paragraph met before any member id is reported with `program=None` rather than
    guessed at: a guess here is what produced citations that pointed at the wrong
    member.
    """
    marks: list[tuple[int, str, str]] = []
    for pattern in (CODE_TAG, BARE_ID):
        for m in pattern.finditer(text):
            if is_member_id(m.group(1), id_lengths, programs):
                marks.append((m.start(1), "program", m.group(1)))
    for m in PARAGRAPH.finditer(text):
        # A view field carries a short view number; a paragraph carries the model id.
        if any(len(run) in para_runs for run in DIGITS.findall(m.group(0))):
            marks.append((m.start(), "paragraph", m.group(0)))

    found: list[dict] = []
    current: str | None = None
    seen: set[int] = set()
    for start, kind, value in sorted(marks):
        if start in seen:
            continue
        seen.add(start)
        if kind == "program":
            current = value
            continue
        # A paragraph name contains its program's digits but never its id, so a
        # paragraph match can never be mistaken for the program mark before it.
        rest = RANGE.match(text[start + len(value):])
        found.append({
            "program": current,
            "paragraph": value,
            "range": [int(rest.group(1)), int(rest.group(2))] if rest else None,
        })
    return found


def load_allow(path: Path | None) -> dict[tuple[str, str], str]:
    """Reviewed exemptions: `PROGRAM PARAGRAPH  reason`, one per line, `#` comments."""
    if not path:
        return {}
    allowed: dict[tuple[str, str], str] = {}
    for number, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        parts = line.split(None, 2)
        if len(parts) < 3:
            sys.exit(f"{path}:{number}: expected 'PROGRAM PARAGRAPH reason', got {raw!r}")
        allowed[(parts[0], parts[1])] = parts[2]
    return allowed


# A `stubs.md` row: the member is the first cell, `neighbor` or `absent` the second.
STUB_ROW = re.compile(r"^\|\s*`?(?P<program>[A-Z][A-Z0-9#@$]{2,10})`?\s*\|"
                      r"\s*`?(?P<kind>neighbor|absent)`?\s*\|")


def load_external(path: Path | None) -> dict[str, str]:
    """The non-internal members, from `stubs.md` - one row per program not in this MU.

    A neighbor or an absent module is not this MU's to document, so a citation of one
    is not a missing provenance document; it is a dependency the design registered and
    accounted for. Read from `stubs.md` rather than from a list of its own, because
    that file is where the design already has to name them, and two lists disagree.
    """
    if not path:
        return {}
    found: dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        if (m := STUB_ROW.match(raw.strip())):
            found[m.group("program")] = m.group("kind")
    if not found:
        print(f"{path}: no neighbor or absent rows found - every cited member that is "
              f"not in the index will be reported", file=sys.stderr)
    return found


def main() -> int:
    parser = argparse.ArgumentParser(
        description=__doc__.splitlines()[0],
        formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    parser.add_argument("--index", type=Path, required=True,
                        help="paragraph-index.json written by extract_logic.py --index")
    parser.add_argument("--java", type=Path, nargs="*", default=[],
                        help="one or more roots to scan for .java files. Omit it to "
                             "report the whole inventory with nothing cited, which is "
                             "the list to check a rule inventory against")
    parser.add_argument("--external", type=Path,
                        help="the MU's design/stubs.md: members cited from it are "
                             "neighbors or absent modules, not missing documents")
    parser.add_argument("--allow", type=Path,
                        help="reviewed exemptions: PROGRAM PARAGRAPH reason per line")
    parser.add_argument("--report", type=Path,
                        help="write a Markdown coverage report here")
    parser.add_argument("--json", type=Path, dest="as_json",
                        help="write the findings and the coverage as JSON here")
    parser.add_argument("--warn-only", action="store_true",
                        help="report and exit 0; for an MU part-way through implement")
    args = parser.parse_args()

    index = json.loads(args.index.read_text(encoding="utf-8"))["programs"]
    programs = set(index)
    known = {(p, para["name"]): para
             for p, entry in index.items() for para in entry["paragraphs"]}
    para_runs, id_lengths = shapes(index)
    allowed = load_allow(args.allow)
    external = load_external(args.external)

    # No `--java` at all is the design-phase run: report the inventory with nothing
    # cited. A root that was given and holds no `.java` is a wrong path, which is a
    # mistake worth stopping for rather than reporting as an MU with no citations.
    files = sorted({f for root in args.java for f in root.rglob("*.java")})
    if args.java and not files:
        sys.exit(f"no .java files under {', '.join(str(r) for r in args.java)}")

    findings: list[dict] = []
    cited: dict[tuple[str, str], list[str]] = defaultdict(list)
    outside: Counter = Counter()
    for path in files:
        where = path.as_posix()
        for line, text in comments(path.read_text(encoding="utf-8", errors="replace")):
            for cite in citations(text, programs, para_runs, id_lengths):
                at = f"{where}:{line}"
                name, program, span = cite["paragraph"], cite["program"], cite["range"]
                if program is not None and program not in programs:
                    if program in external:
                        outside[program] += 1
                        continue
                    findings.append(dict(kind="UNKNOWN_PROGRAM", at=at, program=program,
                                         paragraph=name,
                                         detail="no extracted-logic document for this "
                                                "member, and stubs.md does not register "
                                                "it as a neighbor or absent"))
                    continue
                if program is not None and (program, name) in known:
                    pass
                else:
                    elsewhere = sorted(p for (p, q) in known if q == name)
                    if not elsewhere:
                        findings.append(dict(kind="UNKNOWN_PARAGRAPH", at=at,
                                             program=program, paragraph=name,
                                             detail="in no extracted-logic document"))
                        continue
                    findings.append(dict(
                        kind="WRONG_PROGRAM" if program else "NO_PROGRAM", at=at,
                        program=program, paragraph=name,
                        detail="found under " + ", ".join(elsewhere)))
                    # Count it against the member it really belongs to: the citation
                    # is wrong about the program, not absent, and reporting the
                    # paragraph as uncited as well would say the same thing twice.
                    program = elsewhere[0]
                cited[(program, name)].append(at)
                want = known[(program, name)]["lines"]
                if span and want and span != want:
                    findings.append(dict(
                        kind="STALE_RANGE", at=at, program=program, paragraph=name,
                        detail=f"cited {span[0]}-{span[1]}, "
                               f"document says {want[0]}-{want[1]}"))

    business = [(p, para) for (p, para) in known.items()
                if para["kind"] == "business"]
    uncited = [(key, para) for key, para in business
               if not cited.get(key) and key not in allowed]
    for key, para in uncited:
        findings.append(dict(kind="UNCITED", at="-", program=key[0], paragraph=key[1],
                             detail=f"lines {para['lines'][0]}-{para['lines'][1]}, "
                                    f"{para['statements']} statements"))

    counts = Counter(f["kind"] for f in findings)
    covered = len(business) - len(uncited)
    print(f"{len(files)} Java files, {sum(len(v) for v in cited.values())} citations; "
          f"{len(known)} paragraphs, {len(business)} business, "
          f"{covered} cited or exempt ({covered * 100 // max(len(business), 1)}%)")
    if outside:
        print(f"  {sum(outside.values())} citations of "
              f"{len(outside)} non-internal members (stubs.md): "
              f"{', '.join(f'{p} {external[p]}' for p in sorted(outside))}")
    for kind in ("UNCITED", "UNKNOWN_PARAGRAPH", "WRONG_PROGRAM", "NO_PROGRAM",
                 "STALE_RANGE", "UNKNOWN_PROGRAM"):
        if counts[kind]:
            print(f"  {kind:18s} {counts[kind]}")

    order = {k: i for i, k in enumerate(
        ("STALE_RANGE", "WRONG_PROGRAM", "NO_PROGRAM", "UNKNOWN_PARAGRAPH",
         "UNKNOWN_PROGRAM", "UNCITED"))}
    findings.sort(key=lambda f: (order.get(f["kind"], 9), f["program"] or "",
                                 f["paragraph"]))
    for f in findings:
        print(f"{f['kind']}: {f['program'] or '(no member cited)'} {f['paragraph']}"
              f"  {f['detail']}" + (f"  at {f['at']}" if f["at"] != "-" else ""))

    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(
            report(index, known, cited, allowed, findings, files, external, outside),
            encoding="utf-8")
        print(f"wrote {args.report}", file=sys.stderr)
    if args.as_json:
        args.as_json.parent.mkdir(parents=True, exist_ok=True)
        args.as_json.write_text(json.dumps(dict(
            files=len(files), paragraphs=len(known), business=len(business),
            covered=covered, findings=findings, external=dict(outside),
            cited={f"{p} {q}": v for (p, q), v in sorted(cited.items())}),
            indent=1), encoding="utf-8")
        print(f"wrote {args.as_json}", file=sys.stderr)

    return 1 if findings and not args.warn_only else 0


def report(index: dict, known: dict, cited: dict, allowed: dict,
           findings: list[dict], files: list[Path],
           external: dict[str, str], outside: Counter) -> str:
    """A Markdown report: the summary first, then every paragraph per member."""
    business = [k for k, p in known.items() if p["kind"] == "business"]
    covered = [k for k in business if cited.get(k) or k in allowed]
    out = [
        "# Traceability - COBOL paragraphs against the Java that carries them", "",
        "Generated by `validate_traceability.py` from the paragraph index the "
        "`cobol-logic-extractor` wrote and the COBOL citations in the Java comments. "
        "Regenerate rather than edit.", "",
        f"- {len(index)} members, {len(known)} paragraphs, {len(business)} of them "
        f"business (mechanism paragraphs are exempt)",
        f"- {len(covered)} cited or exempt, {len(business) - len(covered)} not",
        f"- {len(files)} Java files scanned, "
        f"{sum(len(v) for v in cited.values())} citations",
        f"- {len(findings)} findings", "",
    ]
    if outside:
        out += [f"- {sum(outside.values())} citations of members `stubs.md` registers "
                f"as not this MU's: "
                + ", ".join(f"`{p}` {external[p]} ({outside[p]})"
                            for p in sorted(outside)), ""]
    if findings:
        out += ["## Findings", "", "| Finding | Member | Paragraph | Detail | Where |",
                "|---|---|---|---|---|"]
        out += [f"| {f['kind']} | {f['program'] or '—'} | `{f['paragraph']}` | "
                f"{f['detail']} | {f['at']} |" for f in findings]
        out += [""]
    out += ["## Per-member paragraphs", ""]
    for program, entry in index.items():
        paras = entry["paragraphs"]
        hit = sum(1 for p in paras
                  if p["kind"] == "business" and cited.get((program, p["name"])))
        out += [f"### {program} — {entry['model'] or '(no model name)'}", "",
                f"{len(paras)} paragraphs, {entry['business']} business, "
                f"{hit} cited.", "",
                "| Paragraph | Lines | Kind | Statements | Cited in Java |",
                "|---|---|---|---:|---|"]
        for p in paras:
            key = (program, p["name"])
            where = cited.get(key)
            if where:
                shown = ", ".join(f"`{w.rsplit('/', 1)[-1]}`" for w in where[:4])
            elif key in allowed:
                shown = f"exempt — {allowed[key]}"
            elif p["kind"] == "mechanism":
                shown = f"— ({p.get('why', 'mechanism')})"
            else:
                shown = "**not cited**"
            span = f"{p['lines'][0]}-{p['lines'][1]}" if p["lines"] else "—"
            out += [f"| `{p['name']}` | {span} | {p['kind']} | "
                    f"{p['statements']} | {shown} |"]
        out += [""]
    return "\n".join(out) + "\n"


if __name__ == "__main__":
    raise SystemExit(main())
