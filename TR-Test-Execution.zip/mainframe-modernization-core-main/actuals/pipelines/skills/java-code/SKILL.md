---
name: java-code
description: >
  Use every time Java code is written from a designed COBOL / CA Gen migration
  unit (mu-implement) — DAOs, services, controllers, DTOs, exceptions and tests.
  Also use when reviewing or correcting such Java code. Governs logic fidelity,
  Javadoc back-references, COBOL fixed-width field semantics (padding, trimming,
  truncation) and clean code that passes the Sonar way Java profile without
  blocker, critical or major issues.
user-invocable: false
---

# Java code

Seven rules, each applying to every class, method and field you write. The architecture
and persistence rules are `design.md`'s (written with `target-java-3tier`); where rule 4
or 6 and `design.md` differ, `design.md` wins.

**Hard rule: never read the COBOL** (`mu-implement`). "The COBOL" below means what `design/`
and `extracted-logic/` show of it.

## 1. Preserve the logic, not the structure

Reproduce **what** the COBOL decides, in the **order** it matters. Do not
reproduce **how** it is arranged.

Keep faithfully:
- every branch and its condition, including the ones that look redundant
- the outcome of each branch, including "end quietly as if successful"
- the order of operations wherever one step's result feeds the next
- boundary and error conditions, including which ones abort and which do not

Do not carry over:
- paragraph-per-step decomposition, `PERFORM THRU` chains, `GOBACK` placement
- escape flags, status flags, and state variables that exist only because COBOL
  has no exceptions and no early return
- generated CA Gen scaffolding: view-marshalling paragraphs, `MOVEA`/`MOVEB`
  pairs, cursor open/fetch/close paragraph triplets, `GLOBDATA` plumbing
- numbered names (`PARA-0670070638-FETCH`, `SL-0670070675`, `ACCTNG-DT-001EF`).
  No Java identifier carries a generated COBOL name or a legacy program id.

A COBOL check that is unreachable, or that validates nothing, is still a fact
about the source. Do not silently implement it as a real rule and do not
silently drop it — implement what the program actually does, and record the
discrepancy in Javadoc.

## 2. Javadoc, not `//`

Use Javadoc on every class, method, and non-obvious field. It survives into the
IDE and the generated docs, where the next person reading the migration needs it.

Reserve `//` for a genuinely local remark inside a method body — a single line
about the statement it sits above. Never use `//` to carry the COBOL
back-reference for a class, method or field; that belongs in Javadoc.

**Document the code as it stands, never the work that produced it.** The reader
is someone maintaining this class, not someone watching it being written. They
have no idea what an earlier draft looked like and cannot act on it.

So do not write:
- comments about what was removed, added, simplified, renamed, or "no longer"
  done — `No padding, and no trimming either`, `trim removed`, `now a plain
  record`, `moved out of here`
- migration-progress or status notes — `TODO: service layer next`, `first cut`,
  `will be replaced`, `aligned with the new rule`
- comments that answer a question only the author had — a defence of a choice
  nobody reading the code would have questioned
- a heading phrased as the absence of something, when the presence of something
  else is the real fact. If padding is DB2's job, say that; do not announce that
  this class does not pad.

Every **Differs from the COBOL** note under rule 3 is about the COBOL source, not
about a previous version of the Java. That distinction is the test: if the note
would still make sense to a reader who has never seen any other version of this
file, it belongs. If it only makes sense as a reaction to something that used to
be there, delete it.

A genuine gap in the implementation is not a comment — it is a Javadoc statement
of what the class does not do and why, or a question to the user.

## 3. Back-reference the COBOL, and state every difference

Every class and method Javadoc names the COBOL it came from, copied from the
`From` cells of the rules it carries (`rules.md`) - member, paragraph, line range:

```java
/**
 * Reads every billing ledger reconciliation row of the closing month.
 *
 * <p>From {@code P754957R} PARA-0670070710 (1081-1120).
 *
 * <p><b>Differs from the COBOL:</b> returns a {@code Stream} instead of an
 * open cursor with fetch-per-row paragraphs; the rows and their order are
 * unchanged.
 */
```

Citation rules:
- **No folder path**, and member and paragraph names exactly as the `From` cell
  writes them.
- **The line range is required, and it is copied, never recalled.** It comes from the
  `From` cell, which came from `extracted-logic/paragraph-index.json`. The range is the
  part of a citation nobody remembers and the part that goes stale silently, so it is
  checked against the index: a wrong one is a finding, and it sends the next reader to
  the wrong place, which is the single failure a citation exists to prevent.
- Several paragraphs of one member share the one `{@code …}` before them; a paragraph
  named with no member before it anywhere in the comment is a finding, because the
  reader of the delivered code has no index to recover it from.
- Cite every paragraph the method carries, not a representative one. "All of it is
  migrated" is checked by looking for paragraphs no comment names
  (`target-java-3tier`, *Checking that all of it is migrated*), so an uncited
  paragraph reads exactly like a behaviour that was dropped.

Every deviation gets an explicit **Differs from the COBOL** note saying what
changed and why (`design.md` "Differences from the original" lists them). Deviations that always need one:
- a framework feature replacing hand-written COBOL plumbing (exceptions for
  status flags, `@Transactional` for commit/rollback dispatch, retry policy for
  a re-execute loop, exit code for a return code)
- a DB2 `SQLCODE` check expressed as a translated exception
- anything intentionally not implemented, and anything added that the COBOL has
  no equivalent for
- a defect or oddity in the legacy behaviour that is being preserved

If you cannot cite a rule for a piece of logic, that logic is invented — see
rule 5.

## 4. Fixed-width fields: trim where padding can actually reach you

COBOL alphanumeric fields are fixed-width and **space-padded on the right**. A
`PIC X(4)` field holding `'A'` contains `'A   '`, and COBOL's comparison
`IF FIELD = 'A'` pads the literal to the field's width, so `'A'`, `'A '` and
`'A   '` are all equal. Java's `equals` does not. A DB2 `CHAR(n)` column is
padded the same way: `CHAR(3)` holding `'BSA'` is fine, but `CHAR(2)` holding
`'1'` reads back as `'1 '`.

**Strip trailing blanks at the point where a padded value enters Java, and
nowhere else** (`s.replaceAll(" +$", "")`, never `trim()`/`strip()`: a leading
blank is data - see `design.md`, Persistence). That point is:
- a value read from the database — `ResultSet` / row mapper / `queryFor…` on a
  `CHAR(n)` column
- a value parsed out of a fixed-format record — flat file, PDS member, copybook
  layout, `MOVE`-style redefines
- a value compared, matched, or used as a map or set key, if it could have
  arrived padded and has not been trimmed yet

Compare with `equals` on the trimmed value. Never mimic COBOL padding by padding
the Java literal.

**Do not add a trim where padding cannot arrive.** A value that came from an
already-trimmed Java object, was built in Java, or is only being written back to
the database needs no trim — DB2 re-pads a `CHAR(n)` column on insert anyway.
Trimming defensively, "in case", is noise that hides where the real boundary is;
trim once, at the boundary, and let the value travel trimmed after that.

Record the COBOL picture clause and the column type in the Javadoc of any field
that *is* trimmed — `PIC X(2)` / `CHAR(2)` — it is the reason the trim exists,
and without it someone will remove the trim as noise. Where a type deliberately
does **not** trim, say which boundary already did.

**Overflow is unaccounted for in COBOL.** A `MOVE` into a shorter alphanumeric
field silently truncates on the right; a numeric `MOVE` silently drops
high-order digits. The COBOL has no check and raises no error. Java does not
truncate, so an oversized value that the legacy program quietly cut will flow
through at full length and can reach the database as a length error or a wrong
value.

So for every value crossing into a narrower field: decide deliberately whether
to truncate as the COBOL did or to reject, write the decision in Javadoc with
the picture clause and the source line, and never let the difference go
unrecorded. Silent divergence here is the failure mode — not the choice itself.

## 5. Invent nothing

- Every rule, constant, table, column, code value, threshold and error path
  comes from `design/`, `unit/schema.sql`, the DDL, or the migration unit's own documents. If it is
  not there, it does not go in the code.
- Do not add validation, defaults, null handling, retries, logging of business
  values, or "obvious" missing checks that the COBOL does not have. A missing
  check is a question for the business, raised in Javadoc or to the user — not a
  silently added rule.
- Do not guess a column type, nullability, or key. Take it from `unit/schema.sql`,
  `dictionary.md` and `inputs/db-schema/`; one they do not give is a question with the
  value assumed.
- Do not invent line numbers or member names. Verify each citation against the
  `From` cells of `rules.md` before writing it.
- Follow the instructions given for the task exactly, and to their full scope.
  When something is genuinely ambiguous, decide, log the question with the
  assumption in `implement-open-questions.md`, and continue; never a silent assumption.

### Preservation beats sense

**Never change business logic to make it more sensible.** If the COBOL tests
`= SPACES` where `<> 'Y'` would be more useful, tests a condition that can never
be true, picks an arbitrary row where a deterministic one would be safer, or
carries a rule that looks like a bug — reproduce it exactly as it is. Migrating
it and improving it are two separate projects, and mixing them destroys the only
thing that makes the result verifiable: that a difference in output means a
migration defect, not a deliberate redesign.

An improvement you have spotted goes in Javadoc, or to the user, as a
question. It never goes in the code.

### What you may add freely

These have no COBOL counterpart and do not need one — they are target-platform
plumbing, not behaviour:

- **Timeouts, pool sizes, connection and framework configuration.** The COBOL
  had none because the mainframe supplied them elsewhere. Choose sensible values.
- **Logging.** There is no log compatibility to maintain. Log what makes the job
  operable - events, outcomes, error codes, keys - never business values (rule 5).
- **Prepared statements and bind parameters.** Binding a value rather than
  splicing it into SQL text is not a change to the statement.
- **Framework idiom** where rule 3 already covers it: exceptions for status
  flags, `@Transactional` for commit dispatch, a retry policy for a re-execute
  loop.

## 6. Preserve the SQL, do not improve it

Every SQL statement in the target starts as the COBOL's statement as `design.md`
gives it, kept as close to that text as the target platform allows. Traceability
is the point: a reviewer holding the design's statement beside the Java must be
able to see the same statement.

**Do not:**
- add a `WHERE` predicate the cursor does not have, even when the program
  obviously filters the rows afterwards
- add, remove or change `ORDER BY`
- add `FETCH FIRST n ROWS ONLY`, `OPTIMIZE FOR`, `WITH UR`, or any other clause
  the original does not have
- fold a multi-row cursor plus a COBOL test into a single-row query
- merge statements, split statements, or replace two cursors with one
- change a join, an aliasing, or a column list — including "unused" columns

**A test the COBOL performs after the fetch stays after the fetch,** in Java, on
the rows the unchanged statement returned. That is what keeps the two halves
traceable: the statement maps to the `EXEC SQL` block, the test maps to the
paragraph that tests it.

Permitted, because they change no row and no order:
- binding host variables as prepared-statement parameters
- dropping the generated table alias and DB2 schema qualifier when the original
  relies on `CURRENT SCHEMA`, noting it in Javadoc
- whitespace, case and formatting
- reading the result into a `List` or `Stream` instead of a cursor with
  fetch-per-row paragraphs

Cite the rule (`From` cell) in the Javadoc of whatever holds the Java version.
Where reading a whole result set replaces a cursor closed early at the first
match, say so as a **Differs from the COBOL** note.

## 7. Clean code: Sonar way, no blocker, critical or major

Generated code passes the default Sonar Java profile.

**Shape**
- Methods short, one job; cognitive complexity <= 15; <= 7 parameters (else a
  record); guard clauses; no nested ternaries.
- Constructor injection; `final` fields; records for DTOs and value objects;
  interface types (`List`, not `ArrayList`); no raw types.
- Utility classes `final` with a private constructor. No public mutable static state.
- No unused import, field, parameter or local; no dead store; no commented-out
  code; no `TODO`/`FIXME`.
- A literal repeated 3+ times is a constant. `equals` for strings and objects;
  `isEmpty()` not `size() == 0`; return the expression, not a temp.
- Names: `camelCase` methods and fields, `PascalCase` types, `UPPER_SNAKE` constants.

**Errors and resources**
- Throw the design's exceptions, never `Exception`/`RuntimeException`/`Throwable`;
  catch the narrowest type; keep the cause; log or rethrow, not both.
- No empty catch, method or block. Restore the interrupt flag on `InterruptedException`.
- `try-with-resources` for every `Connection`, `Statement`, `ResultSet` and resource `Stream`.
- No `null` for a collection; no `Optional` as a field or parameter; do not ignore
  a return value that signals failure.

**Logging and security**
- SLF4J, never `System.out` or `printStackTrace`; `log.info("x {}", v)`, not concatenation.
- No credentials, URLs, IPs or paths in code. SQL only with bound parameters.

**Tests**
- Every test asserts something; no `@Disabled`, no `Thread.sleep`, no logic in a test.
  Names say the rule and the outcome; one behaviour per test.

Before finishing a class, re-read it against this rule; build with no compiler warnings.
