# GenDates - the shared library

One final class, `<root>.gen.GenDates`, static methods only, no CA Gen types (no views,
return codes, `GLOBDATA`). It exists because these rules are easy to get subtly wrong and
are called from many places.

| Member | Replaces | Contract |
|---|---|---|
| `ZERO` | the zero date | `LocalDate.of(1, 1, 1)`; Db2 `'0001-01-01'`, view `0` |
| `MAX` | the max date | `LocalDate.of(9999, 12, 31)` |
| `fromNumber(int yyyymmdd)` | `TIRFNUMD` | `0` → `ZERO`, `99991231` → `MAX`, other valid → the date; invalid → `IllegalArgumentException` |
| `toNumber(LocalDate d)` | `TIRFDNUM` | `ZERO` or `null` → `0`, else `YYYYMMDD` as a number |
| `isValid(int yyyymmdd)` | `TIRDAT2` request 0 | `0` → `true` (a zero date is not validated); else a real calendar date |
| `parseText(String s)` | `TIRFDTEC` | `yyyy-mm-dd`, `mm/dd/yyyy`, `dd.mm.yyyy`, `yyyynnn`; unparseable → `ZERO` |
| `plus(LocalDate d, Integer years, Integer months, Integer days)` | `TIRFDDUR` | `null` = component missing; applied years, then months, then days |

Unit tests, one per row, plus: `fromNumber(20240230)` throws; `isValid(0)`;
`parseText("garbage")` is `ZERO`; `plus` across 29 February. Where a recording shows a
different value, the recording wins and the contract here is corrected.
