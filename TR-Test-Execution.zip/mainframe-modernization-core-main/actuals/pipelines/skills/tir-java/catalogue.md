# TIR modules → Java

`d` is a `LocalDate`, `t` a `LocalTime`, `ts` a `LocalDateTime`, `n` a `BigDecimal`,
`s` a `String`, `clock` the injected `Clock`.

## Dates and time

| Module | Resolution | Java |
|---|---|---|
| `TIRD2VW`, `TIRVW2D` | NONE | JDBC `LocalDate`; the zero date is `GenDates.ZERO`, Db2 NULL is `null` |
| `TIRS2VW`, `TIRVW2S` | NONE | JDBC `LocalDateTime` |
| `TIRDAT2` request 7 | INLINE | `LocalDateTime.now(clock)` |
| `TIRDAT2` request 0 | LIB | `GenDates.isValid(yyyymmdd)` |
| `TIRDAT2` requests 1-6 | INLINE | `LocalDate.now(clock)`, `d.plusDays(n)`, `DateTimeFormatter`; unused here - a case decides if met |
| `TIRFDAY`, `TIRFMTH`, `TIRFYEAR` | INLINE | `d.getDayOfMonth()`, `d.getMonthValue()`, `d.getYear()` |
| `TIRFHOUR`, `TIRFMIN`, `TIRFSEC` | INLINE | `t.getHour()`, `t.getMinute()`, `t.getSecond()` |
| `TIRFMICR` | INLINE | `(ts.getNano() / 10_000_000) * 10_000` - `TIRDAT2` stamps hold hundredths only |
| `TIRFDTEJ` | INLINE | `d.getYear() * 1000 + d.getDayOfYear()` |
| `TIRFDAYS` | INLINE | `ChronoUnit.DAYS.between(LocalDate.of(0, 12, 31), d)` |
| `TIRFDNUM` | LIB | `GenDates.toNumber(d)` |
| `TIRFNUMD` | LIB | `GenDates.fromNumber(yyyymmdd)` |
| `TIRFDTEC` | LIB | `GenDates.parseText(s)` |
| `TIRFDDUR` | LIB | `GenDates.plus(d, years, months, days)` |

## Numbers and strings

| Module | Resolution | Java |
|---|---|---|
| `TIRFCHR` | INLINE | `String.format("%015d", n.toBigInteger().abs())` |
| `TIRFNUM` | INLINE | `new BigDecimal(s.strip())`; callers handle blank first, as the COBOL does |
| `TIRFSSTR` | INLINE | `s.substring(start - 1, start - 1 + length)`; out of range throws, as the original fails |
| `TIRFTRIM` | INLINE | `s.replaceAll(" +$", "")`; the length is `.length()` |
| `TIRUPPR` | INLINE | `s.toUpperCase(Locale.ROOT)`; usually NONE - it serves the trancode dispatch |

## Services and harness - all NONE

| Module | Becomes |
|---|---|
| `TIRLGLOD` | a direct method call on an injected bean |
| `TIRFAIL` | a domain exception, mapped by the outcome table |
| `TIRMSG`, `TIRMTQB` | the error body's message text |
| `TIRSYSID`, `TIRUSRID` | a configuration property / the caller's identity - a question if a rule uses it |
| `TIRSECR`, `TIRSECW`, `TIRDCRYW` | framework security, or none by decision - a question |
| `TIRBTCH`, `TIRRETCD` | logging, or the batch framework's exit status in a batch target |
| `TIRTRCE` | logging |
| `TIRMOVEA`, `TIRMOVEP` | an assignment |
| `TIRPROF`, `TIRHSTG`, `TIRMMFN`, `TIRADDR`, `TIRSETA`, `TIRDLCT` | disappear |
| `TIRCFID`, `TIRCFIN`, `TIRCSRM`, `TIRLIPS`, `TIRERR`, `TIRPXMIT` | disappear - the archetype's entry layer is the wire format |
