---
name: tir-java
description: "TIR skill for a Java target: how each CA Gen TIR runtime call (`*> @function TIRxxxx`) is resolved in Java - not implemented at all, inline JDK code, or the shared GenDates library class. Use when designing (mu-design) or implementing (mu-implement) code that replaces a program calling TIR modules."
user-invocable: false
---

# TIR runtime calls in Java

What each module does is in the `tir-cobol` skill; that behaviour is what the
recordings show, so it is what Java must match. This skill says **how**. Never the COBOL.

## Three resolutions

| Resolution | Meaning |
|---|---|
| **NONE** | nothing to implement: the framework, JDBC, an injected bean or the target structure covers it, or the call disappears with the CA Gen harness |
| **INLINE** | a JDK expression at the call site, as `catalogue.md` gives it |
| **LIB** | a method of the shared `GenDates` class (`lib.md`) - only where repeating the rule inline is error-prone |

`catalogue.md` gives the resolution of every module. A module not in it is a question,
never an invented class.

## Rules

- **Dates are `LocalDate` / `LocalDateTime` end to end.** Read and bind them with
  `getObject(col, LocalDate.class)` / `setObject`, never `java.sql.Date`: its hybrid
  calendar can shift the year-1 and year-99 sentinels.
- **Sentinels live in `GenDates` only**: the zero date and the max date. Never a second
  `LocalDate.of(1, 1, 1)`.
- **One injected `Clock`** in an explicit zone. Where the original reads the clock more
  than once and the readings can differ observably, say so in `rules.md`.
- **Trim means trailing blanks only** (`TIRFTRIM`, `CHAR` padding): `replaceAll(" +$", "")`,
  the same rule the architecture skill applies at the DAO and request boundaries. Never
  `trim()` / `strip()` on business text.
- **Edge inputs are pinned by cases**, not decided: a zero, blank or invalid date or
  number reaching a TIR call gets a recorded case.

## In the design

`design.md`, section *Neighbors, stubs and the runtime*: one line per TIR module the MU
calls - module, resolution, and the Java from `catalogue.md`. LIB modules name the
`GenDates` method.

## In the implementation

INLINE code goes at the call site. `GenDates` (package `<root>.gen`) is used as it is
when the solution folder already has it. When it does not, this MU writes it into the
solution, exactly as `lib.md` specifies, with the unit tests listed there - and only the
members this MU calls are required. An MU never keeps a second copy.
