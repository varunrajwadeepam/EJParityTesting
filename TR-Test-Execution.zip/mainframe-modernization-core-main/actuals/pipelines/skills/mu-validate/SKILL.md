---
name: mu-validate
description: Validation phase of the COBOL migration - replays the test package of one Migration Unit against the Java product through the e2e framework, classifies every failure and names the next move.
argument-hint: "mu/<MU> [entry=<E>] [<instructions>]"
disable-model-invocation: true
---

# Validate one Migration Unit against its test package

Runs after `mu-build-tests` (package `ready`) and `mu-implement` (a product in `solution/`). Per
entry point: the package imported into framework assets, the golden masters accepted by a named
person, the product replayed twice from a snapshot, every failure classified. Result: runs, a
classified failure list, the report, the questions.

`<mu>` is the argument, normally `mu/<MU>`; layout in `${CLAUDE_PLUGIN_ROOT}/templates/workspace/CLAUDE.md`.
Run from the workspace root. `S` below is `python -B ${CLAUDE_PLUGIN_ROOT}/skills/mu-validate/scripts/mu_validate.py`.
Every step takes `<mu> [--entry E]`, prints one JSON object, exits 0 done, 2 decision or input
needed, 1 failed; `$S status <mu>` names the next step and why.

## Inputs, and nothing else

- `<mu>/mu.yaml`, `<mu>/tools.yaml` (via `${CLAUDE_PLUGIN_ROOT}/scripts/tools_config.py`; replay database
  `e2e-db2`, framework `e2e-framework.path`, default `tools/e2e-framework`).
- `<mu>/tests/` - `package/<E>/` (the package), `tests-state.json`, `tests-open-questions.md`.
- `<mu>/design/rules.md` (rule ids, `Target home`), `tests.md`; `<mu>/unit/schema.sql`.
- The product `solution/` (mu.yaml `solution`), read only, through its snapshot.

## Hard rules

- Never edit the package or anything under `<mu>/tests/`; a test problem ends with a `/pipelines:mu-build-tests` re-run.
- Never write `solution/`; a product problem goes to the implementer.
- Never answer an `RG-n` or a replay-schema `VQ`; never write an `Answer:` line.
- REPLAY only: RECORD and LIVE are not supported (the framework has them; this skill never triggers them).
- Never open COBOL or `inputs/cobol/`; scripts may hash unit sources; never read or print them.
- No MFLens, no parity tester runs.
- Test database: `e2e-db2` only (schema starts with `E2E`); never `DB2INST1`, never `GM_<MU>`.

## What to produce

| Artifact | Written by |
|---|---|
| `validation/` - test solution, `<mu>-e2e` module, `target/` (snapshots, private Maven repository) | `solution`, `snapshot`, `framework` |
| `<mu>/validation/e2e/` - scenarios, golden masters, view mappings, profiles, rules, feature, fixtures | `import`, `fixtures` |
| `<mu>/validation/runs/<run-id>/` - framework reports per run, `summary.json` | `execute` |
| `<mu>/validation/.tmp/analysis.json`, `failures-draft.md` | `analyse` |
| `<mu>/validation/failures.md` - one class per failure | you, from the draft |
| `<mu>/validation/validation-report.md` | `report` |
| `<mu>/validation/validation-open-questions.md` - `VQ-n`, record gate `RG-n` | `gate`; you through `questions add` |
| `<mu>/validation/validation-state.json` | every step |

## Order of work

0. **Preflight.** `$S preflight <mu>`. Exit 1: hard block, stop and say what is missing. Exit 2
   `schema-conflict`: add the returned VQ (`$S questions <mu> add ... --step preflight --blocking yes`)
   and stop. On resume, read its `Answer:` and run `$S preflight <mu> --e2e-schema <NAME>` yourself. A schema named with
   `--e2e-schema` is the owner's choice: its rows are a warning, never a stop. Tables with rows in
   `e2e-db2` are a warning: repeat it in the summary.
1. **Readiness.** `$S readiness <mu>`. Exit 2: `$S report <mu>` (its "Do this first" lists the
   `/pipelines:mu-build-tests` commands), show it and stop.
2. **Framework.** `$S framework <mu>`.
3. **Snapshot.** `$S snapshot <mu>` (reused while the solution's content hash is unchanged).
   `--solution DIR` takes another product folder (a seeded copy) and is kept until `--solution mu.yaml`.
4. **Test solution.** `$S solution <mu>`. Review the derived product facts (main class, base
   package, datasource keys, security): a wrong one is a VQ.
5. **Import.** `$S import <mu>`. Each `warnings` line that drops a field or shows schema drift is a
   non-blocking VQ.
6. **Fixtures.** `$S fixtures <mu>`.
7. **Lint.** `$S lint <mu>` (ER-1 on the module with its assets). Exit 2: run the step it names.
   Exit 1: show the log tail and stop.
8. **Record gate.** `$S gate <mu> prepare`. Exit 2 `gate-open`: show the `RG-n` (file, count, the
   decided answers ◆, the answer form) and stop. Exit 2 `gate-answered` (on resume or a new run): run `$S gate <mu> apply`
   yourself and go on; exit 2 `GATE_ANSWER_REFUSED` or `RECORD_GATE_REJECTED`: show why and stop.
9. **Execute.** `$S execute <mu>` (two runs, compared; counts per scenario). Exit 2:
   `DATABASE_DOWN`: say to start the parity Db2 and stop; `RECORD_GATE_OPEN` (no golden master
   accepted): back to stage 8; "run framework / snapshot / solution / import / fixtures / preflight"
   (not installed, snapshot not current, no module, nothing imported, no fixtures, no `e2e-db2`): run
   that step, then execute again. Exit 1 `NOT_REPEATABLE`: still analyse, name the scenarios that
   differ. Exit 1 `REPLAY_BUILD_FAILED` / `E2E_REPORT_MISSING`: show the log tail and stop.
10. **Failure analysis.** `$S analyse <mu> [--run <run-id>]`. Read `.tmp/analysis.json` (one
   failure per scenario, its failing levels merged); per failure confirm or change the pre-class
   (below), copy `.tmp/failures-draft.md` to `failures.md` and edit the `Class:` / `Confidence:`
   lines; a changed class gets a `Changed: <evidence>` line. One VQ per BINDING (the field or mapping named) and per UNKNOWN.
11. **Report.** `$S report <mu>`. Print a short summary: counts (PASSED as the legacy and ◆ as decided),
   classes, questions, the next move;
   the run's snapshot and package, and say so when the report warns they are not current.

## Classes

| Class | When | Next move |
|---|---|---|
| BINDING | the request does not reach the code as meant: no mapping, 405, 415, 400 on shape, a request field the DTO lacks, an answer field the response lacks, many cases of one operation alike | `/pipelines:mu-build-tests <mu> entry=<E>` (binding) |
| SOLUTION | the request is accepted and the status, answer or rows differ; siblings of a rule pass; a status no handler produces; a decided answer not implemented; a 5xx thrown by service code (wins over BINDING) | the implementer: rule and `Target home` |
| ENVIRONMENT | connection, schema, rights; SKIPPED (a register scenario missing from the report included) | fix the environment, `execute` |
| PACKAGE | BLOCKED (golden master not accepted), package not ready | `/pipelines:mu-build-tests` or the gate |
| DECISION | the answer is the decided answer, or every differing path is one the case or decision does not compare (`compare: ignore`, decided `tables: notCompared`); a divergence or hypothesis naming a field is a hint, never the class | none |
| UNKNOWN | no signal decides | a VQ |

Confirm a class from the evidence only: the request against the snapshot's controller and DTOs,
the difference, the exception, the siblings, the rules' text. Read the snapshot's Java when the
signals disagree; never the COBOL. Confidence `high` needs one decisive signal.

## Re-runs

Every step redoes only what changed: a new package version re-imports (acceptance kept for
unchanged golden masters, changed ones back to the gate); a changed solution gives a new snapshot
and `solution`; an unchanged state skips the step (`$S status <mu>`). The state records the
snapshot and package each step and run used: another snapshot makes solution, lint, execute,
analyse and report stale; another package import, fixtures, lint, execute, analyse and report.
After a fix elsewhere (`/pipelines:mu-build-tests`, the implementer, the environment) start at stage 0 again.

## Questions

`$S questions <mu> add --title .. --question .. --decision .. --affects .. --step <n>
--blocking yes|no` (`yes`: the replay cannot go on without it). Never edit an entry; the scripts
settle the ones they resolve.

## Rules

- Do not stop to ask. Everything short of a stop above is a question with the decision taken.
- The user only fills `Answer:` lines and says "resume" (or runs `/pipelines:mu-validate` again). Never ask the user
  to run a script or a command line; at a stop, say which file and line to answer, then "resume".
- Deterministic work is a script; your own go to `<mu>/validation/.tmp/` (`python -B`).
- Write only into `<mu>/validation/` and `validation/`.
