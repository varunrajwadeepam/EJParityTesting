# validation-report.md - {{mu}} / {{entry}}

{{date}} · package v{{version}} `{{contentHash}}` ({{packageState}}) · snapshot `{{snapshot}}` ({{solution}}) · framework `{{framework}}` · e2e-db2 `{{schema}}` · gate {{gate}}

{{doFirst}}

## Runs

| run | finished | runs | PASSED | FAILED | BLOCKED | NOT_APPLICABLE | SKIPPED | strict | contract | repeatable | identical to previous |
|---|---|---|---|---|---|---|---|---|---|---|---|
{{runs}}

PASSED counts as the legacy and as decided (◆: a decided answer, an accepted deviation, never equal to the legacy).

{{decided}}

## Failures of run {{lastRun}}

{{runOf}}

{{classes}}

## Warnings

{{warnings}}

## Questions

Open {{qOpen}} (blocking {{qBlocking}}) · answered {{qAnswered}} · settled {{qSettled}}

## Next

{{next}}
