package {{package}};

import org.springframework.boot.json.JsonParserFactory;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * How {{muName}}'s application ({{mainClass}}) is composed for validation.
 *
 * <p>Written by mu-validate's solution step. The validation profile {@code e2e} (see {@code application-e2e.yml}) takes
 * the database only from the generic E2E variables.
 */
public final class ValidationEnvironment {

    /** The Spring profile of the validation environment. */
    public static final String PROFILE = "e2e";

    /** The environment variables of the validation database. */
    public static final String DB_URL = "E2E_DB_URL";
    public static final String DB_USER = "E2E_DB_USER";
    public static final String DB_PASSWORD = "E2E_DB_PASSWORD";
    public static final String DB_SCHEMA = "E2E_DB_SCHEMA";

    /** The run-level properties of the booted application: one JSON object. */
    public static final String TARGET_PROPERTIES = "E2E_TARGET_PROPERTIES";

    private static final Pattern HOST_PORT = Pattern.compile("//([^:/;?]+)(?::(\\d+))?");

    private ValidationEnvironment() {
    }

    /**
     * The run-level properties of the validation run (e.g. a product switch that turns its security off) - every boot
     * of the application under validation applies them, the scenario targets as well as the smoke test. Empty when
     * none are set.
     */
    public static Map<String, Object> targetProperties() {
        return targetProperties(System.getenv(TARGET_PROPERTIES));
    }

    static Map<String, Object> targetProperties(String json) {
        return json == null || json.isBlank() ? Map.of() : JsonParserFactory.getJsonParser().parseMap(json);
    }

    /**
     * {@code true} when the validation database is configured and answers on its host and port - the condition for
     * booting the application in a test; otherwise such tests are skipped, never failed.
     */
    public static boolean validationDatabaseConfigured() {
        return validationDatabaseConfigured(System.getenv(), 2000);
    }

    static boolean validationDatabaseConfigured(Map<String, String> env, int timeoutMillis) {
        for (String name : new String[] {DB_URL, DB_USER, DB_PASSWORD, DB_SCHEMA}) {
            String value = env.get(name);
            if (value == null || value.isBlank()) {
                return false;
            }
        }
        Matcher m = HOST_PORT.matcher(env.get(DB_URL));
        if (!m.find()) {
            return false;
        }
        int port = m.group(2) == null ? 50000 : Integer.parseInt(m.group(2));
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(m.group(1), port), timeoutMillis);
            return true;
        } catch (IOException e) {
            return false;
        }
    }
}
