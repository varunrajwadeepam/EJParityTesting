package {{package}};

import com.insurance.e2e.core.junit.E2eScenarioTests;
import org.junit.jupiter.api.DynamicNode;
import org.junit.jupiter.api.TestFactory;

import java.util.stream.Stream;

/**
 * Register-driven lint of {{muName}}: one dynamic container per scenario, one test per comparison level, from the
 * classpath's e2e/ (the MU's derived test assets: scenarios, view mappings, profiles, fixtures, golden masters) -
 * plugins, mappings and golden masters in place, seals intact, every register scenario covered by exactly one feature
 * scenario. It lints in every mode; the scenarios execute as the Behaviour Specification ({{prefix}}BehaviourSuite).
 *
 * <p>Selection from -De2e.scenarios (ids) and -De2e.tags, e.g. "category:Edge &amp; !clock-sensitive". Written by
 * mu-validate's solution step - do not edit: the assets are the content.
 */
class {{prefix}}ParityTest {

    @TestFactory
    Stream<DynamicNode> scenarios() {
        return E2eScenarioTests.forModule("e2e").dynamicTests();
    }
}
