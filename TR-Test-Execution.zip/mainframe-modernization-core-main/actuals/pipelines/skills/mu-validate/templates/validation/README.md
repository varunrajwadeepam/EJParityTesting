# {{appId}} test solution (mu-validate)

Written once by mu-validate's solution step; one `<mu>-e2e` module per MU is added by it. The product
(`../{{solutionDir}}`) never depends on anything here, and nothing here writes the product.

| Module | Purpose |
|---|---|
| `{{appId}}-e2e-parent` | the product's Spring Boot version, the framework BOM, Cucumber, surefire includes, enforcer rules, the profile `e2e-replay` |
| `<mu>-e2e` | one per MU: boots the product's application with the validation profile `e2e`; the register lint (`*ParityTest`), the Behaviour Specification (`*BehaviourSuite`), the smoke test |

Each MU module holds no cases. It reads its test assets (scenario register, golden masters, view mappings, comparison
profile, rules, features, fixture packs) from `mu/<MU>/validation/e2e/` (module property `e2e.assets.dir`), mapped onto
the test classpath as `e2e/`. That folder is derived: `mu_validate.py import` and `fixtures` regenerate it from the
MU's test package; the acceptance of the golden masters is kept in `mu/<MU>/validation/validation-state.json` and
re-applied by every import.

## Run modes

**REPLAY only.** mu-validate runs the replay: the migrated application against the accepted golden masters, on the
fixture rows. The framework also has RECORD and LIVE modes and the `legacy-paritytester` binding; here the binding is
on the test classpath only so that the lint resolves the legacy side of each level. It is never triggered, there is no
`e2e-record` or `e2e-live` profile and no parity-tester setting. Recording is the job of `mu-build-tests`.

| Profile | What runs | Needs |
|---|---|---|
| *(default)* | the lint: register, golden-master seals, mappings, the features linted against the register; the smoke test skips without a database | the derived assets |
| `e2e-replay` | the features executed against the product snapshot | the replay database (`tools.yaml` `e2e-db2`, passed as `E2E_DB_*`) |

## Build

Every build uses the private repository `target/m2/` (framework and product snapshot), `~/.m2` a read-only tail:

```text
mvn verify -pl <mu>-e2e -am -Dmaven.repo.local=target/m2 -Dmaven.repo.local.tail=<home>/.m2/repository
```

Run it through `mu_validate.py` (`solution` for the lint, `execute` for the replay), which sets the environment.

## Ownership

- mu-validate writes the `<mu>-e2e` modules and the module lines; it re-aligns the parent's product pins (Spring Boot
  version, `e2e.product.version`) when the product moves and only reports any other drift.
- `target/` is never committed.
