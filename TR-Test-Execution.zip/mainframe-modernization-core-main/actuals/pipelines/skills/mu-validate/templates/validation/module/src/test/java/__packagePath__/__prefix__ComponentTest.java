package {{package}};

import com.insurance.e2e.core.junit.E2eScenarioTests;
import com.insurance.e2e.core.run.E2eMode;
import java.util.stream.Stream;
import org.junit.jupiter.api.DynamicNode;
import org.junit.jupiter.api.TestFactory;

/**
 * The component-lens cases of {{muName}} (classpath e2e-component/): a Spring bean of the product called inside the
 * booted application, compared with its golden master. The framework's Cucumber steps know only the HTTP call, so
 * these run register-driven in the mode of -De2e.mode. No test package publishes component cases yet (component
 * binding: step-3 F1); without the e2e-component/ assets this class contributes no test.
 *
 * <p>Written by mu-validate's solution step - do not edit.
 */
class {{prefix}}ComponentTest {

    static final String ROOT = "e2e-component";

    @TestFactory
    Stream<DynamicNode> components() {
        if (Thread.currentThread().getContextClassLoader().getResource(ROOT + "/scenarios") == null) {
            return Stream.empty();
        }
        E2eMode mode = E2eMode.parse(System.getProperty(E2eMode.PROPERTY, "lint"));
        return E2eScenarioTests.forModule(ROOT).mode(mode).dynamicTests();
    }
}
