package {{package}};

import org.junit.platform.suite.api.ConfigurationParameter;
import org.junit.platform.suite.api.IncludeEngines;
import org.junit.platform.suite.api.SelectClasspathResource;
import org.junit.platform.suite.api.Suite;

import static io.cucumber.junit.platform.engine.Constants.GLUE_PROPERTY_NAME;
import static io.cucumber.junit.platform.engine.Constants.PLUGIN_PROPERTY_NAME;

/**
 * The Behaviour Specification of {{muName}}: the features under the classpath's e2e/features (generated from the test
 * package by mu_validate.py import), executed through the framework's generic steps in the run mode of -De2e.mode
 * (profile e2e-replay) and only linted in the default profile. Selection: -De2e.scenarios and -De2e.tags. An empty
 * suite passes.
 *
 * <p>The Cucumber report is the run mode's (the framework's BehaviourReports): target/cucumber/{{module}}.html / .json
 * in replay, none in lint - a lint never replaces a replay's report.
 *
 * <p>Written by mu-validate's solution step - do not edit.
 */
@Suite(failIfNoTests = false)
@IncludeEngines("cucumber")
@SelectClasspathResource("e2e/features")
@ConfigurationParameter(key = GLUE_PROPERTY_NAME, value = "com.insurance.e2e.cucumber.glue")
@ConfigurationParameter(key = PLUGIN_PROPERTY_NAME,
        value = "pretty,com.insurance.e2e.cucumber.BehaviourReports:{{module}}")
class {{prefix}}BehaviourSuite {
}
