package {{package}};

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIf;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import javax.sql.DataSource;
import java.sql.Connection;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Boots {{muName}}'s application class with the validation profile and the run-level properties
 * (E2E_TARGET_PROPERTIES, as every validation boot of it) - the composition check. Runs only when the validation
 * database is configured and reachable (E2E_DB_*); skipped otherwise.
 *
 * <p>Written by mu-validate's solution step.
 */
@EnabledIf("{{package}}.ValidationEnvironment#validationDatabaseConfigured")
@SpringBootTest(classes = {{mainClass}}.class)
@ActiveProfiles(ValidationEnvironment.PROFILE)
class {{prefix}}ApplicationSmokeTest {

    @DynamicPropertySource
    static void validationRunProperties(DynamicPropertyRegistry registry) {
        ValidationEnvironment.targetProperties().forEach((name, value) -> registry.add(name, () -> value));
    }

    @Autowired
    private ApplicationContext context;

    @Test
    void theApplicationBootsAgainstTheValidationDatabase() throws Exception {
        assertThat(context.getBean({{mainClass}}.class)).isNotNull();
        DataSource dataSource = context.getBean(DataSource.class);
        try (Connection connection = dataSource.getConnection()) {
            assertThat(connection.isValid(5)).isTrue();
        }
    }
}
