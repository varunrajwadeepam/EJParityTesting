# failures.md - {{mu}} / {{entry}}

Run {{runId}} · snapshot {{snapshot}} · {{date}} · evidence `{{analysis}}`

Failed {{failed}} · blocked {{blocked}} · skipped {{skipped}} · classes: {{classCounts}}

## Not compared

{{apart}}

<!-- failure -->
## {{id}} - {{name}}

Class: {{class}} · Confidence: {{confidence}} · Pre-class: {{preClass}}
Operation: {{operation}} · HTTP expected {{expected}}, actual {{actual}}
Rules: {{rules}}
Suspect rules: {{suspects}}
Why: {{why}}
Fields: {{fields}}
Difference: {{diff}}
Exception: {{exception}}
Signals: {{signals}}
Hints: {{hints}}
Next: {{next}}

<!-- /failure -->
