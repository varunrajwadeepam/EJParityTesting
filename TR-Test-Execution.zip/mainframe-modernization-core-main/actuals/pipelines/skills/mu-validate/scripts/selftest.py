#!/usr/bin/env python3
"""Offline self-test of mu-validate (no Maven, no Db2): a throw-away workspace, stand-ins for docker and
mvn (MU_VALIDATE_CONTAINER_CLI, MU_VALIDATE_MVN), every step through mu_validate.py.

    python -B ${CLAUDE_PLUGIN_ROOT}/skills/mu-validate/scripts/selftest.py [--keep]
"""

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import textwrap
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
RUNNER = HERE / 'mu_validate.py'
sys.path.insert(0, str(HERE))

from vlib.common import canonical, content_hash, file_sha, sha256, slash_command  # noqa: E402

FAKE_DOCKER = r'''
import json, os, re, sys
sql = sys.stdin.buffer.read().decode('utf-8')
if os.environ.get('FAKE_DB2_DOWN'):
    print('SQL30081N  A communication error has been detected.'); sys.exit(8)
db = json.load(open(os.environ['FAKE_DB2'], encoding='utf-8'))
with open(os.environ['FAKE_DB2'] + '.log', 'a', encoding='utf-8') as fh:
    fh.write(sql.replace('\n', ' ') + '\n')
for bad in ('delete ', 'drop ', 'create ', 'insert ', 'update ', 'truncate '):
    if bad in sql.lower():
        print('SQL0000N refused by the fake: ' + bad); sys.exit(8)
print('   Database Connection Information\n\n Local database alias   = TESTDB\n')
if 'syscat.schemata' in sql:
    like = re.search(r"like '([^']*)'", sql).group(1)
    rx = re.compile('^' + re.escape(like).replace('%', '.*').replace('_', '.') + '$')
    for s in sorted(db):
        if rx.match(s):
            print('S|' + s)
elif 'syscat.tables' in sql:
    s = re.search(r"tabschema = '([^']*)'", sql).group(1)
    for t in sorted(db.get(s, {})):
        print('T|' + t)
elif 'count(*)' in sql:
    for t, s in re.findall(r"'C\|([A-Z0-9_]+)\|' \|\| rtrim\(char\(count\(\*\)\)\) from \"([A-Z0-9_]+)\"", sql):
        print('C|%s|%d' % (t, db[s][t]))
'''

FAKE_MVN = r'''
import os, re, sys
args = sys.argv[1:]
if '-v' in args:
    print('Apache Maven 3.9.9 (fake)\nJava version: 21.0.3, vendor: fake'); sys.exit(0)
with open(os.environ['FAKE_MVN_LOG'], 'a', encoding='utf-8') as fh:
    fh.write(' '.join(args) + '\n')
if os.environ.get('FAKE_MVN_FAIL'):
    print('[ERROR] BUILD FAILURE'); sys.exit(1)
head = next(a.split('=', 1)[1] for a in args if a.startswith('-Dmaven.repo.local='))
pom = args[args.index('-f') + 1]
root = os.path.dirname(pom)
if '-Pe2e-replay' in args or any(a.startswith('-Dtest=') for a in args):
    import json, shutil
    with open(os.environ['FAKE_MVN_LOG'] + '.env', 'a', encoding='utf-8') as fh:
        fh.write(json.dumps({k: v for k, v in os.environ.items() if k.startswith('E2E_')}) + '\n')
    module = os.path.join(root, args[args.index('-pl') + 1], 'target')
    test = next((a.split('=', 1)[1] for a in args if a.startswith('-Dtest=')), None)
    if test:
        os.makedirs(os.path.join(module, 'surefire-reports'), exist_ok=True)
        open(os.path.join(module, 'surefire-reports', 'TEST-x.%s.xml' % test), 'w').write(
            '<testsuite name="x.%s" tests="1" failures="0" errors="0" skipped="0"/>' % test)
    else:
        seq = json.loads(os.environ.get('FAKE_REPLAY') or '[]')
        counter = os.environ['FAKE_MVN_LOG'] + '.n'
        n = int(open(counter).read()) if os.path.isfile(counter) else 0
        open(counter, 'w').write(str(n + 1))
        if n < len(seq) and seq[n]:
            os.makedirs(os.path.join(module, 'e2e-reports'), exist_ok=True)
            shutil.copy(seq[n], os.path.join(module, 'e2e-reports', 'e2e-replay.json'))
        if os.environ.get('FAKE_MVN_OUT'):
            print(open(os.environ['FAKE_MVN_OUT'], encoding='utf-8').read())
    print('[INFO] BUILD SUCCESS'); sys.exit(0)
if os.path.isfile(os.path.join(root, 'core', 'pom.xml')):
    v = re.search(r'<version>([^<]+)</version>', open(pom, encoding='utf-8').read()).group(1)
    arts = [('com/insurance/e2e', a, e) for a, e in (('modernization-e2e-framework', 'pom'),
            ('modernization-e2e-bom', 'pom'), ('modernization-e2e-core', 'jar'),
            ('modernization-e2e-legacy-paritytester', 'jar'), ('modernization-e2e-target-spring', 'jar'),
            ('modernization-e2e-target-http', 'jar'), ('modernization-e2e-fixtures-jdbc', 'jar'),
            ('modernization-e2e-cucumber', 'jar'))] + [('com/insurance/archetypes', a, 'jar') for a in
            ('modernization-e2e-basement-archetype', 'modernization-mu-e2e-archetype')]
    for g, a, e in arts:
        d = os.path.join(head, g, a, v); os.makedirs(d, exist_ok=True)
        open(os.path.join(d, '%s-%s.%s' % (a, v, e)), 'w').write('x')
else:
    d = os.path.join(root, 'app', 'target'); os.makedirs(d, exist_ok=True)
    open(os.path.join(d, 'app-1.0.jar'), 'wb').write(b'jar')
print('[INFO] BUILD SUCCESS')
'''

# canned excerpts of real replay build logs (p510): seed run 20261106T123529Z (TC-P510-060 lost to a Db2 read
# timeout before its verdict), live run 20261106T123429Z (TC-P510-043, a 500 thrown by the service), seed run
# 20261106T123929Z (TC-P510-007, a business exception logged without a stack)
LOG_LOST = '''\
Scenario: {sid} add-details-blank-lines                                  # e2e/features/P7549510.feature:63
  When the client sends POST /wip                                              # com.insurance.e2e.cucumber.glue.E2eSteps.sends(java.lang.String,java.lang.String)
      com.insurance.e2e.core.E2eException: Cannot load fixture P7549510/profiles: [jcc][t4][2030][11211][4.37.4] A communication error occurred during operations on the connection's underlying socket, socket input stream,
      or socket output stream.  Error location: Reply.fill() - socketInputStream.read (-1).  Message: Read timed out. ERRORCODE=-4499, SQLSTATE=08001
      \tat com.insurance.e2e.fixtures.jdbc.JdbcEnvironmentPlugin.prepare(JdbcEnvironmentPlugin.java:116)
[ERROR] Tests run: 90, Failures: 54, Errors: 1, Skipped: 4, Time elapsed: 74.00 s <<< FAILURE! -- in e2e.com.travelers.bi.revdb.revol.p510.P510BehaviourSuite
[ERROR] e2e.com.travelers.bi.revdb.revol.p510.P510BehaviourSuite.{sid} add-details-blank-lines -- Time elapsed: 8.612 s <<< ERROR!
com.insurance.e2e.core.E2eException:
Cannot load fixture P7549510/profiles: [jcc][t4][2030][11211][4.37.4] A communication error occurred during operations on the connection's underlying socket, socket input stream,
or socket output stream.  Error location: Reply.fill() - socketInputStream.read (-1).  Message: Read timed out. ERRORCODE=-4499, SQLSTATE=08001
\tat com.insurance.e2e.fixtures.jdbc.JdbcEnvironmentPlugin.prepare(JdbcEnvironmentPlugin.java:116)
\tat com.insurance.e2e.core.run.ScenarioRunner.prepareFixture(ScenarioRunner.java:330)
Caused by: java.sql.SQLTimeoutException: [jcc][t4][2030][11211][4.37.4] A communication error occurred during operations on the connection's underlying socket, socket input stream,
or socket output stream.  Error location: Reply.fill() - socketInputStream.read (-1).  Message: Read timed out. ERRORCODE=-4499, SQLSTATE=08001
\tat com.ibm.db2.jcc.t4.a.a(a.java:592)
[INFO]
'''
LOG_THROWN = '''\
Scenario: {sid} add-pif-seq-negative                                     # e2e/features/P7549510.feature:6775
  Given the fixture pack "P7549510/profiles" and the clock 2024-08-16 10:30:00 # com.insurance.e2e.cucumber.glue.E2eSteps.fixtureAndClock(java.lang.String,java.lang.String)
APP 15:35:30.440 ERROR c.t.b.r.revol.web.ApiExceptionHandler - Processing failed: PIF change sequence is not a number
com.travelers.bi.revdb.revol.exception.ProcessingFailedException: PIF change sequence is not a number
\tat com.travelers.bi.revdb.revol.service.WipService.pifChangeSequence(WipService.java:233)
\tat com.travelers.bi.revdb.revol.service.WipService.doCreate(WipService.java:198)
\tat com.travelers.bi.revdb.revol.service.WipService.create(WipService.java:120)
\tat java.base/java.lang.reflect.Method.invoke(Method.java:580)
\tat com.travelers.bi.revdb.revol.service.WipService$$SpringCGLIB$$0.create(<generated>)
\tat com.travelers.bi.revdb.revol.web.WipController.create(WipController.java:65)
  Then the answer matches the accepted golden master "{sid}"             # com.insurance.e2e.cucumber.glue.E2eSteps.matches(java.lang.String)
      java.lang.AssertionError: {sid} L4 FAILED: DIFF under contract: 5 difference(s): $outcome OUTCOME_KIND legacy='OK' target='TECHNICAL_FAILURE'
      \tat com.insurance.e2e.cucumber.glue.E2eSteps.verdict(E2eSteps.java:396)
Scenario: {sid2} add-be-exists                                                # e2e/features/P7549510.feature:11013
APP 15:40:16.341 WARN  c.t.b.r.revol.web.ApiExceptionHandler - Already exists: WIP business event already exists
  When the client sends POST /wip                                                  # com.insurance.e2e.cucumber.glue.E2eSteps.sends(java.lang.String,java.lang.String)
'''

TOOLS = '''\
# tools.yaml of the self-test MU. Comments must survive the append.
secrets: ~/.config/mu-tools/none.env

db2:                                      # the parity Db2
  kind: local
  container: fake-db2                     # -> RUN_COBOL_DB2_CONTAINER
  database: TESTDB
  port: 50000
  user: db2inst1
  password: testenv                       # local only
  schema: DB2INST1

test-db2:                                 # mu-implement's test database
  kind: local
  host: localhost
  port: 50000
  database: TESTDB
  schema: DB2INST1
  user: db2inst1
  password: testenv

golden-db2:
  kind: local
  container: fake-db2
  database: TESTDB
  schema: GM_T1
  user: db2inst1
  password: testenv
# trailing comment line'''


class T:
    def __init__(self, keep):
        self.keep = keep
        self.ws = Path(tempfile.mkdtemp(prefix='muv-selftest-'))
        self.fails, self.n = [], 0
        self.mu = self.ws / 'mu' / 't1'
        bin_dir = self.ws / '_bin'
        bin_dir.mkdir()
        (bin_dir / 'docker.py').write_text(FAKE_DOCKER, encoding='utf-8')
        (bin_dir / 'mvn.py').write_text(FAKE_MVN, encoding='utf-8')
        self.db_file = bin_dir / 'db.json'
        self.mvn_log = bin_dir / 'mvn.log'
        self.env = dict(os.environ)
        self.env.update({'MU_VALIDATE_CONTAINER_CLI': json.dumps([sys.executable, '-B', str(bin_dir / 'docker.py')]),
                         'MU_VALIDATE_MVN': json.dumps([sys.executable, '-B', str(bin_dir / 'mvn.py')]),
                         'MU_VALIDATE_M2_TAIL': str(self.ws / '_home_m2'),
                         'FAKE_DB2': str(self.db_file), 'FAKE_MVN_LOG': str(self.mvn_log),
                         'PYTHONDONTWRITEBYTECODE': '1'})
        self.env.pop('FAKE_DB2_DOWN', None)
        self.env.pop('FAKE_MVN_FAIL', None)

    # ---------------------------------------------------------------- helpers
    def check(self, cond, what):
        self.n += 1
        if not cond:
            self.fails.append(what)
            print(f'FAIL {what}', file=sys.stderr)

    def w(self, rel, text):
        p = self.ws / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, 'w', encoding='utf-8', newline='\n') as fh:
            fh.write(text)
        return p

    def db(self, schemas):
        self.db_file.write_text(json.dumps(schemas), encoding='utf-8')

    def mvn_calls(self):
        return len(self.mvn_log.read_text(encoding='utf-8').splitlines()) if self.mvn_log.is_file() else 0

    def run(self, *args, env=None):
        e = dict(self.env)
        e.update(env or {})
        p = subprocess.run([sys.executable, '-B', str(RUNNER), *args], cwd=self.ws, env=e, capture_output=True,
                           encoding='utf-8', errors='replace')
        lines = [x for x in (p.stdout or '').splitlines() if x.strip()]
        try:
            doc = json.loads(lines[-1]) if lines else {}
        except ValueError:
            doc = {'_raw': p.stdout}
        if len(lines) != 1:
            self.check(False, f'{args}: expected one JSON line, got {len(lines)}: {p.stderr[-500:]}')
        return p.returncode, doc

    # ---------------------------------------------------------------- fixture workspace
    def package(self):
        doc = {'package': {'schema': 'mu-build-tests/tests.schema.json', 'format': 3, 'version': 1},
               'unit': 'E1', 'api': 'POST /x',
               'cases': [{'id': 'TC-1', 'name': 'add', 'status': 'golden', 'fixture': 'f.sql',
                          'expected': {'status': 201, 'body': {'amount': 1.50, 'b': 'x', 'a': [2, 1]}}},
                         {'id': 'TC-2', 'name': 'nr', 'status': 'not-representable', 'reason': 'no API'}]}
        return doc

    def setup(self):
        self.w('mu/t1/mu.yaml', 'name: t1\nentry_points: [E1]\nsolution: solution/\n')
        self.tools_text = TOOLS
        self.w('mu/t1/tools.yaml', TOOLS)
        self.w('mu/t1/design/rules.md', '# rules\n')
        self.w('mu/t1/design/tests.md', '# tests\n')
        self.w('mu/t1/extracted-logic/paragraph-index.json', '{"programs": {"P": {}}}\n')
        self.w('mu/t1/unit/schema.sql', 'CREATE TABLE T_A (A INT);\n')
        self.w('mu/t1/tests/package/E1/f.sql', 'INSERT INTO T_A VALUES (1);\n')
        doc = self.package()
        inputs = {f: file_sha(self.mu / f) for f in ('design/rules.md', 'design/tests.md',
                                                     'extracted-logic/paragraph-index.json', 'unit/schema.sql')}
        doc['package'].update({'contentHash': content_hash(doc), 'inputs': inputs, 'state': 'ready'})
        # written with the floats as text the way json.dumps writes them (1.5), the seal is of the parsed doc
        self.w('mu/t1/tests/package/E1/E1-tests.json', json.dumps(doc, indent=2) + '\n')
        self.w('mu/t1/tests/tests-state.json', json.dumps({'entry': 'E1', 'state': 'ready', 'scope': 'full',
                                                           'package': {'contentHash': doc['package']['contentHash']}}))
        self.pq_text = ('# tests-open-questions.md\n\n## PQ-1 - a soft one\n\nStep: 3 · Status: open\nBlocking: no\n'
                        'Question: q\nDecision taken: d\nAffects: -\nAnswer: \n')
        self.w('mu/t1/tests/tests-open-questions.md', self.pq_text)
        self.w('solution/pom.xml', '<project><version>1.0</version></project>\n')
        self.w('solution/app/pom.xml', '<project/>\n')
        self.w('solution/app/src/main/java/A.java', 'class A {}\n')
        fw = ('<project xmlns="http://maven.apache.org/POM/4.0.0"><modelVersion>4.0.0</modelVersion>'
              '<groupId>com.insurance.e2e</groupId><artifactId>modernization-e2e-framework</artifactId>'
              '<version>0.9.0-T</version></project>\n')
        self.w('tools/e2e-framework/pom.xml', fw)
        self.w('tools/e2e-framework/core/pom.xml', '<project/>\n')
        self.w('tools/e2e-framework/core/src/C.java', 'class C {}\n')

    def tools_bytes(self):
        return (self.mu / 'tools.yaml').read_bytes()

    def reset_tools(self):
        self.w('mu/t1/tools.yaml', TOOLS)

    # ---------------------------------------------------------------- cases
    def t_seal(self):
        doc = self.package()
        shuffled = json.loads(json.dumps({k: doc[k] for k in reversed(list(doc))}))
        self.check(content_hash(doc) == content_hash(shuffled), 'seal: key order does not matter')
        body = {k: v for k, v in doc.items() if k != 'package'}
        ref = sha256(json.dumps(body, ensure_ascii=False, separators=(',', ':'), sort_keys=True).encode('utf-8'))
        self.check(content_hash(doc) == ref, 'seal: sorted-keys canonical JSON')
        self.check(canonical({'b': 1, 'a': 2}) == b'{"a":2,"b":1}', 'canonical form')

    def t_preflight(self):
        tf = self.mu / 'tools.yaml'
        # missing section, E2E_T1 absent -> appended, comments kept
        self.db({'GM_T1': {'T_A': 3}})
        code, d = self.run('preflight', 'mu/t1')
        text = tf.read_text(encoding='utf-8')
        self.check(code == 0 and d.get('e2eDb2', {}).get('section') == 'written', f'preflight absent: written {code} {d}')
        self.check(text.startswith(TOOLS), 'preflight absent: the file before is kept byte for byte')
        self.check('# trailing comment line' in text and '# local only' in text, 'preflight: comments preserved')
        import yaml
        y = yaml.safe_load(text)
        e = y.get('e2e-db2') or {}
        self.check(e.get('schema') == 'E2E_T1' and e.get('container') == 'fake-db2' and e.get('host') == 'localhost'
                   and e.get('password') == 'testenv', f'preflight: section from test-db2 + db2 container {e}')
        self.check({k: v for k, v in y.items() if k != 'e2e-db2'} == yaml.safe_load(TOOLS), 'preflight: rest equal')
        # present, no rows -> ok, no warning about rows
        code, d = self.run('preflight', 'mu/t1')
        self.check(code == 0 and d['e2eDb2']['section'] == 'present', f'preflight present: {code} {d}')
        # missing, E2E_T1 empty tables -> appended
        self.reset_tools()
        self.db({'E2E_T1': {'T_A': 0, 'T_B': 0}})
        code, d = self.run('preflight', 'mu/t1')
        self.check(code == 0 and d['e2eDb2']['section'] == 'written', f'preflight empty tables: written {code}')
        # missing, rows -> conflict, nothing written, free name
        self.reset_tools()
        self.db({'E2E_T1': {'T_A': 2, 'T_B': 0}, 'E2E_T1_1': {}})
        before = self.tools_bytes()
        code, d = self.run('preflight', 'mu/t1')
        self.check(code == 2 and d.get('status') == 'schema-conflict', f'preflight rows: exit 2 {code} {d}')
        self.check(self.tools_bytes() == before, 'preflight rows: tools.yaml unchanged')
        self.check(d.get('free') == 'E2E_T1_2', f'preflight rows: free name {d.get("free")}')
        self.check(d.get('e2eDb2', {}).get('rows') == {'T_A': 2}, 'preflight rows: tables with counts')
        vqd = d.get('vq') or {}
        self.check(vqd.get('blocking') == 'yes' and 'E2E_T1_2' in vqd.get('question', ''), 'preflight rows: VQ text')
        self.check('--e2e-schema' in d.get('next', ''), 'preflight rows: next command')
        # M2: the derived schema with rows named explicitly is the owner's choice: written, the rows a warning
        code, d = self.run('preflight', 'mu/t1', '--e2e-schema', 'E2E_T1')
        y = yaml.safe_load(tf.read_text(encoding='utf-8'))
        self.check(code == 0 and d.get('status') == 'ready' and (y.get('e2e-db2') or {}).get('schema') == 'E2E_T1'
                   and any('T_A 2' in x and 'deletes' in x for x in d.get('warnings', [])),
                   f'M2: --e2e-schema E2E_T1 with rows accepted with a warning, no loop {code} {d}')
        self.reset_tools()
        # --e2e-schema -> appended with that name
        code, d = self.run('preflight', 'mu/t1', '--e2e-schema', 'e2e_t1v2')
        y = yaml.safe_load(tf.read_text(encoding='utf-8'))
        self.check(code == 0 and (y.get('e2e-db2') or {}).get('schema') == 'E2E_T1V2', f'--e2e-schema: {code} {d}')
        # present + rows -> warning
        self.db({'E2E_T1': {'T_A': 2}, 'E2E_T1V2': {'T_A': 5}})
        code, d = self.run('preflight', 'mu/t1')
        self.check(code == 0 and any('deletes' in x and 'T_A 5' in x for x in d.get('warnings', [])),
                   f'preflight present+rows: warning {code} {d.get("warnings")}')
        # --e2e-schema against a present section of another name -> block
        code, d = self.run('preflight', 'mu/t1', '--e2e-schema', 'E2E_OTHER')
        self.check(code == 1, 'preflight: --e2e-schema differing from the present section blocks')
        # bad prefix: argument, and a present section
        self.reset_tools()
        before = self.tools_bytes()
        code, d = self.run('preflight', 'mu/t1', '--e2e-schema', 'FOO')
        self.check(code == 1 and self.tools_bytes() == before, f'bad prefix argument: exit 1, nothing written {code}')
        with open(tf, 'a', encoding='utf-8', newline='\n') as fh:
            fh.write('\ne2e-db2:\n  container: fake-db2\n  schema: GM_T1\n  user: db2inst1\n  password: testenv\n')
        code, d = self.run('preflight', 'mu/t1')
        self.check(code == 1 and any('E2E' in b for b in d.get('blocks', [])), f'bad prefix section: exit 1 {code}')
        # Db2 down while the section is missing -> block, nothing written
        self.reset_tools()
        before = self.tools_bytes()
        code, d = self.run('preflight', 'mu/t1', env={'FAKE_DB2_DOWN': '1'})
        self.check(code == 1 and self.tools_bytes() == before, f'Db2 down: exit 1, nothing written {code}')
        # missing solution -> block
        shutil.move(str(self.ws / 'solution'), str(self.ws / '_solution'))
        code, d = self.run('preflight', 'mu/t1')
        self.check(code == 1 and any('solution' in b for b in d.get('blocks', [])), 'no solution blocks')
        shutil.move(str(self.ws / '_solution'), str(self.ws / 'solution'))
        log = Path(str(self.db_file) + '.log').read_text(encoding='utf-8').lower()
        self.check(not re.search(r'\b(delete|drop|create|insert|update)\b', log), 'Db2: read-only statements only')
        self.reset_tools()

    def t_readiness(self):
        code, d = self.run('readiness', 'mu/t1')
        self.check(code == 0 and d.get('status') == 'ready' and d.get('sealHolds') is True, f'readiness ready {code} {d}')
        self.check(any('PQ-1' in x for x in d.get('warnings', [])), 'readiness: open non-blocking PQ is a warning')
        tm = self.mu / 'design' / 'tests.md'
        orig = tm.read_bytes()
        with open(tm, 'ab') as fh:
            fh.write(b'\n')
        code, d = self.run('readiness', 'mu/t1')
        fx = d.get('fix') or []
        self.check(code == 2 and d.get('status') == 'stale' and d.get('changedInputs') == ['design/tests.md'],
                   f'readiness stale {code} {d}')
        self.check(fx and fx[0]['command'] == slash_command('mu-build-tests') + ' mu/t1 entry=E1' and 'design/tests.md' in fx[0]['reason'],
                   f'readiness stale: fix command {fx}')
        tm.write_bytes(orig)
        qf = self.mu / 'tests' / 'tests-open-questions.md'
        self.w('mu/t1/tests/tests-open-questions.md', self.pq_text + '\n## PQ-2 - hard\n\nStep: 5 · Status: open\n'
               'Blocking: yes\nQuestion: q\nDecision taken: d\nAffects: -\nAnswer: <...>\n')
        code, d = self.run('readiness', 'mu/t1')
        self.check(code == 2 and d.get('status') == 'needs-answers' and any('PQ-2' in f['reason'] for f in d['fix']),
                   f'readiness blocking PQ {code} {d}')
        self.w('mu/t1/tests/tests-open-questions.md', self.pq_text + '\n## PQ-2 - hard\n\nStep: 5 · Status: open\n'
               'Blocking: yes\nQuestion: q\nDecision taken: d\nAffects: -\nAnswer: yes, as recorded\n')
        code, d = self.run('readiness', 'mu/t1')
        self.check(code == 0, 'readiness: an answered blocking PQ no longer blocks')
        qf.write_text(self.pq_text, encoding='utf-8')
        pf = self.mu / 'tests' / 'package' / 'E1' / 'E1-tests.json'
        orig = pf.read_bytes()
        doc = json.loads(orig)
        doc['cases'][0]['expected']['status'] = 200
        pf.write_text(json.dumps(doc, indent=2), encoding='utf-8')
        code, d = self.run('readiness', 'mu/t1')
        self.check(code == 2 and d.get('status') == 'blocked' and d.get('sealHolds') is False
                   and any(f['issue'] == 'seal broken' for f in d['fix']), f'readiness bad seal {code} {d}')
        pf.write_bytes(orig)
        sf = self.mu / 'tests' / 'tests-state.json'
        so = sf.read_bytes()
        sf.write_text(json.dumps({**json.loads(so), 'state': 'needs-api-check',
                                  'reasons': {'needs-api-check': ['solution changed']}}), encoding='utf-8')
        code, d = self.run('readiness', 'mu/t1')
        self.check(code == 2 and any('--api-checked' in f['command'] for f in d['fix']), 'readiness: needs-api-check')
        sf.write_bytes(so)
        code, d = self.run('readiness', 'mu/t1')
        self.check(code == 0, 'readiness ready again after restore')

    def listing(self, root):
        return sorted((p.relative_to(root).as_posix(), p.stat().st_mtime_ns, p.stat().st_size if p.is_file() else -1)
                      for p in root.rglob('*'))

    def t_framework(self):
        tools_before = self.listing(self.ws / 'tools')
        n0 = self.mvn_calls()
        code, d = self.run('framework', 'mu/t1')
        self.check(code == 0 and d.get('status') == 'installed' and self.mvn_calls() == n0 + 1,
                   f'framework installed {code} {d}')
        last = self.mvn_log.read_text(encoding='utf-8').splitlines()[-1]
        self.check('validation' in last.replace('\\', '/') and '/tools/e2e-framework/pom.xml' not in last.replace('\\', '/'),
                   'framework: built from a copy under validation/target, not in tools/')
        self.check('-Dmaven.repo.local.tail=' in last and '-DskipTests' in last, 'framework: private repo + tail')
        code, d = self.run('framework', 'mu/t1')
        self.check(code == 0 and d.get('status') == 'reused' and self.mvn_calls() == n0 + 1, f'framework reused {d}')
        self.check(self.listing(self.ws / 'tools') == tools_before, 'framework: nothing written under tools/')
        self.w('tools/e2e-framework/core/src/C.java', 'class C { int x; }\n')
        code, d = self.run('framework', 'mu/t1')
        self.check(code == 0 and d.get('status') == 'installed' and d.get('replacedStale') is True,
                   f'framework: changed sources reinstall {d}')

    def t_snapshot(self):
        sol = self.ws / 'solution'
        before = self.listing(sol)
        n0 = self.mvn_calls()
        sf = self.mu / 'validation' / 'validation-state.json'
        st_before = sf.read_bytes() if sf.is_file() else None
        code, d = self.run('snapshot', 'mu/t1', '--status')
        self.check(code == 0 and d.get('status') == 'not_installed', f'snapshot status not_installed {d}')
        self.check((sf.read_bytes() if sf.is_file() else None) == st_before
                   and not (self.ws / 'validation' / 'target' / 'product').exists(), 'snapshot --status writes nothing')
        code, d = self.run('snapshot', 'mu/t1')
        rev = d.get('revision')
        snap = self.ws / 'validation' / 'target' / 'product' / str(rev)
        self.check(code == 0 and d.get('status') == 'built' and self.mvn_calls() == n0 + 1, f'snapshot built {d}')
        self.check((snap / 'app' / 'src' / 'main' / 'java' / 'A.java').is_file(), 'snapshot: copy present')
        man = json.loads((snap.parent / f'{rev}.manifest.json').read_text(encoding='utf-8'))
        self.check(set(man) == {'pom.xml', 'app/pom.xml', 'app/src/main/java/A.java'}, f'snapshot manifest {man}')
        self.check(sha256(''.join(f'{p}\t{h}\n' for p, h in sorted(man.items()))) == d.get('hash'), 'snapshot: hash')
        self.check(d.get('artifacts') == 1, 'snapshot: artifacts listed')
        last = self.mvn_log.read_text(encoding='utf-8').splitlines()[-1]
        self.check('-Dspring-boot.repackage.skip=true' in last and '-DskipTests' in last, 'snapshot: build flags')
        self.check(self.listing(sol) == before, 'snapshot: nothing written under solution/')
        code, d = self.run('snapshot', 'mu/t1')
        self.check(code == 0 and d.get('status') == 'reused' and self.mvn_calls() == n0 + 1, f'snapshot reused {d}')
        code, d = self.run('snapshot', 'mu/t1', '--status')
        self.check(d.get('status') == 'current', f'snapshot status current {d}')
        (sol / 'target').mkdir()
        (sol / 'target' / 'junk.class').write_text('x')
        code, d = self.run('snapshot', 'mu/t1', '--status')
        self.check(d.get('status') == 'current', 'snapshot: target/ is not product content')
        shutil.rmtree(sol / 'target')
        self.w('solution/app/src/main/java/A.java', 'class A { int y; }\n')
        code, d = self.run('snapshot', 'mu/t1', '--status')
        self.check(d.get('status') == 'changed' and (d.get('changedFiles') or {}).get('modified') ==
                   ['app/src/main/java/A.java'], f'snapshot status changed {d}')
        code, d = self.run('snapshot', 'mu/t1')
        self.check(code == 0 and d.get('status') == 'built' and d.get('revision') != rev, f'snapshot rebuilt {d}')
        inst = json.loads((snap.parent / 'installed.json').read_text(encoding='utf-8'))
        self.check(inst.get('revision') == d.get('revision'), 'snapshot: installed.json names the new revision')
        n1 = self.mvn_calls()
        code, d = self.run('snapshot', 'mu/t1')
        self.check(d.get('status') == 'reused' and self.mvn_calls() == n1, 'snapshot: reused after rebuild')
        code, d = self.run('snapshot', 'mu/t1', '--rebuild', env={'FAKE_MVN_FAIL': '1'})
        self.check(code == 1 and not (snap.parent / 'installed.json').is_file(), 'snapshot: failed build, not installed')

    def t_state_questions(self):
        sf = self.mu / 'validation' / 'validation-state.json'
        st = json.loads(sf.read_text(encoding='utf-8'))
        self.check(st.get('format') == 1 and st.get('mu') == 't1', 'state: format and mu')
        self.check(set(st.get('steps', {})) >= {'preflight', 'readiness', 'framework', 'snapshot'}, 'state: steps')
        self.check(st['snapshot'].get('hash') and st['framework'].get('fingerprint'), 'state: hash and fingerprint')
        code, d = self.run('questions', 'mu/t1', 'add', '--title', 'Schema', '--question', 'Which?', '--decision',
                           'none', '--step', 'preflight', '--blocking', 'yes')
        self.check(code == 0 and d.get('added') == 'VQ-1' and d.get('blocking') == ['VQ-1'], f'questions VQ-1 {d}')
        code, d = self.run('questions', 'mu/t1', 'add', '--gate', '--title', 'Record gate E1 v1', '--question',
                           'Accept?', '--decision', 'not accepted yet', '--step', 'gate')
        self.check(d.get('added') == 'RG-1', f'questions RG-1 {d}')
        code, d = self.run('questions', 'mu/t1', 'add', '--title', 'Other', '--question', 'q', '--decision', 'd')
        self.check(d.get('added') == 'VQ-2', 'questions VQ-2')
        qf = self.mu / 'validation' / 'validation-open-questions.md'
        text = qf.read_text(encoding='utf-8')
        self.check('## VQ-1 - Schema\n\nStep: preflight · Status: open\nBlocking: yes\nQuestion: Which?\n'
                   'Decision taken: none\nAffects: -\nAnswer: \n' in text, 'questions: design convention')
        qf.write_text(text.replace('Question: Which?\nDecision taken: none\nAffects: -\nAnswer: ',
                                   'Question: Which?\nDecision taken: none\nAffects: -\nAnswer: E2E_T1V2'),
                      encoding='utf-8')
        self.db({})
        code, d = self.run('preflight', 'mu/t1')
        self.check([a['id'] for a in d.get('answers', [])] == ['VQ-1'] and 'VQ-1' not in d.get('blocking', []),
                   f'preflight reads answered VQs {d.get("answers")}')
        code, d = self.run('status', 'mu/t1')
        self.check(code == 0 and isinstance(d.get('steps'), list) and 'notImplemented' not in d
                   and [x['step'] for x in d['steps']][-2:] == ['analyse', 'report'], f'status {d}')
        code, d = self.run('readiness', 'mu/none')
        self.check(code == 1 and 'mu.yaml' in d.get('error', ''), 'no MU: exit 1')
        code, d = self.run('bogus', 'mu/t1')
        self.check(code == 1 and 'usage' in d.get('error', ''), 'usage error: one JSON, exit 1')

    def t_settle(self):
        code, d = self.run('questions', 'mu/t1', 'add', '--title', 'Replay schema: E2E_T1 already holds rows',
                           '--question', 'Which schema?', '--decision', 'nothing written', '--step', 'preflight',
                           '--blocking', 'yes')
        vid = d.get('added')
        code, d = self.run('preflight', 'mu/t1')
        self.check(vid in d.get('blocking', []) and any(q['id'] == vid for q in d.get('blockingQuestions', [])),
                   f'preflight lists the open blocking VQ {d.get("blockingQuestions")}')
        qf = self.mu / 'validation' / 'validation-open-questions.md'
        before = qf.read_text(encoding='utf-8')
        code, d = self.run('preflight', 'mu/t1', '--e2e-schema', 'E2E_T1')
        after = qf.read_text(encoding='utf-8')
        self.check(code == 0 and d.get('settled') == [vid] and vid not in d.get('blocking', []),
                   f'--e2e-schema settles the schema VQ {code} {d.get("settled")} {d.get("blocking")}')
        changed = [(a, b) for a, b in zip(before.splitlines(), after.splitlines()) if a != b]
        self.check(len(changed) == 1 and changed[0][1].endswith('Status: settled')
                   and len(before.splitlines()) == len(after.splitlines()), f'settle: one status line edited {changed}')
        code, d = self.run('preflight', 'mu/t1', '--e2e-schema', 'E2E_T1')
        self.check(d.get('settled') == [], 'settle: idempotent')

    # ---------------------------------------------------------------- import / fixtures / solution (MU t2)
    def package2(self):
        cols = {'A': 'integer', 'B': 'char(4)'}
        q = 'SELECT A, B FROM T_A ORDER BY A'
        ddl_sha = file_sha(self.ws / 'mu/t2/unit/schema.sql')
        fx_sha = file_sha(self.ws / 'mu/t2/tests/package/E2/f.sql')
        rec = {'recordedAt': '2026-11-06T08:00:00Z', 'fingerprint': 'fp1', 'parityTester': 'abc', 'repeats': 2,
               'runIds': ['r1', 'r2']}
        legacy = {'inputs': {'CMD': 'ADD', 'N': '1'}, 'runId': 'r1', 'number': 'A1', 'responseCode': '0'}
        doc = {
            'package': {'schema': 'mu-build-tests/tests.schema.json', 'format': 3, 'version': 1},
            'unit': 'E2', 'api': 'POST /x served by XController', 'goldenMaster': 'cobol-runner (selftest)',
            'comparison': 'the package rules', 'statuses': {'201': 'created'},
            'comparisonRules': [{'id': i, 'rule': i.lower()} for i in
                                ('STATUS', 'OUTCOME_ONLY_ON_ERROR', 'RTRIM', 'NULL_AS_BLANK', 'NUMBERS_BY_VALUE')],
            'resetTables': ['T_A'],
            'legacySchema': {'inputs': '$inputs', 'runId': '$runId', 'number': 'NUM-0001', 'responseCode': 'RC-0001',
                             'tables': {'ta': {'table': 'T_A', 'columns': cols, 'orderBy': 'A'}}},
            'rules': [{'id': 'R1', 'text': 'An add writes one row. The row has the number.', 'provenBy': ['TC-A']},
                      {'id': 'R2', 'text': 'A text sequence is refused.', 'provenBy': ['TC-B']}],
            'coverage': {'totals': {'paragraphs': {'total': 4, 'covered': 3, 'uncovered': 1},
                                    'lines': {'code': 40, 'covered': 30, 'uncovered': 10}},
                         'programs': {'P1': {'entered': True, 'lines': {'code': 40, 'covered': 30}}}},
            'recordings': {'fp1': {'members': {}, 'fixture': {'name': 'f.sql', 'sha256': fx_sha},
                                   'ddl': {'path': 'mu/t2/unit/schema.sql', 'sha256': ddl_sha}}},
            'cases': [
                {'id': 'TC-A', 'name': 'add', 'origin': 'basic', 'category': 'Happy', 'about': 'an add',
                 'ruleIds': ['R1'], 'status': 'golden', 'fixture': 'f.sql', 'clock': '20240816103000',
                 'clockSensitive': True, 'paragraphs': ['P1.MAIN', 'P1.PARA-1'],
                 'request': {'method': 'POST', 'path': '/x', 'query': {}, 'body': {'n': 1}},
                 'expected': {'status': 201, 'body': {'id': 'A1'},
                              'tables': [{'name': 'T_A', 'query': q, 'columns': ['A', 'B'], 'rows': [[1, 'X']],
                                          'compare': 'ordered'}]},
                 'anticipatedJavaDivergence': [], 'stackDivergence': [], 'recording': rec,
                 'decidedAnswer': {'source': 'OQ-9', 'status': 500, 'recordedStatus': 201, 'tables': 'notCompared',
                                   'rules': ['add-refused'], 'recorded': {'status': 201}, 'pending': True,
                                   'reason': 'OQ-9 is open'},
                 'legacy': {**legacy, 'verify': {'ta': [['1', 'X']]}}},
                {'id': 'TC-B', 'name': 'text-seq', 'origin': 'advanced', 'category': 'Error', 'about': 'a text seq',
                 'ruleIds': ['R2'], 'status': 'golden', 'fixture': 'f.sql', 'clock': '20240816103000123456',
                 'clockSensitive': False, 'paragraphs': ['P1.MAIN'],
                 'request': {'method': 'POST', 'path': '/x', 'query': {}, 'body': {'n': 'ABC'}},
                 'expected': {'status': 500, 'body': {'code': 'FAILED'}},
                 'decidedAnswer': {'source': 'OQ-1', 'status': 500, 'recordedStatus': 201, 'tables': 'notCompared',
                                   'rules': ['text-seq'], 'recorded': {'status': 201, 'body': {'id': ''}}},
                 'anticipatedJavaDivergence': ['OQ-1: the Java refuses'], 'stackDivergence': [], 'recording': rec,
                 'legacy': legacy, 'design': {'request': 'r'}},
                {'id': 'TC-C', 'name': 'no-date', 'origin': 'basic', 'status': 'not-representable',
                 'reason': 'not a request field', 'ruleIds': [], 'paragraphs': [], 'request': None, 'expected': None},
            ]}
        return doc

    def setup2(self):
        m = 'mu/t2/'
        self.w(m + 'mu.yaml', 'name: t2\ndu: demo\nentry_points: [E2]\nsolution: solution/\n')
        self.w(m + 'tools.yaml', TOOLS + '\n\ne2e-db2:\n  kind: local\n  container: fake-db2\n  host: localhost\n'
                                         '  port: 50000\n  database: TESTDB\n  schema: E2E_T2\n  user: db2inst1\n'
                                         '  password: testenv\n')
        self.w(m + 'design/rules.md', '# rules\n')
        self.w(m + 'design/tests.md', '# tests\n')
        self.w(m + 'extracted-logic/paragraph-index.json', '{}\n')
        self.w(m + 'unit/schema.sql', 'CREATE TABLE T_A (\n  A INTEGER NOT NULL,\n  B CHAR(4)\n);\n\n'
                                      'CREATE TABLE T_X (X INTEGER);\n')
        self.w(m + 'tests/package/E2/f.sql', 'INSERT INTO T_A (A, B) VALUES (1, \'X\');\n')
        doc = self.package2()
        inputs = {f: file_sha(self.ws / m / f) for f in ('design/rules.md', 'design/tests.md',
                                                         'extracted-logic/paragraph-index.json', 'unit/schema.sql')}
        doc['package'].update({'contentHash': content_hash(doc), 'inputs': inputs, 'state': 'ready'})
        self.w(m + 'tests/package/E2/E2-tests.json', json.dumps(doc, indent=2) + '\n')
        self.w(m + 'tests/tests-state.json', json.dumps({'entry': 'E2', 'state': 'ready', 'scope': 'full',
                                                         'package': {'contentHash': doc['package']['contentHash']}}))

    def j(self, rel):
        return json.loads((self.ws / rel).read_text(encoding='utf-8'))

    def t_import(self):
        self.setup2()
        e2e = self.ws / 'mu/t2/validation/e2e'
        code, d = self.run('import', 'mu/t2')
        self.check(code == 0 and d.get('status') == 'imported', f'import: imported {code} {d.get("error")}')
        self.check(d.get('scenarios') == 3 and d.get('byStatus') == {'runnable': 2, 'not-applicable': 1}
                   and d.get('golden', {}).get('written') == 2, f'import: counts {d.get("byStatus")} {d.get("golden")}')
        self.check(any('`design`' in w for w in d.get('warnings', [])), f'import: dropped field warned {d.get("warnings")}')
        self.check((d.get('coverage') or {}).get('percent') == '75.0', f'import: coverage from v2 totals {d.get("coverage")}')
        reg = {s['scenarioId']: s for s in self.j('mu/t2/validation/e2e/scenarios/E2.json')['scenarios']}
        a, b, c = reg['TC-A'], reg['TC-B'], reg['TC-C']
        self.check({'rule:R1', 'origin:basic', 'para:P1.MAIN', 'para:P1.PARA-1'} <= set(a.get('tags', []))
                   and a.get('ruleIds') == ['R1'], f'import: rule/origin/para tags + ruleIds {a.get("tags")}')
        self.check(a.get('answerEmpty') is False and a.get('tables'), 'import: table case keeps tables/answerEmpty')
        self.check(b.get('http', {}).get('body') == {'n': 'ABC'} and 'tables' not in b and 'answerEmpty' not in b,
                   f'import: no-table case keeps the body, no tables/answerEmpty {b.get("http")}')
        self.check(b.get('decided', {}).get('source') == 'OQ-1', 'import: v2 decided source accepted')
        self.check('decided' not in a and 'decided' not in a.get('tags', [])
                   and 'decidedAnswer' not in (self.j('mu/t2/validation/e2e/golden/E2/TC-A.json').get('evidence') or {}),
                   f'pending: a pending decided answer is imported as none (table checks kept, no decided) {a}')
        self.check(c.get('status') == 'not-applicable' and c['levels'][0]['mapping'] == 'E2', 'import: n/a mapping')
        ga = self.j('mu/t2/validation/e2e/golden/E2/TC-A.json')['observation']['payload']
        gb = self.j('mu/t2/validation/e2e/golden/E2/TC-B.json')['observation']['payload']
        self.check('$empty' in ga and '$tables' in ga, 'import: $empty/$tables with table checks')
        self.check('$empty' not in gb and '$tables' not in gb, f'import: no $empty without table checks (F9) {gb}')
        vms = sorted(p.stem for p in (e2e / 'view-mappings').glob('*.json'))
        self.check(vms == ['E2', 'E2--code--no-tables', 'E2--id'], f'import: view mappings {vms}')
        nt = self.j('mu/t2/validation/e2e/view-mappings/E2--code--no-tables.json')
        self.check(all(f['legacy'] != '$empty' for f in nt['fields']) and not nt['groups'], 'import: no-tables mapping')
        prof = self.j('mu/t2/validation/e2e/profiles.json')['profiles'][0]
        self.check(prof['name'] == 'contract' and [r['rule'] for r in prof['rules']] ==
                   ['OUTCOME_ONLY_ON_ERROR', 'RTRIM', 'NULL_AS_BLANK', 'NUMERIC_SCALE_INSENSITIVE']
                   and {r['decision'] for r in prof['rules']} == {'PKG-CMP-E2'}, f'import: profile {prof}')
        feat = (e2e / 'features' / 'E2.feature').read_text(encoding='utf-8')
        self.check('@clock-sensitive' in feat and 'decided by "OQ-1"' in feat and '@origin:advanced' in feat
                   and '2024-08-16 10:30:00.123456' in feat, 'import: feature tags, decided step, fraction clock')
        self.check(not list(e2e.parent.glob('README.md')) and not (e2e / '.run').exists(), 'import: no README/.run')
        before = self.listing(e2e)
        code, d = self.run('import', 'mu/t2')
        self.check(code == 0 and d.get('status') == 'unchanged' and self.listing(e2e) == before,
                   f'import twice: unchanged {d.get("status")} {d.get("filesChanged")}')
        # acceptance re-applied by oracle key on a regenerated folder
        from e2elib import canonical as ecan, update as eupd
        master = ecan.load_json(e2e / 'golden' / 'E2' / 'TC-A.json')
        key = eupd.oracle_key(reg['TC-A'], master)
        sf = self.ws / 'mu/t2/validation/validation-state.json'
        st = json.loads(sf.read_text(encoding='utf-8'))
        st['acceptance'] = {'TC-A': {'oracleKey': key, 'by': 'Jane Doe', 'at': '2026-11-06T12:00:00Z'},
                            'TC-B': {'oracleKey': 'other', 'by': 'Jane Doe', 'at': '2026-11-06T12:00:00Z'}}
        sf.write_text(json.dumps(st), encoding='utf-8')
        shutil.rmtree(e2e)
        code, d = self.run('import', 'mu/t2')
        ma = self.j('mu/t2/validation/e2e/golden/E2/TC-A.json')
        mb = self.j('mu/t2/validation/e2e/golden/E2/TC-B.json')
        self.check(d.get('acceptanceReapplied') == 1 and ma['state'] == 'ACCEPTED' and mb['state'] == 'RECORDED'
                   and d.get('acceptanceDropped') == ['TC-B'], f'import: acceptance re-applied by oracle key {d}')
        self.check(ma['history'][-1]['by'] == 'Jane Doe', 'import: acceptance keeps who accepted')
        from e2elib import canonical as ec2
        self.check(ec2.integrity_holds(ec2.load_json(e2e / 'golden' / 'E2' / 'TC-A.json')), 'import: seal holds after')
        code, d = self.run('import', 'mu/t2')
        self.check(d.get('status') == 'unchanged' and d.get('acceptanceReapplied') == 0, 'import: accepted, unchanged')
        # readiness first: a stale input -> exit 2, nothing written
        before = self.listing(e2e)
        tm = self.ws / 'mu/t2/design/tests.md'
        orig = tm.read_bytes()
        tm.write_bytes(orig + b'\n')
        code, d = self.run('import', 'mu/t2')
        self.check(code == 2 and (d.get('readiness') or {}).get('status') == 'stale' and self.listing(e2e) == before,
                   f'import: readiness must pass first {code} {d.get("readiness")}')
        tm.write_bytes(orig)

    def t_fixtures(self):
        code, d = self.run('fixtures', 'mu/t2')
        self.check(code == 0 and d.get('status') == 'prepared' and d.get('packs') == 1 and d.get('reset') == 'all-tables'
                   and d.get('tables') == ['T_A'] and d.get('e2eSchema') == 'E2E_T2', f'fixtures prepared {code} {d}')
        man = self.j('mu/t2/validation/e2e/fixtures/manifest.json')
        sql = (self.ws / 'mu/t2/validation/e2e/fixtures/schema/recording-schema.sql').read_text(encoding='utf-8')
        self.check(man.get('reset') == 'all-tables' and man['packs'][0]['id'] == 'E2/f' and 'CREATE TABLE T_A' in sql
                   and 'T_X' not in sql, 'fixtures: manifest + schema cut from unit/schema.sql')
        gm = self.j('mu/t2/validation/e2e/golden/E2/TC-A.json')
        self.check(gm['provenance']['fixture'] == man['packs'][0]['sha256'], 'fixtures: pack hash = golden provenance')
        code, d = self.run('fixtures', 'mu/t2')
        self.check(d.get('status') == 'unchanged', 'fixtures twice: unchanged')
        # M3: no table check, no resetTables -> still reset: all-tables (decision 3)
        pf = self.ws / 'mu/t2/tests/package/E2/E2-tests.json'
        orig = pf.read_bytes()
        doc = json.loads(orig)
        doc.pop('resetTables', None)
        for c in doc['cases']:
            if isinstance(c.get('expected'), dict):
                c['expected'].pop('tables', None)
        pf.write_text(json.dumps(doc, indent=2), encoding='utf-8')
        code, d = self.run('fixtures', 'mu/t2')
        man = self.j('mu/t2/validation/e2e/fixtures/manifest.json')
        self.check(code == 0 and d.get('reset') == 'all-tables' and man.get('reset') == 'all-tables',
                   f'M3: reset all-tables without table checks or resetTables {code} {d.get("reset")} {d.get("error")}')
        pf.write_bytes(orig)
        code, d = self.run('fixtures', 'mu/t2')
        self.check(code == 0 and d.get('tables') == ['T_A'], 'fixtures: restored')

    def product(self, boot='3.5.1'):
        self.w('solution/pom.xml', textwrap.dedent(f'''\
            <project xmlns="http://maven.apache.org/POM/4.0.0"><modelVersion>4.0.0</modelVersion>
              <parent><groupId>org.springframework.boot</groupId><artifactId>spring-boot-starter-parent</artifactId>
                <version>{boot}</version><relativePath/></parent>
              <groupId>org.demo</groupId><artifactId>demo-solution</artifactId><version>2.0.0-SNAPSHOT</version>
              <packaging>pom</packaging><modules><module>app</module></modules>
              <properties><java.version>21</java.version></properties>
            </project>
            '''))
        self.w('solution/app/pom.xml', textwrap.dedent('''\
            <project xmlns="http://maven.apache.org/POM/4.0.0"><modelVersion>4.0.0</modelVersion>
              <parent><groupId>org.demo</groupId><artifactId>demo-solution</artifactId><version>2.0.0-SNAPSHOT</version>
              </parent><artifactId>demo-app</artifactId>
              <dependencies><dependency><groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-starter-security</artifactId></dependency></dependencies>
            </project>
            '''))
        self.w('solution/app/src/main/java/org/demo/App.java',
               'package org.demo;\n\n@SpringBootApplication\npublic class App {\n}\n')
        self.w('solution/app/src/main/java/org/demo/Sec.java',
               'package org.demo;\n\n@Configuration\npublic class Sec {\n    SecurityFilterChain chain() { return null; }\n}\n')
        self.w('solution/app/src/main/resources/application.yml',
               'server:\n  port: 8080\nspring:\n  datasource:\n    url: ${DB_URL}\n    username: ${DB_USER}\n'
               '    hikari:\n      schema: ${DB_SCHEMA}\napp:\n  key: ${APP_KEY}\n')

    def t_solution(self):
        sol = self.ws / 'solution'
        shutil.rmtree(sol)
        self.product()
        code, d = self.run('solution', 'mu/t2')
        self.check(code == 2 and 'snapshot' in d.get('error', ''), f'solution: needs a current snapshot {code} {d}')
        code, d = self.run('snapshot', 'mu/t2')
        sol_before = self.listing(sol)
        code, d = self.run('solution', 'mu/t2')
        f = d.get('facts') or {}
        self.check(code == 0 and d.get('status') == 'created', f'solution created {code} {d.get("error")}')
        self.check(f.get('mainClass') == 'org.demo.App' and f.get('basePackage') == 'org.demo'
                   and f.get('springBootVersion') == '3.5.1' and f.get('javaRelease') == '21'
                   and f.get('productModule') == 'demo-app' and f.get('productGroupId') == 'org.demo'
                   and f.get('productVersion') == '2.0.0-SNAPSHOT' and f.get('appId') == 'demo', f'solution facts {f}')
        self.check(f.get('datasource', {}).get('environment') == ['DB_SCHEMA', 'DB_URL', 'DB_USER']
                   and f.get('security', {}).get('configClasses') == ['org.demo.Sec']
                   and 'spring-boot-starter-security' in f['security']['dependencies'], f'solution: ds/security {f}')
        self.check(f.get('placeholdersWithoutDefault') == ['app.key=${APP_KEY}'], 'solution: placeholders listed')
        self.check((d.get('e2eDatabase') or {}).get('url') == 'jdbc:db2://localhost:50000/TESTDB'
                   and d['e2eDatabase']['schema'] == 'E2E_T2' and 'testenv' not in json.dumps(d),
                   'solution: datasource from e2e-db2, no password shown')
        v = self.ws / 'validation'
        mod = v / 't2-e2e'
        agg = (v / 'pom.xml').read_text(encoding='utf-8')
        self.check('<module>demo-e2e-parent</module>' in agg and '<module>t2-e2e</module>' in agg
                   and 'e2e:mu-modules' in agg, 'solution: aggregator with marker and module line')
        par = (v / 'demo-e2e-parent' / 'pom.xml').read_text(encoding='utf-8')
        self.check('<version>3.5.1</version>' in par and '<e2e.framework.version>0.9.0-T<' in par
                   and '<id>e2e-replay</id>' in par and '<id>e2e-record</id>' not in par and 'maven-enforcer-plugin' in par
                   and '<include>**/*Suite.java</include>' in par, 'solution: parent pins, profile, enforcer, surefire')
        self.check((v / '.gitignore').is_file() and 'REPLAY only' in (v / 'README.md').read_text(encoding='utf-8'),
                   'solution: .gitignore, README REPLAY only')
        pkgdir = mod / 'src/test/java/e2e/org/demo/t2'
        names = sorted(p.name for p in pkgdir.glob('*.java'))
        self.check(names == ['T2ApplicationSmokeTest.java', 'T2BehaviourSuite.java', 'T2ComponentTest.java',
                             'T2ParityTest.java', 'ValidationEnvironment.java'], f'solution: module classes {names}')
        mpom = (mod / 'pom.xml').read_text(encoding='utf-8')
        self.check('<e2e.assets.dir>${project.basedir}/../../mu/t2/validation/e2e</e2e.assets.dir>' in mpom
                   and '<artifactId>demo-app</artifactId>' in mpom and 'legacy-paritytester' in mpom
                   and 'SERVLET' in mpom, 'solution: module pom (assets dir, product, legacy jar, web stack)')
        yml = (mod / 'src/test/resources/application-e2e.yml').read_text(encoding='utf-8')
        self.check('SET SCHEMA ${E2E_DB_SCHEMA}' in yml and '${E2E_DB_URL}' in yml, 'solution: application-e2e.yml')
        self.check('app.main-class=org.demo.App' in (mod / 'src/test/resources/e2e/basement.properties')
                   .read_text(encoding='utf-8'), 'solution: basement.properties')
        every = [p for p in v.rglob('*') if p.is_file() and 'target' not in p.relative_to(v).parts]
        self.check(not any('{{' in p.read_text(encoding='utf-8') or '__' in p.name for p in every),
                   'solution: every placeholder rendered')
        self.check(self.listing(sol) == sol_before, 'solution: nothing written under solution/')
        code, d = self.run('solution', 'mu/t2')
        self.check(d.get('status') == 'unchanged', f'solution twice: unchanged {d.get("status")} {d.get("files")}')
        (pkgdir / 'T2ParityTest.java').write_text('broken', encoding='utf-8')
        (pkgdir / 'Stray.java').write_text('class Stray {}', encoding='utf-8')
        code, d = self.run('solution', 'mu/t2')
        fl = d.get('files') or {}
        self.check(d.get('status') == 'updated' and fl.get('moduleRepaired') == [
            'src/test/java/e2e/org/demo/t2/T2ParityTest.java'] and fl.get('moduleRemoved') == [
            'src/test/java/e2e/org/demo/t2/Stray.java'], f'solution: module repaired {fl}')
        self.product(boot='3.5.2')
        self.run('snapshot', 'mu/t2')
        code, d = self.run('solution', 'mu/t2')
        self.check(d.get('aligned') and d['aligned'][0]['item'] == 'springBootVersion' and d['aligned'][0]['to'] ==
                   '3.5.2' and '<version>3.5.2</version>' in (v / 'demo-e2e-parent/pom.xml').read_text(encoding='utf-8'),
                   f'solution: parent re-aligned {d.get("aligned")}')
        self.check(not any(x['item'] == 'springBootVersion' for x in d.get('drift', [])), 'solution: no boot drift')

    # ---------------------------------------------------------------- gate / execute (MU t2)
    def answer(self, qid, text):
        qf = self.ws / 'mu/t2/validation/validation-open-questions.md'
        lines = qf.read_text(encoding='utf-8').split('\n')
        inside = False
        for i, line in enumerate(lines):
            if line.startswith('## '):
                inside = line.startswith(f'## {qid} ')
            elif inside and line.startswith('Answer:'):
                lines[i] = f'Answer: {text}'.rstrip()
        qf.write_text('\n'.join(lines), encoding='utf-8')

    def t_gate_parse(self):
        from steps import gate as g
        known = {'TC-1', 'TC-2'}
        ok = g.parse_answer('approved by Jane Doe', known)
        self.check(ok['kind'] == 'approved' and ok['by'] == 'Jane Doe' and ok['disputed'] == {}, f'gate parse: plain {ok}')
        ok = g.parse_answer('  Approved  by  Jürgen Müller-Lüdenscheidt. ', known)
        self.check(ok['kind'] == 'approved' and ok['by'] == 'Jürgen Müller-Lüdenscheidt', f'gate parse: unicode {ok}')
        ok = g.parse_answer('approved by Jane Doe; disputed: TC-1 - stack, not mainframe, TC-2 - wrong rows', known)
        self.check(ok['kind'] == 'approved' and ok['disputed'] == {'TC-1': 'stack, not mainframe', 'TC-2': 'wrong rows'},
                   f'gate parse: disputed list with a comma in a reason {ok}')
        self.check(g.parse_answer('rejected - wrong package', known)['kind'] == 'rejected', 'gate parse: rejected')
        for bad in ('', '   ', 'yes', 'approved', 'approved by', 'approved by Jane', 'approved by me',
                    'approved by Claude', 'approved by The Agent', 'approved by the owner', 'approved by J4ne Doe',
                    'approved by <First Last>', 'approved by Jane Doe; disputed: TC-9 - x',
                    'approved by Jane Doe; disputed: TC-1', 'approved by Jane Doe; disputed:', 'rejected'):
            self.check(g.parse_answer(bad, known)['kind'] == 'unclear', f'gate parse: refused {bad!r}')

    def t_gate(self):
        e2e = self.ws / 'mu/t2/validation/e2e'
        sf = self.ws / 'mu/t2/validation/validation-state.json'
        qf = self.ws / 'mu/t2/validation/validation-open-questions.md'
        code, d = self.run('gate', 'mu/t2', 'apply')
        self.check(code == 2 and 'gate prepare' in d.get('error', ''), f'gate apply before prepare {code} {d}')
        # TC-A new (no acceptance), TC-B changed (accepted at another oracle key)
        st = json.loads(sf.read_text(encoding='utf-8'))
        st['acceptance'] = {'TC-B': {'oracleKey': 'other', 'by': 'Jane Doe', 'at': '2026-11-06T12:00:00Z'}}
        sf.write_text(json.dumps(st), encoding='utf-8')
        shutil.rmtree(e2e)
        self.run('import', 'mu/t2')
        self.run('fixtures', 'mu/t2')
        code, d = self.run('gate', 'mu/t2', 'prepare')
        self.check(code == 2 and d.get('status') == 'gate-open' and d.get('question') == 'RG-1'
                   and d.get('toDecide') == 2 and d.get('byChange') == {'new': 1, 'changed': 1},
                   f'gate prepare: RG-1 with the new and changed masters {code} {d}')
        from vlib import questions as vq
        rg = next(e for e in vq.parse(qf) if e['id'] == 'RG-1')
        self.check(rg['blocking'] and rg['status'] == 'open' and not rg['answered']
                   and '- TC-A add · new · rules R1 · expected 201, 1 table check(s) · recorded 2026-11-06T08:00:00Z'
                   in rg['evidence'] and 'TC-B text-seq · changed' in rg['evidence']
                   and 'decided by OQ-1' in rg['evidence'] and 'approved by <First Last>' in rg['evidence'],
                   f'gate prepare: RG-1 evidence lines {rg}')
        self.check('- pending decision OQ-9: OQ-9 is open (TC-A: the recording is its oracle)' in rg['evidence']
                   and '\u25c6 TC-A' not in rg['evidence'],
                   f'pending: the record gate notes a pending decision, not as decided {rg["evidence"]}')
        self.check('- Decided answers, not the recording (accepted deviations) 1, 1 with another status' in rg['evidence']
                   and '- \u25c6 TC-B text-seq · decided by OQ-1: 500' in rg['evidence']
                   and '· recorded 201 (status changed) · tables notCompared' in rg['evidence'] and '1 of them decided answers (\u25c6' in rg['question'],
                   f'fix 4: the record gate lists the decided answers, decided vs recorded {rg}')
        before = qf.read_bytes()
        code, d = self.run('gate', 'mu/t2', 'prepare')
        self.check(code == 2 and d.get('question') == 'RG-1' and qf.read_bytes() == before,
                   f'gate prepare twice: same RG-1, file unchanged {d}')
        acc_before = json.loads(sf.read_text(encoding='utf-8'))['acceptance']
        for bad in ('', 'approved by me', 'approved by The Agent', 'approved by Jane Doe; disputed: TC-Z - x',
                    'approved by Jane Doe approved by Jane Doe'):
            self.answer('RG-1', bad)
            code, d = self.run('gate', 'mu/t2', 'apply')
            self.check(code == 2 and d.get('errorCode') == 'GATE_ANSWER_REFUSED'
                       and json.loads(sf.read_text(encoding='utf-8'))['acceptance'] == acc_before
                       and next(e for e in vq.parse(qf) if e['id'] == 'RG-1')['status'] == 'open',
                       f'gate apply refuses {bad!r}: nothing written {code} {d}')
        self.answer('RG-1', 'approved by Jane Doe')
        st = json.loads(sf.read_text(encoding='utf-8'))
        real = st['gate']['digest']
        st['gate']['digest'] = 'x'
        sf.write_text(json.dumps(st), encoding='utf-8')
        code, d = self.run('gate', 'mu/t2', 'apply')
        self.check(code == 2 and 'changed since' in d.get('error', ''), f'gate apply: masters changed since prepare {d}')
        st = json.loads(sf.read_text(encoding='utf-8'))
        st['gate']['digest'] = real
        sf.write_text(json.dumps(st), encoding='utf-8')
        self.answer('RG-1', 'approved by Jane Doe; disputed: TC-B - the decided answer does not apply here')
        code, d = self.run('gate', 'mu/t2', 'apply')
        st = json.loads(sf.read_text(encoding='utf-8'))
        acc = st['acceptance']
        self.check(code == 0 and d.get('status') == 'applied' and d.get('accepted') == 1
                   and d.get('goldenStates') == {'ACCEPTED': 1, 'DISPUTED': 1}, f'gate apply: applied {code} {d}')
        self.check(set(acc) == {'TC-A', 'TC-B'} and acc['TC-A']['by'] == 'Jane Doe' and acc['TC-A']['gate'] == 'RG-1'
                   and len(acc['TC-A']['oracleKey']) > 20 and 'state' not in acc['TC-A']
                   and acc['TC-B']['state'] == 'DISPUTED' and 'does not apply' in acc['TC-B']['reason'],
                   f'gate apply: acceptance.<id> = {{oracleKey, by, at}} {acc}')
        ma, mb = self.j('mu/t2/validation/e2e/golden/E2/TC-A.json'), self.j('mu/t2/validation/e2e/golden/E2/TC-B.json')
        self.check(ma['state'] == 'ACCEPTED' and mb['state'] == 'DISPUTED' and mb['history'][-1]['by'] == 'Jane Doe',
                   'gate apply: re-import carries ACCEPTED / DISPUTED')
        self.check(next(e for e in vq.parse(qf) if e['id'] == 'RG-1')['status'] == 'settled', 'gate apply: RG-1 settled')
        code, d = self.run('gate', 'mu/t2', 'prepare')
        self.check(code == 0 and d.get('status') == 'decided' and d.get('toDecide') == 0, f'gate prepare: decided {d}')
        shutil.rmtree(e2e)
        self.run('import', 'mu/t2')
        self.run('fixtures', 'mu/t2')
        self.check(self.j('mu/t2/validation/e2e/golden/E2/TC-B.json')['state'] == 'DISPUTED'
                   and self.j('mu/t2/validation/e2e/golden/E2/TC-A.json')['state'] == 'ACCEPTED',
                   'gate: a regenerated folder gets ACCEPTED / DISPUTED back from the state')
        code, d = self.run('gate', 'mu/t2', 'apply')
        self.check(code == 0 and d.get('status') == 'unchanged', f'gate apply with nothing open: unchanged {d}')

    def canned(self, name, a_status):
        def verdict(sid, status, diffs):
            sig = [f'E2|{x["field"]}|{x["kind"]}' for x in diffs]
            return {'scenarioId': sid, 'unit': 'E2', 'level': 'L4', 'status': status, 'compared': 3,
                    'matched': 3 - len(diffs), 'diffs': [dict(x, signature=s) for x, s in zip(diffs, sig)],
                    'notes': [], 'decisions': [], 'signatures': sig}
        diffs = [] if a_status == 'PASSED' else [{'field': 'body.id', 'kind': 'VALUE', 'legacy': 'A1', 'target': 'B1'}]
        a = {'scenarioId': 'TC-A', 'level': 'L4', 'unit': 'E2', 'mode': 'REPLAY', 'status': a_status,
             'message': 'match under contract' if not diffs else "DIFF under contract: 1 difference(s): body.id",
             'strict': verdict('TC-A', 'MATCH' if not diffs else 'DIFF', diffs),
             'contract': verdict('TC-A', 'MATCH' if not diffs else 'DIFF', diffs),
             'verdictProfile': 'contract', 'notes': [], 'lens': 'service', 'title': 'add', 'hypotheses': []}
        b = {'scenarioId': 'TC-B', 'level': 'L4', 'unit': 'E2', 'mode': 'REPLAY', 'status': 'BLOCKED',
             'message': 'golden master TC-B is DISPUTED, not ACCEPTED', 'lens': 'service', 'title': 'text-seq'}
        c = {'scenarioId': 'TC-C', 'level': 'L4', 'unit': 'E2', 'mode': 'REPLAY', 'status': 'NOT_APPLICABLE',
             'message': 'not a request field', 'lens': 'service', 'title': 'no-date'}
        doc = {'mu': 't2', 'mode': 'REPLAY', 'startedAt': '2026-11-06T12:00:00Z', 'finishedAt': '2026-11-06T12:00:09Z',
               'counts': {}, 'scenarios': [a, b, c]}
        return self.w(f'_bin/{name}.json', json.dumps(doc))

    def t_execute(self):
        import socket
        import threading
        tf = self.ws / 'mu/t2/tools.yaml'
        tools = tf.read_text(encoding='utf-8')
        free = socket.socket()
        free.bind(('127.0.0.1', 0))
        down_port = free.getsockname()[1]
        free.close()
        tf.write_text(tools.replace('port: 50000\n  database: TESTDB\n  schema: E2E_T2',
                                    f'port: {down_port}\n  database: TESTDB\n  schema: E2E_T2'), encoding='utf-8')
        calls = self.mvn_calls()
        code, d = self.run('execute', 'mu/t2')
        self.check(code == 2 and d.get('errorCode') == 'DATABASE_DOWN' and self.mvn_calls() == calls,
                   f'execute: database down -> exit 2 DATABASE_DOWN, no Maven {code} {d}')
        srv = socket.socket()
        srv.bind(('127.0.0.1', 0))
        srv.listen(16)
        port = srv.getsockname()[1]
        def serve():
            try:
                while True:
                    srv.accept()[0].close()
            except OSError:
                pass
        threading.Thread(target=serve, daemon=True).start()
        tf.write_text(tools.replace('host: localhost\n  port: 50000\n  database: TESTDB\n  schema: E2E_T2',
                                    f'host: 127.0.0.1\n  port: {port}\n  database: TESTDB\n  schema: E2E_T2'),
                      encoding='utf-8')
        ok, failed = str(self.canned('ok', 'PASSED')), str(self.canned('failed', 'FAILED'))
        counter = Path(str(self.mvn_log) + '.n')
        envlog = Path(str(self.mvn_log) + '.env')
        counter.unlink(missing_ok=True)
        code, d = self.run('execute', 'mu/t2', env={'FAKE_REPLAY': json.dumps([ok, ok])})
        runs = self.ws / 'mu/t2/validation/runs'
        self.check(code == 0 and d.get('status') == 'done' and d.get('runs') == 2 and d.get('repeatable') is True
                   and d.get('counts') == {'PASSED': 1, 'FAILED': 0, 'BLOCKED': 1, 'NOT_APPLICABLE': 1, 'SKIPPED': 0}
                   and d.get('blockedNotAccepted') == 1 and d.get('identicalToPrevious') is None,
                   f'execute: two runs, counts, blocked not accepted {code} {d}')
        self.check(d.get('columns') == {'strict': {'MATCH': 1}, 'contract': {'MATCH': 1}}, f'execute: columns {d}')
        self.check('testenv' not in json.dumps(d), 'execute: no password in the answer')
        last = self.mvn_log.read_text(encoding='utf-8').splitlines()[-1]
        self.check('-Pe2e-replay' in last and '-Dmaven.test.failure.ignore=true' in last and '-pl t2-e2e -am' in last
                   and 'validation' in last and 'target/m2' in last.replace('\\', '/'), f'execute: Maven call {last}')
        env = json.loads(envlog.read_text(encoding='utf-8').splitlines()[-1])
        self.check(env.get('E2E_DB_URL') == f'jdbc:db2://127.0.0.1:{port}/TESTDB' and env.get('E2E_DB_SCHEMA') == 'E2E_T2'
                   and env.get('E2E_DB_PASSWORD') == 'testenv' and env.get('E2E_TARGET_PIN_CLOCK') == 'true'
                   and env.get('E2E_TARGET_CLOCK') == 'frozen', f'execute: run environment {env}')
        run1 = runs / d['runId']
        summ = self.j(f'mu/t2/validation/runs/{d["runId"]}/summary.json')
        self.check((run1 / 'run-1' / 'e2e-replay.json').is_file() and (run1 / 'run-2' / 'e2e-replay.json').is_file()
                   and summ['perRun'][1]['identicalToPrevious'] is True and summ['blocked'][0]['goldenState'] == 'DISPUTED'
                   and summ['other'][0]['status'] == 'NOT_APPLICABLE', 'execute: runs copied, summary.json')
        counter.unlink(missing_ok=True)
        code, d = self.run('execute', 'mu/t2', '--runs', '1', env={'FAKE_REPLAY': json.dumps([failed])})
        summ = self.j(f'mu/t2/validation/runs/{d.get("runId")}/summary.json') if d.get('runId') else {}
        self.check(code == 0 and d.get('counts', {}).get('FAILED') == 1 and d.get('identicalToPrevious') is False
                   and d.get('deltaFromPrevious', {}).get('newlyFailing') == 1 and d.get('repeatable') is None
                   and summ.get('failed', [{}])[0].get('difference', {}).get('fields') == [
                       {'path': 'body.id', 'kind': 'VALUE', 'expected': 'A1', 'actual': 'B1'}],
                   f'execute: a failed scenario read from the report, delta from the previous run {code} {d}')
        counter.unlink(missing_ok=True)
        code, d = self.run('execute', 'mu/t2', env={'FAKE_REPLAY': json.dumps([ok, failed])})
        self.check(code == 1 and d.get('errorCode') == 'NOT_REPEATABLE' and d.get('summary')
                   and (self.ws / d['summary']).is_file(), f'execute: runs differ -> exit 1 NOT_REPEATABLE {code} {d}')
        counter.unlink(missing_ok=True)
        code, d = self.run('execute', 'mu/t2', env={'FAKE_REPLAY': '[]'})
        self.check(code == 1 and d.get('errorCode') == 'E2E_REPORT_MISSING', f'execute: no report -> exit 1 {d}')
        # M4: one scenario failing on two levels is one FAILED scenario, one failure row with both levels
        two = json.loads(Path(failed).read_text(encoding='utf-8'))
        a3 = json.loads(json.dumps(two['scenarios'][0]))
        a3['level'] = 'L3'
        for v in (a3['strict'], a3['contract']):
            v['diffs'] = [{'field': 'body.x', 'kind': 'VALUE', 'legacy': '1', 'target': '2', 'signature': 'E2|body.x|VALUE'}]
            v['signatures'] = ['E2|body.x|VALUE']
        two['scenarios'].insert(1, a3)
        two_file = self.w('_bin/two-levels.json', json.dumps(two))
        counter.unlink(missing_ok=True)
        code, d = self.run('execute', 'mu/t2', '--runs', '1', env={'FAKE_REPLAY': json.dumps([str(two_file)])})
        summ = self.j(f'mu/t2/validation/runs/{d.get("runId")}/summary.json') if d.get('runId') else {}
        fl = summ.get('failed') or [{}]
        self.check(code == 0 and d.get('counts', {}).get('FAILED') == 1 and d.get('counts', {}).get('PASSED') == 0
                   and len(summ.get('failed') or []) == 1 and fl[0].get('difference', {}).get('levels') == ['L4', 'L3']
                   and {f['path'] for f in fl[0]['difference']['fields']} == {'body.id', 'body.x'}
                   and summ.get('scenarios') == 3 and summ.get('levels') == 4,
                   f'M4: execute counts per scenario, failing levels merged {code} {d.get("counts")} {fl}')
        st = self.j('mu/t2/validation/validation-state.json')
        run = st['runs'][-1]
        self.check(run.get('snapshotHash') == st['snapshot']['hash'] and run.get('contentHash')
                   and run.get('contentHash') == summ.get('package', {}).get('contentHash'),
                   f'H1: a run records the snapshot hash and the package contentHash {run}')
        lost = json.loads(Path(ok).read_text(encoding='utf-8'))
        lost['scenarios'] = [x for x in lost['scenarios'] if x['scenarioId'] != 'TC-A']
        lost_file = self.w('_bin/lost.json', json.dumps(lost))
        out = self.w('_bin/lost.log', LOG_LOST.replace('{sid}', 'TC-A'))
        counter.unlink(missing_ok=True)
        code, d = self.run('execute', 'mu/t2', '--runs', '1', env={'FAKE_REPLAY': json.dumps([str(lost_file)]),
                                                                  'FAKE_MVN_OUT': str(out)})
        summ = self.j(f'mu/t2/validation/runs/{d.get("runId")}/summary.json') if d.get('runId') else {}
        miss = summ.get('missingFromReport') or [{}]
        self.check(code == 0 and d.get('counts', {}).get('SKIPPED') == 1 and d.get('counts', {}).get('PASSED') == 0
                   and miss[0].get('scenarioId') == 'TC-A' and 'ERRORCODE=-4499' in miss[0].get('reason', '')
                   and any(o['scenarioId'] == 'TC-A' and o['status'] == 'SKIPPED' for o in summ.get('other') or [])
                   and summ['perRun'][0].get('missingFromReport') == ['TC-A'],
                   f'execute: a register scenario missing from the report is SKIPPED with the log reason {code} {d}')
        counter.unlink(missing_ok=True)
        code, d = self.run('execute', 'mu/t2', '--tags', '@rule:R1', env={'FAKE_REPLAY': json.dumps([ok, ok])})
        last = self.mvn_log.read_text(encoding='utf-8').splitlines()[-1]
        self.check(code == 0 and '-De2e.tags=@rule:R1' in last and d.get('previousRunId') is None,
                   f'execute: --tags selects, never compared with a full run {d}')
        self.db({'E2E_T2': {'T_A': 0}})
        code, d = self.run('execute', 'mu/t2', '--smoke')
        st = self.j('mu/t2/validation/validation-state.json')
        self.check(code == 0 and d.get('status') == 'booted' and d.get('step') == 'smoke'
                   and d.get('schemaTables') == {'T_A': 0} and '-Dtest=T2ApplicationSmokeTest' in
                   self.mvn_log.read_text(encoding='utf-8').splitlines()[-1]
                   and st['steps']['execute']['status'] == 'done', f'execute --smoke {code} {d}')
        st['gate'] = {'open': None}
        for f in (self.ws / 'mu/t2/validation/e2e/golden/E2').glob('*.json'):
            m = json.loads(f.read_text(encoding='utf-8'))
            m['state'] = 'RECORDED'
            f.write_text(json.dumps(m), encoding='utf-8')
        code, d = self.run('execute', 'mu/t2')
        self.check(code == 2 and d.get('errorCode') == 'RECORD_GATE_OPEN', f'execute: nothing accepted -> exit 2 {d}')
        srv.close()

    # ---------------------------------------------------------------- staleness, lint (MU t2)
    def reseal2(self, mutate):
        pf = self.ws / 'mu/t2/tests/package/E2/E2-tests.json'
        doc = json.loads(pf.read_text(encoding='utf-8'))
        mutate(doc)
        doc['package']['contentHash'] = content_hash(doc)
        pf.write_text(json.dumps(doc, indent=2) + '\n', encoding='utf-8')
        sf = self.ws / 'mu/t2/tests/tests-state.json'
        ts = json.loads(sf.read_text(encoding='utf-8'))
        ts['package']['contentHash'] = doc['package']['contentHash']
        sf.write_text(json.dumps(ts), encoding='utf-8')
        return doc['package']['contentHash']

    def why2(self):
        code, d = self.run('status', 'mu/t2')
        return [x['step'] for x in d.get('steps') or []], {x['step']: x['why'] for x in d.get('steps') or []}

    def t_staleness(self):
        import mu_validate as mv
        from vlib.common import package_hash
        sf = 'mu/t2/validation/validation-state.json'
        for step in ('preflight', 'readiness', 'framework'):
            self.run(step, 'mu/t2')
        # M1: lint is a step after fixtures; it needs the assets
        man = self.ws / 'mu/t2/validation/e2e/fixtures/manifest.json'
        keep = man.read_bytes()
        man.unlink()
        code, d = self.run('lint', 'mu/t2')
        self.check(code == 2 and 'run fixtures' in d.get('error', ''), f'M1: lint needs the fixtures {code} {d}')
        man.write_bytes(keep)
        n0 = self.mvn_calls()
        code, d = self.run('lint', 'mu/t2')
        last = self.mvn_log.read_text(encoding='utf-8').splitlines()[-1]
        st = self.j(sf)
        self.check(code == 0 and d.get('status') == 'passed' and self.mvn_calls() == n0 + 1
                   and 'verify -pl t2-e2e -am' in last and '-Pe2e-replay' not in last
                   and st['lint']['snapshotHash'] == st['snapshot']['hash'] and st['lint'].get('assetsDigest'),
                   f'M1: lint step builds the module with its assets {code} {d.get("error")} {last}')
        order, why = self.why2()
        self.check(order[order.index('fixtures') + 1] == 'lint' and order[order.index('lint') + 1] == 'gate'
                   and why['lint'] is None and why['solution'] is None and why['fixtures'] is None,
                   f'M1: stage order fixtures, lint, gate; all current {order} {why}')
        # H1 package: a new package whose oracles are unchanged
        old_pkg = package_hash(self.ws / 'mu/t2/tests/package/E2/E2-tests.json')
        run = mv.latest_run(st)
        new_pkg = self.reseal2(lambda doc: doc['rules'][0].update(text='An add writes one row, numbered.'))
        _, why = self.why2()
        self.check(why['import'] and why['fixtures'] and why['lint'] and why['execute'] and why['analyse']
                   and why['report'], f'H1: a new package makes import .. report stale {why}')
        self.check(mv.run_not_current(run, st['snapshot']['hash'], old_pkg) is None
                   and 'package' in (mv.run_not_current(run, st['snapshot']['hash'], new_pkg) or ''),
                   'H1: the last run is not of the new package')
        code, d = self.run('import', 'mu/t2')
        _, why = self.why2()
        self.check(code == 0 and why['import'] is None and 'package' in (why['fixtures'] or '') and why['lint'],
                   f'H1: after the import the fixtures are still of the old package; the import makes the lint stale '
                   f'{code} {why}')
        self.run('fixtures', 'mu/t2')
        _, why = self.why2()
        self.check(why['fixtures'] is None and 'assets' in (why['lint'] or ''), f'M1: the re-import made the lint stale {why}')
        self.run('lint', 'mu/t2')
        _, why = self.why2()
        self.check(why['lint'] is None, f'lint current again {why}')
        # H1 product: a changed solution -> new snapshot; solution, lint, execute .. report stale
        self.w('solution/app/src/main/java/org/demo/App.java',
               'package org.demo;\n\n@SpringBootApplication\npublic class App {\n    // changed\n}\n')
        self.run('snapshot', 'mu/t2')
        st = self.j(sf)
        _, why = self.why2()
        self.check(why['snapshot'] is None and 'written for snapshot' in (why['solution'] or '') and why['lint']
                   and why['execute'] and why['analyse'] and why['report'],
                   f'H1: a new snapshot makes solution .. report stale {why}')
        self.check('snapshot' in (mv.run_not_current(mv.latest_run(st), st['snapshot']['hash'], new_pkg) or ''),
                   'H1: the last run is not of the new snapshot')
        code, d = self.run('report', 'mu/t2')
        rep = (self.ws / 'mu/t2/validation/validation-report.md').read_text(encoding='utf-8')
        self.check(code == 0 and d.get('lastRunCurrent') is False and d.get('lastRunSnapshot')
                   and any('not of the current product' in w for w in d.get('warnings') or [])
                   and any('not of the current package' in w for w in d.get('warnings') or [])
                   and 'Replayed: snapshot `' in rep and '**not current**' in rep,
                   f'H1: report names the run\'s snapshot and package and warns {d}')
        code, d = self.run('solution', 'mu/t2')
        _, why = self.why2()
        self.check(code == 0 and why['solution'] is None and 'snapshot' in (why['lint'] or ''),
                   f'H1: solution current again; the lint is of the old snapshot {why}')
        self.run('lint', 'mu/t2')
        _, why = self.why2()
        self.check(why['lint'] is None and why['execute'], f'lint current; execute still due {why}')

    def t_legacy_sources(self):
        from vlib.config import Ctx
        from vlib.e2econfig import e2e_config
        from e2elib import fingerprint as efp
        ctx = Ctx('mu/t2', workspace=self.ws)
        cfg = e2e_config(ctx)
        ddl, units, sources = efp.inputs(self.ws, cfg, 'E2', {})
        self.check(cfg['paths']['legacySources'] == [] and sources == [] and [u for _, u in units] == [ctx.mu / 'unit' / 'E2'],
                   f'M6: no legacy-source folder, only unit/<E> {sources} {units}')
        mine = self.w('mu/t2/unit/E2/sources/P1.cbl', '       IDENTIFICATION DIVISION.\n')
        cobol = self.w('mu/t2/inputs/cobol/P2.cbl', '       PROGRAM-ID. P2.\n')
        doc = {'recordings': {'fp': {'members': {'P1.cbl': file_sha(mine), 'P2.cbl': file_sha(cobol)}}},
               'cases': [{'status': 'golden', 'recording': {'fingerprint': 'fp'}}]}
        m = efp.check(doc, ctx.package_dir, ddl, units, sources)[0]['members']
        self.check(m['same'] == 1 and m['not-found'] == 1 and m['missing'] == ['P2.cbl'],
                   f'M6: members hashed in unit/<E>/sources only, inputs/cobol never looked at {m}')
        bad = [f'{f.relative_to(HERE)}: {w}' for f in HERE.rglob('*.py') if f.name != 'selftest.py'
               for w in ("inputs' / 'cobol'", 'inputs/cobol', 'PARITY_TESTER_DIR', 'origin.json', 'tc-gen',
                         'e2e.tc-generation', 'constitution') if w in f.read_text(encoding='utf-8')]
        self.check(not bad, f'M6 / Low: no inputs/cobol, $PARITY_TESTER_DIR, tc-gen or constitution in the scripts {bad}')
        shutil.rmtree(self.ws / 'mu/t2/inputs')
        shutil.rmtree(self.ws / 'mu/t2/unit/E2')

    # ---------------------------------------------------------------- snapshot --solution
    def t_snapshot_override(self):
        shutil.copytree(self.ws / 'solution', self.ws / 'seeded', ignore=shutil.ignore_patterns('target'))
        self.w('seeded/app/src/main/java/A.java', 'class A { int seeded; }\n')
        sf = self.mu / 'validation' / 'validation-state.json'
        code, d = self.run('snapshot', 'mu/t1', '--solution', 'nowhere')
        self.check(code == 1 and 'no product' in d.get('error', ''), f'snapshot --solution: missing folder {d}')
        code, d = self.run('snapshot', 'mu/t1', '--solution', 'seeded')
        st = json.loads(sf.read_text(encoding='utf-8'))
        self.check(code == 0 and d.get('status') == 'built' and d.get('solution') == 'seeded'
                   and d.get('solutionSource') == 'override' and st.get('solutionOverride') == 'seeded'
                   and st['snapshot'].get('solution') == 'seeded', f'snapshot --solution: built, recorded {d}')
        code, d = self.run('snapshot', 'mu/t1', '--status')
        self.check(d.get('status') == 'current' and d.get('solution') == 'seeded',
                   f'snapshot --status follows the recorded override {d}')
        code, d = self.run('snapshot', 'mu/t1', '--solution', 'mu.yaml')
        st = json.loads(sf.read_text(encoding='utf-8'))
        self.check(code == 0 and d.get('solution') == 'solution' and 'solutionOverride' not in st,
                   f'snapshot --solution mu.yaml drops the override {d}')

    # ---------------------------------------------------------------- analyse / report
    JAVA = {
        'XController.java': (
            'package org.x.web;\n@RestController\n@RequestMapping("/x")\npublic class XController {\n'
            '    private final XService service;\n    /** create */\n    @PostMapping\n'
            '    public ResponseEntity<XResponse> create(@Valid @RequestBody XRequest request) {\n'
            '        return ResponseEntity.created(URI.create("/x/" + service.create(request))).body(new XResponse("1"));\n'
            '    }\n    @PutMapping("/{id}")\n'
            '    public ResponseEntity<XResponse> update(@PathVariable String id, @RequestBody XRequest request) {\n'
            '        return ResponseEntity.ok(new XResponse(id));\n    }\n}\n'),
        'XRequest.java': 'package org.x.dto;\npublic record XRequest(@Size(max = 4) String userIdent, BigDecimal amount,\n'
                         '        List<@NotNull @Valid XLine> lines) {\n}\n',
        'XLine.java': 'package org.x.dto;\npublic record XLine(@JsonProperty("code") String lineCode) {}\n',
        'XResponse.java': 'package org.x.dto;\npublic record XResponse(String id) {}\n',
        'Handler.java': (
            'package org.x.web;\n@RestControllerAdvice\npublic class Handler {\n'
            '    private static final String NF = "NOT_FOUND";\n'
            '    @ExceptionHandler(NotFoundException.class)\n'
            '    public ResponseEntity<Err> nf(NotFoundException e) { return error(HttpStatus.NOT_FOUND, NF, "x"); }\n'
            '    @ExceptionHandler({AlreadyExistsException.class})\n'
            '    public ResponseEntity<Err> dup(AlreadyExistsException e) {\n'
            '        return error(HttpStatus.UNPROCESSABLE_ENTITY, "ALREADY_EXISTS", "x");\n    }\n'
            '    @ExceptionHandler(Exception.class)\n'
            '    public ResponseEntity<Err> other(Exception e) { return error(HttpStatus.INTERNAL_SERVER_ERROR, "U", "x"); }\n'
            '}\n'),
        'XService.java': (
            'package org.x.service;\npublic class XService {\n    private final XDao dao;\n'
            '    public String create(XRequest r) {\n        if (r == null) { throw new NotFoundException("user"); }\n'
            '        return insert(r);\n    }\n    private String insert(XRequest r) { return dao.insert(r); }\n}\n'),
        'XDao.java': 'package org.x.dao;\npublic class XDao {\n    public String insert(XRequest r) {\n'
                     '        throw new AlreadyExistsException("dup");\n    }\n}\n',
    }

    def t3_scenario(self, sid, status, exp=None, act=None, diffs=None, outcome=None, payload=None, hypotheses=None):
        diffs = list(diffs or [])
        if exp is not None and act is not None and exp != act:
            diffs.insert(0, {'field': '$exitState', 'kind': 'EXIT_STATE', 'legacy': str(exp), 'target': str(act)})
        sig = [f'E3|{x["field"]}|{x["kind"]}' for x in diffs]
        verdict = {'scenarioId': sid, 'unit': 'E3', 'level': 'L4', 'profile': 'contract',
                   'status': 'DIFF' if diffs else 'MATCH', 'compared': 5, 'matched': 5 - len(diffs),
                   'diffs': [dict(x, pattern=None, signature=g) for x, g in zip(diffs, sig)], 'notes': [],
                   'decisions': [], 'signatures': sig}
        s = {'scenarioId': sid, 'level': 'L4', 'unit': 'E3', 'mode': 'REPLAY', 'status': status,
             'message': f'{status} {sid}', 'lens': 'service', 'title': sid.lower(), 'hypotheses': hypotheses or []}
        if status in ('PASSED', 'FAILED'):
            s.update(strict=verdict, contract=verdict, verdictProfile='contract')
        if status == 'FAILED':
            meta = {'http.request': 'POST http://localhost:1/x'}
            if act is not None:
                meta['http.status'] = str(act)
            s['target'] = {'outcome': outcome or {'kind': 'OK' if (act or 0) < 400 else 'BUSINESS_EXCEPTION',
                                                  'exitState': act},
                           'meta': meta, 'payload': payload, 'truncated': False}
        return s

    def setup_t3(self):
        m = 'mu/t3/'
        self.w(m + 'mu.yaml', 'name: t3\nentry_points: [E3]\nsolution: solution3/\n')
        self.w(m + 'tools.yaml', TOOLS.replace('# trailing comment line', '') +
               '\ne2e-db2:\n  kind: local\n  container: fake-db2\n  host: localhost\n  port: 50000\n'
               '  database: TESTDB\n  schema: E2E_T3\n  user: db2inst1\n  password: testenv\n')
        self.w(m + 'design/rules.md', '# rules\n\n## Create\n\n| # | Rule | From | Target home |\n|---|---|---|---|\n'
               '| 1 | A create reads the user. | `P` PARA-1 | `XService.create` |\n'
               '| 2 | A duplicate ends with response code `2`. | `P` PARA-2 | `XService.create` |\n'
               '| 3 | The amount is stored. | `P` PARA-3 | `XService.create` |\n'
               '| 4 | A connection is used. | `P` PARA-4 | `XService.insert` |\n'
               '| 5 | A PIF change sequence that is not a number ends the create: `500 PROCESSING_FAILED`. | `P` PARA-5 '
               '| `XService.create` |\n')
        self.w(m + 'design/tests.md', '# tests\n')
        self.w(m + 'extracted-logic/paragraph-index.json', '{"programs": {}}\n')
        self.w(m + 'unit/schema.sql', 'CREATE TABLE T_A (AMT INT);\n')

        def post(body):
            return {'method': 'POST', 'path': '/x', 'url': '/x', 'query': {}, 'body': body}

        good = {'userIdent': 'U1', 'amount': 1, 'lines': [{'code': 'A'}]}
        bad = {'userRef': 'U1', 'amount': 1, 'lines': [{'code': 'A'}]}

        def case(cid, rules, req, status, body=None, **extra):
            return {'id': cid, 'name': cid.lower(), 'origin': 'basic', 'category': 'Happy', 'ruleIds': rules,
                    'status': 'golden', 'request': req, 'expected': {'status': status, 'body': body},
                    'anticipatedJavaDivergence': [], 'stackDivergence': [], **extra}

        cases = [case('TC-B1', ['R3'], post(bad), 201, {'id': '1'}), case('TC-B2', ['R3'], post(bad), 201),
                 case('TC-B3', ['R3'], post(bad), 201), case('TC-P1', ['R1', 'R3'], post(good), 201, {'id': '1'}),
                 case('TC-P2', ['R1'], post(good), 201), case('TC-S1', ['R1', 'R2'], post(good), 409),
                 case('TC-E1', ['R4'], post(good), 201),
                 case('TC-D1', ['R3'], post(good), 201, decidedAnswer={'source': 'OQ-1', 'rules': ['R3'],
                                                                       'status': 500, 'recordedStatus': 201}),
                 case('TC-K1', ['R1'], post(good), 201), case('TC-K2', ['R1'], post(good), 201),
                 case('TC-X1', ['R3'], post(bad), 201),
                 case('TC-D2', ['R1'], post(good), 500, decidedAnswer={'source': 'OQ-2', 'rules': ['R1'], 'status': 500,
                                                                       'recordedStatus': 201, 'tables': 'notCompared'}),
                 case('TC-D3', ['R1'], post(good), 201, {'id': '1', 'z': 'a'},
                      compare=[{'path': 'z', 'mode': 'ignore', 'reason': 'OQ-4: the Java keeps its own z'}]),
                 case('TC-D4', ['R1'], post(good), 200, {'z': 'b'},
                      decidedAnswer={'source': 'OQ-5', 'rules': ['R1'], 'status': 200, 'recordedStatus': 200,
                                     'set': [{'path': 'body.z', 'value': 'b'}]}),
                 case('TC-P3', ['R1'], post(good), 400, decidedAnswer={'source': 'design.md#refuse', 'rules': ['R1'],
                                                                       'status': 400, 'recordedStatus': 201}),
                 case('TC-Q1', ['R9'], post(good), 201, decidedAnswer={'source': 'OQ-9', 'rules': ['R9'], 'status': 400,
                                                                       'recordedStatus': 201, 'pending': True,
                                                                       'reason': 'OQ-9 is open'}),
                 case('TC-Q2', ['R9'], post(good), 201, decidedAnswer={'source': 'OQ-9', 'rules': ['R9'], 'status': 500,
                                                                       'recordedStatus': 201, 'tables': 'notCompared',
                                                                       'pending': True, 'reason': 'OQ-9 is open'})]
        doc = {'package': {'schema': 'mu-build-tests/tests.schema.json', 'format': 3, 'version': 2},
               'unit': 'E3', 'api': 'POST /x', 'binding': {'operations': [
                   {'name': 'create', 'method': 'POST', 'pathTemplate': '/x',
                    'response': {'outcome': 'responseCode', 'map': {'0': {'status': 201}, '1': {'status': 404},
                                                                    '2': {'status': 409}}}}]},
               'cases': cases}
        inputs = {f: file_sha(self.ws / m / f) for f in ('design/rules.md', 'design/tests.md',
                                                         'extracted-logic/paragraph-index.json', 'unit/schema.sql')}
        doc['package'].update({'contentHash': content_hash(doc), 'inputs': inputs, 'state': 'ready'})
        self.w(m + 'tests/package/E3/E3-tests.json', json.dumps(doc, indent=2) + '\n')
        self.w(m + 'tests/tests-state.json', json.dumps({'entry': 'E3', 'state': 'ready', 'scope': 'full',
                                                         'package': {'contentHash': doc['package']['contentHash']}}))
        for name, text in self.JAVA.items():
            self.w(f'validation/target/product/aaaa000000000003/app/src/main/java/org/x/{name}', text)
        self.w('validation/target/product/aaaa000000000003/app/src/main/resources/application.yml',
               'spring:\n  jackson:\n    deserialization:\n      fail-on-unknown-properties: false\n')
        sc = self.t3_scenario
        report = {'mu': 't3', 'mode': 'REPLAY', 'startedAt': '2026-11-06T12:00:00Z',
                  'finishedAt': '2026-11-06T12:00:09Z', 'counts': {}, 'scenarios': [
                      sc('TC-B1', 'FAILED', 201, 404, payload='{"code":"NOT_FOUND","message":"user"}'),
                      sc('TC-B2', 'FAILED', 201, 404, payload='{"code":"NOT_FOUND"}'),
                      sc('TC-B3', 'FAILED', 201, 404, payload='{"code":"NOT_FOUND"}'),
                      sc('TC-P1', 'PASSED'), sc('TC-P2', 'PASSED'),
                      sc('TC-S1', 'FAILED', 409, 422, payload='{"code":"ALREADY_EXISTS"}'),
                      dict(sc('TC-S1', 'FAILED', 409, 422, payload='{"code":"ALREADY_EXISTS"}',
                              diffs=[{'field': 'body.code', 'kind': 'VALUE', 'legacy': 'DUP', 'target': 'ALREADY'}]),
                           level='L3'),
                      sc('TC-E1', 'FAILED', None, None,
                         diffs=[{'field': '$outcome', 'kind': 'OUTCOME_KIND', 'legacy': 'OK',
                                 'target': 'TECHNICAL_FAILURE'}],
                         outcome={'kind': 'TECHNICAL_FAILURE', 'message': 'Connection refused', 'exceptionType':
                                  'org.springframework.jdbc.CannotGetJdbcConnectionException'}),
                      sc('TC-D1', 'FAILED', 500, 500,
                         diffs=[{'field': 'table:T_A[1].AMT', 'kind': 'VALUE', 'legacy': '1', 'target': '0'}],
                         hypotheses=['OQ-1: the product rolls back, AMT stays 0']),
                      sc('TC-U1', 'FAILED', None, None,
                         diffs=[{'field': 'body.z', 'kind': 'VALUE', 'legacy': 'a', 'target': 'b'}]),
                      sc('TC-X1', 'FAILED', 201, 500, payload='{"code":"PROCESSING_FAILED"}',
                         outcome={'kind': 'TECHNICAL_FAILURE', 'exitState': 500}),
                      sc('TC-D2', 'FAILED', 500, 500,
                         diffs=[{'field': 'table:T_A[1].AMT', 'kind': 'VALUE', 'legacy': '1', 'target': '0'}]),
                      sc('TC-D3', 'FAILED', 201, 201,
                         diffs=[{'field': 'body.z', 'kind': 'VALUE', 'legacy': 'a', 'target': 'b'}]),
                      sc('TC-D4', 'FAILED', 200, 200,
                         diffs=[{'field': 'body.z', 'kind': 'VALUE', 'legacy': 'a', 'target': 'b'}]),
                      sc('TC-P3', 'PASSED'), sc('TC-Q1', 'PASSED'),
                      sc('TC-Q2', 'FAILED', 201, 500,
                         diffs=[{'field': 'table:T_A[1].AMT', 'kind': 'VALUE', 'legacy': '1', 'target': '0'}]),
                      sc('TC-K1', 'BLOCKED'), sc('TC-K2', 'SKIPPED')]}
        rid = '20261106T120000Z'
        self.w(f'{m}validation/runs/{rid}/run-1/e2e-replay.json', json.dumps(report))
        # the register lists TC-M1, which the report lacks (lost to a Db2 timeout); TC-X1's 500 is in the build log
        self.w(f'{m}validation/e2e/scenarios/E3.json', json.dumps({'scenarios': [
            {'scenarioId': x, 'title': x.lower(), 'status': 'runnable'}
            for x in list(dict.fromkeys(s['scenarioId'] for s in report['scenarios'])) + ['TC-M1']]}))
        self.w(f'{m}validation/runs/{rid}/run-1/replay-{rid}-1.log', LOG_LOST.replace('{sid}', 'TC-M1')
               + LOG_THROWN.replace('{sid2}', 'TC-S1').replace('{sid}', 'TC-X1'))
        self.w(f'{m}validation/runs/{rid}/run-1/application.log', 'ERROR x\norg.springframework.jdbc.'
               'CannotGetJdbcConnectionException: Connection refused\n\tat a.b(C.java)\n')
        counts = {'PASSED': 4, 'FAILED': 11, 'BLOCKED': 1, 'NOT_APPLICABLE': 0, 'SKIPPED': 1}
        snap = {'hash': 'aaaa000000000003' + '0' * 48, 'revision': 'aaaa000000000003'}
        self.w(f'{m}validation/runs/{rid}/summary.json', json.dumps({
            'format': 1, 'mu': 't3', 'entry': 'E3', 'runId': rid, 'mode': 'replay', 'finishedAt': '2026-11-06T12:00:09Z',
            'snapshot': snap, 'runs': 1, 'counts': counts,
            'columns': {'strict': {'MATCH': 2, 'DIFF': 7}, 'contract': {'MATCH': 2, 'DIFF': 7}},
            'repeatable': None, 'identicalToPrevious': None, 'selection': None, 'warnings': []}))
        self.w(f'{m}validation/e2e/golden/E3/TC-K1.json', json.dumps({'state': 'RECORDED'}))
        self.w(f'{m}validation/validation-state.json', json.dumps({
            'format': 1, 'mu': 't3', 'steps': {}, 'readiness': {'ready': True}, 'snapshot': snap,
            'framework': {'fingerprint': 'f' * 64}, 'gate': {'open': None, 'settled': 'RG-1', 'by': 'Jane Doe'},
            'runs': [{'runId': rid, 'finishedAt': '2026-11-06T12:00:09Z', 'counts': counts}]}))
        return rid

    def t_runlog(self):
        from vlib import runlog
        log = self.w('_bin/runlog.log', LOG_LOST.replace('{sid}', 'TC-P510-060')
                     + LOG_THROWN.replace('{sid2}', 'TC-P510-007').replace('{sid}', 'TC-P510-043'))
        entries = runlog.scenario_log(log)
        lost = runlog.first_exception(entries.get('TC-P510-060'))
        self.check(entries.get('TC-P510-060', {}).get('surefire', {}).get('kind') == 'ERROR'
                   and lost and lost['type'] == 'com.insurance.e2e.core.E2eException'
                   and 'ERRORCODE=-4499, SQLSTATE=08001' in lost['message']
                   and lost['causedBy'][0].startswith('java.sql.SQLTimeoutException') and 'Tests' not in entries,
                   f'runlog: the surefire ERROR of a scenario, message joined, its cause {lost}')
        thrown = runlog.product_exception(entries.get('TC-P510-043'))
        self.check(thrown and thrown['type'].endswith('ProcessingFailedException')
                   and thrown['message'] == 'PIF change sequence is not a number'
                   and thrown['frame'] == 'com.travelers.bi.revdb.revol.service.WipService.pifChangeSequence'
                                          '(WipService.java:233)'
                   and thrown['appFrames'] == ['WipService.pifChangeSequence', 'WipService.doCreate', 'WipService.create',
                                               'WipController.create']
                   and runlog.service_thrown(thrown), f'runlog: the product exception, first app frame {thrown}')
        warn = runlog.product_exception(entries.get('TC-P510-007'))
        self.check(warn and warn['type'] is None and warn['message'].endswith('WIP business event already exists')
                   and not runlog.service_thrown(warn), f'runlog: a logged business exception, no stack {warn}')
        register = [{'scenarioId': x, 'title': x.lower()} for x in ('TC-P510-007', 'TC-P510-043', 'TC-P510-060')]
        report = {'scenarios': [{'scenarioId': 'TC-P510-007', 'status': 'FAILED'},
                                {'scenarioId': 'TC-P510-043', 'status': 'FAILED'}]}
        full, rows = runlog.with_missing(report, register, log)
        self.check(len(rows) == 1 and rows[0]['scenarioId'] == 'TC-P510-060' and rows[0]['status'] == 'SKIPPED'
                   and rows[0]['missingFromReport'] and 'surefire ERROR' in rows[0]['message']
                   and 'ERRORCODE=-4499' in rows[0]['message'] and len(full['scenarios']) == 3
                   and len(report['scenarios']) == 2, f'runlog: a register scenario missing from the report {rows}')

    def t_analyse(self):
        code, d = self.run('analyse', 'mu/t1')
        self.check(code == 2 and d.get('next') == 'execute', f'analyse without a run: exit 2 {code} {d}')
        rid = self.setup_t3()
        code, d = self.run('analyse', 'mu/t3')
        by = {x['scenarioId']: x for x in d.get('byScenario') or []}
        self.check(code == 0 and d.get('status') == 'analysed' and d.get('runId') == rid and d.get('failed') == 12
                   and d.get('blocked') == 1 and d.get('skipped') == 2, f'analyse: counts {code} {d}')
        want = {'TC-B1': 'BINDING', 'TC-B2': 'BINDING', 'TC-S1': 'SOLUTION', 'TC-E1': 'ENVIRONMENT',
                'TC-D1': 'SOLUTION', 'TC-D2': 'DECISION', 'TC-D3': 'DECISION', 'TC-D4': 'DECISION',
                'TC-U1': 'UNKNOWN'}
        for sid, cls in want.items():
            self.check((by.get(sid) or {}).get('class') == cls, f'analyse: {sid} is {cls}: {by.get(sid)}')
        self.check(by.get('TC-B1', {}).get('fields') == ['userRef'] and by['TC-B1']['confidence'] == 'high',
                   f'analyse: BINDING names the unknown field, high {by.get("TC-B1")}')
        self.check(by.get('TC-S1', {}).get('rules') == ['R2'] and by['TC-S1']['confidence'] == 'high',
                   f'analyse: SOLUTION names its rule R2, high {by.get("TC-S1")}')
        self.check(by.get('TC-X1', {}).get('class') == 'SOLUTION' and by['TC-X1'].get('rules') == ['R5']
                   and by['TC-X1'].get('fields') == ['userRef'],
                   f'analyse: a 500 thrown by the service wins over a BINDING signal; suspect R5 from the message, '
                   f'the code and the failing method {by.get("TC-X1")}')
        self.check(d.get('preClasses') == {'BINDING': 3, 'SOLUTION': 4, 'ENVIRONMENT': 3, 'PACKAGE': 1,
                                           'DECISION': 3, 'UNKNOWN': 1},
                   f'analyse: classes incl. BLOCKED / SKIPPED {d.get("preClasses")}')
        an = self.j('mu/t3/validation/.tmp/analysis.json')
        f = {x['scenarioId']: x for x in an['failures']}
        s1 = f['TC-S1']
        self.check(s1['request']['controller']['method'] == 'create' and s1['request']['controller']['status'] == 201
                   and s1['rules'][1]['targetHome'] == 'XService.create'
                   and s1['rules'][1]['throws'] == {'NotFoundException': 404, 'AlreadyExistsException': 422}
                   and s1['rules'][0]['passed'] == ['TC-P1', 'TC-P2', 'TC-P3'] and s1['expected']['status'] == 409
                   and s1['actual']['status'] == 422, f'analyse: SOLUTION evidence {s1}')
        self.check(any('no exception handler produces HTTP 409' in x['signal'] for x in s1['preClass']['signals']),
                   'analyse: the handler mapping is a signal')
        self.check(f['TC-B1']['request']['requestDto'] == ['amount', 'lines', 'userIdent']
                   and f['TC-B1']['request']['unknownFields'] == ['userRef']
                   and f['TC-B1']['response']['fields'] == ['id'], f'analyse: request vs DTO {f["TC-B1"]["request"]}')
        self.check(f['TC-E1']['exception']['exceptionType'].endswith('CannotGetJdbcConnectionException')
                   and an['exceptions'][0]['count'] == 1, 'analyse: exception and the run log')
        x1 = f['TC-X1']
        self.check(x1['exception']['exceptionType'].endswith('ProcessingFailedException')
                   and x1['exception']['frame'].startswith('com.travelers.bi.revdb.revol.service.WipService.'
                                                           'pifChangeSequence')
                   and x1['exception']['serviceThrown'] is True and x1['preClass']['suspectRules'][0]['caseRule'] is False
                   and any('exception message' in w for w in x1['preClass']['suspectRules'][0]['why']),
                   f'analyse: the exception from the build log, the suspect rule with why {x1["exception"]}')
        m1 = next((x for x in an['skipped'] if x['scenarioId'] == 'TC-M1'), {})
        self.check(m1.get('class') == 'ENVIRONMENT' and m1.get('missingFromReport') is True
                   and m1.get('signal') == 'connection failure' and 'ERRORCODE=-4499' in m1.get('reason', ''),
                   f'analyse: a register scenario missing from the report, ENVIRONMENT from the log {m1}')
        pd = {x: f[x]['preClass'] for x in ('TC-D1', 'TC-D2', 'TC-D3', 'TC-D4')}
        self.check(not any(s['class'] == 'DECISION' for s in pd['TC-D1']['signals'])
                   and 'a declared divergence or hypothesis names AMT' in pd['TC-D1']['hints']
                   and any('the status is the decided answer of OQ-1' in h for h in pd['TC-D1']['hints']),
                   f'fix 6: a hypothesis naming the differing field is a hint, not DECISION {pd["TC-D1"]}')
        self.check(pd['TC-D2']['confidence'] == 'high'
                   and any('the decision of OQ-2 does not compare' in s['signal'] for s in pd['TC-D2']['signals'])
                   and any('the case does not compare: body.z' in s['signal'] for s in pd['TC-D3']['signals'])
                   and any('the answer is the decided answer of OQ-5' in s['signal'] for s in pd['TC-D4']['signals']),
                   f'fix 6: DECISION only on decided tables notCompared, compare ignore, the decided value {pd}')
        self.check(by.get('TC-Q2', {}).get('class') == 'SOLUTION' and f['TC-Q2']['decided'] is None
                   and f['TC-Q2']['expected']['status'] == 201,
                   f'pending: a pending decided answer is no decided answer, never DECISION {f["TC-Q2"]["preClass"]}')
        self.check(an['operations']['create']['failed'] == 11 and an['operations']['create']['passed'] == 4
                   and an['api']['jackson']['failOnUnknownProperties'] is False,
                   f'analyse: per operation {an["operations"]}')
        self.check(an['blocked'][0]['goldenState'] == 'RECORDED', 'analyse: BLOCKED with its golden state')
        self.check(sum(1 for x in an['failures'] if x['scenarioId'] == 'TC-S1') == 1 and s1.get('levels') == ['L4', 'L3']
                   and 'body.code' in {x['path'] for x in s1['difference']['fields']},
                   f'M4: analyse one failure per scenario, its failing levels merged {s1.get("levels")}')
        draft = (self.ws / 'mu/t3/validation/.tmp/failures-draft.md').read_text(encoding='utf-8')
        self.check(f'Run {rid}' in draft and '## TC-S1 - tc-s1' in draft
                   and 'Class: SOLUTION · Confidence: high' in draft and 'Hints: the status is the decided answer of OQ-1' in draft
                   and 'Suspect rules: R2 (`XService.create`)' in draft and '{{' not in draft
                   and '- TC-K1 BLOCKED -> PACKAGE' in draft, 'analyse: the draft from templates/failures.md')
        self.draft = draft

    def t_report(self):
        rid = '20261106T120000Z'
        code, d = self.run('report', 'mu/t3')
        rep = (self.ws / 'mu/t3/validation/validation-report.md').read_text(encoding='utf-8')
        self.check(code == 0 and d.get('status') == 'written' and d.get('confirmed') is False
                   and d.get('classes', {}).get('BINDING') == 3 and d.get('package') == 'ready', f'report: written {d}')
        nxt = ' '.join(d.get('next') or [])
        self.check(slash_command('mu-build-tests') + ' mu/t3 entry=E3' in nxt and 'userRef' in nxt and 'mu-implement' in nxt
                   and 'R2' in nxt and 'environment' in nxt and 'TC-U1' in nxt, f'report: next moves {nxt}')
        self.check('(fields: userRef x3)' in nxt and 'SOLUTION 4: R2 (`XService.create`) x1: TC-S1; '
                   'R5 (`XService.create`) x1: TC-X1; no suspect rule: TC-D1' in nxt and 'ENVIRONMENT 3: TC-E1; TC-K2 (SKIPPED' in nxt
                   and 'TC-M1 (SKIPPED, not in the framework report (surefire ERROR)' in nxt,
                   f'report: next move lists every SOLUTION rule with counts, BINDING field, ENVIRONMENT item {nxt}')
        self.check(f'| {rid} | 2026-11-06T12:00:09Z | 1 | 4 (3 as the legacy · \u25c6 1 as decided) | 11 | 1 | 0 | 1 '
                   '| DIFF 7 · MATCH 2 | DIFF 7 · MATCH 2 | - | - |' in rep and 'snapshot `aaaa000000000003`' in rep and 'e2e-db2 `E2E_T3`' in rep
                   and 'RG-1 settled by Jane Doe' in rep and 'not yet confirmed' in rep and '{{' not in rep,
                   f'report: runs table, header {rep}')
        dd = d.get('lastDecided') or {}
        self.check(dd.get('scenarios') == 4 and dd.get('passed') == 1 and dd.get('failed') == 3
                   and dd.get('passedBySource') == {'design.md#refuse': 1}
                   and dd.get('failedBySource') == {'OQ-1': 1, 'OQ-2': 1, 'OQ-5': 1}
                   and f'## Decided answers of run {rid}' in rep
                   and 'PASSED 4: 3 as the legacy · \u25c6 1 as decided (accepted deviation' in rep
                   and '- pending decision OQ-9: OQ-9 is open (TC-Q1: compared with the recording)' in rep
                   and '\u25c6 TC-Q1' not in rep and '\u25c6 TC-Q2' not in rep
                   and set(d.get('pendingDecisions') or {}) == {'TC-Q1', 'TC-Q2'}
                   and '- \u25c6 TC-P3 tc-p3 · PASSED · decided 400 by design.md#refuse · recorded 201 (status changed)'
                   in rep and '\u25c6 FAILED 3 - ' in rep and '- \u25c6 TC-D2 DECISION (high)' in rep,
                   f'fix 4: PASSED split as the legacy / as decided, the decided answers with \u25c6 {dd} {rep}')
        self.w('mu/t3/validation/failures.md', self.draft.replace(
            '## TC-U1 - tc-u1\n\nClass: UNKNOWN · Confidence: low',
            '## TC-U1 - tc-u1\n\nClass: SOLUTION · Confidence: medium'))
        code, d = self.run('report', 'mu/t3')
        self.check(d.get('confirmed') is True and d.get('classes', {}).get('SOLUTION') == 5
                   and 'UNKNOWN' not in d.get('classes', {}), f'report: classes from failures.md {d}')
        st = self.j('mu/t3/validation/validation-state.json')
        st.update(runs=[], gate={'open': 'RG-2'})
        shutil.rmtree(self.ws / 'mu/t3/validation/runs')
        self.w('mu/t3/validation/validation-state.json', json.dumps(st))
        code, d = self.run('report', 'mu/t3')
        self.check(any('RG-2 waits' in x for x in d.get('next') or []), f'report: gate open is the next move {d}')
        (self.ws / 'mu/t3/design/tests.md').write_text('# tests changed\n', encoding='utf-8')
        code, d = self.run('report', 'mu/t3')
        rep = (self.ws / 'mu/t3/validation/validation-report.md').read_text(encoding='utf-8')
        self.check(code == 0 and '## Do this first' in rep and slash_command('mu-build-tests') + ' mu/t3 entry=E3' in rep,
                   f'report: not ready -> do this first {d}')

    def main(self):
        try:
            self.setup()
            for t in (self.t_seal, self.t_preflight, self.t_readiness, self.t_framework, self.t_snapshot,
                      self.t_state_questions, self.t_settle, self.t_import, self.t_fixtures, self.t_gate_parse,
                      self.t_gate, self.t_solution, self.t_execute, self.t_staleness, self.t_legacy_sources,
                      self.t_snapshot_override, self.t_runlog, self.t_analyse, self.t_report):
                t()
        finally:
            if not self.keep:
                shutil.rmtree(self.ws, ignore_errors=True)
        doc = {'status': 'ok' if not self.fails else 'failed', 'checks': self.n, 'failed': self.fails,
               **({'workspace': str(self.ws)} if self.keep else {})}
        print(json.dumps(doc))
        return 0 if not self.fails else 1


if __name__ == '__main__':
    sys.exit(T('--keep' in sys.argv).main())
