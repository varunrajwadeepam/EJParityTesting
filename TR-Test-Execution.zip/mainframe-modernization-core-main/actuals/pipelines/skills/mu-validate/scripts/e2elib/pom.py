"""Minimal, read-only POM parsing (xml.etree), the parent chain on disk, and the two POM edits the pipeline makes: a
module line and a version value."""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path

from .common import E2eError

NS = {"m": "http://maven.apache.org/POM/4.0.0"}
MODULE_MARKER = "<!-- e2e:mu-modules"


@dataclass
class Pom:
    path: Path
    group_id: str | None
    artifact_id: str
    version: str | None
    packaging: str
    parent_group_id: str | None = None
    parent_artifact_id: str | None = None
    parent_version: str | None = None
    parent_relative_path: str | None = None    # None: Maven's default ../pom.xml; "": never looked up on disk
    modules: list[str] = field(default_factory=list)
    properties: dict[str, str] = field(default_factory=dict)
    plugins: list[str] = field(default_factory=list)
    imports: list[tuple[str | None, str | None, str | None]] = field(default_factory=list)  # BOMs: (g, a, v)

    @property
    def effective_group_id(self) -> str | None:
        return self.group_id or self.parent_group_id

    @property
    def effective_version(self) -> str | None:
        return self.version or self.parent_version


def _text(element, path: str) -> str | None:
    found = element.find(path, NS)
    return found.text.strip() if found is not None and found.text else None


def read_pom(path: Path) -> Pom:
    try:
        root = ET.parse(path).getroot()
    except FileNotFoundError:
        raise E2eError("POM_NOT_FOUND", f"{path} does not exist")
    except ET.ParseError as exc:
        raise E2eError("POM_MALFORMED", f"{path} is not well-formed XML: {exc}")
    if not root.tag.endswith("project"):
        raise E2eError("POM_MALFORMED", f"{path} is not a Maven POM")
    if not root.tag.startswith("{"):
        # A POM without the namespace: re-qualify the lookups.
        for element in root.iter():
            element.tag = "{%s}%s" % (NS["m"], element.tag)
    properties = {}
    props = root.find("m:properties", NS)
    if props is not None:
        for child in props:
            properties[child.tag.split("}")[-1]] = (child.text or "").strip()
    plugins = []
    for plugin in root.findall("m:build/m:plugins/m:plugin", NS):
        artifact = _text(plugin, "m:artifactId")
        if artifact:
            plugins.append(artifact)
    imports = [(_text(d, "m:groupId"), _text(d, "m:artifactId"), _text(d, "m:version"))
               for d in root.findall("m:dependencyManagement/m:dependencies/m:dependency", NS)
               if _text(d, "m:scope") == "import"]
    relative = root.find("m:parent/m:relativePath", NS)
    return Pom(
        path=path,
        group_id=_text(root, "m:groupId"),
        artifact_id=_text(root, "m:artifactId") or "",
        version=_text(root, "m:version"),
        packaging=_text(root, "m:packaging") or "jar",
        parent_group_id=_text(root, "m:parent/m:groupId"),
        parent_artifact_id=_text(root, "m:parent/m:artifactId"),
        parent_version=_text(root, "m:parent/m:version"),
        parent_relative_path=None if relative is None else (relative.text or "").strip(),
        modules=[m.text.strip() for m in root.findall("m:modules/m:module", NS) if m.text],
        properties=properties,
        plugins=plugins,
        imports=imports,
    )


def lineage(path: Path) -> list[Pom]:
    """The POM and its parents on disk, nearest first - the chain Maven follows through ``relativePath``.

    A parent is followed when its relativePath (default ``../pom.xml``; a folder means its ``pom.xml``) holds a POM with
    the parent's groupId and artifactId. An empty ``<relativePath/>`` or a parent found elsewhere (a repository parent
    such as spring-boot-starter-parent) ends the chain; the last POM's ``parent_*`` fields still name that parent.
    """
    chain = [read_pom(path)]
    seen = {path.resolve()}
    while True:
        child = chain[-1]
        if not child.parent_artifact_id or child.parent_relative_path == "":
            return chain
        candidate = child.path.parent / (child.parent_relative_path or "../pom.xml")
        if candidate.is_dir():
            candidate = candidate / "pom.xml"
        candidate = candidate.resolve()
        if candidate in seen or not candidate.is_file():
            return chain
        parent = read_pom(candidate)
        if (parent.effective_group_id, parent.artifact_id) != (child.parent_group_id, child.parent_artifact_id):
            return chain
        seen.add(candidate)
        chain.append(parent)


def inherited_properties(chain: list[Pom]) -> dict[str, str]:
    """The properties of a :func:`lineage` as Maven merges them: a child's value overrides its parent's."""
    merged: dict[str, str] = {}
    for member in reversed(chain):
        merged.update(member.properties)
    return merged


_REFERENCE = re.compile(r"\$\{([^}]+)\}")


def interpolate(value: str | None, properties: dict[str, str]) -> str | None:
    """Resolve ``${name}`` references from ``properties``, nested ones too; an unknown reference is left as it is."""
    for _ in range(10):
        if value is None or "${" not in value:
            break
        resolved = _REFERENCE.sub(lambda m: properties.get(m.group(1), m.group(0)), value)
        if resolved == value:
            break
        value = resolved
    return value


_MODULE = re.compile(r"<module>\s*([^<\s]+)\s*</module>")


def ensure_module(aggregator: Path, module: str) -> bool:
    """Add ``<module>module</module>`` to an E2E-owned aggregator, idempotently.

    MU module lines live below the ``e2e:mu-modules`` marker and are kept sorted; a line that already exists anywhere
    in ``<modules>`` is left alone. Returns True when the file changed. The rest of the file is never touched.
    """
    text = aggregator.read_text(encoding="utf-8")
    if module in _MODULE.findall(text):
        return False
    marker = text.find(MODULE_MARKER)
    if marker < 0:
        raise E2eError("AGGREGATOR_MARKER_MISSING",
                       f"{aggregator} has no '{MODULE_MARKER} ...' marker; it was not generated by the basement "
                       "archetype - refusing to edit it")
    line_start = text.rfind("\n", 0, marker) + 1
    indent = text[line_start:marker]
    after_marker = text.index("\n", marker) + 1
    closing = text.index("</modules>", after_marker)
    existing = _MODULE.findall(text[after_marker:closing])
    lines = sorted(set(existing) | {module})
    block = "".join(f"{indent}<module>{name}</module>\n" for name in lines)
    closing_line_start = text.rfind("\n", 0, closing) + 1
    updated = text[:after_marker] + block + text[closing_line_start:]
    with aggregator.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(updated)
    return True


_HIDDEN = re.compile(r"<!--.*?-->|<profiles>.*?</profiles>", re.S)
_PARENT_VERSION = re.compile(r"<parent>(?:(?!</parent>).)*?<version>([^<]*)</version>", re.S)
_PROPERTIES = re.compile(r"<properties>.*?</properties>", re.S)


def set_versions(path: Path, parent_version: str | None = None, properties: dict[str, str] | None = None) -> list[dict]:
    """Rewrite version values of a POM in place: its ``<parent>``'s ``<version>`` and top-level properties.

    Every other byte stays as it is (comments, profiles, layout, line endings); a property the POM does not declare is
    not added.
    Returns one ``{"item", "from", "to"}`` per value changed (``item`` ``parent.version`` or the property name).
    """
    with path.open(encoding="utf-8", newline="") as handle:
        text = handle.read()
    changes = []

    def replace(found, item: str, value: str) -> None:
        nonlocal text
        if found and found.group(1).strip() != value:
            changes.append({"item": item, "from": found.group(1).strip(), "to": value})
            text = text[:found.start(1)] + value + text[found.end(1):]

    def masked() -> str:            # comments and profiles blanked out: nothing inside them is matched or edited
        return _HIDDEN.sub(lambda m: " " * len(m.group(0)), text)

    if parent_version is not None:
        replace(_PARENT_VERSION.search(masked()), "parent.version", parent_version)
    for name, value in (properties or {}).items():
        shadow = masked()
        block = _PROPERTIES.search(shadow)
        if block:
            tag = re.compile(rf"<{re.escape(name)}>([^<]*)</{re.escape(name)}>")
            replace(tag.search(shadow, block.start(), block.end()), name, value)
    if changes:
        with path.open("w", encoding="utf-8", newline="") as handle:
            handle.write(text)
    return changes
