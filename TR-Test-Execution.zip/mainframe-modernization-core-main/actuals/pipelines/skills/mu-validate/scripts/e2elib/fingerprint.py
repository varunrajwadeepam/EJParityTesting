"""The recordings' fingerprint against E2E's own inputs: was the package recorded on the DDL E2E builds its schema
from, on the fixture the package ships, with the driver and the legacy sources E2E can read?

A package names, per recording fingerprint, the hashes of what its recordings ran on (``recordings.<fingerprint>``:
``ddl`` {path, sha256}, ``fixture`` {name, sha256}, ``driver``, ``members`` {file: sha256}, ...). A text file's hash
depends on its line endings - a producer on a CRLF checkout hashes CRLF bytes - so a file is the same when its raw
bytes, its LF form or its CRLF form has the recorded hash; ``form`` says which. Read only.
"""

from __future__ import annotations

from pathlib import Path

from .common import resolve_from, sha256_bytes

FORMS = ("raw", "LF", "CRLF")
SHOWN = 10


def ddl_candidates(workspace: Path, config: dict, doc: dict | None = None) -> list[tuple[str, Path]]:
    """The DDL files a unit's recordings are compared with (label, file): ``database.ddlSources`` (mu-validate:
    mu/<MU>/unit/schema.sql), and for a package of format 3 the DDL its recordings name (``recordings.<fp>.ddl.path``)
    under ``paths.parityTester`` when one is configured (mu-validate: none)."""
    found = [(f"database.ddlSources[{n}]", resolve_from(workspace, entry))
             for n, entry in enumerate((config.get("database") or {}).get("ddlSources") or [])]
    block = doc.get("package") if isinstance((doc or {}).get("package"), dict) else {}
    if block.get("format") != 3:
        return found
    homes = [("paths.parityTester", (config.get("paths") or {}).get("parityTester"))]
    for entry in (doc.get("recordings") or {}).values() if isinstance(doc.get("recordings"), dict) else []:
        ddl = entry.get("ddl") if isinstance(entry, dict) else None
        if isinstance(ddl, dict) and ddl.get("path"):
            for label, home in homes:
                if home:
                    candidate = (f"{label}/{ddl['path']}", resolve_from(workspace, home) / str(ddl["path"]))
                    if candidate not in found:
                        found.append(candidate)
    return found


def inputs(workspace: Path, config: dict, unit: str, doc: dict | None = None) -> tuple[list, list, list]:
    """What E2E can compare a unit's recordings with, from the MU's configuration (vlib/e2econfig.py): the DDL sources
    (``ddl_candidates``), the unit's folder mu/<MU>/unit/<E> (driver.cbl, sources/: hashed only, never read or
    printed), the legacy-source folders (mu-validate: none)."""
    ddl = ddl_candidates(workspace, config, doc)
    paths, engine = config.get("paths") or {}, config.get("engine") or {}
    units = []
    if engine.get("catalogueDir"):
        units.append(("the engine catalogue", resolve_from(workspace, engine["catalogueDir"]) / unit))
    if paths.get("parityTester"):
        units.append(("the parity-tester workspace", resolve_from(workspace, paths["parityTester"]) / "workspace" / unit))
    sources = [(f"paths.legacySources[{n}]", resolve_from(workspace, entry))
               for n, entry in enumerate(paths.get("legacySources") or [])]
    return ddl, units, sources


def forms(data: bytes) -> dict[str, str]:
    """The SHA-256 of a file's raw bytes, of its LF form and of its CRLF form."""
    lf = data.replace(b"\r\n", b"\n")
    return {"raw": sha256_bytes(data), "LF": sha256_bytes(lf), "CRLF": sha256_bytes(lf.replace(b"\n", b"\r\n"))}


def match(recorded: str, candidates: list[tuple[str, Path]]) -> dict:
    """``same`` (with the source and the form), ``differs`` (a candidate exists, none has the hash) or ``not-found``."""
    present = [(label, path) for label, path in candidates if path.is_file()]
    for label, path in present:
        hashes = forms(path.read_bytes())
        for form in FORMS:
            if hashes[form] == recorded:
                return {"status": "same", "source": label, "form": form}
    if present:
        return {"status": "differs", "source": present[0][0], "sha256": forms(present[0][1].read_bytes())["raw"][:12]}
    return {"status": "not-found"}


def _sha(value) -> str | None:
    if isinstance(value, dict):
        value = value.get("sha256")
    return value if isinstance(value, str) and value else None


def check(doc: dict, package_folder: Path, ddl_sources: list[tuple[str, Path]], unit_dirs: list[tuple[str, Path]],
          source_dirs: list[tuple[str, Path]]) -> list[dict]:
    """Per recording fingerprint the golden cases name: the DDL against ``ddl_sources`` (label, file), the fixture
    against the package's file, the driver against ``<unit dir>/driver.cbl``, every member against
    ``<unit dir>/sources/<file>`` and ``<source dir>/<file>``."""
    recordings = doc.get("recordings") if isinstance(doc.get("recordings"), dict) else {}
    used: dict[str, int] = {}
    for case in doc.get("cases", []):
        recording = case.get("recording") if isinstance(case, dict) and case.get("status") == "golden" else None
        if isinstance(recording, dict) and recording.get("fingerprint") is not None:
            used[str(recording["fingerprint"])] = used.get(str(recording["fingerprint"]), 0) + 1
    results = []
    for fingerprint, cases in sorted(used.items()):
        entry = recordings.get(fingerprint) if isinstance(recordings.get(fingerprint), dict) else {}
        result = {"fingerprint": fingerprint, "cases": cases}
        ddl = entry.get("ddl")
        if _sha(ddl):
            result["ddl"] = {"path": ddl.get("path") if isinstance(ddl, dict) else None, "recorded": _sha(ddl)[:12],
                             **(match(_sha(ddl), ddl_sources) if ddl_sources else {"status": "no-source"})}
        fixture = entry.get("fixture")
        if _sha(fixture) and isinstance(fixture, dict) and fixture.get("name"):
            result["fixture"] = {"name": fixture["name"], "recorded": _sha(fixture)[:12],
                                 **match(_sha(fixture), [("package", package_folder / str(fixture["name"]))])}
        if _sha(entry.get("driver")):
            result["driver"] = {"recorded": _sha(entry["driver"])[:12],
                                **match(_sha(entry["driver"]), [(label, d / "driver.cbl") for label, d in unit_dirs])}
        members = entry.get("members") if isinstance(entry.get("members"), dict) else {}
        if members:
            counts = {"same": 0, "differs": 0, "not-found": 0}
            differing, missing, found_in = [], [], set()
            for name, sha in sorted(members.items()):
                candidates = [(label, d / "sources" / name) for label, d in unit_dirs] + \
                             [(label, d / name) for label, d in source_dirs]
                found = match(str(sha), candidates)
                counts[found["status"]] += 1
                if found["status"] == "same":
                    found_in.add(found["source"])
                (differing if found["status"] == "differs" else missing if found["status"] == "not-found"
                 else []).append(name)
            result["members"] = {"recorded": len(members), **counts, "foundIn": sorted(found_in),
                                 "differing": differing[:SHOWN], "missing": missing[:SHOWN]}
        results.append(result)
    return results


def describe(results: list[dict]) -> list[str]:
    """One line per fingerprint for the reports."""
    lines = []
    for r in results:
        parts = []
        for key, label in (("ddl", "DDL"), ("fixture", "fixture"), ("driver", "driver")):
            item = r.get(key)
            if not item:
                continue
            status = item["status"]
            parts.append(f"{label} " + {
                "same": f"= {item.get('source')} ({item.get('form')} form)",
                "differs": f"**differs** from {item.get('source')} (recorded {item['recorded']}, E2E's {item.get('sha256')})",
                "not-found": "not found", "no-source": "not compared (no database.ddlSources)"}[status])
        members = r.get("members")
        if members:
            parts.append(f"legacy sources {members['same']} of {members['recorded']} the same"
                         + (f" (in {', '.join(members['foundIn'])})" if members["foundIn"] else "")
                         + (f", **{members['differs']} differ** ({', '.join(members['differing'])})"
                            if members["differs"] else "")
                         + (f", {members['not-found']} not found" if members["not-found"] else ""))
        lines.append(f"fingerprint {r['fingerprint']} ({r['cases']} recordings): " + "; ".join(parts))
    return lines
