"""A table-definition subset from DDL sources - the E2E-owned schema built from the schema the recordings ran on.

``subset`` takes the tables the fixtures touch, finds each one's ``CREATE TABLE`` in the first source that defines it,
keeps its columns, primary key and other constraints, drops every foreign key to a table outside the subset (and
lists it), adds the table's ``CREATE [UNIQUE] INDEX`` statements, and orders the tables so that a referenced table is
created before the tables referencing it. Statements are split like the framework's ``SqlScript`` (``;`` outside
quotes and comments); names are compared unqualified and in upper case.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

_CREATE_TABLE = re.compile(r"^\s*CREATE\s+TABLE\s+(?:\"?(\w+)\"?\.)?\"?(\w+)\"?\s*\(", re.I)
_CREATE_INDEX = re.compile(r"^\s*CREATE\s+(?:UNIQUE\s+)?INDEX\s+\S+\s+ON\s+(?:\"?\w+\"?\.)?\"?(\w+)\"?", re.I)
_REFERENCES = re.compile(r"\bREFERENCES\s+(?:\"?\w+\"?\.)?\"?(\w+)\"?", re.I)
_FOREIGN_KEY = re.compile(r"\bFOREIGN\s+KEY\b", re.I)
_TOUCHED = re.compile(r"^\s*(?:DELETE\s+FROM|INSERT\s+INTO|UPDATE)\s+(?:\"?\w+\"?\.)?\"?(\w+)\"?", re.I)


def split(script: str) -> list[str]:
    """Statements on ``;``, respecting ``'..'`` / ``".."`` (doubled quotes escape), ``--`` and block comments."""
    statements, current, i, n = [], [], 0, len(script)
    while i < n:
        c = script[i]
        nxt = script[i + 1] if i + 1 < n else ""
        if c == "-" and nxt == "-":
            while i < n and script[i] != "\n":
                i += 1
            continue
        if c == "/" and nxt == "*":
            end = script.find("*/", i + 2)
            i = n if end < 0 else end + 2
            current.append(" ")
            continue
        if c in "'\"":
            start = i
            i += 1
            while i < n:
                if script[i] == c:
                    if i + 1 < n and script[i + 1] == c:
                        i += 2
                        continue
                    break
                i += 1
            current.append(script[start:min(i + 1, n)])
            i += 1
            continue
        if c == ";":
            _add(statements, current)
            i += 1
            continue
        current.append(c)
        i += 1
    _add(statements, current)
    return statements


def _add(statements: list[str], current: list[str]) -> None:
    text = "".join(current).strip()
    if text:
        statements.append(text)
    current.clear()


def touched_tables(statements: list[str]) -> list[str]:
    """Tables a fixture deletes from, inserts into or updates, first mention first, upper case (``SqlScript.tables``)."""
    tables = []
    for statement in statements:
        match = _TOUCHED.match(statement)
        if match and match.group(1).upper() not in tables:
            tables.append(match.group(1).upper())
    return tables


@dataclass
class Table:
    name: str
    columns: list[str]                      # column and constraint items, as written
    suffix: str                             # whatever follows the closing parenthesis
    indexes: list[str] = field(default_factory=list)
    order: int = 0

    def references(self) -> set[str]:
        return {m.group(1).upper() for item in self.columns if _FOREIGN_KEY.search(item)
                for m in _REFERENCES.finditer(item)}


def _top_level_items(text: str) -> list[str]:
    items, depth, current, quote = [], 0, [], ""
    for ch in text:
        if quote:
            current.append(ch)
            if ch == quote:
                quote = ""
            continue
        if ch in "'\"":
            quote = ch
        elif ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif ch == "," and depth == 0:
            items.append("".join(current).strip())
            current = []
            continue
        current.append(ch)
    if "".join(current).strip():
        items.append("".join(current).strip())
    return items


def parse(script: str) -> dict[str, Table]:
    """The tables (with their indexes) a DDL script defines, keyed by upper-case name, in definition order."""
    tables: dict[str, Table] = {}
    indexes: list[tuple[str, str]] = []
    for statement in split(script):
        create = _CREATE_TABLE.match(statement)
        if create:
            name = create.group(2).upper()
            open_at = statement.index("(", create.end() - 1)
            depth, close_at = 0, -1
            for i in range(open_at, len(statement)):
                if statement[i] == "(":
                    depth += 1
                elif statement[i] == ")":
                    depth -= 1
                    if depth == 0:
                        close_at = i
                        break
            if close_at < 0:
                continue
            if name not in tables:
                tables[name] = Table(name, _top_level_items(statement[open_at + 1:close_at]),
                                     statement[close_at + 1:].strip(), order=len(tables))
            continue
        index = _CREATE_INDEX.match(statement)
        if index:
            indexes.append((index.group(1).upper(), statement))
    for table, statement in indexes:
        if table in tables:
            tables[table].indexes.append(statement)
    return tables


@dataclass
class Subset:
    statements: list[str]
    tables: list[str]                        # creation order
    omitted_foreign_keys: list[dict]
    missing: list[str]
    defined_by: dict[str, str]               # table -> source label


def subset(needed: list[str], sources: list[tuple[str, str]]) -> Subset:
    """The DDL for ``needed`` from ``sources`` (label, script) - the first source defining a table wins."""
    parsed = [(label, parse(script)) for label, script in sources]
    chosen: dict[str, Table] = {}
    defined_by: dict[str, str] = {}
    missing = []
    for name in (n.upper() for n in needed):
        for label, tables in parsed:
            if name in tables:
                chosen[name] = tables[name]
                defined_by[name] = label
                break
        else:
            missing.append(name)
    omitted = []
    kept_columns: dict[str, list[str]] = {}
    for name, table in chosen.items():
        kept = []
        for item in table.columns:
            if _FOREIGN_KEY.search(item):
                targets = {m.group(1).upper() for m in _REFERENCES.finditer(item)}
                outside = sorted(t for t in targets if t not in chosen)
                if outside:
                    omitted.append({"table": name, "constraint": " ".join(item.split()), "references": outside})
                    continue
            kept.append(item)
        kept_columns[name] = kept
    ordered = _parents_first(chosen, kept_columns)
    statements = []
    for name in ordered:
        table = chosen[name]
        body = ",\n  ".join(kept_columns[name])
        statements.append(f"CREATE TABLE {name} (\n  {body}\n){(' ' + table.suffix) if table.suffix else ''}")
        statements.extend(" ".join(index.split()) for index in table.indexes)
    return Subset(statements, ordered, omitted, missing, defined_by)


def _parents_first(chosen: dict[str, Table], kept: dict[str, list[str]]) -> list[str]:
    references = {name: {m.group(1).upper() for item in kept[name] if _FOREIGN_KEY.search(item)
                         for m in _REFERENCES.finditer(item)} - {name}
                  for name in chosen}
    ordered, placed = [], set()
    pending = sorted(chosen, key=lambda n: (chosen[n].order, n))
    while pending:
        progress = False
        for name in list(pending):
            if references[name] <= placed:
                ordered.append(name)
                placed.add(name)
                pending.remove(name)
                progress = True
        if not progress:                    # a reference cycle: keep the definition order for the rest
            ordered.extend(pending)
            break
    return ordered


def render(result: Subset, header_lines: list[str]) -> str:
    lines = [f"-- {line}" for line in header_lines]
    if result.omitted_foreign_keys:
        lines.append("-- Foreign keys omitted (they reference tables outside this schema):")
        lines.extend(f"--   {fk['table']}: {fk['constraint']}" for fk in result.omitted_foreign_keys)
    lines.append("")
    return "\n".join(lines) + "\n" + ";\n\n".join(result.statements) + ";\n"


def foreign_key_children(needed: list[str], sources: list[tuple[str, str]]) -> list[str]:
    """The tables of the sources that reference one of ``needed`` - directly or through another such table - in source
    order: the tables a write unit's recording emptied with its own (the generator empties a table's foreign-key
    children first)."""
    tables: dict[str, Table] = {}
    for _, text in sources:
        for name, table in parse(text).items():
            tables.setdefault(name, table)
    found, wanted = [], {n.upper() for n in needed}
    grew = True
    while grew:
        grew = False
        for name, table in tables.items():
            if name not in wanted and table.references() & wanted:
                wanted.add(name)
                found.append(name)
                grew = True
    return found


def recording_ddls(docs: list[dict]) -> list[dict]:
    """The distinct DDLs the recordings of the packages ran on (``recordings.<fp>.ddl``: ``path`` as the producer saw it,
    ``sha256`` of the file) - package format 3 records them."""
    found = {}
    for doc in docs:
        for recording in (doc.get("recordings") or {}).values() if isinstance(doc.get("recordings"), dict) else []:
            ddl = recording.get("ddl") if isinstance(recording, dict) else None
            if isinstance(ddl, dict) and ddl.get("path") and ddl.get("sha256"):
                found.setdefault(ddl["sha256"], {"path": str(ddl["path"]), "sha256": str(ddl["sha256"])})
    return list(found.values())
