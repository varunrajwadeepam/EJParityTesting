"""The Behaviour Specification of a golden-master package: one generated ``features/<UNIT>.feature``.

One feature per package; a ``Rule:`` per package rule (its text from the package JSON); one scenario per case,
under the most specific rule that cites it (the fewest proving cases; ties by rule order) - cases no rule cites come
before the first rule. The scenario's tags are the register's tag vocabulary (``Scenario.effectiveTags`` plus the
scenario id), so a tag means the same to both runners. mu-validate has no BA alignment: the story / business-scenario
parts below are never reached. The steps state what the register
and the golden master hold and nothing else: the framework's glue checks each of them (a lint) and executes the
scenario through the same runner as the register-driven tests. The golden master stays the one oracle - the lines below
a ``Then`` only repeat it. A format-3 case also shows its request body and, when the package checks tables, how many
rows each table holds after the call.

The text is deterministic (LF, stable order): the same package, rules and golden masters give the same bytes.
"""

from __future__ import annotations

import re
import textwrap

from . import canonical

WIDTH = 110
SET_STEP = "And the answer's rows are compared as a set, in any order"
LIST_SET_STEP = 'And the list "{}" is compared as a set, in any order'
IGNORE_STEP = 'And the field "{}" is not compared'
CALLER_STEP = '{} the caller is the user "{}"'
DECIDED_STEP = 'And the answer is decided by "{}", the recording answers {}'
DECIDED_ONLY_STEP = 'And the answer is decided by "{}"'
SHOWN_ROWS = 3
_KEYWORD_LINE = re.compile(r"^(?:(?:Given|When|Then|And|But) |\* |[@|#]|\"\"\"|```|"
                           r"(?:Feature|Rule|Background|Scenario|Scenario Outline|Scenario Template|Example|Examples|"
                           r"Scenarios):)")
_UNRESERVED = re.compile(r"[A-Za-z0-9.\-*_]")


# --------------------------------------------------------------------------- the register's tag vocabulary


def register_tags(case: dict, rule_ids: list[str], register_status: str, critical: bool = False,
                  stories: list[str] = (), examples: list[str] = (), business: list[str] = (),
                  requirements: list[str] = (), paragraphs: list[str] = (), origin: str | None = None) -> list[str]:
    """The explicit tags the import writes into a register scenario: hypothesis, stack (its recording shows the test
    stack, not the mainframe), decided (its expected answer is a decision of the architecture, an accepted deviation),
    critical (it proves a rule the package marks critical), the rules it proves, the BA's user stories and acceptance
    examples it answers (user-story layout) or the business scenarios and requirements the alignment links it to
    (business-scenario layout), its status."""
    tags = []
    if case.get("anticipatedJavaDivergence"):
        tags.append("hypothesis")
    if isinstance(case.get("stackDivergence"), list) and any(str(s).strip() for s in case["stackDivergence"]):
        tags.append("stack")
    if case.get("status") == "golden" and isinstance(case.get("decidedAnswer"), dict) \
            and case["decidedAnswer"].get("pending") is not True:
        tags.append("decided")
    if critical:
        tags.append("critical")
    tags += [f"rule:{tag_text(r)}" for r in rule_ids]
    if origin:                                     # mu-validate: basic / advanced (mu-build-tests' case origin)
        tags.append(f"origin:{tag_text(origin)}")
    tags += [f"para:{tag_text(p)}" for p in paragraphs]   # mu-validate: the COBOL paragraphs the case executes
    tags += [f"story:{tag_text(s)}" for s in stories]
    tags += [f"ae:{tag_text(e)}" for e in examples]
    tags += [f"bs:{tag_text(s)}" for s in business]
    tags += [f"fr:{tag_text(r)}" for r in requirements]
    if register_status != "runnable":
        tags.append(register_status)
    return tags


def tag_values(entry: dict, kind: str) -> list[str]:
    """The values of a register entry's ``<kind>:`` tags, in order (``story`` -> the user stories it answers)."""
    prefix = kind + ":"
    return [t[len(prefix):] for t in entry.get("tags") or [] if t.startswith(prefix)]


def effective_tags(entry: dict) -> list[str]:
    """``Scenario.effectiveTags()`` of a register entry (priority, risks, caveats, per level, branch, category,
    clock-sensitive, the explicit tags), in its order."""
    tags: list[str] = []

    def add(tag):
        if tag and tag not in tags:
            tags.append(tag)

    add(entry.get("priority"))
    for tag in (entry.get("risks") or []) + (entry.get("caveats") or []):
        add(tag)
    for level in entry.get("levels") or []:
        add(f"level:{level.get('level') or 'L4'}")
        add(f"lens:{level.get('lens') or 'service'}")
        add(f"unit:{str(level.get('legacy', '')).split(':', 1)[-1]}")
    if entry.get("branch"):
        add("branch:" + entry["branch"].replace(" ", "_"))
    if entry.get("category"):
        add("category:" + entry["category"].replace(" ", "_"))
    if entry.get("clockSensitive"):
        add("clock-sensitive")
    for tag in entry.get("tags") or []:
        add(tag)
    return tags


def tag_text(value: str) -> str:
    return re.sub(r"\s+", "_", str(value).strip())


# --------------------------------------------------------------------------- rules and placement


def rules_of(case_id: str, rules: list[dict]) -> list[str]:
    return [r["id"] for r in rules if case_id in r.get("provenBy", [])]


def placement(case_ids: list[str], rules: list[dict]) -> dict[str, str | None]:
    """Each case under the most specific rule citing it (fewest proving cases, then rule order); None = no rule."""
    placed = {}
    for case_id in case_ids:
        citing = [(len(r.get("provenBy", [])), n, r["id"]) for n, r in enumerate(rules)
                  if case_id in r.get("provenBy", [])]
        placed[case_id] = min(citing)[2] if citing else None
    return placed


# --------------------------------------------------------------------------- what the steps state


def java_urlencode(text: str) -> str:
    """``java.net.URLEncoder.encode(text, UTF-8)``: unreserved ``A-Za-z0-9.-*_`` kept, space as ``+``, %XX else."""
    out = []
    for ch in text:
        if _UNRESERVED.fullmatch(ch):
            out.append(ch)
        elif ch == " ":
            out.append("+")
        else:
            out.extend(f"%{b:02X}" for b in ch.encode("utf-8"))
    return "".join(out)


def _readable(encoded: str) -> str:
    """An encoded query part with ``[`` and ``]`` shown as they are (unambiguous: ``URLEncoder`` writes a ``%`` as
    ``%25``, so ``%5B`` / ``%5D`` only stand for a bracket)."""
    return encoded.replace("%5B", "[").replace("%5D", "]")


def http_target(http: dict) -> str:
    """``HttpRequestSpec.readableTarget()``: the path as written, the query encoded in order - except the brackets of
    an indexed parameter (``context[0].kind=DIRECT``). The glue accepts it; the request is sent encoded."""
    query = http.get("query") or {}
    encoded = "&".join(f"{_readable(java_urlencode(str(k)))}={_readable(java_urlencode(str(v)))}"
                       for k, v in query.items())
    return http["path"] + ("?" + encoded if encoded else "")


def readable_clock(clock: str) -> str:
    """``20240816103000123456`` -> ``2024-08-16 10:30:00.123456`` (the glue reads the digits back)."""
    fraction = clock[14:]
    return (f"{clock[0:4]}-{clock[4:6]}-{clock[6:8]} {clock[8:10]}:{clock[10:12]}:{clock[12:14]}"
            + (f".{fraction}" if fraction else ""))


def one_line(text) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()


def cell_text(value) -> str | None:
    """What the glue compares a table cell with (Gherkin trims cells); None when not a scalar."""
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)) or type(value).__name__ == "Decimal":
        return str(value)
    if isinstance(value, str):
        return value.strip()
    return None


def _escape_cell(text: str) -> str:
    return text.replace("\\", "\\\\").replace("|", "\\|").replace("\n", "\\n")


TABLES, EMPTY = "$tables", "$empty"


def table_holds_lines(golden: dict) -> list[str]:
    """Format 3 with table checks: ``And the golden master holds status <s>[ with an empty answer]``, then per table
    check ``And the golden master holds <n> row(s) in <TABLE>``."""
    observation = golden.get("observation") or {}
    status = (observation.get("outcome") or {}).get("exitState")
    payload = observation.get("payload") if isinstance(observation.get("payload"), dict) else {}
    if not isinstance(status, int):
        return []
    lines = [f"And the golden master holds status {status}" + (" with an empty answer" if payload.get(EMPTY) else "")]
    for name, rows in (payload.get(TABLES) or {}).items():
        count = len(rows) if isinstance(rows, list) else 0
        lines.append(f"And the golden master holds {count} row{'' if count == 1 else 's'} in {name}")
    return lines


def body_lines(body) -> list[str]:
    """The request body as a JSON doc string (the glue compares it with the register's, as JSON)."""
    return ['"""json', *canonical.dumps_pretty(body).rstrip("\n").split("\n"), '"""']


def holds_lines(golden: dict) -> list[str]:
    """``And the golden master holds status <s> [and <n> <list>[, starting with:]]`` + the first rows as a table."""
    observation = golden.get("observation") or {}
    status = (observation.get("outcome") or {}).get("exitState")
    if not isinstance(status, int):
        return []
    if isinstance(observation.get("payload"), dict) and TABLES in observation["payload"]:
        return table_holds_lines(golden)
    line = f"And the golden master holds status {status}"
    payload = observation.get("payload")
    lists = [k for k, v in payload.items() if isinstance(v, list) and all(isinstance(e, dict) for e in v)] \
        if isinstance(payload, dict) and 200 <= status < 300 else []
    if len(lists) != 1:
        return [line]
    key = lists[0]
    items = payload[key]
    if not items:
        return [f"{line} and no {key}"]
    word = key[:-1] if len(items) == 1 and key.endswith("s") and len(key) > 1 else key
    header = list(items[0].keys())
    rows = []
    for item in items[:SHOWN_ROWS]:
        cells = [cell_text(item.get(field)) for field in header]
        if any(c is None for c in cells) or any(f not in item for f in header):
            return [f"{line} and {len(items)} {word}"]
        rows.append([_escape_cell(c) for c in cells])
    table = [[_escape_cell(h) for h in header]] + rows
    widths = [max(len(r[i]) for r in table) for i in range(len(header))]
    lines = [f"{line} and {len(items)} {word}, starting with:"]
    lines += ["  | " + " | ".join(c.ljust(widths[i]) for i, c in enumerate(r)) + " |" for r in table]
    return lines


# --------------------------------------------------------------------------- the text


def _description(text, indent: str) -> list[str]:
    """Free text as Gherkin description lines: wrapped, and never mistaken for a keyword, tag, table or comment."""
    lines = []
    for paragraph in str(text or "").splitlines():
        for line in textwrap.wrap(paragraph.strip(), WIDTH, break_long_words=False, break_on_hyphens=False) or []:
            lines.append(indent + ("- " + line if _KEYWORD_LINE.match(line) else line))
    return lines


def _plain(text: str) -> str:
    return one_line(str(text).replace("**", "").replace("`", ""))


_ABBREVIATIONS = ("e.g", "i.e", "etc", "cf", "vs", "incl", "approx", "no")


def _sentence_end(text: str) -> int:
    """The index of the first sentence's full stop (not an abbreviation's, not inside parentheses); -1 if none."""
    depth = 0
    for i, ch in enumerate(text):
        depth += (ch == "(") - (ch == ")")
        if ch == "." and text[i + 1:i + 2] == " " and depth <= 0:
            word = text[:i].rsplit(" ", 1)[-1].lstrip("(").lower()
            if word not in _ABBREVIATIONS:
                return i
    return -1


def _rule_title(rule: dict) -> tuple[str, str]:
    """(the Rule line's name - the rule's whole first sentence, however long: a title cut mid-phrase reads wrong -,
    the rest of the rule as its description)."""
    text = _plain(rule.get("text", ""))
    cut = _sentence_end(text)
    head, rest = (text[:cut + 1], text[cut + 2:]) if cut > 0 else (text, "")
    return f"{tag_text(rule['id'])}{' (critical)' if rule.get('critical') else ''} - {head}", rest


def _tag_lines(tags: list[str], indent: str) -> list[str]:
    """The tags as ``@`` tokens, as many per line as fit the width (Gherkin reads several tag lines as one set)."""
    lines, current = [], ""
    for token in ("@" + t for t in tags):
        if current and len(indent) + len(current) + 1 + len(token) > WIDTH:
            lines.append(indent + current)
            current = token
        else:
            current = f"{current} {token}" if current else token
    return lines + ([indent + current] if current else [])


def _set_reasons(case: dict, lists: list[str]) -> list[str]:
    """The package's reasons for the lists of this answer compared as sets (an entry for a list the answer does not
    have compares nothing and is not shown)."""
    compare = case.get("compare") if isinstance(case.get("compare"), list) else []
    return [f"Compared as a set: {c.get('path')}" + (f" - {one_line(c['reason'])}" if c.get("reason") else "")
            for c in compare if isinstance(c, dict) and c.get("mode") == "set" and c.get("path") in lists]


def _answer_lists(case: dict) -> list[str]:
    body = (case.get("expected") or {}).get("body") if isinstance(case.get("expected"), dict) else None
    return [k for k, v in body.items() if isinstance(v, list)] if isinstance(body, dict) else []


def _scenario(entry: dict, case: dict, golden: dict | None, rule_ids: list[str], feature_tags: list[str],
              indent: str, alignment: dict | None = None) -> list[str]:
    sid = entry["scenarioId"]
    tags = [sid] + [t for t in effective_tags(entry) if t not in feature_tags]
    title = one_line(entry.get("title"))
    lines = _tag_lines(tags, indent) + [indent + f"Scenario: {sid}" + (f" {title}" if title else "")]
    body = indent + "  "
    lines += _description(entry.get("description"), body)
    decided = entry.get("decided") if entry.get("status", "runnable") == "runnable" else None
    for hypothesis in entry.get("hypotheses") or []:
        if decided and decision_note(hypothesis, decided):
            lines += _description(f"The decision's note (the expected value is the decided answer below): "
                                  f"{one_line(hypothesis)}", body)
        else:
            lines += _description(f"Hypothesis (anticipated, never the expected value): {one_line(hypothesis)}", body)
    for note in entry.get("stackDivergence") or []:
        lines += _description(f"Recorded on the test stack, not the mainframe (accepted or disputed at the record "
                              f"gate): {one_line(note)}", body)
    if decided:
        lines += _description(decided_line(decided), body)
    principal = (entry.get("http") or {}).get("principal")
    if principal:
        lines += _description(f"Called as user {principal} (the user id the legacy call was recorded with; E2E calls "
                              "with its own test identity of that user, never a real credential).", body)
    runnable = entry.get("status", "runnable") == "runnable"
    set_compared = runnable and (entry.get("compare") or {}).get("rows") == "set"
    set_lists = list((entry.get("compare") or {}).get("setPaths") or []) if runnable else []
    if set_compared or set_lists:
        for reason in _set_reasons(case, _answer_lists(case) if set_compared else set_lists):
            lines += _description(reason + ("" if reason.endswith(".") else "."), body)
    ignored = (entry.get("compare") or {}).get("ignore") or [] if entry.get("status", "runnable") == "runnable" else []
    for item in ignored:
        reason = one_line(item.get("reason"))
        lines += _description(f"Not compared: {item['path']}" + (f" - {reason}" if reason else "")
                              + ("" if reason.endswith(".") else "."), body)
    status = entry.get("status", "runnable")
    if status != "runnable":
        words = "not applicable" if status == "not-applicable" else "blocked"
        return lines + [body + f"* the case is {words}: {one_line(entry.get('statusReason'))}"]
    fixture, clock = entry.get("fixture"), entry.get("clock")
    if fixture and clock:
        lines.append(body + f'Given the fixture pack "{fixture}" and the clock {readable_clock(clock)}')
    elif fixture:
        lines.append(body + f'Given the fixture pack "{fixture}"')
    elif clock:
        lines.append(body + f"Given the clock {readable_clock(clock)}")
    http = entry.get("http")
    if http and principal:
        lines.append(body + CALLER_STEP.format("And" if fixture or clock else "Given", principal))
    if http and isinstance(http.get("body"), dict):
        keyword = "And" if fixture or clock or principal else "Given"
        lines.append(body + f"{keyword} the request body:")
        lines += [body + "  " + line for line in body_lines(http["body"])]
    if http:
        lines.append(body + f"When the client sends {http['method']} {http_target(http)}")
        lines.append(body + f'Then the answer matches the accepted golden master "{sid}"')
        if set_compared:
            lines.append(body + SET_STEP)
        lines += [body + LIST_SET_STEP.format(name) for name in set_lists]
        lines += [body + IGNORE_STEP.format(item["path"]) for item in ignored]
        if decided:
            lines.append(body + (DECIDED_STEP.format(decided["source"], decided["recordedStatus"])
                                 if isinstance(decided.get("recordedStatus"), int)
                                 else DECIDED_ONLY_STEP.format(decided["source"])))
        if golden:
            lines += [body + line for line in holds_lines(golden)]
    return lines


def decision_note(hypothesis, decided: dict) -> bool:
    """Whether a producer's hypothesis is the note of the case's decision (it starts with the decision's row id)."""
    source = str((decided or {}).get("source") or "")
    return bool(source) and str(hypothesis).strip().startswith(source)


def decided_line(decided: dict) -> str:
    """A decided answer (U-127) as the feature states it: the decided status, the row and its requirement, what the
    recording answers, and whether the rows after the call are the recording's."""
    text = f"Decided answer (accepted deviation): {decided.get('status')} by {decided.get('source')}"
    if decided.get("register"):
        text += f" ({decided['register']})"
    if decided.get("required"):
        text += f" - required: {one_line(decided['required'])}"
    recorded = decided.get("recordedStatus")
    text += (f". The legacy recording answers {recorded}" if isinstance(recorded, int)
             else ". The legacy recording gives no status") \
        + "; the golden master holds the decided answer and keeps the recording as the legacy's evidence."
    if decided.get("tables") == "recorded":
        text += " The rows after the call are compared as the recording left them."
    elif decided.get("tables") == "notCompared":
        text += " The rows after the call are not compared."
    return text


def business_layout(alignment: dict | None) -> bool:
    """mu-validate: no BA alignment (step 2a, BA paths are no-ops)."""
    return False


def _rule_stories(rule: dict, alignment: dict | None) -> str | None:
    """mu-validate: no BA alignment - no story line under a rule."""
    return None


def render(doc: dict, unit: str, package_rel: str, package_hash: str, scenarios: list[dict], rules: list[dict],
           goldens: dict[str, dict], alignment: dict | None = None) -> str:
    """The feature text of one package (``scenarios``: its register entries, in case order; ``alignment``: its BA
    alignment, read by ``e2elib/ba.py`` or ``e2elib/ba2.py``)."""
    cases = {c.get("id"): c for c in doc.get("cases", []) if isinstance(c, dict)}
    common = None
    for entry in scenarios:
        level_tags = [t for t in effective_tags(entry) if t.split(":", 1)[0] in ("unit", "lens", "level")]
        common = level_tags if common is None else [t for t in common if t in level_tags]
    feature_tags = common or []
    statuses = [c.get("status") for c in cases.values()]
    counts = ", ".join(f"{statuses.count(s)} {label}" for s, label in (
        ("golden", "golden"), ("not-representable", "not representable"), ("not-recorded", "not recorded"))
        if statuses.count(s))
    lines = [f"# Generated by mu-validate import from {package_rel} (sha256 {package_hash[:12]}) - do not edit:",
             "# a re-import of the package rewrites it. Every expected answer is the accepted golden master",
             f"# golden/{unit}/<scenarioId>.json; the lines below a Then only repeat what it holds."]
    if feature_tags:
        lines.append(" ".join("@" + t for t in feature_tags))
    lines.append(f"Feature: {unit} - {one_line(doc.get('api')) or 'service lens'}")
    for label, key in (("Golden master", "goldenMaster"), ("Comparison", "comparison")):
        if doc.get(key):
            lines += _description(f"{label}: {one_line(doc[key])}", "  ")
    lines += _description(f"Cases: {len(cases)} - {counts}.", "  ")
    if business_layout(alignment):
        lines += _description(f"BA alignment: {alignment['file']} - {len(alignment['scenarios'])} business scenarios, "
                              f"{len(alignment['rules'])} rules with their BA requirements; a scenario carries the tags "
                              "bs:<id> of the business scenarios it is recorded for and fr:<id> of the requirements "
                              "of the rules it proves.", "  ")
    elif alignment is not None:
        lines += _description(f"BA alignment: {alignment['file']} - {len(alignment['stories'])} user stories, "
                              f"{len(alignment['examples'])} acceptance examples; the scenarios answering them carry the "
                              "tags story:<id> and ae:<id>."
                              + (f" Story titles: the BA analysis {alignment['analysis']['folder']}."
                                 if alignment.get("analysis") and not alignment["analysis"].get("missing") else ""),
                              "  ")

    ids = [e["scenarioId"] for e in scenarios]
    placed = placement(ids, rules)
    entries = {e["scenarioId"]: e for e in scenarios}

    def block(sid: str, indent: str) -> list[str]:
        return [""] + _scenario(entries[sid], cases.get(sid, {}), goldens.get(sid), rules_of(sid, rules),
                                feature_tags, indent, alignment)

    for sid in ids:
        if placed[sid] is None:
            lines += block(sid, "  ")
    for rule in rules:
        name, rest = _rule_title(rule)
        lines += ["", f"  Rule: {name}"]
        lines += _description(rest, "    ")
        stories = _rule_stories(rule, alignment)
        if stories:
            lines += _description(stories, "    ")
        elsewhere = [f"{c} (under {placed[c]})" for c in rule.get("provenBy", []) if c in placed and placed[c] != rule["id"]]
        if elsewhere:
            lines += _description("Also proven by " + ", ".join(elsewhere) + ".", "    ")
        for sid in ids:
            if placed[sid] == rule["id"]:
                lines += block(sid, "    ")
    return "\n".join(lines) + "\n"
