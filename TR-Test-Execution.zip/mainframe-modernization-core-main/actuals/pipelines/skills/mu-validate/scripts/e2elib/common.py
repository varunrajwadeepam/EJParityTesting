"""The helpers of e2e_v1's ``e2elib/common.py`` the copied modules use (errors, paths, hashes, writes). Output, exit
codes and processes are mu-validate's own (``vlib/common.py``)."""

from __future__ import annotations

import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path


class E2eError(Exception):
    """A deterministic failure with a machine-readable code."""

    def __init__(self, code: str, message: str, details: dict | None = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details or {}


def now_utc() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def resolve_from(base: Path, value: str | os.PathLike) -> Path:
    """An absolute path, or one relative to ``base`` (normalized, not required to exist)."""
    path = Path(value)
    return (path if path.is_absolute() else Path(base) / path).resolve()


def rel(path: Path, base: Path) -> str:
    try:
        return os.path.relpath(path, base).replace("\\", "/")
    except ValueError:
        return str(path).replace("\\", "/")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_text_if_changed(path: Path, text: str) -> bool:
    """Write ``text`` (UTF-8, LF) unless the file already holds exactly that. Returns True when written."""
    path = Path(path)
    if path.is_file() and path.read_text(encoding="utf-8") == text:
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)
    return True


def write_json(path: Path, value) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def read_json(path: Path):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise E2eError("FILE_NOT_FOUND", f"{path} does not exist") from None
    except ValueError as exc:
        raise E2eError("MALFORMED_JSON", f"{path} is not valid JSON: {exc}") from None
