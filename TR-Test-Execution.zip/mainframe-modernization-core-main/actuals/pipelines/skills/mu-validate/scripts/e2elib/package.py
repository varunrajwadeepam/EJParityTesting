"""Golden-master packages: discovery, the input contract, the producer's seal, the integrity check and the derivations
into test assets.

A package is what a legacy-execution toolchain hands to E2E-VALIDATE for one legacy unit: ``<UNIT>-tests.json`` (the
cases, the behaviour rules and the recordings), usually a Markdown document for people (``<UNIT>-tests.md``, else the
one other ``*.md`` of the folder, else its ``*-tests-json-generation.md``: the generation report) and the fixture
SQL the answers were recorded on (mu-validate reads no BA alignment). Every golden case carries the
target request and the answer the legacy actually gave, already in the shape of the target's response - so the
package's recordings become golden masters (state RECORDED, accepted at the record gate) and the target is compared
with them over its API. Only the package folder's own files are read: its sub-folders belong to the producer (e.g.
``previous/``, its copy of the package this one replaced) and are never imported.

The contract - package format 2 (what E2E relies on; anything else is tolerated):

- ``package``: ``format`` 2, ``version`` (a positive integer, the package's own version), ``contentHash`` (the
  producer's seal: SHA-256 of the document without ``package`` as compact JSON - verified); optional ``schema``,
  ``generator``;
- top level: ``unit``, ``cases[]``, ``legacySchema`` (how a case's ``legacy`` report maps to the legacy's fields:
  ``"<FIELD>"`` or ``"<FIELD>|number"`` for a value, ``{"count", "columns": {name: field}}`` for a list of rows,
  ``"$..."`` for bookkeeping), ``rules[]`` (``id``, ``text``, ``provenBy[]``, optional ``critical``); optional
  ``api``, ``goldenMaster``, ``comparison``, ``statuses``, ``recordings`` (fingerprint -> ``members``: source file ->
  SHA-256), ``coverage`` (the legacy code the golden cases executed);
- every case: a unique ``id``, ``status`` in golden / not-representable / not-recorded; a non-golden case a
  ``reason``; optional ``ruleIds[]``, ``recording`` (``fingerprint``, ``repeats``, ``runIds``, ``recordedAt`` ...);
- a golden case: ``request.method``, ``request.path`` (percent-encoded), ``request.query`` (raw strings),
  ``expected.status`` (integer), ``expected.body`` when 2xx, ``fixture`` (a file of the package), ``clock``
  (14 digits), ``legacy`` (the raw legacy report after ``legacySchema``, with its ``inputs``, and
  ``technicalFailure`` when the legacy failed technically); optional ``clockSensitive``,
  ``anticipatedJavaDivergence[]`` (hypotheses - never an expected value), ``name``, ``about``, ``category``,
  ``compare[]`` (``{"mode": "set", "path": <a list of the body>, "reason"}``: the list's row order is not part of the
  outcome - this release compares the rows of every list of an answer as a set, or of none; ``{"mode": "ignore",
  "path": <a field of the body, or list[].field for every element's>, "reason"}``: that path is not compared, the
  reason naming its decision - the contract verdict leaves it out, the strict comparison still shows it).

A package without the ``package`` block (format 1: the raw legacy as ``rawItems`` / ``count`` / ``*Echo``, the rules
only in its Markdown) is refused: it is regenerated in format 2.

Format 3 (the producer's "database testing"; the same format as v2's
golden-master generator) adds what a call that writes needs:

- ``case.request.body`` (an object: the JSON body of a POST / PUT);
- ``case.expected.empty`` ``true`` for a 2xx answer without a body (``expected.body`` null then - explicit, so an
  absent body is never a silent pass);
- ``case.expected.tables`` ``[{name, query, columns[], rows[[typed]], compare ordered|set}]``: per table check the
  SELECT run after the call and the rows the legacy left (numbers as numbers, DATE ``YYYY-MM-DD``, CHAR text, NULL
  null; ``rows: []`` states that no row is expected) - every recording ran on a fresh database with the unit's tables
  emptied (the checks' and the fixtures' tables and their foreign-key children), then the case's fixture;
- ``legacySchema.tables`` (check id -> ``table``, ``columns`` {column: DDL type}, ``orderBy``, ``compare``) and
  ``case.legacy.verify`` (check id -> the rows as the Db2 CLP printed them: evidence - the integrity check counts them);
- a ``clock`` may carry fraction digits of the second (``20240816103000123456``);
- the producer's seal is Python's compact ``json.dumps`` (``seal``);
- optionally (the producer's machine-readable header): ``binding`` (how each request and expected answer is
  derived; its ``technicalFailure`` - with ``causes[]`` picked by ``when`` on ``legacy.technicalFailure`` - answers a
  legacy technical failure, so the integrity check accepts that answer's status, e.g. a 400 for a failure the
  architecture answers as invalid data), ``comparisonRules[]`` (the fixed rule ids the comparison applies - the
  contract profile follows them: ``comparison_profile``), ``resetTables[]`` (the tables emptied before every
  recording: the fixtures stage puts them in the E2E schema and empties them before every pack) and per case
  ``stackDivergence[]`` (where the recording shows the test stack and not the mainframe: shown at the record gate and
  next to a result, never an expected value) and ``decidedAnswer`` (the architecture decides the answer - a decided
  parity register row, ``source`` ``PAR-...``: the expected status is the row's, not the one the recording gives; the
  recording stays in ``legacy``, the recorded answer in ``decidedAnswer.recorded``; ``tables`` recorded - the rows
  after the call are the recording's - or notCompared - no table check). E2E compares such a case with the decided
  answer and reports it as an accepted deviation, never as equal to the legacy (U-127): the register's ``decided``,
  the golden master's ``evidence.decidedAnswer``, the feature, the record gate, the summary and the report say so.

A format-3 package that checks tables or empty answers (``checks_tables``: a write unit) is compared by status, body
and rows (``comparison_profile``: without ``comparisonRules`` an error body is compared too, never
``OUTCOME_ONLY_ON_ERROR``); one without them (a read unit, e.g. a lookup) is compared like format 2, as its
``comparison`` says (U-105). A package that states ``comparisonRules`` is compared by them (on an error answer only
the status - and the rows the call left - when it states ``OUTCOME_ONLY_ON_ERROR``). A package holds one format; an
MU's packages one format (mixing 2 and 3 is refused by the import).
"""

from __future__ import annotations

import decimal
import json
import re
from pathlib import Path

from . import canonical
from .common import sha256_bytes, sha256_file

STATUSES = ("golden", "not-representable", "not-recorded")
REGISTER_STATUS = {"golden": "runnable", "not-representable": "not-applicable", "not-recorded": "blocked"}
COMPARISON_RULES = ("RTRIM", "NULL_AS_BLANK", "OUTCOME_ONLY_ON_ERROR")
TABLE_COMPARISON_RULES = ("RTRIM", "NULL_AS_BLANK", "NUMERIC_SCALE_INSENSITIVE")      # format 3: bodies and rows too
# A package's comparisonRules (mu-build-tests): the ids a normalization rule of the contract profile applies;
# the others are the comparison's structure - the status, the whole body, an empty answer, arrays in order unless set,
# the case's compare[], the tables after the call, the reset before it -, which the register, the view mapping and the
# fixtures carry. An id in neither list is not applied (a warning).
PACKAGE_NORMALIZATION = {"RTRIM": "RTRIM", "NULL_AS_BLANK": "NULL_AS_BLANK", "NUMBERS_BY_VALUE": "NUMERIC_SCALE_INSENSITIVE",
                         "OUTCOME_ONLY_ON_ERROR": "OUTCOME_ONLY_ON_ERROR"}
PACKAGE_STRUCTURE = ("STATUS", "BODY_WHOLE_ON_2XX", "EMPTY_MEANS_NO_BODY", "ARRAYS_IN_ORDER", "CASE_COMPARE",
                     "TABLES_AFTER_CALL", "STATE_BEFORE_CALL")
COMPARE_MODES = ("set", "ignore")
DECIDED_TABLES = ("recorded", "notCompared")       # decidedAnswer.tables: the recording's rows, or no table check
FORMATS = (2, 3)
TABLE_FORMAT = 3
TABLE_COMPARES = ("ordered", "set")
_CLOCK = re.compile(r"^[0-9]{14}([0-9]{1,9})?$")
_NUMERIC_DDL = re.compile(r"^(decimal|numeric|dec|smallint|integer|int|bigint|real|double|float|decfloat)\b", re.I)
_DATE_TEXT = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$")
_CASE_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
_REQUEST_KEY = re.compile(r"^[A-Za-z0-9$_-]+(\([0-9]+\))?$")
_SHA256 = re.compile(r"^[0-9a-f]{64}$")
FORMAT_1 = ("package format 1 (no 'package' block) is no longer read: regenerate the package in format 2 (a "
            "'package' block with format, version and contentHash, 'legacySchema', 'rules' in the JSON)")


# --------------------------------------------------------------------------- discovery and loading

# The producer's base of its next generation (the producer's rotation): committed with the package, never a package.
PREVIOUS = "previous"


def _package_shaped(path: Path) -> dict | None:
    """The JSON at ``path`` when its top level looks like a package (``unit`` and a ``cases`` list), else None."""
    try:
        doc = canonical.load_json(path)
    except (ValueError, OSError):
        return None
    return doc if isinstance(doc, dict) and isinstance(doc.get("unit"), str) and isinstance(doc.get("cases"), list) \
        else None


def unit_folders(folder: Path) -> list[Path]:
    """The package folders under ``folder`` (one per legacy unit), sorted; hidden ones are no package folders."""
    return sorted(p for p in folder.iterdir() if p.is_dir() and not p.name.startswith(".")) if folder.is_dir() else []


def discover(folder: Path) -> list[Path]:
    """Every JSON file of ``folder`` or of a package folder in it whose top level is a package (``unit`` and a
    ``cases`` list), sorted - every package of every unit (see :func:`catalogue` for the current one). A package
    folder's own sub-folders are never read: they are the producer's (e.g. its ``previous/`` copy of the last
    package, or a working plan), never a package E2E imports - :func:`not_read` names them."""
    if not folder.is_dir():
        return []
    candidates = sorted(folder.glob("*.json")) + [p for unit in unit_folders(folder) for p in sorted(unit.glob("*.json"))]
    return [p for p in candidates if p.is_file() and _package_shaped(p) is not None]


def not_read(folder: Path) -> list[dict]:
    """The sub-folders of the package folders under ``folder``, which discovery never reads: per sub-folder its path
    relative to ``folder`` and the package-shaped JSON files directly in it, with their unit and version label. An
    empty sub-folder (no file anywhere in it) is not worth a line."""
    found = []
    for unit in unit_folders(folder):
        for sub in sorted(p for p in unit.iterdir() if p.is_dir() and any(f.is_file() for f in p.rglob("*"))):
            packages = []
            for path in sorted(sub.glob("*.json")):
                doc = _package_shaped(path)
                if doc is not None:
                    packages.append({"file": path.name, "unit": doc["unit"],
                                     "label": version_label(package_version(doc))})
            found.append({"folder": sub.relative_to(folder).as_posix(), "packages": packages})
    return found


def not_read_lines(entries: list[dict]) -> list[str]:
    """One line per sub-folder discovery skipped, for a summary."""
    def what(folder: str) -> str:
        return ("the producer's base of its next generation" if folder.rsplit("/", 1)[-1] == PREVIOUS
                else "a sub-folder of the package folder, the producer's")

    return [f"{e['folder']}/ not read: {what(e['folder'])}" + (
        "; it holds " + ", ".join(f"{p['file']} ({p['unit']} {p['label']})" for p in e["packages"])
        if e["packages"] else "") for e in entries]


def package_block(doc: dict) -> dict:
    block = doc.get("package")
    return block if isinstance(block, dict) else {}


def package_version(doc: dict) -> int | None:
    """The package's own version (``package.version``), None when it declares none."""
    version = package_block(doc).get("version")
    return version if isinstance(version, int) and not isinstance(version, bool) and version >= 1 else None


def version_label(version: int | None) -> str:
    return f"v{version}" if version else "unversioned"


def catalogue(folder: Path) -> list[dict]:
    """Per legacy unit (from the package JSON's ``unit``, not the folder): the current package and the older ones,
    read only. The package is replaced in place, so a unit normally has one, current whatever its folder is called;
    several packages of a unit are ordered by their ``package.version`` - one without a version, or two with the same,
    leave ``current`` None and ``problem`` says why (the order is the operator's to clear up)."""
    units: dict[str, list[tuple[Path, dict]]] = {}
    for path in discover(folder):
        doc = canonical.load_json(path)
        units.setdefault(doc["unit"], []).append((path, doc))
    entries = []
    for unit in sorted(units):
        found = [(package_version(doc), path) for path, doc in units[unit]]
        entry = {"unit": unit, "current": None, "version": None, "label": None, "older": [], "problem": None}
        if len(found) == 1:
            version, path = found[0]
            entry.update(current=path, version=version, label=version_label(version))
        else:
            folders = lambda pairs: ", ".join(sorted(p.parent.name for _, p in pairs))  # noqa: E731
            unversioned = [(v, p) for v, p in found if v is None]
            numbers = [v for v, _ in found if v is not None]
            if unversioned:
                entry["problem"] = (f"{len(found)} packages of {unit}, but {folders(unversioned)} declare(s) no "
                                    "package.version: their order is unknown - replace the package in place")
            elif len(set(numbers)) != len(numbers):
                entry["problem"] = f"{len(found)} packages of {unit} share a package.version: {folders(found)}"
            else:
                ordered = sorted(found, key=lambda vp: vp[0])
                version, path = ordered[-1]
                entry.update(current=path, version=version, label=version_label(version),
                             older=[{"path": p, "version": v, "label": version_label(v)} for v, p in ordered[:-1]])
        entries.append(entry)
    return entries


def current_packages(folder: Path) -> tuple[list[Path], list[str]]:
    """(the current package of every unit, the problems of the units whose order is ambiguous)."""
    entries = catalogue(folder)
    return [e["current"] for e in entries if e["current"]], [e["problem"] for e in entries if e["problem"]]


BA_ALIGNMENT_SUFFIX = "-ba-alignment.md"
GENERATION_REPORT_SUFFIX = "-tests-json-generation.md"


def _ba_files(path: Path) -> list[Path]:
    return sorted(p for p in path.parent.glob("*.md") if p.is_file() and p.name.lower().endswith(BA_ALIGNMENT_SUFFIX))


def ba_alignment_md(path: Path) -> Path | None:
    """mu-validate: no BA alignment in pipelines_v2 - never read (step 2a, BA paths are no-ops)."""
    return None


def _v1_ba_alignment_md(path: Path) -> Path | None:
    """The package's BA alignment: the one ``*-ba-alignment.md`` of the folder; None when there is none or several
    (:func:`folder_warnings` says so)."""
    found = _ba_files(path)
    return found[0] if len(found) == 1 else None


def companion_md(path: Path) -> Path | None:
    """The package's Markdown for people: ``<UNIT>-tests.md`` next to ``<UNIT>-tests.json``, else the one ``*.md`` of
    the folder that is no BA alignment, else the one generation report (``*-tests-json-generation.md``) among them;
    None when there is none or the choice is not clear."""
    md = path.with_suffix(".md")
    if md.is_file():
        return md
    ba_files = _ba_files(path)
    others = sorted(p for p in path.parent.glob("*.md") if p.is_file() and p not in ba_files)
    if len(others) == 1:
        return others[0]
    reports = [p for p in others if p.name.lower().endswith(GENERATION_REPORT_SUFFIX)]
    return reports[0] if len(reports) == 1 else None


def folder_warnings(path: Path) -> list[str]:
    """What in the package folder E2E cannot place: several BA alignments (none is read)."""
    ba_files = _ba_files(path)
    return [f"several BA alignment files ({', '.join(p.name for p in ba_files)}): none is read - keep one"] \
        if len(ba_files) > 1 else []


def unused_files(path: Path, doc: dict) -> list[str]:
    """The package folder's files that are neither the JSON, its Markdown, its BA alignment nor a fixture a case names
    - typically what an in-place replacement left of the previous package."""
    named = {c.get("fixture") for c in doc.get("cases", []) if isinstance(c, dict) and c.get("fixture")}
    keep = {path.name} | {p.name for p in (companion_md(path), ba_alignment_md(path)) if p} | named
    return sorted(p.name for p in path.parent.iterdir() if p.is_file() and p.name not in keep
                  and not (p.name.lower().endswith(BA_ALIGNMENT_SUFFIX) and folder_warnings(path)))


def is_golden(case: dict) -> bool:
    return case.get("status") == "golden"


def status_class(status: int) -> str:
    """The outcome kind an HTTP status stands for (as the HTTP capture plugin maps it)."""
    if status >= 500:
        return "TECHNICAL_FAILURE"
    return "BUSINESS_EXCEPTION" if status >= 400 else "OK"


def is_format3(doc: dict) -> bool:
    """Whether a package is of format 3: it may carry request bodies, empty answers, table checks, clocks with a
    second's fraction - what it accepts and how it is sealed."""
    return package_block(doc).get("format") == TABLE_FORMAT


CLOCK_MODES = ("frozen", "advancing")


def clock_mode(config: dict, docs: list[dict]) -> str:
    """How the pinned clock runs (``target.clockMode``): ``frozen`` or ``advancing`` as configured; ``auto`` (the
    default) - frozen when a package is of format 3 (a value built from the clock, e.g. a key from its microseconds,
    then matches the recording's), advancing for format 2 (decision U-94). The framework reads it as
    ``e2e.target.clock`` (environment ``E2E_TARGET_CLOCK``)."""
    configured = str((config.get("target") or {}).get("clockMode") or "auto").lower()
    if configured in CLOCK_MODES:
        return configured
    return "frozen" if any(is_format3(doc) for doc in docs) else "advancing"


def checks_tables(doc: dict) -> bool:
    """Whether a package checks what a call leaves behind - a format-3 package with a table check or an empty answer in
    any case (a write unit). Only then are the answers compared by status, body and rows (``TABLE_COMPARISON_RULES``),
    one view mapping per answer shape and the tables part of the golden masters; a format-3 package without them (a
    read unit) is compared like format 2, as its ``comparison`` says (U-105)."""
    return is_format3(doc) and any(table_checks(case) or answer_empty(case)
                                   for case in doc.get("cases", []) if isinstance(case, dict))


def table_specs(doc: dict) -> dict[str, dict]:
    """``legacySchema.tables`` by table name: ``{name: {"check": <id>, "columns": {column: DDL type}, "orderBy",
    "compare"}}``."""
    tables = (doc.get("legacySchema") or {}).get("tables") if isinstance(doc.get("legacySchema"), dict) else None
    found = {}
    for check, spec in (tables or {}).items() if isinstance(tables, dict) else []:
        if isinstance(spec, dict) and isinstance(spec.get("table"), str):
            found[spec["table"]] = {"check": check, "columns": spec.get("columns") or {}, "orderBy": spec.get("orderBy"),
                                    "compare": spec.get("compare")}
    return found


def column_type(ddl: str | None) -> str:
    """The view mapping's field type of a column's DDL type: numbers by value, dates in their reported form, the rest
    as text."""
    text = str(ddl or "").strip()
    if _NUMERIC_DDL.match(text):
        return "NUMBER"
    return "DATE" if text.lower() in ("date", "timestamp", "time") or text.lower().startswith("timestamp") else "STRING"


def answer_empty(case: dict) -> bool:
    return (case.get("expected") or {}).get("empty") is True


def body_shape(case: dict) -> str:
    """The shape of a case's expected body - its sorted keys, ``no-body`` for none: the cases of one shape share a view
    mapping (a field missing on both sides is a difference, so a success and an error body cannot share one)."""
    body = (case.get("expected") or {}).get("body")
    return "+".join(sorted(str(k) for k in body)) if isinstance(body, dict) and body else "no-body"


def mapping_id(unit: str, case: dict) -> str:
    return f"{unit}--{body_shape(case)}"


def table_checks(case: dict) -> list[dict]:
    tables = (case.get("expected") or {}).get("tables")
    return [t for t in tables if isinstance(t, dict)] if isinstance(tables, list) else []


def captures(case: dict) -> bool:
    """mu-validate (F9, step 2a): whether the framework adds ``$empty`` / ``$tables`` to this case's answer - only for a
    case with table checks or a stated empty answer (``TableCapture``: ``answerEmpty`` set, ``tables`` not empty). A
    case without them (e.g. a decided answer whose rows are notCompared) gets neither, in the register, the golden
    master and its view mapping alike."""
    return bool(table_checks(case)) or answer_empty(case)


NO_CAPTURE = "no-tables"


def capture_mapping_id(unit: str, case: dict) -> str:
    return mapping_id(unit, case) if captures(case) else f"{mapping_id(unit, case)}--{NO_CAPTURE}"


# --------------------------------------------------------------------------- the producer's seal


def _js_number(value) -> str:
    """ECMAScript ``Number::toString`` of a JSON number as the producer's ``JSON.stringify`` writes it."""
    if isinstance(value, int):
        return str(value)
    if value != value or value in (float("inf"), float("-inf")):
        return "null"
    if value == 0:
        return "0"
    sign = "-" if value < 0 else ""
    parts = decimal.Decimal(repr(abs(value))).normalize().as_tuple()
    digits = "".join(str(d) for d in parts.digits)
    k, n = len(digits), parts.exponent + len(digits)
    if k <= n <= 21:
        text = digits + "0" * (n - k)
    elif 0 < n <= 21:
        text = digits[:n] + "." + digits[n:]
    elif -6 < n <= 0:
        text = "0." + "0" * -n + digits
    else:
        e = n - 1
        text = (digits if k == 1 else digits[0] + "." + digits[1:]) + "e" + ("+" if e >= 0 else "-") + str(abs(e))
    return sign + text


def js_stringify(value) -> str:
    """``JSON.stringify(value)``: compact, keys in their order, strings as JSON escapes them, numbers as ECMAScript."""
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, (int, float)):
        return _js_number(value)
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, dict):
        return "{" + ",".join(json.dumps(str(k), ensure_ascii=False) + ":" + js_stringify(v)
                              for k, v in value.items()) + "}"
    if isinstance(value, (list, tuple)):
        return "[" + ",".join(js_stringify(v) for v in value) + "]"
    raise TypeError(f"cannot stringify {type(value).__name__}")


def seal(doc: dict) -> str:
    """The package's content hash: SHA-256 of the document without its ``package`` block, as compact JSON. ``doc`` is
    read with plain floats (``json.loads``), as the producer holds it. Its producer's compact JSON: format 2's
    (JavaScript) is ``JSON.stringify``; format 3's (Python - mu-build-tests) is ``json.dumps(..., ensure_ascii=False, separators=(",", ":"))`` - the two write
    numbers differently (``25`` / ``25.0``)."""
    body = {k: v for k, v in doc.items() if k != "package"}
    if is_format3(doc):
        # mu-validate: the pipelines_v2 producer (mu-build-tests) seals canonical JSON with sorted keys (step 2a)
        return sha256_bytes(json.dumps(body, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
                            .encode("utf-8"))
    return sha256_bytes(js_stringify(body).encode("utf-8"))


def seal_of_file(path: Path) -> str:
    with open(path, encoding="utf-8") as handle:
        return seal(json.load(handle))


# --------------------------------------------------------------------------- the contract


def _rule_problems(doc: dict, ids: set[str]) -> list[str]:
    rules = doc.get("rules")
    if not isinstance(rules, list):
        return ["top level: 'rules' (the behaviour rules, a list) is required"]
    problems, seen = [], set()
    for index, rule in enumerate(rules):
        if not isinstance(rule, dict) or not isinstance(rule.get("id"), str) or not rule["id"].strip() \
                or not isinstance(rule.get("text"), str) or not isinstance(rule.get("provenBy"), list):
            problems.append(f"rules[{index}]: 'id', 'text' and 'provenBy' (a list of case ids) are required")
            continue
        if rule["id"] in seen:
            problems.append(f"rules[{index}]: duplicate rule id {rule['id']}")
        seen.add(rule["id"])
        unknown = [str(c) for c in rule["provenBy"] if c not in ids]
        if unknown:
            problems.append(f"rule {rule['id']}: cites unknown cases {unknown}")
        if "critical" in rule and not isinstance(rule["critical"], bool):
            problems.append(f"rule {rule['id']}: 'critical' must be true or false")
    return problems


def _legacy_schema_problems(doc: dict) -> list[str]:
    schema = doc.get("legacySchema")
    if not isinstance(schema, dict) or not schema:
        return ["top level: 'legacySchema' (how each case's legacy report maps to the legacy's fields) is required"]
    problems = []
    for key, spec in schema.items():
        if isinstance(spec, str):
            continue
        if key == "tables" and is_format3(doc):
            problems += _table_schema_problems(spec)
            continue
        if not isinstance(spec, dict) or not isinstance(spec.get("columns"), dict) or not spec["columns"]:
            problems.append(f"legacySchema.{key}: a field name or a list {{'count', 'columns': {{...}}}}")
    return problems


def _table_schema_problems(tables) -> list[str]:
    if not isinstance(tables, dict):
        return ["legacySchema.tables: an object of table checks (check id -> {table, columns, orderBy, compare})"]
    problems, names = [], set()
    for check, spec in tables.items():
        where = f"legacySchema.tables.{check}"
        if not isinstance(spec, dict) or not isinstance(spec.get("table"), str) or not spec["table"] \
                or not isinstance(spec.get("columns"), dict) or not spec["columns"]:
            problems.append(f"{where}: 'table' and 'columns' (column -> DDL type) are required")
            continue
        if spec["table"] in names:
            problems.append(f"{where}: the table {spec['table']} has two checks")
        names.add(spec["table"])
        if spec.get("compare") not in (None, *TABLE_COMPARES):
            problems.append(f"{where}: 'compare' must be one of {', '.join(TABLE_COMPARES)}")
    return problems


def _table_problems(case: dict, where: str, specs: dict[str, dict]) -> list[str]:
    """A format-3 case's ``expected.tables``: each check names a table of ``legacySchema.tables``, its columns are that
    check's, every row has one value per column, ``compare`` is ordered or set."""
    tables = (case.get("expected") or {}).get("tables")
    if tables is None:
        return []
    if not isinstance(tables, list):
        return [f"{where}: 'expected.tables' must be a list of table checks"]
    problems, seen = [], set()
    for index, check in enumerate(tables):
        at = f"{where}: expected.tables[{index}]"
        if not isinstance(check, dict) or not isinstance(check.get("name"), str) \
                or not isinstance(check.get("query"), str) or not isinstance(check.get("columns"), list) \
                or not check["columns"] or not isinstance(check.get("rows"), list):
            problems.append(f"{at}: 'name', 'query', 'columns' and 'rows' are required")
            continue
        name = check["name"]
        if name in seen:
            problems.append(f"{at}: the table {name} is checked twice")
        seen.add(name)
        if not re.match(r"^\s*SELECT\b", check["query"], re.I) or ";" in check["query"].strip().rstrip(";"):
            problems.append(f"{at}: 'query' must be one SELECT")
        spec = specs.get(name)
        if spec is None:
            problems.append(f"{at}: the table {name} has no check in legacySchema.tables")
        elif list(spec["columns"]) != [str(c) for c in check["columns"]]:
            problems.append(f"{at}: its columns are not legacySchema.tables.{spec['check']}'s")
        elif spec.get("compare") and check.get("compare") != spec["compare"]:
            problems.append(f"{at}: compares {name} {check.get('compare')} but legacySchema.tables.{spec['check']} "
                            f"{spec['compare']} - this release compares a table one way for every case")
        if check.get("compare") not in TABLE_COMPARES:
            problems.append(f"{at}: 'compare' must be one of {', '.join(TABLE_COMPARES)}")
        if any(not isinstance(row, list) or len(row) != len(check["columns"]) for row in check["rows"]):
            problems.append(f"{at}: every row needs one value per column ({len(check['columns'])})")
    return problems


def set_paths(case: dict) -> list[str]:
    """The answer's lists a case compares as sets (its ``compare`` entries of mode ``set``), in order."""
    compare = case.get("compare") if isinstance(case.get("compare"), list) else []
    return list(dict.fromkeys(str(c["path"]) for c in compare
                              if isinstance(c, dict) and c.get("mode") == "set" and c.get("path")))


def principal_of(case: dict) -> str | None:
    """The user a case's call is made as (format 3 ``request.principal``: the COBOL user id it was recorded with, for an
    API that takes the user from the caller's identity), else None. The package never holds a credential."""
    request = case.get("request") if isinstance(case.get("request"), dict) else {}
    principal = request.get("principal")
    return principal if isinstance(principal, str) and principal.strip() else None


def principals(doc: dict) -> list[str]:
    """The distinct users the golden cases of a package are called as, in first-seen order."""
    return list(dict.fromkeys(p for c in doc.get("cases") or [] if isinstance(c, dict) and is_golden(c)
                              for p in [principal_of(c)] if p))


def answer_lists(case: dict) -> list[str]:
    """The lists of a case's expected body (its top-level keys holding a list), in body order."""
    body = (case.get("expected") or {}).get("body")
    return [k for k, v in body.items() if isinstance(v, list)] if isinstance(body, dict) else []


def set_lists(case: dict) -> list[str]:
    """The lists of a golden 2xx answer a case compares as sets, in body order: its ``compare`` set paths the expected
    body holds as lists. As in the producer's own comparison (``check-java``), a set entry applies to its list
    only - the other lists keep their order - and one for a list the answer does not have has no effect."""
    expected = case.get("expected") or {}
    status = expected.get("status")
    if not (is_golden(case) and isinstance(status, int) and 200 <= status < 300):
        return []
    stated = set(set_paths(case))
    return [k for k in answer_lists(case) if k in stated]


def compared_as_set(case: dict) -> bool:
    """Whether the register compares rows of a case as a set: a golden 2xx answer with a list its ``compare`` sets."""
    return bool(set_lists(case))


def set_compare(case: dict, tables: bool = False) -> dict:
    """The register's set comparison of a case (U-123): ``rows: set`` when its set lists are every list of the answer
    and it checks no table - the form of every earlier package, so their oracle keys stay as they are -, else
    ``setPaths`` naming those lists (the other lists and the table checks keep their own order); ``{}`` without one.
    An order difference in a set list is a note (``order: report-only``)."""
    lists = set_lists(case)
    if not lists:
        return {}
    if lists == answer_lists(case) and not (tables and table_checks(case)):
        return {"rows": "set", "order": "report-only"}
    return {"setPaths": lists, "order": "report-only"}


def set_compare_warnings(doc: dict) -> list[str]:
    """A golden 2xx case's set entry for a list its answer does not have: no effect (the producer's own semantics) -
    shown, never refused; one line per path."""
    found: dict[str, list] = {}
    for case in doc.get("cases") or []:
        if not isinstance(case, dict) or not is_golden(case):
            continue
        expected = case.get("expected") or {}
        status, body = expected.get("status"), expected.get("body")
        if not isinstance(body, dict) or not isinstance(status, int) or not 200 <= status < 300:
            continue
        for path in set_paths(case):
            if path not in body:
                found.setdefault(path, []).append(str(case.get("id")))
    return [f"compare set {path}: the answer of {len(ids)} case(s) has no such list - no effect (e.g. {ids[0]})"
            for path, ids in found.items()]


def ignore_entries(case: dict) -> list[dict]:
    """The answer's paths a case does not compare (its ``compare`` entries of mode ``ignore``): ``{"path", "reason"}``
    each, in order, one per path."""
    compare = case.get("compare") if isinstance(case.get("compare"), list) else []
    found = {}
    for c in compare:
        if isinstance(c, dict) and c.get("mode") == "ignore" and isinstance(c.get("path"), str) and c["path"]:
            found.setdefault(c["path"], {"path": c["path"], "reason": str(c.get("reason") or "")})
    return list(found.values())


def _ignore_problems(case: dict, where: str) -> list[str]:
    """A case's ignored paths: each with its reason, naming a field of the expected body (``list[].field``: a field of
    that list's elements)."""
    problems = []
    body = (case.get("expected") or {}).get("body")
    for entry in [c for c in case["compare"] if c.get("mode") == "ignore"]:
        path = entry.get("path")
        if not isinstance(entry.get("reason"), str) or not entry["reason"].strip():
            problems.append(f"{where}: compare ignore {path} needs its 'reason' (the decision it rests on)")
        if not isinstance(body, dict):
            problems.append(f"{where}: compare ignore {path}, but the case expects no body")
            continue
        group, _, field = path.partition("[].")
        if field:
            rows = body.get(group)
            if not isinstance(rows, list) or (rows and not any(isinstance(r, dict) and field in r for r in rows)):
                problems.append(f"{where}: compare ignores {path}, but the expected body has no list {group} with a "
                                f"field {field}")
        elif path not in body or isinstance(body[path], (list, dict)):
            problems.append(f"{where}: compare ignores {path}, but the expected body has no such field (a list's field "
                            "is named list[].field)")
    return problems


def _compare_problems(case: dict, where: str) -> list[str]:
    compare = case.get("compare")
    if compare is None:
        return []
    if not isinstance(compare, list) or any(not isinstance(c, dict) for c in compare):
        return [f"{where}: 'compare' must be a list of {{'mode', 'path', 'reason'}}"]
    problems = [f"{where}: compare mode {c.get('mode')!r} is not read by this release (it reads "
                + ", ".join(repr(m) for m in COMPARE_MODES) + ")" for c in compare if c.get("mode") not in COMPARE_MODES]
    problems += [f"{where}: a compare entry needs a 'path' (a list or a field of the answer)"
                 for c in compare if not isinstance(c.get("path"), str) or not c["path"]]
    if problems:
        return problems
    problems = _ignore_problems(case, where)
    expected = case.get("expected") or {}
    body, status = expected.get("body"), expected.get("status")
    if not isinstance(body, dict) or not isinstance(status, int) or not 200 <= status < 300:
        return problems                                         # an error answer's body is never compared
    # a set entry applies to its own list (U-123); one for a list the answer lacks has no effect (a warning:
    # set_compare_warnings), one naming a field that is no list, or a nested path, cannot be applied
    lists = answer_lists(case)
    for path in set_paths(case):
        if path in lists:
            continue
        if path in body:
            problems.append(f"{where}: compare sets {path}, but the expected body's {path} is no list")
        elif "." in path or "[" in path:
            problems.append(f"{where}: compare set {path}: this release compares the answer's top-level lists as sets "
                            "only")
    return problems


def decided_of(case: dict) -> dict | None:
    """The case's decided answer; None when it has none or it is pending (``pending: true``: its source is not
    decided, ``expected`` is the recorded answer)."""
    stated = case.get("decidedAnswer")
    return stated if isinstance(stated, dict) and stated.get("pending") is not True else None


def pending_of(case: dict) -> dict | None:
    """A pending decided answer of the case, in brief: ``{source, reason}``; else None."""
    stated = case.get("decidedAnswer")
    if not isinstance(stated, dict) or stated.get("pending") is not True:
        return None
    return {"source": str(stated.get("source") or "").strip(), "reason": " ".join(str(stated.get("reason") or "").split())}


def _decided_problems(case: dict, where: str, format3: bool) -> list[str]:
    """A case's decided answer (``decidedAnswer``, format 3): an object naming the register row that decides it and
    the decided status; ``tables`` recorded (the case has table checks: the recording's rows) or notCompared (it has
    none). That the decided status is the expected one is the integrity check's (with the row's ``PAR-`` id)."""
    stated = case.get("decidedAnswer")
    if stated is None:
        return []
    if not format3:
        return [f"{where}: 'decidedAnswer' is package format 3"]
    if not isinstance(stated, dict):
        return [f"{where}: 'decidedAnswer' must be an object (the decided register row: source, status, ...)"]
    if stated.get("pending") is True:                 # not decided: the case is compared with the recording
        return []
    problems = []
    if not isinstance(stated.get("source"), str) or not stated["source"].strip():
        problems.append(f"{where}: 'decidedAnswer.source' (the register row that decides the answer) is required")
    if not isinstance(stated.get("status"), int) or isinstance(stated.get("status"), bool):
        problems.append(f"{where}: 'decidedAnswer.status' (the decided HTTP status) must be an integer")
    recorded = stated.get("recordedStatus")
    if recorded is not None and (not isinstance(recorded, int) or isinstance(recorded, bool)):
        problems.append(f"{where}: 'decidedAnswer.recordedStatus' (the status the recording gives) must be an integer "
                        "or null")
    mode, checks = stated.get("tables"), (case.get("expected") or {}).get("tables")
    if mode is not None and mode not in DECIDED_TABLES:
        problems.append(f"{where}: 'decidedAnswer.tables' must be one of {', '.join(DECIDED_TABLES)}")
    elif mode == "notCompared" and checks:
        problems.append(f"{where}: 'decidedAnswer.tables' is notCompared, but the case has table checks")
    elif mode == "recorded" and not checks:
        problems.append(f"{where}: 'decidedAnswer.tables' is recorded, but the case has no table check")
    return problems


def contract_problems(doc: dict, folder: Path) -> list[str]:
    problems = []
    if not isinstance(doc.get("unit"), str) or not doc["unit"].strip():
        problems.append("top level: 'unit' is required")
    cases = doc.get("cases")
    if not isinstance(cases, list) or not cases:
        return problems + ["top level: 'cases' must be a non-empty list"]
    block = doc.get("package")
    if block is None:
        return problems + [FORMAT_1]
    if not isinstance(block, dict) or block.get("format") not in FORMATS:
        found = block.get("format") if isinstance(block, dict) else block
        return problems + [f"package.format {found!r} is not read by this release (it reads format "
                           + ", ".join(str(f) for f in FORMATS) + ")"]
    if package_version(doc) is None:
        problems.append("package.version (a positive integer) is required")
    declared = block.get("contentHash")
    if not isinstance(declared, str) or not _SHA256.match(declared):
        problems.append("package.contentHash (the producer's SHA-256 seal) is required")
    problems += _legacy_schema_problems(doc)
    tables = is_format3(doc)
    specs = table_specs(doc) if tables else {}
    ids = {c.get("id") for c in cases if isinstance(c, dict)}
    problems += _rule_problems(doc, ids)
    rule_ids = {r.get("id") for r in doc.get("rules") or [] if isinstance(r, dict)}
    recordings = doc.get("recordings") if isinstance(doc.get("recordings"), dict) else None
    seen = set()
    for index, case in enumerate(cases):
        where = f"cases[{index}]"
        if not isinstance(case, dict):
            problems.append(f"{where}: not an object")
            continue
        case_id = case.get("id")
        if not isinstance(case_id, str) or not _CASE_ID.match(case_id):
            problems.append(f"{where}: 'id' missing or not a plain identifier")
        elif case_id in seen:
            problems.append(f"{where}: duplicate id {case_id}")
        else:
            seen.add(case_id)
            where = case_id
        cited = case.get("ruleIds")
        if cited is not None and (not isinstance(cited, list) or any(r not in rule_ids for r in cited)):
            problems.append(f"{where}: 'ruleIds' must name rules of the package")
        fingerprint = (case.get("recording") or {}).get("fingerprint") if isinstance(case.get("recording"), dict) \
            else None
        if recordings is not None and fingerprint is not None and str(fingerprint) not in recordings:
            problems.append(f"{where}: recording.fingerprint {fingerprint} is not in 'recordings'")
        status = case.get("status")
        if status not in STATUSES:
            problems.append(f"{where}: 'status' must be one of {', '.join(STATUSES)}")
            continue
        if status != "golden":
            if not case.get("reason"):
                problems.append(f"{where}: a {status} case needs a 'reason'")
            continue
        request = case.get("request") or {}
        if not isinstance(request.get("method"), str) or not isinstance(request.get("path"), str) \
                or not request["path"].startswith("/") or any(c.isspace() for c in request["path"]):
            problems.append(f"{where}: 'request.method' and an encoded 'request.path' (starting with /) are required")
        query = request.get("query", {})
        if not isinstance(query, dict) or any(not isinstance(v, str) for v in query.values()):
            problems.append(f"{where}: 'request.query' must map names to strings")
        if request.get("body") is not None and not isinstance(request["body"], dict):
            problems.append(f"{where}: 'request.body' must be an object")
        principal = request.get("principal")
        if principal is not None:
            if not tables:
                problems.append(f"{where}: 'request.principal' is package format 3")
            elif not isinstance(principal, str) or not principal.strip() or "\n" in principal or "\r" in principal:
                problems.append(f"{where}: 'request.principal' (the user the call is made as) must be a non-blank "
                                "one-line string")
        expected = case.get("expected") or {}
        code = expected.get("status")
        empty = expected.get("empty")
        if not isinstance(code, int) or isinstance(code, bool):
            problems.append(f"{where}: 'expected.status' (an integer) is required")
        elif tables and empty is not None and (empty is not True or expected.get("body") is not None):
            problems.append(f"{where}: 'expected.empty' is true with a null 'expected.body', or absent")
        elif 200 <= code < 300 and not (tables and empty is True) and not isinstance(expected.get("body"), dict):
            problems.append(f"{where}: a 2xx case needs 'expected.body' (an object)"
                            + (" or 'expected.empty': true" if tables else ""))
        problems += _compare_problems(case, where)
        problems += _decided_problems(case, where, tables)
        if tables:
            problems += _table_problems(case, where, specs)
        elif expected.get("tables") is not None or empty is not None:
            problems.append(f"{where}: 'expected.tables' / 'expected.empty' are package format 3")
        fixture = case.get("fixture")
        if fixture is None and tables:
            problems.append(f"{where}: a golden case without a fixture (only the empty tables) is not read by this "
                            "release - name a fixture file")
        elif not isinstance(fixture, str) or not (folder / fixture).is_file():
            problems.append(f"{where}: 'fixture' must name a file of the package ({fixture!r} not found)")
        if not isinstance(case.get("clock"), str) or not _CLOCK.match(case["clock"]):
            problems.append(f"{where}: 'clock' must be 14 digits (yyyyMMddHHmmss), optionally with up to 9 digits "
                            "of a second's fraction")
        legacy = case.get("legacy")
        if not isinstance(legacy, dict) or not isinstance(legacy.get("inputs"), dict):
            problems.append(f"{where}: 'legacy' (the legacy's report, with its 'inputs') is required")
            continue
        if any(not _REQUEST_KEY.match(str(k)) or not isinstance(v, str) or "\n" in v or "\r" in v
               for k, v in legacy["inputs"].items()):
            problems.append(f"{where}: 'legacy.inputs' must map plain field names to one-line strings")
    return problems


def seal_problems(path: Path, doc: dict) -> list[str]:
    """The producer's seal against the file's content (only for a package the contract accepts)."""
    declared = package_block(doc).get("contentHash")
    actual = seal_of_file(path)
    return [] if declared == actual else [
        f"package.contentHash {str(declared)[:12]} does not match the content ({actual[:12]}): the package was changed "
        "after its producer wrote it - regenerate it, never edit it"]


# --------------------------------------------------------------------------- the integrity check


def _rtrim(value) -> str:
    return "" if value is None else str(value).rstrip()


def _same_number(legacy, value) -> bool:
    if isinstance(value, bool) or value is None:
        return False
    try:
        return decimal.Decimal(str(legacy).strip()) == decimal.Decimal(str(value))
    except decimal.InvalidOperation:
        return False


_PATH_VARIABLE = re.compile(r"\{[^/{}]+\}")


def _binding_operations(doc: dict) -> list[dict]:
    """The binding's operations: its ``operations``, or the binding itself when it is one operation (an api with one
    ``response``)."""
    binding = doc.get("binding")
    if not isinstance(binding, dict):
        return []
    found = [op for op in binding.get("operations") or [] if isinstance(op, dict)]
    return found + ([binding] if isinstance(binding.get("response"), dict) else [])


def _operation_matches(operation: dict, request) -> bool:
    template, path = operation.get("pathTemplate"), (request or {}).get("path") if isinstance(request, dict) else None
    if not isinstance(template, str) or not isinstance(path, str):
        return False
    method = operation.get("method")
    if isinstance(method, str) and str(request.get("method", "")).upper() != method.upper():
        return False
    pattern = "[^/]+".join(re.escape(part) for part in _PATH_VARIABLE.split(template))
    return re.fullmatch(pattern, path.split("?", 1)[0]) is not None


def _item_templates(node, key: str, found: list) -> None:
    if isinstance(node, dict):
        if node.get("$list") == key and isinstance(node.get("$item"), dict):
            found.append(node["$item"])
        for value in node.values():
            _item_templates(value, key, found)
    elif isinstance(node, list):
        for value in node:
            _item_templates(value, key, found)


def numeric_columns(doc: dict, case: dict, key: str) -> set[str]:
    """The fields of a list ``key`` the package's binding turns into numbers: its ``$item`` template reads them with a
    ``number`` pipe (``col:wipFinancial|number``) - in the case's operation (method and ``pathTemplate``), else in any
    operation. The legacy keeps the COBOL text ('1500.50'), the expected answer the number (1500.5)."""
    operations = _binding_operations(doc)
    chosen = [op for op in operations if _operation_matches(op, case.get("request"))] or operations
    numeric = set()
    for operation in chosen:
        items: list = []
        _item_templates(operation.get("response"), key, items)
        for item in items:
            numeric.update(name for name, expression in item.items() if isinstance(expression, str)
                           and expression.startswith("col:")
                           and "number" in [pipe.strip() for pipe in expression.split("|")[1:]])
    return numeric


def _spec(spec: str) -> tuple[str, bool]:
    """(the legacy field, whether it is a number) of a legacySchema value."""
    field, _, kind = spec.partition("|")
    return field, kind == "number"


def failure_statuses(doc: dict, legacy: dict) -> set[int] | None:
    """The statuses the package's ``binding`` answers a legacy technical failure with: per technical-failure answer
    (the binding's, an operation's) the first of its ``causes`` whose ``when`` fields all equal the legacy's
    ``technicalFailure`` fields (trimmed - as the producer's ``binding.py`` picks it), else the answer itself. None
    without a binding that states one (a technical failure is then answered with a 5xx)."""
    binding = doc.get("binding")
    if not isinstance(binding, dict):
        return None
    answers = [binding.get("technicalFailure")] + [op.get("technicalFailure") for op in binding.get("operations") or []
                                                   if isinstance(op, dict)]
    got = legacy.get("technicalFailure") if isinstance(legacy.get("technicalFailure"), dict) else {}
    found = set()
    for answer in answers:
        if not isinstance(answer, dict):
            continue
        cause = next((c for c in answer.get("causes") or [] if isinstance(c, dict) and isinstance(c.get("when"), dict)
                      and all(str(got.get(k) or "").strip() == str(v).strip() for k, v in c["when"].items())), answer)
        if isinstance(cause.get("status"), int) and not isinstance(cause["status"], bool):
            found.add(cause["status"])
    return found or None


DECIDED_SOURCE = re.compile(r"^(PAR-|OQ-[0-9]+|PQ-[0-9]+|design\.md#)")


def decided_source_ok(source) -> bool:
    """mu-validate: a decided answer cites a parity register row (``PAR-...``, e2e_v1) or a pipelines_v2 decision -
    ``OQ-n`` (design), ``PQ-n`` (mu-build-tests) or ``design.md#...`` (step 2a)."""
    return bool(DECIDED_SOURCE.match(str(source or "").strip()))


def integrity(doc: dict) -> tuple[list[str], dict]:
    """Does each golden case's expected answer agree with the legacy report it was derived from (``legacySchema``)?

    Data-driven, so no target API is assumed: an error status (5xx) exactly when the legacy failed technically - or,
    when the package's ``binding`` answers a technical failure (``failure_statuses``: per cause), that answer's status;
    for a 2xx answer every body field the schema maps (the body key is the legacy key) equal to the legacy value - right-
    trimmed, a ``|number`` numerically -, every mapped list with the legacy's row count and, row by row in order, the
    mapped columns (right-trimmed, or numerically where the binding's item template reads the column with a ``number``
    pipe: ``numeric_columns``). Returns (problems, what was checked: cases, values, the body keys no legacy field backs, the
    legacy keys no body field shows)."""
    schema = doc.get("legacySchema") if isinstance(doc.get("legacySchema"), dict) else {}
    tables = is_format3(doc)
    specs = table_specs(doc) if tables else {}
    mapped = {k: s for k, s in schema.items() if not (isinstance(s, str) and s.startswith("$"))
              and not (tables and k == "tables")}
    problems, checked, values = [], 0, 0
    unbacked, legacy_only = set(), set()
    table_counts = {"checks": 0, "rows": 0, "values": 0}
    for case in doc.get("cases", []):
        if not isinstance(case, dict) or not is_golden(case) or not isinstance(case.get("legacy"), dict):
            continue
        cid, legacy = case.get("id"), case["legacy"]
        expected = case.get("expected") or {}
        status = expected.get("status")
        failed = bool(legacy.get("technicalFailure"))
        answered = failure_statuses(doc, legacy) if failed else None
        decided = decided_of(case)
        if decided is not None:
            # The architecture decides this answer (a parity register row, the package's decidedAnswer): the
            # expected status is the row's, not one the legacy outcome gives; the body is not compared.
            if status != decided.get("status") or not decided_source_ok(decided.get("source")):
                problems.append(f"{cid}: expected status {status} but its decidedAnswer states "
                                f"{decided.get('status')} ({decided.get('source')})")
        elif isinstance(status, int) and answered:
            if status not in answered:
                problems.append(f"{cid}: expected status {status} but the package's binding answers this technical "
                                f"failure with {', '.join(str(s) for s in sorted(answered))}")
        elif isinstance(status, int) and (status >= 500) != failed:
            problems.append(f"{cid}: expected status {status} but the legacy "
                            + ("failed technically" if failed else "completed"))
        if tables:
            problems += _table_integrity(cid, case, legacy, specs, table_counts)
        body = expected.get("body")
        if not isinstance(body, dict) or not isinstance(status, int) or not 200 <= status < 300:
            continue
        checked += 1
        unbacked.update(k for k in body if k not in mapped)
        for key, spec in mapped.items():
            if key not in body:
                legacy_only.add(key)
                continue
            if key not in legacy:
                problems.append(f"{cid}: the body has {key} but the legacy report has no {key}")
                continue
            if isinstance(spec, dict):
                rows, items = legacy[key], body[key]
                if not isinstance(rows, list) or not isinstance(items, list):
                    problems.append(f"{cid}: {key} is not a list on both sides")
                    continue
                values += 1
                if len(rows) != len(items):
                    problems.append(f"{cid}: {len(items)} {key} but {len(rows)} legacy rows")
                    continue
                columns = list(spec["columns"].items())
                unbacked.update(f"{key}[].{n}" for item in items if isinstance(item, dict) for n in item
                                if n not in spec["columns"])
                numeric = numeric_columns(doc, case, key)
                for n, (item, row) in enumerate(zip(items, rows), start=1):
                    cells = row if isinstance(row, list) else [row]
                    if not isinstance(item, dict) or len(cells) != len(columns):
                        problems.append(f"{cid}: {key}[{n}] does not have the legacy row's {len(columns)} columns")
                        break
                    # right-trimmed text, or - for a field the binding turns into a number - the same number
                    wrong = [name for (name, _), cell in zip(columns, cells)
                             if name not in item or (_rtrim(item[name]) != _rtrim(cell)
                                                     and not (name in numeric and _same_number(cell, item[name])))]
                    values += len(columns)
                    if wrong:
                        problems.append(f"{cid}: {key}[{n}].{wrong[0]} {item.get(wrong[0])!r} is not the legacy row's "
                                        f"{cells[[c for c, _ in columns].index(wrong[0])]!r}")
                        break
                continue
            _, number = _spec(spec)
            values += 1
            same = _same_number(legacy[key], body[key]) if number else _rtrim(legacy[key]) == _rtrim(body[key])
            if not same:
                problems.append(f"{cid}: {key} {body[key]!r} differs from the legacy's {legacy[key]!r}")
    found = {"cases": checked, "values": values, "bodyKeysNotFromLegacy": sorted(unbacked),
             "legacyOnly": sorted(legacy_only)}
    if tables:
        found["tables"] = table_counts
    return problems, found


def _typed(value, ddl: str) -> bool:
    """Whether a recorded value has the type its column's DDL gives it (NULL always does)."""
    if value is None:
        return True
    if _NUMERIC_DDL.match(str(ddl or "").strip()):
        return isinstance(value, (int, float, decimal.Decimal)) and not isinstance(value, bool)
    if str(ddl or "").strip().lower() == "date":
        return isinstance(value, str) and _DATE_TEXT.match(value) is not None
    return isinstance(value, str)


def _table_integrity(cid: str, case: dict, legacy: dict, specs: dict[str, dict], counts: dict) -> list[str]:
    """A format-3 case's rows against what the recording printed (``legacy.verify``: as many rows) and against their
    columns' DDL types (numbers, ``YYYY-MM-DD`` dates, text)."""
    problems = []
    verify = legacy.get("verify") if isinstance(legacy.get("verify"), dict) else {}
    for check in table_checks(case):
        spec = specs.get(check.get("name")) or {}
        rows = check.get("rows") or []
        counts["checks"] += 1
        counts["rows"] += len(rows)
        printed = verify.get(spec.get("check"))
        if isinstance(printed, list) and len(printed) != len(rows):
            problems.append(f"{cid}: {len(rows)} row(s) of {check['name']} but the recording printed {len(printed)}")
        for n, row in enumerate(rows, start=1):
            wrong = [col for col, value in zip(check.get("columns") or [], row)
                     if not _typed(value, (spec.get("columns") or {}).get(col))]
            counts["values"] += len(row)
            if wrong:
                problems.append(f"{cid}: {check['name']}[{n}].{wrong[0]} {row[check['columns'].index(wrong[0])]!r} is "
                                f"not a {(spec.get('columns') or {}).get(wrong[0])} value")
                break
    return problems


def integrity_problems(doc: dict) -> list[str]:
    return integrity(doc)[0]


# --------------------------------------------------------------------------- the behaviour rules


def rules_of(doc: dict) -> list[dict]:
    """The package's behaviour rules as E2E keeps them (``rules/<UNIT>.json``): id, text, the proving cases, and
    ``critical`` when the package marks the rule so."""
    rules = []
    for rule in doc.get("rules") or []:
        if isinstance(rule, dict) and isinstance(rule.get("id"), str):
            entry = {"id": rule["id"], "text": str(rule.get("text", "")),
                     "provenBy": [str(c) for c in rule.get("provenBy") or []]}
            if rule.get("critical") is True:
                entry["critical"] = True
            rules.append(entry)
    return rules


def rule_warnings(doc: dict, rules: list[dict]) -> list[str]:
    """A golden case whose ``ruleIds`` differ from the rules citing it (``provenBy``): shown, not refused."""
    warnings = []
    for case in doc.get("cases", []):
        if isinstance(case, dict) and is_golden(case) and case.get("ruleIds") is not None:
            citing = sorted(r["id"] for r in rules if case.get("id") in r["provenBy"])
            if sorted(case["ruleIds"]) != citing:
                warnings.append(f"{case.get('id')}: ruleIds {sorted(case['ruleIds'])} but cited by {citing}")
    return warnings


# --------------------------------------------------------------------------- the recordings and the coverage


def recording_members(doc: dict, case: dict) -> dict[str, str]:
    """The legacy sources (file -> SHA-256) of the recording a case was made with; empty when the package names none."""
    fingerprint = (case.get("recording") or {}).get("fingerprint") if isinstance(case.get("recording"), dict) else None
    entry = (doc.get("recordings") or {}).get(str(fingerprint)) if fingerprint is not None else None
    members = entry.get("members") if isinstance(entry, dict) else None
    return {str(k): str(v) for k, v in members.items()} if isinstance(members, dict) else {}


def recording_summary(doc: dict) -> dict:
    """How the golden cases were recorded: repeats, fingerprints, toolchain revisions, when."""
    golden = [c for c in doc.get("cases", []) if isinstance(c, dict) and is_golden(c)]
    recordings = [c["recording"] for c in golden if isinstance(c.get("recording"), dict)]
    repeats = sorted({r["repeats"] for r in recordings if isinstance(r.get("repeats"), int)})
    times = sorted(str(r["recordedAt"]) for r in recordings if r.get("recordedAt"))
    generator = package_block(doc).get("generator") if isinstance(package_block(doc).get("generator"), dict) else {}
    return {"golden": len(golden), "withRecording": len(recordings), "repeats": repeats,
            "fingerprints": sorted({str(r["fingerprint"]) for r in recordings if r.get("fingerprint") is not None}),
            "members": len({m for c in golden for m in recording_members(doc, c)}),
            "toolchain": sorted({str(r["parityTester"]) for r in recordings if r.get("parityTester")}),
            "recordedFrom": times[0] if times else None, "recordedTo": times[-1] if times else None,
            "generator": {k: generator[k] for k in ("name", "scriptsHash") if generator.get(k)}}


def coverage_summary(doc: dict) -> dict | None:
    """The package's legacy code coverage in brief (None when the package has no ``coverage`` block)."""
    coverage = doc.get("coverage")
    if not isinstance(coverage, dict):
        return None
    total = coverage.get("total") if isinstance(coverage.get("total"), dict) else {}
    code, executed = total.get("codeLines"), total.get("executedLines")
    programs = [p for p in coverage.get("programs") or [] if isinstance(p, dict)]         if isinstance(coverage.get("programs"), list) else []
    totals = coverage.get("totals") if isinstance(coverage.get("totals"), dict) else None
    if totals is not None:              # mu-validate: the pipelines_v2 shape (mu-build-tests), step 2a
        lines = totals.get("lines") if isinstance(totals.get("lines"), dict) else {}
        paragraphs = totals.get("paragraphs") if isinstance(totals.get("paragraphs"), dict) else {}
        code, executed = lines.get("code"), lines.get("covered")
        programs = [{"program": name, **(p if isinstance(p, dict) else {})}
                    for name, p in (coverage.get("programs") or {}).items()]             if isinstance(coverage.get("programs"), dict) else programs
        percent = None
        if isinstance(code, int) and isinstance(executed, int) and code > 0:
            percent = str((decimal.Decimal(executed) * 100 / decimal.Decimal(code)).quantize(decimal.Decimal("0.1")))
        return {"codeLines": code, "executedLines": executed, "percent": percent,
                "paragraphs": paragraphs or None, "programs": len(programs),
                "neverEntered": sorted(str(p["program"]) for p in programs if p.get("entered") is False),
                "scope": coverage.get("scope")}
    percent = None
    if isinstance(code, int) and isinstance(executed, int) and code > 0:
        percent = str((decimal.Decimal(executed) * 100 / decimal.Decimal(code)).quantize(decimal.Decimal("0.1")))
    return {"codeLines": code, "executedLines": executed, "percent": percent,
            "unexplained": coverage.get("unexplained"), "programs": len(programs),
            "neverEntered": sorted(str(p.get("program")) for p in programs if p.get("entered") is False),
            "uncoveredRanges": sum(len(p.get("uncovered") or []) for p in programs),
            "scope": coverage.get("scope")}


# --------------------------------------------------------------------------- derivations


def fixture_pack_id(unit: str, fixture: str) -> str:
    return f"{unit}/{Path(fixture).stem}"


def fixture_rel_file(unit: str, fixture: str) -> str:
    return f"{unit}/{Path(fixture).name}"


def pack_hash(files: list[tuple[str, bytes]]) -> str:
    """``FixtureManifest.packHash``: SHA-256 over ``<file>\\n<sha256 of its bytes, CRLF as LF>\\n`` per file, in load
    order - a checkout with other line endings has the same pack (and the same golden masters)."""
    lf = [(name, data.replace(b"\r\n", b"\n")) for name, data in files]
    identity = "".join(f"{name}\n{sha256_bytes(data)}\n" for name, data in lf)
    return sha256_bytes(identity.encode("utf-8"))


def _is_number(value) -> bool:
    return isinstance(value, (int, float, decimal.Decimal)) and not isinstance(value, bool)


def _scalars(value: dict, prefix: str):
    """(dotted path, value) of every scalar of a nested object, depth first (a list inside it is no field)."""
    for name, item in value.items():
        path = f"{prefix}.{name}"
        if isinstance(item, dict):
            yield from _scalars(item, path)
        elif not isinstance(item, list):
            yield path, item


def view_mapping(unit: str, bodies: list[dict], description: str) -> dict:
    """The payload mapping: every top-level scalar of the expected bodies a field, every scalar of a nested object a
    field under its dotted path (``processOptions.correctionEnabled`` - the framework reads a golden master and the
    answer at that path; U-126), every list of objects a group. A group's field is a NUMBER when every value the bodies
    give it is a number (none, or null, otherwise text) - so the comparison's number rules
    (``NUMERIC_SCALE_INSENSITIVE``: 1500.5 = 1500.50) reach a list's numbers too (U-125); the other group fields stay
    untyped, as before."""
    fields: dict[str, str] = {}
    groups: dict[str, list[str]] = {}
    kinds: dict[tuple[str, str], set[str]] = {}
    for body in bodies:
        for key, value in body.items():
            if isinstance(value, list):
                if all(isinstance(e, dict) for e in value):
                    names = groups.setdefault(key, [])
                    for element in value:
                        for name in element:
                            if name not in names:
                                names.append(name)
                            item = element[name]
                            kinds.setdefault((key, name), set()).add(
                                "null" if item is None else "number" if _is_number(item) else "other")
                continue
            if isinstance(value, dict):
                for path, item in _scalars(value, key):
                    fields.setdefault(path, "NUMBER" if isinstance(item, (int, decimal.Decimal))
                                      and not isinstance(item, bool) else "STRING")
                continue
            kind = "NUMBER" if isinstance(value, (int, decimal.Decimal)) and not isinstance(value, bool) else "STRING"
            fields.setdefault(key, kind)
    return {
        "schemaVersion": "1.0",
        "unit": unit,
        "description": description,
        "fields": [{"legacy": k, "target": k, "type": t} for k, t in fields.items()],
        "groups": [{"name": g, "target": g, "fields": [
            {"legacy": n, "target": n} | ({"type": "NUMBER"} if "number" in kinds.get((g, n), set())
                                          and kinds[(g, n)] <= {"number", "null"} else {})
            for n in names]} for g, names in groups.items()],
    }


def table_view_mappings(unit: str, doc: dict) -> dict[str, dict]:
    """Format 3: one view mapping per answer shape (:func:`mapping_id`) - the body's fields and lists (as
    :func:`view_mapping`), ``$empty`` (whether the answer had a body), and per table a group ``table:<TABLE>`` over
    ``$tables.<TABLE>`` with the columns typed from ``legacySchema.tables`` (``rows: set`` for a check compared as a
    set)."""
    specs = table_specs(doc)
    shapes: dict[str, dict] = {}
    for case in doc.get("cases", []):
        if not isinstance(case, dict) or not is_golden(case):
            continue
        shape = shapes.setdefault(capture_mapping_id(unit, case), {"bodies": [], "tables": [],
                                                                   "captures": captures(case)})
        body = (case.get("expected") or {}).get("body")
        if isinstance(body, dict):
            shape["bodies"].append(body)
        for check in table_checks(case):
            if check["name"] not in shape["tables"]:
                shape["tables"].append(check["name"])
    mappings = {}
    for mid, shape in sorted(shapes.items()):
        if not shape["captures"]:
            mappings[mid] = view_mapping(unit, shape["bodies"], f"API response of {unit} with a body of the shape "
                                                                f"{mid.split('--')[1]}; no table checks")
            continue
        mapping = view_mapping(unit, shape["bodies"], f"API response of {unit} with a body of the shape "
                                                      f"{mid.split('--', 1)[1]} and the rows the call left")
        mapping["fields"].append({"legacy": EMPTY, "target": EMPTY, "type": "STRING"})
        for name in shape["tables"]:
            spec = specs.get(name) or {"columns": {}}
            group = {"name": f"table:{name}", "target": f"{TABLES}.{name}",
                     "fields": [{"legacy": col, "target": col, "type": column_type(ddl)}
                                for col, ddl in spec["columns"].items()]}
            if spec.get("compare") == "set":
                group["rows"] = "set"
            mapping["groups"].append(group)
        mappings[mid] = mapping
    if any(isinstance(c, dict) and not is_golden(c) for c in doc.get("cases", [])):
        # mu-validate (step 2a): the not-applicable / blocked cases name the unit's mapping; nothing is compared
        mappings[unit] = view_mapping(unit, [], f"Cases of {unit} that do not run (not applicable or blocked): "
                                                "nothing is compared")
    return mappings


EMPTY = "$empty"                     # the framework's TableCapture keys: the answer had no body / the rows read after
TABLES = "$tables"


def comparison_rule_ids(doc: dict) -> list[str] | None:
    """The ids of a package's ``comparisonRules``, in order; None when it states none (an earlier package)."""
    stated = doc.get("comparisonRules")
    if not isinstance(stated, list):
        return None
    return [str(r.get("id")) for r in stated if isinstance(r, dict) and r.get("id")]


def comparison_rule_warnings(doc: dict) -> list[str]:
    """A package's comparison rule this release does not apply as stated: shown, never refused."""
    ids = comparison_rule_ids(doc) or []
    unknown = [i for i in ids if i not in PACKAGE_NORMALIZATION and i not in PACKAGE_STRUCTURE]
    return [f"comparisonRules: {', '.join(unknown)} not applied by this release (it applies "
            f"{', '.join([*PACKAGE_NORMALIZATION, *PACKAGE_STRUCTURE])})"] if unknown else []


def normalization_rules(doc: dict | None, tables: bool = False) -> tuple[str, ...]:
    """The contract profile's normalization rules for one package: the ones its ``comparisonRules`` state, else the
    fixed set of its kind (format 3 with table checks: bodies and rows on every answer - U-105)."""
    ids = comparison_rule_ids(doc or {})
    if ids is None:
        return TABLE_COMPARISON_RULES if tables else COMPARISON_RULES
    return tuple(dict.fromkeys(PACKAGE_NORMALIZATION[i] for i in ids if i in PACKAGE_NORMALIZATION))


def reset_tables(doc: dict) -> list[str]:
    """A package's ``resetTables`` (the tables emptied before every recording), upper case, in its order."""
    stated = doc.get("resetTables")
    return list(dict.fromkeys(str(t).strip().upper() for t in stated if str(t).strip())) if isinstance(stated, list) \
        else []


def stack_divergences(case: dict) -> list[str]:
    """Where a case's recording shows the test stack and not the mainframe (``stackDivergence``): prose, never an
    expected value."""
    stated = case.get("stackDivergence")
    return [str(s) for s in stated if str(s).strip()] if isinstance(stated, list) else []


def decided_answer(case: dict) -> dict | None:
    """A case whose expected answer the architecture decides (``decidedAnswer``: a decided parity register row - the
    expected status is the row's, not the one the recording gives), in brief: ``{source, status, recordedStatus,
    register?, required?, tables?, rules?}``; None for any other case. Reported as an accepted deviation (U-127)."""
    stated = decided_of(case)
    if stated is None:
        return None
    found = {"source": str(stated.get("source") or "").strip(), "status": stated.get("status"),
             "recordedStatus": stated.get("recordedStatus")}
    for key in ("register", "required", "tables"):
        if isinstance(stated.get(key), str) and stated[key].strip():
            found[key] = " ".join(stated[key].split())
    rules = [str(r) for r in stated.get("rules") or [] if str(r).strip()] if isinstance(stated.get("rules"), list) \
        else []
    if rules:
        found["rules"] = rules
    return found


def decided_warnings(doc: dict) -> list[str]:
    """A package with decided answers whose comparison is not ``OUTCOME_ONLY_ON_ERROR``: their error body (none is
    decided - only the status) is compared too."""
    ids = [c.get("id") for c in doc.get("cases") or [] if isinstance(c, dict) and is_golden(c) and decided_answer(c)]
    if not ids or "OUTCOME_ONLY_ON_ERROR" in normalization_rules(doc, checks_tables(doc)):
        return []
    return [f"{len(ids)} case(s) with a decided answer (e.g. {ids[0]}): the package does not state "
            "OUTCOME_ONLY_ON_ERROR, so their error body is compared too - the decision names only the status"]


def failure_binding(doc: dict) -> list[dict]:
    """The binding's technical-failure answers in brief, for the record gate: where, status, code, source and the
    ``when`` of a cause."""
    binding = doc.get("binding")
    if not isinstance(binding, dict):
        return []
    found = []
    tops = [("api", binding.get("technicalFailure"))] + [(f"operation {op.get('name')}", op.get("technicalFailure"))
                                                          for op in binding.get("operations") or [] if isinstance(op, dict)]
    for where, answer in tops:
        if not isinstance(answer, dict):
            continue
        for cause, entry in [(None, answer)] + [(c.get("when"), c) for c in answer.get("causes") or [] if isinstance(c, dict)]:
            body = entry.get("body") if isinstance(entry.get("body"), dict) else {}
            code = body.get("code")
            found.append({"where": where, "when": cause, "status": entry.get("status"), "source": entry.get("source"),
                          "code": code.split(":", 1)[1].strip('"') if isinstance(code, str) and code.startswith("const:")
                          else code})
    return found


def comparison_profile(units: list[str], texts: dict[str, str | None], tables: bool = False,
                       docs: dict[str, dict] | None = None) -> dict:
    """The ``contract`` profile of the package rules, one decision per unit, the package's own wording kept beside: the
    rules its ``comparisonRules`` state (``normalization_rules``), else format 3 with table checks (``tables``)
    compares bodies and rows on every answer (RTRIM, NULL as blank, decimals by value) and the rest as format 2."""
    rules = [{"rule": rule, "decision": f"PKG-CMP-{unit}"} for unit in units
             for rule in normalization_rules((docs or {}).get(unit), tables)]
    return {
        "schemaVersion": "1.0",
        "description": "Comparison rules of the golden-master package(s), applied as the contract profile; accepted "
                       "at the record gate. Package wording: " + " | ".join(
                           f"{u}: {texts.get(u) or '(none stated)'}" for u in units),
        "profiles": [{"name": "contract", "rules": rules}],
    }


def scenario(case: dict, unit: str, origin: dict, tags: list[str] | None = None, tables: bool = False) -> dict:
    """One register 1.1 scenario for one package case (no expected values: those are the golden master's).
    ``tags``: the explicit tags (``feature.register_tags``: hypothesis, critical, the rules it proves, its status).
    ``tables`` (format 3): the request body, the table checks the framework reads after the call, whether the answer
    is to be empty, and the view mapping of the answer's shape."""
    register_status = REGISTER_STATUS[case["status"]]
    legacy = case.get("legacy") or {}
    entry = {"scenarioId": case["id"], "origin": {**origin, "caseId": case["id"]}}
    for source, target in (("name", "title"), ("about", "description"), ("category", "category")):
        if case.get(source):
            entry[target] = str(case[source])
    entry["status"] = register_status
    if register_status != "runnable":
        entry["statusReason"] = str(case.get("reason"))
    if case.get("anticipatedJavaDivergence"):
        entry["hypotheses"] = [str(h) for h in case["anticipatedJavaDivergence"]]
    if stack_divergences(case):
        entry["stackDivergence"] = stack_divergences(case)
    if is_golden(case) and decided_answer(case):
        entry["decided"] = decided_answer(case)      # the expected answer is a decision, not the recording's (U-127)
    if case.get("clockSensitive") is not None:
        entry["clockSensitive"] = bool(case["clockSensitive"])
    if tags:
        entry["tags"] = list(tags)
    rule_ids = [str(r) for r in case.get("ruleIds") or [] if str(r).strip()] if isinstance(case.get("ruleIds"), list)         else []
    if rule_ids:                                       # mu-validate: the case's rules, as the producer states them
        entry["ruleIds"] = rule_ids
    entry["servicePoint"] = unit
    entry["levels"] = [{"level": "L4", "lens": "service", "legacy": f"LEG-SP:{unit}", "target": "TGT-HTTP:app",
                        "mapping": unit}]
    if case.get("fixture"):
        entry["fixture"] = fixture_pack_id(unit, case["fixture"])
    if isinstance(case.get("clock"), str) and _CLOCK.match(case["clock"]):
        entry["clock"] = case["clock"]
    entry["request"] = {str(k): str(v) for k, v in (legacy.get("inputs") or {}).items()}
    request = case.get("request")
    if isinstance(request, dict) and request.get("path"):
        entry["http"] = {"method": str(request.get("method", "GET")).upper(), "path": request["path"],
                         "query": {str(k): str(v) for k, v in (request.get("query") or {}).items()}}
        if isinstance(request.get("body"), dict):           # mu-validate: kept with or without table checks (2a)
            entry["http"]["body"] = request["body"]
        if principal_of(case):                                    # format 3 (the contract), with or without tables
            entry["http"]["principal"] = principal_of(case)      # the user the call is made as (part of the oracle)
    expected = case.get("expected") or {}
    body = expected.get("body")
    if tables and is_golden(case):
        entry["levels"][0]["mapping"] = capture_mapping_id(unit, case)
        checks = table_checks(case)
        if captures(case):
            entry["tables"] = [{"name": c["name"], "query": c["query"], "columns": [str(x) for x in c["columns"]],
                                "compare": c.get("compare") or "ordered"} for c in checks]
            entry["answerEmpty"] = answer_empty(case)
        compare = set_compare(case, tables=True)
        groups = [v for v in (body or {}).values() if isinstance(v, list)] + [c["rows"] for c in checks]
        if groups and all(not g for g in groups):
            compare["expectEmpty"] = True             # stated by the package (rows: []), never a vacuous match
        if ignore_entries(case):
            compare["ignore"] = ignore_entries(case)
        if compare:
            entry["compare"] = compare
        return entry
    if is_golden(case) and isinstance(body, dict) and 200 <= int(expected.get("status", 0)) < 300:
        compare = set_compare(case)                    # an order difference in a set list: a note
        lists = [v for v in body.values() if isinstance(v, list)]
        if lists and all(not v for v in lists):
            compare["expectEmpty"] = True
        if ignore_entries(case):
            compare["ignore"] = ignore_entries(case)  # the contract verdict leaves these paths out; strict shows them
        if compare:
            entry["compare"] = compare
    return entry


def provenance(case: dict, doc: dict, fixture_pack: str) -> dict:
    """How a golden case was recorded: the package's engine, the legacy sources' hashes, the fixture pack, the clock,
    the repeats and when (``Provenance``)."""
    recording = case.get("recording") if isinstance(case.get("recording"), dict) else {}
    found = {"platform": "gnucobol-emulated", "engine": str(doc.get("goldenMaster") or "golden-master package"),
             "sources": recording_members(doc, case), "fixture": fixture_pack, "clock": case["clock"], "env": {},
             "dbMode": "logic",
             "repeatRuns": recording["repeats"] if isinstance(recording.get("repeats"), int) else 1}
    if recording.get("recordedAt"):
        found["recordedAt"] = str(recording["recordedAt"])
    return found


def table_payload(case: dict) -> dict:
    """Format 3: the expected answer as the framework's ``TableCapture`` builds the target's - the body's fields, ``$empty``
    and ``$tables.<TABLE>`` (each row an object of its columns, NULL kept)."""
    body = (case.get("expected") or {}).get("body")
    payload = dict(body) if isinstance(body, dict) else {}
    if not captures(case):              # mu-validate (F9): no $empty / $tables without table checks
        return payload if payload else None
    payload[EMPTY] = answer_empty(case)
    payload[TABLES] = {c["name"]: [dict(zip([str(x) for x in c["columns"]], row)) for row in c["rows"]]
                       for c in table_checks(case)}
    return payload


def golden_master(case: dict, unit: str, origin: dict, provenance_of_case: dict, imported_at: str,
                  supersedes: str | None, tables: bool = False) -> dict:
    """A sealed golden master (schema 1.1) for one golden package case: the expected answer as the observation, the
    raw legacy report and the recording as evidence, state RECORDED. Format 3 (``tables``): the answer with its
    emptiness and the rows the call left (:func:`table_payload`)."""
    expected = case["expected"]
    status = int(expected["status"])
    if tables:
        expected = {**expected, "body": table_payload(case)}
    legacy = case.get("legacy") if isinstance(case.get("legacy"), dict) else None
    evidence = {"legacy": legacy} if legacy else {}
    if isinstance(case.get("recording"), dict):
        evidence["recording"] = case["recording"]
    decided = decided_of(case)
    if isinstance(decided, dict):
        # the observation is the decided answer: the decision and the answer the recording gives stay beside it (the
        # recorded rows are the legacy's verify / the expected tables already)
        evidence["decidedAnswer"] = {k: v for k, v in decided.items() if k != "recorded"}
        if isinstance(decided.get("recorded"), dict):
            evidence["decidedAnswer"]["recorded"] = {k: v for k, v in decided["recorded"].items() if k != "tables"}
    master = {
        "schemaVersion": "1.1",
        "scenarioId": case["id"],
        "unit": unit,
        "level": "L4",
        "lens": "service",
        "origin": {**origin, "caseId": case["id"]} | ({"runId": str(legacy["runId"])}
                                                     if (legacy or {}).get("runId") else {}),
        "request": {str(k): str(v) for k, v in ((legacy or {}).get("inputs") or {}).items()},
        "observation": {
            "form": "TARGET_PAYLOAD",
            "fields": {},
            "groups": {},
            "outcome": {"kind": status_class(status), "exitState": status},
            **({"payload": expected["body"]} if expected.get("body") is not None else {}),   # an error may have none
            "meta": {},
        },
        "evidence": evidence,
        "provenance": provenance_of_case,
        "state": "RECORDED",
        "history": [{"to": "RECORDED", "at": imported_at, "by": "e2e_package import",
                     "reason": f"imported from {origin.get('package')} (case {case['id']})"}],
    }
    if supersedes:
        master["supersedes"] = supersedes
    master["contentHash"] = canonical.golden_hash(master)
    return master


def file_hash(path: Path) -> str:
    return sha256_file(path)
