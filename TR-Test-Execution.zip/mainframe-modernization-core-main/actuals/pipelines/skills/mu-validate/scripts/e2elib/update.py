"""What changed in a unit's suite between E2E's last import and the package now - and the suite update report.

The baseline is E2E's own last import (the MU module's register, golden masters and rules, and the import manifest),
never an older package, which was replaced in place. Cases are matched by id; a case whose name changed under the
same id is another case (**replaced**). Each case is seen through two kinds of field:

- **the oracle** - what a golden master's acceptance covers: the request (the HTTP request and the legacy inputs), the
  expected status and body, the fixture pack and its content hash, the clock, whether the case runs at all, whether
  its rows are compared as a set and the answer paths it does not compare (each only part of the oracle when a case
  has it, so the key of every other case stays as it was). A change here supersedes the golden master: it is RECORDED
  again and the record gate asks for it.
- **descriptive** - title, description, category, hypotheses, the stack divergences, the date-dependent flag, the
  reason of a case that does not run, the rules it proves. Shown, never a reason to re-accept. (mu-validate has no
  BA alignment: the BA-link parts below are never reached.)

Anything else a package regeneration changes (another version or folder, the recording's run ids, repeats, source
hashes and raw legacy report, the package's description of how it was recorded) leaves an accepted golden master as
it is.
"""

from __future__ import annotations

import re

from . import canonical, feature

ORACLE = ("runs", "http", "request", "expectedStatus", "expectedBody", "fixture", "fixtureHash", "clock", "rows",
          "setPaths", "tables", "answerEmpty", "notCompared", "decided")
# in the key only when a case has them (format 2 keys unchanged; setPaths - one list of an answer as a set, U-123 -
# only for such a case, so the earlier packages' keys stay as they were; decided - the expected answer is a decision of
# the architecture, U-127: the person accepts the decision with the recording)
OPTIONAL_ORACLE = ("rows", "setPaths", "tables", "answerEmpty", "notCompared", "decided")
DESCRIPTIVE = ("title", "description", "category", "hypotheses", "stackDivergence", "clockSensitive", "statusReason",
               "rules", "stories", "examples")
SHOWN = 60


# --------------------------------------------------------------------------- one view of a case, either side


def case_view(entry: dict, golden: dict | None, rules: list[dict] | None = None) -> dict:
    """A register entry and its golden master (or None) as the fields the diff compares; the rules a case proves come
    from the unit's rules (``rules/<UNIT>.json``), else from the entry's ``rule:`` tags."""
    observation = (golden or {}).get("observation") or {}
    proved = sorted(r["id"] for r in rules if entry.get("scenarioId") in r.get("provenBy", [])) if rules is not None \
        else sorted(t[len("rule:"):] for t in entry.get("tags") or [] if t.startswith("rule:"))
    provenance = (golden or {}).get("provenance") or {}
    return {
        # a scenario blocked only because no caller identity is configured runs as recorded once there is one: the
        # block is this workspace's configuration, no property of the recording (its acceptance stays)
        "runs": "runnable" if entry.get("blockedBy") == "identity" else entry.get("status", "runnable"),
        "http": entry.get("http"),
        "request": entry.get("request") or {},
        "expectedStatus": (observation.get("outcome") or {}).get("exitState") if golden else None,
        "expectedBody": observation.get("payload") if golden else None,
        "fixture": entry.get("fixture"),
        "fixtureHash": provenance.get("fixture") if golden else None,
        "clock": entry.get("clock"),
        "rows": "set" if (entry.get("compare") or {}).get("rows") == "set" else None,
        "setPaths": sorted((entry.get("compare") or {}).get("setPaths") or []) or None,
        "tables": entry.get("tables") or None,
        "answerEmpty": entry.get("answerEmpty"),
        # the paths only: a reason worded otherwise changes no comparison
        "notCompared": sorted(i["path"] for i in (entry.get("compare") or {}).get("ignore") or []) or None,
        # the decision and what it changes (the row's wording or file:line moving changes no comparison)
        "decided": {k: (entry.get("decided") or {}).get(k) for k in ("source", "status", "recordedStatus", "tables")}
        if entry.get("decided") else None,
        "title": entry.get("title"),
        "description": entry.get("description"),
        "category": entry.get("category"),
        "hypotheses": entry.get("hypotheses") or [],
        "stackDivergence": entry.get("stackDivergence") or [],
        "clockSensitive": bool(entry.get("clockSensitive")),
        "statusReason": entry.get("statusReason"),
        "rules": proved,
        # the BA links of either alignment layout: user stories / business scenarios, acceptance examples /
        # requirements
        "stories": feature.tag_values(entry, "story") + feature.tag_values(entry, "bs"),
        "examples": feature.tag_values(entry, "ae") + feature.tag_values(entry, "fr"),
    }


def oracle_key(entry: dict | None, golden: dict | None) -> str:
    """One hash over a golden case's oracle (two equal keys: the same acceptance covers both). The set comparison
    joins the key only when a case has it, so the key of every other case is the one an earlier import computed."""
    view = case_view(entry or {}, golden)
    return canonical.canonical_hash({k: canonical.JsonNode(view[k]) for k in ORACLE
                                     if k not in OPTIONAL_ORACLE or view[k] is not None})


def baseline(resources, unit: str, rules: list[dict] | None = None) -> dict[str, dict]:
    """The last import of ``unit`` in the MU module: id -> view (empty when the unit was never imported)."""
    register = resources / "scenarios" / f"{unit}.json"
    if not register.is_file():
        return {}
    goldens = {p.stem: canonical.load_json(p) for p in sorted((resources / "golden" / unit).glob("*.json"))}
    return {e["scenarioId"]: case_view(e, goldens.get(e["scenarioId"]), rules)
            for e in canonical.load_json(register).get("scenarios", [])}


# --------------------------------------------------------------------------- the diff


def _short(value, limit: int = SHOWN) -> str:
    if value is None:
        return "(none)"
    if isinstance(value, dict) and set(value) >= {"method", "path"}:
        text, limit = f"{value['method']} {feature.http_target(value)}", 4 * limit   # the request is the point
        if value.get("principal"):
            text += f" as user {value['principal']}"                                 # who calls is part of it
    elif isinstance(value, (dict, list)):
        text = canonical.canonical_text(canonical.JsonNode(value))
    else:
        text = str(value)
    return text if len(text) <= limit else text[:limit - 3] + "..."


def _map_changes(label: str, old, new) -> list[dict]:
    """A map (the legacy inputs) key by key."""
    if not isinstance(old, dict) or not isinstance(new, dict):
        return [{"field": label, "from": _short(old), "to": _short(new)}]
    return [{"field": f"{label} {key}", "from": _short(old.get(key)), "to": _short(new.get(key))}
            for key in list(old) + [k for k in new if k not in old] if old.get(key) != new.get(key)]


def _body_changes(old, new) -> list[dict]:
    """The expected body field by field: scalars with old and new value; a list of rows by its count, or - same
    count - the fields of the first row that differs."""
    if not isinstance(old, dict) or not isinstance(new, dict):
        return [{"field": "expected.body", "from": _short(old), "to": _short(new)}]
    changes = []
    for key in list(old) + [k for k in new if k not in old]:
        a, b = old.get(key), new.get(key)
        if a == b:
            continue
        if isinstance(a, list) and isinstance(b, list):
            first = next((i for i, (x, y) in enumerate(zip(a, b)) if x != y), min(len(a), len(b)))
            if len(a) == len(b) and isinstance(a[first], dict) and isinstance(b[first], dict):
                changes += [{"field": f"expected.body.{key}[{first + 1}].{name}", "from": _short(a[first].get(name)),
                             "to": _short(b[first].get(name))}
                            for name in list(a[first]) + [n for n in b[first] if n not in a[first]]
                            if a[first].get(name) != b[first].get(name)]
                rows = sum(1 for x, y in zip(a, b) if x != y)
                if rows > 1:
                    changes[-1]["detail"] = f"{rows} rows differ"
            else:
                changes.append({"field": f"expected.body.{key}", "from": f"{len(a)} rows", "to": f"{len(b)} rows",
                                "detail": f"first difference at row {first + 1}"})
        else:
            changes.append({"field": f"expected.body.{key}", "from": _short(a), "to": _short(b)})
    return changes


BUSINESS, STORIES = "business-scenarios", "user-stories"
# The BA links in the words of their alignment layout: business scenarios BS-n.x and functional requirements FR-n.x
# (the bs: / fr: tags), or - an alignment of the earlier layout - user stories US-n.x and acceptance examples AE-n.x
# (story: / ae:). A case's links are of one layout; case_view keeps both kinds under "stories" / "examples".
BA_WORDS = {
    BUSINESS: {"stories": "business scenarios", "examples": "requirements", "Stories": "Business scenarios",
               "story": "Business scenario", "tags": "`bs:` / `fr:`", "storyTags": "Business-scenario tags",
               "exampleTags": "requirement tags", "changedRows": "Business scenarios", "per": "business scenario"},
    STORIES: {"stories": "user stories", "examples": "acceptance examples", "Stories": "User stories",
              "story": "Story", "tags": "`story:` / `ae:`", "storyTags": "Story tags",
              "exampleTags": "acceptance-example tags", "changedRows": "Stories", "per": "story"},
}


def ba_layout(*groups) -> str:
    """The alignment layout of BA link ids: business scenarios when any is a ``BS-`` or ``FR-`` id, else user stories
    (the earlier layout's ``US-`` / ``AE-`` ids, or none)."""
    ids = [str(i) for group in groups for i in (group if isinstance(group, (list, tuple, set)) else [])]
    return BUSINESS if any(i.startswith(("BS-", "FR-")) for i in ids) else STORIES


def section_layout(section: dict | None) -> str:
    """The layout of an update record's BA section: as recorded (``layout``), else from the ids it names."""
    section = section or {}
    return section.get("layout") or ba_layout([s.get("id") for s in section.get("stories") or []])


def compare(old: dict, new: dict) -> list[dict]:
    """The changed fields of one case, the oracle's first; each ``{"field", "from", "to", "oracle"}``. The BA links
    are named in the words of their layout (business scenarios / requirements, or user stories / acceptance
    examples)."""
    changes = []
    for field in ORACLE + DESCRIPTIVE:
        a, b = old.get(field), new.get(field)
        if a == b:
            continue
        if field == "expectedBody":
            changes += [dict(c, oracle=True) for c in _body_changes(a, b)]
            continue
        if field == "request":
            changes += [dict(c, oracle=True) for c in _map_changes("legacy input", a, b)]
            continue
        label = {"runs": "status", "http": "request", "request": "legacy inputs", "expectedStatus": "expected.status",
                 "fixtureHash": "fixture content", "rows": "rows compared as",
                 "setPaths": "lists compared as a set", "notCompared": "not compared", "decided": "decided answer",
                 "stackDivergence": "stack divergences"}.get(field, field)
        if field in ("stories", "examples"):
            label = BA_WORDS[ba_layout(a, b)][field]
        if field == "clock":
            a, b = (feature.readable_clock(v) if isinstance(v, str) and len(v) == 14 else v for v in (a, b))
        if field == "rows":
            a, b = (v or "in order" for v in (a, b))
        if field == "fixtureHash":
            a, b = (str(v)[:12] if v else v for v in (a, b))
        changes.append({"field": label, "from": _short(a), "to": _short(b), "oracle": field in ORACLE})
    return changes


def replaced(old: dict, new: dict) -> bool:
    """Another case under the same id: both sides are named, and the names differ (a renumbered package)."""
    return bool(old.get("title")) and bool(new.get("title")) and old["title"] != new["title"]


def diff(old: dict[str, dict], new: dict[str, dict]) -> dict:
    """ID-matched: added, removed, changed (with fields and whether the golden master needs a new acceptance; a case
    replaced by another under the same id is a change with ``replaced`` and the names)."""
    added = [i for i in new if i not in old]
    removed = [i for i in old if i not in new]
    changed, unchanged = [], 0
    for case_id in [i for i in new if i in old]:
        fields = compare(old[case_id], new[case_id])
        if not fields:
            unchanged += 1
            continue
        oracle = any(f["oracle"] for f in fields)
        item = {"id": case_id, "reAccept": oracle and new[case_id]["runs"] == "runnable", "fields": fields}
        if replaced(old[case_id], new[case_id]):
            item.update(replaced=True, was=old[case_id]["title"], now=new[case_id]["title"])
        changed.append(item)
    reaccept = [i for i in added if new[i]["runs"] == "runnable"] + [c["id"] for c in changed if c["reAccept"]]
    return {"added": [{"id": i, "status": new[i]["runs"], "title": new[i].get("title")} for i in added],
            "removed": [{"id": i, "status": old[i]["runs"], "title": old[i].get("title")} for i in removed],
            "changed": changed, "unchanged": unchanged, "reAccept": reaccept}


def fixture_changes(old: dict[str, dict], new: dict[str, dict]) -> list[dict]:
    """Each fixture pack whose content changed, with the cases on it."""
    packs = {}
    for case_id, view in new.items():
        before = old.get(case_id)
        if view.get("fixtureHash") and before and before.get("fixtureHash") \
                and before["fixtureHash"] != view["fixtureHash"]:
            packs.setdefault(view["fixture"], {"fixture": view["fixture"], "from": before["fixtureHash"][:12],
                                               "to": view["fixtureHash"][:12], "cases": []})["cases"].append(case_id)
    return list(packs.values())


def package_changes(frm: dict, to: dict) -> list[str]:
    """What differs between E2E's last import of a unit (``frm``) and its package now (``to``): another place, another
    version, the package JSON, the companion Markdown, the BA alignment, the BA analysis it takes the stories' titles
    from, the fixture files. ``e2e_package status`` marks the stages stale on any of them, and the import writes an
    update record naming them. A hash the last import did not record (an import before format 2; the BA analysis before
    format 6) is no change; a BA alignment the last import did not record is one only when the package has it now
    (added)."""
    changes = []
    if frm.get("package") != to.get("package"):
        changes.append(f"package moved: {frm.get('package')} -> {to.get('package')}")
    if frm.get("version") != to.get("version") or (frm.get("packageFormat") or 1) != (to.get("packageFormat") or 1):
        lower = isinstance(frm.get("version"), int) and isinstance(to.get("version"), int) \
            and to["version"] < frm["version"] and (frm.get("packageFormat") or 1) == (to.get("packageFormat") or 1)
        changes.append(f"package {frm.get('label')} (format {frm.get('packageFormat') or 1}) -> {to.get('label')} "
                       f"(format {to.get('packageFormat') or 1})" + (" - a LOWER version than the last import" if lower
                                                                      else ""))
    for key, label in (("packageHash", "package content"), ("markdownHash", "companion Markdown"),
                       ("fixtureHashes", "fixture files")):
        if frm.get(key) is not None and frm.get(key) != to.get(key):
            changes.append(f"{label} changed")
    if frm.get("baAlignmentHash") != to.get("baAlignmentHash"):
        changes.append("BA alignment " + ("added" if not frm.get("baAlignmentHash") else
                                          "removed" if not to.get("baAlignmentHash") else "changed"))
    if frm.get("baRecorded") and frm.get("baArtifactsHash") != to.get("baArtifactsHash"):
        changes.append(f"BA analysis ({to.get('baArtifacts') or frm.get('baArtifacts')}, the stories' titles) "
                       + ("added" if not frm.get("baArtifactsHash") else
                          "removed" if not to.get("baArtifactsHash") else "changed"))
    return changes


def update_reasons(frm: dict, to: dict) -> str:
    """Why an update record exists: the package's changes, then an import-format upgrade."""
    reasons = package_changes(frm, to)
    if (frm.get("importFormat") or 1) != to.get("importFormat"):
        reasons.append(f"import format {frm.get('importFormat') or 1} -> {to.get('importFormat')} (E2E's generated "
                       "files rewritten)")
    return "; ".join(reasons) or "nothing in the package - E2E's generated files differed from what the import writes"


def rule_changes(old: list[dict], new: list[dict]) -> dict:
    before, after = {r["id"]: r for r in old}, {r["id"]: r for r in new}
    return {"added": [i for i in after if i not in before], "removed": [i for i in before if i not in after],
            "changed": [i for i in after if i in before and (after[i].get("text") != before[i].get("text")
                                                              or after[i].get("provenBy") != before[i].get("provenBy"))]}


def story_changes(old: dict[str, dict], new: dict[str, dict], alignment: dict | None = None) -> dict | None:
    """mu-validate: no BA alignment, no per-story section (step 2a, BA paths are no-ops)."""
    return None


def _story_source_line(frm: dict, to: dict) -> str:
    return ""


def _moved_text(moved: dict) -> str:
    """``66 on new scenarios, 2 gained, 46 lost, 0 changed, 0 on removed scenarios`` - one kind of tag; gained, lost
    and changed count the scenarios kept from the last import."""
    return (f"{len(moved.get('new') or [])} on new scenarios, {len(moved['gained'])} gained, {len(moved['lost'])} "
            f"lost, {len(moved['changed'])} changed, {len(moved.get('removed') or [])} on removed scenarios")


def story_lines(record: dict, results: dict[str, dict] | None = None) -> list[str]:
    """The per-story section of an update record or a suite update report (``results``: story -> this run's rollup)."""
    section = record.get("stories")
    if not section:
        return []
    words = BA_WORDS[section_layout(section)]
    scenarios, examples = section["scenarios"], section["examples"]
    lines = [_story_source_line(record["from"], record["to"]), "",
             f"{words['storyTags']}: {_moved_text(scenarios)}; {words['exampleTags']}: {_moved_text(examples)}. "
             f"{words['changedRows']} whose scenarios changed: {len(section['stories'])}; unchanged: "
             f"{section['storiesUnchanged']}.", ""]
    if section["stories"]:
        header = f"| {words['story']} | Title | Status now | Scenarios now | Added | Removed |"
        lines += [header + (" Results (this run) |" if results is not None else ""),
                  "|---|---|---|---|---|---|" + ("---|" if results is not None else "")]
        for story in section["stories"]:
            row = (f"| {story['id']} | {_cell(story.get('title') or '-')} | "
                   f"{_cell(story.get('status') or 'not in the alignment')} | {', '.join(story['now']) or '-'} | "
                   f"{', '.join(story['added']) or '-'} | {', '.join(story['removed']) or '-'} |")
            if results is not None:
                row += " - |"
            lines.append(row)
        lines.append("")
    return lines


# --------------------------------------------------------------------------- Markdown


def _cell(text) -> str:
    return re.sub(r"\s+", " ", str(text if text is not None else "")).replace("|", "/")


def identity_rows(frm: dict, to: dict) -> list[str]:
    """The hash and format rows of an update's ``| | before | now |`` table - what the change detection compares."""
    def short(value) -> str:
        return str(value)[:12] if value else "-"

    def files(hashes) -> str:
        return ", ".join(f"`{name}` {short(value)}" for name, value in sorted(hashes.items())) if hashes else "-"

    return [f"| Package format | {frm.get('packageFormat') or 1} | {to.get('packageFormat') or 1} |",
            f"| Package content hash (producer's seal) | {short(frm.get('contentHash'))} | "
            f"{short(to.get('contentHash'))} |",
            f"| Package SHA-256 | {short(frm.get('packageHash'))} | {short(to.get('packageHash'))} |",
            f"| Companion Markdown SHA-256 | {short(frm.get('markdownHash'))} | {short(to.get('markdownHash'))} |",
            f"| BA alignment SHA-256 | {short(frm.get('baAlignmentHash'))} | {short(to.get('baAlignmentHash'))} |",
            f"| BA analysis (story titles) hash | {short(frm.get('baArtifactsHash'))} | "
            f"{short(to.get('baArtifactsHash'))} |",
            f"| Fixture files SHA-256 | {files(frm.get('fixtureHashes'))} | {files(to.get('fixtureHashes'))} |",
            f"| Import format | {frm.get('importFormat') or 1} | {to.get('importFormat')} |"]


def change_rows(record: dict, only: set[str] | None = None) -> list[str]:
    """Table rows ``| case | change | fields |`` of a diff (``only``: these case ids)."""
    rows = []
    cases = record["cases"]
    for item in cases["added"]:
        if only is None or item["id"] in only:
            rows.append(f"| {item['id']} | new ({item['status']}) | {_cell(item.get('title'))} |")
    for item in cases["changed"]:
        if only is None or item["id"] in only:
            if item.get("replaced"):
                kind = "replaced by another case" + (" - accept" if item["reAccept"] else " (same oracle)")
                rows.append(f"| {item['id']} | {kind} | was {_cell(item['was'])}, now {_cell(item['now'])} |")
                continue
            fields = "; ".join(f"{f['field']}: {_cell(f['from'])} -> {_cell(f['to'])}"
                               + (f" ({f['detail']})" if f.get("detail") else "") for f in item["fields"])
            kind = "changed - accept again" if item["reAccept"] else "changed (description only)"
            rows.append(f"| {item['id']} | {kind} | {fields} |")
    for item in cases["removed"]:
        if only is None or item["id"] in only:
            rows.append(f"| {item['id']} | removed | {_cell(item.get('title'))} |")
    return rows


def execution_delta(before: dict[str, tuple], after: dict[str, tuple]) -> dict:
    """Two runs' fingerprints (``scenario|level|unit`` -> (status, difference signatures[, title])) compared; a scenario
    whose title changed under the same id is another case (``replaced``), never compared with the old one."""
    out = {"newlyPassing": [], "newlyFailing": [], "stillFailingSameSignature": [],
           "stillFailingOtherSignature": [], "new": [], "removed": [], "replaced": [], "otherChanges": [],
           "unchanged": 0}
    for key in sorted(set(before) | set(after)):
        sid = key.split("|", 1)[0]
        if key not in before:
            out["new"].append({"scenarioId": sid, "status": after[key][0]})
        elif key not in after:
            out["removed"].append({"scenarioId": sid, "status": before[key][0]})
        else:
            (was, was_sig, *was_title), (now, now_sig, *now_title) = before[key], after[key]
            if was_title and now_title and was_title[0] and now_title[0] and was_title[0] != now_title[0]:
                out["replaced"].append({"scenarioId": sid, "was": was_title[0], "now": now_title[0], "status": now})
            elif was == now == "FAILED":
                out["stillFailingSameSignature" if tuple(was_sig) == tuple(now_sig)
                    else "stillFailingOtherSignature"].append(sid)
            elif was == now:
                out["unchanged"] += 1
            elif now == "PASSED":
                out["newlyPassing"].append({"scenarioId": sid, "from": was})
            elif now == "FAILED":
                out["newlyFailing"].append({"scenarioId": sid, "from": was})
            else:
                out["otherChanges"].append({"scenarioId": sid, "from": was, "to": now})
    return out


def _ids(items: list) -> str:
    out = []
    for item in items:
        if isinstance(item, str):
            out.append(item)
        elif "was" in item:
            out.append(f"{item['scenarioId']} ({item['was']} -> {item['now']}: {item['status']})")
        elif "to" in item:
            out.append(f"{item['scenarioId']} {item['from']} -> {item['to']}")
        elif "from" in item:
            out.append(f"{item['scenarioId']} (was {item['from']})")
        else:
            out.append(f"{item['scenarioId']} {item['status']}")
    return ", ".join(out) or "-"


def delta_lines(delta: dict) -> list[str]:
    """Table rows ``| change | count | scenarios |`` of an execution delta."""
    rows = [(label, delta[key]) for key, label in (
        ("newlyPassing", "Newly passing"), ("newlyFailing", "Newly failing"),
        ("stillFailingSameSignature", "Still failing, same difference"),
        ("stillFailingOtherSignature", "Still failing, another difference"), ("new", "New scenarios"),
        ("removed", "Removed scenarios"), ("replaced", "Replaced by another case (same id, not compared)"),
        ("otherChanges", "Other status changes")) if key != "replaced" or delta.get(key)]
    return [f"| {label} | {len(items)} | {_ids(items)} |" for label, items in rows] + [
        f"| Unchanged (not failing) | {delta['unchanged']} | |"]


def replaced_note(cases: dict) -> str:
    """`` (N of them replaced by another case under the same id)`` when the package renumbered its cases."""
    count = sum(1 for c in cases["changed"] if c.get("replaced"))
    return f" ({count} of them replaced by another case under the same id)" if count else ""


def report_summary(report: dict) -> str:
    """One line for the orchestrator's final report."""
    cases, gate, delta = report["cases"], report["gate"], (report["execution"] or {}).get("deltaFromPrevious")
    text = (f"{report['unit']} {report['from'].get('label')} -> {report['to'].get('label')}: "
            f"{len(cases['added'])} added, {len(cases['removed'])} removed, {len(cases['changed'])} changed"
            f"{replaced_note(cases)}; "
            f"{len(gate['accepted'])} accepted again" + (f" by {', '.join(gate['by'])}" if gate["by"] else "")
            + (f", {len(gate['disputed'])} disputed" if gate["disputed"] else ""))
    if delta:
        text += (f"; execution: {len(delta['newlyPassing'])} newly passing, {len(delta['newlyFailing'])} newly "
                 f"failing, {len(delta['stillFailingSameSignature']) + len(delta['stillFailingOtherSignature'])} "
                 f"still failing, {len(delta['new'])} new, {len(delta['removed'])} removed"
                 + (f", {len(delta['replaced'])} replaced by another case" if delta.get("replaced") else ""))
    return text


def report_markdown(report: dict) -> str:
    """The suite update report (``validation/<MU>/updates/<ts>-<UNIT>-<from>-to-<to>.md``)."""
    frm, to, cases, golden, gate = report["from"], report["to"], report["cases"], report["golden"], report["gate"]
    execution = report.get("execution") or {}
    lines = [f"# Suite update report - {report['mu']} - {report['unit']} {frm.get('label')} -> {to.get('label')}", "",
             f"Written by `e2e_test_solution` after the execute stage's run `{execution.get('runId')}`, from the design "
             f"stage's update record `{report['update']['file']}`, the record gate's signed decisions and the execute "
             "summary. Compared with E2E's own last import; cases matched by id.", "",
             f"**Summary:** {report['summary']}.", "",
             "## Versions", "", "| | Before | Now |", "|---|---|---|",
             f"| Package | `{frm.get('package')}` | `{to.get('package')}` |",
             f"| Version | {frm.get('label')} | {to.get('label')} |",
             *identity_rows(frm, to),
             f"| Imported | {frm.get('importedAt')} | {to.get('importedAt')} |", "",
             f"**Changed since the last import:** {update_reasons(frm, to)}.", "",
             "## Cases", "",
             f"{len(cases['added'])} added, {len(cases['removed'])} removed, {len(cases['changed'])} changed"
             f"{replaced_note(cases)}, {cases['unchanged']} unchanged.", ""]
    rows = change_rows(report)
    if rows:
        lines += ["| Case | Change | Fields (before -> now) |", "|---|---|---|"] + rows + [""]
    if report["fixtures"]:
        lines += ["Fixtures changed: " + "; ".join(f"`{f['fixture']}` ({', '.join(f['cases'])})"
                                                   for f in report["fixtures"]), ""]
    if report.get("stories"):
        words = BA_WORDS[section_layout(report["stories"])]
        lines += [f"## {words['Stories']} (BA alignment)", "",
                  f"The scenarios' {words['tags']} tags before and after the update"
                  + (f", with this run's results per {words['per']}." if execution.get("runId") else "."), ""]
        lines += story_lines(report, report.get("storyResults") if execution.get("runId") else None)
    lines += ["## Golden masters", "", "| | Count | Cases |", "|---|---|---|"]
    for key, label in (("written", "Written (new, RECORDED)"), ("superseded", "Superseded (changed, RECORDED again; "
                                                                               "the old one archived STALE)"),
                       ("orphaned", "Orphaned (no longer golden; archived STALE)"),
                       ("keptOracleUnchanged", "Kept although metadata or evidence changed (another version, run "
                                               "ids, the recording)")):
        ids = golden[key]
        shown = ", ".join(ids[:12]) + (f", ... ({len(ids) - 12} more in the JSON)" if len(ids) > 12 else "")
        lines.append(f"| {label} | {len(ids)} | {shown or '-'} |")
    lines += [f"| Kept, their acceptance stands (all) | {len(golden['kept'])} | |", "",
              "## Record gate", "",
              f"- Asked for: {', '.join(gate['asked']) or 'nothing (no recording new or changed)'}",
              f"- Accepted: {', '.join(gate['accepted']) or '-'}" + (f" - by {', '.join(gate['by'])}" if gate["by"] else ""),
              f"- Disputed: {', '.join(gate['disputed']) or '-'}", "",
              "## Behaviour Specification", "",
              f"`{report['feature']['file']}` " + ("rewritten" if report["feature"]["changed"] else "unchanged")
              + (f"; scenarios added {', '.join(a['id'] for a in cases['added'])}" if cases["added"] else "")
              + (f"; removed {', '.join(r['id'] for r in cases['removed'])}" if cases["removed"] else "") + ".", ""]
    if execution:
        lines += [f"## Execution (run `{execution['runId']}`, {execution.get('runs')} run(s), repeatable: "
                  f"{execution.get('repeatable')})", "", "| Status | Scenario levels |", "|---|---|"]
        lines += [f"| {k} | {v} |" for k, v in sorted((execution.get("counts") or {}).items())]
        delta = execution.get("deltaFromPrevious")
        if delta:
            lines += ["", f"Compared with the previous run `{execution.get('previousRunId')}`:", "",
                      "| Change | Count | Scenarios |", "|---|---|---|"] + delta_lines(delta)
        else:
            lines += ["", "No earlier full run to compare with."]
    return "\n".join(lines) + "\n"


def update_markdown(record: dict) -> str:
    """The design stage's update record of one unit (``validation/<MU>/design/update-<UNIT>.md``)."""
    frm, to, cases, golden = record["from"], record["to"], record["cases"], record["golden"]
    lines = [f"# Package update - {record['unit']} {frm.get('label')} -> {to.get('label')}", "",
             "Written by `e2e_package import` (design); compared with E2E's own last import, cases matched by id.", "",
             "| | Last import | Now |", "|---|---|---|",
             f"| Package | `{frm.get('package')}` | `{to.get('package')}` |",
             f"| Version | {frm.get('label')} | {to.get('label')} |",
             *identity_rows(frm, to),
             f"| Imported | {frm.get('importedAt')} | {to.get('importedAt')} |", "",
             f"**Changed since the last import:** {update_reasons(frm, to)}.", "",
             f"**Cases:** {len(cases['added'])} added, {len(cases['removed'])} removed, {len(cases['changed'])} "
             f"changed{replaced_note(cases)}, {cases['unchanged']} unchanged. **To accept again at the record gate:** "
             f"{', '.join(cases['reAccept']) or 'none'}.", "",
             f"**Golden masters:** {len(golden['written'])} written, {len(golden['kept'])} kept "
             f"({len(golden['keptOracleUnchanged'])} of them with only metadata or evidence changed), "
             f"{len(golden['superseded'])} superseded, {len(golden['orphaned'])} orphaned"
             + (" (the superseded and orphaned ones archived STALE under `golden/<unit>/.superseded/`)"
                if golden["superseded"] or golden["orphaned"] else "") + ".", ""]
    rows = change_rows(record)
    if rows:
        lines += ["| Case | Change | Fields (last import -> now) |", "|---|---|---|"] + rows + [""]
    if record["fixtures"]:
        lines += ["**Fixtures changed:**", ""] + [
            f"- `{f['fixture']}` {f['from']} -> {f['to']}: {', '.join(f['cases'])}" for f in record["fixtures"]] + [""]
    rules = record["rules"]
    if any(rules.values()):
        lines += [f"**Rules:** added {', '.join(rules['added']) or '-'}; removed {', '.join(rules['removed']) or '-'}; "
                  f"changed {', '.join(rules['changed']) or '-'}.", ""]
    if record.get("stories"):
        words = BA_WORDS[section_layout(record["stories"])]
        lines += [f"**{words['Stories']} (BA alignment) - the scenarios' {words['tags'].replace('`', '')} tags:**",
                  ""] + story_lines(record)
    lines.append(f"**Behaviour Specification:** `{record['feature']['file']}` "
                 + ("rewritten." if record["feature"]["changed"] else "unchanged."))
    return "\n".join(lines) + "\n"


# --------------------------------------------------------------------------- the record gate's disputes


def disputes(resources: Path) -> dict[str, dict]:
    """The DISPUTED golden masters: scenario id -> who disputed it at the record gate, when and why (the last DISPUTED
    step of its history)."""
    found = {}
    for path in sorted((resources / "golden").glob("*/*.json")) if (resources / "golden").is_dir() else []:
        master = canonical.load_json(path)
        if master.get("state") != "DISPUTED":
            continue
        step = next((h for h in reversed(master.get("history") or []) if h.get("to") == "DISPUTED"), {})
        reason = str(step.get("reason") or "")
        found[master.get("scenarioId") or path.stem] = {
            "by": step.get("by"), "at": step.get("at"),
            "reason": reason.split(": ", 1)[1] if reason.startswith("record gate: ") else reason}
    return found


def dispute_message(dispute: dict) -> str:
    return ("disputed at the record gate" + (f" by {dispute['by']}" if dispute.get("by") else "")
            + (f" ({str(dispute['at'])[:10]})" if dispute.get("at") else "")
            + (f": {dispute['reason']}" if dispute.get("reason") else "")
            + " - only accepted golden masters support a verdict")


# --------------------------------------------------------------------------- decided answers (U-127)

# The fields a decided answer sets - the status and the outcome kind derived from it: in a decided scenario's
# difference they compare the Java with the decided answer, not with the legacy (U-132: named so in the summary and
# the report; the run report keeps the framework's wording)
DECIDED_FIELDS = ("$exitState", "$outcome")
_DECIDED_TEXT = re.compile(r"(\$(?:exitState|outcome) [A-Z_]+ )legacy=")


def decided_text(text):
    """A difference's text with the status fields' expected side named ``decided=`` (other fields keep ``legacy=``)."""
    return _DECIDED_TEXT.sub(r"\1decided=", text) if isinstance(text, str) else text


def decided_difference(diff: dict | None, decided: dict | None) -> dict | None:
    """A decided scenario's difference as the summary and the report name it: the status fields' expected side is the
    decided answer (``expectedFrom: decided``, ``decided=`` in the text); the rows and the body stay the recording's."""
    if not diff or not decided:
        return diff
    fields = [dict(f, expectedFrom="decided") if f.get("path") in DECIDED_FIELDS else f for f in diff.get("fields") or []]
    return {**diff, "fields": fields, "summary": decided_text(diff.get("summary"))}
