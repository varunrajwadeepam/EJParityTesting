"""Canonical JSON and golden-master content hashes, byte-identical to the framework's ``JsonSupport``.

Golden masters a script writes (recordings imported from a package) are sealed here and verified by the Java
framework, and the Java side seals what it records; both must produce the same bytes for the same content:

- object keys sorted by UTF-16 code units (Java ``String.compareTo``), compact separators, UTF-8;
- a ``None`` value inside an object is left out (Jackson ``NON_NULL`` on maps and records) - except inside a JSON
  node (a target payload), where ``null`` is a value and is kept: wrap such a subtree in :class:`JsonNode`;
- empty objects and arrays are kept; list elements are never dropped;
- ``int`` as digits, :class:`decimal.Decimal` with its scale (``1.50``), ``bool`` as ``true``/``false``; ``float`` is
  refused (read JSON with :func:`load_json`, which parses decimals exactly);
- strings: ``"`` and ``\\`` escaped, ``\\b \\t \\n \\f \\r`` short, any other control character as ``\\u00XX`` with
  upper-case hex (Jackson), everything else - ``/`` and non-ASCII included - raw.

:func:`golden_content` applies the defaults the Java constructors apply on reading (empty maps, outcome ``OK``), so
the hash of a file is the hash Java computes for it.
"""

from __future__ import annotations

import decimal
import hashlib
import json
from pathlib import Path

_ESCAPES = {'"': '\\"', "\\": "\\\\", "\b": "\\b", "\t": "\\t", "\n": "\\n", "\f": "\\f", "\r": "\\r"}


class JsonNode:
    """A subtree whose ``None`` values are JSON nulls and are kept (Jackson ``JsonNode``)."""

    __slots__ = ("value",)

    def __init__(self, value):
        self.value = value


def _string(text: str) -> str:
    out = ['"']
    for ch in text:
        escaped = _ESCAPES.get(ch)
        if escaped is not None:
            out.append(escaped)
        elif ord(ch) < 0x20:
            out.append("\\u%04X" % ord(ch))
        else:
            out.append(ch)
    out.append('"')
    return "".join(out)


def _sort_key(name: str) -> bytes:
    return name.encode("utf-16-be", "surrogatepass")


def _value(value, keep_null: bool) -> str:
    if isinstance(value, JsonNode):
        return _value(value.value, True)
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, decimal.Decimal):
        return str(value)
    if isinstance(value, float):
        raise TypeError("a float has no exact canonical form; read JSON with load_json (decimals stay exact)")
    if isinstance(value, str):
        return _string(value)
    if isinstance(value, dict):
        entries = [(str(k), v) for k, v in value.items() if keep_null or v is not None]
        entries.sort(key=lambda kv: _sort_key(kv[0]))
        return "{" + ",".join(_string(k) + ":" + _value(v, keep_null) for k, v in entries) + "}"
    if isinstance(value, (list, tuple)):
        return "[" + ",".join(_value(v, keep_null) for v in value) + "]"
    raise TypeError(f"cannot canonicalize {type(value).__name__}")


def canonical_text(value) -> str:
    """The canonical JSON text of ``value``."""
    return _value(value, False)


def canonical_hash(value) -> str:
    """SHA-256 hex of the canonical UTF-8 bytes of ``value`` (``JsonSupport.canonicalHash``)."""
    return hashlib.sha256(canonical_text(value).encode("utf-8", "surrogatepass")).hexdigest()


def load_json(path: Path):
    """Reads JSON with exact decimals (``1.50`` stays ``1.50``), as the framework does."""
    with open(path, encoding="utf-8") as handle:
        return json.load(handle, parse_float=decimal.Decimal)


def loads_json(text: str):
    return json.loads(text, parse_float=decimal.Decimal)


def dumps_pretty(value) -> str:
    """Stable, readable JSON for files: two-space indent, insertion order, raw UTF-8, exact decimals."""
    return _pretty(value, 0) + "\n"


def _pretty(value, depth: int) -> str:
    pad = "  " * (depth + 1)
    end = "  " * depth
    if isinstance(value, JsonNode):
        return _pretty(value.value, depth)
    if isinstance(value, dict):
        if not value:
            return "{}"
        items = [pad + _string(str(k)) + ": " + _pretty(v, depth + 1) for k, v in value.items()]
        return "{\n" + ",\n".join(items) + "\n" + end + "}"
    if isinstance(value, (list, tuple)):
        if not value:
            return "[]"
        if all(not isinstance(v, (dict, list, tuple, JsonNode)) for v in value):
            return "[" + ", ".join(_pretty(v, depth + 1) for v in value) + "]"
        return "[\n" + ",\n".join(pad + _pretty(v, depth + 1) for v in value) + "\n" + end + "]"
    return _value(value, True)


def _observation(observation: dict | None) -> dict:
    observation = dict(observation or {})
    observation.setdefault("form", "CANONICAL")
    observation["fields"] = observation.get("fields") or {}
    observation["groups"] = observation.get("groups") or {}
    observation["meta"] = observation.get("meta") or {}
    outcome = dict(observation.get("outcome") or {})
    if outcome.get("kind") is None:
        outcome["kind"] = "OK"
    observation["outcome"] = outcome
    if observation.get("payload") is not None:
        observation["payload"] = JsonNode(observation["payload"])
    else:
        observation.pop("payload", None)
    return observation


def _provenance(provenance: dict | None) -> dict:
    provenance = dict(provenance or {})
    provenance["sources"] = provenance.get("sources") or {}
    provenance["env"] = provenance.get("env") or {}
    return provenance


def golden_content(master: dict) -> dict:
    """The sealed content of a golden master (``GoldenMaster.computeContentHash``): no state, history or hash."""
    content = {
        "schemaVersion": master.get("schemaVersion"),
        "scenarioId": master.get("scenarioId"),
        "unit": master.get("unit"),
        "level": master.get("level"),
        "request": master.get("request") or {},
        "observation": _observation(master.get("observation")),
        "evidence": master.get("evidence") or {},
        "provenance": _provenance(master.get("provenance")),
        "supersedes": master.get("supersedes"),
    }
    if master.get("lens") is not None:
        content["lens"] = master["lens"]
    if master.get("origin"):
        content["origin"] = master["origin"]
    return content


def golden_hash(master: dict) -> str:
    """The content hash Java computes for this golden master."""
    return canonical_hash(golden_content(master))


def integrity_holds(master: dict) -> bool:
    return master.get("contentHash") == golden_hash(master)
