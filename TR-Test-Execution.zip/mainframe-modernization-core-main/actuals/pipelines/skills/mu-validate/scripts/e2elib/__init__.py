"""The e2e_v1 (git main) library modules mu-validate imports with: package, feature, update, canonical, fingerprint,
ddl, schemacheck, pom, common - BA parts no-ops, pipelines_v2 fixes marked "mu-validate"."""
