"""A package against the JSON Schema its producer publishes - warnings only, never a gate.

The package's producer, mu-build-tests, ships its contract in ``${CLAUDE_PLUGIN_ROOT}/skills/mu-build-tests/schema/`` (JSON Schema
2020-12, found by its ``$id``), so the producer and any consumer validate against one file. A package names it in
``package.schema``. E2E's own input contract (``e2elib/package.py``) stays the blocking gate and
tolerates what it does not use; this check reports where a package leaves the producer's schema, so a drift between
the generator and its schema is seen before it matters.

Standard library only: the keywords the producer's schema uses - ``type``, ``const``, ``enum``, ``pattern``,
``minimum``, ``required``, ``properties``, ``additionalProperties``, ``propertyNames``, ``items``, ``oneOf``,
``allOf``, ``if`` / ``then`` / ``else``, ``not``, ``$ref`` to ``#/$defs/...``. Annotations (``title``,
``description``, ``format``, ``$schema``, ``$id``) are ignored; any other keyword is reported once as not checked.
"""

from __future__ import annotations

import decimal
import json
import re
from pathlib import Path

SCHEMA_DIR = Path(__file__).resolve().parents[3] / "mu-build-tests" / "schema"      # mu-validate: the producer's schema
SHOWN = 10
_ANNOTATIONS = {"$schema", "$id", "$defs", "title", "description", "format", "default", "examples", "$comment"}
_CHECKED = {"type", "const", "enum", "pattern", "minimum", "required", "properties", "additionalProperties",
            "propertyNames", "items", "oneOf", "allOf", "if", "then", "else", "not", "$ref"}
_TYPES = {"object": lambda v: isinstance(v, dict), "array": lambda v: isinstance(v, list),
          "string": lambda v: isinstance(v, str), "boolean": lambda v: isinstance(v, bool),
          "null": lambda v: v is None,
          # e2elib.canonical reads exact decimals: a JSON number with a fraction is a Decimal there
          "integer": lambda v: (isinstance(v, int) and not isinstance(v, bool))
                                or (isinstance(v, decimal.Decimal) and v == v.to_integral_value()),
          "number": lambda v: isinstance(v, (int, float, decimal.Decimal)) and not isinstance(v, bool)}


def shipped() -> dict[str, Path]:
    """The schemas this pipeline ships, by their ``$id``."""
    found = {}
    for path in sorted(SCHEMA_DIR.glob("*.json")) if SCHEMA_DIR.is_dir() else []:
        try:
            schema_id = json.loads(path.read_text(encoding="utf-8")).get("$id")
        except (ValueError, OSError):
            continue
        if isinstance(schema_id, str):
            found[schema_id] = path
    return found


def _same(a, b) -> bool:
    """JSON equality: ``true`` is no ``1``."""
    if isinstance(a, bool) or isinstance(b, bool):
        return type(a) is type(b) and a == b
    return a == b


class _Validator:
    def __init__(self, root: dict):
        self.root = root
        self.unchecked: set[str] = set()

    def resolve(self, ref: str) -> dict:
        if not ref.startswith("#/"):
            raise ValueError(f"unsupported $ref {ref}")
        node = self.root
        for part in ref[2:].split("/"):
            node = node[part.replace("~1", "/").replace("~0", "~")]
        return node

    def valid(self, value, schema) -> bool:
        return not self.errors(value, schema, "$", limit=1)

    def errors(self, value, schema, path: str, limit: int | None = None) -> list[str]:
        if schema is True or schema == {}:
            return []
        if schema is False:
            return [f"{path}: not allowed"]
        out: list[str] = []

        def add(items):
            out.extend(items)
            return limit is not None and len(out) >= limit

        self.unchecked |= {k for k in schema if k not in _CHECKED | _ANNOTATIONS}
        if "$ref" in schema and add(self.errors(value, self.resolve(schema["$ref"]), path, limit)):
            return out
        types = schema.get("type")
        if types is not None:
            names = types if isinstance(types, list) else [types]
            if not any(_TYPES.get(t, lambda v: False)(value) for t in names):
                return out + [f"{path}: expected {' or '.join(names)}, found {_kind(value)}"]
        if "const" in schema and not _same(value, schema["const"]):
            add([f"{path}: must be {json.dumps(schema['const'])}"])
        if "enum" in schema and not any(_same(value, e) for e in schema["enum"]):
            add([f"{path}: {json.dumps(value)[:40]} is not one of {', '.join(json.dumps(e) for e in schema['enum'])}"])
        if isinstance(value, str) and "pattern" in schema and not re.search(schema["pattern"], value):
            add([f"{path}: {json.dumps(value)[:40]} does not match {schema['pattern']}"])
        if _TYPES["number"](value) and "minimum" in schema and value < schema["minimum"]:
            add([f"{path}: {value} is below {schema['minimum']}"])
        if isinstance(value, dict):
            for key in schema.get("required") or []:
                if key not in value and add([f"{path}: '{key}' is required"]):
                    return out
            properties = schema.get("properties") or {}
            for key, sub in properties.items():
                if key in value and add(self.errors(value[key], sub, f"{path}.{key}", limit)):
                    return out
            extra = schema.get("additionalProperties", True)
            for key in value:
                if key in properties:
                    continue
                if extra is False:
                    if add([f"{path}: '{key}' is not allowed"]):
                        return out
                elif isinstance(extra, dict) and add(self.errors(value[key], extra, f"{path}.{key}", limit)):
                    return out
            names = schema.get("propertyNames")
            if names is not None:
                for key in value:
                    if not self.valid(key, names) and add([f"{path}: the key '{key}' is not allowed by its name"]):
                        return out
        if isinstance(value, list) and isinstance(schema.get("items"), dict):
            for index, item in enumerate(value):
                where = f"{path}[{item.get('id')}]" if isinstance(item, dict) and isinstance(item.get("id"), str) \
                    else f"{path}[{index}]"
                if add(self.errors(item, schema["items"], where, limit)):
                    return out
        if "oneOf" in schema:
            matching = sum(1 for sub in schema["oneOf"] if self.valid(value, sub))
            why = "; ".join(e.split(": ", 1)[-1] for sub in schema["oneOf"]
                            for e in self.errors(value, sub, path, limit=1)) if not matching else ""
            if matching != 1 and add([f"{path}: matches {matching} of its {len(schema['oneOf'])} allowed forms, "
                                      "expected exactly 1" + (f" ({why})" if why else "")]):
                return out
        for sub in schema.get("allOf") or []:
            if add(self.errors(value, sub, path, limit)):
                return out
        if "if" in schema:
            branch = schema.get("then") if self.valid(value, schema["if"]) else schema.get("else")
            if branch is not None and add(self.errors(value, branch, path, limit)):
                return out
        if "not" in schema and self.valid(value, schema["not"]):
            add([f"{path}: matches the form the schema forbids here: {json.dumps(schema['not'])[:80]}"])
        return out


def _kind(value) -> str:
    return next((name for name in ("null", "boolean", "integer", "number", "string", "array", "object")
                 if _TYPES[name](value)), type(value).__name__)


def _shown(path) -> str:
    """The schema file relative to the working directory when below it, else absolute."""
    path = Path(path).resolve()
    try:
        return path.relative_to(Path.cwd().resolve()).as_posix()
    except ValueError:
        return path.as_posix()


def check(doc: dict) -> dict | None:
    """The package against the schema its ``package.schema`` names, when this pipeline ships it: ``{"schema", "file",
    "problems", "notChecked"}``; ``{"schema", "file": None, ...}`` when it names one this pipeline does not ship; None
    when it names none."""
    block = doc.get("package") if isinstance(doc.get("package"), dict) else {}
    schema_id = block.get("schema")
    if not isinstance(schema_id, str) or not schema_id:
        return None
    path = shipped().get(schema_id)
    if path is None:
        return {"schema": schema_id, "file": None, "problems": [], "notChecked": [],
                "note": f"the package names the schema {schema_id}, which this pipeline does not ship: not checked"}
    schema = json.loads(path.read_text(encoding="utf-8"))
    validator = _Validator(schema)
    problems = validator.errors(doc, schema, "$")
    return {"schema": schema_id, "file": _shown(path), "problems": problems,
            "notChecked": sorted(validator.unchecked)}


def warning_lines(result: dict | None) -> list[str]:
    """The check as warnings: at most :data:`SHOWN` problems, then a count."""
    if not result or not result.get("problems"):
        return []
    problems = result["problems"]
    lines = [f"the package leaves its producer's schema {result['schema']} ({result['file']}): {p}"
             for p in problems[:SHOWN]]
    if len(problems) > SHOWN:
        lines.append(f"the package leaves its producer's schema {result['schema']} in {len(problems) - SHOWN} more "
                     "places (the import summary's schemaCheck lists them all)")
    return lines
