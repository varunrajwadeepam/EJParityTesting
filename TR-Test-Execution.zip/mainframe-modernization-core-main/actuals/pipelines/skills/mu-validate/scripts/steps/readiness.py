"""Step 1 - readiness: is the entry's test package the one to validate with?

    mu_validate.py readiness <mu> [--entry E]

Reads tests/tests-state.json and the package tests/package/<E>/<E>-tests.json (never writes them).
Not ready (exit 2, `fix`: one item per problem with the /mu-build-tests command and the reason): no
package, a seal (contentHash, sorted-keys canonical JSON) that does not hold, an integrity problem (format,
unit, case ids, statuses, fixture files, not-recorded cases), a package.inputs hash that differs from the
current design/rules.md, design/tests.md, extracted-logic/paragraph-index.json, unit/schema.sql, an open
blocking PQ in tests/tests-open-questions.md, a tests-state.json that is missing, of another package or
not `ready`. Warnings: open non-blocking PQs, scope basic-only.
"""

from vlib import questions as vq
from vlib.common import slash_command, content_hash, file_sha, read_json
from vlib.config import INPUT_FILES

FORMAT = 3
STATUSES = ('golden', 'not-representable', 'not-recorded')


def add_arguments(ap):
    pass


def integrity(ctx, doc):
    out = []
    pk = doc.get('package') if isinstance(doc.get('package'), dict) else {}
    if pk.get('format') != FORMAT:
        out.append(f'package.format is {pk.get("format")!r}, mu-validate reads {FORMAT}')
    if doc.get('unit') != ctx.entry:
        out.append(f'unit is {doc.get("unit")!r}, not the entry {ctx.entry}')
    cases = doc.get('cases') if isinstance(doc.get('cases'), list) else None
    if not cases:
        out.append('the package has no cases')
        return out
    seen = set()
    for c in cases:
        cid = c.get('id') if isinstance(c, dict) else None
        if not cid:
            out.append('a case without an id')
            continue
        if cid in seen:
            out.append(f'case id {cid} twice')
        seen.add(cid)
        st = c.get('status')
        if st not in STATUSES:
            out.append(f'{cid}: unknown status {st!r}')
        elif st == 'not-recorded':
            out.append(f'{cid}: not-recorded ({c.get("reason", "")})')
        elif st == 'golden' and not isinstance(c.get('expected'), dict):
            out.append(f'{cid}: golden without expected')
        fx = c.get('fixture')
        if fx and not (ctx.package_dir / str(fx)).is_file():
            out.append(f'{cid}: fixture {fx} missing in the package folder')
    return out


def run_step(ctx, args, st):
    cmd = f"{slash_command('mu-build-tests')} {ctx.mu_arg} entry={ctx.entry}"
    fix, warnings = [], []

    def need(issue, reason, command=cmd):
        fix.append({'issue': issue, 'reason': reason, 'command': command})

    doc = read_json(ctx.package, 'package', decimal=True) if ctx.package.is_file() else None
    tstate = read_json(ctx.tests_state, 'tests state') if ctx.tests_state.is_file() else None
    pk = (doc or {}).get('package') if isinstance((doc or {}).get('package'), dict) else {}
    info = {'entry': ctx.entry, 'package': ctx.rel(ctx.package), 'version': pk.get('version'),
            'contentHash': pk.get('contentHash'), 'packageState': pk.get('state'),
            'testsState': (tstate or {}).get('state'), 'scope': (tstate or {}).get('scope')}
    if doc is None:
        need('no package', f'{ctx.rel(ctx.package)} is missing: build and install the package')
    else:
        seal = content_hash(doc)
        info['sealHolds'] = seal == pk.get('contentHash')
        if not info['sealHolds']:
            need('seal broken', f'package.contentHash {str(pk.get("contentHash"))[:12]} does not match the content '
                                f'({seal[:12]}): the package was changed after mu-build-tests wrote it; rebuild it, '
                                'never edit it')
        for p in integrity(ctx, doc):
            need('integrity', p)
        rec = pk.get('inputs')
        if not isinstance(rec, dict) or not rec:
            need('inputs unknown', 'the package records no package.inputs: staleness cannot be checked; rebuild')
        else:
            cur = ctx.inputs()
            changed = sorted(f for f in set(rec) | set(INPUT_FILES) if rec.get(f) != cur.get(f))
            info['changedInputs'] = changed
            for f in changed:
                need('stale', f'{f} changed since package v{pk.get("version")} was built')
    entries = vq.parse(ctx.tests_questions, prefixes=('PQ',))
    blocking = vq.open_blocking(entries)
    for e in blocking:
        need('needs-answers', f'{e["id"]} ({e["title"]}) is blocking and unanswered: answer it in '
                              f'{ctx.rel(ctx.tests_questions)}, then rerun', cmd)
    nonblocking = [e['id'] for e in vq.open_entries(entries) if not e['blocking']]
    if nonblocking:
        warnings.append(f'open non-blocking PQs: {", ".join(nonblocking)}')
    if tstate is None:
        need('no tests state', f'{ctx.rel(ctx.tests_state)} is missing: run the command to its state step')
    else:
        if tstate.get('entry') not in (None, ctx.entry):
            need('tests state of another entry', f'tests-state.json is of {tstate.get("entry")}, not {ctx.entry}')
        sp = (tstate.get('package') or {}).get('contentHash')
        if doc is not None and sp != pk.get('contentHash'):
            need('tests state of another package', 'tests-state.json was written for another package '
                                                   f'({str(sp)[:12]}): rerun to the state step')
        if tstate.get('state') != 'ready':
            reasons = '; '.join(f'{k}: {", ".join(v)}' for k, v in (tstate.get('reasons') or {}).items()) or '-'
            extra = ' --api-checked after checking the binding' if tstate.get('state') == 'needs-api-check' else ''
            need(f'tests state {tstate.get("state")}', f'mu-build-tests state is {tstate.get("state")} ({reasons})',
                 cmd + extra)
        if tstate.get('scope') == 'basic-only':
            warnings.append('scope basic-only: the package has no advanced set')
    ready = not fix
    st['readiness'] = {'entry': ctx.entry, 'ready': ready, 'version': pk.get('version'),
                       'contentHash': pk.get('contentHash'), 'packageSha256': file_sha(ctx.package),
                       'inputs': pk.get('inputs')}
    out = {**info, 'fix': fix, 'warnings': warnings}
    if ready:
        return 0, {'status': 'ready', **out}
    issues = {f['issue'] for f in fix}
    status = ('blocked' if issues & {'no package', 'seal broken', 'integrity', 'inputs unknown'} else
              'stale' if 'stale' in issues else 'needs-answers' if 'needs-answers' in issues else 'not-ready')
    return 2, {'status': status, **out}
