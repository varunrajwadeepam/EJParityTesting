"""Step 9 - analyse: the evidence behind every scenario of the last replay that did not pass, and a first class.

    mu_validate.py analyse <mu> [--entry E] [--run RUN_ID]

Reads runs/<run-id>/summary.json and the framework report of its last run (run-<n>/e2e-replay.json), the package
(case name, rules, request, expected answer, decided answer, divergences), design/rules.md (each rule's
`Target home`), the golden-master states and the product snapshot the run used (controller mapping of the request,
request and response DTO fields, exception handler statuses, the exceptions the rule's target home throws; Java read
as text). Per FAILED scenario (one entry, its FAILED levels merged; a scenario's worst level decides): the difference, what the product answered, the request against the API, the
exception if any (from the answer, else the scenario's block of the build log: type, message, first product frame),
siblings of the same rules and how they ended, the suspect rules (the case's rules, and any rule whose text or Target
home names the exception message, the answer's code, the failing frame or field), and a pre-class with the signals
that fired:

  BINDING      the request does not reach the code as meant: no mapping (404/405), 415, 400 on shape, a request
               field the DTO has no property for (named), an expected answer field the response DTO lacks, many
               cases of one operation failing alike -> /mu-build-tests
  SOLUTION     the request is accepted and the answer or rows differ, siblings of a rule pass, a status no handler
               produces, a decided answer the product does not implement, a 5xx thrown by product code below the
               entry layer (wins over BINDING signals) -> the rule and its target home
  ENVIRONMENT  connection, schema or rights failures, SKIPPED (incl. a register scenario missing from the report)
  PACKAGE      BLOCKED (golden master not accepted), package not ready
  DECISION     the answer is the decided answer (its status, and every differing value the decided one), or every
               differing path is one the case or its decision does not compare (`compare: ignore`, a decided
               `tables: notCompared`); nothing else gives DECISION
  UNKNOWN      no signal decides -> a question

A declared divergence or hypothesis that names a differing field, and a status equal to the decided one with other
differences, are hints: listed with the evidence (`hints`), never a class signal.

BLOCKED and SKIPPED scenarios are listed apart (PACKAGE / ENVIRONMENT). Writes validation/.tmp/analysis.json and
validation/.tmp/failures-draft.md (templates/failures.md, the pre-classes filled in). The agent confirms or
changes each class and writes validation/failures.md. Exit 0; 2 when there is no run to analyse.
"""

import re
from collections import Counter, defaultdict
from pathlib import Path

from e2elib.package import decided_of as live_decided
from vlib import javaapi, runlog
from vlib.common import SKILL, Stop, by_scenario, iso_now, read_json, read_text, write_json, write_text

CLASSES = ('BINDING', 'SOLUTION', 'ENVIRONMENT', 'PACKAGE', 'DECISION', 'UNKNOWN')
NEXT = {'BINDING': 'mu-build-tests', 'PACKAGE': 'mu-build-tests', 'SOLUTION': 'implementer',
        'ENVIRONMENT': 'environment', 'DECISION': 'none', 'UNKNOWN': 'question'}
SHOWN = 12
EXCERPT = 400
_ENV = re.compile(r'Connection refused|ConnectException|CannotGetJdbcConnection|CannotCreateTransaction|'
                  r'SQLNonTransientConnection|SocketTimeout|UnknownHost|SQLCODE=-30081|ERRORCODE=-4499|'
                  r'Communications link|pool .* (exhausted|timed out)', re.I)
_ENV_SCHEMA = re.compile(r'SQLCODE=-(204|206|551|552|567|1035)|undefined name|is an undefined name', re.I)
_TRACE = re.compile(r'^\s*(?:Caused by:\s*)?((?:[a-z]\w*\.)+[A-Z]\w*(?:Exception|Error))(?::\s*(.*))?$')


def add_arguments(ap):
    ap.add_argument('--run', help='the run id under validation/runs/ (default: the last one)')


# ---------------------------------------------------------------- inputs

def last_run(ctx, run_id=None):
    if run_id:
        path = ctx.runs / run_id / 'summary.json'
        if not path.is_file():
            raise Stop(f'no run {run_id} in {ctx.rel(ctx.runs)}', code=2)
        return run_id, read_json(path, 'run summary')
    found = []
    for path in sorted(ctx.runs.glob('*/summary.json')) if ctx.runs.is_dir() else []:
        try:
            doc = read_json(path, 'run summary')
        except Stop:
            continue
        found.append((str(doc.get('finishedAt') or ''), path.parent.name, doc))
    if not found:
        raise Stop(f'no replay run in {ctx.rel(ctx.runs)}: run execute first', code=2, next='execute')
    _, rid, doc = max(found, key=lambda f: (f[0], f[1]))
    return rid, doc


def rules_of(path):
    """{R<n>: {targetHome, text}} from the rule tables of design/rules.md (the `#` and `Target home` columns)."""
    out = {}
    if not Path(path).is_file():
        return out
    cols = None
    for line in read_text(path).splitlines():
        s = line.strip()
        if not s.startswith('|'):
            cols = None if not s else cols
            continue
        cells = [c.strip() for c in s.strip('|').split('|')]
        if cells and cells[0] in ('#', 'Rule', 'Id', 'ID'):
            low = [c.lower() for c in cells]
            cols = {'id': 0, 'text': 1, 'home': low.index('target home') if 'target home' in low else None}
            continue
        if cols is None or re.fullmatch(r'[-: ]+', ''.join(cells)):
            continue
        rid = cells[0].strip('*` ')
        if not re.fullmatch(r'R?\d+[a-z]?', rid):
            continue
        rid = rid if rid.startswith('R') else f'R{rid}'
        home = cells[cols['home']] if cols['home'] is not None and cols['home'] < len(cells) else None
        out[rid] = {'targetHome': home.strip('` ') if home else None, 'text': cells[cols['text']]}
    return out


def operation_of(case, operations):
    req = case.get('request') or {}
    method, path = str(req.get('method') or '').upper(), str(req.get('path') or req.get('url') or '')
    for op in operations:
        if str(op.get('method') or '').upper() == method and op.get('pathTemplate') and \
                javaapi.path_matches(op['pathTemplate'], '/' + path.split('?', 1)[0].strip('/')):
            return op
    return None


def run_exceptions(run_dir):
    """Distinct exception lines of the run's application log, with counts (most frequent first)."""
    counts = Counter()
    for log in sorted(run_dir.glob('*.log')):
        try:
            for line in read_text(log).splitlines():
                m = _TRACE.match(line)
                if m:
                    counts[f'{m.group(1)}: {(m.group(2) or "").strip()[:160]}'.rstrip(': ')] += 1
        except OSError:
            continue
    return [{'line': k, 'count': v} for k, v in counts.most_common(SHOWN)]


# ---------------------------------------------------------------- one scenario

def deciding(s):
    chosen = s.get('strict') if s.get('verdictProfile') == 'strict' else s.get('contract')
    return chosen or s.get('strict') or s.get('contract') or {}


def answer_of(s):
    t = s.get('target') or {}
    outcome = t.get('outcome') or {k: t.get(k) for k in ('kind', 'exitState', 'exceptionType', 'message') if k in t}
    meta = t.get('meta') or {}
    status = meta.get('http.status') or outcome.get('exitState')
    try:
        status = int(status) if status is not None else None
    except (TypeError, ValueError):
        status = None
    payload = t.get('payload')
    return {'status': status, 'request': meta.get('http.request'), 'contentType': meta.get('http.contentType'),
            'outcome': outcome or None,
            'payload': (payload[:EXCERPT] + '...') if isinstance(payload, str) and len(payload) > EXCERPT else payload}


def expected_of(case, diffs):
    exp = case.get('expected') or {}
    decided = live_decided(case) or {}
    status = decided.get('status') or exp.get('status')
    for d in diffs:
        if d.get('kind') == 'EXIT_STATE':
            try:
                status = int(d.get('legacy'))
            except (TypeError, ValueError):
                pass
    body = decided.get('body') if 'body' in decided else exp.get('body')
    return {'status': status, 'bodyFields': sorted(body) if isinstance(body, dict) else [],
            'empty': exp.get('empty'), 'tables': len(exp.get('tables') or [])}


def payload_code(answer):
    m = re.search(r'"code"\s*:\s*"([^"]*)"', answer.get('payload') or '') if isinstance(answer.get('payload'), str) \
        else None
    return m.group(1) if m else None


def exception_of(outcome, logged):
    """The answer's exception, completed from the build log (the product's own logged exception first)."""
    exc = {k: outcome.get(k) for k in ('exceptionType', 'message') if outcome.get(k)}
    if logged:
        if not exc.get('exceptionType') and logged.get('type'):
            exc['exceptionType'] = logged['type']
        if not exc.get('message') and logged.get('message'):
            exc['message'] = logged['message']
        exc.update({k: logged.get(k) for k in ('frame', 'frameClass', 'appFrames', 'causedBy', 'logged')
                    if logged.get(k)})
        exc['source'] = 'answer+log' if outcome.get('exceptionType') else f"log ({logged.get('source')})"
        exc['serviceThrown'] = runlog.service_thrown(logged)
    elif exc:
        exc['source'] = 'answer'
    return exc or None


def evidence(s, case, rules, api, operations, by_rule, statuses, logged=None):
    sid = s.get('scenarioId')
    verdict = deciding(s)
    diffs = verdict.get('diffs') or []
    answer = answer_of(s)
    expected = expected_of(case, diffs)
    req = case.get('request') or {}
    method, path = str(req.get('method') or '').upper(), str(req.get('path') or req.get('url') or '')
    op = operation_of(case, operations)
    mapping, how = api.mapping_for(method, path) if method and path and api.controllers else (None, 'no controller '
                                                                                               'in the snapshot')
    dto = api.fields(mapping['requestBody']) if mapping and mapping.get('requestBody') else None
    body = req.get('body')
    unknown = javaapi.unknown_fields(body, dto) if dto is not None else []
    response = api.fields(mapping['responseType']) if mapping and mapping.get('responseType') else None
    missing_out = [f for f in expected['bodyFields'] if response is not None and f not in response
                   and (expected['status'] or 0) < 400]
    rule_rows = []
    for rid in case.get('ruleIds') or []:
        info = rules.get(rid) or {}
        others = [x for x in by_rule.get(rid, []) if x != sid]
        rule_rows.append({'id': rid, 'targetHome': info.get('targetHome'), 'text': (info.get('text') or '')[:200],
                          'passed': [x for x in others if statuses.get(x) == 'PASSED'],
                          'failed': [x for x in others if statuses.get(x) == 'FAILED'],
                          'cases': len(others) + 1,
                          'throws': api.throws_of(info.get('targetHome')) if info.get('targetHome') else None})
    outcome = answer.get('outcome') or {}
    exception = exception_of(outcome, logged)
    return {
        'scenarioId': sid, 'name': case.get('name'), 'title': s.get('title'), 'status': s.get('status'),
        'level': s.get('level'), 'message': (s.get('message') or '')[:EXCERPT],
        'operation': (op or {}).get('name') or (f'{method} {path}' if method else None),
        'rules': rule_rows,
        'expected': expected, 'actual': answer,
        'difference': {'profile': verdict.get('profile') or s.get('verdictProfile'), 'count': len(diffs),
                       'strict': (s.get('strict') or {}).get('status'), 'contract': (s.get('contract') or {}).get('status'),
                       'signatures': (verdict.get('signatures') or [])[:SHOWN],
                       'fields': [{'path': d.get('field'), 'kind': d.get('kind'), 'expected': d.get('legacy'),
                                   'actual': d.get('target'), 'pattern': d.get('pattern')} for d in diffs[:SHOWN]]},
        'request': {'method': method, 'path': path, 'bodyFields': len(javaapi.body_fields(body)) if body else 0,
                    'unknownFields': unknown, 'mapping': how,
                    'controller': {k: mapping.get(k) for k in ('controller', 'method', 'verb', 'path', 'file', 'line',
                                                               'requestBody', 'status')} if mapping else None,
                    'requestDto': sorted(dto) if dto is not None else None},
        'response': {'type': (mapping or {}).get('responseType'), 'fields': sorted(response) if response else None,
                     'missingFields': missing_out},
        'exception': exception,
        'decided': decided_of(case),
        'ignored': ignored_paths(case),
        'divergences': (case.get('anticipatedJavaDivergence') or []) + (case.get('stackDivergence') or []),
        'hypotheses': s.get('hypotheses') or [],
        'design': case.get('design'),
    }


def decided_of(case):
    """The case's decided answer: source, rules, status, recorded status, tables, and the decided body and set[]
    values (the expected body of a decided case is the decided one)."""
    dec = live_decided(case)
    if dec is None:
        return None
    out = {k: dec.get(k) for k in ('source', 'rules', 'status', 'recordedStatus', 'tables')}
    body = dec.get('body') if 'body' in dec else (case.get('expected') or {}).get('body')
    out['body'] = body if isinstance(body, dict) else None
    out['set'] = [x for x in dec.get('set') or [] if isinstance(x, dict) and x.get('path')]
    return out


def ignored_paths(case):
    """The answer paths the case or its decision does not compare (`compare` entries of mode ignore)."""
    entries = list(case.get('compare') or []) + list((live_decided(case) or {}).get('compare') or [])
    return list(dict.fromkeys(c['path'] for c in entries if isinstance(c, dict) and c.get('mode') == 'ignore'
                              and isinstance(c.get('path'), str) and c['path']))


def body_key(path):
    """A difference path as a body path: `body.` / `$.` dropped, `[n]` -> `[]`."""
    return re.sub(r'\[\d*\]', '[]', re.sub(r'^(?:\$\.|body\.)', '', str(path or '')))


def is_ignored(path, e):
    if str(path or '').startswith('table:'):
        return ((e.get('decided') or {}).get('tables')) == 'notCompared'
    key = body_key(path)
    return any(key == i or key.startswith(i + '.') or key.startswith(i + '[') for i in map(body_key, e.get('ignored')
                                                                                          or []))


_NONE = object()


def decided_value(dec, path):
    key = body_key(path)
    for x in dec.get('set') or []:
        if body_key(x['path']) == key:
            return x.get('value')
    body = dec.get('body') or {}
    return body.get(key, _NONE) if '[' not in key and '.' not in key else _NONE


def same(a, b):
    return ('' if a is None else str(a)).rstrip() == ('' if b is None else str(b)).rstrip()


def decision_match(e):
    """Why the failure is the decision (the answer is the decided one, or every differing path is not compared),
    else None."""
    diff = e['difference']
    fields = diff['fields']
    if not fields or diff['count'] > len(fields):
        return None
    dec = e.get('decided') or {}
    rest = [f for f in fields if not is_ignored(f['path'], e)]
    if not rest:
        return (f'every differing path is one the {"decision of " + str(dec.get("source")) if dec else "case"} does '
                f'not compare: {", ".join(sorted({f["path"] for f in fields})[:4])}')
    act = e['actual'].get('status')
    if not dec or act is None or dec.get('status') != act:
        return None
    for f in rest:
        if f['path'] in ('$exitState', '$outcome'):
            continue
        v = decided_value(dec, f['path'])
        if v is _NONE or not same(v, f['actual']):
            return None
    return f'the answer is the decided answer of {dec.get("source")} ({act})'


def merge_levels(e, levels):
    """One failure per scenario: the differences of its other FAILED levels joined to the first one's."""
    e['levels'] = [x.get('level') for x in levels]
    seen = {(f['path'], f['kind']) for f in e['difference']['fields']}
    for other in levels[1:]:
        verdict = deciding(other)
        diffs = verdict.get('diffs') or []
        e['difference']['count'] += len(diffs)
        e['difference']['signatures'] = list(dict.fromkeys(e['difference']['signatures']
                                                           + (verdict.get('signatures') or [])))[:SHOWN]
        for d in diffs:
            if (d.get('field'), d.get('kind')) not in seen and len(e['difference']['fields']) < SHOWN:
                seen.add((d.get('field'), d.get('kind')))
                e['difference']['fields'].append({'path': d.get('field'), 'kind': d.get('kind'),
                                                  'expected': d.get('legacy'), 'actual': d.get('target'),
                                                  'pattern': d.get('pattern'), 'level': other.get('level')})


# ---------------------------------------------------------------- classification

def classify(e, ctx_info):
    """Pre-class of one failure: {class, confidence, scores, signals [{class, weight, signal}], suspectRules}."""
    signals = []

    def fire(cls, weight, text):
        signals.append({'class': cls, 'weight': weight, 'signal': text})

    exp, act = e['expected'].get('status'), e['actual'].get('status')
    req, outcome = e['request'], e['actual'].get('outcome') or {}
    op = ctx_info['operations'].get(e.get('operation')) or {}
    status_differs = exp is not None and act is not None and exp != act
    exc = e.get('exception') or {}
    trace = ' '.join(str(outcome.get(k) or '') for k in ('exceptionType', 'message')) + ' ' + \
        ' '.join(x['line'] for x in ctx_info.get('exceptions') or [] if outcome.get('exceptionType')
                 and outcome['exceptionType'] in x['line']) + ' ' + \
        ' '.join(str(exc.get(k) or '') for k in ('exceptionType', 'message')) + ' ' + ' '.join(exc.get('causedBy') or [])
    # ENVIRONMENT
    if _ENV.search(trace):
        fire('ENVIRONMENT', 3, f'connection failure: {trace.strip()[:160]}')
    elif _ENV_SCHEMA.search(trace):
        fire('ENVIRONMENT', 2, f'schema, table or rights failure: {trace.strip()[:160]}')
    if act is None and outcome.get('kind') in ('TECHNICAL_FAILURE', 'NOT_RUN'):
        fire('ENVIRONMENT', 1.5, f'no HTTP answer ({outcome.get("kind")})')
    if ctx_info.get('allFailedAlike'):
        fire('ENVIRONMENT', 1, 'every compared scenario of the run failed the same way')
    # PACKAGE
    if ctx_info.get('readiness') is False:
        fire('PACKAGE', 2, 'the package is not ready (readiness)')
    # BINDING
    if req.get('controller') is None and req.get('method'):
        fire('BINDING', 3, f'request not mapped: {req.get("mapping")}')
    if req.get('unknownFields'):
        ignored = '' if ctx_info.get('failOnUnknown') else ' (ignored silently: fail-on-unknown-properties false)'
        fire('BINDING', 3, f'request field(s) the DTO {req["controller"]["requestBody"]} has no property for: '
                           f'{", ".join(req["unknownFields"][:6])}{ignored}')
    if e['response'].get('missingFields'):
        fire('BINDING', 3, f'expected answer field(s) the response {e["response"]["type"]} lacks: '
                           f'{", ".join(e["response"]["missingFields"][:6])}')
    if status_differs and act in (405, 415):
        fire('BINDING', 3, f'HTTP {act} where {exp} is expected (method or media type)')
    if status_differs and act == 400:
        fire('BINDING', 2, f'HTTP 400 where {exp} is expected: the request shape is refused')
    if status_differs and act == 404:
        code = payload_code(e['actual'])
        if req.get('controller') is None or code in (None, '') or 'resource' in str(e['actual'].get('payload')).lower():
            fire('BINDING', 2, f'HTTP 404 where {exp} is expected, no business answer')
        else:
            fire('BINDING', 0.5, f'HTTP 404 ({code}) where {exp} is expected: a lookup found nothing - inputs bound?')
    if op.get('compared', 0) >= 3 and op.get('failed', 0) >= 0.8 * op['compared'] and \
            op.get('byActual', {}).get(str(act), 0) >= 0.8 * op['failed']:
        fire('BINDING', 1.5, f'{op["failed"]} of {op["compared"]} compared cases of operation {e["operation"]} fail, '
                             f'{op["byActual"].get(str(act), 0)} with HTTP {act}')
    # SOLUTION
    accepted = act is not None and req.get('controller') is not None and not req.get('unknownFields') and \
        not e['response'].get('missingFields') and (not status_differs or act not in (400, 404, 405, 415))
    if accepted:
        fire('SOLUTION', 1, 'the request is mapped and every request field bound')
    passing = sorted({x for r in e['rules'] for x in r['passed']})
    if passing:
        fire('SOLUTION', 1 if not accepted else 1.5,
             f'siblings of the same rules pass: {", ".join(passing[:5])}{" ..." if len(passing) > 5 else ""}')
    if op.get('passed'):
        fire('SOLUTION', 0.5, f'operation {e["operation"]} answers {op["passed"]} other case(s) right')
    if status_differs and exp and exp >= 400 and accepted:
        producers = ctx_info['answering'](exp)
        if not producers:
            fire('SOLUTION', 1.5, f'no exception handler produces HTTP {exp}; HTTP {act} comes from '
                                  f'{", ".join(ctx_info["answering"](act)[:4]) or "the handlers"}')
        else:
            homes = [r for r in e['rules'] if r.get('throws')]
            if homes and not any(v == exp for r in homes for v in r['throws'].values()):
                fire('SOLUTION', 1, f'the target home(s) throw nothing mapped to HTTP {exp}')
    if exp is not None and act == exp and e['difference']['count'] and accepted:
        fire('SOLUTION', 1, 'the status matches; values or rows differ')
    thrown = bool(act is not None and act >= 500 and req.get('controller') is not None and exc.get('serviceThrown')
                  and not _ENV.search(trace) and not _ENV_SCHEMA.search(trace))
    if thrown:
        fire('SOLUTION', 3, f'HTTP {act} from product code after the request was accepted: '
                            f'{str(exc.get("exceptionType") or "").rsplit(".", 1)[-1]}: {exc.get("message") or ""} at '
                            f'{(exc.get("appFrames") or ["?"])[0]}')
    elif outcome.get('kind') == 'TECHNICAL_FAILURE' and act == 500 and not _ENV.search(trace) and \
            not _ENV_SCHEMA.search(trace):
        fire('SOLUTION', 1, f'the product failed: {outcome.get("exceptionType") or exc.get("exceptionType") or "HTTP 500"}')
    dec = e.get('decided') or {}
    hints = []
    match = decision_match(e)
    if match:
        fire('DECISION', 4, match)
    if dec and act is not None:
        if dec.get('recordedStatus') == act and dec.get('status') != act:
            fire('SOLUTION', 1.5, f'the product answers the recorded {act}, the decided answer ({dec.get("source")}) '
                                  f'is {dec.get("status")}')
        elif dec.get('status') == act and not match:
            hints.append(f'the status is the decided answer of {dec.get("source")}; the rest differs')
    notes = ' '.join(e.get('divergences') or []) + ' ' + ' '.join(e.get('hypotheses') or [])
    names = {n for f in e['difference']['fields'] for n in re.sub(r'^table:|\[\d*\]|\$', '', f['path'] or '').split('.')}
    hit = sorted(n for n in names if n and len(n) > 2 and re.search(r'\b' + re.escape(n) + r'\b', notes))
    if hit:
        hints.append(f'a declared divergence or hypothesis names {", ".join(hit[:4])}')
    elif notes.strip():
        hints.append('the case declares a divergence or hypothesis')
    scores = {c: round(sum(s['weight'] for s in signals if s['class'] == c), 2) for c in CLASSES[:-1]}
    ranked = sorted(scores.items(), key=lambda kv: -kv[1])
    (top, s1), (_, s2) = ranked[0], ranked[1]
    if s1 < 1.5 or s1 == s2:
        cls, conf = 'UNKNOWN', 'low'
    else:
        cls = top
        conf = 'high' if s1 >= 3 and s1 - s2 >= 1.5 else 'medium' if s1 >= 2 and s1 - s2 >= 0.5 else 'low'
    if thrown and cls in ('BINDING', 'UNKNOWN'):     # the product threw after accepting it: the binding is not why
        cls, conf = 'SOLUTION', 'high' if scores['SOLUTION'] > scores['BINDING'] else 'medium'
        signals.append({'class': 'SOLUTION', 'weight': 0, 'signal': 'preferred over BINDING: the exception comes '
                                                                     'from product code after the request was accepted'})
    if match:                                      # the answer is the decided one: nothing else explains the failure
        cls, conf = 'DECISION', 'high'
    binding = (req.get('unknownFields') or []) + (e['response'].get('missingFields') or [])
    return {'class': cls, 'confidence': conf, 'scores': scores, 'signals': signals, 'hints': hints,
            'suspectRules': suspect_rules(e, ctx_info) if cls in ('SOLUTION', 'UNKNOWN', 'DECISION') else [],
            'fields': binding if cls == 'BINDING' or (cls == 'SOLUTION' and thrown) else []}


def words(text):
    """Lower-case words of a text; camelCase and snake_case split (`pifChangeSequence` -> pif change sequence)."""
    return re.findall(r'[a-z0-9]+', re.sub(r'([a-z0-9])([A-Z])', r'\1 \2', str(text or '')).replace('_', ' ').lower())


def joined(text):
    return ' ' + ' '.join(words(text)) + ' '


def message_share(message, text_words):
    """Share of the message's word trigrams (bigrams for a short message) the text contains."""
    w = [x for x in words(message) if x not in ('failed', 'processing')] if message else []
    n = min(3, len(w))
    grams = [' '.join(w[i:i + n]) for i in range(len(w) - n + 1)] if n >= 2 else []
    return (sum(1 for g in grams if f' {g} ' in text_words) / len(grams)) if grams else 0.0


def suspect_rules(e, ctx_info):
    """The rules most likely broken, each with why. Every rule of rules.md is weighed: the exception message, the
    answer's code, the exception type and the failing product method named in its text (a rule outside the case needs
    1.5 of these); then no passing sibling and every case failing (the case's own rules), the expected status's
    legacy response code or the status named in the text, its Target home on the failing stack, a differing field
    named. The best score (2 or more) wins; ties are all named."""
    exp = e['expected'].get('status')
    codes = ctx_info['codesFor'](e.get('operation'), exp)
    exc = e.get('exception') or {}
    code = payload_code(e['actual'])
    frames = exc.get('appFrames') or []
    method = frames[0].split('.', 1)[-1] if frames else None
    etype = str(exc.get('exceptionType') or '').rsplit('.', 1)[-1]
    fields = sorted({p.split('.')[-1] for f in e['difference']['fields']
                     for p in [re.sub(r'^table:|\[\d*\]', '', f['path'] or '')] if p and not p.startswith('$')})
    own = {r['id']: r for r in e['rules']}
    every = dict(ctx_info.get('rules') or {})
    for rid, r in own.items():
        every.setdefault(rid, {'text': r.get('text'), 'targetHome': r.get('targetHome')})
    ranked = []
    for rid, info in every.items():
        text, home = info.get('text') or '', info.get('targetHome')
        tw = joined(text)
        found, why = 0.0, []
        share = message_share(exc.get('message'), tw)
        if share >= 0.3:
            found += round(3 * share, 2)
            why.append(f'names the exception message ({share:.0%} of "{exc.get("message")}")')
        if code and re.search(r'(?<![A-Z_])' + re.escape(code) + r'(?![A-Z_])', text):
            found += 1.5
            why.append(f'names the answer code {code}')
        if etype and etype in text:
            found += 1
            why.append(f'names {etype}')
        if method and len(words(method)) >= 2 and joined(method) in tw:
            found += 1
            why.append(f'names the failing method {method}')
        r = own.get(rid)
        if r is None and found < 1.5:
            continue
        score = found
        if r is not None and not r['passed']:
            score += 2
            why.append('no other case of the rule passes')
            if r['failed']:
                score += 1
                why.append(f'its other cases fail too ({", ".join(r["failed"][:4])})')
        if codes and any(re.search(r'(?:response )?code\s+`?' + re.escape(c) + r'`?(?!\d)', text) for c in codes):
            score += 2
            why.append(f'names legacy response code {"/".join(codes)} (expected HTTP {exp})')
        if exp and re.search(r'(?<!\d)' + str(exp) + r'(?!\d)', text):
            score += 1
            why.append(f'names HTTP {exp}')
        if home and home.strip('` ') in frames:
            score += 0.5
            why.append(f'its target home {home} is on the failing stack')
        hits = [f for f in fields if words(f) and joined(f) in tw][:2]
        if hits:
            score += 0.5 * len(hits)
            why.append(f'names the differing {", ".join(hits)}')
        ranked.append((round(score, 2), rid, home, r is not None, why))
    best = max((x[0] for x in ranked), default=0)
    out = [{'id': rid, 'targetHome': home, 'score': sc, 'caseRule': mine, 'why': why}
           for sc, rid, home, mine, why in ranked if sc == best and best >= 2]
    return sorted(out, key=lambda x: (not x['caseRule'], int(re.sub(r'\D', '', x['id']) or 0)))


# ---------------------------------------------------------------- draft

def render_draft(ctx, doc):
    tpl = read_text(SKILL / 'templates' / 'failures.md')
    m = re.search(r'<!-- failure -->\n(.*?)<!-- /failure -->\n?', tpl, re.S)
    block, out = (m.group(1), []) if m else ('', [])
    for f in doc['failures']:
        pc = f['preClass']
        rules = ', '.join(f"{r['id']} (`{r['targetHome']}`)" if r.get('targetHome') else r['id'] for r in f['rules'])
        suspects = ', '.join(f"{r['id']} (`{r['targetHome']}`)" if r.get('targetHome') else r['id']
                             for r in pc['suspectRules']) or '-'
        why = ' | '.join(f"{r['id']}: {'; '.join(r.get('why') or []) or '-'}" for r in pc['suspectRules']) or '-'
        exc = f.get('exception') or {}
        exception = (f"{exc.get('exceptionType') or '-'}: {exc.get('message') or '-'}"
                     + (f" at {exc['frame']}" if exc.get('frame') else '') + f" ({exc.get('source')})") if exc else '-'
        diff = '; '.join(f"{x['path']} {x['kind']} expected `{x['expected']}` actual `{x['actual']}`"
                         for x in f['difference']['fields'][:4]) or '-'
        values = {'id': f['scenarioId'], 'name': f.get('name') or f.get('title') or '', 'class': pc['class'],
                  'confidence': pc['confidence'], 'preClass': f"{pc['class']} ({pc['confidence']})",
                  'rules': rules or '-', 'suspects': suspects, 'why': why, 'exception': exception, 'operation': f.get('operation') or '-',
                  'expected': str(f['expected'].get('status')), 'actual': str(f['actual'].get('status')),
                  'diff': diff, 'fields': ', '.join(pc['fields']) or '-',
                  'signals': '; '.join(f"{s['class']} {s['weight']}: {s['signal']}" for s in pc['signals']) or '-',
                  'hints': '; '.join(pc.get('hints') or []) or '-',
                  'next': NEXT[pc['class']]}
        out.append(fill(block, values))
    counts = Counter(f['preClass']['class'] for f in doc['failures'])
    values = {'mu': ctx.name, 'entry': ctx.entry, 'runId': doc['runId'], 'snapshot': doc['snapshot'] or '-',
              'date': doc['analysedAt'][:10], 'analysis': ctx.rel(ctx.tmp / 'analysis.json'),
              'failed': str(len(doc['failures'])), 'blocked': str(len(doc['blocked'])),
              'skipped': str(len(doc['skipped'])),
              'classCounts': ' · '.join(f'{c} {counts[c]}' for c in CLASSES if counts[c]) or 'none',
              'apart': '\n'.join(f"- {b['scenarioId']} {b['status']} -> {b['class']}: {b.get('reason') or '-'}"
                                 for b in doc['blocked'] + doc['skipped']) or '- none'}
    text = fill(tpl[:m.start()] if m else tpl, values) + ''.join(out) + (fill(tpl[m.end():], values) if m else '')
    return text


def fill(text, values):
    return re.sub(r'\{\{(\w+)\}\}', lambda m: str(values.get(m.group(1), m.group(0))), text)


def skipped_row(s, cases, log_entries):
    """A SKIPPED scenario, ENVIRONMENT, with the build log's exception for it (a connection failure named)."""
    exc = s.get('evidence') or runlog.first_exception(log_entries.get(s['scenarioId']))
    text = ' '.join([runlog.describe(exc) or '', ' '.join((exc or {}).get('causedBy') or []), s.get('message') or ''])
    signal = ('connection failure' if _ENV.search(text) else 'schema, table or rights failure'
              if _ENV_SCHEMA.search(text) else 'not run' if s.get('missingFromReport') else 'skipped')
    return {'scenarioId': s['scenarioId'], 'name': (cases.get(s['scenarioId']) or {}).get('name') or s.get('title'),
            'status': 'SKIPPED', 'class': 'ENVIRONMENT', 'reason': (s.get('message') or '')[:EXCERPT],
            'missingFromReport': bool(s.get('missingFromReport')), 'signal': signal,
            'evidence': {'exception': runlog.describe(exc), 'causedBy': (exc or {}).get('causedBy') or []}
            if exc else None}


# ---------------------------------------------------------------- the step

def run_step(ctx, args, st):
    run_id, summary = last_run(ctx, getattr(args, 'run', None))
    run_dir = ctx.runs / run_id / f'run-{summary.get("runs") or 1}'
    report = read_json(run_dir / 'e2e-replay.json', 'framework report')
    log_path = runlog.build_log(run_dir)
    log_entries = runlog.scenario_log(log_path) if log_path else {}
    if not summary.get('selection'):                         # a register scenario the report lacks: SKIPPED
        register = runlog.register_of(ctx.e2e / 'scenarios' / f'{ctx.entry}.json')
        report = {**report, 'scenarios': list(report.get('scenarios') or [])
                  + runlog.missing(register, report, log_entries)}
    package = read_json(ctx.package, 'package') if ctx.package.is_file() else {}
    cases = {c.get('id'): c for c in package.get('cases') or []}
    operations = ((package.get('binding') or {}).get('operations')) or []
    rules = rules_of(ctx.mu / 'design' / 'rules.md')
    revision = (summary.get('snapshot') or {}).get('revision') or (st.get('snapshot') or {}).get('revision')
    snap = ctx.products / revision if revision else None
    api = javaapi.Api(snap) if snap and snap.is_dir() else javaapi.Api(Path('/nonexistent'))
    warnings = [] if api.files else [f'no product snapshot {revision}: the API is not read']
    groups = by_scenario(report.get('scenarios') or [])      # a scenario's worst level decides
    statuses = {sid: status for sid, (status, _) in groups.items()}
    # one row per scenario: its deciding level, with every FAILED level kept for the merge
    scenarios = [{**next(x for x in levels if x.get('status') == status), 'status': status,
                  '_failed': [x for x in levels if x.get('status') == 'FAILED']}
                 for sid, (status, levels) in groups.items()]
    by_rule = defaultdict(list)
    for sid in statuses:
        for rid in (cases.get(sid) or {}).get('ruleIds') or []:
            by_rule[rid].append(sid)
    ops = defaultdict(lambda: {'cases': 0, 'compared': 0, 'passed': 0, 'failed': 0, 'byActual': Counter()})
    for s in scenarios:
        case = cases.get(s['scenarioId']) or {}
        op = operation_of(case, operations)
        req = case.get('request') or {}
        name = (op or {}).get('name') or (f'{str(req.get("method") or "").upper()} {req.get("path")}'
                                         if req.get('method') else '-')
        o = ops[name]
        o['cases'] += 1
        if s['status'] in ('PASSED', 'FAILED'):
            o['compared'] += 1
            o['passed' if s['status'] == 'PASSED' else 'failed'] += 1
            if s['status'] == 'FAILED':
                o['byActual'][str(answer_of(s)['status'])] += 1
    ops = {k: {**v, 'byActual': dict(v['byActual'])} for k, v in ops.items()}
    compared = [s for s in scenarios if s['status'] in ('PASSED', 'FAILED')]
    failed_s = [s for s in scenarios if s['status'] == 'FAILED']
    sigs = {tuple(sorted(deciding(s).get('signatures') or [])) for s in failed_s}
    exceptions = run_exceptions(ctx.runs / run_id / f'run-{summary.get("runs") or 1}')

    def codes_for(op_name, status):
        op = next((o for o in operations if o.get('name') == op_name), None)
        resp = ((op or {}).get('response') or {}).get('map') or {}
        return [k for k, v in resp.items() if isinstance(v, dict) and v.get('status') == status]

    info = {'rules': rules, 'operations': ops, 'failOnUnknown': api.jackson['failOnUnknownProperties'], 'exceptions': exceptions,
            'answering': api.statuses_answering, 'codesFor': codes_for,
            'readiness': (st.get('readiness') or {}).get('ready'),
            'allFailedAlike': len(compared) >= 3 and len(failed_s) == len(compared) and len(sigs) == 1}
    failures = []
    for s in failed_s:
        e = evidence(s, cases.get(s['scenarioId']) or {}, rules, api, operations, by_rule, statuses,
                     runlog.product_exception(log_entries.get(s['scenarioId'])))
        merge_levels(e, s['_failed'])
        e['preClass'] = classify(e, info)
        failures.append(e)
    states = {p.stem: (read_json(p, 'golden master').get('state'))
              for p in sorted((ctx.e2e / 'golden' / ctx.entry).glob('*.json'))} if (ctx.e2e / 'golden' /
                                                                                       ctx.entry).is_dir() else {}
    blocked = [{'scenarioId': s['scenarioId'], 'name': (cases.get(s['scenarioId']) or {}).get('name'),
                'status': 'BLOCKED', 'class': 'PACKAGE', 'reason': (s.get('message') or '')[:EXCERPT],
                'goldenState': states.get(s['scenarioId'])} for s in scenarios if s['status'] == 'BLOCKED']
    skipped = [skipped_row(s, cases, log_entries) for s in scenarios if s['status'] == 'SKIPPED']
    counts = Counter(f['preClass']['class'] for f in failures)
    counts.update(b['class'] for b in blocked + skipped)
    doc = {'format': 1, 'mu': ctx.name, 'entry': ctx.entry, 'runId': run_id, 'analysedAt': iso_now(),
           'run': {'summary': ctx.rel(ctx.runs / run_id / 'summary.json'), 'report': ctx.rel(run_dir / 'e2e-replay.json'),
                   'log': ctx.rel(log_path) if log_path else None,
                   'finishedAt': summary.get('finishedAt'), 'selection': summary.get('selection'),
                   'counts': summary.get('counts')},
           'snapshot': revision, 'snapshotDir': ctx.rel(snap) if snap else None,
           'api': {'controllers': [{k: c[k] for k in ('verb', 'path', 'controller', 'method', 'requestBody',
                                                        'responseType', 'status')} for c in api.controllers],
                   'exceptionStatus': {k: v['status'] for k, v in api.exception_status.items()},
                   'jackson': api.jackson},
           'operations': ops, 'exceptions': exceptions,
           'classCounts': {c: counts[c] for c in CLASSES if counts[c]},
           'failures': failures, 'blocked': blocked, 'skipped': skipped, 'warnings': warnings}
    out = ctx.tmp / 'analysis.json'
    write_json(out, doc)
    draft = ctx.tmp / 'failures-draft.md'
    write_text(draft, render_draft(ctx, doc))
    st['analysis'] = {'runId': run_id, 'at': doc['analysedAt'], 'file': ctx.rel(out), 'failed': len(failures),
                      'classCounts': doc['classCounts']}
    return 0, {'status': 'analysed', 'entry': ctx.entry, 'runId': run_id, 'failed': len(failures),
               'blocked': len(blocked), 'skipped': len(skipped), 'preClasses': doc['classCounts'],
               'byScenario': [{'scenarioId': f['scenarioId'], 'class': f['preClass']['class'],
                               'confidence': f['preClass']['confidence'],
                               'rules': [r['id'] for r in f['preClass']['suspectRules']],
                               'fields': f['preClass']['fields']} for f in failures[:40]],
               'analysis': ctx.rel(out), 'draft': ctx.rel(draft), 'failuresFile': ctx.rel(ctx.failures),
               'warnings': warnings,
               'next': 'confirm or change each class, write failures.md from the draft, one VQ per BINDING or '
                       'UNKNOWN, then report'}
