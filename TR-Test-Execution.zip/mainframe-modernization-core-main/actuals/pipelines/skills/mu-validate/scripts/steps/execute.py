"""Step 8 - execute: the replay. Does the product answer as the legacy did, on the same rows?

    mu_validate.py execute <mu> [--entry E] [--runs 2] [--tags EXPR]
    mu_validate.py execute <mu> --smoke

Port of e2e_v1 main `e2e_test_solution build --mode replay`: `mvn verify -Pe2e-replay
-Dmaven.test.failure.ignore=true -pl <mu>-e2e -am` in validation/, the private repository validation/target/m2
(~/.m2 a read-only tail), the product snapshot, E2E_DB_* from tools.yaml e2e-db2 (the password only in the child
environment), the clock pinned and frozen at each case's instant (E2E_TARGET_PIN_CLOCK=true, E2E_TARGET_CLOCK=frozen;
the module pom also sets e2e.target.clock=frozen). The framework (fixtures-jdbc) builds the e2e-db2 schema from
fixtures/manifest.json once per run (CREATE SCHEMA when absent, its tables dropped and created from
schema/recording-schema.sql) and empties every table before each pack: no other schema is touched.

The results come from <module>/target/e2e-reports/e2e-replay.json, never from the Maven exit (a scenario that differs
is a result). A scenario of the register (e2e/scenarios/<entry>.json) the report lacks - e.g. a surefire error before
its verdict - counts SKIPPED, with the build log's exception as its reason (a full run only). Each run is copied to mu/<MU>/validation/runs/<run-id>/run-<n>/ (the reports and the build log);
runs/<run-id>/summary.json holds the snapshot and package replayed, the counts per scenario and status (a
scenario's worst level decides; its FAILED levels are one row), the strict and contract columns, BLOCKED scenarios with
their reason and golden-master state (not accepted: never a pass), the failed ones with their first differences,
whether the runs were identical to each other and to the previous full run. `--tags` selects (-De2e.tags); a
selected run is never compared with a full one.

Before it runs: framework installed, snapshot current, module present, assets imported and fixtures prepared, at
least one golden master ACCEPTED (exit 2 otherwise), and the database answering (exit 2, errorCode DATABASE_DOWN).
Not repeatable: exit 1 (NOT_REPEATABLE) after the summary is written.

--smoke boots the application once against the e2e-db2 database (<prefix>ApplicationSmokeTest, default profile,
no scenario) and lists the tables of the e2e-db2 schema (read-only); it writes no run.
"""

import json
import os
import shutil
import socket
import time
import xml.etree.ElementTree as ET
from collections import Counter

from e2elib import canonical, update
from steps import solution as solution_step
from vlib import db2, maven, runlog
from vlib.common import Stop, by_scenario, iso_now, last_lines, long_path, package_hash, read_json, sha256, write_json

PROFILE = 'e2e-replay'
REPORT = 'e2e-replay.json'
SHOWN_FIELDS = 8
STATUSES = ('PASSED', 'FAILED', 'BLOCKED', 'NOT_APPLICABLE', 'SKIPPED')


def add_arguments(ap):
    ap.add_argument('--runs', type=int, default=2, help='replay runs to compare (default 2)')
    ap.add_argument('--tags', help='tag expression of the register vocabulary (-De2e.tags)')
    ap.add_argument('--smoke', action='store_true', help='boot the application against e2e-db2 only; no replay')


# ---------------------------------------------------------------- environment

def database(ctx):
    sec = ctx.tool('e2e-db2')
    if not sec:
        raise Stop('tools.yaml has no e2e-db2: run preflight', code=2)
    schema = str(sec.get('schema') or '').upper()
    if not schema.startswith('E2E'):
        raise Stop(f'e2e-db2 schema {schema!r} does not start with E2E: refused (run preflight)')
    host, port = sec.get('host') or 'localhost', int(sec.get('port') or 50000)
    url = f'jdbc:db2://{host}:{port}/{sec.get("database") or "TESTDB"}'
    return {'host': host, 'port': port, 'url': url, 'schema': schema, 'user': sec.get('user'),
            'password': sec.get('password'), 'container': sec.get('container'),
            'database': sec.get('database') or 'TESTDB'}


def reachable(host, port, timeout=3.0):
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def environment(db):
    env = {k: v for k, v in os.environ.items() if k not in solution_step.DB_ENV + solution_step.RUN_ENV}
    env.update({'E2E_DB_URL': db['url'], 'E2E_DB_USER': str(db['user'] or ''),
                'E2E_DB_PASSWORD': str(db['password'] or ''), 'E2E_DB_SCHEMA': db['schema'],
                'E2E_TARGET_PIN_CLOCK': 'true', 'E2E_TARGET_CLOCK': 'frozen'})
    shown = {'E2E_DB_URL': db['url'], 'E2E_DB_USER': db['user'], 'E2E_DB_PASSWORD': 'set' if db['password'] else
             'not set', 'E2E_DB_SCHEMA': db['schema'], 'E2E_TARGET_PIN_CLOCK': 'true', 'E2E_TARGET_CLOCK': 'frozen'}
    return env, shown


def schema_tables(db):
    """{table: rows} of the e2e-db2 schema through the container's CLP (read-only), or the reason it is unknown."""
    if not db.get('container'):
        return None, 'e2e-db2 names no container'
    try:
        return db2.tables(db, db['schema']), None
    except Stop as e:
        return None, str(e)


# ---------------------------------------------------------------- the report

def read_report(path):
    return json.loads(path.read_text(encoding='utf-8')) if path.is_file() else None


def verdict_of(s):
    return (s.get('strict') if s.get('verdictProfile') == 'strict' else s.get('contract')) or {}


def fingerprint(report):
    """Per scenario level: (status, difference signatures of the deciding comparison, title)."""
    return {f'{s.get("scenarioId")}|{s.get("level")}|{s.get("unit")}':
            (s.get('status'), tuple(sorted(verdict_of(s).get('signatures') or [])), s.get('title'))
            for s in report.get('scenarios', [])}


def prints_digest(prints):
    return sha256(json.dumps(sorted([k, v[0], list(v[1]), v[2]] for k, v in prints.items()), ensure_ascii=False))[:16]


def difference(s):
    verdict = verdict_of(s)
    diffs = verdict.get('diffs') or []
    return {'profile': s.get('verdictProfile'), 'signatures': sorted(verdict.get('signatures') or []),
            'count': len(diffs), 'fields': [{'path': d.get('field'), 'kind': d.get('kind'), 'expected': d.get('legacy'),
                                             'actual': d.get('target')} for d in diffs[:SHOWN_FIELDS]]}


def golden_states(ctx):
    folder = ctx.e2e / 'golden' / ctx.entry
    return {p.stem: canonical.load_json(p).get('state') for p in sorted(folder.glob('*.json'))} \
        if folder.is_dir() else {}


def merged_difference(levels):
    """One difference of a scenario's FAILED levels: their fields and signatures together, the levels named."""
    parts = [difference(s) for s in levels]
    fields, seen = [], set()
    for p in parts:
        for f in p['fields']:
            key = (f['path'], f['kind'], str(f['expected']), str(f['actual']))
            if key not in seen:
                seen.add(key)
                fields.append(f)
    return {'profile': parts[0]['profile'], 'signatures': sorted({x for p in parts for x in p['signatures']}),
            'count': sum(p['count'] for p in parts), 'fields': fields[:SHOWN_FIELDS],
            'levels': [s.get('level') for s in levels]}


def scenario_counts(report):
    counts = {k: 0 for k in STATUSES}
    counts.update(Counter(status for status, _ in by_scenario(report.get('scenarios') or []).values()))
    return counts


def summarize(report, states):
    """Per scenario (its worst level decides; the FAILED levels merged into one row): counts per status, the strict /
    contract columns of the deciding level, blocked / failed / not-applicable rows."""
    groups = by_scenario(report.get('scenarios') or [])
    rows = [(sid, status, levels, next(x for x in levels if x.get('status') == status))
            for sid, (status, levels) in groups.items()]
    counts = scenario_counts(report)
    columns = {}
    for name in ('strict', 'contract'):
        found = [s[name].get('status') for _, _, _, s in rows if isinstance(s.get(name), dict)]
        if found:
            columns[name] = dict(Counter(found))
    blocked = [{'scenarioId': sid, 'title': s.get('title'), 'reason': s.get('message'),
                'goldenState': states.get(sid)} for sid, status, _, s in rows if status == 'BLOCKED']
    failed = [{'scenarioId': sid, 'title': s.get('title'), 'message': s.get('message'),
               'difference': merged_difference([x for x in levels if x.get('status') == 'FAILED']),
               'hypotheses': s.get('hypotheses') or []}
              for sid, status, levels, s in rows if status == 'FAILED']
    other = [{'scenarioId': sid, 'status': status, 'reason': s.get('message')}
             for sid, status, _, s in rows if status not in ('PASSED', 'FAILED', 'BLOCKED')]
    return {'scenarios': len(rows), 'levels': len(report.get('scenarios') or []), 'counts': counts, 'columns': columns,
            'blockedNotAccepted': sum(1 for b in blocked if b['goldenState'] not in (None, 'ACCEPTED')),
            'blocked': blocked, 'failed': failed, 'other': other}


def register(ctx):
    return runlog.register_of(ctx.e2e / 'scenarios' / f'{ctx.entry}.json')


def completed(ctx, report, run_dir, selection):
    """The report with a SKIPPED row per register scenario it lacks (full runs only), and those rows."""
    if selection or report is None:
        return report, []
    return runlog.with_missing(report, register(ctx), runlog.build_log(run_dir))


def previous_full_run(ctx, run_id):
    found = []
    for path in sorted(ctx.runs.glob('*/summary.json')) if ctx.runs.is_dir() else []:
        if path.parent.name == run_id:
            continue
        try:
            doc = read_json(path, 'run summary')
        except Stop:
            continue
        if doc.get('mode') == 'replay' and not doc.get('selection') and doc.get('runs'):
            found.append((str(doc.get('finishedAt') or ''), path.parent.name, doc))
    if not found:
        return None
    _, rid, doc = max(found, key=lambda f: (f[0], f[1]))
    run_dir = ctx.runs / rid / f'run-{doc["runs"]}'
    report, _ = completed(ctx, read_report(run_dir / REPORT), run_dir, None)
    return rid, doc, report


def compare_runs(reports):
    prints = [fingerprint(r) for r in reports]
    differences = [{'scenario': key, 'run': n + 2, 'first': list(prints[0].get(key) or ()),
                    'other': list(p.get(key) or ())}
                   for n, p in enumerate(prints[1:]) for key in sorted(set(prints[0]) | set(p))
                   if prints[0].get(key) != p.get(key)]
    return prints, differences


def build_summary(ctx, st, run_id, started_at, reports, builds, selection, shown, snap_hash=None):
    states = golden_states(ctx)
    prints, differences = compare_runs(reports)
    last = reports[-1]
    summary = {'format': 1, 'mu': ctx.name, 'entry': ctx.entry, 'runId': run_id, 'mode': 'replay',
               'startedAt': started_at, 'finishedAt': last.get('finishedAt') or iso_now(),
               'snapshot': {'hash': snap_hash, 'revision': snap_hash[:16]} if snap_hash else
               {k: (st.get('snapshot') or {}).get(k) for k in ('hash', 'revision')},
               'package': {'contentHash': package_hash(ctx.package), 'version': (st.get('import') or {}).get('version'),
                           'imported': (st.get('import') or {}).get('contentHash'),
                           'fixtures': (st.get('fixtures') or {}).get('contentHash')},
               'framework': (st.get('framework') or {}).get('fingerprint'), 'environment': shown,
               'selection': selection, 'runs': len(reports),
               'perRun': [{'run': n + 1, 'counts': {k: v for k, v in scenario_counts(r).items() if v},
                           'digest': prints_digest(p), 'identicalToPrevious': None if n == 0 else p == prints[n - 1],
                           **builds[n]} for n, (r, p) in enumerate(zip(reports, prints))],
               'repeatable': None if len(reports) < 2 else not differences,
               'differencesBetweenRuns': differences, 'goldenStates': dict(Counter(states.values())),
               **summarize(last, states),
               'missingFromReport': [{'scenarioId': s['scenarioId'], 'reason': s['message']}
                                     for s in last.get('scenarios') or [] if s.get('missingFromReport')]}
    previous = previous_full_run(ctx, run_id) if not selection else None
    summary['previousRunId'] = previous[0] if previous else None
    if previous and previous[2] is not None:
        before = fingerprint(previous[2])
        summary['identicalToPrevious'] = before == prints[-1]
        delta = update.execution_delta(before, prints[-1])
        summary['deltaFromPrevious'] = {k: (v if isinstance(v, int) else len(v)) for k, v in delta.items()}
    else:
        summary['identicalToPrevious'] = None
        summary['deltaFromPrevious'] = None
    return summary


# ---------------------------------------------------------------- maven

def module_of(ctx, st):
    module_dir = ctx.validation / solution_step.module_name(ctx)
    if not (module_dir / 'pom.xml').is_file() or not (ctx.validation / 'pom.xml').is_file():
        raise Stop(f'{ctx.rel(module_dir)} does not exist: run solution', code=2)
    prefix = (st.get('solution') or {}).get('prefix')
    return module_dir, prefix


def clear(module_dir):
    copied = module_dir / 'target' / 'test-classes' / 'e2e'
    if copied.is_dir():                                   # Maven copies resources but never deletes a removed one
        shutil.rmtree(long_path(copied))
    reports = module_dir / 'target' / 'e2e-reports'
    for stale in reports.iterdir() if reports.is_dir() else []:
        if stale.is_file():                               # never read an earlier run's report as this run's
            stale.unlink()


def surefire(module_dir, since, pattern='TEST-*.xml'):
    totals = {'tests': 0, 'failures': 0, 'errors': 0, 'skipped': 0}
    for report in sorted((module_dir / 'target' / 'surefire-reports').glob(pattern)):
        if report.stat().st_mtime < since:
            continue
        try:
            suite = ET.parse(report).getroot()
        except ET.ParseError:
            continue
        for k in totals:
            totals[k] += int(suite.get(k, '0') or 0)
    return totals


# ---------------------------------------------------------------- the step

def preconditions(ctx, st):
    _, snap_hash = solution_step.preconditions(ctx)       # framework installed, snapshot current (exit 2)
    module_dir, prefix = module_of(ctx, st)
    if not (ctx.e2e / 'scenarios' / f'{ctx.entry}.json').is_file():
        raise Stop('nothing is imported: run import', code=2)
    if not (ctx.e2e / 'fixtures' / 'manifest.json').is_file():
        raise Stop('the fixtures are not prepared: run fixtures', code=2)
    return module_dir, prefix, snap_hash


def smoke(ctx, st, db, env, shown, module_dir, prefix):
    if not prefix:
        raise Stop('the module\'s class prefix is unknown: run solution', code=2)
    test = f'{prefix}ApplicationSmokeTest'
    clear(module_dir)
    log = ctx.logs / f'smoke-{module_dir.name}.log'
    started, since = time.monotonic(), time.time() - 2
    code, out = maven.mvn(['-f', str(ctx.validation / 'pom.xml'), 'verify', '-pl', module_dir.name, '-am',
                           f'-Dtest={test}', '-Dsurefire.failIfNoSpecifiedTests=false'],
                          cwd=ctx.validation, log=log, head=ctx.m2, tail=ctx.home_m2, env=env)
    totals = surefire(module_dir, since, f'TEST-*{test}.xml')
    passed = code == 0 and totals['tests'] >= 1 and not totals['skipped'] and not totals['failures'] \
        and not totals['errors']
    tables, why = schema_tables(db)
    doc = {'status': 'booted' if passed else 'failed', 'test': test, 'exitCode': code, **totals,
           'seconds': round(time.monotonic() - started, 1), 'log': ctx.rel(log), 'environment': shown,
           'schema': db['schema'], 'schemaTables': tables, **({'schemaTablesUnknown': why} if why else {})}
    st['smoke'] = {k: doc[k] for k in ('status', 'at', 'tests', 'skipped', 'failures', 'errors', 'schema')
                   if k in doc} | {'at': iso_now()}
    if not passed:
        why_failed = 'skipped (the test found no reachable database)' if totals['skipped'] else \
            'not run' if not totals['tests'] else f'Maven exit {code}'
        raise Stop(f'the smoke boot failed: {why_failed}; see {doc["log"]}', code=1,
                   **{k: v for k, v in doc.items() if k != 'status'}, tail=last_lines(out, 30))
    return 0, doc


def run_step(ctx, args, st):
    module_dir, prefix, snap_hash = preconditions(ctx, st)
    db = database(ctx)
    env, shown = environment(db)
    if not reachable(db['host'], db['port']):
        raise Stop(f'the replay database does not answer at {db["host"]}:{db["port"]} - start the parity Db2 '
                   '(parity-tester start), then run execute again', code=2, errorCode='DATABASE_DOWN',
                   database={k: shown[k] for k in ('E2E_DB_URL', 'E2E_DB_SCHEMA')})
    if args.smoke:
        return smoke(ctx, st, db, env, shown, module_dir, prefix)
    if args.runs < 1:
        raise Stop('--runs must be 1 or more')
    states = golden_states(ctx)
    counts = Counter(states.values())
    if not counts.get('ACCEPTED'):
        raise Stop('no golden master is ACCEPTED: run gate prepare and have the record gate answered', code=2,
                   errorCode='RECORD_GATE_OPEN', goldenStates=dict(counts), question=(st.get('gate') or {}).get('open'))
    warnings = []
    if counts.get('RECORDED'):
        warnings.append(f'{counts["RECORDED"]} golden master(s) are not accepted (record gate '
                        f'{(st.get("gate") or {}).get("open") or "not prepared"}): they replay BLOCKED')
    started_at = iso_now()
    run_id = base_id = started_at.replace('-', '').replace(':', '')
    n = 1
    while (ctx.runs / run_id).exists():
        n += 1
        run_id = f'{base_id}-{n}'
    run_root = ctx.runs / run_id
    selection = {'tags': args.tags} if args.tags else None
    arguments = ['-f', str(ctx.validation / 'pom.xml'), 'verify', f'-P{PROFILE}', '-Dmaven.test.failure.ignore=true',
                 '-pl', module_dir.name, '-am'] + ([f'-De2e.tags={args.tags.strip()}'] if args.tags else [])
    reports, builds = [], []
    started = time.monotonic()
    for number in range(1, args.runs + 1):
        clear(module_dir)
        log = ctx.logs / f'replay-{run_id}-{number}.log'
        since, t0 = time.time() - 2, time.monotonic()
        code, out = maven.mvn(arguments, cwd=ctx.validation, log=log, head=ctx.m2, tail=ctx.home_m2, env=env,
                              timeout=7200)
        target = run_root / f'run-{number}'
        target.mkdir(parents=True, exist_ok=True)
        reports_dir = module_dir / 'target' / 'e2e-reports'
        for source in reports_dir.iterdir() if reports_dir.is_dir() else []:
            if source.is_file():
                shutil.copy2(source, target / source.name)
        shutil.copy2(log, target / log.name)
        build = {'exitCode': code, 'seconds': round(time.monotonic() - t0, 1), 'log': ctx.rel(target / log.name),
                 'surefire': surefire(module_dir, since)}
        if code != 0:
            raise Stop(f'the replay build {number} failed (Maven exit {code}, not a scenario result); see '
                       f'{ctx.rel(log)}', code=1, errorCode='REPLAY_BUILD_FAILED', runId=run_id,
                       tail=last_lines(out, 30))
        report = read_report(reports_dir / REPORT)
        if report is None:
            raise Stop(f'no {REPORT} in {ctx.rel(reports_dir)} after run {number}: did the module run any scenario?',
                       code=1, errorCode='E2E_REPORT_MISSING', runId=run_id, log=ctx.rel(log))
        report, absent = completed(ctx, report, target, selection)
        if absent:
            build['missingFromReport'] = [s['scenarioId'] for s in absent]
        reports.append(report)
        builds.append(build)
    summary = build_summary(ctx, st, run_id, started_at, reports, builds, selection, shown, snap_hash)
    summary['seconds'] = round(time.monotonic() - started, 1)
    summary['warnings'] = warnings
    write_json(run_root / 'summary.json', summary)
    st.setdefault('runs', []).append({'runId': run_id, 'finishedAt': summary['finishedAt'], 'counts': summary['counts'],
                                      'repeatable': summary['repeatable'], 'selection': selection,
                                      'snapshot': summary['snapshot'].get('revision'),
                                      'snapshotHash': summary['snapshot'].get('hash'),
                                      'contentHash': summary['package']['contentHash'],
                                      'summary': ctx.rel(run_root / 'summary.json')})
    doc = {'status': 'done', 'entry': ctx.entry, 'runId': run_id, 'runs': len(reports), 'counts': summary['counts'],
           'columns': summary['columns'], 'blockedNotAccepted': summary['blockedNotAccepted'],
           'repeatable': summary['repeatable'], 'identicalToPrevious': summary['identicalToPrevious'],
           'previousRunId': summary['previousRunId'], 'deltaFromPrevious': summary['deltaFromPrevious'],
           'summary': ctx.rel(run_root / 'summary.json'), 'warnings': warnings}
    if summary['repeatable'] is False:
        raise Stop(f'the {len(reports)} replay runs differ in {len(summary["differencesBetweenRuns"])} scenario '
                   f'level(s): not repeatable - see {doc["summary"]}', code=1, errorCode='NOT_REPEATABLE',
                   **{k: v for k, v in doc.items() if k != 'status'})
    return 0, doc
