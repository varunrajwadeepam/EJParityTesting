"""Step 7 - gate: the record gate. A named person accepts the golden masters as the oracle of the replay.

    mu_validate.py gate <mu> prepare [--entry E]
    mu_validate.py gate <mu> apply   [--entry E]

People decide here; the script prepares what they decide on and records the decision. It never decides: there is
no option that approves, and the agent never writes the answer.

  prepare  lists the golden masters that are new or changed (RECORDED and no acceptance of their current oracle
           key) in a blocking RG-n of validation-open-questions.md, one evidence line each (case id, name, rules,
           expected status, recorded at), the decided answers among them first (◆ case, source, decided status and
           code vs the recorded status, tables), and exits 2 while it is open. An open RG-n of the same masters is kept
           (no new entry); one of other masters (the package changed before it was answered) is set settled and
           replaced. Nothing new or changed: exit 0, nothing written.
  apply    reads the RG-n Answer:
             approved by <First Last>
             approved by <First Last>; disputed: <id> - <reason>, <id> - <reason>
             rejected - <reason>
           An empty answer, or one that names no person, is refused (exit 2, nothing written). Approved: every
           listed master -> validation-state.json `acceptance.<id> = {oracleKey, by, at, gate}` (the disputed ones
           also `state: DISPUTED, reason`), RG-n set settled, then the import is re-done so the golden masters carry
           it (ACCEPTED / DISPUTED). Rejected: nothing accepted, exit 2. Masters changed since prepare: exit 2.
"""

import hashlib
import re
from collections import Counter

from e2elib import canonical, package, update
from steps import importer
from vlib import questions as vq
from vlib.common import slash_command, Stop, iso_now

ANSWER_FORM = ('`approved by <First Last>` or `approved by <First Last>; disputed: <id> - <reason>, <id> - <reason>`'
               ' (or `rejected - <reason>`)')
_APPROVED = re.compile(r'^approved\s+by\s+(?P<by>[^;]+?)\s*(?:;\s*disputed\s*:\s*(?P<disputed>.*?))?\s*\.?$', re.I)
_REJECTED = re.compile(r'^rejected\s*(?:[-–—:]\s*(?P<reason>.*?))?\s*$', re.I)
_ITEM = re.compile(r'^(?P<id>[A-Za-z0-9_.:-]+)\s+[-–—]\s+(?P<reason>\S.*)$')
_SPLIT = re.compile(r'\s*,\s*(?=[A-Za-z0-9_.:-]+\s+[-–—]\s)')
NOT_A_PERSON = {'agent', 'ai', 'assistant', 'auto', 'automatic', 'automatically', 'bot', 'claude', 'llm', 'me',
                'model', 'myself', 'nobody', 'owner', 'script', 'someone', 'system', 'the', 'user', 'unknown', 'tbd',
                'name', 'first', 'last', 'your', 'approved', 'by', 'disputed', 'rejected'}


def add_arguments(ap):
    ap.add_argument('action', choices=['prepare', 'apply'], help='prepare the record gate RG-n, or apply its answer')


# ---------------------------------------------------------------- answer

def person(text):
    """The name when `text` names a person (two or more words of letters), else None."""
    words = text.replace('<', ' ').replace('>', ' ').split()
    if len(words) < 2 or len(words) > 6:
        return None
    for w in words:
        core = re.sub(r"[.'\-’]", '', w)
        if not core or not core.isalpha() or core.lower() in NOT_A_PERSON:
            return None
    return ' '.join(words)


def parse_answer(answer, listed):
    """{'kind': 'approved' | 'rejected' | 'unclear', 'by', 'disputed' {id: reason}, 'reason', 'why'}."""
    text = ' '.join((answer or '').split())
    if not text:
        return {'kind': 'unclear', 'why': 'the answer is empty'}
    m = _REJECTED.match(text)
    if m:
        if not m.group('reason'):
            return {'kind': 'unclear', 'why': 'a rejection needs its reason: `rejected - <reason>`'}
        return {'kind': 'rejected', 'reason': m.group('reason')}
    m = _APPROVED.match(text)
    if not m:
        return {'kind': 'unclear', 'why': f'the answer does not read {ANSWER_FORM}'}
    by = person(m.group('by'))
    if not by:
        return {'kind': 'unclear', 'why': f'"{m.group("by")}" names no person: the answer needs the first and last '
                                          'name of who decided'}
    disputed = {}
    if m.group('disputed') is not None:
        items = [i for i in _SPLIT.split(m.group('disputed').strip()) if i.strip()]
        if not items:
            return {'kind': 'unclear', 'why': '`disputed:` lists no recording'}
        for item in items:
            im = _ITEM.match(item.strip().rstrip('.'))
            if not im:
                return {'kind': 'unclear', 'why': f'"{item}" does not read `<id> - <reason>`'}
            if im.group('id') not in listed:
                return {'kind': 'unclear', 'why': f'{im.group("id")} is not one of the golden masters this gate lists'}
            disputed[im.group('id')] = im.group('reason').strip()
    return {'kind': 'approved', 'by': by, 'disputed': disputed}


# ---------------------------------------------------------------- what is to be decided

def load(ctx):
    register = ctx.e2e / 'scenarios' / f'{ctx.entry}.json'
    folder = ctx.e2e / 'golden' / ctx.entry
    if not register.is_file() or not folder.is_dir():
        raise Stop(f'{ctx.rel(ctx.e2e)} holds no imported golden masters of {ctx.entry}: run import first', code=2)
    entries = {e['scenarioId']: e for e in canonical.load_json(register).get('scenarios', [])}
    masters = {p.stem: canonical.load_json(p) for p in sorted(folder.glob('*.json'))}
    broken = sorted(sid for sid, m in masters.items() if not canonical.integrity_holds(m))
    if broken:
        raise Stop('golden masters were edited after they were sealed: run import again', broken=broken)
    return entries, masters


def to_decide(ctx, st):
    """(entries, masters, {sid: {oracleKey, change}}, re-import needed) - RECORDED and not decided at that key."""
    entries, masters = load(ctx)
    acceptance = st.get('acceptance') or {}
    listed, reimport = {}, []
    for sid, master in masters.items():
        if master.get('state') != 'RECORDED':
            continue
        key = update.oracle_key(entries.get(sid), master)
        acc = acceptance.get(sid)
        if acc and acc.get('oracleKey') == key:
            reimport.append(sid)                         # decided, the import has not carried it yet
            continue
        listed[sid] = {'oracleKey': key, 'change': 'changed' if acc or master.get('supersedes') else 'new'}
    return entries, masters, listed, reimport


def digest(listed):
    return hashlib.sha256('\n'.join(f'{sid}:{v["oracleKey"]}' for sid, v in sorted(listed.items()))
                          .encode('utf-8')).hexdigest()[:16]


def evidence_line(sid, change, entry, master):
    entry = entry or {}
    payload = (master.get('observation') or {}).get('payload') or {}
    outcome = (master.get('observation') or {}).get('outcome') or {}
    recording = (master.get('evidence') or {}).get('recording') or {}
    expected = f'expected {outcome.get("exitState", "?")}'
    if isinstance(payload, dict):
        if payload.get('$empty'):
            expected += ', empty answer'
        if isinstance(payload.get('$tables'), dict):
            expected += f', {len(payload["$tables"])} table check(s)'
    decided = entry.get('decided') or {}
    if decided:
        expected += f' (decided by {decided.get("source")}; recorded {decided.get("recordedStatus", "?")})'
    rules = ', '.join(entry.get('ruleIds') or []) or '-'
    at = recording.get('recordedAt') or '?'
    repeats = recording.get('repeats')
    return (f'- {sid} {entry.get("title") or "-"} · {change} · rules {rules} · {expected} · recorded {at}'
            + (f' ({repeats} runs)' if repeats else ''))


def decided_lines(entries, masters, sids):
    """The decided answers among the listed masters (◆): case, source, decided answer vs the recorded one."""
    rows = []
    for sid in sorted(sids):
        decided = (entries.get(sid) or {}).get('decided') or {}
        if not decided:
            continue
        payload = (masters[sid].get('observation') or {}).get('payload')
        code = payload.get('code') if isinstance(payload, dict) and isinstance(payload.get('code'), str) else None
        recorded = decided.get('recordedStatus', '?')
        rows.append(f'- ◆ {sid} {(entries.get(sid) or {}).get("title") or "-"} · decided by {decided.get("source")}: '
                    f'{decided.get("status")}{f" {code}" if code else ""} · recorded {recorded}'
                    + (' (status changed)' if recorded not in ('?', None) and recorded != decided.get('status') else '')
                    + (f' · tables {decided["tables"]}' if decided.get('tables') else ''))
    if not rows:
        return []
    changed = sum(1 for r in rows if '(status changed)' in r)
    return [f'- Decided answers, not the recording (accepted deviations) {len(rows)}, {changed} with another status '
            'than the recorded one: accepting the golden master accepts its decided answer.'] + rows


def pending_lines(ctx, sids):
    """The listed cases whose decided answer is pending: compared with the recording, the decision not applied."""
    try:
        doc = canonical.load_json(ctx.package) if ctx.package.is_file() else {}
    except (OSError, ValueError):
        return []
    rows = [(c['id'], package.pending_of(c)) for c in doc.get('cases') or [] if isinstance(c, dict)
            and c.get('id') in sids]
    return [f'- pending decision {p["source"]}: {p["reason"] or "-"} ({sid}: the recording is its oracle)'
            for sid, p in sorted(rows) if p]


def gate_entry(ctx, st, entries, masters, listed):
    imported = (st.get('imports') or {}).get(ctx.entry) or {}
    label = f'{ctx.entry} {imported.get("label") or ""}'.strip()
    states = Counter(m.get('state') for m in masters.values())
    profiles = ctx.e2e / 'profiles.json'
    rules = [r.get('rule') for p in (canonical.load_json(profiles).get('profiles') or [] if profiles.is_file() else [])
             if p.get('name') == 'contract' for r in p.get('rules') or [] if r.get('decision') == f'PKG-CMP-{ctx.entry}']
    counts = Counter(v['change'] for v in listed.values())
    what = ', '.join(f'{n} {k}' for k, n in sorted(counts.items()))
    lines = [f'- Package {label} (seal {str(imported.get("contentHash") or "")[:12]}); golden masters now: '
             + ', '.join(f'{k} {n}' for k, n in sorted(states.items())) + '.',
             f'- Read before accepting: {ctx.rel(ctx.e2e / "features" / f"{ctx.entry}.feature")} (the recordings as '
             f'scenarios) and the package report {ctx.rel(ctx.tests / "tests-report.md")}.',
             f'- Comparison decision PKG-CMP-{ctx.entry}: {", ".join(rules) or "no rules"} (the package\'s '
             'comparisonRules); the strict comparison stays visible in the run report.',
             '- Recorded by mu-build-tests on the parity-tester (GnuCOBOL, Db2 LUW), not on the mainframe: the '
             'emulator is not qualified here, every verdict carries this caveat.']
    decided = decided_lines(entries, masters, listed)
    lines += decided + pending_lines(ctx, set(listed))
    lines += [evidence_line(sid, listed[sid]['change'], entries.get(sid), masters[sid]) for sid in sorted(listed)]
    lines.append(f'- Answer as: {ANSWER_FORM}. Only the person deciding answers; the agent never does.')
    return {'title': f'Record gate {label}: {len(listed)} golden master(s) to accept',
            'step': 'gate', 'blocking': 'yes',
            'question': f'Accept the {len(listed)} golden master(s) of {label} listed below ({what}) as the oracle of '
                        f'the replay, with the comparison decision PKG-CMP-{ctx.entry}'
                        + (f', {len(decided) - 1} of them decided answers (◆, listed first)' if decided else '') + '?',
            'evidence': lines,
            'decision': 'nothing is accepted: a golden master not accepted replays BLOCKED, never PASSED',
            'affects': f'validation-state.json acceptance; {ctx.rel(ctx.e2e / "golden" / ctx.entry)} states; execute'}


def open_gate(ctx, st):
    gate = st.get('gate') or {}
    qid = gate.get('open')
    entry = next((e for e in vq.parse(ctx.questions) if e['id'] == qid), None) if qid else None
    return gate, qid, entry


# ---------------------------------------------------------------- prepare / apply

def prepare(ctx, st):
    entries, masters, listed, reimport = to_decide(ctx, st)
    gate, qid, entry = open_gate(ctx, st)
    states = dict(Counter(m.get('state') for m in masters.values()))
    base = {'entry': ctx.entry, 'goldenStates': states, 'file': ctx.rel(ctx.questions)}
    if reimport:
        base['warnings'] = [f'{len(reimport)} golden master(s) are decided but still RECORDED: run import']
    if not listed:
        if entry and entry['status'] != 'settled':
            vq.set_status(ctx.questions, qid, 'settled')
        st['gate'] = {**gate, 'open': None}
        return 0, {'status': 'decided', **base, 'toDecide': 0,
                   'message': 'every golden master is decided (accepted or disputed)', 'next': 'execute'}
    d = digest(listed)
    superseded = None
    if entry and entry['status'] != 'settled' and gate.get('digest') == d:
        status = 'answered' if entry['answered'] else 'open'
        return 2, {'status': f'gate-{status}', **base, 'question': qid, 'toDecide': len(listed),
                   'next': 'gate apply' if entry['answered'] else None,
                   'message': (f'{qid} is answered: the agent applies it (gate apply)' if entry['answered'] else
                               f'{qid} waits for a named person\'s answer in {ctx.rel(ctx.questions)}; '
                               'then say "resume"')}
    if entry and entry['status'] != 'settled':
        vq.set_status(ctx.questions, qid, 'settled')        # its masters changed before it was answered
        superseded = qid
    new_id = vq.append(ctx.questions, gate_entry(ctx, st, entries, masters, listed), 'RG')
    st.setdefault('questions', {})[f'gate:{d}'] = new_id
    st['gate'] = {'open': new_id, 'digest': d, 'preparedAt': iso_now(),
                  'listed': {sid: v for sid, v in sorted(listed.items())}}
    if superseded:
        st['gate']['supersedes'] = superseded
    counts = Counter(v['change'] for v in listed.values())
    return 2, {'status': 'gate-open', **base, 'question': new_id, 'toDecide': len(listed), 'byChange': dict(counts),
               'supersededQuestion': superseded,
               'message': f'{new_id} written: a named person answers it ({ANSWER_FORM}), then says "resume"; '
                          'the agent applies it'}


def apply(ctx, args, st):
    gate, qid, entry = open_gate(ctx, st)
    if not qid:
        _, _, listed, _ = to_decide(ctx, st)
        if listed:
            raise Stop('no record gate is open: run gate prepare', code=2, toDecide=len(listed))
        return 0, {'status': 'unchanged', 'entry': ctx.entry, 'message': 'nothing to decide'}
    if entry is None:
        raise Stop(f'{qid} is not in {ctx.rel(ctx.questions)}: run gate prepare', code=2)
    if entry['status'] == 'settled':
        raise Stop(f'{qid} is settled: run gate prepare', code=2)
    _, _, listed, _ = to_decide(ctx, st)
    if digest(listed) != gate.get('digest'):
        raise Stop(f'the golden masters changed since {qid} was prepared: run gate prepare (a new RG replaces it)',
                   code=2, question=qid)
    decision = parse_answer(entry['answer'], set(listed))
    if decision['kind'] == 'unclear':
        raise Stop(f'{qid} cannot be applied: {decision["why"]}. Answer it as {ANSWER_FORM}', code=2, question=qid,
                   errorCode='GATE_ANSWER_REFUSED')
    if decision['kind'] == 'rejected':
        st['gate'] = {**gate, 'rejected': {'question': qid, 'reason': decision['reason'], 'at': iso_now()}}
        raise Stop(f'{qid} rejected the golden masters ({decision["reason"]}): nothing is accepted - rebuild the '
                   'package with ' + slash_command('mu-build-tests') + ', then import and gate prepare again', code=2, question=qid,
                   errorCode='RECORD_GATE_REJECTED')
    now = iso_now()
    acceptance = st.setdefault('acceptance', {})
    for sid, v in sorted(listed.items()):
        acc = {'oracleKey': v['oracleKey'], 'by': decision['by'], 'at': now, 'gate': qid}
        if sid in decision['disputed']:
            acc.update(state='DISPUTED', reason=decision['disputed'][sid])
        acceptance[sid] = acc
    vq.set_status(ctx.questions, qid, 'settled')
    st['gate'] = {'open': None, 'digest': gate.get('digest'), 'settled': qid, 'by': decision['by'], 'at': now,
                  'accepted': len(listed) - len(decision['disputed']), 'disputed': sorted(decision['disputed'])}
    result = {'status': 'applied', 'entry': ctx.entry, 'question': qid, 'by': decision['by'],
              'accepted': len(listed) - len(decision['disputed']), 'disputed': decision['disputed']}
    try:
        _, imported = importer.run_step(ctx, args, st)
    except Stop as e:
        return 1, {**result, 'status': 'failed', 'error': f'the acceptance is recorded, the re-import failed: {e} - '
                                                          'run import', 'reimport': e.extra}
    states = imported.get('goldenStates') or {}
    result.update(goldenStates=states, reimport={k: imported.get(k) for k in ('status', 'acceptanceReapplied',
                                                                               'acceptanceDropped')},
                  next='execute')
    if states.get('RECORDED'):
        result['warnings'] = [f'{states["RECORDED"]} golden master(s) still RECORDED after the re-import']
    return 0, result


def run_step(ctx, args, st):
    return prepare(ctx, st) if args.action == 'prepare' else apply(ctx, args, st)
