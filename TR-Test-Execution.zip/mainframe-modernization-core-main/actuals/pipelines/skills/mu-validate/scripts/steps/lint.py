"""Step 7 - lint: ER-1 on the module with its assets, after import and fixtures.

    mu_validate.py lint <mu> [--entry E]

Needs the framework installed, the snapshot current, the module written (solution), the assets imported and the
fixtures prepared (exit 2 otherwise). `mvn verify -pl <mu>-e2e -am` in the default profile against the private
repository, no E2E_DB_* in the environment (the smoke test skips; no database is touched). Passes with Maven exit 0
and 0 failures, 0 errors; the framework's lint report (target/e2e-reports/e2e-lint.json) gives the scenarios by
status. A failed ER-1 is exit 1. Records the digests of the assets and the module and the snapshot and package it
linted (validation-state.json lint): a re-import, new fixtures, a new module or snapshot make it stale.
"""

from steps import solution
from vlib.common import Stop, package_hash, tree_digest


def add_arguments(ap):
    pass


def digests(ctx, module_dir):
    return {'assetsDigest': tree_digest(ctx.e2e), 'moduleDigest': tree_digest(module_dir / 'pom.xml', module_dir / 'src')}


def run_step(ctx, args, st):
    _, snap_hash = solution.preconditions(ctx)
    module_dir = ctx.validation / solution.module_name(ctx)
    if not (module_dir / 'pom.xml').is_file() or not (ctx.validation / 'pom.xml').is_file():
        raise Stop(f'{ctx.rel(module_dir)} does not exist: run solution', code=2)
    if not (ctx.e2e / 'scenarios' / f'{ctx.entry}.json').is_file():
        raise Stop('nothing is imported: run import', code=2)
    if not (ctx.e2e / 'fixtures' / 'manifest.json').is_file():
        raise Stop('the fixtures are not prepared: run fixtures', code=2)
    linted = digests(ctx, module_dir)
    passed, build = solution.er1(ctx, module_dir)
    lint = build.get('lint') or {}
    st['lint'] = {'entry': ctx.entry, 'snapshotHash': snap_hash, 'contentHash': package_hash(ctx.package), **linted,
                  **{k: build.get(k) for k in ('er1', 'tests', 'failures', 'errors', 'skipped', 'log')},
                  'scenarios': lint.get('scenarios'), 'byStatus': lint.get('byStatus')}
    imported = (st.get('import') or {}).get('scenarios')
    warnings = [] if lint.get('scenarios') or not imported else \
        [f'the lint report lists no scenario, {imported} are imported: is the module reading the assets?']
    if not passed:
        raise Stop(f'ER-1 failed: the lint build of {module_dir.name} has {build["failures"]} failure(s), '
                   f'{build["errors"]} error(s), Maven exit {build["exitCode"]}; see {build["log"]}', code=1,
                   module=module_dir.name, build=build, warnings=warnings)
    return 0, {'status': 'passed', 'entry': ctx.entry, 'module': module_dir.name, 'scenarios': lint.get('scenarios'),
               'byStatus': lint.get('byStatus'), 'build': build, 'warnings': warnings}
