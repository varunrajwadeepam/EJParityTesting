"""Step 0 - preflight: build tools, the product, the framework, the replay schema (tools.yaml e2e-db2).

    mu_validate.py preflight <mu> [--entry E] [--e2e-schema NAME]

Hard blocks (exit 1): Maven < 3.9 or missing, the JDK Maven runs on < 21, no mu.yaml `solution` with a
pom.xml, no framework (tools/e2e-framework, or tools.yaml e2e-framework.path) with pom.xml and core/pom.xml,
an e2e-db2 schema not starting with E2E (or equal to the test-db2 / golden-db2 schema), no test-db2/db2
connection, Db2 not reachable while e2e-db2 is missing.
e2e-db2 (decision 3): present -> used as is, tables with rows are a warning (they will be deleted);
missing and E2E_<MU> (or --e2e-schema) absent or without rows -> appended to tools.yaml as a text block
(connection of test-db2, else db2), everything else kept; missing and the derived E2E_<MU> has rows -> nothing
written, exit 2 with tables, counts, a free name E2E_<MU>_<n> and the text of a blocking VQ. A schema named
with --e2e-schema that has rows is the owner's choice: written, its rows a warning (every replay deletes them).
Also reported: answered VQs (apply them this run), open blocking VQs (`blocking`, `blockingQuestions`: the
run stops on them). With --e2e-schema applied, the open replay-schema VQ of the preflight is set to settled.
"""

import json
import re

from vlib import db2, maven, questions as vq
from vlib.common import slash_command, SCRIPTS, Stop, read_text, run, shown_path, which
from vlib.config import load_yaml, schema_name

SECTION = 'e2e-db2'
SCHEMA_VQ_TITLE = 'Replay schema:'


def add_arguments(ap):
    ap.add_argument('--e2e-schema', metavar='NAME', help='the replay schema to write into tools.yaml e2e-db2')


def _major(v):
    if not v:
        return 0
    head = v.split('.')[0]
    if head == '1' and '.' in v:
        head = v.split('.')[1]
    return int(re.sub(r'\D.*', '', head) or 0)


def _ver(v):
    return tuple(int(x) for x in re.findall(r'\d+', v or '')[:2]) or (0,)


def tool_checks(ctx):
    checks, blocks, warnings = {}, [], []
    mv, jv, first = maven.version()
    checks['maven'] = mv or first
    if not mv or _ver(mv) < (3, 9):
        blocks.append(f'Maven 3.9+ needed (found: {mv or first or "none"}): the private repository with a '
                      'read-only ~/.m2 tail needs it')
    checks['jdk'] = jv
    if _major(jv) < 21:
        blocks.append(f'the JDK Maven runs on is {jv or "unknown"}: JDK 21+ needed (set JAVA_HOME)')
    java = which('java')
    if java:
        try:
            _, out = run([java, '-version'], timeout=60)
            m = re.search(r'version "([^"]+)"', out)
            checks['javaOnPath'] = m.group(1) if m else None
            if m and _major(m.group(1)) < 21:
                warnings.append(f'java on PATH is {m.group(1)}; the builds use the JDK of JAVA_HOME ({jv})')
        except Stop:
            checks['javaOnPath'] = None
    sol = ctx.solution
    checks['solution'] = ctx.rel(sol) if sol else None
    if not sol or not (sol / 'pom.xml').is_file():
        blocks.append(f'no product: mu.yaml solution {ctx.rel(sol) if sol else "(not set)"} has no pom.xml '
                      '(run ' + slash_command('mu-implement') + ' first)')
    fw = ctx.framework
    checks['framework'] = ctx.rel(fw)
    if not ((fw / 'pom.xml').is_file() and (fw / 'core' / 'pom.xml').is_file()):
        blocks.append(f'no test framework in {ctx.rel(fw)} (pom.xml, core/pom.xml): place it there or name its '
                      'folder in tools.yaml e2e-framework.path')
    return checks, blocks, warnings


def _scalar(v):
    s = str(v)
    return s if re.fullmatch(r'[A-Za-z0-9_./:@-]+', s) else json.dumps(s)


def section_text(conn_raw, schema, source):
    rows = [('kind', 'local', None),
            ('container', conn_raw['container'], 'the Db2 container the CLP runs in'),
            ('host', conn_raw['host'], 'how the tests on this machine reach it'),
            ('port', conn_raw['port'], None),
            ('database', conn_raw['database'], None),
            ('schema', schema, 'E2E-owned: every table is emptied per fixture pack'),
            ('user', conn_raw['user'], None),
            ('password', conn_raw['password'], None)]
    lines = [f'{SECTION}:'.ljust(42) + f'# mu-validate replay schema; written by its preflight from {source}']
    for k, v, c in rows:
        if v in (None, ''):
            continue
        line = f'  {k}: {_scalar(v)}'
        lines.append(line.ljust(42) + f'# {c}' if c else line)
    return lines


def connection(ctx):
    """(source, raw values for writing, resolved values for querying) of test-db2, else db2."""
    raw_all = ctx.raw_tools()
    db2_raw = raw_all.get('db2') if isinstance(raw_all.get('db2'), dict) else {}
    for source in ('test-db2', 'db2'):
        raw = raw_all.get(source)
        if not isinstance(raw, dict):
            continue
        res = ctx.tool(source) or {}
        db2_res = ctx.tool('db2') or {}

        def pick(d, d2, k, default=None):
            v = d.get(k)
            if v in (None, '') and source != 'db2':
                v = d2.get(k)
            return default if v in (None, '') else v
        w = {'container': pick(raw, db2_raw, 'container'), 'host': raw.get('host') or 'localhost',
             'port': pick(raw, db2_raw, 'port', 50000), 'database': pick(raw, db2_raw, 'database', 'TESTDB'),
             'user': pick(raw, db2_raw, 'user', 'db2inst1'), 'password': pick(raw, db2_raw, 'password', '')}
        q = {'container': pick(res, db2_res, 'container'), 'database': str(pick(res, db2_res, 'database', 'TESTDB')),
             'user': str(pick(res, db2_res, 'user', 'db2inst1')), 'password': str(pick(res, db2_res, 'password', ''))}
        return source, w, q
    return None, None, None


def _other_schemas(ctx):
    out = {}
    for s in ('test-db2', 'golden-db2', 'db2'):
        sec = ctx.raw_tools().get(s)
        if isinstance(sec, dict) and sec.get('schema'):
            out[s] = str(sec['schema']).upper()
    return out


def check_name(ctx, name):
    """A block message for a schema mu-validate may not own, else None."""
    if not db2.IDENT.match(name):
        return f'{name!r} is not a plain Db2 schema name'
    if not name.startswith('E2E'):
        return f'replay schema {name} does not start with E2E (the framework empties every table of it)'
    for s, other in _other_schemas(ctx).items():
        if other == name:
            return f'replay schema {name} is the {s} schema: give e2e-db2 its own schema'
    return None


def append_section(ctx, lines):
    """Append the section as text at the end of tools.yaml; verify every other section is unchanged."""
    raw_bytes = ctx.tools_file.read_bytes()
    text = raw_bytes.decode('utf-8')
    nl = '\r\n' if '\r\n' in text else '\n'
    before = load_yaml(ctx.tools_file)
    block = nl.join(lines) + nl
    sep = '' if text.endswith(('\n', '\r\n')) or not text else nl
    with open(ctx.tools_file, 'ab') as fh:
        fh.write((sep + nl + block).encode('utf-8'))
    after = load_yaml(ctx.tools_file)
    rest_after = {k: v for k, v in after.items() if k != SECTION}
    if rest_after != before or not isinstance(after.get(SECTION), dict) or not read_text(ctx.tools_file).startswith(
            text):
        ctx.tools_file.write_bytes(raw_bytes)
        raise Stop(f'appending {SECTION} would change {ctx.rel(ctx.tools_file)} otherwise: restored, nothing written')


def e2e_db2(ctx, args, mu_cmd):
    """(code, info, blocks, warnings)."""
    raw = ctx.raw_tools()
    info, blocks, warnings = {'section': 'missing'}, [], []
    want = args.e2e_schema.strip().upper() if args.e2e_schema else None
    if isinstance(raw.get(SECTION), dict):
        sec = ctx.tool(SECTION) or {}
        schema = str(sec.get('schema') or '').upper()
        info.update(section='present', schema=schema)
        if want and want != schema:
            blocks.append(f'--e2e-schema {want}: tools.yaml {SECTION} already names {schema} (edit the file to change it)')
            return 1, info, blocks, warnings
        bad = check_name(ctx, schema)
        if bad:
            blocks.append(bad)
            return 1, info, blocks, warnings
        db2_res = ctx.tool('db2') or {}
        conn = {'container': sec.get('container') or db2_res.get('container'),
                'database': str(sec.get('database') or db2_res.get('database') or 'TESTDB'),
                'user': str(sec.get('user') or 'db2inst1'), 'password': str(sec.get('password') or '')}
        info['database'] = conn['database']
        if not conn['container']:
            warnings.append(f'{SECTION} names no container (and db2 none): the tables were not checked')
            info['checked'] = False
            return 0, info, blocks, warnings
        try:
            tabs = db2.tables(conn, schema)
        except Stop as e:
            warnings.append(f'{schema} not checked: {e} (the execute step needs the database: start the parity-tester)')
            info['checked'] = False
            return 0, info, blocks, warnings
        info.update(checked=True, tables=tabs)
        rows = {t: n for t, n in tabs.items() if n}
        if rows:
            warnings.append(f'{schema} holds rows that every replay deletes: '
                            + ', '.join(f'{t} {n}' for t, n in rows.items()))
        return 0, info, blocks, warnings

    source, w, q = connection(ctx)
    if not source:
        blocks.append(f'{ctx.rel(ctx.tools_file)} has neither test-db2 nor db2: no connection for {SECTION}')
        return 1, info, blocks, warnings
    if not q['container']:
        blocks.append(f'{source} (and db2) names no container: the schema cannot be checked')
        return 1, info, blocks, warnings
    base = schema_name(ctx.name)
    name = want or base
    info.update(schema=name, source=source, database=q['database'])
    bad = check_name(ctx, name)
    if bad:
        blocks.append(bad)
        return 1, info, blocks, warnings
    try:
        tabs = db2.tables(q, name)
    except Stop as e:
        blocks.append(f'{SECTION} missing and {name} cannot be checked: {e} (start the parity-tester)')
        return 1, info, blocks, warnings
    info.update(checked=True, tables=tabs)
    rows = {t: n for t, n in tabs.items() if n}
    if rows and want:                     # named explicitly: the owner's choice, its rows are deleted per replay
        counts = ', '.join(f'{t} {c}' for t, c in rows.items())
        info.update(rowsAccepted=rows)
        warnings.append(f'{name} named with --e2e-schema holds rows that every replay deletes: {counts}')
    elif rows:
        existing = set(db2.schemas(q, f'{base}%'))
        n = 1
        while f'{base}_{n}' in existing or f'{base}_{n}' == name:
            n += 1
        free = f'{base}_{n}'
        counts = ', '.join(f'{t} {c}' for t, c in rows.items())
        info.update(conflict=True, rows=rows, free=free)
        question = {
            'title': f'{SCHEMA_VQ_TITLE} {name} already holds rows',
            'step': 'preflight', 'blocking': 'yes',
            'question': (f'tools.yaml has no {SECTION} section and schema {name} in {q["database"]} '
                         f'({q["container"]}) holds rows ({counts}). mu-validate empties every table of its replay '
                         f'schema per fixture pack. Which schema should the replay use: the free {free}, another '
                         f'E2E name, or {name} with its rows deleted? Write the schema name on the Answer line, '
                         f'then say "resume".'),
            'decision': f'nothing written; the run stops until a schema is named (proposed: {free})',
            'affects': f'tools.yaml {SECTION}; every replay run'}
        return 2, info, [], warnings + [f'{name} holds rows: {counts}'], {
            'vq': question, 'free': free,
            'next': f'python -B {shown_path(SCRIPTS / "mu_validate.py")} preflight {mu_cmd} '
                    f'--e2e-schema <answer, e.g. {free}>'}
    lines = section_text(w, name, source)
    append_section(ctx, lines)
    info.update(section='written', written=lines)
    if tabs:
        info['note'] = f'{name} exists with {len(tabs)} empty table(s)'
    return 0, info, blocks, warnings


def settle_schema_question(ctx, args, info):
    """--e2e-schema applied (the section written with it, or already naming it): the open replay-schema VQ(s) of the
    preflight -> Status settled (the one status edit mu-validate makes in its questions file)."""
    want = args.e2e_schema.strip().upper() if args.e2e_schema else None
    if not want or info.get('schema') != want or info.get('section') not in ('written', 'present'):
        return []
    done = []
    for e in vq.parse(ctx.questions):
        if e['prefix'] == 'VQ' and e['status'] != 'settled' and e['step'] == 'preflight' \
                and e['title'].startswith(SCHEMA_VQ_TITLE):
            vq.set_status(ctx.questions, e['id'], 'settled')
            done.append(e['id'])
    return done


def run_step(ctx, args, st):
    checks, blocks, warnings = tool_checks(ctx)
    extra = {}
    if blocks:
        code, info = 1, {'section': 'not checked'}
    else:
        r = e2e_db2(ctx, args, ctx.mu_arg)
        code, info, b2, w2 = r[:4]
        extra = r[4] if len(r) > 4 else {}
        blocks += b2
        warnings += w2
    settled = settle_schema_question(ctx, args, info) if not blocks and code == 0 else []
    entries = vq.parse(ctx.questions)
    st['preflight'] = {'tools': checks, 'e2eDb2': {k: v for k, v in info.items() if k != 'written'}}
    doc = {'entry': ctx.entry, 'tools': checks, 'e2eDb2': info, 'blocks': blocks, 'warnings': warnings,
           'answers': [{k: e[k] for k in ('id', 'title', 'status', 'blocking', 'affects', 'answer')}
                       for e in vq.answered(entries)],
           'blocking': [e['id'] for e in vq.open_blocking(entries)],
           'blockingQuestions': [{k: e[k] for k in ('id', 'title', 'step')} for e in vq.open_blocking(entries)],
           'settled': settled, **extra}
    if blocks:
        return 1, {'status': 'blocked', **doc}
    if code == 2:
        return 2, {'status': 'schema-conflict', **doc}
    return 0, {'status': 'ready', **doc}
