"""Step 10 - report: validation/validation-report.md from templates/report.md, and the next move.

    mu_validate.py report <mu> [--entry E]

What it shows: the package seen (version, seal, readiness), the snapshot and where its sources came from, the
framework fingerprint, the e2e-db2 schema, the record gate, the snapshot and package the last run replayed
(a warning when they are not the current ones), every run (counts per status, PASSED split into as the legacy and
as decided (accepted deviation, marked ◆), strict and contract columns, repeatable, identical to the previous
run), the decided answers of the last run (passed and failed, by source; each with its decided and recorded
status), the failure classes of the last run (from failures.md when it
is of that run, else the pre-classes of analysis.json, marked so; a confirmed failure without suspect rules takes
analyse's, marked [analyse]), the questions and the next move: /mu-build-tests for BINDING or PACKAGE (every field,
with counts), the implementer for SOLUTION (every suspect rule, with its failures), an environment fix (every
ENVIRONMENT item, with its reason), answers, or done.
Reads only; writes the report. Exit 0.
"""

import copy
import re
from collections import Counter

from e2elib import package
from steps import readiness, snapshot as snapshot_step
from vlib import questions as vq
from vlib.common import (slash_command, SKILL, Stop, by_scenario, iso_now, package_hash, read_json, read_text,
                         write_text)

CLASSES = ('BINDING', 'SOLUTION', 'ENVIRONMENT', 'PACKAGE', 'DECISION', 'UNKNOWN')
STATUSES = ('PASSED', 'FAILED', 'BLOCKED', 'NOT_APPLICABLE', 'SKIPPED')
DECIDED = '◆'


def add_arguments(ap):
    pass


def runs_of(ctx):
    found = []
    for path in sorted(ctx.runs.glob('*/summary.json')) if ctx.runs.is_dir() else []:
        try:
            doc = read_json(path, 'run summary')
        except Stop:
            continue
        found.append((str(doc.get('finishedAt') or ''), path.parent.name, doc))
    return [(rid, doc) for _, rid, doc in sorted(found, key=lambda f: (f[0], f[1]))]


def column(c):
    return ' · '.join(f'{k} {v}' for k, v in sorted((c or {}).items())) or '-'


def yes_no(v):
    return '-' if v is None else 'yes' if v else 'no'


def run_row(rid, doc, split=None):
    counts = doc.get('counts') or {}
    cols = doc.get('columns') or {}
    sel = f" ({doc['selection'].get('tags')})" if doc.get('selection') else ''
    cells = [str(counts.get(s, 0)) for s in STATUSES]
    if split and split['passed']:
        cells[0] += (f" ({counts.get('PASSED', 0) - split['passed']} as the legacy · {DECIDED} {split['passed']} "
                     'as decided)')
    return (f"| {rid}{sel} | {doc.get('finishedAt') or '-'} | {doc.get('runs') or '-'} | "
            + ' | '.join(cells)
            + f" | {column(cols.get('strict'))} | {column(cols.get('contract'))} | {yes_no(doc.get('repeatable'))} | "
              f"{yes_no(doc.get('identicalToPrevious'))} |")


def decided_cases(ctx):
    """({case id: {source, status, recordedStatus, tables, name}} of the package's decided answers,
    {case id: {source, reason}} of its pending ones)."""
    try:
        doc = read_json(ctx.package, 'package') if ctx.package.is_file() else {}
    except Stop:
        return {}, {}
    cases = [c for c in doc.get('cases') or [] if isinstance(c, dict) and c.get('id')]
    return ({c['id']: {**{k: d.get(k) for k in ('source', 'status', 'recordedStatus', 'tables')}, 'name': c.get('name')}
             for c in cases for d in [package.decided_of(c)] if d},
            {c['id']: p for c in cases for p in [package.pending_of(c)] if p})


def run_statuses(ctx, rid, doc):
    """{scenario id: status} of a run's last framework report, else None."""
    path = ctx.runs / rid / f"run-{doc.get('runs') or 1}" / 'e2e-replay.json'
    if not path.is_file():
        return None
    try:
        report = read_json(path, 'framework report')
    except Stop:
        return None
    return {sid: status for sid, (status, _) in by_scenario(report.get('scenarios') or []).items()}


def decided_summary(statuses, decided):
    """The decided answers of a run: {scenarios, passed, failed, passedBySource, failedBySource, rows}."""
    rows = [{**d, 'id': sid, 'result': statuses[sid]} for sid, d in sorted(decided.items()) if sid in statuses]

    def by_source(status):
        return dict(Counter(str(r['source']) for r in rows if r['result'] == status).most_common())

    return {'scenarios': len(rows), 'passed': sum(1 for r in rows if r['result'] == 'PASSED'),
            'failed': sum(1 for r in rows if r['result'] == 'FAILED'),
            'passedBySource': by_source('PASSED'), 'failedBySource': by_source('FAILED'), 'rows': rows}


def pending_lines(pending):
    return [f"- pending decision {p['source']}: {p['reason'] or '-'} ({sid}: compared with the recording)"
            for sid, p in sorted(pending.items())]


def decided_section(run_id, counts, split, pending=None):
    if not split or not split['scenarios']:
        return '\n'.join([f'## Decided answers of run {run_id}', '', 'none decided.', ''] + pending_lines(pending)) \
            if pending else ''
    passed = counts.get('PASSED', 0)

    def sources(by):
        return ', '.join(f'{k} x{v}' for k, v in by.items())

    head = (f"PASSED {passed}: {passed - split['passed']} as the legacy · {DECIDED} {split['passed']} as decided "
            '(accepted deviation: the expected answer is the decided one, not the recording)'
            + (f" - {sources(split['passedBySource'])}" if split['passedBySource'] else '') + '.'
            + (f" {DECIDED} FAILED {split['failed']} - {sources(split['failedBySource'])}." if split['failed'] else ''))
    lines = [f'## Decided answers of run {run_id}', '', head, '']
    for r in split['rows']:
        changed = r.get('recordedStatus') is not None and r.get('recordedStatus') != r.get('status')
        lines.append(f"- {DECIDED} {r['id']} {r.get('name') or '-'} · {r['result']} · decided "
                     f"{r.get('status')} by {r.get('source')} · recorded {r.get('recordedStatus', '?')}"
                     + (' (status changed)' if changed else '')
                     + (f" · tables {r['tables']}" if r.get('tables') else ''))
    return '\n'.join(lines + pending_lines(pending or {}))


def parse_failures(path, run_id):
    """[{id, class, confidence, suspects, fields}] of failures.md when it is of run `run_id`, else None."""
    if not path.is_file():
        return None
    text = read_text(path)
    if not re.search(r'^Run\s+' + re.escape(run_id) + r'\b', text, re.M):
        return None
    out, cur = [], None
    for line in text.splitlines():
        m = re.match(r'^##\s+(\S+)\s+-', line)
        if m:
            cur = {'id': m.group(1), 'class': None, 'confidence': None, 'suspects': '-', 'fields': '-'}
            out.append(cur)
            continue
        if cur is None:
            continue
        m = re.match(r'^Class:\s*\**([A-Z]+)\**(?:\s*·\s*Confidence:\s*(\w+))?', line)
        if m:
            cur['class'], cur['confidence'] = m.group(1), m.group(2)
        m = re.match(r'^Suspect rules:\s*(.*)$', line)
        if m:
            cur['suspects'] = m.group(1).strip()
        m = re.match(r'^Fields:\s*(.*)$', line)
        if m:
            cur['fields'] = m.group(1).strip()
    return [f for f in out if f['class']]


def from_analysis(doc):
    out = []
    for f in doc.get('failures') or []:
        pc = f.get('preClass') or {}
        out.append({'id': f['scenarioId'], 'class': pc.get('class'), 'confidence': pc.get('confidence'),
                    'suspects': ', '.join(f"{r['id']} (`{r.get('targetHome')}`)" for r in pc.get('suspectRules') or [])
                    or '-', 'fields': ', '.join(pc.get('fields') or []) or '-'})
    return out


def ids_text(ids, shown=12):
    ids = list(ids)
    return ', '.join(ids[:shown]) + (f' and {len(ids) - shown} more' if len(ids) > shown else '')


def rule_refs(text):
    """[(rule id, target home)] of a `Suspect rules:` value (`R13 (`WipService.create`), R2`)."""
    return [(m.group(1), m.group(2)) for m in re.finditer(r'\b(R\d+[a-z]?)\b(?:\s*\(`([^`]*)`\))?', text or '')]


def suspect_counts(failures):
    """[((rule, home), [scenario ids])] of every suspect rule of the failures, most failures first."""
    by = {}
    for f in failures:
        for rid, home in dict.fromkeys(rule_refs(f['suspects'])):
            key = next((k for k in by if k[0] == rid), (rid, home or None))
            by.setdefault(key, []).append(f['id'])
    return sorted(by.items(), key=lambda kv: (-len(kv[1]), int(re.sub(r'\D', '', kv[0][0]) or 0)))


def run_of(ctx, last):
    """(line naming the snapshot and package the run replayed, warnings when they are not the current ones)."""
    if not last:
        return '', []
    snap = (last.get('snapshot') or {}).get('hash') or (last.get('snapshot') or {}).get('revision')
    pkg = (last.get('package') or {}).get('contentHash')
    try:
        current_snap = snapshot_step.status(ctx)[1]['hash']
    except Stop as e:
        current_snap, why = None, str(e)
    current_pkg = package_hash(ctx.package)
    warnings = []
    if current_snap is None:
        warnings.append(f'the current product snapshot is unknown ({why}): run {last.get("runId")} may be of another')
    elif not snap or not current_snap.startswith(str(snap)):
        warnings.append(f'run {last.get("runId")} replayed snapshot {str(snap or "unrecorded")[:16]}, the product is now '
                        f'{current_snap[:16]}: its results are not of the current product (snapshot, solution, '
                        'execute again)')
    if not pkg or pkg != current_pkg:
        warnings.append(f'run {last.get("runId")} replayed package {str(pkg or "unrecorded")[:12]}, the package is now '
                        f'{str(current_pkg or "-")[:12]}: its results are not of the current package (import, '
                        'fixtures, execute again)')
    line = (f'Replayed: snapshot `{str(snap or "-")[:16]}` · package `{str(pkg or "-")[:12]}` - '
            + ('**not current**' if warnings else 'current'))
    return line, warnings


def run_step(ctx, args, st):
    probe = copy.deepcopy(st)
    try:
        rcode, rd = readiness.run_step(ctx, args, probe)
    except Stop as e:
        rcode, rd = 1, {'status': 'failed', 'error': str(e), 'fix': []}
    runs = runs_of(ctx)
    last_id, last = (runs[-1] if runs else (None, None))
    decided, pending = decided_cases(ctx)
    splits = {r: decided_summary(s, decided) for r, d in runs
              for s in [run_statuses(ctx, r, d) if decided else None] if s is not None}
    split = splits.get(last_id)
    analysis_file = ctx.tmp / 'analysis.json'
    analysis = read_json(analysis_file, 'analysis') if analysis_file.is_file() else None
    if analysis and analysis.get('runId') != last_id:
        analysis = None
    failures = parse_failures(ctx.failures, last_id) if last_id else None
    confirmed = failures is not None
    if failures is None and analysis:
        failures = from_analysis(analysis)
    elif failures and analysis:                 # a confirmed failure without suspect rules: analyse's, marked
        pre = {f['id']: f for f in from_analysis(analysis)}
        for f in failures:
            p = pre.get(f['id'])
            if f['suspects'] in ('-', '') and p and p['class'] == f['class'] and p['suspects'] != '-':
                f['suspects'] = p['suspects'] + ' [analyse]'
    apart = (analysis or {}).get('blocked', []) + (analysis or {}).get('skipped', [])
    counts = Counter(f['class'] for f in failures or [])
    counts.update(b['class'] for b in apart)
    entries = vq.parse(ctx.questions)
    qs = vq.summary(entries)
    gate = st.get('gate') or {}
    gate_text = (f"{gate['open']} open" if gate.get('open') else
                 f"{gate['settled']} settled by {gate.get('by')}" if gate.get('settled') else 'not prepared')
    sec = ctx.tool('e2e-db2') or {}
    schema = str(sec.get('schema') or ((st.get('preflight') or {}).get('e2eDb2') or {}).get('schema') or '-')
    snap = st.get('snapshot') or {}
    solution = st.get('solutionOverride') or 'mu.yaml solution'
    run_line, run_warnings = run_of(ctx, last)
    warnings = run_warnings + list((last or {}).get('warnings') or [])
    rows = ((st.get('preflight') or {}).get('e2eDb2') or {}).get('tables') or {}
    if any(rows.values()):
        warnings.append(f'e2e-db2 {schema} holds rows the replay deletes: '
                        + ', '.join(f'{t} {n}' for t, n in rows.items() if n))
    if failures is not None and not confirmed:
        warnings.append('classes are the pre-classes of analyse: failures.md of this run is not written')
    warnings += rd.get('warnings') or []

    # next move
    do_first, nxt = [], []
    if rcode != 0:
        do_first = [f"- {f['reason']}: `{f['command']}`" for f in rd.get('fix') or []] or \
            [f"- readiness: {rd.get('error') or rd.get('status')}"]
        nxt.append('Do this first (the package is not ready), then run mu-validate again.')
    blocking = [e for e in vq.open_blocking(entries) if e['prefix'] == 'VQ']
    if blocking:
        nxt.append(f"Answer {', '.join(e['id'] for e in blocking)} in `{ctx.rel(ctx.questions)}`.")
    if gate.get('open'):
        nxt.append(f"{gate['open']} waits for a named person's answer in `{ctx.rel(ctx.questions)}`; then say "
                   '"resume" (the agent applies it and runs the replay).')
    elif not runs:
        nxt.append('Run `execute`.')
    elif failures is None:
        nxt.append('Run `analyse` on the last run.')
    else:
        cmd = f"{slash_command('mu-build-tests')} {ctx.mu_arg} entry={ctx.entry}"
        by = {c: [f for f in failures if f['class'] == c] for c in CLASSES}
        pkg = by['BINDING'] + by['PACKAGE'] + [b for b in apart if b['class'] == 'PACKAGE']
        if pkg:
            ids = sorted({f.get('id') or f.get('scenarioId') for f in pkg})
            fields = Counter(x for f in by['BINDING'] for x in f['fields'].split(', ') if x and x != '-')
            nxt.append(f'`{cmd}` - BINDING/PACKAGE {len(ids)}: {ids_text(ids)}'
                       + (' (fields: ' + ', '.join(f'{k} x{v}' for k, v in sorted(fields.items(),
                                                                                key=lambda kv: (-kv[1], kv[0])))
                          + ')' if fields else ''))
        if by['SOLUTION']:
            rules = suspect_counts(by['SOLUTION'])
            none = [f['id'] for f in by['SOLUTION'] if not rule_refs(f['suspects'])]
            nxt.append(f"Implementer (`{slash_command('mu-implement')} {ctx.mu_arg}`) - SOLUTION {len(by['SOLUTION'])}: "
                       + ('; '.join(f"{rid}{f' (`{home}`)' if home else ''} x{len(ids)}: {ids_text(ids)}"
                                    for (rid, home), ids in rules)
                          if rules else ids_text([f['id'] for f in by['SOLUTION']]))
                       + (f"; no suspect rule: {ids_text(none)}" if rules and none else ''))
        env = by['ENVIRONMENT'] + [b for b in apart if b['class'] == 'ENVIRONMENT']
        if env:
            nxt.append(f"Fix the environment (e2e-db2 `{schema}`, the database, the product's configuration), then "
                       f"`execute` - ENVIRONMENT {len(env)}: "
                       + '; '.join(f"{f.get('id') or f.get('scenarioId')}"
                                   + (f" ({f.get('status')}, {str(f.get('reason'))[:160]})" if f.get('reason') else '')
                                   for f in env))
        if by['UNKNOWN']:
            nxt.append(f"Answer the questions on {', '.join(f['id'] for f in by['UNKNOWN'][:8])}.")
        if by['DECISION'] and len(nxt) == 0:
            nxt.append('Nothing to fix: the differences are the decided answers.')
        if not failures and not apart:
            nxt.append('Done: every compared scenario passes'
                       + (f" ({DECIDED} {split['passed']} as decided)" if split and split['passed'] else '') + '.')
    classes = ('| class | count |\n|---|---|\n' + '\n'.join(f'| {c} | {counts[c]} |' for c in CLASSES if counts[c])
               if counts else ('none' if failures is not None else 'not analysed'))
    if failures:
        classes += ('\n\n' + ('Confirmed in' if confirmed else 'Pre-classes; not yet confirmed in')
                    + f' `{ctx.rel(ctx.failures)}`:\n\n'
                    + '\n'.join(f"- {DECIDED + ' ' if f['id'] in decided else ''}{f['id']} {f['class']} "
                                f"({f['confidence'] or '-'})"
                                + (f" · rules {f['suspects']}" if f['suspects'] != '-' else '')
                                + (f" · fields {f['fields']}" if f['fields'] != '-' else '') for f in failures[:30]))
    values = {'mu': ctx.name, 'entry': ctx.entry, 'date': iso_now()[:10], 'version': rd.get('version') or '-',
              'contentHash': str(rd.get('contentHash') or '-')[:12], 'packageState': rd.get('status') or '-',
              'snapshot': snap.get('revision') or '-', 'solution': solution,
              'framework': str((st.get('framework') or {}).get('fingerprint') or '-')[:16], 'schema': schema,
              'gate': gate_text, 'doFirst': ('## Do this first\n\n' + '\n'.join(do_first)) if do_first else '',
              'runs': '\n'.join(run_row(r, d, splits.get(r)) for r, d in runs) or '| - | - | - | - | - | - | - | - | - | - | - | - |',
              'lastRun': last_id or '-', 'runOf': run_line, 'classes': classes,
              'decided': decided_section(last_id, (last or {}).get('counts') or {}, split, pending),
              'warnings': '\n'.join(f'- {w}' for w in warnings) or '- none',
              'qOpen': len(qs['open']), 'qBlocking': len(qs['blocking']), 'qAnswered': len(qs['answered']),
              'qSettled': len(qs['settled']), 'next': '\n'.join(f'- {n}' for n in nxt) or '- none'}
    tpl = read_text(SKILL / 'templates' / 'report.md')
    text = re.sub(r'\{\{(\w+)\}\}', lambda m: str(values.get(m.group(1), m.group(0))), tpl)
    text = re.sub(r'\n{3,}', '\n\n', text)
    write_text(ctx.report, text)
    return 0, {'status': 'written', 'entry': ctx.entry, 'report': ctx.rel(ctx.report), 'package': rd.get('status'),
               'gate': gate_text, 'runs': len(runs), 'lastRun': last_id,
               'lastRunSnapshot': ((last or {}).get('snapshot') or {}).get('revision'),
               'lastRunPackage': ((last or {}).get('package') or {}).get('contentHash'),
               'lastRunCurrent': not run_warnings if last else None, 'warnings': warnings,
               'lastCounts': (last or {}).get('counts'),
               'lastDecided': {k: v for k, v in split.items() if k != 'rows'} if split else None,
               'pendingDecisions': pending, 'classes': dict(counts), 'confirmed': confirmed,
               'questions': {k: qs[k] for k in ('open', 'blocking')}, 'next': nxt}
