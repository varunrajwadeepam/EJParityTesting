"""Step 2 - framework: install tools/e2e-framework into the private repository validation/target/m2.

    mu_validate.py framework <mu> [--force] [--with-tests]

Reused when every module and archetype of the framework's version is in the repository and the source
fingerprint (sha256 over path + sha256 of every framework file, target/ left out) equals the one the last
install left beside the framework POM (e2e-framework-source.sha256). Otherwise the framework is copied to
validation/target/framework/<fingerprint>/ (nothing written under tools/) and built there with
`mvn install -DskipTests -DskipITs -Dinvoker.skip=true` into validation/target/m2, ~/.m2 a read-only tail.
"""

import hashlib
import os
import re
import shutil
import xml.etree.ElementTree as ET
from pathlib import Path

from vlib import maven
from vlib.common import Stop, file_sha, iso_now, last_lines, long_path, write_text

ARTIFACTS = [
    ('com/insurance/e2e', 'modernization-e2e-framework', 'pom'),
    ('com/insurance/e2e', 'modernization-e2e-bom', 'pom'),
    ('com/insurance/e2e', 'modernization-e2e-core', 'jar'),
    ('com/insurance/e2e', 'modernization-e2e-legacy-paritytester', 'jar'),
    ('com/insurance/e2e', 'modernization-e2e-target-spring', 'jar'),
    ('com/insurance/e2e', 'modernization-e2e-target-http', 'jar'),
    ('com/insurance/e2e', 'modernization-e2e-fixtures-jdbc', 'jar'),
    ('com/insurance/e2e', 'modernization-e2e-cucumber', 'jar'),
    ('com/insurance/archetypes', 'modernization-e2e-basement-archetype', 'jar'),
    ('com/insurance/archetypes', 'modernization-mu-e2e-archetype', 'jar'),
]
SKIP = {'target', '.git', '.idea', '.vscode'}


def add_arguments(ap):
    ap.add_argument('--force', action='store_true', help='reinstall even when the fingerprint is unchanged')
    ap.add_argument('--with-tests', action='store_true', help="run the framework's own tests during the install")


def framework_version(fw):
    try:
        root = ET.parse(fw / 'pom.xml').getroot()
    except (ET.ParseError, OSError) as e:
        raise Stop(f'{fw / "pom.xml"} not readable: {e}') from None
    ns = re.match(r'\{.*\}', root.tag)
    ns = ns.group(0) if ns else ''
    v = root.find(f'{ns}version')
    if v is None or not (v.text or '').strip():
        raise Stop(f'{fw / "pom.xml"} declares no version')
    return v.text.strip()


def fingerprint(fw):
    h = hashlib.sha256()
    for p in sorted(p for p in fw.rglob('*') if p.is_file() and not SKIP & set(p.relative_to(fw).parts)):
        h.update(f'{p.relative_to(fw).as_posix()}\n{file_sha(p)}\n'.encode('utf-8'))
    return h.hexdigest()


def missing(repo, version):
    return [f'{g.replace("/", ".")}:{a}:{version}' for g, a, ext in ARTIFACTS
            if not (repo / g / a / version / f'{a}-{version}.{ext}').is_file()]


def marker(repo, version):
    g, a, _ = ARTIFACTS[0]
    return repo / g / a / version / 'e2e-framework-source.sha256'


def copy_sources(fw, dest):
    """The framework copied (target/ left out) to `dest`: the build never writes into tools/."""
    if dest.exists():
        shutil.rmtree(long_path(dest))
    base, out = long_path(fw), long_path(dest)
    for root, dirs, files in os.walk(base):
        dirs[:] = sorted(d for d in dirs if d not in SKIP)
        for name in files:
            src = Path(root) / name
            dst = out / src.relative_to(base)
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
    return dest


def status_of(ctx):
    fw = ctx.framework
    version = framework_version(fw)
    fp = fingerprint(fw)
    mk = marker(ctx.m2, version)
    installed = mk.read_text(encoding='utf-8').strip() if mk.is_file() else None
    miss = missing(ctx.m2, version)
    return version, fp, installed, miss


def run_step(ctx, args, st):
    fw = ctx.framework
    if not (fw / 'pom.xml').is_file():
        raise Stop(f'no framework in {ctx.rel(fw)} (pom.xml): run preflight')
    version, fp, installed, miss = status_of(ctx)
    base = {'version': version, 'framework': ctx.rel(fw), 'repository': ctx.rel(ctx.m2), 'fingerprint': fp[:16]}
    if not miss and installed == fp and not args.force:
        st['framework'] = {**(st.get('framework') or {}), 'version': version, 'fingerprint': fp,
                           'repository': ctx.rel(ctx.m2)}
        return 0, {'status': 'reused', **base}
    log = ctx.tmp / 'framework-install.log'
    build = copy_sources(fw, ctx.target / 'framework' / fp[:16])
    arguments = ['-f', str(build / 'pom.xml'), 'install']
    if not args.with_tests:
        arguments += ['-DskipTests', '-DskipITs', '-Dinvoker.skip=true']
    code, out = maven.mvn(arguments, cwd=build, log=log, head=ctx.m2, tail=ctx.home_m2)
    if code != 0:
        raise Stop(f'framework install failed (exit {code}); see {ctx.rel(log)}', log=ctx.rel(log),
                   tail=last_lines(out))
    still = missing(ctx.m2, version)
    if still:
        raise Stop('the framework build succeeded but artifacts are missing from the repository', missing=still)
    write_text(marker(ctx.m2, version), fp + '\n')
    at = iso_now()
    st['framework'] = {'version': version, 'fingerprint': fp, 'repository': ctx.rel(ctx.m2), 'installedAt': at}
    return 0, {'status': 'installed', **base, 'previouslyMissing': miss,
               'replacedStale': bool(not miss and installed != fp), 'log': ctx.rel(log)}
