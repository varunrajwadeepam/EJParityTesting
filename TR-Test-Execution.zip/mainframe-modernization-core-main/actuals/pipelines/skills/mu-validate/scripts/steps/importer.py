"""Step 5 - import: the entry's test package -> the framework assets in mu/<MU>/validation/e2e/.

    mu_validate.py import <mu> [--entry E]

Port of e2e_v1 main `e2e_package import` (e2elib, BA parts no-ops). The readiness check runs first and must
pass (exit 2 with its fix list otherwise); the package is then checked against the input contract, the seal
(sorted-keys canonical JSON) and the integrity check - a refusal writes nothing. Writes, under the asset folder:

  scenarios/<E>.json           register 1.1: one scenario per case; tags hypothesis / decided / rule: / origin: /
                               para: / status, `ruleIds`, clockSensitive (feature tag @clock-sensitive)
  golden/<E>/<id>.json         one sealed golden master per golden case, RECORDED; one whose content or oracle is
                               unchanged is kept with its lifecycle; a changed or removed one is archived STALE under
                               golden/<E>/.superseded/
  view-mappings/<E>--*.json    one per answer shape (with `$empty` and the table groups when the case checks tables,
                               `--no-tables` otherwise); <E>.json for the cases that do not run
  profiles.json                the contract profile = the package's comparisonRules (decision 4 A)
  rules/<E>.json, features/<E>.feature, callers.json (only when a call is made as a user)

Acceptance (validation-state.json `acceptance`: scenarioId -> {oracleKey, by, at, gate[, state DISPUTED, reason]},
written by the gate step) is re-applied to every RECORDED golden master whose oracle key is the decided one
(ACCEPTED, or DISPUTED); the others stay RECORDED (the record gate asks for them).
A second import of an unchanged package changes nothing (`status: unchanged`). `warnings`: rule, comparison,
decided, schema and recorded-on findings, the package fields not carried.
"""

import copy
from collections import Counter
from pathlib import Path

from e2elib import canonical, common as ec, feature, fingerprint, package as pkg, schemacheck, update
from e2elib.common import E2eError
from steps import readiness
from vlib.common import Stop, iso_now
from vlib.e2econfig import e2e_config, identity as caller_identity

SCRIPT = 'mu-validate import'
IMPORT_FORMAT = 1
SUPERSEDED = '.superseded'
DROPPED_CASE_FIELDS = {'design': 'the basic case\'s tests.md block (people read design/tests.md)'}
IDENTITY_BLOCK = ('needs the caller identity: the call is made as the user {user} (request.principal) and no caller '
                  'identity is configured (pipelines_v2 has none yet) - never sent anonymously')


def add_arguments(ap):
    pass


# ---------------------------------------------------------------- package facts

def fixture_hashes(path, doc):
    names = sorted({c['fixture'] for c in doc.get('cases', []) if isinstance(c, dict) and c.get('fixture')})
    return {n: pkg.file_hash(path.parent / n) for n in names if (path.parent / n).is_file()}


def identity(ctx, path, doc):
    version = pkg.package_version(doc)
    block = pkg.package_block(doc)
    md = pkg.companion_md(path)
    return {'package': ctx.rel(path), 'folder': path.parent.name, 'version': version,
            'label': pkg.version_label(version), 'packageFormat': block.get('format') if block else 1,
            'contentHash': block.get('contentHash'), 'packageHash': pkg.file_hash(path),
            'markdown': ctx.rel(md) if md else None, 'markdownHash': pkg.file_hash(md) if md else None,
            'baAlignmentHash': None, 'fixtureHashes': fixture_hashes(path, doc)}


def dropped_fields(doc):
    out = []
    for name, what in DROPPED_CASE_FIELDS.items():
        n = sum(1 for c in doc.get('cases', []) if isinstance(c, dict) and c.get(name))
        if n:
            out.append(f'case field `{name}` not carried into the assets ({n} cases): {what}')
    n = sum(1 for c in doc.get('cases', []) if isinstance(c, dict) and (pkg.decided_of(c) or {}).get('set'))
    if n:
        out.append(f'decidedAnswer.set not carried ({n} cases): the framework register has no place for it')
    return out


def check(ctx, path, doc, config):
    problems = pkg.contract_problems(doc, path.parent)
    problems += pkg.seal_problems(path, doc) if not problems else []
    integrity, checked = pkg.integrity(doc) if not problems else ([], None)
    rules = pkg.rules_of(doc) if not problems else []
    recorded_on = fingerprint.check(doc, path.parent, *fingerprint.inputs(ctx.workspace, config, doc['unit'], doc)) \
        if not problems else []
    schema = schemacheck.check(doc)
    cases = [c for c in doc.get('cases', []) if isinstance(c, dict)]
    warnings = (schemacheck.warning_lines(schema) + pkg.rule_warnings(doc, rules) + pkg.comparison_rule_warnings(doc)
                + (pkg.set_compare_warnings(doc) if not problems else [])
                + (pkg.decided_warnings(doc) if not problems else [])
                + [f'file not used by the package: {n}' for n in pkg.unused_files(path, doc)]
                + [f'fingerprint {r["fingerprint"]}: the recordings ran on another {label} than '
                   f'{r[key]["source"]}' for r in recorded_on for key, label in (('ddl', 'DDL'), ('fixture', 'fixture'))
                   if r.get(key, {}).get('status') == 'differs']
                + dropped_fields(doc))
    return {'unit': doc.get('unit'), 'cases': len(cases), 'byStatus': dict(Counter(c.get('status') for c in cases)),
            'clockSensitive': sum(1 for c in cases if c.get('clockSensitive')),
            'comparisonRules': pkg.comparison_rule_ids(doc), 'rules': len(rules),
            'recording': pkg.recording_summary(doc) if not problems else None,
            'recordedOn': [{k: (v.get('status', v) if isinstance(v, dict) else v) for k, v in r.items()}
                           for r in recorded_on],
            'coverage': pkg.coverage_summary(doc) if not problems else None,
            'contractProblems': problems, 'integrityProblems': integrity, 'integrityChecked': checked,
            'warnings': list(dict.fromkeys(warnings))}


# ---------------------------------------------------------------- derivation

def block_for_identity(entry):
    principal = (entry.get('http') or {}).get('principal')
    if entry.get('status') != 'runnable' or not principal:
        return
    entry['status'] = 'blocked'
    entry['statusReason'] = IDENTITY_BLOCK.format(user=principal)
    entry['blockedBy'] = 'identity'
    entry['tags'] = list(entry.get('tags') or []) + ['blocked']


def _strings(v):
    return [str(x) for x in v if str(x).strip()] if isinstance(v, list) else []


def derive_unit(ctx, path, doc, config):
    package_rel = ctx.rel(path)
    tables = pkg.checks_tables(doc)
    rules = pkg.rules_of(doc)
    rule_problems = pkg.rule_warnings(doc, rules) + ([] if rules else ['the package states no behaviour rules'])
    critical = {r['id'] for r in rules if r.get('critical')}
    entries = []
    for case in doc['cases']:
        rule_ids = list(dict.fromkeys(_strings(case.get('ruleIds')) + feature.rules_of(case['id'], rules)))
        origin = case.get('origin') if isinstance(case.get('origin'), str) else None
        tags = feature.register_tags(case, rule_ids, pkg.REGISTER_STATUS[case['status']],
                                     critical=bool(critical.intersection(rule_ids)),
                                     paragraphs=_strings(case.get('paragraphs')), origin=origin)
        entries.append(pkg.scenario(case, doc['unit'], {'package': package_rel}, tags, tables=tables))
    if not caller_identity(config):
        for entry in entries:
            block_for_identity(entry)
    return entries, rules, rule_problems, package_rel


def provenance_of(case, unit, doc, fixture_bytes):
    return pkg.provenance(case, doc, pkg.pack_hash([(pkg.fixture_rel_file(unit, case['fixture']), fixture_bytes)]))


def write(path, value):
    return ec.write_text_if_changed(path, canonical.dumps_pretty(value))


def archive_stale(directory, master, reason, at):
    if master.get('state') != 'STALE':
        master = dict(master)
        master['history'] = list(master.get('history') or []) + [
            {'from': master.get('state'), 'to': 'STALE', 'at': at, 'by': SCRIPT, 'reason': reason}]
        master['state'] = 'STALE'
    name = f"{master.get('scenarioId')}.{str(master.get('contentHash', '0' * 12))[:12]}.json"
    write(directory / SUPERSEDED / name, master)
    return name


def golden_of(case, unit, package_rel, doc, files, now, supersedes):
    if case['fixture'] not in files:
        files[case['fixture']] = (Path(doc['__folder__']) / case['fixture']).read_bytes()
    return pkg.golden_master(case, unit, {'kind': 'package', 'package': package_rel},
                             provenance_of(case, unit, doc, files[case['fixture']]), now, supersedes,
                             tables=pkg.checks_tables(doc))


def import_goldens(unit, cases, package_rel, doc, resources, now, old_entries, new_entries):
    directory = resources / 'golden' / unit
    ids = {'written': [], 'kept': [], 'keptOracleUnchanged': [], 'superseded': [], 'orphaned': []}
    golden_ids, files = set(), {}
    for case in cases:
        if not pkg.is_golden(case):
            continue
        golden_ids.add(case['id'])
        path = directory / f"{case['id']}.json"
        if path.is_file():
            old = canonical.load_json(path)
            same = golden_of(case, unit, package_rel, doc, files, now, old.get('supersedes'))
            if canonical.integrity_holds(old) and same['contentHash'] == old.get('contentHash'):
                ids['kept'].append(case['id'])
                continue
            if canonical.integrity_holds(old) and update.oracle_key(old_entries.get(case['id']), old) \
                    == update.oracle_key(new_entries.get(case['id']), same):
                ids['kept'].append(case['id'])
                ids['keptOracleUnchanged'].append(case['id'])
                continue
            reason = 'the package changed this recording' if canonical.integrity_holds(old) \
                else 'the stored golden master no longer matched its seal'
            archive_stale(directory, old, reason, now)
            write(path, golden_of(case, unit, package_rel, doc, files, now, old.get('contentHash')))
            ids['superseded'].append(case['id'])
            continue
        write(path, golden_of(case, unit, package_rel, doc, files, now, None))
        ids['written'].append(case['id'])
    if directory.is_dir():
        for stale in sorted(directory.glob('*.json')):
            if stale.stem not in golden_ids:
                archive_stale(directory, canonical.load_json(stale), 'no longer a golden case of the package', now)
                stale.unlink()
                ids['orphaned'].append(stale.stem)
    return {'counts': {k: len(ids[k]) for k in ('written', 'kept', 'superseded', 'orphaned')}, 'ids': ids}


def current_views(unit, doc, package_rel, entries, rules):
    files, views = {}, {}
    for entry, case in zip(entries, doc['cases']):
        golden = golden_of(case, unit, package_rel, doc, files, '-', None) if pkg.is_golden(case) else None
        views[entry['scenarioId']] = update.case_view(entry, golden, rules)
    return views


def write_callers(resources):
    callers = {}
    folder = resources / 'scenarios'
    for register in sorted(folder.glob('*.json')) if folder.is_dir() else []:
        for entry in canonical.load_json(register).get('scenarios', []):
            principal = (entry.get('http') or {}).get('principal')
            if principal and entry.get('status') in ('runnable', 'blocked'):
                found = callers.setdefault(principal, {'id': principal, 'units': [], 'scenarios': 0})
                if register.stem not in found['units']:
                    found['units'].append(register.stem)
                found['scenarios'] += 1
    target = resources / 'callers.json'
    if not callers:
        if target.is_file():
            target.unlink()
            return True
        return False
    return write(target, {'generatedBy': SCRIPT, 'description': 'The users the module\'s calls are made as (the '
                                                                'packages\' request.principal) - no credential.',
                          'callers': list(callers.values())})


def profiles(resources, unit, doc):
    """profiles.json: the contract profile of the package rules (decision 4 A, e2e_v1's ``comparison_profile``);
    this unit's rules replaced, another imported unit's kept."""
    path = resources / 'profiles.json'
    old = canonical.load_json(path) if path.is_file() else {}
    others = [r for p in old.get('profiles') or [] if p.get('name') == 'contract' for r in p.get('rules') or []
              if r.get('decision') != f'PKG-CMP-{unit}']
    mine = pkg.comparison_profile([unit], {unit: doc.get('comparison')}, tables=pkg.checks_tables(doc),
                                  docs={unit: doc})
    rules = sorted(others + mine['profiles'][0]['rules'], key=lambda r: str(r.get('decision')))
    mine['profiles'][0]['rules'] = rules
    units = sorted({str(r.get('decision', ''))[len('PKG-CMP-'):] for r in rules} | {unit})
    if len(units) > 1:
        mine['description'] += f' (units: {", ".join(units)}; the wording is that of the last unit imported)'
    return write(path, mine), mine


# ---------------------------------------------------------------- acceptance

def reapply_acceptance(directory, entries, accepted, decision):
    """RECORDED masters whose oracle key is the decided one -> ACCEPTED again, or DISPUTED when the record gate
    disputed it (`state: DISPUTED`, with its reason) - the person, the time of the gate."""
    applied, dropped = [], []
    by_id = {e['scenarioId']: e for e in entries}
    for path in sorted(directory.glob('*.json')) if directory.is_dir() else []:
        master = canonical.load_json(path)
        sid = master.get('scenarioId')
        acc = accepted.get(sid)
        if not acc:
            continue
        key = update.oracle_key(by_id.get(sid), master)
        if key != acc.get('oracleKey'):
            if master.get('state') == 'RECORDED':
                dropped.append(sid)
            continue
        if master.get('state') != 'RECORDED':
            continue
        target = 'DISPUTED' if acc.get('state') == 'DISPUTED' else 'ACCEPTED'
        gate = f'record gate {acc["gate"]}' if acc.get('gate') else 'record gate'
        entry = {'from': 'RECORDED', 'to': target, 'at': acc.get('at'), 'by': acc.get('by'),
                 'reason': f'{gate}: {acc.get("reason") or "disputed"}' if target == 'DISPUTED' else
                 f'{gate} (re-applied by mu-validate import: the oracle is the accepted one)'}
        if target == 'ACCEPTED':
            entry['decision'] = decision
        master['history'] = list(master.get('history') or []) + [entry]
        master['state'] = target
        write(path, master)
        applied.append(sid)
    return applied, dropped


# ---------------------------------------------------------------- the step

def ensure_ready(ctx, args, st):
    probe = copy.deepcopy(st)
    code, doc = readiness.run_step(ctx, args, probe)
    st['readiness'] = probe['readiness']
    if code != 0:
        raise Stop(f'the package is not ready ({doc.get("status")}): fix it first (readiness)', code=2,
                   readiness={k: doc.get(k) for k in ('status', 'fix', 'warnings')})


def import_unit(ctx, st, path, resources, config):
    doc = canonical.load_json(path)
    info = check(ctx, path, doc, config)
    if info['contractProblems'] or info['integrityProblems']:
        raise Stop('the package breaks the input contract, the seal or the integrity check; nothing was imported',
                   code=1, contractProblems=info['contractProblems'][:30],
                   integrityProblems=info['integrityProblems'][:30])
    unit = doc['unit']
    doc['__folder__'] = str(path.parent)
    now = iso_now()
    imports = st.setdefault('imports', {})
    before_side = imports.get(unit)
    old_register = resources / 'scenarios' / f'{unit}.json'
    old_entries = {e['scenarioId']: e for e in canonical.load_json(old_register).get('scenarios', [])} \
        if old_register.is_file() else {}
    entries, rules, rule_problems, package_rel = derive_unit(ctx, path, doc, config)
    old_rules_file = resources / 'rules' / f'{unit}.json'
    old_rules = canonical.load_json(old_rules_file).get('rules', []) if old_rules_file.is_file() else []
    old_views = update.baseline(resources, unit, old_rules)
    new_views = current_views(unit, doc, package_rel, entries, rules)
    found_now = identity(ctx, path, doc)

    register = {'schemaVersion': '1.1', 'mu': ctx.name,
                'description': f'Test package {Path(package_rel).name} ({unit}): {doc.get("api") or "service lens"}',
                'generatedBy': SCRIPT,
                'source': {'package': package_rel, 'packageHash': found_now['packageHash']}
                | ({'markdown': found_now['markdown'], 'markdownHash': found_now['markdownHash']}
                   if found_now['markdown'] else {}),
                'scenarios': entries}
    if pkg.checks_tables(doc):
        mappings = pkg.table_view_mappings(unit, doc)
    else:
        bodies = [c['expected']['body'] for c in doc['cases'] if pkg.is_golden(c)
                  and 200 <= int(c['expected']['status']) < 300 and isinstance(c['expected'].get('body'), dict)]
        mappings = {unit: pkg.view_mapping(unit, bodies, f'API response of {unit}, derived from the package\'s '
                                                         'expected bodies')}
    rules_doc = {'schemaVersion': 1, 'unit': unit,
                 'source': {'file': package_rel, 'sha256': found_now['packageHash'], 'field': 'rules'},
                 'rules': rules, 'problems': rule_problems}
    changed = [name for name, written in (
        [(f'scenarios/{unit}.json', write(resources / 'scenarios' / f'{unit}.json', register))]
        + [(f'view-mappings/{mid}.json', write(resources / 'view-mappings' / f'{mid}.json', m))
           for mid, m in mappings.items()]
        + [(f'rules/{unit}.json', write(resources / 'rules' / f'{unit}.json', rules_doc))]) if written]
    views = resources / 'view-mappings'
    for stale in sorted(set(views.glob(f'{unit}.json')) | set(views.glob(f'{unit}--*.json'))):
        if stale.stem not in mappings:
            stale.unlink()
            changed.append(f'view-mappings/{stale.name} (removed)')
    goldens = import_goldens(unit, doc['cases'], package_rel, doc, resources, now, old_entries,
                             {e['scenarioId']: e for e in entries})
    applied, dropped = reapply_acceptance(resources / 'golden' / unit, entries, st.get('acceptance') or {},
                                          f'PKG-CMP-{unit}')
    masters = {p.stem: canonical.load_json(p) for p in sorted((resources / 'golden' / unit).glob('*.json'))}
    text = feature.render(doc, unit, package_rel, found_now['packageHash'], entries, rules, masters, None)
    feature_changed = ec.write_text_if_changed(resources / 'features' / f'{unit}.feature', text)
    if feature_changed:
        changed.append(f'features/{unit}.feature')
    profiles_changed, profile = profiles(resources, unit, doc)
    if profiles_changed:
        changed.append('profiles.json')
    if write_callers(resources):
        changed.append('callers.json')

    record = None
    if before_side:
        cases_diff = update.diff(old_views, new_views)
        to_side = {**found_now, 'importFormat': IMPORT_FORMAT, 'importedAt': now}
        touched = cases_diff['added'] or cases_diff['removed'] or cases_diff['changed'] \
            or update.fixture_changes(old_views, new_views) or any(update.rule_changes(old_rules, rules).values()) \
            or update.package_changes(before_side, to_side)
        if touched:
            record = {'unit': unit, 'from': before_side, 'to': to_side, 'cases': cases_diff,
                      'fixtures': update.fixture_changes(old_views, new_views),
                      'rules': update.rule_changes(old_rules, rules), 'stories': None, 'importedAt': now,
                      'golden': goldens['ids'], 'generatedBy': SCRIPT,
                      'feature': {'file': f'{ctx.rel(resources)}/features/{unit}.feature', 'changed': feature_changed}}
            ec.write_json(ctx.tmp / f'update-{unit}.json', record)
            ec.write_text_if_changed(ctx.tmp / f'update-{unit}.md', update.update_markdown(record))
    status_changed = bool(changed) or bool(applied) or any(goldens['counts'][k] for k in
                                                            ('written', 'superseded', 'orphaned'))
    if status_changed or not before_side:
        imports[unit] = {**found_now, 'importFormat': IMPORT_FORMAT, 'importedAt': now}
    statuses = Counter(e['status'] for e in entries)
    return status_changed, {
        'unit': unit, 'package': package_rel, 'version': found_now['version'], 'contentHash': found_now['contentHash'],
        'scenarios': len(entries), 'byStatus': dict(statuses), 'golden': goldens['counts'],
        'goldenStates': dict(Counter(m.get('state') for m in masters.values())),
        'viewMappings': sorted(mappings), 'profile': [r['rule'] for r in profile['profiles'][0]['rules']
                                                      if r['decision'] == f'PKG-CMP-{unit}'],
        'rules': len(rules), 'acceptanceReapplied': len(applied), 'acceptanceDropped': dropped,
        'reAccept': (record or {}).get('cases', {}).get('reAccept', []),
        'update': ctx.rel(ctx.tmp / f'update-{unit}.md') if record else None,
        'filesChanged': changed, 'blockedByIdentity': sum(1 for e in entries if e.get('blockedBy') == 'identity'),
        'coverage': info['coverage'], 'recordedOn': info['recordedOn'], 'integrityChecked': info['integrityChecked'],
        'warnings': list(dict.fromkeys(rule_problems + info['warnings']))}


def run_step(ctx, args, st):
    ensure_ready(ctx, args, st)
    config = e2e_config(ctx)
    resources = ctx.e2e
    try:
        changed, result = import_unit(ctx, st, ctx.package, resources, config)
    except E2eError as e:
        raise Stop(f'{e.code}: {e.message}', code=1, **({'details': e.details} if e.details else {})) from None
    warnings = [f'{result["unit"]}: {w}' for w in result.pop('warnings')]
    st['import'] = {'entry': ctx.entry, 'contentHash': result['contentHash'], 'version': result['version'],
                    'assets': ctx.rel(resources), 'scenarios': result['scenarios'], 'byStatus': result['byStatus'],
                    'goldenStates': result['goldenStates']}
    return 0, {'status': 'imported' if changed else 'unchanged', 'entry': ctx.entry, 'assets': ctx.rel(resources),
               **result, 'warnings': warnings}
