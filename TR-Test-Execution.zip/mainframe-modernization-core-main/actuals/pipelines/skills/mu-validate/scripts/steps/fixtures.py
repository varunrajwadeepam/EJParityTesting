"""Step 6 - fixtures: the rows and table shapes the scenarios run on, in mu/<MU>/validation/e2e/fixtures/.

    mu_validate.py fixtures <mu> [--entry E]

Port of e2e_v1 main `e2e_fixtures prepare`. Writes <E>/<file> (every fixture the package's cases name, byte for
byte; a file no case names any more is removed), schema/recording-schema.sql (the tables the packs touch, the
table checks' tables with their foreign-key children and the package's resetTables, defined as in the DDL the
recordings name - mu/<MU>/unit/schema.sql, found by its sha256; built at execute time in the e2e-db2 schema,
never here) and manifest.json (the packs with their hashes, the schema, always `reset: all-tables`: decision 3). Refuses when a
table has no definition, or when an imported golden master names another pack hash (import again). Touches no
database.
"""

from pathlib import Path

from e2elib import canonical, common as ec, ddl, fingerprint, package as pkg
from vlib.common import slash_command, Stop, package_hash
from vlib.e2econfig import e2e_config

SCRIPT = 'mu-validate fixtures'
SCHEMA_FILE = 'schema/recording-schema.sql'
RESET_ALL_TABLES = 'all-tables'           # the framework's FixtureManifest.RESET_ALL_TABLES


def add_arguments(ap):
    pass


def recording_sources(ctx, config, wanted):
    sources, located = [], []
    for want in wanted:
        doc = {'package': {'format': 3}, 'recordings': {'_': {'ddl': want}}}
        candidates = fingerprint.ddl_candidates(ctx.workspace, config, doc)
        hit = fingerprint.match(want['sha256'], candidates)
        if hit['status'] != 'same':
            return None, [{'how': label, 'path': ctx.rel(path), 'found': path.is_file()} for label, path in candidates]
        path = dict(candidates)[hit['source']]
        located.append({'how': hit['source'], 'path': ctx.rel(path), 'form': hit['form'], 'matched': True})
        sources.append((f"{want['path']} (sha256 {want['sha256']})", path.read_text(encoding='utf-8', errors='replace')))
    return sources, located


def golden_mismatches(resources, pack_hashes):
    fixture_of = {}
    for register in sorted((resources / 'scenarios').glob('*.json')):
        for scenario in canonical.load_json(register).get('scenarios', []):
            if scenario.get('fixture'):
                fixture_of[scenario['scenarioId']] = scenario['fixture']
    out = []
    for golden in sorted((resources / 'golden').glob('*/*.json')):
        master = canonical.load_json(golden)
        pack = fixture_of.get(master.get('scenarioId'))
        recorded = (master.get('provenance') or {}).get('fixture')
        if pack and recorded and pack_hashes.get(pack) != recorded:
            out.append({'scenarioId': master.get('scenarioId'), 'pack': pack, 'recorded': recorded,
                        'prepared': pack_hashes.get(pack)})
    return out


def run_step(ctx, args, st):
    if not ctx.package.is_file():
        raise Stop(f'{ctx.rel(ctx.package)} not found: run readiness', code=2)
    config = e2e_config(ctx)
    schema_name = config['database']['schema']
    resources = ctx.e2e
    if not (resources / 'scenarios' / f'{ctx.entry}.json').is_file():
        raise Stop(f'{ctx.rel(resources)} holds no register of {ctx.entry}: run import first', code=2)
    fixtures = resources / 'fixtures'
    doc = canonical.load_json(ctx.package)
    unit = doc['unit']
    packs, changed, needed = [], [], []
    for name in sorted({c['fixture'] for c in doc['cases'] if isinstance(c, dict) and c.get('fixture')}):
        source = ctx.package_dir / name
        if not source.is_file():
            raise Stop(f'{ctx.rel(source)} is named by a case but missing')
        data = source.read_bytes()
        rel_file = pkg.fixture_rel_file(unit, name)
        target = fixtures / rel_file
        if not target.is_file() or target.read_bytes() != data:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            changed.append(f'fixtures/{rel_file}')
        tables = ddl.touched_tables(ddl.split(data.decode('utf-8')))
        needed += [t for t in tables if t not in needed]
        packs.append({'id': pkg.fixture_pack_id(unit, name), 'files': [rel_file], 'tables': tables,
                      'sha256': pkg.pack_hash([(rel_file, data)])})
    named = {Path(f).name for p in packs for f in p['files']}
    unit_dir = fixtures / unit
    for stale in sorted(unit_dir.iterdir()) if unit_dir.is_dir() else []:
        if stale.is_file() and stale.name not in named:
            stale.unlink()
            changed.append(f'fixtures/{unit}/{stale.name} (removed)')

    tables_mode = pkg.checks_tables(doc)
    if tables_mode:
        for case in doc['cases']:
            for check in pkg.table_checks(case) if isinstance(case, dict) else []:
                name = str(check.get('name') or '').upper()
                if name and name not in needed:
                    needed.append(name)
    reset_named = pkg.reset_tables(doc)
    needed += [t for t in reset_named if t not in needed]
    wanted = ddl.recording_ddls([doc]) if pkg.is_format3(doc) else []
    if wanted:
        sources, located = recording_sources(ctx, config, wanted)
        if sources is None:
            raise Stop('no DDL with the content the recordings ran on: mu/<MU>/unit/schema.sql differs from the '
                       'recording (rebuild the package with ' + slash_command('mu-build-tests') + ')', code=2, wanted=wanted, tried=located)
    else:
        located = []
        schema_sql = ctx.mu / 'unit' / 'schema.sql'
        if not schema_sql.is_file():
            raise Stop(f'{ctx.rel(schema_sql)} not found', code=2)
        sources = [(f'unit/schema.sql (sha256 {ec.sha256_file(schema_sql)})',
                    schema_sql.read_text(encoding='utf-8', errors='replace'))]
    children = ddl.foreign_key_children(needed, sources) if tables_mode else []
    needed += [c for c in children if c not in needed]
    subset = ddl.subset(needed, sources)
    if subset.missing:
        raise Stop('no DDL source defines ' + ', '.join(subset.missing) + ': the replay schema cannot be built',
                   missing=subset.missing)
    origins = sorted(set(subset.defined_by.values()))
    schema_text = ddl.render(subset, [
        f'Replay schema of {ctx.name} - generated by {SCRIPT}; regenerate, never edit.',
        f'{len(subset.tables)} tables (the tables the fixture packs touch'
        + (', the table checks\' tables and their foreign-key children' if tables_mode else '')
        + (', the tables the package empties before every recording (resetTables)' if reset_named else '')
        + '; every one emptied before a pack loads), defined as in: ' + '; '.join(origins),
        'Built at execute time in the tools.yaml e2e-db2 schema (a name starting with E2E), never elsewhere.',
    ])
    if ec.write_text_if_changed(fixtures / SCHEMA_FILE, schema_text):
        changed.append(f'fixtures/{SCHEMA_FILE}')
    manifest = {'schemaVersion': '1.0', 'packs': packs,
                'schema': {'file': SCHEMA_FILE, 'tables': subset.tables, 'source': '; '.join(origins),
                           'sha256': ec.sha256_bytes(schema_text.replace('\r\n', '\n').encode('utf-8'))},
                'reset': RESET_ALL_TABLES}        # decision 3: every table emptied per fixture pack, always
    if ec.write_text_if_changed(fixtures / 'manifest.json', canonical.dumps_pretty(manifest)):
        changed.append('fixtures/manifest.json')
    mismatches = golden_mismatches(resources, {p['id']: p['sha256'] for p in packs})
    if mismatches:
        raise Stop('imported golden masters name another fixture pack than the one prepared: run import again',
                   mismatches=mismatches)
    st['fixtures'] = {'entry': ctx.entry, 'contentHash': package_hash(ctx.package), 'packs': len(packs), 'tables': subset.tables,
                      'schemaSha256': manifest['schema']['sha256'], 'reset': manifest.get('reset'),
                      'e2eSchema': schema_name}
    return 0, {'status': 'prepared' if changed else 'unchanged', 'entry': ctx.entry, 'packs': len(packs),
               'tables': subset.tables, 'reset': manifest.get('reset'), 'resetTables': reset_named,
               'foreignKeyChildren': children, 'omittedForeignKeys': subset.omitted_foreign_keys,
               'ddlFoundBy': [x['how'] for x in located if x.get('matched')], 'e2eSchema': schema_name,
               'manifest': ctx.rel(fixtures / 'manifest.json'), 'filesChanged': changed}
