"""Step 3 - snapshot: the product as an immutable copy by content hash, built into validation/target/m2.

    mu_validate.py snapshot <mu> [--status] [--rebuild] [--solution DIR | --solution mu.yaml]

Content hash: sha256 over `<path>\\t<sha256>\\n` of every file of the mu.yaml `solution` folder, sorted,
target/ .git/ .idea/ .vscode/ node_modules/ .claude/ left out. Snapshot validation/target/product/<hash16>/
(copy), <hash16>.manifest.json (path -> sha256), <hash16>.provenance.json (build result, artifacts),
installed.json (the snapshot whose artifacts the private repository holds). Build:
`mvn install -DskipTests -Dspring-boot.repackage.skip=true` in the snapshot, into validation/target/m2,
~/.m2 a read-only tail. Reused while the hash is unchanged and installed. Nothing is written under the
solution. --status writes nothing: current / changed (with the changed files) / not_installed.
--solution DIR takes the product from DIR instead of mu.yaml `solution` (a seeded copy for a test); kept in
validation-state.json `solutionOverride` so every later step reads the same product; `--solution mu.yaml` drops it.
"""

import os
import shutil
import time
from pathlib import Path

from vlib import maven
from vlib.common import Stop, file_sha, iso_now, last_lines, long_path, read_json, sha256, write_json

COPY_SKIP = {'.git', 'target', '.idea', '.vscode', 'node_modules', '.claude'}
INSTALLED = 'installed.json'
SHOWN = 50


def add_arguments(ap):
    ap.add_argument('--status', action='store_true', help='report current / changed / not_installed; write nothing')
    ap.add_argument('--rebuild', action='store_true', help='copy and build again even when the hash is unchanged')
    ap.add_argument('--solution', help='product folder instead of mu.yaml solution (recorded); "mu.yaml" drops it')


def manifest_of(solution):
    out = {}
    base = long_path(solution)
    for root, dirs, files in os.walk(base):
        dirs[:] = sorted(d for d in dirs if d not in COPY_SKIP)
        for name in sorted(files):
            src = Path(root) / name
            out[src.relative_to(base).as_posix()] = file_sha(src)
    return out


def hash_of(manifest):
    return sha256(''.join(f'{p}\t{d}\n' for p, d in sorted(manifest.items())))


def diff(old, new):
    added = sorted(set(new) - set(old))
    removed = sorted(set(old) - set(new))
    modified = sorted(p for p in set(old) & set(new) if old[p] != new[p])
    return {'added': added[:SHOWN], 'removed': removed[:SHOWN], 'modified': modified[:SHOWN],
            'count': len(added) + len(removed) + len(modified)}


def copy_tree(solution, dest, manifest):
    base, out = long_path(solution), long_path(dest)
    if out.exists():
        shutil.rmtree(out)
    for rel in sorted(manifest):
        d = out / rel
        d.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(base / rel, d)
    copied = manifest_of(dest)
    if copied != manifest:
        raise Stop(f'the copy in {dest} differs from the solution (it changed during the copy?): run again')


def artifacts(snapshot):
    found = []
    base = long_path(snapshot)
    for jar in sorted(base.glob('**/target/*.jar')):
        if jar.name.endswith(('-sources.jar', '-javadoc.jar')):
            continue
        found.append({'module': jar.parent.parent.relative_to(base).as_posix() or '.', 'file': jar.name,
                      'sha256': file_sha(jar)})
    return found


def _solution(ctx):
    sol = ctx.solution
    if not sol or not (sol / 'pom.xml').is_file():
        what = '--solution' if ctx.solution_override else 'mu.yaml solution'
        raise Stop(f'no product: {what} {ctx.rel(sol) if sol else "(not set)"} has no pom.xml')
    return sol


def status(ctx):
    sol = _solution(ctx)
    man = manifest_of(sol)
    h = hash_of(man)
    inst_file = ctx.products / INSTALLED
    inst = read_json(inst_file, 'installed snapshot') if inst_file.is_file() else None
    doc = {'solution': ctx.rel(sol), 'hash': h, 'revision': h[:16], 'files': len(man)}
    if not inst:
        return 0, {'status': 'not_installed', **doc, 'installed': None}
    doc['installed'] = {k: inst.get(k) for k in ('revision', 'hash', 'installedAt')}
    if inst.get('hash') == h:
        return 0, {'status': 'current', **doc}
    mf = ctx.products / f'{inst.get("revision")}.manifest.json'
    changed = diff(read_json(mf, 'snapshot manifest'), man) if mf.is_file() else None
    return 0, {'status': 'changed', **doc, 'changedFiles': changed}


def choose_solution(ctx, args, st):
    if not args.solution:
        return
    if args.solution == 'mu.yaml':
        sol = ctx.manifest.get('solution')
        ctx.solution = (ctx.workspace / str(sol)).resolve() if sol else None
        ctx.solution_override = None
        if not args.status:
            st.pop('solutionOverride', None)
        return
    ctx.use_solution(args.solution)
    if not args.status:
        _solution(ctx)
        st['solutionOverride'] = ctx.solution_override


def run_step(ctx, args, st):
    choose_solution(ctx, args, st)
    if args.status:
        return status(ctx)
    sol = _solution(ctx)
    man = manifest_of(sol)
    h = hash_of(man)
    rev = h[:16]
    snap = ctx.products / rev
    prov_file = ctx.products / f'{rev}.provenance.json'
    man_file = ctx.products / f'{rev}.manifest.json'
    inst_file = ctx.products / INSTALLED
    inst = read_json(inst_file, 'installed snapshot') if inst_file.is_file() else {}
    prev = read_json(prov_file, 'provenance') if prov_file.is_file() else None
    built = bool(prev and (prev.get('build') or {}).get('status') == 'success' and prev.get('hash') == h
                 and (snap / 'pom.xml').is_file())
    base = {'solution': ctx.rel(sol), 'solutionSource': 'override' if ctx.solution_override else 'mu.yaml',
            'hash': h, 'revision': rev, 'snapshotDir': ctx.rel(snap),
            'repository': ctx.rel(ctx.m2), 'files': len(man)}
    if built and inst.get('hash') == h and not args.rebuild:
        st['snapshot'] = {'hash': h, 'revision': rev, 'dir': ctx.rel(snap), 'solution': ctx.rel(sol),
                          'builtAt': (prev.get('build') or {}).get('builtAt'), 'artifacts': len(prev.get('artifacts') or [])}
        return 0, {'status': 'reused', **base, 'artifacts': len(prev.get('artifacts') or [])}
    if not built or args.rebuild:
        copy_tree(sol, snap, man)
        write_json(man_file, man)
    log = ctx.logs / f'snapshot-{rev}.log'
    started = time.monotonic()
    if inst_file.is_file():
        inst_file.unlink()
    code, out = maven.mvn(['-f', str(snap / 'pom.xml'), 'install', '-DskipTests',
                           '-Dspring-boot.repackage.skip=true'], cwd=snap, log=log, head=ctx.m2, tail=ctx.home_m2)
    at = iso_now()
    build = {'status': 'success' if code == 0 else 'failed', 'exitCode': code,
             'seconds': round(time.monotonic() - started, 1), 'builtAt': at, 'log': ctx.rel(log),
             'repository': ctx.rel(ctx.m2),
             'command': 'mvn install -DskipTests -Dspring-boot.repackage.skip=true (private repository, ~/.m2 tail)'}
    prov = {'format': 1, 'revision': rev, 'hash': h, 'solution': ctx.rel(sol), 'files': len(man),
            'createdAt': (prev or {}).get('createdAt') if built and not args.rebuild else at, 'build': build,
            'artifacts': artifacts(snap) if code == 0 else []}
    write_json(prov_file, prov)
    if code != 0:
        raise Stop(f'the snapshot build failed (exit {code}); see {ctx.rel(log)}', log=ctx.rel(log),
                   tail=last_lines(out))
    write_json(inst_file, {'revision': rev, 'hash': h, 'installedAt': at, 'provenance': prov_file.name})
    st['snapshot'] = {'hash': h, 'revision': rev, 'dir': ctx.rel(snap), 'solution': ctx.rel(sol), 'builtAt': at,
                      'artifacts': len(prov['artifacts'])}
    return 0, {'status': 'built', **base, 'build': build, 'artifacts': len(prov['artifacts']),
               **({'reinstalled': f'the private repository held {inst.get("revision")}'} if built and inst else {})}
