"""Step 4 - solution: the test solution validation/ and this MU's module <mu>-e2e (ER-1 lint: step lint).

    mu_validate.py solution <mu> [--entry E]

Needs the framework installed and the product snapshot current (steps framework, snapshot: exit 2 otherwise).
The product facts are read from the snapshot copy (never from the solution): the @SpringBootApplication class
(exactly one), its module, groupId and version, the Spring Boot version and Java release through the module's
parent chain, the datasource keys of its application*.yml / *.properties, its security configuration, the
placeholders without default. From the skill's templates/validation/:

  validation/pom.xml, README.md, .gitignore, <app>-e2e-parent/pom.xml   written once (validation/ may hold only
      target/ before); afterwards the parent's product pins (Spring Boot version, e2e.product.version) are
      re-aligned and any other drift (Java release, framework version, product groupId) is reported
  validation/<mu>-e2e/   written from templates/validation/module/; a missing or differing file is (re)written
      (the module is mu-validate's: "repaired"); its line added below the aggregator's marker. Assets:
      property e2e.assets.dir = mu/<MU>/validation/e2e/ (relative to the module)

Records the snapshot hash the module was written for (validation-state.json solution.snapshotHash).
er1() - `mvn verify -pl <mu>-e2e -am` in the default profile against the private repository, no E2E_DB_* in the
environment - is run by the lint step once the assets are imported and the fixtures prepared.
"""

import os
import re
import shutil
import time
import xml.etree.ElementTree as ET
from pathlib import Path

from e2elib import pom
from e2elib.common import E2eError
from steps import framework, snapshot
from vlib import maven
from vlib.common import SKILL, Stop, last_lines, long_path, read_json, read_text, write_text
from vlib.config import load_yaml

TEMPLATES = SKILL / 'templates' / 'validation'
MODULE_TEMPLATES = TEMPLATES / 'module'
TEST_SOLUTION_VERSION = '1.0.0-SNAPSHOT'
CUCUMBER_DEFAULT = '7.21.1'            # the framework archetype's defaults when the framework POM names none
REST_ASSURED_DEFAULT = '5.5.6'
DB_ENV = ('E2E_DB_URL', 'E2E_DB_USER', 'E2E_DB_PASSWORD', 'E2E_DB_SCHEMA')
RUN_ENV = ('E2E_TARGET_PROPERTIES', 'E2E_TARGET_PIN_CLOCK', 'E2E_TARGET_CLOCK', 'E2E_TARGET_IDENTITY')
_BOOT_APP = re.compile(r'^\s*@(?:org\.springframework\.boot\.autoconfigure\.)?SpringBootApplication\b', re.M)
_PACKAGE = re.compile(r'^\s*package\s+([\w.]+)\s*;', re.M)
_CLASS = re.compile(r'^\s*(?:public\s+)?(?:final\s+|abstract\s+)*class\s+(\w+)', re.M)
_SECURITY = re.compile(r'\bSecurityFilterChain\b|@EnableWebSecurity\b|@EnableMethodSecurity\b')
_PLACEHOLDER = re.compile(r'\{\{(\w+)\}\}')
_ENV_REF = re.compile(r'\$\{([^}:]+)(:[^}]*)?\}')
_DEP = re.compile(r'<artifactId>\s*([^<\s]+)\s*</artifactId>')


def add_arguments(ap):
    pass


# ---------------------------------------------------------------- names

def class_prefix(token):
    parts = [p for p in re.split(r'[^A-Za-z0-9]+', str(token)) if p]
    prefix = ''.join(p[:1].upper() + p[1:] for p in parts) or 'Mu'
    return prefix if prefix[0].isalpha() else 'Mu' + prefix


def package_segment(token):
    seg = re.sub(r'[^a-z0-9]', '', str(token).lower()) or 'mu'
    return seg if seg[0].isalpha() else 'mu' + seg


def module_name(ctx):
    return re.sub(r'[^a-z0-9-]+', '-', ctx.name.lower()).strip('-') + '-e2e'


# ---------------------------------------------------------------- product facts

def boot_applications(sources):
    found = []
    for java in sorted(sources.rglob('*.java')) if sources.is_dir() else []:
        text = read_text(java)
        if _BOOT_APP.search(text):
            pk, klass = _PACKAGE.search(text), _CLASS.search(text)
            if klass:
                found.append((pk.group(1) + '.' if pk else '') + klass.group(1))
    return found


def spring_boot_version(chain, properties):
    for member in chain:
        if member.parent_group_id == 'org.springframework.boot' and \
                member.parent_artifact_id in ('spring-boot-starter-parent', 'spring-boot-dependencies'):
            return pom.interpolate(member.parent_version, properties)
    for member in chain:
        for group, artifact, version in member.imports:
            if (group, artifact) == ('org.springframework.boot', 'spring-boot-dependencies'):
                return pom.interpolate(version, properties)
    return pom.interpolate(properties.get('spring-boot.version'), properties)


def _flatten(v, prefix=''):
    if isinstance(v, dict):
        for k, x in v.items():
            yield from _flatten(x, f'{prefix}.{k}' if prefix else str(k))
    else:
        yield prefix, v


def application_config(module_dir):
    """{key: value} of the module's src/main/resources/application*.yml|yaml|properties (profile files by name)."""
    res = module_dir / 'src' / 'main' / 'resources'
    out = {}
    for f in sorted(res.glob('application*')) if res.is_dir() else []:
        if f.suffix in ('.yml', '.yaml'):
            try:
                docs = [load_yaml(f)]
            except Exception:  # noqa: BLE001 - a multi-document or odd file is listed, not fatal
                docs = []
            for d in docs:
                for k, v in _flatten(d):
                    out[f'{f.name}:{k}'] = v
        elif f.suffix == '.properties':
            for line in read_text(f).splitlines():
                line = line.strip()
                if line and not line.startswith(('#', '!')) and ('=' in line or ':' in line):
                    k, v = re.split(r'\s*[=:]\s*', line, maxsplit=1)
                    out[f'{f.name}:{k}'] = v
    return out


def security_facts(module_dir, config, pom_text):
    classes, keys = [], set()
    for java in sorted((module_dir / 'src' / 'main' / 'java').rglob('*.java')):
        text = read_text(java)
        if _SECURITY.search(text):
            pk, klass = _PACKAGE.search(text), _CLASS.search(text)
            if klass:
                classes.append((pk.group(1) + '.' if pk else '') + klass.group(1))
            keys |= {m.group(0) for m in _ENV_REF.finditer(text)}
    deps = sorted(a for a in set(_DEP.findall(pom_text)) if 'security' in a or 'oauth2' in a)
    issuer = {k.split(':', 1)[1]: v for k, v in config.items() if 'issuer-uri' in k or 'jwk-set-uri' in k}
    return {'configClasses': classes, 'dependencies': deps, 'tokenSettings': issuer, 'propertiesRead': sorted(keys),
            'present': bool(classes or deps)}


def product_facts(ctx, snap):
    """Every value the templates need, read from the snapshot copy of the product."""
    if not (snap / 'pom.xml').is_file():
        raise Stop(f'no snapshot in {ctx.rel(snap)}: run snapshot', code=2)
    root = pom.read_pom(snap / 'pom.xml')
    dirs = [snap / m for m in root.modules if (snap / m / 'pom.xml').is_file()] if root.modules else [snap]
    apps = [(d, a) for d in dirs for a in boot_applications(d / 'src' / 'main' / 'java')]
    if not apps:
        raise Stop('the product holds no @SpringBootApplication class: the module needs an application to boot')
    if len(apps) > 1:
        raise Stop('the product holds several @SpringBootApplication classes: name the one to boot',
                   classes=[f'{ctx.rel(d)}: {a}' for d, a in apps])
    app_dir, main = apps[0]
    app_pom = pom.read_pom(app_dir / 'pom.xml')
    chain = pom.lineage(app_pom.path)
    props = pom.inherited_properties(chain)
    boot = spring_boot_version(chain, props)
    if not boot or '$' in boot:
        raise Stop(f'neither {app_dir.name}/pom.xml nor its parents name a Spring Boot version', found=boot)
    java = pom.interpolate(props.get('java.version') or props.get('maven.compiler.release'), props) or '21'
    config = application_config(app_dir)
    ds = {k.split(':', 1)[1]: v for k, v in config.items() if ':spring.datasource.' in k}
    env_refs = sorted({m.group(1) for v in ds.values() for m in _ENV_REF.finditer(str(v))})
    no_default = sorted({f'{k.split(":", 1)[1]}=${{{m.group(1)}}}' for k, v in config.items()
                         for m in _ENV_REF.finditer(str(v)) if m.group(2) is None
                         and ':spring.datasource.' not in k})
    text = '\n'.join(str(v) for v in config.values()) + '\n' + '\n'.join(config)
    app_id = str(ctx.manifest.get('du') or '').strip() or re.sub(r'-(solution|parent|root)$', '', root.artifact_id)
    base_package = main.rsplit('.', 1)[0] if '.' in main else ''
    server_port = next((v for k, v in config.items() if k.endswith(':server.port')), None)
    return {
        'snapshot': ctx.rel(snap), 'appId': re.sub(r'[^A-Za-z0-9-]+', '-', app_id).strip('-').lower() or 'app',
        'productModule': app_pom.artifact_id, 'productModuleDir': app_dir.relative_to(snap).as_posix() or '.',
        'productGroupId': app_pom.effective_group_id, 'productVersion': app_pom.effective_version,
        'mainClass': main, 'basePackage': base_package, 'springBootVersion': boot, 'javaRelease': str(java),
        'serverPort': server_port,
        'datasource': {'keys': ds, 'environment': env_refs,
                       'initSql': any('connection-init-sql' in k for k in ds),
                       'excludesAutoConfiguration': 'DataSourceAutoConfiguration' in text},
        'security': security_facts(app_dir, config, read_text(app_pom.path)),
        'placeholdersWithoutDefault': no_default,
    }


def e2e_database(ctx):
    """The replay database of tools.yaml e2e-db2 as the run passes it (E2E_DB_*; the password is never shown)."""
    sec = ctx.tool('e2e-db2')
    if not sec:
        return None
    url = f'jdbc:db2://{sec.get("host") or "localhost"}:{sec.get("port") or 50000}/{sec.get("database") or "TESTDB"}'
    return {'section': 'e2e-db2', 'url': url, 'schema': str(sec.get('schema') or '').upper(),
            'user': sec.get('user'), 'password': 'set' if sec.get('password') else 'not set',
            'environment': {'E2E_DB_URL': url, 'E2E_DB_USER': sec.get('user'),
                            'E2E_DB_PASSWORD': '<tools.yaml e2e-db2 password>',
                            'E2E_DB_SCHEMA': str(sec.get('schema') or '').upper()}}


# ---------------------------------------------------------------- templates

def render(text, values):
    def value(m):
        if m.group(1) not in values:
            raise Stop(f'template placeholder {{{{{m.group(1)}}}}} has no value')
        return str(values[m.group(1)])
    return _PLACEHOLDER.sub(value, text)


def template_values(ctx, facts, framework_pom, module_dir):
    package = '.'.join(x for x in ('e2e', facts['basePackage'], package_segment(ctx.name)) if x)
    ds = facts['datasource']
    keys = ', '.join(f'{k}={v}' for k, v in ds['keys'].items() if k.endswith(('.url', '.username', '.password',
                                                                               '.schema'))) or 'none'
    return {
        'appId': facts['appId'], 'groupId': facts['productGroupId'], 'version': TEST_SOLUTION_VERSION,
        'productGroupId': facts['productGroupId'], 'productVersion': facts['productVersion'],
        'productModule': facts['productModule'], 'springBootVersion': facts['springBootVersion'],
        'javaRelease': facts['javaRelease'], 'frameworkVersion': framework_pom.version,
        'cucumberVersion': framework_pom.properties.get('cucumber.version') or CUCUMBER_DEFAULT,
        'restAssuredVersion': framework_pom.properties.get('rest-assured.version') or REST_ASSURED_DEFAULT,
        'solutionDir': ctx.solution.name if ctx.solution else 'solution',
        'muName': ctx.name, 'module': module_dir.name, 'prefix': class_prefix(ctx.name), 'package': package,
        'packagePath': package.replace('.', '/'), 'mainClass': facts['mainClass'],
        'assetsDir': os.path.relpath(ctx.e2e, module_dir).replace('\\', '/'), 'assetsDirShown': ctx.rel(ctx.e2e),
        'productDatasourceKeys': keys,
        'autoconfigure': ('  autoconfigure:\n    # The product excludes DataSourceAutoConfiguration; the replay runs on '
                          'the real database.\n    exclude: []\n') if ds['excludesAutoConfiguration'] else '',
        'webStack': ('            <!-- The product\'s security configuration needs a servlet context: a context booted '
                     'for the component\n                 lens gets one (step-3 F2). -->\n'
                     '            <e2e.target.web>SERVLET</e2e.target.web>\n') if facts['security']['present'] else '',
    }


def rendered(source, values, skip=()):
    """{relative target path: text} of every template file below `source` (`skip`: top-level names left out)."""
    out = {}
    for path in sorted(p for p in source.rglob('*') if p.is_file()):
        rel = path.relative_to(source)
        if rel.parts[0] in skip:
            continue
        parts = []
        for part in rel.parts:
            part = part.replace('__gitignore__', '.gitignore').replace('__packagePath__', values['packagePath'])
            part = re.sub(r'__(\w+?)__', lambda m: str(values.get(m.group(1), m.group(0))), part)
            parts.append(part)
        out['/'.join(parts)] = render(read_text(path).replace('\r\n', '\n'), values)
    return out


def write_files(root, files, overwrite):
    """(created, repaired, differing-but-kept) relative paths."""
    created, repaired, kept = [], [], []
    for rel, text in files.items():
        dest = root.joinpath(*rel.split('/'))
        if dest.is_file():
            if read_text(dest).replace('\r\n', '\n') == text:
                continue
            if not overwrite:
                kept.append(rel)
                continue
            repaired.append(rel)
        else:
            created.append(rel)
        write_text(dest, text)
    return created, repaired, kept


def stale_module_files(module_dir, files):
    """Files of the module's src/ that no template writes (e.g. a class of another prefix): removed."""
    keep = {module_dir.joinpath(*r.split('/')).resolve() for r in files}
    removed = []
    src = module_dir / 'src'
    for p in sorted(src.rglob('*')) if src.is_dir() else []:
        if p.is_file() and p.resolve() not in keep:
            p.unlink()
            removed.append(p.relative_to(module_dir).as_posix())
    return removed


def align(ctx, parent, facts):
    changes = pom.set_versions(parent, facts['springBootVersion'],
                               {'e2e.product.version': facts['productVersion']})
    names = {'parent.version': 'springBootVersion', 'e2e.product.version': 'productVersion'}
    return [{'item': names.get(c['item'], c['item']), 'from': c['from'], 'to': c['to'], 'file': ctx.rel(parent)}
            for c in changes]


def drift(ctx, parent, values):
    p = pom.read_pom(parent)
    checks = [('javaRelease', p.properties.get('java.version'), values['javaRelease']),
              ('frameworkVersion', p.properties.get('e2e.framework.version'), values['frameworkVersion']),
              ('productGroupId', p.properties.get('e2e.product.groupId'), values['productGroupId'])]
    return [{'item': i, 'recorded': r, 'current': c, 'file': ctx.rel(parent)} for i, r, c in checks if r != c]


# ---------------------------------------------------------------- ER-1

def surefire(module_dir, since):
    totals = {'tests': 0, 'failures': 0, 'errors': 0, 'skipped': 0}
    classes, failing = [], []
    for report in sorted((module_dir / 'target' / 'surefire-reports').glob('TEST-*.xml')):
        if report.stat().st_mtime < since:
            continue
        try:
            suite = ET.parse(report).getroot()
        except ET.ParseError:
            continue
        counts = {k: int(suite.get(k, '0') or 0) for k in totals}
        for k in totals:
            totals[k] += counts[k]
        name = suite.get('name')
        classes.append({'class': name, **counts})
        if counts['failures'] or counts['errors']:
            failing.append(name)
    return totals, classes, failing


def lint_report(module_dir, since):
    path = module_dir / 'target' / 'e2e-reports' / 'e2e-lint.json'
    if not path.is_file() or path.stat().st_mtime < since:
        return None
    doc = read_json(path, 'lint report')
    by_scenario = {}
    for s in doc.get('scenarios') or []:
        prev = by_scenario.get(s.get('scenarioId'))
        if prev in (None, 'PASSED'):                 # a scenario's status: its first level that is not PASSED
            by_scenario[s.get('scenarioId')] = s.get('status')
    statuses = {}
    for v in by_scenario.values():
        statuses[v] = statuses.get(v, 0) + 1
    problems = [{'scenarioId': s.get('scenarioId'), 'status': s.get('status'), 'message': s.get('message')}
                for s in doc.get('scenarios') or [] if s.get('status') not in ('PASSED', 'NOT_APPLICABLE')]
    return {'report': path, 'scenarios': len(by_scenario), 'byStatus': statuses, 'levels': doc.get('counts'),
            'problems': problems[:30]}


def er1(ctx, module_dir):
    copied = module_dir / 'target' / 'test-classes' / 'e2e'
    if copied.is_dir():                                   # Maven copies resources but never deletes a removed one
        shutil.rmtree(long_path(copied))
    env = {k: v for k, v in os.environ.items() if k not in DB_ENV + RUN_ENV}
    log = ctx.logs / f'solution-lint-{module_dir.name}.log'
    started, since = time.monotonic(), time.time() - 2
    code, out = maven.mvn(['-f', str(ctx.validation / 'pom.xml'), 'verify', '-pl', module_dir.name, '-am'],
                          cwd=ctx.validation, log=log, head=ctx.m2, tail=ctx.home_m2, env=env)
    totals, classes, failing = surefire(module_dir, since)
    lint = lint_report(module_dir, since)
    passed = code == 0 and not totals['failures'] and not totals['errors']
    result = {'er1': 'pass' if passed else 'fail', 'exitCode': code, **totals, 'classes': classes,
              'failing': failing, 'seconds': round(time.monotonic() - started, 1), 'log': ctx.rel(log),
              'environment': 'no E2E_DB_* (the smoke test skips: it needs the replay database)'}
    if lint:
        lint['report'] = ctx.rel(lint['report'])
        result['lint'] = lint
    if code != 0:
        result['tail'] = last_lines(out, 30)
    return passed, result


# ---------------------------------------------------------------- the step

def preconditions(ctx):
    _, fp, installed, miss = framework.status_of(ctx)
    if miss or installed != fp:
        raise Stop('the framework is not installed in the private repository (or another build of it is): run '
                   'framework', code=2, missing=miss)
    _, snap = snapshot.status(ctx)
    if snap['status'] != 'current':
        raise Stop(f'the product snapshot is {snap["status"]}: run snapshot', code=2,
                   changedFiles=snap.get('changedFiles'))
    return ctx.products / snap['revision'], snap['hash']


def run_step(ctx, args, st):
    snap, snap_hash = preconditions(ctx)
    try:
        facts = product_facts(ctx, snap)
        framework_pom = pom.read_pom(ctx.framework / 'pom.xml')
    except E2eError as e:
        raise Stop(f'{e.code}: {e.message}') from None
    root = ctx.validation
    module_dir = root / module_name(ctx)
    values = template_values(ctx, facts, framework_pom, module_dir)
    aggregator = root / 'pom.xml'
    parent = root / f'{values["appId"]}-e2e-parent' / 'pom.xml'
    result = {'testSolution': ctx.rel(root), 'module': module_dir.name, 'created': False, 'files': {}}
    if not aggregator.is_file():
        leftovers = sorted(p.name for p in root.iterdir() if p.name != 'target') if root.is_dir() else []
        if leftovers:
            raise Stop(f'{ctx.rel(root)}/ exists without its aggregator and holds {leftovers}: refusing to write over '
                       'unknown content')
        created, _, _ = write_files(root, rendered(TEMPLATES, values, skip=('module',)), overwrite=False)
        result.update(created=True)
        result['files']['testSolution'] = created
    elif not parent.is_file():
        found = sorted(p.parent.name for p in root.glob('*-e2e-parent/pom.xml'))
        raise Stop(f'{ctx.rel(parent)} not found (the product\'s application id is {values["appId"]}); found '
                   f'{found or "no parent"}: the test solution belongs to another application', parents=found)
    module_files = rendered(MODULE_TEMPLATES, values)
    created, repaired, _ = write_files(module_dir, module_files, overwrite=True)
    removed = stale_module_files(module_dir, module_files)
    result['files'].update(moduleCreated=created, moduleRepaired=repaired, moduleRemoved=removed)
    result['moduleLineAdded'] = pom.ensure_module(aggregator, module_dir.name)
    result['aligned'] = align(ctx, parent, facts)
    result['drift'] = drift(ctx, parent, values)
    changed = result['created'] or created or repaired or removed or result['moduleLineAdded'] or result['aligned']
    status = 'created' if result['created'] else 'updated' if changed else 'unchanged'
    db = e2e_database(ctx)
    st['solution'] = {'snapshotHash': snap_hash, 'module': module_dir.name, 'dir': ctx.rel(module_dir), 'parent': ctx.rel(parent),
                      'package': values['package'], 'prefix': values['prefix'], 'assetsDir': values['assetsDir'],
                      'facts': facts, 'e2eDatabase': db}
    doc = {'status': status, **result, 'package': values['package'], 'classPrefix': values['prefix'],
           'assetsDir': values['assetsDirShown'], 'facts': facts, 'e2eDatabase': db,
           'warnings': [f'{d["item"]}: the parent pins {d["recorded"]}, the product / framework has {d["current"]} '
                        '(reported only)' for d in result['drift']]
           + ([] if db else ['tools.yaml has no e2e-db2: run preflight (the replay needs it)'])
           + [f'product placeholder without default: {p} (the replay must provide it)'
              for p in facts['placeholdersWithoutDefault']]}
    return 0, {**doc, 'snapshotHash': snap_hash, 'next': 'import, fixtures, then lint (ER-1)'}
