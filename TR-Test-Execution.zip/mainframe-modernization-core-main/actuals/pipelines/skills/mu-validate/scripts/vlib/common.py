"""Shared helpers of the mu-validate scripts: one JSON object on stdout, exit 0 done, 2 decision or input
needed, 1 failed. Python 3.10+, standard library plus PyYAML (through tools_config.py). Run from the
workspace root."""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import traceback
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

for _stream in (sys.stdout, sys.stderr):
    if hasattr(_stream, 'reconfigure'):
        _stream.reconfigure(encoding='utf-8', errors='replace', newline='\n')

HERE = Path(__file__).resolve().parent              # ${CLAUDE_PLUGIN_ROOT}/skills/mu-validate/scripts/vlib
SCRIPTS = HERE.parent
SKILL = SCRIPTS.parent                              # ${CLAUDE_PLUGIN_ROOT}/skills/mu-validate
SKILLS = SKILL.parent                               # ${CLAUDE_PLUGIN_ROOT}/skills
TOOLS_CONFIG = SKILLS.parent / 'scripts' / 'tools_config.py'


def slash_command(name):
    """The slash command `name` as the user types it: `/pipelines:<name>` in the plugin, `/<name>` in a local .claude/."""
    return f'/pipelines:{name}' if (SKILLS.parent / '.claude-plugin' / 'plugin.json').is_file() else f'/{name}'


def shown_path(path):
    """`path` relative to the working directory when it is below it, else absolute (local .claude/ or plugin root)."""
    path = Path(path).resolve()
    try:
        return path.relative_to(Path.cwd().resolve()).as_posix()
    except ValueError:
        return path.as_posix()


class Stop(Exception):
    """code 1 = failed, 2 = decision or input needed; keyword arguments go into the JSON answer."""

    def __init__(self, message, code=1, **extra):
        super().__init__(message)
        self.code = code
        self.extra = extra


def eprint(*xs):
    print(*xs, file=sys.stderr)


def plain(v):
    if isinstance(v, Decimal):
        return int(v) if v == v.to_integral_value() and 'E' not in str(v) and '.' not in str(v) else float(v)
    if isinstance(v, dict):
        return {k: plain(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [plain(x) for x in v]
    if isinstance(v, Path):
        return v.as_posix()
    return v


def emit(doc):
    sys.stdout.write(json.dumps(plain(doc), ensure_ascii=True) + '\n')
    sys.stdout.flush()


def main(fn):
    """fn() returns (exit code, answer dict) or an answer dict (exit 0)."""
    try:
        r = fn()
        code, doc = r if isinstance(r, tuple) else (0, r)
    except Stop as e:
        eprint(f'ERROR {e}')
        code = e.code
        doc = {'status': 'failed' if code == 1 else 'needs-input', 'error': str(e), **e.extra}
    except SystemExit as e:
        if not isinstance(e.code, str):
            raise
        eprint(f'ERROR {e.code}')
        code, doc = 1, {'status': 'failed', 'error': e.code}
    except Exception as e:  # noqa: BLE001 - a crash is still one JSON object on stdout, exit 1
        traceback.print_exc(file=sys.stderr)
        code, doc = 1, {'status': 'failed', 'error': f'{type(e).__name__}: {e}'}
    doc = dict(doc or {})
    doc.setdefault('status', 'ok' if code == 0 else 'needs-input' if code == 2 else 'failed')
    emit(doc)
    sys.exit(code)


class Parser(argparse.ArgumentParser):
    """argparse whose usage errors come back as one JSON object, exit 1."""

    def error(self, message):
        emit({'status': 'failed', 'error': f'usage: {message}', 'usage': self.format_usage().strip()})
        sys.exit(1)


# ---------------------------------------------------------------- files and hashes

def read_text(path, encoding='utf-8'):
    with open(path, encoding=encoding, errors='replace', newline='') as fh:
        return fh.read()


def write_text(path, text):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding='utf-8', newline='\n') as fh:
        fh.write(text)


def read_json(path, what, decimal=False):
    try:
        return json.loads(read_text(path), parse_float=Decimal if decimal else None)
    except FileNotFoundError:
        raise Stop(f'{what} {Path(path).as_posix()} not found') from None
    except ValueError as e:
        raise Stop(f'{what} {Path(path).as_posix()} is not valid JSON: {e}') from None


def write_json(path, v):
    """Atomic: a temp file renamed over the old one."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp')
    with open(tmp, 'w', encoding='utf-8', newline='\n') as fh:
        fh.write(json.dumps(plain(v), ensure_ascii=False, indent=2) + '\n')
    os.replace(tmp, path)


def sha256(data):
    return hashlib.sha256(data.encode('utf-8') if isinstance(data, str) else data).hexdigest()


def file_sha(path):
    path = Path(path)
    if not path.is_file():
        return None
    h = hashlib.sha256()
    with open(path, 'rb') as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def canonical(v):
    """Canonical JSON as mu-build-tests seals it: sorted keys, compact, UTF-8 bytes."""
    return json.dumps(plain(v), ensure_ascii=False, separators=(',', ':'), sort_keys=True).encode('utf-8')


def content_hash(doc):
    """The package seal: sha256 of the canonical JSON of a package without its `package` block."""
    return sha256(canonical({k: v for k, v in doc.items() if k != 'package'}))


def package_hash(path):
    """The package's declared seal (`package.contentHash`), None when the file is absent or unreadable."""
    try:
        doc = json.loads(Path(path).read_text(encoding='utf-8')) if Path(path).is_file() else {}
    except (ValueError, OSError):
        return None
    block = doc.get('package') if isinstance(doc, dict) else None
    return block.get('contentHash') if isinstance(block, dict) else None


def tree_digest(*roots, skip=('target',)):
    """sha256 over `<root>/<path>\\t<sha256>\\n` of every file below `roots` (`skip`: folder names left out)."""
    lines = []
    for root in roots:
        root = Path(root)
        if root.is_file():
            lines.append(f'{root.name}\t{file_sha(root)}\n')
            continue
        for dirpath, dirs, files in os.walk(root) if root.is_dir() else []:
            dirs[:] = sorted(d for d in dirs if d not in skip)
            for name in sorted(files):
                p = Path(dirpath) / name
                lines.append(f'{root.name}/{p.relative_to(root).as_posix()}\t{file_sha(p)}\n')
    return sha256(''.join(lines))


SEVERITY = ('FAILED', 'BLOCKED', 'SKIPPED', 'PASSED', 'NOT_APPLICABLE')


def by_scenario(levels):
    """{scenarioId: (status, [its levels])} of a framework report's scenario levels, in report order; a scenario's
    status is its worst level's (FAILED > BLOCKED > SKIPPED > PASSED > NOT_APPLICABLE)."""
    groups = {}
    for s in levels:
        if s.get('scenarioId'):
            groups.setdefault(s['scenarioId'], []).append(s)
    rank = {k: n for n, k in enumerate(SEVERITY)}
    return {sid: (min((x.get('status') for x in ls), key=lambda v: rank.get(v, -1)), ls) for sid, ls in groups.items()}


def iso_now():
    return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


def long_path(path):
    """Windows extended-length form of an absolute path (snapshots sit deeper than the product)."""
    resolved = Path(path).resolve()
    if os.name != 'nt':
        return resolved
    text = str(resolved)
    if text.startswith('\\\\?\\'):
        return resolved
    if text.startswith('\\\\'):
        return Path('\\\\?\\UNC\\' + text[2:])
    return Path('\\\\?\\' + text)


# ---------------------------------------------------------------- processes

def which(name):
    found = shutil.which(name)
    if found or os.name != 'nt':
        return found
    for suffix in ('.cmd', '.bat', '.exe'):
        found = shutil.which(name + suffix)
        if found:
            return found
    return None


def command(env_name, name):
    """The command line of a tool: env `env_name` (a JSON array or one executable; selftest stand-ins),
    else `name` on PATH; None when neither."""
    over = os.environ.get(env_name)
    if over:
        try:
            v = json.loads(over)
            if isinstance(v, list) and v:
                return [str(x) for x in v]
        except ValueError:
            pass
        return [over]
    found = which(name)
    return [found] if found else None


def run(cmd, cwd=None, timeout=3600, stdin=None, log=None, env=None):
    """(returncode, stdout+stderr text). Never through a shell. `env`: the whole environment (None: inherited)."""
    try:
        p = subprocess.run(list(cmd), cwd=str(cwd) if cwd else None, input=stdin, capture_output=True,
                           timeout=timeout, stdin=None if stdin is not None else subprocess.DEVNULL, env=env)
    except FileNotFoundError:
        raise Stop(f'{cmd[0]} is not installed or not on PATH') from None
    except subprocess.TimeoutExpired:
        raise Stop(f'{" ".join(map(str, cmd))} did not finish within {timeout}s') from None
    out = (p.stdout or b'').decode('utf-8', errors='replace') + (p.stderr or b'').decode('utf-8', errors='replace')
    if log is not None:
        Path(log).parent.mkdir(parents=True, exist_ok=True)
        with open(log, 'w', encoding='utf-8', newline='\n') as fh:
            fh.write('$ ' + ' '.join(map(str, cmd)) + '\n' + out)
    return p.returncode, out


def last_lines(text, count=25):
    return [line for line in text.splitlines() if line.strip()][-count:]
