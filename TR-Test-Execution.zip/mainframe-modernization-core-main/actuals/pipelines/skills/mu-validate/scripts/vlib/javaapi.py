"""The product's HTTP API read from Java sources as plain text (no compiler): controller mappings, request and
response DTO fields, exception handler status mapping, the exceptions a method throws. Good enough for Spring MVC
code written the conventional way; anything it cannot read is left out, never guessed."""

import os
import re
from pathlib import Path

from .common import read_text

HTTP_STATUS = {
    'CONTINUE': 100, 'OK': 200, 'CREATED': 201, 'ACCEPTED': 202, 'NO_CONTENT': 204, 'MOVED_PERMANENTLY': 301,
    'FOUND': 302, 'SEE_OTHER': 303, 'NOT_MODIFIED': 304, 'BAD_REQUEST': 400, 'UNAUTHORIZED': 401,
    'PAYMENT_REQUIRED': 402, 'FORBIDDEN': 403, 'NOT_FOUND': 404, 'METHOD_NOT_ALLOWED': 405, 'NOT_ACCEPTABLE': 406,
    'REQUEST_TIMEOUT': 408, 'CONFLICT': 409, 'GONE': 410, 'PRECONDITION_FAILED': 412, 'PAYLOAD_TOO_LARGE': 413,
    'UNSUPPORTED_MEDIA_TYPE': 415, 'I_AM_A_TEAPOT': 418, 'UNPROCESSABLE_ENTITY': 422, 'UNPROCESSABLE_CONTENT': 422,
    'LOCKED': 423, 'PRECONDITION_REQUIRED': 428, 'TOO_MANY_REQUESTS': 429, 'INTERNAL_SERVER_ERROR': 500,
    'NOT_IMPLEMENTED': 501, 'BAD_GATEWAY': 502, 'SERVICE_UNAVAILABLE': 503, 'GATEWAY_TIMEOUT': 504}
ENTITY_STATUS = {'ok': 200, 'created': 201, 'accepted': 202, 'noContent': 204, 'badRequest': 400, 'notFound': 404,
                 'unprocessableEntity': 422, 'internalServerError': 500}
VERBS = {'Get': 'GET', 'Post': 'POST', 'Put': 'PUT', 'Delete': 'DELETE', 'Patch': 'PATCH'}
SKIP_DIRS = {'target', '.git', 'test', 'node_modules'}
_STRIP = re.compile(r'("(?:\\.|[^"\\\n])*")|(/\*.*?\*/|//[^\n]*)', re.S)
_STRING = re.compile(r'"(?:\\.|[^"\\\n])*"')
_SIMPLE = {'String', 'Integer', 'Long', 'Short', 'Byte', 'Double', 'Float', 'Boolean', 'Character', 'BigDecimal',
           'BigInteger', 'LocalDate', 'LocalDateTime', 'LocalTime', 'Instant', 'OffsetDateTime', 'ZonedDateTime',
           'Object', 'UUID', 'int', 'long', 'short', 'byte', 'double', 'float', 'boolean', 'char', 'Void', 'void'}


def strip_comments(text):
    return _STRIP.sub(lambda m: m.group(1) or (' ' if m.group(2).startswith('//') else
                                                re.sub(r'[^\n]', ' ', m.group(2))), text)


def balanced(text, i, open_='(', close=')'):
    """Index after the bracket that closes the one at text[i]; len(text) when unbalanced."""
    depth, n, in_str = 0, len(text), None
    while i < n:
        c = text[i]
        if in_str:
            if c == '\\':
                i += 2
                continue
            if c == in_str:
                in_str = None
        elif c in '"\'':
            in_str = c
        elif c == open_:
            depth += 1
        elif c == close:
            depth -= 1
            if depth == 0:
                return i + 1
        i += 1
    return n


def split_top(text, sep=','):
    parts, depth, cur, in_str = [], 0, [], None
    for c in text:
        if in_str:
            cur.append(c)
            if c == in_str:
                in_str = None
            continue
        if c in '"\'':
            in_str = c
        elif c in '(<[{':
            depth += 1
        elif c in ')>]}':
            depth -= 1
        elif c == sep and depth == 0:
            parts.append(''.join(cur).strip())
            cur = []
            continue
        cur.append(c)
    if ''.join(cur).strip():
        parts.append(''.join(cur).strip())
    return parts


_ANN = re.compile(r'@([\w.]+)\s*')


def annotations(text):
    """[(name, args or None)] of a run of annotations at the start of text, and the rest."""
    found, i = [], 0
    while True:
        while i < len(text) and text[i].isspace():
            i += 1
        m = _ANN.match(text, i)
        if not m:
            return found, text[i:]
        j = m.end()
        args = None
        if j < len(text) and text[j] == '(':
            end = balanced(text, j)
            args = text[j + 1:end - 1]
            j = end
        found.append((m.group(1).split('.')[-1], args))
        i = j


def literal(args, keys=('value', 'path', 'name')):
    """The first string literal of annotation args (positional or one of `keys`)."""
    if args is None:
        return None
    m = re.match(r'\s*\{?\s*"((?:\\.|[^"\\])*)"', args)
    if m:
        return m.group(1)
    for k in keys:
        m = re.search(r'\b' + k + r'\s*=\s*\{?\s*"((?:\\.|[^"\\])*)"', args)
        if m:
            return m.group(1)
    return None


def status_name(text, constants=None):
    """HTTP status code named in text: HttpStatus.X, HttpStatusCode.valueOf(n), .status(n)."""
    m = re.search(r'HttpStatus\.([A-Z_]+)', text)
    if m and m.group(1) in HTTP_STATUS:
        return HTTP_STATUS[m.group(1)]
    m = re.search(r'(?:valueOf|status)\(\s*(\d{3})\s*\)', text)
    if m:
        return int(m.group(1))
    m = re.search(r'\bcode\s*=\s*(\d{3})', text)
    return int(m.group(1)) if m else None


def element_type(type_text):
    """`List<@NotNull @Valid X>` -> (X, True); `X` -> (X, False); annotations and generics dropped."""
    t = re.sub(r'@[\w.]+(\s*\([^)]*\))?', ' ', type_text).strip()
    m = re.match(r'(?:java\.util\.)?(?:List|Set|Collection|Iterable|Optional)\s*<\s*(.+)\s*>$', t)
    if m:
        inner, _ = element_type(m.group(1))
        return inner, True
    if t.endswith('[]'):
        return t[:-2].strip(), True
    return re.sub(r'<.*>', '', t).strip().split('.')[-1], False


class JavaFile:
    def __init__(self, path, rel):
        self.path, self.rel = path, rel
        self.text = strip_comments(read_text(path))
        m = re.search(r'\bpackage\s+([\w.]+)\s*;', self.text)
        self.package = m.group(1) if m else ''
        self.types = {}
        for m in re.finditer(r'\b(class|record|interface|enum)\s+(\w+)', self.text):
            head_start = self.text.rfind(';', 0, m.start()) + 1
            head_start = max(head_start, self.text.rfind('}', 0, m.start()) + 1)
            self.types.setdefault(m.group(2), {'kind': m.group(1), 'at': m.start(),
                                              'head': self.text[head_start:m.start()]})

    def line_of(self, index):
        return self.text.count('\n', 0, index) + 1

    def constants(self):
        return dict(re.findall(r'static\s+final\s+String\s+(\w+)\s*=\s*"((?:\\.|[^"\\])*)"\s*;', self.text))


class Api:
    """The snapshot's sources, indexed by simple type name."""

    def __init__(self, root):
        self.root = Path(root)
        self.files, self.by_type = [], {}
        if self.root.is_dir():
            for base, dirs, names in os.walk(self.root):
                dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS)
                for name in sorted(names):
                    if name.endswith('.java'):
                        p = Path(base) / name
                        jf = JavaFile(p, p.relative_to(self.root).as_posix())
                        self.files.append(jf)
                        for t in jf.types:
                            self.by_type.setdefault(t, jf)
        self.controllers = [c for f in self.files for c in self._controllers(f)]
        self.handlers = [h for f in self.files for h in self._handlers(f)]
        self.exception_status = self._exception_statuses()
        self.jackson = self._jackson()

    # ------------------------------------------------------------ methods
    def _body_start(self, jf, type_name):
        t = jf.types[type_name]
        i = t['at']
        if t['kind'] == 'record':
            i = balanced(jf.text, jf.text.index('(', i))
        return jf.text.index('{', i)

    def _methods(self, jf, type_name):
        """[{annotations, returns, name, params, body, line}] of the methods declared directly in a type."""
        text, out = jf.text, []
        b0 = self._body_start(jf, type_name)
        b1 = balanced(text, b0, '{', '}') - 1
        i, seg = b0 + 1, b0 + 1
        while i < b1:
            c = text[i]
            if c == '"':
                m = _STRING.match(text, i)
                i = m.end() if m else i + 1
                continue
            if c == '(':
                i = balanced(text, i)
                continue
            if c == ';':
                seg = i + 1
            elif c == '{':
                end = balanced(text, i, '{', '}')
                header = text[seg:i]
                anns, rest = annotations(header + ' ')
                m = re.match(r'^(.*?)(\w+)\s*\((.*)\)\s*(?:throws\s+[\w.,\s]+)?$', rest.strip(), re.S)
                if m and not re.search(r'\b(class|record|interface|enum)\b', m.group(1)):
                    returns = re.sub(r'\b(public|protected|private|static|final|synchronized|abstract|default)\b',
                                     ' ', m.group(1)).strip()
                    out.append({'annotations': anns, 'returns': returns, 'name': m.group(2), 'params': m.group(3),
                                'body': text[i:end], 'line': jf.line_of(seg + len(header) - len(header.lstrip()))})
                i = seg = end
                continue
            i += 1
        return out

    def _class_annotations(self, jf, type_name):
        anns, _ = annotations(re.sub(r'\b(public|final|abstract)\b', ' ', jf.types[type_name]['head']) + ' ')
        return anns

    # ------------------------------------------------------------ controllers
    def _controllers(self, jf):
        found = []
        for tname, t in jf.types.items():
            anns = dict(self._class_annotations(jf, tname))
            if 'RestController' not in anns and 'Controller' not in anns:
                continue
            base = literal(anns.get('RequestMapping')) or ''
            for meth in self._methods(jf, tname):
                ann = dict(meth['annotations'])
                verb, path = None, None
                for a, v in VERBS.items():
                    if f'{a}Mapping' in ann:
                        verb, path = v, literal(ann[f'{a}Mapping']) or ''
                if verb is None and 'RequestMapping' in ann:
                    m = re.search(r'RequestMethod\.(\w+)', ann['RequestMapping'] or '')
                    verb, path = (m.group(1) if m else 'ANY'), literal(ann['RequestMapping']) or ''
                if verb is None:
                    continue
                params = []
                for p in split_top(meth['params']):
                    pa, rest = annotations(p + ' ')
                    bits = rest.split()
                    pname = bits[-1] if bits else ''
                    ptype = ' '.join(bits[:-1])
                    pad = dict(pa)
                    kind = 'body' if 'RequestBody' in pad else 'path' if 'PathVariable' in pad else \
                        'query' if 'RequestParam' in pad else 'header' if 'RequestHeader' in pad else 'other'
                    key = 'PathVariable' if kind == 'path' else 'RequestParam' if kind == 'query' else None
                    params.append({'kind': kind, 'type': element_type(ptype)[0] if ptype else '', 'name':
                                   (literal(pad.get(key)) if key else None) or pname,
                                   'valid': 'Valid' in pad or 'Validated' in pad})
                status = None
                if 'ResponseStatus' in ann:
                    status = status_name(ann['ResponseStatus'] or '')
                if status is None:
                    for k, v in ENTITY_STATUS.items():
                        if re.search(r'ResponseEntity\s*\.\s*' + k + r'\s*\(', meth['body']):
                            status = v
                            break
                if status is None:
                    status = status_name(meth['body']) or 200
                ret, many = element_type(re.sub(r'^ResponseEntity\s*<\s*(.*)>$', r'\1', meth['returns']))
                found.append({'controller': tname, 'file': jf.rel, 'line': meth['line'], 'method': meth['name'],
                              'verb': verb, 'path': join_path(base, path), 'params': params,
                              'requestBody': next((p['type'] for p in params if p['kind'] == 'body'), None),
                              'responseType': ret, 'responseIsList': many, 'status': status})
        return found

    def mapping_for(self, verb, path):
        """(controller method, how) for an HTTP request; (None, why) when no mapping takes it."""
        path = '/' + path.split('?', 1)[0].strip('/')
        same_path = []
        for c in self.controllers:
            if path_matches(c['path'], path):
                same_path.append(c)
                if c['verb'] in (verb, 'ANY'):
                    return c, 'mapped'
        if same_path:
            return None, f'path {path} is mapped for {sorted({c["verb"] for c in same_path})}, not {verb} (405)'
        return None, f'no controller maps {verb} {path} (404)'

    # ------------------------------------------------------------ DTOs
    def fields(self, type_name, depth=0):
        """{json name: {type, list, nested {...}}} of a DTO, or None when the type is not in the sources."""
        jf = self.by_type.get(type_name)
        if jf is None or type_name in _SIMPLE or depth > 3:
            return None
        t = jf.types[type_name]
        out = {}
        if t['kind'] == 'record':
            p0 = jf.text.index('(', t['at'])
            comps = split_top(jf.text[p0 + 1:balanced(jf.text, p0) - 1])
        elif t['kind'] == 'class':
            b0 = jf.text.index('{', t['at'])
            body = jf.text[b0 + 1:balanced(jf.text, b0, '{', '}') - 1]
            flat = re.sub(r'\{[^{}]*\}', ';', body)
            flat = re.sub(r'\{[^{}]*\}', ';', flat)
            comps = [s.strip() for s in flat.split(';') if s.strip() and '(' not in re.sub(r'@\w+\([^)]*\)', '', s)
                     and not re.search(r'\bstatic\b', s)]
            comps = [re.sub(r'=.*$', '', c, flags=re.S).strip() for c in comps]
            comps = [re.sub(r'\b(private|protected|public|final|transient)\b', ' ', c) for c in comps]
        else:
            return None
        for comp in comps:
            anns, rest = annotations(comp + ' ')
            bits = rest.split()
            if len(bits) < 2:
                continue
            name, ftype = bits[-1], ' '.join(bits[:-1])
            ad = dict(anns)
            if 'JsonIgnore' in ad:
                continue
            json_name = literal(ad.get('JsonProperty')) or name
            elem, many = element_type(ftype)
            entry = {'field': name, 'type': elem, 'list': many}
            nested = self.fields(elem, depth + 1) if elem not in _SIMPLE else None
            if nested is not None:
                entry['nested'] = nested
            if 'JsonAlias' in ad:
                entry['aliases'] = re.findall(r'"((?:\\.|[^"\\])*)"', ad['JsonAlias'] or '')
            out[json_name] = entry
        return out

    # ------------------------------------------------------------ exception handling
    def _handlers(self, jf):
        found = []
        for tname, t in jf.types.items():
            anns = dict(self._class_annotations(jf, tname))
            if 'RestControllerAdvice' not in anns and 'ControllerAdvice' not in anns:
                continue
            consts = jf.constants()
            for meth in self._methods(jf, tname):
                ann = dict(meth['annotations'])
                if 'ExceptionHandler' not in ann:
                    continue
                types = re.findall(r'(\w+)\.class', ann['ExceptionHandler'] or '')
                if not types:
                    types = [element_type(' '.join(p.split()[:-1]))[0] for p in split_top(meth['params'])][:1]
                status = status_name(ann.get('ResponseStatus') or '') if 'ResponseStatus' in ann else None
                status = status or status_name(meth['body'])
                code = None
                m = re.search(r'HttpStatus\.[A-Z_]+\s*,\s*("(?:\\.|[^"\\])*"|\w+)', meth['body'])
                if m:
                    code = m.group(1).strip('"') if m.group(1).startswith('"') else consts.get(m.group(1), m.group(1))
                found.append({'advice': tname, 'file': jf.rel, 'line': meth['line'], 'method': meth['name'],
                              'exceptions': types, 'status': status, 'code': code})
        return found

    def _exception_statuses(self):
        """{exception type: {status, by}} from the handlers, then @ResponseStatus on the exception classes."""
        out = {}
        for h in self.handlers:
            for e in h['exceptions']:
                out.setdefault(e, {'status': h['status'], 'code': h['code'], 'by': f'{h["advice"]}.{h["method"]}'})
        for jf in self.files:
            for tname in jf.types:
                anns = dict(self._class_annotations(jf, tname))
                if 'ResponseStatus' in anns and tname not in out:
                    out[tname] = {'status': status_name(anns['ResponseStatus'] or ''), 'code': None,
                                  'by': f'@ResponseStatus on {tname}'}
        return out

    def statuses_answering(self, status):
        return sorted(e for e, v in self.exception_status.items() if v.get('status') == status)

    def throws_of(self, home):
        """`Class.method` -> {exception: status} of the `throw new X(` in that method (all overloads)."""
        if not home or '.' not in home:
            return None
        cls, meth = home.split('.', 1)
        meth = re.sub(r'\(.*$', '', meth).strip()
        if self.by_type.get(cls.strip('` ')) is None:
            return None
        found, seen, todo = {}, set(), [(cls.strip('` '), meth, 0)]
        while todo:
            tname, name, depth = todo.pop()
            jf = self.by_type.get(tname)
            if jf is None or (tname, name) in seen or depth > 5:
                continue
            seen.add((tname, name))
            members = self._methods(jf, tname)
            own = {m['name'] for m in members}
            fields = dict((f, t) for t, f in re.findall(r'(?:private|protected)\s+(?:final\s+)?(\w+)\s+(\w+)\s*[;=]',
                                                         jf.text))
            for m in members:
                if m['name'] != name:
                    continue
                for e in re.findall(r'throw\s+new\s+(\w+)\s*\(', m['body']):
                    found[e] = (self.exception_status.get(e) or {}).get('status')
                todo.extend((tname, c, depth + 1) for c in set(re.findall(r'(?<![\w.])(\w+)\s*\(', m['body']))
                            if c in own)
                todo.extend((fields[o], c, depth + 1) for o, c in set(re.findall(r'\b(\w+)\.(\w+)\s*\(', m['body']))
                            if o in fields and fields[o] in self.by_type)
        return found

    # ------------------------------------------------------------ configuration
    def _jackson(self):
        """spring.jackson.deserialization.fail-on-unknown-properties of the product (Spring Boot default: false)."""
        value, where = False, 'Spring Boot default'
        for base, dirs, names in os.walk(self.root) if self.root.is_dir() else []:
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
            for name in names:
                if not re.fullmatch(r'application\.(ya?ml|properties)', name):
                    continue
                text = read_text(Path(base) / name)
                m = re.search(r'fail-on-unknown-properties\s*[:=]\s*(\w+)', text) or \
                    re.search(r'FAIL_ON_UNKNOWN_PROPERTIES\s*[:=]\s*(\w+)', text)
                if m:
                    value, where = m.group(1).lower() == 'true', (Path(base) / name).relative_to(self.root).as_posix()
        return {'failOnUnknownProperties': value, 'from': where}


def join_path(base, path):
    joined = '/'.join(x.strip('/') for x in (base, path) if x and x.strip('/'))
    return '/' + joined


def path_matches(template, path):
    rx = '^' + re.sub(r'\\\{[^}]*\\\}', '[^/]+', re.escape(template.rstrip('/') or '/')) + '/?$'
    return re.match(rx, path.rstrip('/') or '/') is not None


def body_fields(body, prefix=''):
    """Flat JSON paths of a request body: `a`, `details[].b`."""
    out = []
    if isinstance(body, dict):
        for k, v in body.items():
            out.append(prefix + k)
            if isinstance(v, dict):
                out.extend(body_fields(v, prefix + k + '.'))
            elif isinstance(v, list) and v and isinstance(v[0], dict):
                keys = {}
                for item in v:
                    if isinstance(item, dict):
                        keys.update(dict.fromkeys(item))
                out.extend(body_fields(dict.fromkeys(keys, None), prefix + k + '[].'))
    return out


def unknown_fields(body, dto):
    """Body paths the DTO has no property for (matched by JSON name or alias)."""
    if not isinstance(body, dict) or dto is None:
        return []
    out = []
    for k, v in body.items():
        f = dto.get(k) or next((x for x in dto.values() if k in (x.get('aliases') or [])), None)
        if f is None:
            out.append(k)
            continue
        nested = f.get('nested')
        if nested is None:
            continue
        items = v if isinstance(v, list) else [v]
        seen = set()
        for item in items:
            for u in unknown_fields(item, nested):
                if u not in seen:
                    seen.add(u)
                    out.append(f'{k}[].{u}' if isinstance(v, list) else f'{k}.{u}')
    return out
