"""What the build log of a replay run says per scenario (text only, no Maven): the exception each scenario's Cucumber
block carries (the product's `APP` log lines are interleaved there), the surefire ERROR/FAILURE sections, and the
scenarios of the register (e2e/scenarios/<entry>.json) the framework report lacks - SKIPPED, with the log's reason."""

import re

from vlib.common import read_json, read_text

_SCENARIO = re.compile(r'^Scenario(?: Outline)?:\s+(\S+)')
_EXC = re.compile(r'^\s*(Caused by:\s*)?((?:[a-zA-Z_$][\w$]*\.)+[A-Z][\w$]*(?:Exception|Error|Failure))(?::\s?(.*))?$')
_FRAME = re.compile(r'^\s*at\s+([\w$.]+)\.([\w$<>]+)\(([^)]*)\)')
_APP = re.compile(r'^APP\s+\S+\s+(ERROR|WARN|INFO|DEBUG|TRACE)\s+(\S+)\s+-\s+(.*)$')
_SUREFIRE = re.compile(r'^\[ERROR\]\s+(?:\S+\.)?([^\s.]+)\s.*?\s--\s+Time elapsed.*<<<\s+(ERROR|FAILURE)!')
_END = re.compile(r'^\[(?:INFO|ERROR|WARNING)\]\s+(?:Tests run:|Results:)')
_STEP = re.compile(r'^\s*(?:Given|When|Then|And|But|\*)\s')
NOISE = ('java.lang.AssertionError', 'org.opentest4j.', 'org.junit.', 'io.cucumber.')
FRAMEWORK = ('java.', 'javax.', 'jakarta.', 'jdk.', 'sun.', 'com.sun.', 'org.springframework.', 'org.apache.',
             'org.hibernate.', 'com.zaxxer.', 'com.ibm.', 'com.fasterxml.', 'io.cucumber.', 'org.junit.',
             'org.opentest4j.', 'com.insurance.e2e.', 'org.eclipse.', 'io.micrometer.', 'reactor.', 'io.netty.',
             'org.slf4j.', 'ch.qos.', 'net.bytebuddy.', 'org.mockito.', 'org.aspectj.', 'e2e.')
WEB = re.compile(r'\.(?:web|controller|rest|api)\.|(?:Controller|ControllerAdvice|ExceptionHandler|Handler|Filter)$')
BINDING_TYPES = re.compile(r'MethodArgumentNotValid|HttpMessageNotReadable|HttpMediaTypeNotSupported|'
                           r'HttpRequestMethodNotSupported|MissingServletRequest|MissingPathVariable|ConstraintViolation|'
                           r'BindException|TypeMismatch|NoHandlerFound|NoResourceFound')
MESSAGE = 400


def app_frame(cls):
    return not cls.startswith(FRAMEWORK) and '$$' not in cls and not cls.startswith('?')


def _exceptions(lines):
    """The exceptions of a block of log lines: [{type, message, causedBy, frame, appFrames, logged, source}]."""
    out, cur, logged, i = [], None, None, 0
    while i < len(lines):
        line = lines[i]
        m = _APP.match(line)
        if m:
            logged = {'level': m.group(1), 'logger': m.group(2), 'message': m.group(3).strip(), 'line': i}
            if m.group(1) in ('ERROR', 'WARN'):
                out.append({'type': None, 'message': m.group(3).strip()[:MESSAGE], 'causedBy': [], 'frame': None,
                            'appFrames': [], 'logged': f'{m.group(1)} {m.group(2)} - {m.group(3).strip()}'[:MESSAGE],
                            'source': 'application'})
                cur = out[-1]
            i += 1
            continue
        m = _EXC.match(line)
        if m and m.group(2).startswith(NOISE):                   # the harness's verdict, not an exception
            cur = None
            i += 1
            continue
        if m:
            text = [(m.group(3) or '').strip()]
            j = i + 1
            while j < len(lines) and len(text) < 4:
                nxt = lines[j]
                if not nxt.strip() or _FRAME.match(nxt) or _EXC.match(nxt) or _APP.match(nxt) or _STEP.match(nxt) \
                        or nxt.lstrip().startswith(('[', '...', 'Caused by')) or _SCENARIO.match(nxt):
                    break
                text.append(nxt.strip())
                j += 1
            message = ' '.join(t for t in text if t)[:MESSAGE]
            if m.group(1) and cur is not None:                     # Caused by: of the exception above
                cur['causedBy'].append(f'{m.group(2)}: {message}'.rstrip(': ')[:MESSAGE])
            elif cur is not None and cur['type'] is None and cur['source'] == 'application' \
                    and logged and i - logged['line'] <= 2:         # the stack of the APP line just above
                cur.update(type=m.group(2), message=message or cur['message'])
            else:
                out.append({'type': m.group(2), 'message': message, 'causedBy': [], 'frame': None, 'appFrames': [],
                            'logged': None, 'source': 'harness' if m.group(2).startswith('com.insurance.e2e.')
                            else 'log'})
                cur = out[-1]
            i = j
            continue
        m = _FRAME.match(line)
        if m and cur is not None:
            cls, method, where = m.groups()
            if app_frame(cls):
                simple = f'{cls.rsplit(".", 1)[-1]}.{method}'
                if cur['frame'] is None:
                    cur['frame'] = f'{cls}.{method}({where})'
                    cur['frameClass'] = cls
                if simple not in cur['appFrames'] and len(cur['appFrames']) < 8:
                    cur['appFrames'].append(simple)
        i += 1
    return out


def scenario_log(path):
    """{scenarioId: {'exceptions': [...], 'surefire': {kind, exceptions} | None}} of one replay build log."""
    try:
        lines = read_text(path).splitlines()
    except OSError:
        return {}
    blocks, cur, start = {}, None, 0
    sure, s_cur, s_start = {}, None, 0

    def close_block(end):
        if cur:
            blocks.setdefault(cur, []).extend(lines[start:end])

    for n, line in enumerate(lines):
        m = _SCENARIO.match(line)
        if m or _END.match(line):
            close_block(n)
            cur, start = (m.group(1), n + 1) if m else (None, n)
        m = _SUREFIRE.match(line)
        if m or (s_cur and (line.startswith('[') and n > s_start)):
            if s_cur:
                sure[s_cur]['lines'] = lines[s_start:n]
            s_cur, s_start = (m.group(1), n + 1) if m else (None, n)
            if m:
                sure[s_cur] = {'kind': m.group(2), 'lines': []}
    close_block(len(lines))
    if s_cur:
        sure[s_cur]['lines'] = lines[s_start:]
    out = {}
    for sid in set(blocks) | set(sure):
        sf = sure.get(sid)
        out[sid] = {'exceptions': _exceptions(blocks.get(sid) or []),
                    'surefire': {'kind': sf['kind'], 'exceptions': _exceptions(sf['lines'])} if sf else None}
    return out


def product_exception(entry):
    """The exception the product logged for the scenario (its APP line and stack), else None."""
    found = [x for x in (entry or {}).get('exceptions') or [] if x['source'] == 'application']
    return next((x for x in found if x['type']), found[0] if found else None)


def first_exception(entry):
    """The first exception of the scenario's surefire section, else of its Cucumber block, else None."""
    sf = (entry or {}).get('surefire') or {}
    return next(iter(sf.get('exceptions') or []), None) or next(iter((entry or {}).get('exceptions') or []), None)


def service_thrown(exc):
    """Whether the exception was thrown by product code below the entry layer (not a request binding failure)."""
    if not exc or not exc.get('type') or not exc.get('frameClass') or BINDING_TYPES.search(exc['type']):
        return False
    return not WEB.search(exc['frameClass'])


def describe(exc):
    if not exc:
        return None
    head = f"{exc['type']}: {exc['message']}" if exc.get('type') else exc.get('logged') or exc.get('message') or ''
    cause = f" (caused by {exc['causedBy'][0].split(':', 1)[0]})" if exc.get('causedBy') else ''
    at = f" at {exc['frame']}" if exc.get('frame') else ''
    return head.rstrip(': ') + cause + at


def build_log(run_dir):
    found = sorted(run_dir.glob('replay-*.log')) if run_dir and run_dir.is_dir() else []
    return found[-1] if found else None


def register_of(path):
    try:
        doc = read_json(path, 'scenario register')
    except Exception:  # noqa: BLE001 - no register: nothing to compare
        return []
    return [s for s in (doc.get('scenarios') or []) if s.get('scenarioId')]


def missing(register, report, log_entries):
    """Rows SKIPPED for the register scenarios the framework report lacks, the log's reason in each."""
    seen = {s.get('scenarioId') for s in report.get('scenarios') or []}
    rows = []
    for r in register:
        sid = r['scenarioId']
        if sid in seen:
            continue
        entry = log_entries.get(sid)
        exc = first_exception(entry)
        kind = ((entry or {}).get('surefire') or {}).get('kind')
        why = describe(exc)
        reason = ('not in the framework report' + (f' (surefire {kind})' if kind else '')
                  + (f': {why}' if why else ': no result and no log evidence for the scenario'))
        rows.append({'scenarioId': sid, 'level': None, 'unit': None, 'mode': 'REPLAY', 'status': 'SKIPPED',
                     'message': reason, 'title': r.get('title'), 'missingFromReport': True,
                     'evidence': exc, 'hypotheses': []})
    return rows


def with_missing(report, register, log_path):
    """The report with a SKIPPED row per register scenario it lacks (the report itself is not changed)."""
    if report is None or not register:
        return report, []
    rows = missing(register, report, scenario_log(log_path) if log_path else {})
    if not rows:
        return report, []
    return {**report, 'scenarios': list(report.get('scenarios') or []) + rows}, rows
