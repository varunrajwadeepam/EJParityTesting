"""Read-only Db2 queries through the db2 container's CLP (`docker exec <container> ... db2`), as run-cobol's
db2_run does. MU_VALIDATE_CONTAINER_CLI replaces docker/podman (a JSON array; selftest stand-ins)."""

import os
import re

from .common import Stop, command, run

ERROR_ID = re.compile(r'\b(SQL\d{4,5}N|DB2\d{4,5}E)\b')
NOT_AN_ERROR = {'DB21034E'}
IDENT = re.compile(r'^[A-Z][A-Z0-9_]{0,127}$')


def container_cli():
    cmd = command('MU_VALIDATE_CONTAINER_CLI', 'docker') or command('MU_VALIDATE_CONTAINER_CLI', 'podman')
    if not cmd:
        raise Stop('no container CLI on PATH (docker, podman): the Db2 queries go through the db2 container')
    return cmd


def clp(db, sql):
    """Run `sql` (read-only statements, `;`-terminated) as db['user'] in db['database']; returns the output
    lines. Raises Stop when the CLP fails."""
    script = f"connect to {db['database']} user {db['user']} using {db['password']};\n{sql}\n"
    path = f'/tmp/mu_validate_{os.getpid()}.sql'
    inner = (f"cat > {path} && chmod 644 {path} && su - db2inst1 -c 'db2 -txf {path}'; "
             f'rc=$?; rm -f {path}; exit $rc')
    code, out = run([*container_cli(), 'exec', '-i', db['container'], 'sh', '-c', inner],
                    stdin=script.encode('utf-8'), timeout=300)
    errors = [m for m in ERROR_ID.findall(out) if m not in NOT_AN_ERROR]
    if code >= 4 or errors:
        tail = ' | '.join(line.strip() for line in out.strip().splitlines()[-4:])
        raise Stop(f"Db2 in container {db['container']} not reached or the query failed (rc {code}, "
                   f"{', '.join(errors) or 'no message id'}): {tail}")
    return out.splitlines()


def _marked(lines, mark):
    out = []
    for line in lines:
        s = line.strip()
        if s.startswith(mark + '|'):
            out.append(s[len(mark) + 1:].strip())
    return out


def schemas(db, like):
    """Schema names matching a LIKE pattern."""
    lines = clp(db, f"select 'S|' || rtrim(schemaname) from syscat.schemata where schemaname like '{like}';")
    return sorted(_marked(lines, 'S'))


def tables(db, schema):
    """{table: row count} of the base tables in `schema` ({} when it has none or does not exist)."""
    if not IDENT.match(schema):
        raise Stop(f'{schema!r} is not a plain Db2 schema name')
    lines = clp(db, f"select 'T|' || rtrim(tabname) from syscat.tables where tabschema = '{schema}' "
                    "and type = 'T' order by tabname;")
    names = _marked(lines, 'T')
    if not names:
        return {}
    union = ' union all '.join(f"select 'C|{t}|' || rtrim(char(count(*))) from \"{schema}\".\"{t}\"" for t in names)
    counts = {}
    for item in _marked(clp(db, union + ';'), 'C'):
        t, _, n = item.partition('|')
        counts[t.strip()] = int(n.strip() or 0)
    return {t: counts.get(t, 0) for t in names}
