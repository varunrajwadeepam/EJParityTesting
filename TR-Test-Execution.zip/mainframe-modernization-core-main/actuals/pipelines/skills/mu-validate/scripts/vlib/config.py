"""The MU as mu-validate reads it: mu.yaml, tools.yaml (through ${CLAUDE_PLUGIN_ROOT}/scripts/tools_config.py) and the
paths of the test solution and the working folder."""

import importlib.util
import os
import re
from pathlib import Path

from .common import TOOLS_CONFIG, Stop, read_text

TEST_SOLUTION = 'validation'
FRAMEWORK = 'tools/e2e-framework'
INPUT_FILES = ('design/rules.md', 'design/tests.md', 'extracted-logic/paragraph-index.json', 'unit/schema.sql')

_TC = {}


def tools_config():
    if 'm' not in _TC:
        spec = importlib.util.spec_from_file_location('tools_config', TOOLS_CONFIG)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        _TC['m'] = mod
    return _TC['m']


def load_yaml(path):
    import yaml
    return yaml.safe_load(read_text(path)) or {}


def schema_name(mu_name):
    return 'E2E_' + re.sub(r'[^A-Z0-9_]', '_', str(mu_name).upper())


def disk_case(path):
    """`path` with every part spelled as on disk (a case-insensitive file system accepts `mu/P510` for `mu/p510`)."""
    parts = Path(path).parts
    out = Path(parts[0])
    for part in parts[1:]:
        try:
            out = out / next((p.name for p in out.iterdir() if p.name.lower() == part.lower()), part)
        except OSError:
            out = out / part
    return out


class Ctx:
    """Paths are absolute; `mu_arg` is the MU folder relative to the workspace, as on disk (used in fix commands)."""

    def __init__(self, mu, entry=None, workspace=None):
        self.workspace = Path(workspace or Path.cwd()).resolve()
        self.mu_arg = Path(mu).as_posix().rstrip('/')
        self.mu = (self.workspace / mu).resolve() if not Path(mu).is_absolute() else Path(mu).resolve()
        if not (self.mu / 'mu.yaml').is_file():
            raise Stop(f'{self.mu_arg}/mu.yaml not found: run from the workspace root with the MU folder (mu/<MU>)')
        self.mu = disk_case(self.mu)
        try:
            self.mu_arg = self.mu.relative_to(disk_case(self.workspace)).as_posix()
        except ValueError:
            self.mu_arg = self.mu.as_posix()
        self.manifest = load_yaml(self.mu / 'mu.yaml')
        self.name = str(self.manifest.get('name') or self.mu.name)
        entries = [str(e) for e in self.manifest.get('entry_points') or []]
        if entry is None:
            if not entries:
                raise Stop('mu.yaml names no entry point: pass --entry <ENTRY>')
            entry = entries[0]
        elif entries and entry not in entries:
            raise Stop(f'--entry {entry} is not in mu.yaml entry_points {entries}')
        self.entry = entry
        self.entries = entries
        self.tools_file = self.mu / 'tools.yaml'
        # read only: the package and the inputs it rests on
        self.tests = self.mu / 'tests'
        self.tests_state = self.tests / 'tests-state.json'
        self.tests_questions = self.tests / 'tests-open-questions.md'
        self.package_dir = self.tests / 'package' / entry
        self.package = self.package_dir / f'{entry}-tests.json'
        # the product and the framework (read only)
        sol = self.manifest.get('solution')
        self.solution = (self.workspace / str(sol)).resolve() if sol else None
        # the test solution (shared by every MU)
        self.validation = self.workspace / TEST_SOLUTION
        self.target = self.validation / 'target'
        self.m2 = self.target / 'm2'
        self.products = self.target / 'product'
        self.logs = self.target / 'logs'
        # the working folder of this MU
        self.work = self.mu / 'validation'
        self.e2e = self.work / 'e2e'
        self.runs = self.work / 'runs'
        self.state_file = self.work / 'validation-state.json'
        self.questions = self.work / 'validation-open-questions.md'
        self.report = self.work / 'validation-report.md'
        self.failures = self.work / 'failures.md'
        self.tmp = self.work / '.tmp'
        self.solution_override = None
        over = self._stored_override()
        if over:
            self.use_solution(over)

    def _stored_override(self):
        """`solutionOverride` of validation-state.json (set by `snapshot --solution DIR`)."""
        import json
        try:
            return json.loads(read_text(self.state_file)).get('solutionOverride') if self.state_file.is_file() else None
        except ValueError:
            return None

    def use_solution(self, folder):
        """Take the product from `folder` (workspace-relative or absolute) instead of mu.yaml `solution`."""
        p = Path(os.path.expanduser(str(folder)))
        self.solution = (p if p.is_absolute() else self.workspace / p).resolve()
        self.solution_override = self.rel(self.solution)

    # ------------------------------------------------------------ tools.yaml
    def raw_tools(self):
        return load_yaml(self.tools_file) if self.tools_file.is_file() else {}

    def tool(self, name, required=False):
        """A tools.yaml section with secrets and {mu} resolved, or None when absent and optional."""
        raw = self.raw_tools()
        if name not in raw or not isinstance(raw.get(name), dict):
            if required:
                raise Stop(f'no section "{name}" in {self.rel(self.tools_file)}')
            return None
        return tools_config().tool(str(self.mu), name)

    @property
    def framework(self):
        sec = self.raw_tools().get('e2e-framework')
        path = sec.get('path') if isinstance(sec, dict) else None
        if path:
            p = Path(os.path.expanduser(str(path)))
            return (p if p.is_absolute() else self.workspace / p).resolve()
        return self.workspace / FRAMEWORK

    @property
    def home_m2(self):
        over = os.environ.get('MU_VALIDATE_M2_TAIL')
        return Path(over).resolve() if over else Path.home() / '.m2' / 'repository'

    def inputs(self):
        from .common import file_sha
        return {f: file_sha(self.mu / f) for f in INPUT_FILES}

    def rel(self, path):
        try:
            return os.path.relpath(Path(path), self.workspace).replace('\\', '/')
        except ValueError:
            return Path(path).as_posix()
