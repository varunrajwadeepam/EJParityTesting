"""mu/<MU>/validation/validation-state.json: what mu-validate knows about one MU between runs.
Written by the scripts only.

  format 1, mu, updatedAt
  steps        {<step>: {at, status, exit}}
  preflight    {e2eDb2 {section, schema, written, tables}, tools {...}}
  readiness    {entry, state, version, contentHash, packageSha256, inputs}
  framework    {version, fingerprint, repository, installedAt}
  snapshot     {hash, revision, dir, builtAt, artifacts}
  questions    {<key>: <VQ-n | RG-n>}
  acceptance   {<scenarioId>: {oracleKey, by, at, gate[, state DISPUTED, reason]}} - the record gate's decisions
  gate         {open, digest, preparedAt, listed {<id>: {oracleKey, change}} | settled, by, at, accepted, disputed}
  runs         [{runId, finishedAt, counts, repeatable, selection, snapshot, summary}]; smoke {status, at, ...}
"""

import copy

from .common import Stop, iso_now, read_json, write_json

FORMAT = 1
SKELETON = {'format': FORMAT, 'mu': None, 'updatedAt': None, 'steps': {}, 'preflight': {}, 'readiness': {},
            'framework': {}, 'snapshot': {}, 'questions': {}, 'acceptance': {}, 'runs': []}


def read(ctx):
    st = copy.deepcopy(SKELETON)
    if ctx.state_file.is_file():
        stored = read_json(ctx.state_file, 'validation state')
        if stored.get('format') != FORMAT:
            raise Stop(f'{ctx.rel(ctx.state_file)} has format {stored.get("format")!r}, this script writes {FORMAT}')
        st.update(stored)
    st['mu'] = ctx.name
    return st


def write(ctx, st):
    st = dict(st)
    st['updatedAt'] = iso_now()
    write_json(ctx.state_file, st)
    return st


def record_step(st, step, code, status):
    st.setdefault('steps', {})[step] = {'at': iso_now(), 'status': status, 'exit': code}


def question_id(st, key, prefix='VQ', taken=()):
    """The stable id of question `key`: the one it got first, else the next free <prefix>-<n>."""
    known = st.setdefault('questions', {})
    if key in known:
        return known[key]
    used = [int(v.split('-', 1)[1]) for v in list(known.values()) + list(taken)
            if v.startswith(prefix + '-') and v.split('-', 1)[1].isdigit()]
    known[key] = f'{prefix}-{max(used, default=0) + 1}'
    return known[key]
