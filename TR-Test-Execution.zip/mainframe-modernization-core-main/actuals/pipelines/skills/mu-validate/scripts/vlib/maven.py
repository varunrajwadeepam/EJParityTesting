"""Maven for mu-validate: batch mode, logged, the private repository validation/target/m2 as the only
written repository and ~/.m2/repository as a read-only tail (Maven 3.9+). MU_VALIDATE_MVN replaces mvn
(a JSON array; selftest stand-ins)."""

import re

from .common import Stop, command, run


def mvn_cmd():
    cmd = command('MU_VALIDATE_MVN', 'mvn')
    if not cmd:
        raise Stop('Maven (mvn) is not on PATH: install Maven 3.9+ and retry')
    return cmd


def repo_flags(head, tail):
    flags = [f'-Dmaven.repo.local={head}']
    if tail is not None:
        flags.append(f'-Dmaven.repo.local.tail={tail}')
    return flags


def mvn(arguments, cwd, log, head, tail, timeout=3600, env=None):
    return run([*mvn_cmd(), '-B', '-ntp', *repo_flags(head, tail), *arguments], cwd=cwd, timeout=timeout, log=log,
               env=env)


def version():
    """(maven version, java version Maven runs on, first line) from `mvn -v`."""
    try:
        code, out = run([*mvn_cmd(), '-v'], timeout=120)
    except Stop as e:
        return None, None, str(e)
    m = re.search(r'Apache Maven (\d+\.\d+(?:\.\d+)?)', out)
    j = re.search(r'Java version: ([0-9][^,\s]*)', out)
    first = out.strip().splitlines()[0] if out.strip() else ''
    return (m.group(1) if m else None), (j.group(1) if j else None), first
