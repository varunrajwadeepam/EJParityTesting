"""Question files in the design convention (plus `Blocking:`):

    ## VQ-<n> - <title>          (RG-<n> for the record gate; PQ-<n> in mu-build-tests' file)

    Step: <step> · Status: open | answered | settled
    Blocking: yes | no
    Question: <...>
    Evidence: <...>              (optional; the record gate's list, one `- ` line each)
    Decision taken: <...>
    Affects: <...>
    Answer: <filled by a person; the next run applies it>

A line that starts no known label continues the field above it. An Answer that is empty or a `<...>`
placeholder is not filled. append() only adds text at the end; entries are never rewritten - except the one
status edit set_status() makes (the `Status:` of one entry, e.g. the preflight's replay-schema VQ settled once
`--e2e-schema` is applied).
"""

import re
from pathlib import Path

from .common import Stop, read_text

HEADER = ('# validation-open-questions.md\n\n'
          'Questions (`VQ-n`) and record gates (`RG-n`) of mu-validate. Answer on the `Answer:` line; '
          '`Blocking: yes` holds the run until it is answered.\n')
_FIELDS = {'Question': 'question', 'Evidence': 'evidence', 'Decision taken': 'decision', 'Affects': 'affects',
           'Answer': 'answer', 'Blocking': 'blocking'}
_LABEL = re.compile(r'^(Question|Evidence|Decision taken|Affects|Answer|Blocking):\s*(.*)$')
_STEP = re.compile(r'^Step:\s*(.*?)\s*(?:[·|]\s*Status:\s*(.*))?$')
_STATUS = re.compile(r'^Status:\s*(.*)$')
STATUSES = ('open', 'answered', 'settled')
PREFIXES = ('VQ', 'RG')


def _head(prefixes):
    return re.compile(r'^##\s+((' + '|'.join(prefixes) + r')-([0-9]+))\s*(?:[-–—]\s*(.*))?$')


def _filled(text):
    t = (text or '').strip()
    return bool(t) and not re.fullmatch(r'<[^>]*>', t)


def parse(path, prefixes=PREFIXES):
    """[{id, prefix, n, title, step, status, blocking (bool), question, decision, affects, answer, answered}]."""
    path = Path(path)
    if not path.is_file():
        return []
    head = _head(prefixes)
    out, cur, key = [], None, None
    for line in read_text(path).splitlines():
        m = head.match(line.strip())
        if m:
            cur = {'id': m.group(1), 'prefix': m.group(2), 'n': int(m.group(3)), 'title': (m.group(4) or '').strip(),
                   'step': '', 'status': '', 'blocking': '', 'question': '', 'evidence': '', 'decision': '',
                   'affects': '', 'answer': ''}
            out.append(cur)
            key = None
            continue
        if cur is None:
            continue
        if line.startswith('#'):
            cur, key = None, None
            continue
        s = line.strip()
        if not s:
            key = None
            continue
        m = _STEP.match(s)
        if m:
            cur['step'] = m.group(1).strip()
            if m.group(2) is not None:
                cur['status'] = m.group(2).strip()
            key = None
            continue
        m = _STATUS.match(s)
        if m:
            cur['status'] = m.group(1).strip()
            key = None
            continue
        m = _LABEL.match(s)
        if m:
            key = _FIELDS[m.group(1)]
            cur[key] = m.group(2).strip()
            continue
        if key:
            cur[key] = (cur[key] + '\n' + s).strip()
    for e in out:
        st = e['status'].lower()
        e['status'] = next((x for x in STATUSES if st == x), st if st and '|' not in st else 'open')
        e['blocking'] = e['blocking'].strip().lower().startswith('y')
        e['answered'] = _filled(e['answer'])
        if not e['answered']:
            e['answer'] = ''
    return out


def answered(entries):
    return [e for e in entries if e['answered'] and e['status'] != 'settled']


def open_entries(entries):
    return [e for e in entries if not e['answered'] and e['status'] != 'settled']


def open_blocking(entries):
    return [e for e in open_entries(entries) if e['blocking']]


def next_id(entries, prefix='VQ'):
    return f"{prefix}-{max([e['n'] for e in entries if e['prefix'] == prefix] or [0]) + 1}"


def summary(entries):
    return {'total': len(entries), 'open': [e['id'] for e in open_entries(entries)],
            'blocking': [e['id'] for e in open_blocking(entries)], 'answered': [e['id'] for e in answered(entries)],
            'settled': [e['id'] for e in entries if e['status'] == 'settled']}


def _one_line(v):
    return re.sub(r'\s*\n\s*', ' ', str(v or '')).strip()


def _evidence_line(v):
    t = _one_line(v)
    if t.startswith('#') or _LABEL.match(t) or _STEP.match(t) or _STATUS.match(t):
        t = '- ' + t                                       # never read as a heading or another field
    return t


def render(eid, entry):
    blocking = 'yes' if entry.get('blocking') in (True, 'yes', 'y', 'true') else 'no'
    evidence = [x for x in (_evidence_line(v) for v in entry.get('evidence') or []) if x]
    return (f"## {eid} - {_one_line(entry['title'])}\n\n"
            f"Step: {_one_line(entry.get('step')) or '-'} · Status: {entry.get('status') or 'open'}\n"
            f"Blocking: {blocking}\n"
            f"Question: {_one_line(entry['question'])}\n"
            + ''.join(f'{x}\n' for x in (['Evidence:'] + evidence if evidence else []))
            + f"Decision taken: {_one_line(entry['decision'])}\n"
            f"Affects: {_one_line(entry.get('affects')) or '-'}\n"
            f"Answer: {_one_line(entry.get('answer'))}\n")


def append(path, entry, prefix='VQ'):
    """Append one entry (title, question, decision; optional step, status, blocking, evidence (lines), affects,
    answer, id). Returns the id."""
    path = Path(path)
    entries = parse(path)
    eid = entry.get('id') or next_id(entries, prefix)
    if not re.fullmatch(r'(VQ|RG)-[0-9]+', eid):
        raise Stop(f'bad question id {eid}')
    if any(e['id'] == eid for e in entries):
        raise Stop(f'{eid} already exists in {path.as_posix()}')
    for k in ('title', 'question', 'decision'):
        if not _one_line(entry.get(k)):
            raise Stop(f'a question needs {k}')
    if (entry.get('status') or 'open') not in STATUSES:
        raise Stop(f'status {entry.get("status")} is not one of {STATUSES}')
    path.parent.mkdir(parents=True, exist_ok=True)
    existing = read_text(path) if path.is_file() else ''
    with open(path, 'a', encoding='utf-8', newline='\n') as fh:
        if not existing:
            fh.write(HEADER)
            existing = HEADER
        if not existing.endswith('\n'):
            fh.write('\n')
        fh.write('\n' + render(eid, entry))
    return eid


def set_status(path, eid, status):
    """Set the `Status:` of entry `eid` (its `Step: ... · Status: ...` line, or its own `Status:` line); every other
    byte stays. Returns True when the file changed."""
    if status not in STATUSES:
        raise Stop(f'status {status} is not one of {STATUSES}')
    path = Path(path)
    lines = read_text(path).split('\n')
    head = _head(PREFIXES)
    inside = False
    for i, line in enumerate(lines):
        m = head.match(line.strip())
        if m:
            inside = m.group(1) == eid
            continue
        if not inside:
            continue
        if line.startswith('#'):
            break
        bare = line.rstrip('\r')
        m = re.match(r'^(\s*Step:\s*.*?\s*[·|]\s*Status:\s*)(\S+)(.*)$', bare) or \
            re.match(r'^(\s*Status:\s*)(\S+)(.*)$', bare)
        if m:
            if m.group(2) == status:
                return False
            lines[i] = m.group(1) + status + m.group(3) + line[len(bare):]
            with open(path, 'w', encoding='utf-8', newline='') as fh:
                fh.write('\n'.join(lines))
            return True
    raise Stop(f'{eid} has no Status line in {path.as_posix()}')
