"""The e2e_v1 library's configuration built from the MU: mu.yaml, tools.yaml, the paths of step 2 section 2.
Replaces ``e2elib.config.read``. No legacy-source folder: the recordings' members are hashed against
mu/<MU>/unit/<E>/sources only (never read or printed); no other legacy folder."""

import sys

from .common import SCRIPTS

if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))


def e2e_config(ctx):
    sec = ctx.tool('e2e-db2') or {}
    return {
        'muId': ctx.name,
        'portfolio': ctx.name,
        'paths': {
            'goldenPackages': str(ctx.tests / 'package'),
            'solution': str(ctx.solution) if ctx.solution else None,
            'e2eSolution': str(ctx.validation),
            'legacySources': [],                   # members: unit/<E>/sources via engine.catalogueDir
            'parityTester': None,                  # RECORD / LIVE not supported (decision 8)
            'baArtifacts': None,
        },
        # the driver fingerprint: mu/<MU>/unit/<E>/driver.cbl (step 2a)
        'engine': {'catalogueDir': str(ctx.mu / 'unit')},
        # the DDL the recordings name, found by its sha256 (step 2a)
        'database': {'ddlSources': [str(ctx.mu / 'unit' / 'schema.sql')],
                     'schema': str(sec.get('schema') or '').upper() or None},
        'target': {},
    }


def identity(config):
    """No caller identity in pipelines_v2 yet: a call made as a user is BLOCKED (e2e_v1's rule)."""
    return None
