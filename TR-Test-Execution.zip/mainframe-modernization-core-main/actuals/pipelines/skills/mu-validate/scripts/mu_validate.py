#!/usr/bin/env python3
"""mu-validate step runner: one MU's test package replayed against the product.

    python -B ${CLAUDE_PLUGIN_ROOT}/skills/mu-validate/scripts/mu_validate.py <step> <mu> [--entry E] [step options]
    python -B ${CLAUDE_PLUGIN_ROOT}/skills/mu-validate/scripts/mu_validate.py status <mu> [--entry E]
    python -B ${CLAUDE_PLUGIN_ROOT}/skills/mu-validate/scripts/mu_validate.py questions <mu> [list | add --title T --question Q
                                    --decision D [--affects A] [--step S] [--blocking yes|no] [--gate]]

Steps: preflight [--e2e-schema NAME], readiness, framework [--force] [--with-tests],
snapshot [--status] [--rebuild] [--solution DIR], solution, import, fixtures, lint, gate prepare|apply,
execute [--runs N] [--tags EXPR] [--smoke], analyse [--run RUN_ID], report. Each prints one JSON object,
exits 0 done, 2 decision or input needed, 1 failed, and records its outcome in
mu/<MU>/validation/validation-state.json (snapshot --status writes nothing).
"""

import sys
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))

from steps import analyse, execute, fixtures, framework, gate, importer, preflight, readiness, report, snapshot  # noqa: E402
from steps import lint, solution  # noqa: E402
from vlib import questions as vq, state  # noqa: E402
from vlib.common import Parser, Stop, file_sha, main, package_hash  # noqa: E402
from vlib.config import Ctx  # noqa: E402

STEPS = {'preflight': preflight, 'readiness': readiness, 'framework': framework, 'snapshot': snapshot,
         'solution': solution, 'import': importer, 'fixtures': fixtures, 'lint': lint, 'gate': gate, 'execute': execute,
         'analyse': analyse, 'report': report}


def build_parser():
    ap = Parser(prog='mu_validate', description='mu-validate step runner')
    sub = ap.add_subparsers(dest='command', required=True, parser_class=Parser)
    for name, mod in STEPS.items():
        sp = sub.add_parser(name)
        sp.add_argument('mu', help='the MU folder, mu/<MU>')
        sp.add_argument('--entry', help='entry point (default: the first of mu.yaml entry_points)')
        sp.add_argument('--json', action='store_true', help='accepted; the answer is always one JSON object')
        mod.add_arguments(sp)
    sp = sub.add_parser('status')
    sp.add_argument('mu')
    sp.add_argument('--entry')
    sp.add_argument('--json', action='store_true')
    sp = sub.add_parser('questions')
    sp.add_argument('mu')
    sp.add_argument('--entry')
    sp.add_argument('--json', action='store_true')
    sp.add_argument('action', nargs='?', default='list', choices=['list', 'add'])
    sp.add_argument('--title')
    sp.add_argument('--question')
    sp.add_argument('--decision')
    sp.add_argument('--affects')
    sp.add_argument('--step')
    sp.add_argument('--blocking', choices=['yes', 'no'], default='no')
    sp.add_argument('--gate', action='store_true', help='a record gate entry (RG-n) instead of a VQ-n')
    return ap


def latest_run(st):
    return max((r for r in st.get('runs') or []), key=lambda r: (r.get('finishedAt') or '', r.get('runId') or ''),
               default=None)


def run_not_current(run, snap_hash, pkg_hash):
    """Why the run is not of the current product and package; None when it is."""
    if not run:
        return None
    rec = run.get('snapshotHash') or run.get('snapshot')
    if not snap_hash or not rec or not snap_hash.startswith(str(rec)):
        return f'run {run.get("runId")} replayed snapshot {str(rec or "unrecorded")[:16]}, the product is now ' \
               f'{str(snap_hash or "unknown")[:16]}'
    if run.get('contentHash') != pkg_hash:
        return f'run {run.get("runId")} replayed package {str(run.get("contentHash") or "unrecorded")[:12]}, the ' \
               f'package is now {str(pkg_hash or "-")[:12]}'
    return None


def staleness(ctx, st):
    """Per implemented step why it has to run (again); None when current."""
    steps = st.get('steps') or {}
    why = {}
    for name in STEPS:
        last = steps.get(name)
        why[name] = 'not run' if not last else (f'last run exit {last.get("exit")}' if last.get('exit') else None)
    rd = st.get('readiness') or {}
    pkg_hash = package_hash(ctx.package)
    if why['readiness'] is None:
        if rd.get('packageSha256') != file_sha(ctx.package):
            why['readiness'] = 'the package changed since'
        elif rd.get('inputs') and rd['inputs'] != ctx.inputs():
            why['readiness'] = 'a design or unit input changed since'
    if why['framework'] is None:
        try:
            _, fp, installed, miss = framework.status_of(ctx)
            if fp != (st.get('framework') or {}).get('fingerprint') or installed != fp or miss:
                why['framework'] = 'the framework sources or the private repository changed'
        except Stop as e:
            why['framework'] = str(e)
    snap_hash = None
    try:
        _, s = snapshot.status(ctx)
        snap_hash = s['hash']
        if why['snapshot'] is None and (s['status'] != 'current' or s['hash'] != (st.get('snapshot') or {}).get('hash')):
            why['snapshot'] = f'snapshot {s["status"]}'
    except Stop as e:
        why['snapshot'] = why['snapshot'] or str(e)
    sol = st.get('solution') or {}
    built_on = sol.get('snapshotHash') or str((sol.get('facts') or {}).get('snapshot') or '').rsplit('/', 1)[-1]
    if why['solution'] is None and (not snap_hash or not built_on or not snap_hash.startswith(built_on)):
        why['solution'] = f'the module was written for snapshot {built_on[:16] or "unrecorded"}, the product is now ' \
                          f'{str(snap_hash or "unknown")[:16]}'
    if why['solution'] is None and (why['snapshot'] or why['framework']):
        why['solution'] = 'the framework or the snapshot is not current'
    if why['import'] is None and (st.get('import') or {}).get('contentHash') != pkg_hash:
        why['import'] = 'another package than the one imported'
    if why['fixtures'] is None and (st.get('fixtures') or {}).get('contentHash') != pkg_hash:
        why['fixtures'] = 'another package than the one the fixtures were prepared from'
    if why['fixtures'] is None and why['import']:
        why['fixtures'] = 'the import is not current'
    if why['lint'] is None:
        lt = st.get('lint') or {}
        module_dir = ctx.validation / solution.module_name(ctx)
        if why['solution'] or why['import'] or why['fixtures']:
            why['lint'] = 'the module, the import or the fixtures are not current'
        elif not snap_hash or lt.get('snapshotHash') != snap_hash:
            why['lint'] = 'another snapshot than the one linted'
        elif lint.digests(ctx, module_dir) != {k: lt.get(k) for k in ('assetsDigest', 'moduleDigest')}:
            why['lint'] = 'the assets or the module changed since the lint (import, fixtures, solution)'
    if why['gate'] is None:
        try:
            listed = gate.to_decide(ctx, st)[2]
            if listed:
                why['gate'] = f'{len(listed)} golden master(s) wait for the record gate'
        except Stop as e:
            why['gate'] = str(e)
    last_run = latest_run(st)
    if why['execute'] is None and (why['gate'] or why['solution'] or why['fixtures'] or why['lint']):
        why['execute'] = 'an earlier step is not current'
    if why['execute'] is None:
        why['execute'] = run_not_current(last_run, snap_hash, pkg_hash)
    latest = (last_run or {}).get('runId')
    if why['analyse'] is None and (st.get('analysis') or {}).get('runId') != latest:
        why['analyse'] = f'run {latest} is not analysed'
    if why['analyse'] is None and why['execute']:
        why['analyse'] = 'the run analysed is not current: ' + why['execute']
    others = max((v.get('at') or '' for k, v in steps.items() if k != 'report'), default='')
    if why['report'] is None and (why['analyse'] or others > (steps.get('report') or {}).get('at', '')):
        why['report'] = 'the analysis is not current or a step ran after the last report'
    return why


def handle_status(ctx):
    st = state.read(ctx)
    why = staleness(ctx, st)
    following = next((s for s in STEPS if why[s]), None)
    entries = vq.parse(ctx.questions)
    return {'status': 'current' if following is None else 'incomplete', 'mu': ctx.name, 'entry': ctx.entry,
            'steps': [{'step': s, 'done': why[s] is None, 'why': why[s],
                       'last': (st.get('steps') or {}).get(s)} for s in STEPS],
            'next': following, 'questions': vq.summary(entries),
            'stateFile': ctx.rel(ctx.state_file)}


def handle_questions(ctx, a):
    if a.action == 'add':
        st = state.read(ctx)
        prefix = 'RG' if a.gate else 'VQ'
        eid = vq.append(ctx.questions, {'title': a.title, 'question': a.question, 'decision': a.decision,
                                         'affects': a.affects, 'step': a.step, 'blocking': a.blocking}, prefix)
        st.setdefault('questions', {})[f'{a.step or "-"}:{a.title}'] = eid
        state.write(ctx, st)
        return {'added': eid, 'file': ctx.rel(ctx.questions), **vq.summary(vq.parse(ctx.questions))}
    entries = vq.parse(ctx.questions)
    return {'file': ctx.rel(ctx.questions), **vq.summary(entries), 'entries': entries}


def run():
    a = build_parser().parse_args()
    ctx = Ctx(a.mu, a.entry)
    if a.command == 'status':
        return handle_status(ctx)
    if a.command == 'questions':
        return handle_questions(ctx, a)
    st = state.read(ctx)
    readonly = a.command == 'snapshot' and a.status
    recorded = 'smoke' if a.command == 'execute' and a.smoke else a.command     # a smoke boot is no replay
    try:
        code, doc = STEPS[a.command].run_step(ctx, a, st)
    except Stop as e:
        if not readonly:
            state.record_step(st, recorded, e.code, 'failed' if e.code == 1 else 'needs-input')
            state.write(ctx, st)
        raise
    doc = {'step': recorded, 'mu': ctx.name, **doc}
    if not readonly:
        state.record_step(st, recorded, code, doc.get('status'))
        state.write(ctx, st)
        doc['stateFile'] = ctx.rel(ctx.state_file)
    return code, doc


if __name__ == '__main__':
    main(run)
