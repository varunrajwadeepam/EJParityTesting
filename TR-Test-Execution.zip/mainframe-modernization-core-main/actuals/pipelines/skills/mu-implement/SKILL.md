---
name: mu-implement
description: Implement phase of the COBOL migration - builds the solution code of one Migration Unit from its design artifacts.
argument-hint: "mu/<MU> [-git-commit]"
disable-model-invocation: true
---

# Implement one Migration Unit

Runs after `mu-design`. Builds into the solution exactly what `<mu>/design/` specifies:
the behaviour of the original, in the target's shape. The design has decided; this command
builds, tests and reports. It does not redesign.

`<mu>` below is the argument, normally `mu/<MU>`; layout in
`${CLAUDE_PLUGIN_ROOT}/templates/workspace/CLAUDE.md`. `<mu>` and the `mu.yaml` `solution` folder
are relative to the workspace root, the folder holding `mu/`; the command runs from there.

Optional flag `-git-commit`: step 4 commits each package. Without it the command makes no
git commits.

## Inputs, and nothing else

- `<mu>/mu.yaml` - the manifest. Without it, stop. `solution` is the solution folder.
- `<mu>/tools.yaml` - only via `python ${CLAUDE_PLUGIN_ROOT}/scripts/tools_config.py <mu> <tool> [key]`;
  the test database is the `test-db2` section, or `db2` when there is no `test-db2`.
- `<mu>/design/` - `rules.md`, `dictionary.md`, `design.md`, `tests.md`, `stubs.md`,
  `interface.md`, `design-open-questions.md` (with the user's answers), `report.md`.
- `<mu>/unit/` - `schema.sql`, `<entry>/cases.json`, `<entry>/fixtures/`.
- `<mu>/extracted-logic/` - when a design statement needs its source behaviour checked,
  and `paragraph-index.json`, which step 7's traceability gate reads. Missing, the gate
  cannot run: that is a question and a note in `report.md`, with the one command that
  fixes it (re-extract the MU with `--index`, `cobol-logic-extractor`), not a block.
- `<mu>/inputs/` - `target-state.md`, `db-schema/`, `deps/` (libraries, other MUs'
  `<name>.usage.md`).
- The solution folder: build files, shared code, other MUs' modules - of a boundary MU
  (`mu.yaml` `boundaries`) its public contract only (`api/`, `api/model/`, `exception/`).
  A stub client is built as `design.md` states it, not improved.
- **Skills** named in `mu.yaml` `target`: `code_skill` (code standards), `solution_skill`
  (build, dependencies, shared codebase, tests), `tir_skill` (runtime calls, shared library),
  `architecture_skill` (`SKILL.md`, its implement files as `SKILL.md` names them, and
  `archetype/<archetype>.md`: common part and "Implement part").

**Hard rule: never read the COBOL** - `inputs/cobol/`, `unit/*/sources/`, `driver.cbl`, any
`*.CBL` - for you and every subagent; put it in every subagent brief. The original is what
`design/` and `extracted-logic/` say. No MFLens, no parity-tester. Do not read a previous implementation of the same
programs.

## What to produce

- Code, configuration and tests in the solution folder - nothing else there.
- Into `<mu>/implement/` (temp files in `<mu>/implement/.tmp/`), each from its template in
  `${CLAUDE_PLUGIN_ROOT}/skills/mu-implement/templates/` - read it before writing the artifact:

| Artifact | Content | Template |
|---|---|---|
| `plan.md` | work items: rule, `tests.md` case and "Differences" line -> file, `class.method`, test; packages and order | `plan.md` |
| `implement-open-questions.md` | choices and gaps the design leaves open: question, decision taken, affects, `Answer:` | `implement-open-questions.md` |
| `<name>.usage.md` (`<name>`: `mu.yaml` `name`) | for clients - other MUs or external callers - and self-contained: entry points, wiring, every operation with its fields, outcomes and legacy mapping, domain names, public types; copied as is into a client's `inputs/deps/` | `usage.md` |
| `traceability.md` | the gate's coverage report: every paragraph of the original against the code that carries it | generated, step 7 |
| `report.md` | step status, build and test counts, coverage, review findings and outcomes, what is left | `report.md` |

## Order of work

0. **Preflight.** Stop only on a hard block, saying exactly what is missing: `mu.yaml` with
   `solution` and the four skills; `design/rules.md`, `design.md`, `dictionary.md`, `tests.md`;
   `unit/schema.sql` and each entry point's `cases.json` and `fixtures/`. Anything else
   missing is a question. Load the skills. On a re-run, read the answers in
   `implement-open-questions.md` first and redo only what they affect.
1. **Read the design**, in parallel: every rule, every case, every "Differences" line.
2. **Inspect the solution and libraries** (`solution_skill`): what exists, what this MU
   reuses, where it goes. Never edit another MU's or a library's code beyond registering this
   MU; anything more is a question.
3. **Plan** - `plan.md`. Every rule and every case maps to a work item.
4. **Implement** per work item, with its unit test (`code_skill`, `solution_skill`).
   Subagents for independent packages of work, each given its work items, the design files,
   the skills and the rules of this command. With `-git-commit`: commit each package as soon
   as its build is green (the solution's own gate first, if it has one), in `plan.md`'s
   order: a shared library change, then the module, then its registration in the
   application. Stage only the package's files, never push or amend.
5. **Build and unit tests** - the whole module green.
6. **Integration tests** - one per `tests.md` case against the test database (`tools.yaml`
   `test-db2`, else `db2`), as `solution_skill` says, isolated from other modules' tests as
   the solution's rules say (e.g. a test schema of the module's own). Never start a
   database. Not defined or not reachable: where the solution's rules give a fallback
   database (e.g. an embedded H2), run on it and report it as such; otherwise write the
   tests, skip running them, finish everything else, and report it - in `report.md`
   "Waiting for the user" and the final summary - asking the user to start or define the
   database (`test-db2` in `tools.yaml`) and re-run; the re-run does only this step.
7. **Review.** First the traceability gate, before any reviewer reads anything - it is a
   set comparison and a reviewer's sample is not:

       python ${CLAUDE_PLUGIN_ROOT}/scripts/check_rule_coverage.py \
           --index <mu>/extracted-logic/paragraph-index.json --rules <mu>/design/rules.md \
           --allow-out <mu>/implement/.tmp/allow.txt --warn-only
       python ${CLAUDE_PLUGIN_ROOT}/skills/target-java-3tier/scripts/validate_traceability.py \
           --index <mu>/extracted-logic/paragraph-index.json --java <solution>/src/main/java \
           --external <mu>/design/stubs.md --allow <mu>/implement/.tmp/allow.txt \
           --report <mu>/implement/traceability.md

   (the architecture skill's own path and flags, where it is not `target-java-3tier`.)
   The first regenerates the design's exemptions so the second honours them rather than
   asking for the same judgement twice. Fix every finding: an `UNCITED` paragraph is
   either code that is missing a citation or behaviour that is missing from the code, and
   telling those two apart is the work. Report the counts in `report.md` either way.
   Then fresh subagents in parallel, none told how the code was made, each reporting
   findings with severity (High/Medium/Low) and evidence:
   1. **traceability** - every rule in its home, every case a test, every `From` cited;
      given the gate's report, so it reviews what the gate cannot: whether a cited
      paragraph's behaviour is actually what the code does;
   2. **design** - the code against `design.md` and the archetype;
   3. **code** - against `code_skill`;
   4. **tests** - against `tests.md` and `solution_skill`.
   Fix what has evidence, the rest becomes a question; rebuild and rerun the tests; send each
   High back to its reviewer once. Log every outcome in `report.md`.
8. **Usage and report.** Write `<name>.usage.md`, in the archetype's form, and `report.md`;
   print a short summary: work items, tests run/failed, questions, blocks. `<name>.usage.md`:
   - signatures, types, codes, configuration and wiring from the built code; meanings,
     defaults, edge values and rollback from `design/interface.md`, `design.md` and
     `dictionary.md`; legacy fields and exit states from `dictionary.md` and
     `extracted-logic/` (the entry point's contract);
   - one `Operations` section per operation, every `mu.yaml` entry point under one;
   - copies every value it needs (lists, limits, messages); names no other document;
   - every public type of the archetype's contract and every outcome code is in it; code
     and design disagreeing: the code's, and a question.

Record questions in `implement-open-questions.md` as you go, in every step.

## Working

- Do not stop to ask. Everything short of a hard block becomes a question with the decision
  taken - never a silent assumption.
- Where documents conflict, keep the original's business logic and raise a question.
- Prefer a script to judgment for anything deterministic; write your own into
  `<mu>/implement/.tmp/` with the file-writing tool (no heredocs), run `python -B`.
- Read files in parallel. Long builds go to the background; wait for the completion notice.
- Write only into the solution folder and `<mu>/implement/`.

## What not to do

- **Do not invent business logic.** Every rule, value and error path comes from `design/`.
- **Do not change behaviour to make it more sensible** - a proposal is a question.
- **Do not edit a `tests.md` expectation** to make a test pass.
