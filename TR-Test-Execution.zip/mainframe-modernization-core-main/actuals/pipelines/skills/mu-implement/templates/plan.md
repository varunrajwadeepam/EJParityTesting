# plan.md - <mu>

Every rule of `rules.md`, every case of `tests.md` and every line of `design.md` "Differences
from the original" maps to exactly one work item. Nothing else is planned.

## Starting point

Module: <module, path>   Package root: <root>   Reused: <shared classes, libraries, other MUs>

## Work items

| # | Package | Work item | Rules | Cases | Files (create / modify) | Home `class.method` | Unit test |
|---|---|---|---|---|---|---|---|
| W1 | P1 | WIP number generator | 20-26 | create-ok | create `WipNumberGenerator.java` | `WipNumberGenerator.next` | `WipNumberGeneratorTest` |

Package = a work package one subagent builds; packages with no shared file run in parallel.

## Order

<packages in build order, and why - a dependency between them>

## Coverage

- Rules with no work item: <none, or each with the reason>
- Cases with no integration test: <none, or each with the reason>
