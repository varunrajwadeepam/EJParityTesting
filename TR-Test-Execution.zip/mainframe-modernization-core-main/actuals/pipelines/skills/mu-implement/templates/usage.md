# <name>.usage.md

Everything a client of MU `<name>` - another MU or an external caller - needs to call it.
Refers to no other document. Copied as is into the client's `inputs/deps/`.

## What it is

<one paragraph: what the MU does; archetype; deployment unit; module coordinates and build>

## Entry points

| Program | Legacy name | Operation | What it does |
|---|---|---|---|

<every `mu.yaml` entry point; "the other N programs of the tree are internal">

## Wiring

<the archetype's form>

Caller provides: <DataSource and the tables it must reach, transaction manager, beans>

| Property / environment variable | Meaning | Default |
|---|---|---|

## Operations

### `<operation>` - replaces `CALL '<PROGRAM>'`

Inputs:

| Field | Type | Width | Meaning, default, edge values | Legacy import field |
|---|---|---|---|---|

Outputs:

| Field | Type | Width | Meaning, order, limits | Legacy export field |
|---|---|---|---|---|

Outcomes:

| Outcome | Code | Severity | Message | Rollback | When | Legacy exit state |
|---|---|---|---|---|---|---|

Transaction and effects: <joins the caller's transaction or not; tables read / written; or none>

<a short call example>

## Domain names

| Name | Meaning | Width |
|---|---|---|

## Public types

| Type | Package | What it is for |
|---|---|---|

## Shared code this MU added

<classes other MUs may reuse - e.g. `GenDates` - or "none">
