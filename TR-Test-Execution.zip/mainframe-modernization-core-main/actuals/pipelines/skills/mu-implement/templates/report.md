# report.md - <mu>

| Step | Status | Note |
|---|---|---|

Work items <done>/<planned> · rules covered <n>/<n> · cases tested <n>/<n> · open questions <n>

## Build and tests

| Module | Build | Unit run / failed / skipped | Integration run / failed / skipped |
|---|---|---|---|

Test database: <`test-db2` | `db2` - host:port/database> | not run: <not defined | not reachable>
Failing cases: <case - cause - question>

## Traceability

From the gate, not from reading: `<n>` business paragraphs, `<n>` cited or exempt
(`<n>`%), `<n>` findings. Report: `implement/traceability.md`.

| Finding | Count | What was done |
|---|---:|---|

<Not run: no `extracted-logic/paragraph-index.json` - re-extract the MU with `--index`.>

## Review findings

| # | Reviewer | Severity | Finding | applied / rejected / open | Where / why |
|---|---|---|---|---|---|

## Changes outside this MU's module

<file - why, or "none">

## Blocked

## Left behind

Contents of `<mu>/implement/.tmp/`; rows left in the database, if any.

## Waiting for the user

<integration tests not run: start the database / define `test-db2` in `tools.yaml`, then re-run>
