# implement-open-questions.md

An entry only where the design or the solution is silent or contradicts itself, and the
wrong choice changes behaviour, a contract or another MU's code.

## Settled

- <decision, one line>

## IQ-<n> - <title>

Step: <step> · Status: open | answered | settled
Question: <what the design or the solution does not say>
Decision taken: <what the code does>, because <why>
Affects: rules <n>, cases <name>, files <path>
Answer: <filled by the user; the next run applies it>
