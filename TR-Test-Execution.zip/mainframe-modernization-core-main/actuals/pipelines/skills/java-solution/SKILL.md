---
name: java-solution
description: Solution-level rules for mu-implement - inspect and join a shared Java codebase, dependencies and libraries, Maven build, unit tests while coding and the tests.md integration run once all code exists.
user-invocable: false
---

# Java solution

Layers, persistence and trimming are `design.md`'s; code style is `java-code`'s.

**Hard rule: never read the COBOL** (`mu-implement`): `inputs/cobol/`, `unit/*/sources/`,
`driver.cbl`.

## Inspect before planning
- Find the build files (parent and module `pom.xml`, wrapper), packages, config, existing tests, shared runtime classes (`GenDates`), other MUs' modules.
- Read every `inputs/deps/*.md` (library, blueprint, earlier MU): where it is and how to use it. Use what exists; never write a second copy.

## Join
- Place this MU as the design's module layout says; new files under the MU's own package.
- Touch another module only to register this MU (dependency, scan, config), minimally; anything more is a question. Do not reformat other files.
- Dependencies: versions only where the parent manages them; children declare none. A dependency `target-state.md` does not list is a question.

## Build
- `./mvnw` if present, else `mvn`. Work on this MU's module: `-pl <module> -am` (`-am` is required: otherwise shared libraries come from a possibly stale local repository).
- Compile `-q -DskipTests package`; unit `test`; integration `verify` (failsafe, `*IT`). Reports: `target/surefire-reports`, `target/failsafe-reports`.
- Build output stays in `target/`; logs and scratch scripts in `mu/<MU>/implement/.tmp/`. No fixed scripts: write small ones when needed.
- A build or test still red after 3 fix rounds on the same cause = question, move on; report it.

## Unit tests while coding
- Per work item (rule or group of rules): write the test with the code, run just it (`-Dtest=Class#method`), fix until green, then next item.
- One test class per rule home; plain JUnit + Mockito, DAOs mocked, no Spring context, no database.
- Test data from `rules.md` worked examples and `tests.md`; a derived identifier is tested per component and as a whole.
- Before integration: the whole module's unit tests green.

## Integration tests from tests.md (after all code exists)
- One test per case: request and expected outcome from the case; `Expected rows` checked with a query.
- Database: `tools.yaml` `test-db2` section, or `db2` when there is none, via `${CLAUDE_PLUGIN_ROOT}/scripts/tools_config.py` (host, port, database, user, password); never started here. Not defined or not reachable: the solution's fallback database where its rules give one (an embedded H2 in Db2 mode, reported as such); otherwise the tests are written but not run - report it and ask for the database (`mu-implement` step 6). Tables per `unit/schema.sql`. Seed from `unit/<entry>/fixtures/*.sql`.
- **The test database is shared with other MUs' tests; keep this MU's apart.** A test
  schema of the MU's own where the solution provides one (its tables created from
  `unit/schema.sql` when missing, never dropped), otherwise keys with the fixtures'
  reserved prefix. Every `DELETE`/`UPDATE` names the fixtures' exact keys - never a pattern
  another MU's keys also match (`LIKE 'ZT%'` hits every MU's `ZT` rows, mid-run) - and no
  `DROP`/`TRUNCATE`.
- **What the SQL leaves to the database is not a test's to fix.** Rows an `ORDER BY`
  leaves tied - or a read with no `ORDER BY` - come in the database's physical order: a
  recording shows one order, a fresh test table may give another. Such a case keeps the
  order of the sort key and compares the rows of one key as a set, and `tests.md` says
  so under `Does not verify`.
- **A Db2-only clause the SQL keeps verbatim is a test fact.** `OPTIMIZE FOR n ROWS`, a
  null's place in an ascending order (Db2: last), a blank-padded `CHAR` comparison: a
  fallback test database (H2 in Db2 mode) parses or orders them otherwise. `design.md`
  *Testing* names each one the MU's statements hold, so the implementation adapts the
  test database - never the statement.
- **Amounts are compared with their scale.** A JSON tree comparison takes `0` and `0.00`
  as equal; compare the amount as text.
- Each test removes what it wrote; row counts end as they began; suite green twice in a row.
- A failing case: code defect = fix code; setup defect = fix test. Expectation vs design disagreement = never edit the expectation; question, case stays failing and is reported. "Does not verify" lines limit what a case asserts.
- A skipped test is a failure of process, not a pass.

## Report numbers
Per module: unit run/failed/skipped, integration run/failed/skipped, cases of `tests.md` covered/total.
