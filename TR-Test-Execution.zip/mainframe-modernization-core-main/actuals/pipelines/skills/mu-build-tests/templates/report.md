# tests-report.md - {{mu}} / {{entry}}

State: **{{state}}** · scope {{scope}} · {{date}} · package {{package}}

{{reasons}}

## Cases

| cases | basic | advanced | golden | not-representable | not-recorded | clock-sensitive | decided | decision pending |
|---|---|---|---|---|---|---|---|---|
| {{cases}} | {{basic}} | {{advanced}} | {{golden}} | {{notRepresentable}} | {{notRecorded}} | {{clockSensitive}} | {{decided}} | {{pendingDecisions}} |

## Coverage (business paragraphs, package coverage)

| | covered | uncovered | total | outside every paragraph |
|---|---|---|---|---|
| paragraphs | {{parasCovered}} | {{parasUncovered}} | {{parasTotal}} | - |
| lines | {{linesCovered}} | {{linesUncovered}} | {{linesTotal}} | {{outsideLines}} |

{{coverageNote}}

## Last build

{{build}}

## Warnings

{{warnings}}

## Questions

Open {{qOpen}} (blocking {{qBlocking}}) · answered {{qAnswered}} · settled {{qSettled}}

## Next

{{next}}
