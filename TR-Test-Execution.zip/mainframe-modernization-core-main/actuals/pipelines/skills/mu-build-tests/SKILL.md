---
name: mu-build-tests
description: Test phase of the COBOL migration - builds the test package of one Migration Unit (basic set from tests.md plus an advanced set from rules.md), every expectation recorded on the real COBOL.
argument-hint: "mu/<MU> [entry=<E>] [<instructions>]"
disable-model-invocation: true
---

# Build the test package of one Migration Unit

Runs after `mu-design`; before, beside or after `mu-implement`. Per entry point: the **basic
set** (the cases of `design/tests.md`) plus an **advanced set** derived from `design/rules.md`,
each case marked with its rules and the paragraphs it ran, each expectation recorded twice on
the COBOL through `run-cobol`. Result: the package, its state, the questions.

`<mu>` is the argument, normally `mu/<MU>`; layout in `${CLAUDE_PLUGIN_ROOT}/templates/workspace/CLAUDE.md`.
Run from the workspace root. `S` below is `python -B ${CLAUDE_PLUGIN_ROOT}/skills/mu-build-tests/scripts`.
Every script takes `<mu> [--entry E]`, prints one JSON object, exits 0 done, 2 decision or input
needed, 1 failed.

## Inputs, and nothing else

- `<mu>/mu.yaml`, `<mu>/tools.yaml` (via `${CLAUDE_PLUGIN_ROOT}/scripts/tools_config.py`; recording
  database: `golden-db2`, required - never `db2`).
- `<mu>/design/` - `rules.md` (the truth about behaviour), `tests.md` (the basic set, taken as it
  is), `design.md`, `interface.md`, `dictionary.md`, `stubs.md`, `design-open-questions.md`.
- `<mu>/extracted-logic/*.md` and `paragraph-index.json` - arms, data access, outputs.
- `<mu>/unit/schema.sql`, `<mu>/unit/<E>/` - `cases.json`, `fixtures/`, `schema.yaml`; the unit
  is reused as design built it.
- The solution (`mu.yaml` `solution`), only to check the API on a re-run.
- `PLAN.md` and `PACKAGE.md` beside this file; the `run-cobol` skill.

**Hard rule: the COBOL stays out of your context.** You and every subagent writing cases never
open `inputs/cobol/`, `unit/*/sources/`, `driver.cbl`, any `*.CBL`; no MFLens. One exception: a
separate subagent may read the COBOL only to prepare or fix a run on the parity tester (which
input or row reaches a range); it returns inputs, rows and the cause, never source text.

## What to produce

In `<mu>/tests/` (temp files in `<mu>/tests/.tmp/`):

| Artifact | Written by |
|---|---|
| `plan/<E>.plan.json` - contract, binding, decisions, cases (`PLAN.md`) | you; `import_unit.py` for the basic cases |
| `fixtures/<E>/*.sql` | you; `import_unit.py` copies the unit's |
| `notes/<E>-arms.md` - decision arms per business paragraph, each with rules and cases | `arms.py skeleton`, then you |
| `package/<E>/` - `<E>-tests.json` (`PACKAGE.md`), fixtures, `traceability.md` | `build.py --install`, `trace.py` |
| `previous/<E>/` - the package before this run | `rotate.py` |
| `tests-state.json`, `tests-report.md` | `state.py` |
| `tests-open-questions.md` - `PQ-n` | you, through `questions.py add` |

## Order of work

0. **Preflight.** `$S/preflight.py <mu>`; exit 1 is a hard block: stop and say what is missing
   (no `golden-db2`: give the user the `add` section for `tools.yaml`; never record on `db2`).
   Apply the `answers` it lists (and the user's instructions) in the steps they affect.
   `$S/db.py <mu> --create-tables`, then `$S/rotate.py <mu>` (once per run).
1. **Context.** Read `rules.md`, `tests.md`, the design documents and the extracted logic of
   every program in the tree; a subagent per program when large.
2. **Arms.** `$S/arms.py <mu> skeleton`. Per business paragraph, one row per decision arm (each
   literal, `WHEN OTHER`, SQL code, limit, null indicator, date test) with its rule ids. An arm
   no rule explains is a `PQ` (design gap), never a silent case.
3. **Plan.** `$S/import_unit.py <mu>` imports the basic cases (`origin: basic`, names and
   `tests.md` expectations kept); each `warnings` line on a dropped `clock:` input is a
   non-blocking `PQ`. Write the contract: `inputMap`, `outputs`, `tables`, `api`
   from `interface.md` / `design.md` / the `Request:` lines (REST only), `decisions` from the
   design's differences and answers (`source` = `OQ-n`, `PQ-n` or `design.md#...`).
4. **Fixtures.** Seed rows for every data requirement: cap and cap+1, NULL, at and over a width,
   each date arm, duplicate key; real keys and foreign keys; a comment per row naming its arm.
5. **Advanced cases.** One per arm, boundary, clock edge and data requirement, plus one
   metamorphic case under another clock; `origin: advanced`; `about` starts with the rule and
   arm ids; fill the arms' case column.
6. **Capture.** `$S/record.py <mu>` (each case twice plus a probe-clock run), then
   `$S/build.py <mu>`. Exit 2 is a regression against the previous package: report it, accept
   only on the user's instruction (`--accept-regressions`). A surprise in a recording is a finding:
   correct `about` / `category`, never the inputs. Each "Design expectations differ" line becomes a `PQ`.
   Each "Pending decisions" line names a source not yet answered or settled: report it; the
   answer applies once the user settles it.
7. **Coverage loop.** `.tmp/<E>/uncovered.md` (from build; `$S/coverage.py <mu>` alone: the last
   build's runs) names the business paragraphs no case ran. Add cases that reach them, back to 6;
   at most 3 rounds, stop when a round adds nothing. A paragraph left uncovered gets a reason in its arm row.
8. **Review.** A fresh subagent, not told how the cases were made, checks the cases against the
   arms table and the package against `rules.md`; `$S/arms.py <mu> check` must exit 0 or every
   gap is a `PQ`. Fix with evidence, rebuild.
9. **Install, trace, state.** `$S/build.py <mu> --install`, `$S/trace.py <mu>`; after checking
   the binding against an existing solution, `$S/state.py <mu> --api-checked`, else
   `$S/state.py <mu>`. Print a short summary: cases, coverage, state, questions.

Record questions as you go, every step: `$S/questions.py <mu> add --title .. --question ..
--decision .. --affects .. --step <n> --blocking yes|no` (`yes`: it changes cases, fixtures or
expectations).

## Re-runs

Any time: answers, user instructions, a solution that appeared or changed (read its controller,
request and response types and exception mapping; adapt `api` when every input, output and call
is still reachable, else a blocking `PQ`), an SME decision (a `decisions` entry and a case for
it; the recording stays), changed `rules.md` / `tests.md` / unit (state `stale`). Unchanged cases
are carried forward; only cases whose inputs, fixture, clock or code changed are recorded again.

## Rules

- Never write a built field by hand (`expected`, `legacy`, `request`, `status`, ids, coverage):
  change the plan and build again.
- Never predict an outcome; never change a recording because of an answer - a decided behaviour
  is a `decisions` entry naming its source.
- Never rename, renumber or reorder a case of an earlier package; drop one only through
  `removed` with a reason.
- Do not stop to ask. Everything short of a hard block is a question with the decision taken.
- Deterministic work is a script; your own go to `<mu>/tests/.tmp/` (file-writing tool, `python -B`).
- Write only into `<mu>/tests/`.
