# The plan: `tests/plan/<E>.plan.json`

Start from `templates/plan.template.json`. Keys starting with `_` are ignored (stripped from `api` in the package). The entry point is `--entry`, else the first of `mu.yaml` `entry_points`.

| key | req. | meaning |
|---|---|---|
| `idPrefix` | no | case ids `<idPrefix>NNN`; new ids follow the highest base and removed id |
| `defaults` | yes | below |
| `constantInputs` | no | `{<COBOL field>: <value>}` sent on every call |
| `inputMap` | yes | `{<param>: <COBOL field> \| group}`, in driver order |
| `outputs` | yes | the legacy block; with a base suite its `legacySchema` without `tables`, verbatim |
| `technicalFailure` | no | failure flag spec; default CA Gen GLOBDATA |
| `tables` | no | table checks `{<check id>: {...}}` |
| `api` | no | REST binding; absent = COBOL-only baseline (`binding: null`, no request/expected) |
| `decisions` | no | `{<id>: {...}}`, known Java differences |
| `compare` | no | `[{path, mode, reason}]` joined to every case's `compare` |
| `removed` | no | `{<name>: {id, reason}}`; a base case leaves only through here; name and id never reused |
| `goldenMaster` | no | text; `recorded YYYY-MM-DD` is replaced by the newest recording date |
| `suiteHeader` | no | `{api, statuses}` copied into the package; no `statuses`: the base suite's, else default texts (`comparison` is fixed by build.py) |
| `cases` | yes | below |

## defaults

| key | meaning |
|---|---|
| `clock` | `^[0-9]{14}([0-9]{1,6})?$`; the clock of every case without its own |
| `probeClock` | required, same format, not `clock`; every case runs once more at it (a case with its own clock: at `clock`) |
| `fixture` | file of `tests/fixtures/<E>/`, default for every case |
| `shims` | default `["cagen"]` |
| `repeats` | runs per case, default 2; repeats that disagree make the case not-recorded |
| `checks` | check ids every case runs unless it names its own `checks` |

## constantInputs, inputMap

- `"clock:<fmt>"`: evaluated at the run's clock; tokens `yyyy MM dd HH mm ss ffffff`. The probe run evaluates it at the probe clock.
- Scalar: `"<param>": "<COBOL field>"`. Param = the API key it travels as (body key, query parameter, path placeholder).
- Group: `"<param>": {"count": <count field>, "item": {<item key>: <field>}}`; the param is a list of objects; count = list length; items past OCCURS are not sent.
- A param absent or `""` is not sent (the driver leaves spaces/zero). Send order: constantInputs, inputMap, `extraInputs` (override in place).
- A param may only select the operation (`operations[].when`) and never travel in the request.

## outputs

| spec | legacy value |
|---|---|
| `"$inputs"` / `"$runId"` | `{field: value}` sent / the run id |
| `"<FIELD>[\|number][\|default:<v>]"` | the output field |
| `"param:<p>[\|...]"` | the input value of that param |
| `{"count": <field>, "columns": {<key>: <field>}}` | list of rows `[[v, ...]]`, `count` rows; not written on a technical failure |

No output of a field that only echoes a `clock:` input.

## Names

- First `"inputs": "$inputs"`, `"runId": "$runId"`; then echoes in inputMap order, other scalars, lists.
- All keys lowerCamel; `verify`, `tables`, `technicalFailure` reserved.
- An echo (`param:<p>`, or a field equal to an inputMap scalar field after the suffix cut below) is named as the param.
- Other scalars: exactly the field noun, never a dictionary name: cut a trailing `-<digits>[A-Z]*`, split on `-`, drop one-letter words, lowerCamel (`RV-SERVER-DATE-0044` -> `rvServerDate`, `ACCOUNT-BALANCE-2` -> `accountBalance`); no `Echo|Echoed|Out|Output|Export|Exp|Ret|Returned` suffix.
- Group item keys lowerCamel.
- Query/path/body key = the param it sends (path through `|enum` exempt); body array = its `$param`; response array = its `$list`; item key = its `col:`.

## technicalFailure, tables

`technicalFailure`: `{flag, ok: [...], fields: {<legacy key>: <field>}, extraFlags?: {<field>: [ok values]}}`; each given key replaces the default (`flag STATUS-FLAG`, `ok ["", "OK"]`); `fields` entries add to or override the default ones (statusFlag, lastStatus, errorEncountered, failedIn, savedSqlcode). A flag outside `ok` adds `legacy.technicalFailure` = `fields`.

`tables.<check id>`: `{table, columns[], where?, orderBy?[], compare?: ordered|set}`. Table and columns from `unit/schema.sql`; `where` has no `;`; `compare` default `ordered` with orderBy, else `set`. One check per table per case.

## The API binding

- `api` = one endpoint `{method, pathTemplate, path, query, body, principal, response, technicalFailure, enumMaps}`, or `{operations: [{name, when, ...}], enumMaps, technicalFailure?}`.
- `when: {<param>: <value>}`: the first operation whose params all equal is the case's. No operation, or a blank path placeholder: build refuses until the case is marked not-representable.
- A path value through `|enum` that only the field's blank padding or cut maps: build makes the case not-representable.
- POST/PUT always send `body` (`{}` when none). A key whose value is absent is left out.
- Expressions: `param:<p>` `item:<k>` `path:<k>` `scalar:<legacy key>` `list:<legacy list>` `full:<legacy list>` (rows >= OCCURS) `const:<json>` `col:<column>`. Templates: `{"$param": <group>, "$item": {...}}` (request), `{"$list": <list>, "$item": {...}}` (response).
- Pipes, left to right: `|enum` (`enumMaps[<param>]`, trailing blanks ignored) `|default:<v>` `|trim` `|number` `|date` (YYYYMMDD -> YYYY-MM-DD, blank -> absent) `|blankAbsent`.
- `response`: `{status, body}` | `{status, statusMap: {scalar, map: {<value>: <status>}}, body}` | `{outcome: <legacy key>, map: {<right-trimmed value>: answer}, otherwise?}`; answer `{status, body}` | `{status, empty: true}`.
- `technicalFailure` (operation's, else api's): `{status, body, source, causes?: [{when: {<legacy.technicalFailure key>: <value>}, status, body, source}]}`; first matching cause answers, else itself. Every one needs `source`.
- `source`: `OQ-<n>` | `PQ-<n>` | `design.md#<anchor>`. A decision's `answer` applies only when its source is decided: the `OQ-<n>` answered or settled in `design/design-open-questions.md`, the `PQ-<n>` in `tests/tests-open-questions.md`, the anchor a heading of `design/design.md`; otherwise the case's `decidedAnswer` is `pending` and `expected` stays the recorded answer.

## Decisions

`{when, text, source?, kind?, clockDependent?, compare?, answer?}`. `when`: predicates joined by `&`, all must fire:

| predicate | fires when |
|---|---|
| `clockSensitive` | the probe run differs or aborts |
| `technicalFailure` | the recording has `legacy.technicalFailure` |
| `absent:<p>` / `blank:<p>` / `zero:<p>` / `absentOrZero:<p>` | the param is absent / blank / numeric 0 / either |
| `unmapped:<p>` | the param's value has no `enumMaps` entry |
| `param:<p>=<v1>\|<v2>` | the trimmed param is one of them |
| `notDate:<p>` | eight digits, no calendar date |
| `negative:<p>` / `above:<p>=<n>` / `wider:<p>=<n>` | number < 0 / number > n / trimmed length > n |
| `legacy:<key>=<v>` / `failure:<field>=<v>` | trimmed legacy key / `legacy.technicalFailure` field |
| `operation:<name>` / `status:<http>` / `case:<name>` | the operation / the recorded expected status / that case |

- `kind`: `java` (default) -> `anticipatedJavaDivergence`; `stack` -> `stackDivergence`. `text` gets `source: ` prefixed; `{date}` = the case clock's date. Text must not say "not compared" without a `compare` ignore, nor state an expected status. `source` required for kind java and for any `answer`.
- `clockDependent: true` makes the case `clockSensitive`; a probe difference without one is reported. `compare: [{path, mode: set|ignore, reason}]` (ignore needs reason) joins a 2xx body's compare.
- `answer` (kind java only): `{status?, body?, set?: [{path, value}], tables?: recorded|notCompared}`; `set` path `body.<key>[n]...` | `status` | `tables.<TABLE>[<row>].<COLUMN>`; `tables` required when the case has table checks. Fired answers must be equal.

## cases[]

| key | meaning |
|---|---|
| `name` | unique, kebab-case `^[a-z0-9]+(-[a-z0-9]+)*$` (else build refuses); a base case keeps it |
| `origin` | `basic` (import_unit; carries `design`) / `advanced` (the agent's; no `design`) |
| `category` | `Happy` `Edge` `Boundary` `Error` `Robustness` `Duplicate` `Metamorphic`; required |
| `about` | required |
| `params` | `{<inputMap param>: value}` |
| `ruleIds` | `R<n>` of `design/rules.md` |
| `status` / `reason` | only `not-representable`, reason required |
| `extraInputs` | `{<COBOL field>: value}` no param carries; requires not-representable |
| `clock`, `fixture`, `checks` | override `defaults` |
| `suppressRules` / `compare` | decision ids that do not apply / `[{path, mode, reason}]` |
| `divergence` / `stack` | extra texts for `anticipatedJavaDivergence` / `stackDivergence` |

Two cases with the same inputs, clock, fixture and request are refused. A base case keeps its inputs and fixture.

## import_unit.py vs the agent

- import_unit.py: one basic case per `unit/<E>/cases.json` case (`name`, `origin`, `about`, `params` through inputMap, `fixture` / `clock` when not the default, `extraInputs` + not-representable + reason); `design` and `ruleIds` from `design/tests.md` `## <name>` (re-import: `design` rewritten, missing rule ids added, nothing else touched); the fixture copied to `tests/fixtures/<E>/` (never overwritten). Unit inputs equal to their `constantInputs` value are dropped; a unit input for a `clock:` constant that differs is dropped too, the case records at its own clock, and import lists it in `warnings`; unit `expect` is never copied.
- The agent: the contract before import (`defaults`, `constantInputs`, `inputMap`, `outputs`, `tables`, `api`), `category` of every case (import sets `null`), a non-blocking `PQ` per dropped `clock:` input warning, advanced cases, `decisions`, `removed`.
