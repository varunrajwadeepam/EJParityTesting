#!/usr/bin/env python3
"""Decide the state of an entry point's tests, write tests-state.json and package.state, render the report.

    python -B state.py <mu> [--entry E] [--api-checked] [--record-failed MESSAGE]

State, first match wins (precedence blocked > stale > needs-answers > needs-api-check > drafted > ready):
  blocked          a hard block of preflight (missing input), no installed package, a package whose
                   contentHash does not match its content, a not-recorded case, a last build left
                   with regressions (.tmp/<E>/build.json status regressions/failed), or
                   a failed record.py: tests/.tmp/<E>/record.json status failed and newer
                   than the installed package, or --record-failed MESSAGE.
  stale            a package.inputs hash differs from the current file.
  needs-answers    an open tests-open-questions.md entry with `Blocking: yes` and no Answer.
  needs-api-check  the solution has a src/main and the plan's api._checkedAgainst is not its hash.
  drafted          no solution src/main yet (mu.yaml `solution`).
  ready            otherwise.
Every reason found is reported, not only the winning one.

--api-checked: the agent checked plan.api against the solution; stores the sha256 of the
solution's src/main in plan api._checkedAgainst (and in the state) before deciding.
Writes tests/tests-state.json, package.state of the installed package (outside the seal: contentHash
unchanged; refused when it would change) and tests/tests-report.md from templates/report.md.
Scope: `basic-only` when the plan has no `origin: advanced` case or notes/<E>-arms.md is missing
(state unchanged; a warning, and the next move says to run again), else `full`.
Exit 0 ready or drafted; 2 any other state; 1 failed.
"""

import os
import re
import sys
from datetime import datetime, timezone

sys.dont_write_bytecode = True

import questions as pq  # noqa: E402
from btlib import (SKILL, Paths, Stop, content_hash, iso_now, main, parser, read_json, read_text,  # noqa: E402
                   recording_db, write_json, write_text)
from preflight import hard_blocks, solution_dirs, solution_hash, stale_inputs  # noqa: E402

ORDER = ['blocked', 'stale', 'needs-answers', 'needs-api-check', 'drafted', 'ready']
NEXT = {
    'blocked': 'Clear the blocks listed above (inputs, record failure, not-recorded cases, regressions), '
               'then record.py and build.py --install again.',
    'stale': 'The design or unit inputs changed since the package: rotate.py, import_unit.py, review plan and '
             'arms, record.py, build.py --install.',
    'needs-answers': 'Answer the blocking entries of tests-open-questions.md, then rerun the command.',
    'needs-api-check': 'Check plan.api against the solution (endpoints, request and response types), correct the '
                       'binding, build.py --install, then state.py --api-checked.',
    'drafted': 'Complete against the design; no solution yet. Rerun once the solution exists (needs-api-check).',
    'ready': 'Nothing to do: the package is ready for the solution\'s integration run.',
}
BASIC_ONLY_NEXT = 'Scope basic-only: run again to add the advanced set.'


def scope_of(p, plan):
    """(scope, warning or None): basic-only without an advanced plan case or the arms notes."""
    missing = []
    if not any(c.get('origin') == 'advanced' for c in plan.get('cases') or []):
        missing.append('the plan has no origin: advanced case')
    if not p.arms.is_file():
        missing.append(f'{p.rel(p.arms)} is missing')
    if missing:
        return 'basic-only', 'scope basic-only: ' + '; '.join(missing)
    return 'full', None


def counts(cases):
    def n(f):
        return sum(1 for c in cases if f(c))
    return {'cases': len(cases), 'basic': n(lambda c: c.get('origin') == 'basic'),
            'advanced': n(lambda c: c.get('origin') == 'advanced'),
            'golden': n(lambda c: c.get('status') == 'golden'),
            'notRepresentable': n(lambda c: c.get('status') == 'not-representable'),
            'notRecorded': n(lambda c: c.get('status') == 'not-recorded'),
            'clockSensitive': n(lambda c: c.get('clockSensitive') is True),
            'decided': n(lambda c: bool(c.get('decidedAnswer')) and not c['decidedAnswer'].get('pending')),
            'pendingDecisions': n(lambda c: bool((c.get('decidedAnswer') or {}).get('pending')))}


def api_checked(p, h):
    if not h:
        raise Stop('--api-checked: the solution has no src/main to check against (mu.yaml solution)')
    if not p.plan.is_file():
        raise Stop(f'--api-checked: no plan {p.rel(p.plan)}')
    plan = read_json(p.plan, 'plan')
    if not isinstance(plan.get('api'), dict):
        raise Stop('--api-checked: the plan has no api object')
    plan['api']['_checkedAgainst'] = h
    write_json(p.plan, plan)


def _mtime(f):
    if not f.is_file():
        return None
    return datetime.fromtimestamp(f.stat().st_mtime, timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


def _when(s):
    try:
        return datetime.fromisoformat(str(s).replace('Z', '+00:00'))
    except ValueError:
        return None


def installed_at(p, suite, build):
    """When the installed package was installed: build.json installedAt for that contentHash, else the file's mtime."""
    if suite is None:
        return None
    if build and build.get('installedAt') and build.get('contentHash') == (suite.get('package') or {}).get('contentHash'):
        return _when(build['installedAt'])
    return datetime.fromtimestamp(p.suite.stat().st_mtime, timezone.utc)


def record_failure(p, suite, build):
    """The blocked reason of a failed record.py (tests/.tmp/<E>/record.json) newer than the installed package."""
    f = p.tmp / 'record.json'
    if not f.is_file():
        return None
    rec = read_json(f, 'record.json')
    if rec.get('status') != 'failed':
        return None
    at = _when(rec.get('finishedAt') or rec.get('startedAt')) or datetime.fromtimestamp(f.stat().st_mtime, timezone.utc)
    inst = installed_at(p, suite, build)
    if inst is not None and at <= inst:
        return None
    first = (rec.get('failures') or [{}])[0]
    case = f"{first.get('case')}: " if first.get('case') else ''
    return f"record.py failed{' (run ' + str(rec['runId']) + ')' if rec.get('runId') else ''}: {case}{first.get('reason', '')}"


def _lines(xs, empty='(none)'):
    return '\n'.join(f'- {x}' for x in xs) if xs else empty


def render(p, doc, build):
    tpl = read_text(SKILL / 'templates' / 'report.md')
    c, cov, q = doc['counts'], doc['coverage'], doc['questions']
    pk = doc['package']
    if build:
        regs, upd = build.get('regressions') or [], build.get('updated') or []
        btxt = (f"{build.get('status', '?')} · version {build.get('version')} · installed {build.get('installed')} · "
                f"added {build.get('added', 0)}, carried {build.get('carried', 0)}, removed {build.get('removed', 0)}\n\n"
                f"Regressions ({len(regs)}):\n{_lines(regs)}\n\nUpdated ({len(upd)}):\n{_lines(upd)}")
    else:
        btxt = '(no build.json)'
    reasons = [f'- {s}: {r}' for s in ORDER for r in doc['reasons'].get(s, [])]

    def ids(xs):
        return f"{len(xs)}{' (' + ', '.join(xs) + ')' if xs else ''}"
    vals = {
        'mu': p.mu.name, 'entry': p.entry, 'state': doc['state'], 'date': doc['timestamps']['written'],
        'package': f"v{pk['version']} ({str(pk['contentHash'])[:16]})" if pk.get('version') else '(not installed)',
        'reasons': '\n'.join(reasons) or '- no open reason',
        **{k: str(v) for k, v in c.items()},
        'parasCovered': cov['paragraphs'].get('covered', 0), 'parasUncovered': cov['paragraphs'].get('uncovered', 0),
        'parasTotal': cov['paragraphs'].get('total', 0), 'linesCovered': cov['lines'].get('covered', 0),
        'linesUncovered': cov['lines'].get('uncovered', 0), 'linesTotal': cov['lines'].get('code', 0),
        'outsideLines': cov.get('outsideLines', 0), 'scope': doc['scope'],
        'coverageNote': ('Line counts estimated from paragraph ranges (unit sources absent).'
                         if cov.get('estimated') else 'Details: package coverage, tests/.tmp/<E>/uncovered.md.'),
        'build': btxt, 'warnings': _lines(doc['warnings']),
        'qOpen': ids(q['open']), 'qBlocking': ids(q['blocking']), 'qAnswered': ids(q['answered']),
        'qSettled': ids(q['settled']),
        'next': NEXT[doc['state']] + (' ' + BASIC_ONLY_NEXT if doc['scope'] == 'basic-only' else ''),
    }
    return re.sub(r'\{\{(\w+)\}\}', lambda m: str(vals.get(m.group(1), m.group(0))), tpl)


def run():
    ap = parser('Decide the tests state, write tests-state.json, package.state and tests-report.md.')
    ap.add_argument('--api-checked', action='store_true', help='record the solution hash the api was checked against')
    ap.add_argument('--record-failed', metavar='MESSAGE', help='record.py failed (exit 1): the state is blocked')
    a = ap.parse_args()
    p = Paths(a.mu, a.entry)
    now = iso_now()
    old = read_json(p.state, 'state') if p.state.is_file() else {}
    sol_hash = solution_hash(p)
    if a.api_checked:
        api_checked(p, sol_hash)
    reasons = {s: [] for s in ORDER}
    warnings = []
    reasons['blocked'] += hard_blocks(p)
    if a.record_failed:
        reasons['blocked'].append(f'record.py failed: {a.record_failed}')
    suite = read_json(p.suite, 'package') if p.suite.is_file() else None
    build = read_json(p.tmp / 'build.json', 'build.json') if (p.tmp / 'build.json').is_file() else None
    rec = record_failure(p, suite, build)
    if rec:
        reasons['blocked'].append(rec)
    cases = (suite or {}).get('cases') or []
    if suite is None:
        reasons['blocked'].append(f'no installed package {p.rel(p.suite)}')
    else:
        if suite.get('package', {}).get('contentHash') != content_hash(suite):
            reasons['blocked'].append('package contentHash does not match its content (edited by hand?)')
        reasons['blocked'] += [f"{c['id']} {c.get('name', '')}: not-recorded ({c.get('reason', '')})"
                               for c in cases if c.get('status') == 'not-recorded']
    if build and build.get('status') in ('regressions', 'failed'):
        reasons['blocked'].append(f"last build: {build.get('status')} ({len(build.get('regressions') or [])} "
                                  'regressions), not installed')
    stale = stale_inputs(p, suite) if suite else []
    if stale is None:
        warnings.append('the installed package records no package.inputs: staleness unknown')
    reasons['stale'] += [f'{s} changed since the package' for s in stale or []]
    entries = pq.parse(p.questions)
    qsum = pq.summary(entries)
    reasons['needs-answers'] += [f'{i} is blocking and unanswered' for i in qsum['blocking']]
    plan = read_json(p.plan, 'plan') if p.plan.is_file() else {}
    checked = (plan.get('api') or {}).get('_checkedAgainst') if isinstance(plan.get('api'), dict) else None
    if sol_hash and checked != sol_hash:
        reasons['needs-api-check'].append('solution src/main ' + ('changed since the api check' if checked
                                                                  else 'present, api never checked against it'))
    if not sol_hash:
        reasons['drafted'].append('no solution src/main yet')
    state = next(s for s in ORDER if reasons[s] or s == 'ready')
    scope, why = scope_of(p, plan)
    if why:
        warnings.append(why)
    cov = (suite or {}).get('coverage') or {}
    totals = cov.get('totals') or {}
    outside_lines = totals.get('outsideLines', sum((cov.get('outside') or {}).values()))
    warnings += cov.get('warnings') or []
    try:
        recording_db(p.mu)
    except Exception as e:  # noqa: BLE001 - the report must render without the database config
        warnings.append(f'recording database not resolved: {e}')
    pk = (suite or {}).get('package') or {}
    api_at = now if a.api_checked else (old.get('timestamps') or {}).get('apiChecked')
    doc = {
        'entry': p.entry, 'state': state, 'scope': scope, 'reasons': {k: v for k, v in reasons.items() if v},
        'package': {'version': pk.get('version'), 'contentHash': pk.get('contentHash'), 'path': p.rel(p.suite)},
        'counts': counts(cases),
        'coverage': {'paragraphs': totals.get('paragraphs') or {}, 'lines': totals.get('lines') or {},
                     'outsideLines': outside_lines, 'estimated': bool(totals.get('estimated'))},
        'inputs': p.inputs(), 'packageInputs': pk.get('inputs'), 'stale': stale or [],
        'solution': {'present': bool(solution_dirs(p)), 'hash': sol_hash, 'checkedAgainst': checked},
        'questions': qsum, 'warnings': warnings,
        'timestamps': {'written': now, 'apiChecked': api_at, 'build': _mtime(p.tmp / 'build.json'), 'package': _mtime(p.suite)},
    }
    write_json(p.state, doc)
    if suite is not None and pk.get('state') != state:
        before = content_hash(suite)
        suite['package']['state'] = state
        if content_hash(suite) != before:
            raise Stop('setting package.state would change the contentHash')
        st = p.suite.stat()
        write_json(p.suite, suite)
        os.utime(p.suite, ns=(st.st_atime_ns, st.st_mtime_ns))  # package.state is no install: keep its time
    write_text(p.report, render(p, doc, build))
    out = {'state': state, 'scope': scope, 'reasons': doc['reasons'], 'counts': doc['counts'], 'stale': doc['stale'],
           'questions': {k: qsum[k] for k in ('open', 'blocking', 'answered')}, 'stateFile': p.rel(p.state),
           'report': p.rel(p.report), 'warnings': [why] if why else []}
    return (0 if state in ('ready', 'drafted') else 2), {'status': state, **out}


if __name__ == '__main__':
    main(run)
