#!/usr/bin/env python3
"""What the command needs before it starts, and what changed since the installed package.

    python -B preflight.py <mu> [--entry E] [--offline]

Hard blocks (exit 1, listed in `blocks`): mu.yaml, design/rules.md, design/tests.md,
extracted-logic/ with paragraph-index.json, unit/<E>/ complete (sources/ with members, driver.cbl,
cases.json, schema.yaml), unit/schema.sql; tools.yaml golden-db2 (btlib.recording_db; when missing,
`add` holds the section to add), also with --offline; the cobol-runner health URL (tools.yaml
cobol-runner url + health) answers; the recording database is reachable (db.py --check). --offline
skips the runner and database checks (reported under `skipped`).
Also reported: `answers` (PQ entries whose Answer is filled and not settled: apply them this run),
`blocking` (open blocking PQ ids), `stale` (package.inputs of the installed package that differ
from the current files), `solution` (mu.yaml `solution` folder holds a src/main), plan/package
presence, and warnings. Exit 0 when nothing blocks.
Importable: hard_blocks(p), stale_inputs(p, suite), solution_dirs(p), solution_hash(p).
"""

import json
import subprocess
import sys
import urllib.request
from pathlib import Path

sys.dont_write_bytecode = True

import questions as pq  # noqa: E402
from btlib import HERE, Paths, Stop, main, parser, read_json, recording_db, sha256, tool  # noqa: E402


def hard_blocks(p):
    """Missing read-only inputs, as a list of messages."""
    out = []
    need = [(p.mu / 'mu.yaml', 'file'), (p.rules_md, 'file'), (p.tests_md, 'file'),
            (p.mu / 'extracted-logic', 'dir'), (p.paragraph_index, 'file'), (p.unit, 'dir'), (p.sources, 'dir'),
            (p.driver, 'file'), (p.unit_cases, 'file'), (p.schema_yaml, 'file'), (p.ddl, 'file')]
    for f, kind in need:
        ok = f.is_file() if kind == 'file' else f.is_dir()
        if not ok:
            out.append(f'missing {kind} {p.rel(f)}')
    if p.sources.is_dir() and not any(x.is_file() for x in p.sources.iterdir()):
        out.append(f'{p.rel(p.sources)} holds no member')
    if p.paragraph_index.is_file():
        try:
            idx = json.loads(p.paragraph_index.read_text(encoding='utf-8'))
            if not (idx.get('programs') or {}):
                out.append(f'{p.rel(p.paragraph_index)} has no programs')
        except ValueError as e:
            out.append(f'{p.rel(p.paragraph_index)} is not valid JSON: {e}')
    return out


def stale_inputs(p, suite):
    """Paths of package.inputs whose sha256 differs from the current file (None: the package
    records no inputs)."""
    rec = (suite or {}).get('package', {}).get('inputs')
    if not rec:
        return None
    cur = p.inputs()
    return sorted(k for k in set(rec) | set(cur) if rec.get(k) != cur.get(k))


def solution_root(p):
    sol = p.manifest().get('solution')
    return Path(sol) if sol else None


def solution_dirs(p):
    """Every src/main folder under the mu.yaml `solution` folder (relative to the workspace root),
    build output (target/, build/, node_modules/) left out."""
    root = solution_root(p)
    if not root or not root.is_dir():
        return []
    skip = {'target', 'build', 'node_modules', '.git'}
    return sorted(d for d in root.rglob('main') if d.is_dir() and d.parent.name == 'src'
                  and not skip & set(d.relative_to(root).parts))


def solution_hash(p):
    """sha256 over (path, sha256) of every file under the solution's src/main folders, or None."""
    dirs = solution_dirs(p)
    if not dirs:
        return None
    root = solution_root(p)
    files = sorted((f.relative_to(root).as_posix(), sha256(f.read_bytes()))
                   for d in dirs for f in d.rglob('*') if f.is_file())
    return sha256(json.dumps(files, separators=(',', ':')))


def runner_health(p):
    r = tool(p.mu, 'cobol-runner', required=False) or {}
    if not r.get('url'):
        return 'tools.yaml has no cobol-runner url'
    url = str(r['url']).rstrip('/') + (r.get('health') or '/health')
    try:
        with urllib.request.urlopen(url, timeout=5) as resp:
            if resp.status >= 400:
                return f'cobol-runner {url} answered {resp.status}'
    except Exception as e:  # noqa: BLE001 - any failure is "not reached"
        return f'cobol-runner {url} not reached: {e}'
    return None


def db_check(p):
    cmd = [sys.executable, '-B', str(HERE / 'db.py'), str(p.mu), '--entry', p.entry, '--check']
    try:
        r = subprocess.run(cmd, stdin=subprocess.DEVNULL, capture_output=True, encoding='utf-8', errors='replace',
                           timeout=180)
    except (OSError, subprocess.TimeoutExpired) as e:
        return f'db.py --check did not finish: {e}', {}
    try:
        doc = json.loads((r.stdout or '').strip().splitlines()[-1])
    except (ValueError, IndexError):
        doc = {}
    if r.returncode == 1:
        return f"database not reachable: {doc.get('error') or (r.stderr or '').strip()[-300:]}", doc
    return None, doc


def run():
    ap = parser('Check the inputs, the runner and the database before a run.')
    ap.add_argument('--offline', action='store_true', help='skip the runner and database checks')
    a = ap.parse_args()
    try:
        p = Paths(a.mu, a.entry)
    except Stop as e:
        return 1, {'status': 'blocked', 'blocks': [str(e)]}
    blocks = hard_blocks(p)
    skipped, warnings, add = [], [], None
    try:
        recording_db(p.mu)
    except Stop as e:
        blocks.append(str(e))
        add = e.extra.get('add')
    if a.offline:
        skipped = ['runner', 'database']
    else:
        h = runner_health(p)
        if h:
            blocks.append(h)
        d, doc = db_check(p)
        if d:
            blocks.append(d)
        if doc.get('missing'):
            warnings.append(f"tables missing in the recording database: {doc['missing']} (db.py --create-tables)")
    entries = pq.parse(p.questions)
    suite = read_json(p.suite, 'package') if p.suite.is_file() else None
    stale = stale_inputs(p, suite)
    if suite is not None and stale is None:
        warnings.append('the installed package records no package.inputs: staleness unknown')
    dirs = solution_dirs(p)
    doc = {'entry': p.entry, 'blocks': blocks, 'skipped': skipped,
           'answers': [{k: e[k] for k in ('id', 'title', 'status', 'blocking', 'affects', 'answer')}
                       for e in pq.answered(entries)],
           'blocking': [e['id'] for e in pq.open_blocking(entries)],
           'stale': stale or [], 'plan': p.plan.is_file(), 'package': p.suite.is_file(),
           'packageVersion': (suite or {}).get('package', {}).get('version'),
           'solution': {'present': bool(dirs), 'srcMain': [p.rel(d) for d in dirs]},
           'warnings': warnings}
    if add:
        doc['add'] = add
    if blocks:
        doc['status'] = 'blocked'
        return 1, doc
    return 0, doc


if __name__ == '__main__':
    main(run)
