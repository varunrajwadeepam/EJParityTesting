#!/usr/bin/env python3
"""Run every case of an entry point against the real COBOL and cache what it did.

    python -B record.py <mu> [--entry E] [--force] [--repeats n] [--new-contract] [--run-id ID]

Each run goes through run-cobol (run_cobol.py, never modified): the unit's sources/ and
driver.cbl, the runner of tools.yaml, and the recording database (tools.yaml golden-db2, required;
db.py). Per run, in order: every table of unit/schema.sql emptied (children first), the
case's fixture, the build-and-run, the case's table checks (raw, as the CLP renders them, and
typed, one JSON object per row). A case therefore sees its fixture rows and nothing else.

Runs needed:
  * the cases of the base suite (previous/<E>/<E>-tests.json) - only when something they rest on
    changed: members, driver, fixture, DDL, shims, runner or Db2 image, database, env. Otherwise
    they are CARRIED FORWARD (build.py takes them from the base suite, index.json "$carried"),
  * every plan case whose name is not a base case,
  * for every case with COBOL inputs (base cases too, carried forward or not) one PROBE run: the
    same inputs once (repeats 1) at its probe clock - the default clock for a case at another
    clock, else defaults.probeClock - with every clock-derived input (`clock:<fmt>`) evaluated at
    that clock. build.py decides clockSensitive from it; a probe is never legacy, never coverage.

The clock reaches the shims as CAGENSHIM_CLOCK (14 digits, or 20 with the fraction padded).
Every run is made `repeats` times (plan defaults.repeats, default 2) and cached under
tests/.tmp/<E>/runs/<key>.json; the key covers inputs, clock, fixture, shims, the checks and the
fingerprint, so an unchanged run is never repeated and a changed one always is. --force runs
everything again.

A fixture that does not apply, or a runner that is not reached, is the stack's failure, not the
program's: retried twice after 30 s, never cached, and then the recording stops (exit 1).

Every run, failed ones too, leaves tests/.tmp/<E>/record.json: status ok|failed, runId (--run-id,
else rotate.py's), startedAt/finishedAt, counts, carried, resetTables (the list emptied before every
run; build.py publishes the same), failures[{case, reason}]. state.py reads it.
"""

import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

sys.dont_write_bytecode = True

from btlib import (RUN_COBOL, Paths, Stop, bad_clocks, check_inputs, check_key, checks_changed, checks_of, clock_inputs, conn, contract_errors,  # noqa: E402
                   db_env, ddl, defaults, dumps, eprint, fingerprint, fingerprint_id, iso_now, key_of, load_base,
                   load_plan, main, outputs_map, parity_commit, parser, plan_inputs, probe_clock, read_json,
                   read_text, recording_db, reset_sql, reset_tables, run_cobol, run_key, schema_fields, shim_clock,
                   tool, verify_queries, write_json)

RUN_ENV = {'GIXSQL_AUTOCOMMIT': 'off'}
RETRY_WAIT = int(os.environ.get('BT_RETRY_WAIT', '30'))


def run():
    ap = parser('Record every case on the real COBOL (run-cobol) and cache the runs.')
    ap.add_argument('--force', action='store_true', help='run everything again')
    ap.add_argument('--repeats', type=int, help='runs per case (default plan defaults.repeats, else 2)')
    ap.add_argument('--new-contract', action='store_true', help="the plan's outputs replace the base legacySchema")
    ap.add_argument('--run-id', help='the run this recording belongs to (default: the id rotate.py kept)')
    a = ap.parse_args()
    p = Paths(a.mu, a.entry)
    marker = p.tmp / 'rotated'
    res = {'entry': p.entry, 'runId': a.run_id or (read_text(marker).strip() if marker.is_file() else None) or None,
           'startedAt': iso_now(), 'counts': {}, 'carried': 0}

    def finish(status, failures):
        write_json(p.tmp / 'record.json', {'status': status, **res, 'finishedAt': iso_now(), 'failures': failures})
    try:
        doc = record(a, p, res)
    except Stop as e:
        finish('failed', [{'case': e.extra.get('case'), 'reason': str(e)}])
        raise
    except (Exception, SystemExit) as e:  # noqa: BLE001 - record.json is written on every run; main() reports it
        why = str(e.code) if isinstance(e, SystemExit) else f'{type(e).__name__}: {e}'
        finish('failed', [{'case': None, 'reason': why}])
        raise
    finish('ok', [])
    return {**doc, 'result': p.rel(p.tmp / 'record.json')}


def record(a, p, rec):
    plan = load_plan(p)
    bad = contract_errors(p, plan, {'new-contract': a.new_contract})
    if bad:
        raise Stop("the plan breaks the naming rules or the base suite's contract (PLAN.md \"Names\")", errors=bad)
    clocks = bad_clocks(plan)
    if clocks:
        raise Stop('clocks: ^[0-9]{14}([0-9]{1,6})?$, and defaults.probeClock other than defaults.clock', errors=clocks)
    base = load_base(p)
    db = recording_db(p.mu)
    rc = run_cobol(db)
    runner = tool(p.mu, 'cobol-runner')['url']
    tables = ddl(p)
    fields = schema_fields(p)
    dflt = defaults(plan)
    shims = dflt.get('shims') or ['cagen']
    repeats = int(a.repeats or dflt.get('repeats') or 2)
    force = bool(a.force)
    p.runs.mkdir(parents=True, exist_ok=True)
    commit = parity_commit(p)
    prints = {}

    def fp_of(fixture):
        if fixture not in prints:
            prints[fixture] = fingerprint(p, fixture, shims, db, RUN_ENV)
        return prints[fixture]

    jobs = []

    def want(label, inputs, clock, fixture, checks, n=None):
        check_inputs(inputs, fields, label)
        if fixture and not (p.fixtures / fixture).is_file():
            raise Stop(f'{label}: fixture {fixture} is not in {p.rel(p.fixtures)}', case=label)
        jobs.append({'label': label, 'inputs': inputs, 'clock': clock, 'fixture': fixture, 'checks': checks,
                     'verify': verify_queries(plan, {'checks': checks}, tables), 'repeats': n or repeats})

    removed = plan.get('removed') or {}
    base_cases = (base or {}).get('cases') or []
    base_names = {c.get('name') for c in base_cases}
    IN = key_of((base or {}).get('legacySchema') or {}, '$inputs')
    plan_by_name = {c.get('name'): c for c in plan.get('cases') or []}
    kept = [c for c in base_cases if IN and (c.get('legacy') or {}).get(IN) is not None and c.get('name') not in removed]

    def case_checks(c):
        pc = plan_by_name.get(c.get('name'))
        return checks_of(plan, pc if pc is not None else {'name': c.get('name')})

    def stale(c):
        sql = checks_changed(plan, c, case_checks(c))
        if sql:
            return f"check SQL changed: {', '.join(sql)}"
        was = (c.get('recording') or {}).get('fingerprint')
        now = fp_of(c.get('fixture') or dflt.get('fixture'))
        if was == fingerprint_id(now):
            return None
        before = ((base or {}).get('recordings') or {}).get(was) or {}
        changed = [k for k in now if dumps(before.get(k)) != dumps(now[k])]
        return f"recorded on {was}, today is {fingerprint_id(now)} (changed: {', '.join(changed) or 'unknown'})"

    why = '--force' if force else next((f"{c['id']} {c['name']} is removed by the plan"
                                        for c in base_cases if c.get('name') in removed), None)
    if not why:
        why = next((f"{c['id']} {c['name']}: {r}" for c in kept for r in [stale(c)] if r), None)
    carried = {}
    if kept and not why:
        carried = {f"suite:{c['name']}": c['recording']['fingerprint'] for c in kept}
        eprint(f"{len(kept)} base cases carried forward: each was recorded on today's fingerprint")
    else:
        if kept:
            eprint(f'{len(kept)} base cases run again: {why}')
        for c in kept:
            inputs = [[f, v] for f, v in c['legacy'][IN].items()]
            want(f"suite:{c['name']}", inputs, c.get('clock') or dflt.get('clock'), c.get('fixture') or dflt.get('fixture'),
                 case_checks(c))
    for c in plan.get('cases') or []:
        if c.get('name') in base_names:
            continue
        clock = c.get('clock') or dflt.get('clock')
        want(f"plan:{c['name']}", plan_inputs(plan, c, fields['inputs'], clock), clock,
             c.get('fixture') or dflt.get('fixture'), checks_of(plan, c))
    # The probe run of every case (the carried base cases too): once, at its probe clock.
    probes = [(j['label'], j['inputs'], j['clock'], j['fixture'], j['checks']) for j in jobs]
    if carried:
        probes += [(f"suite:{c['name']}", [[f, v] for f, v in c['legacy'][IN].items()], c.get('clock') or dflt.get('clock'),
                    c.get('fixture') or dflt.get('fixture'), case_checks(c)) for c in kept]
    for label, inputs, clock, fixture, checks in probes:
        pclock = probe_clock(plan, clock)
        want(f'{label}@probe', clock_inputs(plan, inputs, pclock), pclock, fixture, checks, 1)

    index = {'$carried': carried} if carried else {}
    ran, done = 0, set()
    counts = rec['counts']
    counts.update(runsNeeded=len(jobs), probes=sum(1 for j in jobs if j['label'].endswith('@probe')), recorded=0,
                  fromCache=0)
    rec.update(carried=len(carried), database=f"{db['database']}/{db['schema']}", resetTables=reset_tables(tables))
    reset = reset_sql(tables)
    db2 = conn(db)
    env = {**os.environ, **db_env(db)}

    def once(j, n):
        problem = None
        for attempt in range(1, 4):
            ok, out = rc.db2_run(reset, quiet=True, stop=True)
            if not ok:
                problem = f'reset failed: {out[-300:]}'
            else:
                with tempfile.TemporaryDirectory() as d:
                    case = {'name': f'run-{n}', 'env': {'CAGENSHIM_CLOCK': shim_clock(j['clock'])}, 'inputs': j['inputs'],
                            'verify': j['verify']}
                    if j['fixture']:
                        case['fixture'] = str((p.fixtures / j['fixture']).resolve())
                    cfg = {'unit': p.entry, 'shims': shims, 'db2': db2, 'env': RUN_ENV, 'cases': [case]}
                    cf = Path(d) / 'cases.json'
                    cf.write_text(json.dumps(cfg), encoding='utf-8')
                    proc = subprocess.run([sys.executable, '-B', str(RUN_COBOL), str(p.unit.resolve()), '--cases', str(cf),
                                           '--out', d, '--runner', runner, '--all'], capture_output=True, text=True,
                                          encoding='utf-8', errors='replace', env=env)
                    out_file = Path(d) / f'run-{n}.json'
                    got = json.loads(out_file.read_text(encoding='utf-8')) if out_file.is_file() else None
                if got is None:
                    tail = (proc.stdout + proc.stderr).strip().splitlines()[-6:]
                    problem = 'run-cobol wrote no result (fixture failed or runner not reached): ' + ' | '.join(tail)
                elif got.get('fixture') and not got['fixture'].get('ok'):
                    problem = f"fixture failed: {got['fixture'].get('output', '')[:300]}"
                else:
                    bad_verify = {k: v for k, v in (got.get('verify') or {}).items() if not v.get('ok')}
                    if bad_verify:
                        lab, v = next(iter(bad_verify.items()))
                        hint = (' -- the typed form uses JSON_OBJECT; this Db2 may not have it') if lab.endswith('#typed') else ''
                        raise Stop(f"{j['label']}: check {lab} failed: {' | '.join(v.get('rows') or [])[:400]}{hint}",
                                   case=j['label'])
                    return got
            eprint(f"{j['label']}: {problem} (attempt {attempt})")
            if attempt < 3:
                time.sleep(RETRY_WAIT)
        write_json(p.tmp / 'index.json', index)
        raise Stop(f"{j['label']}: the stack cannot run this case; nothing was cached for it. Is the runner up, is the "
                   'database there (db.py --check)?', problem=problem, case=j['label'])

    for j in jobs:
        fp = fp_of(j['fixture'])
        key = run_key(j['inputs'], j['clock'], j['fixture'], shims, check_key(plan, j['checks'], tables), fingerprint_id(fp))
        index[j['label']] = key
        file = p.runs / f'{key}.json'
        if key in done or (file.is_file() and not force
                           and len(read_json(file, 'run').get('repeats') or []) >= j['repeats']):
            counts['fromCache'] += 1
            continue
        done.add(key)
        reps, first = [], None
        for n in range(1, j['repeats'] + 1):
            got = once(j, n)
            res = got.get('result') or {}
            first = first or got
            reps.append({'runId': res.get('runId'), 'recordedAt': iso_now(), 'ok': bool(res.get('ok')),
                         'outputs': outputs_map(res), 'verify': {k: v.get('rows') or [] for k, v in
                                                               (got.get('verify') or {}).items()},
                         'error': res.get('error'), 'stderr': ((res.get('run') or {}).get('stderr') or '')[-2000:],
                         'driverErrors': res.get('driverErrors') or []})
        write_json(file, {'label': j['label'], 'clock': j['clock'], 'fixture': j['fixture'], 'checks': j['checks'],
                          'inputs': j['inputs'], 'fingerprint': fp, 'parityTester': commit,
                          'recordedAt': reps[0]['recordedAt'], 'coverage': (first.get('result') or {}).get('coverage'),
                          'repeats': reps})
        ran += 1
        counts['recorded'] = ran
        eprint(f"{j['label']}  ok={reps[0]['ok']}  runIds={','.join(str(r['runId']) for r in reps)}")
    write_json(p.tmp / 'index.json', index)
    return {'entry': p.entry, 'database': f"{db['database']}/{db['schema']}", 'runsNeeded': len(jobs),
            'probes': sum(1 for j in jobs if j['label'].endswith('@probe')),
            'repeats': repeats, 'recorded': ran, 'fromCache': len(jobs) - ran, 'carried': len(carried),
            'runs': p.rel(p.runs), 'index': p.rel(p.tmp / 'index.json')}


if __name__ == '__main__':
    main(run)
