#!/usr/bin/env python3
"""The arms table tests/notes/<E>-arms.md: which case proves which arm of which business paragraph.

    python -B arms.py <mu> [--entry E] skeleton
    python -B arms.py <mu> [--entry E] check

skeleton  from extracted-logic/paragraph-index.json (business paragraphs only) and design/rules.md
          writes one table per program:
              | arm id | program.paragraph | lines | condition (agent) | rule ids | case ids |
          one row per paragraph, prefilled with its lines and the rules whose `From` cell cites it
          (`PROG` in backticks, then `PARA (from-to)`, comma separated). A paragraph listed in the
          rules.md table with a "Why no rule" column gets `no rule: <why>` as its rule cell.
          Rerun-safe: the existing file is merged - arm ids (A-<n>) stay, cells already filled are
          kept, rows the agent added (more arms of one paragraph, new A-<n>) are kept; an empty
          cell of a paragraph's first row is prefilled again. Rows of paragraphs no longer in the
          index are kept and listed as `orphans`. Text under `## Notes` is kept verbatim.
check     every arm has a rule id (R<n>, known to rules.md) or a PQ-<n> (in
          tests-open-questions.md) - `no rule:` rows are exempt from both checks - and >= 1 case
          id, each the id or the name of a case of the plan (or the id of an installed package
          case). Exit 2 with the gaps.
"""

import re
import sys

sys.dont_write_bytecode = True

import questions as pq  # noqa: E402
from btlib import Paths, Stop, design_rules, main, parser, read_json, read_text, write_text  # noqa: E402

COLS = ['arm id', 'program.paragraph', 'lines', 'condition (agent)', 'rule ids', 'case ids']
NO_RULE = 'no rule:'
_ARM = re.compile(r'^A-([0-9]+)$')


# ---------------------------------------------------------------- markdown tables

def _cells(line):
    s = line.strip()
    if s.startswith('|'):
        s = s[1:]
    if s.endswith('|') and not s.endswith('\\|'):
        s = s[:-1]
    return [c.strip().replace('\\|', '|') for c in re.split(r'(?<!\\)\|', s)]


def tables(text):
    """[(header cells, [row cells])] of every markdown table of the text."""
    out, block = [], []
    for line in text.splitlines() + ['']:
        if line.strip().startswith('|'):
            block.append(line)
            continue
        if len(block) >= 2 and re.fullmatch(r'[\s|:-]+', block[1]):
            out.append(([c.lower() for c in _cells(block[0])], [_cells(b) for b in block[2:]]))
        block = []
    return out


def _esc(v):
    return str(v or '').replace('|', '\\|').replace('\n', ' ').strip()


def _plain(cell):
    return cell.replace('`', '').strip()


# ---------------------------------------------------------------- rules.md

_CITE = re.compile(r'`([A-Za-z0-9#@$-]+)`|([A-Za-z0-9][A-Za-z0-9-]*)\s*\(\s*([0-9]+)\s*-\s*([0-9]+)\s*\)')


def citations(cell):
    """[(PROG, PARA, from, to)] of a From cell: a backticked program, then PARA (from-to)..."""
    out, prog = [], None
    for m in _CITE.finditer(cell or ''):
        if m.group(1):
            prog = m.group(1)
        elif prog:
            out.append((prog, m.group(2), int(m.group(3)), int(m.group(4))))
    return out


def rules_md(p):
    """({(PROG, PARA): [R<n>...]}, {(PROG, PARA): why}, [(PROG, PARA, from, to)] cited)."""
    if not p.rules_md.is_file():
        raise Stop(f'{p.rel(p.rules_md)} not found')
    cites, no_rule, cited = {}, {}, []
    for head, rows in tables(read_text(p.rules_md)):
        if 'from' in head and head and head[0] in ('#', 'rule', 'id'):
            fi = head.index('from')
            for r in rows:
                m = re.fullmatch(r'R?([0-9]+)', r[0].strip()) if r else None
                if not m or len(r) <= fi:
                    continue
                for c in citations(r[fi]):
                    cited.append(c)
                    ids = cites.setdefault(c[:2], [])
                    if f'R{m.group(1)}' not in ids:
                        ids.append(f'R{m.group(1)}')
        why = next((i for i, h in enumerate(head) if 'no rule' in h), None)
        if why is not None and 'paragraph' in head:
            mi = next((i for i, h in enumerate(head) if h in ('member', 'program')), 0)
            pi = head.index('paragraph')
            for r in rows:
                if len(r) > max(mi, pi, why):
                    no_rule[(_plain(r[mi]), _plain(r[pi]))] = _plain(r[why])
    return cites, no_rule, cited


def business(p):
    idx = read_json(p.paragraph_index, 'paragraph index')
    out = []
    for prog, v in (idx.get('programs') or {}).items():
        for para in v.get('paragraphs') or []:
            if para.get('kind') == 'business':
                lines = para.get('lines') or []
                out.append({'program': prog, 'name': para['name'],
                            'lines': f'{lines[0]}-{lines[1]}' if len(lines) == 2 else ''})
    return out


# ---------------------------------------------------------------- the arms file

def read_arms(p):
    """({program: [row dict]}, notes text) of the existing file."""
    if not p.arms.is_file():
        return {}, ''
    text = read_text(p.arms).replace('\r\n', '\n')
    notes = ''
    m = re.search(r'^## Notes[ \t]*$', text, re.M)
    if m:
        notes = text[m.end():].strip('\n')
        text = text[:m.start()]
    rows = {}
    for head, body in tables(text):
        if head[:1] != ['arm id']:
            continue
        for r in body:
            r = (r + [''] * len(COLS))[:len(COLS)]
            if not _ARM.match(r[0]):
                continue
            row = dict(zip(['arm', 'para', 'lines', 'condition', 'rules', 'cases'], r))
            prog = row['para'].split('.', 1)[0] or '?'
            rows.setdefault(prog, []).append(row)
    return rows, notes


def _n(arm):
    return int(_ARM.match(arm).group(1))


def skeleton(p):
    cites, no_rule, cited = rules_md(p)
    paras = business(p)
    old, notes = read_arms(p)
    by_para = {}
    for prog_rows in old.values():
        for r in prog_rows:
            by_para.setdefault(r['para'], []).append(r)
    used = [_n(r['arm']) for rs in by_para.values() for r in rs]
    nxt = max(used or [0]) + 1
    known = {f"{x['program']}.{x['name']}" for x in paras}
    out, added, prefilled, no_rule_rows = {}, 0, 0, 0
    for x in paras:
        key = f"{x['program']}.{x['name']}"
        rules = cites.get((x['program'], x['name'])) or []
        why = no_rule.get((x['program'], x['name']))
        prefill = ', '.join(rules) if rules else (f'{NO_RULE} {why}' if why else '')
        rows = sorted(by_para.get(key) or [], key=lambda r: _n(r['arm']))
        if not rows:
            rows = [{'arm': f'A-{nxt}', 'para': key, 'lines': '', 'condition': '', 'rules': '', 'cases': ''}]
            nxt += 1
            added += 1
        first = rows[0]
        if not first['lines']:
            first['lines'] = x['lines']
        if not first['rules'] and prefill:
            first['rules'] = prefill
        prefilled += bool(rules)
        no_rule_rows += bool(why and not rules)
        out.setdefault(x['program'], []).extend(rows)
    orphans = []
    for key, rows in by_para.items():
        if key not in known:
            prog = key.split('.', 1)[0] or '?'
            out.setdefault(prog, []).extend(sorted(rows, key=lambda r: _n(r['arm'])))
            orphans += [r['arm'] for r in rows]
    idx_names = {(x['program'], x['name']) for x in paras}
    warnings = sorted({f'rules.md cites {c[0]}.{c[1]} ({c[2]}-{c[3]}), not a business paragraph of the index'
                       for c in cited if (c[0], c[1]) not in idx_names})
    warnings += sorted(f'rules.md "no rule" lists {k[0]}.{k[1]}, not a business paragraph of the index'
                       for k in no_rule if k not in idx_names)
    lines = [f'# {p.entry} - arms', '',
             'Written by arms.py skeleton; kept on rerun. Fill condition, rule ids (R<n> or PQ-<n>) and case ids '
             '(plan names or ids). Several arms of one paragraph: add rows with new arm ids (A-<next>).', '']
    for prog, rows in out.items():
        lines += [f'## {prog}', '', '| ' + ' | '.join(COLS) + ' |', '|' + '---|' * len(COLS)]
        lines += ['| ' + ' | '.join(_esc(r[k]) for k in ('arm', 'para', 'lines', 'condition', 'rules', 'cases')) + ' |'
                  for r in rows]
        lines.append('')
    lines += ['## Notes', '']
    if notes:
        lines += [notes, '']
    write_text(p.arms, '\n'.join(lines))
    total = sum(len(r) for r in out.values())
    return {'arms': p.rel(p.arms), 'paragraphs': len(paras), 'rows': total, 'added': added,
            'prefilledRules': prefilled, 'noRuleRows': no_rule_rows,
            'withoutRule': len(paras) - prefilled - no_rule_rows, 'orphans': orphans,
            'programs': {k: len(v) for k, v in out.items()}, 'warnings': warnings}


def _tokens(cell):
    return [t for t in re.split(r'[\s,;]+', cell or '') if t]


def plan_case_keys(p):
    keys = set()
    if p.plan.is_file():
        for c in read_json(p.plan, 'plan').get('cases') or []:
            keys.update(str(c[k]) for k in ('id', 'name') if c.get(k))
    names = set(keys)
    if p.suite.is_file():
        for c in read_json(p.suite, 'package').get('cases') or []:
            if c.get('name') in names and c.get('id'):
                keys.add(str(c['id']))
    return keys


def check(p):
    if not p.arms.is_file():
        raise Stop(f'{p.rel(p.arms)} not found: run arms.py skeleton first')
    rows, _ = read_arms(p)
    known_rules = set(design_rules(p))
    known_pq = {e['id'] for e in pq.parse(p.questions)}
    cases = plan_case_keys(p)
    if not p.plan.is_file():
        raise Stop(f'no plan {p.rel(p.plan)}')
    gaps = {'noRule': [], 'unknownRule': [], 'unknownQuestion': [], 'noCase': [], 'unknownCase': []}
    total, exempt = 0, []
    for prog_rows in rows.values():
        for r in prog_rows:
            total += 1
            who = f"{r['arm']} {r['para']}"
            if r['rules'].lower().startswith(NO_RULE):
                exempt.append(r['arm'])
                continue
            toks = _tokens(r['rules'])
            rids = [t for t in toks if re.fullmatch(r'R[0-9]+', t)]
            qids = [t for t in toks if re.fullmatch(r'PQ-[0-9]+', t)]
            if not rids and not qids:
                gaps['noRule'].append(who)
            gaps['unknownRule'] += [f'{who}: {t}' for t in rids if known_rules and t not in known_rules]
            gaps['unknownQuestion'] += [f'{who}: {t}' for t in qids if t not in known_pq]
            cids = [t for t in _tokens(r['cases']) if t not in ('-', '—')]
            if not cids:
                gaps['noCase'].append(who)
            gaps['unknownCase'] += [f'{who}: {t}' for t in cids if t not in cases]
    gaps = {k: v for k, v in gaps.items() if v}
    doc = {'arms': p.rel(p.arms), 'rows': total, 'exempt': exempt, 'gaps': gaps,
           'gapCount': sum(len(v) for v in gaps.values())}
    if gaps:
        doc['status'] = 'gaps'
        return 2, doc
    return 0, doc


def run():
    ap = parser('Write (skeleton) or check (check) the arms table of an entry point.')
    ap.add_argument('action', choices=['skeleton', 'check'])
    a = ap.parse_args()
    p = Paths(a.mu, a.entry)
    return skeleton(p) if a.action == 'skeleton' else check(p)


if __name__ == '__main__':
    main(run)
