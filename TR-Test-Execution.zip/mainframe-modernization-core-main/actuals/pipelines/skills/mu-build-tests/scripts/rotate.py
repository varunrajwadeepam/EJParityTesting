#!/usr/bin/env python3
"""Make the current version of an entry point's tests its previous one.

    python -B rotate.py <mu> [--entry E] [--run-id ID]

Run once per run of the command, first. An entry point has at most two versions:

  current   the package <mu>/tests/package/<E>/ (<E>-tests.json, the fixture files,
            traceability.md), the plan tests/plan/<E>.plan.json and the arms table
            tests/notes/<E>-arms.md
  previous  tests/previous/<E>/: a copy of the same files (one level) plus manifest.json, the
            base the new current is built from (record.py and build.py read the existing cases
            from previous/<E>/<E>-tests.json). Validation never reads it.

Once per run: the run id is kept in tests/.tmp/<E>/rotated; a second call with the same
--run-id rotates nothing. Without --run-id a new id is made (and returned). Without a
published package nothing is rotated (bootstrap, or previous/ is already the base).
Warns, never fixes, when a working fixture differs from the package's copy.
"""

import shutil
import sys
from datetime import datetime, timezone

sys.dont_write_bytecode = True

from btlib import Paths, dumps, eprint, file_sha, iso_now, main, parser, read_text, write_text  # noqa: E402


def run():
    ap = parser('Copy the current package, plan and arms table to tests/previous/<E>/.')
    ap.add_argument('--run-id', help='the run this rotation belongs to (once per run)')
    a = ap.parse_args()
    p = Paths(a.mu, a.entry)
    run_id = a.run_id or datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    marker = p.tmp / 'rotated'
    base = {'entry': p.entry, 'runId': run_id, 'previous': p.rel(p.previous)}
    if a.run_id and marker.is_file() and read_text(marker).strip() == a.run_id:
        return {**base, 'status': 'already-rotated', 'rotated': False}
    if not p.suite.is_file():
        state = 'previous is the base' if (p.previous / p.suite.name).is_file() else 'bootstrap'
        write_text(marker, run_id + '\n')
        return {**base, 'status': 'nothing-to-rotate', 'rotated': False, 'reason': f'no package {p.rel(p.suite)} ({state})'}
    files = {f.name: f for f in sorted(p.package.iterdir()) if f.is_file()}
    files[p.plan.name] = p.plan
    files[p.arms.name] = p.arms
    if p.previous.exists():
        shutil.rmtree(p.previous)
    p.previous.mkdir(parents=True)
    manifest = {'rotatedAt': iso_now(), 'runId': run_id, 'files': {}}
    copied, absent = [], []
    for name, src in files.items():
        if not src.is_file():
            manifest['files'][name] = None
            absent.append(name)
            continue
        shutil.copyfile(src, p.previous / name)
        manifest['files'][name] = {'from': p.rel(src), 'sha256': file_sha(src)}
        copied.append(name)
    write_text(p.previous / 'manifest.json', dumps(manifest, 2) + '\n')
    write_text(marker, run_id + '\n')
    warnings = []
    for f in sorted(p.package.glob('*.sql')):
        work = p.fixtures / f.name
        if work.is_file() and work.read_bytes() != f.read_bytes():
            warnings.append(f'{p.rel(work)} differs from the package copy: the build lists the cases it changes')
    for w in warnings:
        eprint(f'warning: {w}')
    return {**base, 'status': 'rotated', 'rotated': True, 'copied': copied, 'absent': absent, 'warnings': warnings}


if __name__ == '__main__':
    main(run)
