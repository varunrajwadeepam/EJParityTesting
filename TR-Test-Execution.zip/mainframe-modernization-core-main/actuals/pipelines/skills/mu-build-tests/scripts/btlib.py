"""Shared helpers of the mu-build-tests scripts.

Everything that decides WHAT a case is lives in the plan (written by the agent, import_unit for
the basic cases). Everything that decides what a case SAYS lives in the run cache (record.py, from
the real COBOL through run-cobol). build.py only combines the two, so the same plan and the same
runs always produce the same package.

Python 3.10+, standard library plus PyYAML (through tools_config.py). Run from the workspace root
(the folder holding mu/). Every script prints exactly one JSON object on stdout (human detail on
stderr or in files) and exits 0 done, 2 decision or input needed, 1 failed.
"""

import argparse
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
import traceback
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path

for _stream in (sys.stdout, sys.stderr):
    if hasattr(_stream, 'reconfigure'):
        _stream.reconfigure(encoding='utf-8', errors='replace', newline='\n')

HERE = Path(__file__).resolve().parent
SKILL = HERE.parent                                # ${CLAUDE_PLUGIN_ROOT}/skills/mu-build-tests
SKILLS = SKILL.parent                              # ${CLAUDE_PLUGIN_ROOT}/skills
TOOLS_CONFIG = SKILLS.parent / 'scripts' / 'tools_config.py'
# BT_RUN_COBOL replaces run-cobol only for selftest.py (a stand-in that needs no stack).
RUN_COBOL = Path(os.environ.get('BT_RUN_COBOL') or SKILLS / 'run-cobol' / 'scripts' / 'run_cobol.py')
GENERATOR = 'mu-build-tests'
FORMAT = 3
SCHEMA_ID = 'mu-build-tests/tests.schema.json'
CATEGORIES = ['Happy', 'Edge', 'Boundary', 'Error', 'Robustness', 'Duplicate', 'Metamorphic']
STATUSES = ['golden', 'not-representable', 'not-recorded']
# package.statuses when neither the plan's suiteHeader.statuses nor the base suite names one.
STATUS_TEXTS = {
    'golden': 'recorded from the real COBOL run',
    'not-representable': 'no API request means this COBOL call; legacy recorded for reference',
    'not-recorded': "the COBOL run aborted, or its repeats disagreed; reason is the runtime error line or 'not repeatable'",
}
CASE_NAME = re.compile(r'^[a-z0-9]+(-[a-z0-9]+)*\Z')
ORIGINS = ['basic', 'advanced']
RESERVED_KEYS = ('verify', 'tables', 'technicalFailure')
CLOCK = re.compile(r'^[0-9]{14}([0-9]{1,6})?\Z')
# The files a package rests on besides the plan and the runs: package.inputs (outside the seal).
INPUT_FILES = ('design/rules.md', 'design/tests.md', 'extracted-logic/paragraph-index.json', 'unit/schema.sql')

# The CA Gen technical-failure fields (GLOBDATA). A plan overrides them with
# `technicalFailure: { flag, ok: [...], fields: { <name>: <field> } }`.
CAGEN_FAILURE = {
    'flag': 'STATUS-FLAG',
    'ok': ['', 'OK'],
    'fields': {'statusFlag': 'STATUS-FLAG', 'lastStatus': 'LAST-STATUS', 'errorEncountered': 'ERROR-ENCOUNTERED-SW',
               'failedIn': 'CUR-AB-NAME', 'savedSqlcode': 'SAVED-SQLCODE'},
}


class Stop(Exception):
    """A condition the scripts refuse to continue under. code 1 = failed, 2 = decision or input
    needed; extra keyword arguments go into the JSON answer."""

    def __init__(self, message, code=1, **extra):
        super().__init__(message)
        self.code = code
        self.extra = extra


def eprint(*xs):
    print(*xs, file=sys.stderr)


def emit(doc):
    """The one JSON object on stdout."""
    sys.stdout.write(json.dumps(_plain(doc), ensure_ascii=True) + '\n')
    sys.stdout.flush()


def main(fn):
    """fn() returns (exit code, answer dict) or an answer dict (exit 0)."""
    try:
        r = fn()
        code, doc = r if isinstance(r, tuple) else (0, r)
    except Stop as e:
        eprint(f'ERROR {e}')
        code = e.code
        doc = {'status': 'failed' if code == 1 else 'needs-input', 'error': str(e), **e.extra}
    except SystemExit as e:
        if not isinstance(e.code, str):     # usage errors (Parser.error) have emitted their JSON already
            raise
        eprint(f'ERROR {e.code}')           # sys.exit(message) of a loaded module (tools_config)
        code, doc = 1, {'status': 'failed', 'error': e.code}
    except Exception as e:  # noqa: BLE001 - a crash is still one JSON object on stdout, exit 1
        traceback.print_exc(file=sys.stderr)
        code, doc = 1, {'status': 'failed', 'error': f'{type(e).__name__}: {e}'}
    doc = dict(doc or {})
    doc.setdefault('status', 'ok' if code == 0 else 'needs-input' if code == 2 else 'failed')
    emit(doc)
    sys.exit(code)


class Parser(argparse.ArgumentParser):
    """argparse whose usage errors come back as one JSON object, exit 1."""

    def error(self, message):
        emit({'status': 'failed', 'error': f'usage: {message}', 'usage': self.format_usage().strip()})
        sys.exit(1)


def parser(description, entry=True):
    ap = Parser(description=description)
    ap.add_argument('mu', help='the MU folder, mu/<MU>')
    if entry:
        ap.add_argument('--entry', help='entry point (default: the first of mu.yaml entry_points)')
    return ap


# ---------------------------------------------------------------- files

def read_text(path, encoding='utf-8'):
    with open(path, encoding=encoding, errors='replace', newline='') as fh:
        return fh.read()


def write_text(path, text):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding='utf-8', newline='\n') as fh:
        fh.write(text)


def read_json(path, what):
    try:
        return json.loads(read_text(path), parse_float=Decimal)
    except FileNotFoundError:
        raise Stop(f'{what} {path} not found') from None
    except ValueError as e:
        raise Stop(f'{what} {path} is not valid JSON: {e}') from None


def _plain(v):
    if isinstance(v, Decimal):
        return int(v) if v == v.to_integral_value() and 'E' not in str(v) and '.' not in str(v) else float(v)
    if isinstance(v, dict):
        return {k: _plain(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [_plain(x) for x in v]
    if isinstance(v, Path):
        return v.as_posix()
    return v


def dumps(v, indent=None):
    v = _plain(v)
    if indent is None:
        return json.dumps(v, ensure_ascii=False, separators=(',', ':'), sort_keys=False)
    return json.dumps(v, ensure_ascii=False, indent=indent)


def canonical(v):
    """Canonical JSON: sorted keys, compact, UTF-8 bytes (what contentHash is taken of)."""
    return json.dumps(_plain(v), ensure_ascii=False, separators=(',', ':'), sort_keys=True).encode('utf-8')


def content_hash(doc):
    """sha256 of the canonical JSON of a package without its `package` block."""
    return sha256(canonical({k: v for k, v in doc.items() if k != 'package'}))


def write_json(path, v):
    write_text(path, dumps(v, 2) + '\n')


def sha256(data):
    return hashlib.sha256(data.encode('utf-8') if isinstance(data, str) else data).hexdigest()


def file_sha(path):
    return sha256(Path(path).read_bytes()) if Path(path).is_file() else None


def iso_now():
    t = datetime.now(timezone.utc)
    return t.strftime('%Y-%m-%dT%H:%M:%S.') + f'{t.microsecond // 1000:03d}Z'


# ---------------------------------------------------------------- paths

class Paths:
    """Where one entry point's tests live. `mu` is relative to the workspace root."""

    def __init__(self, mu, entry=None):
        self.mu = Path(mu)
        if not (self.mu / 'mu.yaml').is_file():
            raise Stop(f'{self.mu}/mu.yaml not found: run from the workspace root with the MU folder (mu/<MU>)')
        entries = self.manifest().get('entry_points') or []
        if entry is None:
            if not entries:
                raise Stop('mu.yaml names no entry point: pass --entry <ENTRY>')
            entry = entries[0]
        elif entries and entry not in entries:
            raise Stop(f'--entry {entry} is not in mu.yaml entry_points {entries}')
        self.entry = entry
        # read only
        self.unit = self.mu / 'unit' / entry                     # run-cobol's unit
        self.sources = self.unit / 'sources'
        self.driver = self.unit / 'driver.cbl'
        self.schema_yaml = self.unit / 'schema.yaml'
        self.unit_cases = self.unit / 'cases.json'
        self.ddl = self.mu / 'unit' / 'schema.sql'
        self.design = self.mu / 'design'
        self.rules_md = self.design / 'rules.md'
        self.tests_md = self.design / 'tests.md'
        self.paragraph_index = self.mu / 'extracted-logic' / 'paragraph-index.json'
        # written by the command
        self.tests = self.mu / 'tests'
        self.plan = self.tests / 'plan' / f'{entry}.plan.json'
        self.fixtures = self.tests / 'fixtures' / entry          # working fixtures
        self.notes = self.tests / 'notes'
        self.arms = self.notes / f'{entry}-arms.md'
        self.package = self.tests / 'package' / entry
        self.suite = self.package / f'{entry}-tests.json'
        self.previous = self.tests / 'previous' / entry
        self.state = self.tests / 'tests-state.json'
        self.report = self.tests / 'tests-report.md'
        self.questions = self.tests / 'tests-open-questions.md'
        self.tmp = self.tests / '.tmp' / entry
        self.runs = self.tmp / 'runs'

    def manifest(self):
        import yaml
        return yaml.safe_load(read_text(self.mu / 'mu.yaml')) or {}

    def rel(self, path):
        try:
            return Path(path).resolve().relative_to(Path.cwd().resolve()).as_posix()
        except ValueError:
            return Path(path).as_posix()

    def inputs(self):
        """package.inputs: {path relative to the MU folder: sha256, null when absent}."""
        return {f: file_sha(self.mu / f) for f in INPUT_FILES}


# ---------------------------------------------------------------- tools.yaml, run-cobol

def _module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def tool(mu, name, required=True):
    """A tools.yaml section (secrets and {mu} resolved), or None when optional and absent."""
    cfg = _module(TOOLS_CONFIG, 'tools_config')
    import yaml
    raw = yaml.safe_load(read_text(Path(mu) / 'tools.yaml')) or {}
    if name not in raw:
        if required:
            raise Stop(f'no section "{name}" in {mu}/tools.yaml')
        return None
    return cfg.tool(str(mu), name)


def _ident(db):
    return (str(db.get('container') or '').lower(), str(db.get('database') or '').upper(),
            str(db.get('schema') or db.get('user') or '').upper())


GOLDEN_DB2_SECTION = """golden-db2:                               # mu-build-tests' recording database (emptied per case)
  kind: local
  container: parity-db2                   # the driver's DSN (TESTDB) is compiled in
  database: TESTDB
  schema: GM_<MU>                         # own schema, not the db2 / test-db2 one
  user: db2inst1
  password: testenv
"""


def recording_db(mu):
    """The database the recordings run on: tools.yaml `golden-db2` (required; db.py and record.py empty
    its tables). Keys: container, database, schema, user, password, runner_host, port; a key golden-db2
    leaves out comes from db2. Refused: no golden-db2, or one naming the database and schema of db2 or
    of test-db2."""
    db2 = tool(mu, 'db2', required=False) or {}
    src = tool(mu, 'golden-db2', required=False)
    if not src:
        raise Stop(f'{mu}/tools.yaml has no golden-db2 section: recordings empty every table, so they need an own '
                   'database or schema (no fallback to db2); add the section', add=GOLDEN_DB2_SECTION)

    def get(k, default=None):
        v = src.get(k)
        if v in (None, ''):
            v = db2.get(k)
        return default if v in (None, '') else v
    db = {'section': 'golden-db2', 'container': get('container'), 'database': str(get('database', 'TESTDB')),
          'user': str(get('user', 'db2inst1')), 'password': str(get('password', '')),
          'runner_host': str(get('runner_host', 'db2')), 'port': str(get('port', 50000))}
    db['schema'] = str(get('schema') or db['user']).upper()
    if not db['container']:
        raise Stop('tools.yaml golden-db2 names no container (the Db2 container the CLP runs in)')
    test = tool(mu, 'test-db2', required=False)
    for name, other in (('db2', db2), ('test-db2', test)):
        if not other:
            continue
        o = {'container': other.get('container') or db2.get('container'), 'database': other.get('database'),
             'schema': other.get('schema'), 'user': other.get('user')}
        if _ident(o) == _ident(db):
            raise Stop(f"golden-db2 names {db['database']}/{db['schema']} in {db['container']}, the {name} database: "
                       'recordings empty every table, give golden-db2 its own database or schema')
    return db


def db_env(db):
    """The RUN_COBOL_DB2_* variables run-cobol reads (at import, and in every subprocess)."""
    return {'RUN_COBOL_DB2_CONTAINER': db['container'], 'RUN_COBOL_DB2_DATABASE': db['database'],
            'RUN_COBOL_DB2_SCHEMA': db['schema'], 'RUN_COBOL_DB2_USER': db['user'],
            'RUN_COBOL_DB2_PASSWORD': db['password'], 'RUN_COBOL_DB2_HOSTNAME': db['runner_host'],
            'RUN_COBOL_DB2_PORT': db['port']}


def conn(db):
    """The cases file `db2` block: how the RUNNER connects. No `dsn`: the driver's DSN is compiled in
    and run-cobol's default is the one that matches it."""
    return {'database': db['database'], 'hostname': db['runner_host'], 'port': db['port'], 'user': db['user'],
            'password': db['password'], 'schema': db['schema']}


_RC = {}


def run_cobol(db):
    """The run-cobol script as a module, pointed at the recording database (its module-level defaults
    read RUN_COBOL_DB2_* when it is loaded, so the environment is set first)."""
    env = db_env(db)
    os.environ.update(env)
    key = (str(RUN_COBOL), dumps(env))
    if key not in _RC:
        _RC[key] = _module(RUN_COBOL, 'run_cobol')
    return _RC[key]


def db2_run(db, sql, stop=True, allowed=()):
    """SQL through the container's CLP against the recording database, in its schema."""
    return run_cobol(db).db2_run(sql, quiet=True, stop=stop, allowed=allowed)


# ---------------------------------------------------------------- schema.yaml and the DDL

def schema_types(p):
    """{'inputs': {name: type}, 'outputs': {name: type}} from schema.yaml (type as written)."""
    import yaml
    doc = yaml.safe_load(read_text(p.schema_yaml)) or {}
    return {side: {f['name']: str(f.get('type', '')) for f in doc.get(side) or []} for side in ('inputs', 'outputs')}


def schema_fields(p):
    """{'inputs': {name: occurs or None}, 'outputs': {name: occurs or None}} from schema.yaml."""
    out = {}
    for side, fields in schema_types(p).items():
        out[side] = {}
        for name, t in fields.items():
            m = re.search(r'OCCURS\s+([0-9]+)', t)
            out[side][name] = int(m.group(1)) if m else None
    return out


def field_width(types, field):
    """The width of an alphanumeric input field (`X(25)` -> 25, `X` -> 1); None for any other type."""
    m = re.fullmatch(r'\s*X(?:\(([0-9]+)\))?\s*', (types or {}).get('inputs', {}).get(field, '') or '')
    return (int(m.group(1)) if m.group(1) else 1) if m else None


_COL = re.compile(r'^\s*"?([A-Z][A-Z0-9_#$@]*)"?\s+([A-Z]+(?:\s+[A-Z]+)*?(?:\s*\([0-9 ,]+\))?)(?=\s|,|$)', re.I)
_SKIP = {'CONSTRAINT', 'PRIMARY', 'FOREIGN', 'UNIQUE', 'CHECK'}


def ddl(p):
    """Tables of unit/schema.sql: {TABLE: {'columns': {COL: type}, 'parents': [TABLE]}}, in file order."""
    if not p.ddl.is_file():
        raise Stop(f'{p.ddl} not found: the unit has no schema.sql (run-cobol, "The tables")')
    text = '\n'.join(line.split('--', 1)[0] for line in read_text(p.ddl).splitlines())
    tables = {}
    for m in re.finditer(r'CREATE\s+TABLE\s+(?:"?\w+"?\.)?"?(\w+)"?\s*\((.*?)\)\s*;', text, re.I | re.S):
        name, body = m.group(1).upper(), m.group(2)
        cols, parents = {}, []
        depth, part, parts = 0, '', []
        for ch in body:
            depth += ch == '('
            depth -= ch == ')'
            if ch == ',' and depth == 0:
                parts.append(part)
                part = ''
            else:
                part += ch
        parts.append(part)
        for item in parts:
            ref = re.search(r'REFERENCES\s+(?:"?\w+"?\.)?"?(\w+)"?', item, re.I)
            if ref:
                parents.append(ref.group(1).upper())
            c = _COL.match(item)
            if c and c.group(1).upper() not in _SKIP:
                cols[c.group(1).upper()] = re.sub(r'\s+', ' ', c.group(2).upper()).replace(' (', '(')
        tables[name] = {'columns': cols, 'parents': parents}
    return tables


def reset_tables(tables):
    """The one reset list: every table of unit/schema.sql (`tables` = ddl(p)), children before
    parents, so a reset never meets a RESTRICT foreign key. record.py and db.py --reset empty these
    before every run; build.py publishes the same list as the package's resetTables."""
    order, seen = [], set()

    def visit(t, path=()):
        if t in seen or t in path:
            return
        for child in [c for c, v in tables.items() if t in v['parents'] and c != t]:
            visit(child, path + (t,))
        seen.add(t)
        order.append(t)
    for t in tables:
        visit(t)
    return order


def reset_sql(tables):
    return '\n'.join(f'DELETE FROM {t};' for t in reset_tables(tables)) + '\n'


def fixture_tables(path):
    """The tables a fixture file inserts into or deletes from."""
    if not path or not Path(path).is_file():
        return set()
    text = '\n'.join(line.split('--', 1)[0] for line in read_text(path).splitlines())
    return {m.group(1).upper() for m in re.finditer(r'\b(?:INSERT\s+INTO|DELETE\s+FROM)\s+(?:"?\w+"?\.)?"?(\w+)"?', text, re.I)}


def unknown_tables(plan, tables, fixture_files):
    """Tables the plan's checks or the fixtures name that unit/schema.sql does not declare."""
    want = {str(t.get('table', '')).upper() for t in (plan.get('tables') or {}).values()}
    for f in fixture_files:
        want |= fixture_tables(f)
    return sorted(t for t in want if t not in tables)


# ---------------------------------------------------------------- plan

def load_plan(p):
    if not p.plan.is_file():
        raise Stop(f'no plan {p.rel(p.plan)}: copy templates/plan.template.json there first (PLAN.md)')
    return read_json(p.plan, 'plan')


def defaults(plan):
    return plan.get('defaults') or {}


def case_clock(plan, case):
    return case.get('clock') or defaults(plan).get('clock')


def valid_clock(c):
    return isinstance(c, str) and CLOCK.match(c) is not None


def bad_clocks(plan):
    """Clocks that break ^[0-9]{14}([0-9]{1,6})?$ (defaults and cases), and a missing probeClock or
    one equal to the clock (every case also runs at its probe clock)."""
    out = []
    d = defaults(plan)
    for k in ('clock', 'probeClock'):
        if not valid_clock(d.get(k)):
            out.append(f'defaults.{k} {d.get(k)!r}: YYYYMMDDhhmmss, optionally with up to six fraction digits')
    if d.get('probeClock') is not None and d.get('probeClock') == d.get('clock'):
        out.append('defaults.probeClock: one fixed clock other than defaults.clock is required')
    for c in plan.get('cases') or []:
        if c.get('clock') is not None and not valid_clock(c['clock']):
            out.append(f"case {c.get('name')}: clock {c['clock']!r}")
    return out


def shim_clock(c):
    """CAGENSHIM_CLOCK: 14 digits as they are, a fraction padded to six digits (20 in all)."""
    c = str(c)
    return c if len(c) <= 14 else c.ljust(20, '0')


def probe_clock(plan, clock):
    """The clock a case's probe run uses: the default clock for a case at another clock, else probeClock."""
    d = defaults(plan)
    return d.get('clock') if clock != d.get('clock') else d.get('probeClock')


_CLOCK_TOKEN = re.compile(r'yyyy|MM|dd|HH|mm|ss|ffffff')


def clock_value(spec, clock):
    """A constantInputs value `clock:<fmt>` evaluated at a run's clock (tokens yyyy MM dd HH mm ss ffffff)."""
    if not valid_clock(clock):
        raise Stop(f'{spec}: no valid clock to evaluate it at ({clock!r})')
    c = shim_clock(clock).ljust(20, '0')
    parts = {'yyyy': c[0:4], 'MM': c[4:6], 'dd': c[6:8], 'HH': c[8:10], 'mm': c[10:12], 'ss': c[12:14], 'ffffff': c[14:20]}
    return _CLOCK_TOKEN.sub(lambda m: parts[m.group(0)], spec[len('clock:'):])


def is_clock_input(v):
    return isinstance(v, str) and v.startswith('clock:')


def constant_inputs(plan, clock):
    return [(f, clock_value(v, clock) if is_clock_input(v) else v) for f, v in (plan.get('constantInputs') or {}).items()]


def clock_inputs(plan, inputs, clock):
    """Recorded inputs ([field, value] pairs) with every clock-derived constant evaluated at `clock`
    (a base case's probe run)."""
    now = dict(constant_inputs(plan, clock))
    clocked = {f for f, v in (plan.get('constantInputs') or {}).items() if is_clock_input(v)}
    return [[f, now[f] if f in clocked else v] for f, v in inputs]


def is_group(spec):
    return isinstance(spec, dict) and isinstance(spec.get('item'), dict)


def plan_inputs(plan, case, fields=None, clock=None):
    """The COBOL inputs a plan case stands for, as ordered [field, value] pairs: constantInputs
    (a `clock:<fmt>` value evaluated at `clock`, default the case's clock), then inputMap in its
    order (a group: its count, then each item's fields), then extraInputs (which may override a
    field in place). A param that is absent or "" is not sent: the driver resets every input to
    spaces/zero. Items past the group's OCCURS cannot reach the driver and are left out; the count
    still says how many the request carried."""
    pairs = constant_inputs(plan, clock or case_clock(plan, case))
    params = case.get('params') or {}
    for param, spec in (plan.get('inputMap') or {}).items():
        v = params.get(param)
        if is_group(spec):
            if v is None:
                continue
            if not isinstance(v, list):
                raise Stop(f"case {case.get('name')}: param {param} feeds a group: it must be a list of objects")
            occurs = (fields or {}).get(next(iter(spec['item'].values()), None)) if fields else None
            pairs.append((spec['count'], str(len(v))))
            for n, item in enumerate(v, 1):
                if occurs and n > occurs:
                    break
                for key, field in spec['item'].items():
                    x = (item or {}).get(key)
                    if x is not None and x != '':
                        pairs.append((f'{field}({n})', x if isinstance(x, str) else _s(x)))
            continue
        if v is not None and v != '':
            pairs.append((spec, v if isinstance(v, str) else _s(v)))
    extra = case.get('extraInputs') or {}
    out, done = [], set()
    for f, v in pairs:
        if f in extra:
            if f not in done:
                out.append((f, str(extra[f])))
                done.add(f)
            continue
        out.append((f, v))
    for f, v in extra.items():
        if f not in done and all(f != x for x, _ in pairs):
            out.append((f, str(v)))
    return [[f, v] for f, v in out]


def mapped_fields(plan):
    """The plain COBOL fields the inputMap reads (a group: its count and item fields)."""
    out = set()
    for spec in (plan.get('inputMap') or {}).values():
        if is_group(spec):
            out.add(str(spec['count']))
            out.update(str(f) for f in spec['item'].values())
        else:
            out.add(str(spec))
    return out


def check_inputs(pairs, fields, where):
    for f, _ in pairs:
        base = re.sub(r'\([0-9]+\)\Z', '', f)
        if base not in fields['inputs']:
            raise Stop(f'{where}: input {f} is not in schema.yaml')


# ---------------------------------------------------------------- values

def _s(v):
    """A value as text, numbers the way JSON writes them (10.50 -> 10.5, 7.0 -> 7)."""
    if v is None:
        return ''
    if isinstance(v, bool):
        return 'true' if v else 'false'
    if isinstance(v, (int, float, Decimal)):
        d = Decimal(str(v)).normalize()
        return format(d, 'f') if d != d.to_integral_value() else str(int(d))
    return str(v)


def _num(v):
    """A number, or None (not a number). '' and blanks are 0, as a numeric COBOL field reads them."""
    if isinstance(v, bool):
        return int(v)
    if isinstance(v, (int, float, Decimal)):
        return Decimal(str(v))
    if isinstance(v, str):
        s = v.strip()
        if s == '':
            return Decimal(0)
        try:
            return Decimal(s)
        except InvalidOperation:
            return None
    return None


# ---------------------------------------------------------------- the legacy block

def is_list(spec):
    return isinstance(spec, dict) and 'count' in spec


def field_of(spec):
    return spec.split('|')[0] if isinstance(spec, str) and not spec.startswith(('$', 'param:')) else None


def key_of(outputs, token):
    return next((k for k, v in outputs.items() if v == token), None)


def _piped(v, ops):
    for op in ops:
        name, _, rest = op.partition(':')
        if name == 'number':
            if v is not None:
                v = to_number(v)
        elif name == 'default':
            if v is None:
                v = rest
        else:
            raise Stop(f'outputs: unknown pipe |{op}')
    return v


def to_number(v):
    if isinstance(v, (int, float, Decimal)):
        return v
    s = str(v).strip()
    if s == '':
        return 0
    try:
        d = Decimal(s)
    except InvalidOperation:
        return v
    return int(d) if d == d.to_integral_value() and '.' not in s else d


def outputs_map(result):
    out = {}
    for entry in result.get('outputs') or []:
        occ = entry.get('occurrence')
        name = entry.get('field') or '?'
        out[f'{name}({int(occ):03d})' if occ not in (None, '') and str(occ).isdigit() else name] = entry.get('value', '')
    return out


def failure_of(plan):
    """The technical-failure spec: CA Gen GLOBDATA, each key the plan's technicalFailure sets replacing it;
    `fields` merged (plan entries add or override, default entries stay).
    `extraFlags` {field: [ok values]}: more fields whose value outside its list marks the run failed."""
    tf = plan.get('technicalFailure') or {}
    return {**CAGEN_FAILURE, **tf, 'fields': {**CAGEN_FAILURE['fields'], **(tf.get('fields') or {})}}


def failed(actual, plan):
    if not actual:
        return False
    tf = failure_of(plan)
    flag = actual.get(tf['flag'])
    bad = flag is not None and str(flag).strip() not in tf['ok']
    for field, ok in (tf.get('extraFlags') or {}).items():
        v = actual.get(field)
        bad = bad or (v is not None and str(v).strip() not in ok)
    return bad


def legacy_of(actual, plan, inputs, run_id, verify=None):
    """The legacy block of one run, read through plan.outputs; `actual` is None for an aborted run.
    `verify` (check id -> raw CLP rows) is appended as `verify`, `technicalFailure` when the run
    set the failure flag or an extra flag (such a run writes no list: the program left before
    building it)."""
    outputs = plan['outputs']
    imap = {k: v for k, v in (plan.get('inputMap') or {}).items() if not is_group(v)}
    inmap = {f: v for f, v in inputs}
    bad = failed(actual, plan)
    out = {}
    for key, spec in outputs.items():
        if is_list(spec):
            if not actual or bad:
                continue
            count = to_number(actual.get(spec['count'], '0'))
            count = int(count) if isinstance(count, (int, Decimal)) else 0
            out[key] = [[actual.get(f'{field}({i:03d})') for field in spec['columns'].values()] for i in range(1, count + 1)]
            continue
        if spec == '$inputs':
            out[key] = {f: v for f, v in inputs}
            continue
        if spec == '$runId':
            out[key] = run_id if actual else None
            continue
        src, *ops = spec.split('|')
        if src.startswith('param:'):
            out[key] = _piped(inmap.get(imap.get(src[6:])), ops)
            continue
        if not actual:
            continue
        out[key] = _piped(actual.get(src), ops)
    if actual and verify:
        out['verify'] = verify
    if bad:
        tf = failure_of(plan)
        out['technicalFailure'] = {k: actual.get(f) for k, f in tf['fields'].items()}
    return out


def same_outcome(a, b, plan):
    """Same outcome: every legacy key but the run id and the inputs (verify rows and technicalFailure included)."""
    skip = {key_of(plan['outputs'], '$runId'), key_of(plan['outputs'], '$inputs')}
    return canonical({k: v for k, v in a.items() if k not in skip}) == canonical({k: v for k, v in b.items() if k not in skip})


# ---------------------------------------------------------------- table checks

def checks_of(plan, case):
    names = case.get('checks')
    if names is None:
        names = defaults(plan).get('checks') or []
    tables = plan.get('tables') or {}
    for n in names:
        if n not in tables:
            raise Stop(f"case {case.get('name')}: check {n} is not in the plan's tables")
    seen = {}
    for n in names:
        t = tables[n]['table'].upper()
        if t in seen:
            raise Stop(f"case {case.get('name')}: checks {seen[t]} and {n} both read {t}: one check per table and case")
        seen[t] = n
    return list(names)


def compare_of(chk):
    return chk.get('compare') or ('ordered' if chk.get('orderBy') else 'set')


def check_sql(chk, typed=False, tables=None):
    """The SELECT of a table check: raw (the CLP renders it) or typed (one JSON object per row)."""
    cols = chk['columns']
    if typed:
        types = (tables or {}).get(chk['table'].upper(), {}).get('columns', {})
        width = 64 + sum(len(c) + 8 + _width(types.get(c.upper(), '')) for c in cols)
        sel = 'JSON_OBJECT(' + ', '.join(f"KEY '{c}' VALUE {c}" for c in cols) + \
              f' NULL ON NULL RETURNING VARCHAR({min(max(width, 256), 32000)}) FORMAT JSON)'
    else:
        sel = ', '.join(cols)
    sql = f"SELECT {sel} FROM {chk['table']}"
    if chk.get('where'):
        sql += f" WHERE {chk['where']}"
    if chk.get('orderBy'):
        sql += ' ORDER BY ' + ', '.join(chk['orderBy'])
    return sql


def checks_changed(plan, case, names):
    """A packaged case's table checks whose recorded SQL is not the plan's today: [check name]. The recorded
    SQL is expected.tables[].query (decidedAnswer.recorded for a decided case); a case recorded without
    queries (no binding) compares the check names of legacy.verify. Only a golden case has checks to compare."""
    if case.get('status') != 'golden':
        return []
    exp = (case.get('decidedAnswer') or {}).get('recorded') or case.get('expected') or {}
    was = {str(t.get('name')).upper(): t.get('query') for t in exp.get('tables') or []}
    if not was:
        return [] if sorted((case.get('legacy') or {}).get('verify') or {}) == sorted(names) else list(names)
    now = {plan['tables'][n]['table'].upper(): (n, check_sql(plan['tables'][n])) for n in names}
    return sorted({*(now[t][0] for t in now if was.get(t) != now[t][1]), *(t for t in was if t not in now)})


def _width(t):
    m = re.search(r'\(([0-9]+)', t)
    if t.startswith(('DATE',)):
        return 12
    if t.startswith(('TIMESTAMP',)):
        return 28
    if t.startswith(('SMALLINT', 'INTEGER', 'INT', 'BIGINT')):
        return 22
    return (int(m.group(1)) + 4) * 2 if m else 40


def verify_queries(plan, case, tables):
    out = {}
    for n in checks_of(plan, case):
        chk = plan['tables'][n]
        out[n] = check_sql(chk)
        out[f'{n}#typed'] = check_sql(chk, typed=True, tables=tables)
    return out


# Db2's JSON_OBJECT writes a DECIMAL with its leading zeros ("AMT":-000000012.50), which JSON does
# not allow: outside a string a number's leading zeros are dropped.
_DB2_NUM = re.compile(r'"(?:[^"\\]|\\.)*"|(?<![\w.])(-?)0+(?=[0-9])')


def db2_json_row(line):
    return json.loads(_DB2_NUM.sub(lambda m: m.group(0) if m.group(0).startswith('"') else m.group(1), line),
                      parse_float=Decimal)


def typed_rows(lines, chk, where):
    """Rows of a typed check: each CLP line one JSON object, read in the check's column order."""
    rows = []
    for line in lines:
        try:
            obj = db2_json_row(line)
        except ValueError:
            raise Stop(f'{where}: a typed row is not JSON (truncated by the CLP?): {line[:120]}') from None
        rows.append([obj.get(c) for c in chk['columns']])
    return rows


def table_types(plan, tables):
    out = {}
    for n, chk in (plan.get('tables') or {}).items():
        cols = tables.get(chk['table'].upper(), {}).get('columns', {})
        out[n] = {'table': chk['table'], 'columns': {c: cols.get(c.upper(), 'unknown').lower() for c in chk['columns']},
                  'orderBy': chk.get('orderBy') or [], 'compare': compare_of(chk)}
    return out


def table_errors(plan, tables):
    errs = []
    for n, chk in (plan.get('tables') or {}).items():
        t = str(chk.get('table', '')).upper()
        if t not in tables:
            errs.append(f'tables.{n}: table {t} is not in unit/schema.sql')
            continue
        cols = tables[t]['columns']
        for c in chk.get('columns') or []:
            if c.upper() not in cols:
                errs.append(f'tables.{n}: column {c} is not a column of {t}')
        for c in chk.get('orderBy') or []:
            if c.upper() not in cols:
                errs.append(f'tables.{n}: orderBy {c} is not a column of {t}')
        if not chk.get('columns'):
            errs.append(f'tables.{n}: columns are required')
        if chk.get('compare') not in (None, 'ordered', 'set'):
            errs.append(f'tables.{n}: compare is ordered or set')
        if ';' in str(chk.get('where') or ''):
            errs.append(f'tables.{n}: where has no `;`')
    return errs


# ---------------------------------------------------------------- the API binding (REST)
# Declarative, nothing about a unit in code. `api` is one endpoint
#   { method, pathTemplate, path{}, query{}, body?, principal?, enumMaps, response, technicalFailure }
# or { operations: [{ name, when{param: value}, method, pathTemplate, ... }], enumMaps, technicalFailure? }:
# a case's operation is the first whose `when` params all equal the case's.
# response: { status, body } | { status, statusMap{scalar, map}, body } |
#           { outcome: <legacy key>, map{<right-trimmed value>: answer}, otherwise? };
# answer: { status, body } | { status, empty: true }.
# technicalFailure (operation, else api): { status, body, source, causes?[{ when{<tf field>: value}, status, body, source }] };
# the first cause whose fields all equal the recorded ones (right-trimmed) answers, else the answer itself.
# Expressions: param:<p> item:<k> path:<k> scalar:<legacy key> list:<legacy list> full:<legacy list>
#   const:<json> col:<column>; templates { "$list": <l>, "$item": {...} }, { "$param": <group>, "$item": {...} }.
# Pipes, left to right: |enum (enumMaps[<param>]; a key matches with or without its trailing blanks)
#   |default:<v> |trim |number |date (YYYYMMDD -> YYYY-MM-DD, blank -> absent) |blankAbsent.
# A key whose value is absent is left out.
_ABSENT = object()
HTTP_METHODS = ('GET', 'POST', 'PUT', 'PATCH', 'DELETE')


def _pipe(v, ops, ctx, src):
    for op in ops:
        name, _, arg = op.partition(':')
        if name == 'enum':
            m = ((ctx.get('api') or {}).get('enumMaps') or {}).get(src) or {}
            key = v if isinstance(v, str) else _s(v)
            if v is not _ABSENT and key in m:
                v = m[key]
            elif isinstance(v, str) and v == v.rstrip():
                k = next((k for k in m if k.rstrip() == v), None)
                if k is not None:
                    v = m[k]
        elif name == 'default':
            if v is _ABSENT:
                v = arg
        elif name == 'trim':
            if isinstance(v, str):
                v = v.rstrip()
        elif name == 'number':
            if v is not _ABSENT and v is not None:
                v = to_number(v)
        elif name == 'date':
            if isinstance(v, str):
                s = v.strip()
                v = f'{s[:4]}-{s[4:6]}-{s[6:8]}' if re.fullmatch(r'[0-9]{8}', s) else (s or _ABSENT)
        elif name == 'blankAbsent':
            if isinstance(v, str) and v.strip() == '':
                v = _ABSENT
        else:
            raise Stop(f'binding: unknown pipe |{op}')
    return v


def _columns(ctx, name):
    spec = (ctx.get('outputs') or {}).get(name)
    if not is_list(spec):
        raise Stop(f'binding: {name} is no list of plan.outputs')
    return list(spec['columns'].keys())


def _row(cols, r):
    return {c: (r[j] if j < len(r) else _ABSENT) for j, c in enumerate(cols)}


def evaluate(expr, ctx):
    if isinstance(expr, list):
        return [evaluate(x, ctx) for x in expr]
    if isinstance(expr, dict):
        if expr.get('$list'):
            cols = _columns(ctx, expr['$list'])
            return [evaluate(expr.get('$item') or {}, {**ctx, 'row': _row(cols, r)})
                    for r in (ctx.get('legacy') or {}).get(expr['$list']) or []]
        if expr.get('$param'):
            items = (ctx.get('params') or {}).get(expr['$param'])
            if not isinstance(items, list):
                return _ABSENT
            return [evaluate(expr.get('$item') or {}, {**ctx, 'item': it or {}}) for it in items]
        out = {}
        for k, x in expr.items():
            x = evaluate(x, ctx)
            if x is not _ABSENT:
                out[k] = x
        return out
    if not isinstance(expr, str):
        return expr
    head, *ops = expr.split('|')
    kind, sep, name = head.partition(':')
    if not sep:
        raise Stop(f'binding: expression without a source: {expr}')
    if kind == 'param':
        v = (ctx.get('params') or {}).get(name, _ABSENT)
    elif kind == 'item':
        v = (ctx.get('item') or {}).get(name, _ABSENT)
    elif kind == 'path':
        v = (ctx.get('path') or {}).get(name, _ABSENT)
    elif kind == 'scalar':
        v = (ctx.get('legacy') or {}).get(name, _ABSENT)
    elif kind == 'col':
        v = (ctx.get('row') or {}).get(name, _ABSENT)
    elif kind == 'list':
        cols = _columns(ctx, name)
        v = [{c: (x.rstrip() if isinstance(x, str) else x) for c, x in _row(cols, r).items() if x is not _ABSENT}
             for r in (ctx.get('legacy') or {}).get(name) or []]
    elif kind == 'full':
        occurs = (ctx.get('occurs') or {}).get(name)
        v = isinstance(occurs, int) and len((ctx.get('legacy') or {}).get(name) or []) >= occurs
    elif kind == 'const':
        v = json.loads(name, parse_float=Decimal)
    else:
        raise Stop(f'binding: unknown source {kind}: in {expr}')
    if v is None and kind in ('param', 'item'):
        v = _ABSENT
    return _pipe(v, ops, ctx, name)


def operations(api):
    if not api:
        return []
    return api['operations'] if api.get('operations') else [{**api, 'name': api.get('name', 'default')}]


def operation_for(api, case):
    """The API operation a case stands for: the first whose `when` params all match, or None."""
    params = case.get('params') or {}
    for op in operations(api):
        if all(params.get(k, _ABSENT) == v for k, v in (op.get('when') or {}).items()):
            return op
    return None


def unrepresentable(api, case):
    """Why no request can mean this case (no operation matches, a path placeholder would be blank), or None."""
    if not api:
        return None
    op = operation_for(api, case)
    if op is None:
        return 'no API operation matches its params (the `when` of every operation)'
    vals = evaluate(op.get('path') or {}, {'api': api, 'params': case.get('params') or {}})
    for k in re.findall(r'\{(\w+)\}', str(op.get('pathTemplate') or '')):
        v = vals.get(k, _ABSENT)
        if v is _ABSENT or (isinstance(v, str) and v.strip() == ''):
            return f'path placeholder {{{k}}} would be blank'
    return None


def request_for(api, case):
    """(request, problem). problem is why no request can mean this case, or None. A POST or PUT
    always carries its body (an operation without one sends {})."""
    problem = unrepresentable(api, case)
    if problem:
        return None, problem
    op = operation_for(api, case)
    ctx = {'api': api, 'params': case.get('params') or {}}
    path_vals = evaluate(op.get('path') or {}, ctx)
    path = op['pathTemplate']
    for k, v in path_vals.items():
        path = path.replace(f'{{{k}}}', _quote(_s(v)), 1)
    query = evaluate(op.get('query') or {}, ctx)
    qs = '&'.join(f'{k}={_quote(_s(v))}' for k, v in query.items())
    method = op.get('method', 'GET')
    req = {'method': method, 'path': path, **path_vals, 'query': query}
    if op.get('principal') is not None:
        who = evaluate(op['principal'], ctx)
        if who is not _ABSENT:
            req['principal'] = _s(who)
    req['url'] = f'{path}?{qs}' if qs else path
    if 'body' in op or str(method).upper() in ('POST', 'PUT'):
        req['body'] = evaluate(op.get('body') or {}, {**ctx, 'path': path_vals})
    return req, None


def _quote(s):
    from urllib.parse import quote
    return quote(s, safe="-_.!~*'()")


def failure_answer(api, op, legacy):
    """The technical-failure answer for a recorded failure: the first cause whose `when` fields all
    equal legacy.technicalFailure's (right-trimmed), else the answer itself; the operation's replaces the api's."""
    tf = op.get('technicalFailure') or (api or {}).get('technicalFailure')
    if not tf:
        return None
    got = legacy.get('technicalFailure') or {}
    for cause in tf.get('causes') or []:
        if all(_s(got.get(k)).strip() == _s(v).strip() for k, v in (cause.get('when') or {}).items()):
            return cause
    return tf


def failure_answers(api):
    """Every technical-failure answer of a binding, with where it is (each needs its `source`)."""
    out = []
    multi = bool((api or {}).get('operations'))
    for op in operations(api):
        tf = op.get('technicalFailure')
        if not tf:
            continue
        where = f"operation {op.get('name')}" if multi else 'api'
        out.append((f'{where} technicalFailure', tf))
        out += [(f'{where} technicalFailure.causes[{i}]', c) for i, c in enumerate(tf.get('causes') or [])]
    if multi and api.get('technicalFailure'):
        tf = api['technicalFailure']
        out.append(('api technicalFailure', tf))
        out += [(f'api technicalFailure.causes[{i}]', c) for i, c in enumerate(tf.get('causes') or [])]
    return out


def _answer(a, ctx):
    if a.get('empty'):
        return {'status': a.get('status', 200), 'body': None, 'empty': True}
    return {'status': a.get('status', 200), 'body': evaluate(a.get('body') or {}, ctx)}


def expected_for(api, case, legacy, outputs=None, occurs=None):
    """The expected answer for a recorded outcome (expected.tables are added by build.py)."""
    op = operation_for(api, case)
    if op is None:
        raise Stop(f"binding: case {case.get('name')} matches no API operation")
    ctx = {'api': api, 'params': case.get('params') or {}, 'legacy': legacy, 'outputs': outputs or {},
           'occurs': occurs or {}}
    ctx['path'] = evaluate(op.get('path') or {}, ctx)
    if legacy.get('technicalFailure'):
        tf = failure_answer(api, op, legacy)
        if tf is None:
            raise Stop(f"binding: operation {op.get('name')} has no technicalFailure response")
        return _answer(tf, ctx)
    r = op.get('response') or {}
    if 'outcome' in r:
        v = _s(legacy.get(r['outcome'])).strip()
        a = (r.get('map') or {}).get(v)
        if a is None:
            a = r.get('otherwise')
        if a is None:
            raise Stop(f"case {case.get('name')}: outcome {r['outcome']}={v!r} has no entry in operation "
                       f"{op.get('name')}'s response map, and no `otherwise`")
        return _answer(a, ctx)
    status = r.get('status', 200)
    if r.get('statusMap'):
        v = _s(legacy.get(r['statusMap'].get('scalar'))).strip()
        if v in (r['statusMap'].get('map') or {}):
            status = r['statusMap']['map'][v]
    return _answer({**r, 'status': status}, ctx)


def unmapped(api, case, param):
    """Whether a param's value has no entry in its enum map (the `unmapped:<p>` predicate)."""
    m = ((api or {}).get('enumMaps') or {}).get(param)
    v = (case.get('params') or {}).get(param, _ABSENT)
    return bool(m) and v is not _ABSENT and v is not None and (v if isinstance(v, str) else _s(v)) not in m


def published(v):
    """The plan's api without its comment keys (`_...`): the package's `binding`."""
    if isinstance(v, dict):
        return {k: published(x) for k, x in v.items() if not str(k).startswith('_')}
    if isinstance(v, list):
        return [published(x) for x in v]
    return v


def padded_variant(api, plan, case, types):
    """Why a case is an unspellable enum variant, or None: a path value through |enum that only the
    COBOL field's padding with blanks or its cut to the field width maps (no request can send the
    difference: the case is the mapped case again)."""
    if not api:
        return None
    op = operation_for(api, case)
    params = case.get('params') or {}
    for ph, expr in ((op.get('path') or {}).items() if op is not None else []):
        m = re.match(r'param:([^|]+)((?:\|[^|]+)*)$', str(expr))
        if not m or '|enum' not in m.group(2):
            continue
        param, raw = m.group(1), params.get(m.group(1))
        emap = (api.get('enumMaps') or {}).get(param) or {}
        if not isinstance(raw, str) or raw in emap or (raw == raw.rstrip() and any(k.rstrip() == raw for k in emap)):
            continue
        field = str((plan.get('inputMap') or {}).get(param))
        width = field_width(types, field)
        seen = (raw[:width] if width else raw).rstrip()
        key = next((k for k in emap if k.rstrip() == seen), None)
        if key is not None:
            how = f'cuts {raw!r} to its {width} characters' if width and len(raw) > width else f'pads {raw!r} with blanks'
            return (f"the COBOL field {field}{f' X({width})' if width else ''} {how}: for the COBOL it is "
                    f"{key.rstrip()!r}, which the API spells {emap[key]!r} (path {{{ph}}}); no request can send the difference")
    return None


# ---------------------------------------------------------------- naming rules
_BANNED_SUFFIX = re.compile(r'(Echo|Echoed|Out|Output|Export|Exp|Ret|Returned)$')
_CAMEL = re.compile(r'^[a-z][A-Za-z0-9]*$')


def _base(field):
    return re.sub(r'-[0-9]+[A-Z]*\Z', '', str(field))


def field_noun(field):
    words = [w for w in _base(field).split('-') if len(w) > 1]
    return (words[0].lower() + ''.join(w.capitalize() for w in words[1:])) if words else ''


def _param_of(expr):
    m = re.match(r'param:([^|]+)', expr) if isinstance(expr, str) else None
    return m.group(1) if m else None


def _answers(op):
    """Every answer an operation can give: its response (or each entry of an outcome map and its
    `otherwise`), and its technical-failure answer."""
    r = op.get('response') or {}
    out = list((r.get('map') or {}).values()) + ([r['otherwise']] if isinstance(r.get('otherwise'), dict) else [])
    if 'outcome' not in r:
        out.append(r)
    if isinstance(op.get('technicalFailure'), dict):
        out.append(op['technicalFailure'])
    return [x for x in out if isinstance(x, dict)]


def naming_errors(plan):
    errs = []
    out = plan.get('outputs') or {}
    imap = plan.get('inputMap') or {}
    keys = list(out)
    if keys[:2] != ['inputs', 'runId'] or out.get('inputs') != '$inputs' or out.get('runId') != '$runId':
        errs.append('outputs must start with "inputs": "$inputs", "runId": "$runId", in this order')
    by_base = {_base(f): p for p, f in imap.items() if isinstance(f, str)}
    echoes, scalars, lists = [], [], []
    for k, spec in out.items():
        if k in ('inputs', 'runId'):
            continue
        if k in RESERVED_KEYS:
            errs.append(f'outputs key "{k}" is reserved for the package')
            continue
        if not _CAMEL.match(k):
            errs.append(f'outputs key "{k}" is not lowerCamel')
        if is_list(spec):
            lists.append(k)
            continue
        param = _param_of(spec) or by_base.get(_base(field_of(spec)))
        if param is not None:
            echoes.append(k)
            if k != param:
                errs.append(f'outputs key "{k}" echoes param "{param}": name it "{param}"')
        else:
            scalars.append(k)
            if _BANNED_SUFFIX.search(k):
                errs.append(f'outputs key "{k}": no Echo/Out/Export-style suffix')
            want = field_noun(field_of(spec))
            if want and k != want:
                errs.append(f'outputs key "{k}" reads {field_of(spec)}: name it "{want}"')
    order = [p for p in imap if p in echoes]
    if keys[2:] != order + scalars + lists:
        errs.append(f'outputs order must be inputs, runId, the echoes in inputMap order, the other scalars, the lists: '
                    f'{["inputs", "runId"] + order + scalars + lists}')
    for p, spec in imap.items():
        if is_group(spec):
            for ik in spec['item']:
                if not _CAMEL.match(ik):
                    errs.append(f'inputMap {p}: item key "{ik}" is not lowerCamel')
        elif isinstance(spec, dict):
            errs.append(f'inputMap {p}: a group is {{ "count": <field>, "item": {{ <key>: <field> }} }}')
    api = plan.get('api')
    multi = bool((api or {}).get('operations'))
    for op in operations(api):
        where = f"operation {op.get('name')}: " if multi else ''
        for q, expr in (op.get('query') or {}).items():
            p = _param_of(expr)
            if p is not None and p != q:
                errs.append(f'{where}param "{p}" is sent as query "{q}": name it "{q}"')
        for ph, expr in (op.get('path') or {}).items():
            p = _param_of(expr)
            if p is not None and p != ph and '|enum' not in str(expr):
                errs.append(f'{where}param "{p}" is sent as path {{{ph}}}: name it "{ph}"')
        p = _param_of(op.get('principal'))
        want = field_noun(imap.get(p)) if p is not None and isinstance(imap.get(p), str) else ''
        if want and p != want:
            errs.append(f'{where}param "{p}" is sent as the principal and reads {imap[p]}: name it "{want}"')
        body = op.get('body')
        for bk, expr in (body.items() if isinstance(body, dict) else []):
            if isinstance(expr, dict) and '$param' in expr:
                if bk != expr['$param']:
                    errs.append(f'{where}group param "{expr["$param"]}" is sent as body array "{bk}": name it "{bk}"')
                continue
            p = _param_of(expr)
            if p is not None and p != bk:
                errs.append(f'{where}param "{p}" is sent as body key "{bk}": name it "{bk}"')
        for answer in _answers(op):
            for bk, tpl in (answer.get('body') or {}).items() if isinstance(answer.get('body'), dict) else []:
                if isinstance(tpl, dict) and '$list' in tpl:
                    if bk != tpl['$list']:
                        errs.append(f'{where}list "{tpl["$list"]}" feeds body array "{bk}": name it "{bk}"')
                    cols = (out.get(tpl['$list']) or {}).get('columns') or {}
                    for ik, iexpr in (tpl.get('$item') or {}).items():
                        m = re.match(r'col:([^|]+)', str(iexpr))
                        if m and m.group(1) in cols and m.group(1) != ik:
                            errs.append(f'{where}column "{m.group(1)}" feeds item key "{ik}": name it "{ik}"')
    return errs


def legacy_contract(schema):
    """A suite's legacySchema without `tables` (the plan keeps the checks in its own `tables`)."""
    return {k: v for k, v in (schema or {}).items() if k != 'tables'}


def _body_shape(body):
    if not isinstance(body, dict):
        return None
    return {k: (list(v[0].keys()) if isinstance(v, list) and v and isinstance(v[0], dict) else None) for k, v in body.items()}


def reference_errors(plan, ref):
    """What the plan must keep from the base suite: its legacySchema verbatim, the constant inputs every
    golden case was called with (a clock-derived constant aside), the expected body layout of a single
    endpoint, the technicalFailure keys."""
    errs = []
    out = plan.get('outputs') or {}
    rs = legacy_contract(ref.get('legacySchema'))
    if dumps(rs) != dumps(out):
        errs.append(f"outputs differ from the base suite's legacySchema: copy it verbatim\n    base: {dumps(rs)}\n"
                    f"    plan: {dumps(out)}")
    ik = key_of(rs, '$inputs')
    golden = [c for c in ref.get('cases') or [] if c.get('status') == 'golden']
    clocked = {f for f, v in (plan.get('constantInputs') or {}).items() if is_clock_input(v)}
    if ik and golden:
        blocks = [(c.get('legacy') or {}).get(ik) or {} for c in golden]
        mapped = mapped_fields(plan)
        const = {f: v for f, v in blocks[0].items() if re.sub(r'\([0-9]+\)\Z', '', f) not in mapped
                 and f not in clocked and all(b.get(f, _ABSENT) == v for b in blocks)}
        mine = {f: v for f, v in (plan.get('constantInputs') or {}).items() if f not in clocked}
        if dumps(const) != dumps(mine):
            errs.append(f'constantInputs differ from the inputs every base golden case was called with: {dumps(const)} '
                        f'(plan: {dumps(mine)})')
    api = plan.get('api')
    if api and not api.get('operations'):
        resp = api.get('response') or {}
        ok = next((c.get('expected') for c in golden if 'technicalFailure' not in (c.get('legacy') or {})
                   and (c.get('expected') or {}).get('status') == resp.get('status')), None)
        tf = next((c.get('expected') for c in golden if 'technicalFailure' in (c.get('legacy') or {}) and c.get('expected')), None)
        tpl = resp.get('body') or {}
        mine = {k: (list(v['$item'].keys()) if isinstance(v, dict) and '$item' in v else None) for k, v in tpl.items()}
        theirs = _body_shape((ok or {}).get('body'))
        if theirs is not None and (list(theirs) != list(mine) or any(theirs[k] is not None and theirs[k] != mine.get(k)
                                                                     for k in theirs)):
            errs.append(f'api.response.body keys differ from the base expected body: {dumps(theirs)} (plan: {dumps(mine)})')
        if isinstance((tf or {}).get('body'), dict):
            want = list(tf['body'].keys())
            have = list(((api.get('technicalFailure') or {}).get('body') or {}).keys())
            if want != have:
                errs.append(f'api.technicalFailure.body keys differ from the base suite: {want} (plan: {have})')
    tfl = next((c['legacy']['technicalFailure'] for c in ref.get('cases') or []
                if isinstance((c.get('legacy') or {}).get('technicalFailure'), dict)), None)
    if tfl is not None:
        have = list(failure_of(plan)['fields'].keys())
        if list(tfl.keys()) != have:
            errs.append(f'legacy.technicalFailure keys differ from the base suite: {list(tfl.keys())} (plan: {have})')
    return errs


def contract_errors(p, plan, opt=None):
    errs = naming_errors(plan)
    if plan.get('tables'):
        errs += table_errors(plan, ddl(p))
    if not (opt or {}).get('new-contract'):
        base = load_base(p)
        if base is not None:
            errs += reference_errors(plan, base)
    return errs


# ---------------------------------------------------------------- decisions
# plan.decisions { <id>: { when, text, source?, kind?: java|stack, clockDependent?, compare?[], answer? } }.
# when: predicates joined by `&`, every part fires:
#   clockSensitive | technicalFailure | absent:<p> | zero:<p> | absentOrZero:<p> | blank:<p> | unmapped:<p>
#   param:<p>=<v1>|<v2>   the param's trimmed value is one of them (absent never matches)
#   notDate:<p>           eight digits that are no calendar date     negative:<p>   a number below 0
#   above:<p>=<n>         a number above n                          wider:<p>=<n>  more than n characters, trimmed
#   legacy:<key>=<v>      the legacy key's trimmed value            failure:<f>=<v> a field of legacy.technicalFailure
#   operation:<name>      the API operation                         status:<http>  the recorded expected status
#   case:<name>           that case
# kind java -> anticipatedJavaDivergence, kind stack -> stackDivergence; compare entries join a 2xx body's compare.
# answer (kind java): { status?, body?, set?[{path, value}], tables?: recorded|notCompared } decides the case's
# expected answer on top of the recorded one; decidedAnswer keeps the recorded one.
SOURCE = re.compile(r'^(OQ|PQ)-[0-9]+$|^design\.md#.+$')
PREDICATES = ('clockSensitive', 'technicalFailure', 'absent', 'zero', 'absentOrZero', 'blank', 'unmapped', 'param',
              'legacy', 'failure', 'operation', 'status', 'case', 'notDate', 'negative', 'above', 'wider')
DECISION_KINDS = ('java', 'stack')
ANSWER_TABLES = ('recorded', 'notCompared')
COMPARE_MODES = ('set', 'ignore')


def compare_errors(cmp, where):
    out = []
    for x in cmp or []:
        if not x.get('path') or x.get('mode') not in COMPARE_MODES:
            out.append(f"{where}: compare needs a path and a mode in {'/'.join(COMPARE_MODES)}")
        elif x.get('mode') == 'ignore' and not x.get('reason'):
            out.append(f"{where}: compare {x.get('path')} ignore needs a reason (the decision it rests on)")
    return out


def calendar_date(s):
    if not re.fullmatch(r'[0-9]{8}', s):
        return None
    y, m, d = int(s[:4]), int(s[4:6]), int(s[6:])
    days = [31, 29 if (y % 4 == 0 and y % 100 != 0) or y % 400 == 0 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    return y >= 1 and 1 <= m <= 12 and 1 <= d <= days[m - 1]


def _scalar(v):
    return v is not _ABSENT and v is not None and not isinstance(v, (list, dict))


def fires(when, case, legacy, clock_sensitive, exp=None, api=None):
    """Whether a decision's `when` fires on a case (its params), its legacy block and expected answer."""
    if '&' in when:
        return all(fires(w, case, legacy, clock_sensitive, exp, api) for w in when.split('&'))
    kind, _, arg = when.partition(':')
    params = case.get('params') or {}
    v = params.get(arg, _ABSENT)
    if v is None:
        v = _ABSENT
    key, _, want = arg.partition('=')
    pv = params.get(key, _ABSENT)
    if kind == 'legacy':
        return _s(legacy.get(key)).strip() == want
    if kind == 'failure':
        tf = legacy.get('technicalFailure')
        return bool(tf) and _s(tf.get(key)).strip() == want
    if kind == 'param':
        return _scalar(pv) and _s(pv).strip() in want.split('|')
    if kind == 'notDate':
        return _scalar(v) and calendar_date(_s(v).strip()) is False
    if kind in ('negative', 'above', 'wider'):
        if not _scalar(pv):
            return False
        if kind == 'wider':
            return len(_s(pv).strip()) > int(want)
        x = _num(pv)
        return x is not None and (x < 0 if kind == 'negative' else x > Decimal(want))
    if kind == 'case':
        return case.get('name') == arg
    if kind == 'operation':
        op = operation_for(api, case) if api else None
        return op is not None and op.get('name') == arg
    if kind == 'status':
        return exp is not None and _s(exp.get('status')) == arg
    if kind == 'clockSensitive':
        return bool(clock_sensitive)
    if kind == 'technicalFailure':
        return bool(legacy.get('technicalFailure'))
    if kind == 'absent':
        return v is _ABSENT
    if kind == 'zero':
        return v is not _ABSENT and _num(v) == 0
    if kind == 'absentOrZero':
        return v is _ABSENT or _num(v) == 0
    if kind == 'blank':
        return v is not _ABSENT and _s(v).strip() == ''
    if kind == 'unmapped':
        return bool(api) and unmapped(api, case, arg)
    raise Stop(f'decision: unknown predicate {when}')


def decision_errors(plan):
    """The plan's decisions and the binding's technical-failure answers, checked before any case."""
    errs = []
    if plan.get('divergenceRules'):
        errs.append('divergenceRules is the tc-gen name: the plan states them as `decisions` (PLAN.md)')
    for did, r in (plan.get('decisions') or {}).items():
        where = f'decision {did}'
        if not r.get('when') or not r.get('text'):
            errs.append(f'{where}: when and text are required')
            continue
        kind = r.get('kind') or 'java'
        if kind not in DECISION_KINDS:
            errs.append(f"{where}: kind {kind} not in {'/'.join(DECISION_KINDS)}")
        ans = r.get('answer')
        if (ans is not None or kind == 'java') and not SOURCE.match(str(r.get('source') or '')):
            errs.append(f"{where}: source {r.get('source')!r}: the decision it rests on, OQ-<n> / PQ-<n> or design.md#<anchor>")
        errs += compare_errors(r.get('compare'), where)
        if re.search(r'\bnot compared\b', str(r['text']), re.I) and not any(x.get('mode') == 'ignore' for x in r.get('compare') or []):
            errs.append(f'{where}: the text says "not compared" but the decision has no compare ignore: state the '
                        'comparison as `compare`, never as prose')
        if re.search(r'\b(expects?|expected)\s+(status\s+)?[1-5][0-9]{2}\b', str(r['text']), re.I):
            errs.append(f"{where}: the text states the package's expected status: that is the binding's or the answer's")
        for w in str(r['when']).split('&'):
            k, _, a = w.partition(':')
            if k not in PREDICATES:
                errs.append(f'{where}: unknown predicate {w}')
            elif k in ('above', 'wider') and not re.fullmatch(r'[^=]+=-?[0-9]+', a):
                errs.append(f'{where}: {w} needs <param>=<number>')
        if ans is None:
            continue
        if kind != 'java':
            errs.append(f'{where}: only a kind java decision has an answer')
            continue
        if not isinstance(ans, dict) or not any(k in ans for k in ('status', 'body', 'set', 'tables')):
            errs.append(f'{where}: answer is {{status?, body?, set?, tables?}} with at least one of them')
            continue
        unknown = sorted(set(ans) - {'status', 'body', 'set', 'tables'})
        if unknown:
            errs.append(f"{where}: answer keys {', '.join(unknown)} (allowed: status, body, set, tables)")
        st = ans.get('status')
        if st is not None and (not isinstance(st, int) or isinstance(st, bool) or not 200 <= st <= 599):
            errs.append(f'{where}: answer.status {st!r} is an HTTP status 200-599')
        if ans.get('tables') not in (None, *ANSWER_TABLES):
            errs.append(f"{where}: answer.tables {ans.get('tables')!r} not in {'/'.join(ANSWER_TABLES)}")
        for i, s in enumerate(ans.get('set') or []):
            if not isinstance(s, dict) or not s.get('path') or 'value' not in s:
                errs.append(f'{where}: answer.set[{i}] is {{path, value}}')
    for where, a in failure_answers(plan.get('api')):
        if not SOURCE.match(str(a.get('source') or '')):
            errs.append(f'binding: {where} needs a source: the decision that gives this answer (OQ-<n> / PQ-<n> / design.md#<anchor>)')
    return errs


def design_anchors(path):
    """The heading anchors of a Markdown file, lower case: GitHub slugs (a repeated one gets -1, -2, ...),
    plus explicit `{#id}` and `<a id|name="...">`."""
    path = Path(path)
    if not path.is_file():
        return set()
    out, seen, fence = set(), {}, False
    for line in read_text(path).splitlines():
        if line.lstrip().startswith(('```', '~~~')):
            fence = not fence
        if fence:
            continue
        out.update(x.lower() for x in re.findall(r'<a\s+(?:id|name)="([^"]+)"', line))
        m = re.match(r'^#{1,6}\s+(.*?)\s*#*\s*$', line)
        if not m:
            continue
        text = m.group(1)
        out.update(x.lower() for x in re.findall(r'\{#([^}\s]+)\}', text))
        text = re.sub(r'\{#[^}]*\}|<[^>]+>', '', text)
        slug = re.sub(r'[^\w\- ]', '', text.strip().lower()).replace(' ', '-')
        n = seen.get(slug, 0)
        seen[slug] = n + 1
        out.add(slug if n == 0 else f'{slug}-{n}')
    return out


def pending_reason(p, source, cache=None):
    """Why a decided answer's source is not a decision yet, or None: an OQ-<n> / PQ-<n> must be
    answered or settled in design/design-open-questions.md / tests/tests-open-questions.md, a
    design.md#<anchor> must be a heading anchor of design/design.md."""
    import questions
    cache = {} if cache is None else cache
    src = str(source or '')
    m = re.fullmatch(r'(OQ|PQ)-[0-9]+', src)
    if m:
        f = p.design / 'design-open-questions.md' if m.group(1) == 'OQ' else p.questions
        if f not in cache:
            cache[f] = {e['id']: e for e in questions.parse(f, m.group(1))}
        e = cache[f].get(src)
        if e is None:
            return f'{src} is not in {p.rel(f)}'
        return None if questions.decided([e]) else f'{src} is {e["status"]} in {p.rel(f)}, not answered or settled'
    if src.startswith('design.md#'):
        f = p.design / 'design.md'
        if f not in cache:
            cache[f] = design_anchors(f)
        anchor = src.split('#', 1)[1]
        return None if anchor.lower() in cache[f] else f'{p.rel(f)} has no heading anchor #{anchor}'
    return f'source {src!r} is no OQ-<n>, PQ-<n> or design.md#<anchor>'


def pending_decisions(p, plan):
    """{decision id: reason} of the plan's decisions with an answer whose source is not decided
    (pending_reason): their text reaches the case, their answer does not replace `expected`."""
    cache, out = {}, {}
    for did, r in (plan.get('decisions') or {}).items():
        if r.get('answer') is not None:
            why = pending_reason(p, r.get('source'), cache)
            if why:
                out[did] = why
    return out


_PATH_TOKEN = re.compile(r'([^.\[\]]+)|\[([0-9]+)\]')


def apply_set(expected, path, value):
    """Set one value of an expected answer. path: `body.<key>[n]...`, `status`, or
    `tables.<TABLE>[<row>].<COLUMN>` (a row value of expected.tables). Raises Stop when the path is absent."""
    toks = [(m.group(1), int(m.group(2)) if m.group(2) else None) for m in _PATH_TOKEN.finditer(path)]
    if not toks:
        raise Stop(f'answer.set path {path!r} is empty')
    if toks[0][0] == 'tables':
        if len(toks) != 4 or toks[1][0] is None or toks[2][1] is None or toks[3][0] is None:
            raise Stop(f'answer.set path {path!r}: a table value is tables.<TABLE>[<row>].<COLUMN>')
        t = next((x for x in expected.get('tables') or [] if x['name'].upper() == toks[1][0].upper()), None)
        if t is None:
            raise Stop(f'answer.set path {path!r}: the recorded answer has no table {toks[1][0]}')
        col = next((j for j, c in enumerate(t['columns']) if c.upper() == toks[3][0].upper()), None)
        row = toks[2][1]
        if col is None or row >= len(t['rows']):
            raise Stop(f"answer.set path {path!r}: {t['name']} has no row {row} / column {toks[3][0]}")
        t['rows'][row][col] = value
        return
    cur = expected
    for n, (k, i) in enumerate(toks):
        last = n == len(toks) - 1
        if k is not None:
            if not isinstance(cur, dict) or k not in cur:
                raise Stop(f'answer.set path {path!r}: the recorded answer has no {k}')
            if last:
                cur[k] = value
            else:
                cur = cur[k]
        else:
            if not isinstance(cur, list) or i >= len(cur):
                raise Stop(f'answer.set path {path!r}: the recorded answer has no element [{i}]')
            if last:
                cur[i] = value
            else:
                cur = cur[i]


def decide(answering, exp):
    """The decided answer of a case from its fired answering decisions [(id, decision)] and its recorded
    expected answer: (expected, decidedAnswer). Raises Stop on conflicting answers or a bad answer."""
    answers = {dumps(r['answer']) for _, r in answering}
    if len(answers) > 1:
        raise Stop(f"the decisions {', '.join(k for k, _ in answering)} decide different answers: make their "
                   'predicates exclusive (one decision per situation)')
    k, r = answering[0]
    ans = r['answer']
    has_rows = bool(exp.get('tables'))
    tables = ans.get('tables')
    if has_rows and tables not in ANSWER_TABLES:
        raise Stop(f'decision {k} decides the answer of a case with table checks: answer.tables recorded (the rows the '
                   'COBOL left stay expected) or notCompared (they are left out)')
    new = json.loads(dumps(exp), parse_float=Decimal)
    if 'status' in ans:
        new['status'] = ans['status']
        if 'body' not in ans and not (200 <= ans['status'] < 300) and ans['status'] != exp.get('status'):
            new['body'] = {}
            new.pop('empty', None)
    if 'body' in ans:
        new['body'] = ans['body']
        new.pop('empty', None)
        if ans['body'] is None:
            new['empty'] = True
    if has_rows and tables == 'notCompared':
        new.pop('tables', None)
    for s in ans.get('set') or []:
        apply_set(new, s['path'], s['value'])
    da = {'source': r['source'], 'rules': [x for x, _ in answering], 'status': new.get('status'),
          'recordedStatus': exp.get('status')}
    if ans.get('set'):
        da['set'] = ans['set']
    if has_rows:
        da['tables'] = tables
    da['recorded'] = exp
    return new, da


def design_mismatches(case, op):
    """For a basic case: where the binding's request (method, path) and the expected status differ from
    case.design (Request: first token method, second path; Expected outcome: first 3-digit number)."""
    d = case.get('design') or {}
    req, exp = case.get('request'), case.get('expected')
    out = []
    toks = [t.rstrip(',;') for t in str(d.get('request') or '').split()]
    if toks and toks[0].upper() in HTTP_METHODS:
        if not req:
            out.append(f'design requests {toks[0]} {toks[1] if len(toks) > 1 else ""}'.rstrip() + ', the package has no request')
        else:
            if req['method'].upper() != toks[0].upper():
                out.append(f"method: design {toks[0].upper()}, binding {req['method']}")
            if len(toks) > 1 and toks[1].startswith('/'):
                want = toks[1]
                tpl = (op or {}).get('pathTemplate') or ''
                rx = '^' + re.sub(r'\\\{\w+\\\}', '[^/]+', re.escape(want)) + '$'
                if want not in (req['path'], req['url'], tpl) and not re.match(rx, req['path']):
                    out.append(f"path: design {want}, binding {req['path']}")
    m = re.search(r'(?<![0-9])([1-5][0-9]{2})(?![0-9])', str(d.get('outcome') or ''))
    if m:
        if not exp:
            out.append(f'status: design {m.group(1)}, the package has no expected answer ({case.get("status")})')
        elif _s(exp.get('status')) != m.group(1):
            out.append(f"status: design {m.group(1)}, expected {exp.get('status')}")
    return out


# ---------------------------------------------------------------- suites

def base_suite_file(p):
    """The suite the new one is built from: previous/<E>/<E>-tests.json (after rotate), else the package."""
    prev = p.previous / p.suite.name
    return prev if prev.is_file() else p.suite


def load_base(p):
    f = base_suite_file(p)
    return read_json(f, 'base suite') if f.is_file() else None


# ---------------------------------------------------------------- fingerprints

def _tree_hash(d):
    out = {}
    d = Path(d)
    if d.is_dir():
        for f in sorted(x for x in d.rglob('*') if x.is_file()):
            out[f.relative_to(d).as_posix()] = sha256(f.read_bytes())
    return out


def _sh(cmd, cwd=None):
    try:
        r = subprocess.run(cmd, cwd=cwd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                           encoding='utf-8', errors='replace', timeout=60)
    except (OSError, subprocess.TimeoutExpired):
        return None
    return r.stdout.strip() if r.returncode == 0 else None


def parity_home(p):
    pt = tool(p.mu, 'parity-tester', required=False) or {}
    return Path(pt['home']) if pt.get('home') else None


def parity_commit(p):
    home = parity_home(p)
    if not home or not home.is_dir():
        return {'commit': None, 'dirty': None}
    commit = _sh(['git', 'rev-parse', 'HEAD'], home)
    dirty = _sh(['git', 'status', '--porcelain', '--', '.'], home)
    return {'commit': commit, 'dirty': None if dirty is None else dirty != ''}


def image_of(container):
    """The image id of a container, or None (no container name, no CLI, not running)."""
    if not container:
        return None
    return _sh([os.environ.get('RUN_COBOL_CONTAINER_CLI') or 'docker', 'inspect', str(container),
                '--format', '{{.Image}}'])


RUNNER_CONTAINER = 'parity-cobol-runner'   # the parity tester's docker-compose container_name


def runner_container(mu):
    """tools.yaml cobol-runner `container`, else the parity tester's RUNNER_CONTAINER."""
    return (tool(mu, 'cobol-runner', required=False) or {}).get('container') or RUNNER_CONTAINER


def fingerprint(p, fixture, shims, db, env):
    """What a recording rests on, per file, so a reviewer can tell WHICH member, shim or table
    definition changed. The clock is not here: it is the case's own. The runner image is the one of
    runner_container()."""
    home = parity_home(p)
    shim_root = home / 'config' / 'cobol-runner' / 'shims' if home else None
    return {
        'members': {f.name: sha256(f.read_bytes()) for f in sorted(p.sources.glob('*')) if f.is_file()},
        'driver': file_sha(p.driver),
        'fixture': {'name': fixture, 'sha256': file_sha(p.fixtures / fixture) if fixture else None},
        'ddl': {'path': p.rel(p.ddl), 'sha256': file_sha(p.ddl)},
        'shims': {s: sha256(dumps(_tree_hash(shim_root / s))) if shim_root else None for s in shims},
        'runnerImage': image_of(runner_container(p.mu)),
        'db2Image': image_of(db['container']),
        'database': f"{db['database']}/{db['schema']}",
        'env': env,
    }


def fingerprint_id(fp):
    return sha256(dumps(fp))[:12]


def check_key(plan, names, tables):
    """[[name, raw SQL, typed SQL]] of a case's table checks: the checks part of its run key."""
    return [[n, check_sql(plan['tables'][n]), check_sql(plan['tables'][n], typed=True, tables=tables)] for n in names]


def run_key(inputs, clock, fixture, shims, checks, fp_id):
    """checks: check_key() of the case (the check SQL, not only the names)."""
    return sha256(dumps([inputs, clock, fixture, shims, checks, fp_id]))[:16]


def suite_run_keys(plan, suite, tables):
    """{case name: run key} of a suite's golden cases, as build.py resolves them: the recorded inputs,
    clock, fixture, the plan's shims and check SQL (tables: ddl()), the recording's fingerprint."""
    ik = key_of((suite or {}).get('legacySchema') or {}, '$inputs')
    shims = defaults(plan).get('shims') or ['cagen']
    by = {c.get('name'): c for c in plan.get('cases') or []}
    out = {}
    for c in (suite or {}).get('cases') or []:
        fp = (c.get('recording') or {}).get('fingerprint')
        inputs = (c.get('legacy') or {}).get(ik) if ik else None
        if c.get('status') != 'golden' or not fp or not isinstance(inputs, dict):
            continue
        pc = by.get(c.get('name')) or {'name': c.get('name')}
        out[c['name']] = run_key([[f, v] for f, v in inputs.items()], c.get('clock'), c.get('fixture'), shims,
                                 check_key(plan, checks_of(plan, pc), tables), fp)
    return out


def generator(p):
    h = hashlib.sha256()
    files = sorted([*HERE.glob('*.py'), *(SKILL / 'templates').glob('*'), *(SKILL / 'schema').glob('*.json'),
                    SKILL / 'SKILL.md', SKILL / 'PLAN.md', SKILL / 'PACKAGE.md'], key=lambda f: f.name)
    for f in files:
        if f.is_file():
            h.update(f.name.encode('utf-8'))
            h.update(f.read_bytes())
    return {'name': GENERATOR, 'scriptsHash': h.hexdigest()[:16], 'parityTester': parity_commit(p)}


# ---------------------------------------------------------------- design/rules.md, design/tests.md

def design_rules(p):
    """{ 'R<n>': text } from design/rules.md: every table row whose first cell is a number."""
    if not p.rules_md.is_file():
        return {}
    out = {}
    for line in read_text(p.rules_md).splitlines():
        m = re.match(r'^\|\s*([0-9]+)\s*\|(.*?)\|', line)
        if m:
            out[f'R{m.group(1)}'] = re.sub(r'\s+', ' ', m.group(2)).strip()
    return out


# tests.md line label -> case.design key
DESIGN_LABELS = {'Request': 'request', 'Expected outcome': 'outcome', 'Expected rows': 'rows', 'Rules': 'rules',
                 'Not asserted': 'notAsserted', 'Does not verify': 'doesNotVerify'}
_LABEL = re.compile(r'^([A-Z][A-Za-z ]{0,40}):(?:\s|$)')


def rule_tokens(text):
    """`Rules: 5, 7, 9` -> (['5', '7', '9'], ['R5', 'R7', 'R9']); `-` or empty -> ([], [])."""
    toks = [t.strip() for t in re.split(r'[,;]', text or '') if t.strip() and t.strip() not in ('-', '—', 'none')]
    ids = []
    for t in toks:
        m = re.match(r'^R?([0-9]+)\b', t)
        if m and f'R{m.group(1)}' not in ids:
            ids.append(f'R{m.group(1)}')
    return toks, ids


def tests_md_blocks(p):
    """{case name: design block} from design/tests.md, taken as it is.

    A block is a `## <name>` section holding at least one of the labelled lines `Request:`,
    `Expected outcome:`, `Expected rows:`, `Rules:`, `Not asserted:`, `Does not verify:`; the value
    is the raw text after the label plus the following non-blank lines that start no other label.
    When the file has `# <entry>` headings, only the entry's own section is read.
    Returns {name: {request, outcome, rows, rules[], notAsserted, doesNotVerify, ruleIds[]}}."""
    if not p.tests_md.is_file():
        return {}
    lines = read_text(p.tests_md).splitlines()
    h1 = [i for i, l in enumerate(lines) if re.match(r'^# \S', l)]
    mine = [i for i in h1 if lines[i][2:].strip() == p.entry]
    if mine:
        start = mine[0]
        nxt = [i for i in h1 if i > start]
        lines = lines[start + 1: nxt[0] if nxt else len(lines)]
    out = {}
    name, block, key = None, None, None

    def close():
        if name and block is not None and any(v is not None for k, v in block.items() if k != 'rules'):
            raw = block.pop('_rules', None)
            block['rules'], block['ruleIds'] = rule_tokens(raw)
            out[name] = block
    for line in lines:
        m = re.match(r'^##\s+(.+?)\s*$', line)
        if m and not line.startswith('###'):
            close()
            name, key = m.group(1).strip().strip('`'), None
            block = {k: None for k in DESIGN_LABELS.values() if k != 'rules'}
            continue
        if block is None:
            continue
        if not line.strip():
            key = None
            continue
        lm = _LABEL.match(line)
        if lm:
            key = DESIGN_LABELS.get(lm.group(1))
            if key:
                value = line[lm.end():].strip()
                if key == 'rules':
                    block['_rules'] = value
                else:
                    block[key] = value
            continue
        if key == 'rules':
            block['_rules'] = (block.get('_rules') or '') + ' ' + line.strip()
        elif key:
            block[key] = (block[key] + '\n' if block[key] else '') + line.rstrip()
    close()
    for b in out.values():
        for k in list(b):
            if k == '_rules':
                b.pop(k)
    return out
