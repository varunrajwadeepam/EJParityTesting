#!/usr/bin/env python3
"""Paragraph and line coverage of the recorded runs against the paragraph index.

Pure calculation, no threshold. Importable:
    compute(index, runs, sources_dir=None) -> dict
    uncovered_md(result) -> str
    load_runs(paths) -> (runs, warnings)
`runs` items: {"case": str, "coverage": <run_cobol result["coverage"]>}.

CLI: python -B coverage.py <mu> [--entry E] [--runs DIR]
Default runs, first that has any: the cases of the last build (tests/.tmp/<E>/build.json `runs`,
else the installed package's golden cases -> run key, as build.py resolves them; keys without a run
file skipped), then tests/.tmp/<E>/runs, then unit/<E>/.run-cobol. `@probe` runs never count.
Run files accepted (*.json, first match wins):
  {"coverage": {"programs": [...]}}                 bare coverage holder
  {"case": .., "result": {"coverage": ..}}          run_cobol out file (.run-cobol/)
  {"run": {"coverage": ..}} / {"record": ..}        wrapped run result
  {.., "repeats": [<any of the above>, ..]}         record file: first repeat with coverage
  [<any of the above>, ..]                          list of runs in one file
Case name: case (str, or dict .name) / name / key / id / label (without plan:/suite:), else the file stem.
Writes <mu>/tests/.tmp/<E>/coverage.json and uncovered.md. Never outputs source text.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

_PROC_RE = re.compile(r"\bPROCEDURE\s+DIVISION\b", re.I)


# ---------------------------------------------------------------- source

def code_lines(path: Path) -> set[int] | None:
    """1-based numbers of PROCEDURE DIVISION code lines of a fixed-format member.

    Code line: col 7 not '*' or '/', cols 8-72 not blank and not a '*>' comment.
    None when the file cannot be read. Only numbers leave this function.
    """
    try:
        text = path.read_text(encoding="latin-1")
    except OSError:
        return None
    out: set[int] = set()
    in_proc = False
    for n, raw in enumerate(text.split("\n"), 1):
        line = raw.rstrip("\r")
        if len(line) < 7:
            continue
        if line[6] in "*/":
            continue
        area = line[7:72]
        body = area.strip()
        if not body or body.startswith("*>"):
            continue
        if not in_proc:
            if _PROC_RE.search(area):
                in_proc = True
                out.add(n)
            continue
        out.add(n)
    return out


# ---------------------------------------------------------------- runs

def _expand(ranges) -> set[int]:
    lines: set[int] = set()
    for r in ranges or []:
        try:
            a, b = int(r[0]), int(r[1])
        except (TypeError, ValueError, IndexError):
            continue
        lines.update(range(a, b + 1))
    return lines


def _find_coverage(doc, depth: int = 0):
    if depth > 4 or not isinstance(doc, dict):
        return None
    cov = doc.get("coverage")
    if isinstance(cov, dict) and isinstance(cov.get("programs"), list):
        return cov
    for key in ("result", "run", "record", "output"):
        found = _find_coverage(doc.get(key), depth + 1)
        if found is not None:
            return found
    for rep in doc.get("repeats") or []:
        found = _find_coverage(rep, depth + 1)
        if found is not None:
            return found
    return None


def _case_name(doc: dict, default: str) -> str:
    for key in ("case", "name", "key", "id"):
        v = doc.get(key)
        if isinstance(v, str) and v:
            return v
        if isinstance(v, dict) and isinstance(v.get("name"), str):
            return v["name"]
    label = doc.get("label")
    if isinstance(label, str) and label:
        return re.sub(r"^(plan|suite):", "", label)
    return default


def _is_probe(doc) -> bool:
    return isinstance(doc, dict) and str(doc.get("label") or "").endswith("@probe")


def load_runs(paths) -> tuple[list[dict], list[str]]:
    runs: list[dict] = []
    warnings: list[str] = []
    for p in sorted(Path(x) for x in paths):
        try:
            doc = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError) as e:
            warnings.append(f"{p.name}: unreadable ({e.__class__.__name__})")
            continue
        docs = doc if isinstance(doc, list) else [doc]
        found = 0
        if all(_is_probe(d) for d in docs):
            continue
        for i, d in enumerate(docs):
            if _is_probe(d):
                continue
            cov = _find_coverage(d)
            if cov is None:
                continue
            stem = p.stem if len(docs) == 1 else f"{p.stem}#{i}"
            runs.append({"case": _case_name(d, stem), "coverage": cov})
            found += 1
        if not found:
            warnings.append(f"{p.name}: no coverage found, skipped")
    return runs, warnings


# ---------------------------------------------------------------- compute

def compute(index: dict, runs: list[dict], sources_dir: Path | None = None) -> dict:
    iprogs = (index or {}).get("programs") or {}
    sources_dir = Path(sources_dir) if sources_dir else None

    # union of executed lines per program, per-case lines, run facts
    union: dict[str, set[int]] = {}
    per_case: dict[str, dict[str, set[int]]] = {}
    entered_in: dict[str, int] = {}
    instrumented: dict[str, int] = {}
    src_name: dict[str, str] = {}
    unknown: set[str] = set()
    for run in runs:
        case = str(run.get("case"))
        cmap = per_case.setdefault(case, {})
        for p in (run.get("coverage") or {}).get("programs") or []:
            name = p.get("program")
            if not name:
                continue
            if name not in iprogs:
                unknown.add(name)
            if p.get("source"):
                src_name.setdefault(name, p["source"])
            if p.get("entered"):
                entered_in[name] = entered_in.get(name, 0) + 1
            il = p.get("instrumentedLines")
            if isinstance(il, int):
                instrumented[name] = max(il, instrumented.get(name, 0))
            lines = _expand(p.get("executed"))
            union.setdefault(name, set()).update(lines)
            cmap.setdefault(name, set()).update(lines)

    paragraphs: list[dict] = []
    programs: dict[str, dict] = {}
    outside: dict[str, int] = {}
    outside_where: dict[str, dict] = {}
    estimated_any = False
    for prog, pdata in iprogs.items():
        source = src_name.get(prog) or pdata.get("source") or f"{prog}.CBL"
        code = code_lines(sources_dir / source) if sources_dir else None
        estimated = code is None
        executed = union.get(prog, set())
        if code is not None:
            executed_code = executed & code
        else:
            executed_code = executed
        in_any: set[int] = set()
        biz = {"total": 0, "covered": 0, "uncovered": 0}
        mech = {"total": 0, "covered": 0}
        lines = {"code": 0, "covered": 0, "uncovered": 0}
        for para in pdata.get("paragraphs") or []:
            try:
                a, b = int(para["lines"][0]), int(para["lines"][1])
            except (KeyError, TypeError, ValueError, IndexError):
                continue
            rng = set(range(a, b + 1))
            in_any |= rng
            kind = para.get("kind", "business")
            n_code = len(rng & code) if code is not None else len(rng)
            n_cov = len(rng & executed_code)
            covered = bool(rng & executed)
            cases = sorted(c for c, m in per_case.items() if rng & m.get(prog, set()))
            paragraphs.append({
                "program": prog, "name": para.get("name"), "lines": [a, b], "kind": kind,
                "statements": para.get("statements"), "codeLines": n_code,
                "coveredLines": n_cov, "covered": covered, "cases": cases,
                "estimated": estimated,
                **{k: para[k] for k in ("why", "functions", "sql", "performs") if para.get(k)},
            })
            if kind == "mechanism":
                mech["total"] += 1
                mech["covered"] += covered
                continue
            biz["total"] += 1
            biz["covered" if covered else "uncovered"] += 1
            lines["code"] += n_code
            lines["covered"] += n_cov
            if estimated:
                estimated_any = True
        lines["uncovered"] = lines["code"] - lines["covered"]
        out_lines = executed - in_any
        if out_lines:
            outside[prog] = len(out_lines)
            first, last = (min(in_any), max(in_any)) if in_any else (0, 0)
            outside_where[prog] = {
                "beforeFirst": sum(1 for n in out_lines if n < first),
                "between": sum(1 for n in out_lines if first <= n <= last),
                "afterLast": sum(1 for n in out_lines if n > last),
            }
        programs[prog] = {
            "source": source, "sourceFound": not estimated, "estimated": estimated,
            "entered": prog in entered_in, "enteredIn": entered_in.get(prog, 0),
            "executedLines": len(executed),
            "instrumentedLines": instrumented.get(prog),
            "paragraphs": biz, "mechanism": mech, "lines": lines,
        }

    cases_out: dict[str, list[str]] = {}
    for case in per_case:
        cases_out[case] = [f"{p['program']}.{p['name']}" for p in paragraphs
                           if p["kind"] != "mechanism" and case in p["cases"]]

    tb = {"total": 0, "covered": 0, "uncovered": 0}
    tl = {"code": 0, "covered": 0, "uncovered": 0}
    for pr in programs.values():
        for k in tb:
            tb[k] += pr["paragraphs"][k]
        for k in tl:
            tl[k] += pr["lines"][k]

    warnings = [f"{p}: {n} executed line(s) outside every indexed paragraph"
                f" (before first {w['beforeFirst']}, between {w['between']}, after last {w['afterLast']};"
                " unindexed generated code or index/source mismatch)"
                for p, n in outside.items() for w in [outside_where[p]]]
    warnings += [f"{p}: in the runs but not in the paragraph index" for p in sorted(unknown)]
    if estimated_any:
        warnings.append("line counts estimated from range spans for: "
                        + ", ".join(p for p, v in programs.items() if v["estimated"]))

    return {
        "totals": {"paragraphs": tb, "lines": tl, "outsideLines": sum(outside.values()), "estimated": estimated_any,
                   "runs": len(runs), "cases": len(per_case)},
        "programs": programs,
        "paragraphs": paragraphs,
        "cases": cases_out,
        "outside": outside,
        "outsideWhere": outside_where,
        "notEntered": [p for p in iprogs if p not in entered_in],
        "warnings": warnings,
    }


def uncovered_md(result: dict) -> str:
    t = result.get("totals", {})
    tp, tl = t.get("paragraphs", {}), t.get("lines", {})
    out = ["# Uncovered business paragraphs", "",
           f"Business paragraphs covered {tp.get('covered', 0)}/{tp.get('total', 0)}; "
           f"lines covered {tl.get('covered', 0)}/{tl.get('code', 0)}"
           + (" (estimated)" if t.get("estimated") else "")
           + f"; executed lines outside every indexed paragraph {t.get('outsideLines', 0)}.", ""]
    if result.get("notEntered"):
        out += ["Programs never entered: " + ", ".join(result["notEntered"]), ""]
    rows = [p for p in result.get("paragraphs", []) if p["kind"] != "mechanism" and not p["covered"]]
    if not rows:
        out.append("None.")
    for p in rows:
        a, b = p["lines"]
        line = (f"- {p['program']} `{p['name']}` lines {a}-{b}, statements {p.get('statements')}, "
                f"code lines {p['codeLines']}")
        hints = []
        if p.get("why"):
            hints.append(f"why: {p['why']}")
        if p.get("functions"):
            hints.append("functions: " + ", ".join(map(str, p["functions"])))
        if p.get("sql"):
            hints.append("sql: " + ", ".join(map(str, p["sql"])))
        if hints:
            line += "; " + "; ".join(hints)
        out.append(line)
    return "\n".join(out) + "\n"


# ---------------------------------------------------------------- CLI

def build_keys(p) -> tuple[dict | None, str | None]:
    """{case name: run key} of the last build: build.json `runs`, else the installed package's golden
    cases with the plan (btlib.suite_run_keys). (None, None) when neither is there."""
    from btlib import ddl, read_json, suite_run_keys

    bj = p.tmp / "build.json"
    if bj.is_file():
        keys = read_json(bj, "build.json").get("runs")
        if isinstance(keys, dict):
            return keys, p.rel(bj)
    if p.suite.is_file() and p.plan.is_file():
        return suite_run_keys(read_json(p.plan, "plan"), read_json(p.suite, "package"), ddl(p)), p.rel(p.suite)
    return None, None


def build_runs(p, keys: dict) -> tuple[list[dict], list[str]]:
    """The runs of the build's cases, named by case; a key without a run file (stale) or a probe run is skipped."""
    runs, warnings = [], []
    for name, key in keys.items():
        f = p.runs / f"{key}.json"
        try:
            doc = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError):
            warnings.append(f"{name}: run {key} not in {p.rel(p.runs)}, skipped")
            continue
        cov = None if _is_probe(doc) else _find_coverage(doc)
        if cov is not None:
            runs.append({"case": name, "coverage": cov})
    return runs, warnings


def run():
    """CLI (btlib conventions: one JSON object on stdout; exit 0 done, 1 failed)."""
    from btlib import Paths, Stop, parser  # the CLI only: compute() and friends stay importable without it

    ap = parser(__doc__.splitlines()[0])
    ap.add_argument("--runs", help="folder of run files (default: the last build's cases, else tests/.tmp/<E>/runs, "
                                   "else unit/<E>/.run-cobol)")
    a = ap.parse_args()
    p = Paths(a.mu, a.entry)
    try:
        index = json.loads(p.paragraph_index.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        raise Stop(f"paragraph index unusable: {p.rel(p.paragraph_index)} ({e.__class__.__name__})")
    runs, warnings, runs_dir, source = [], [], None, None
    keys, of = (None, None) if a.runs else build_keys(p)
    if keys:
        runs, warnings = build_runs(p, keys)
        if runs:
            runs_dir, source = p.runs, of
    candidates = [Path(a.runs)] if a.runs else [p.runs, p.unit / ".run-cobol"]
    for d in candidates if not runs else []:
        files = sorted(d.glob("*.json")) if d.is_dir() else []
        if files:
            runs, more = load_runs(files)
            if runs:
                runs_dir, source, warnings = d, p.rel(d), warnings + more
                break
    if not runs:
        raise Stop("no runs with coverage in: " + ", ".join([*([of] if of else []), *(p.rel(c) for c in candidates)]))
    result = compute(index, runs, p.sources)
    result["entry"] = p.entry
    result["runsDir"] = p.rel(runs_dir)
    result["runsFrom"] = source
    warnings += result["warnings"]
    p.tmp.mkdir(parents=True, exist_ok=True)
    cj, um = p.tmp / "coverage.json", p.tmp / "uncovered.md"
    cj.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    um.write_text(uncovered_md(result), encoding="utf-8")
    return {"status": "ok", "entry": p.entry, "runsDir": p.rel(runs_dir), "runsFrom": source, "totals": result["totals"],
            "notEntered": result["notEntered"], "files": [p.rel(cj), p.rel(um)], "warnings": warnings}


if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    sys.dont_write_bytecode = True
    from btlib import main
    main(run)
