#!/usr/bin/env python3
"""The recording database: check it, create the unit's tables in it, empty them, probe the runner.

    python -B db.py <mu> [--entry E] --check          reachable? which unit/schema.sql tables exist
    python -B db.py <mu> [--entry E] --tables         the unit/schema.sql tables with their row counts
    python -B db.py <mu> [--entry E] --create-tables  create the missing unit/schema.sql tables in the
                                                       schema (idempotent: existing tables are skipped)
    python -B db.py <mu> [--entry E] --reset          delete every row of those tables (children first)
    python -B db.py <mu> [--entry E] --runner-probe   one run of the first unit case against it, to
                                                       prove the runner reaches the database

The database is tools.yaml `golden-db2` (btlib.recording_db; required, no fallback to `db2`); the
database itself is given, never created here. Statements go through run-cobol's CLP route (the
Db2 container), with SET SCHEMA <schema>; the tables are created unqualified in that schema.
Several actions may be combined; they run in the order create-tables, reset, tables, check, probe.
Exit 0 done; 2 tables missing (--check); 1 database or runner not reached.
"""

import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

sys.dont_write_bytecode = True

from btlib import (RUN_COBOL, Paths, Stop, conn, db2_run, db_env, ddl, eprint, main, parser,  # noqa: E402
                   read_text, recording_db, reset_sql, reset_tables, tool)

ALREADY_THERE = ('SQL0601N', 'SQL0624N', 'SQL0605W')


def _rows(text):
    return [l.strip() for l in text.splitlines() if l.strip() and not l.startswith(('DB2', 'SQL'))]


def existing(db):
    """(reachable, tables of the schema, message)."""
    ok, out = db2_run(db, f"SELECT TABNAME FROM SYSCAT.TABLES WHERE TABSCHEMA = '{db['schema']}' AND TYPE = 'T';",
                      stop=False)
    if not ok:
        return False, set(), out.strip()[-600:]
    return True, {r.upper() for r in _rows(out) if re.fullmatch(r'[A-Za-z0-9_#$@]+', r)}, ''


def statements(sql):
    """The statements of a DDL file (comments dropped, split on ; outside quotes)."""
    text = '\n'.join(line.split('--', 1)[0] for line in sql.splitlines())
    out, cur, quote = [], '', False
    for ch in text:
        if ch == "'":
            quote = not quote
        if ch == ';' and not quote:
            if cur.strip():
                out.append(cur.strip())
            cur = ''
        else:
            cur += ch
    if cur.strip():
        out.append(cur.strip())
    return out


def table_of(stmt):
    pats = [r'^CREATE\s+TABLE\s+(?:"?\w+"?\.)?"?(\w+)"?', r'^ALTER\s+TABLE\s+(?:"?\w+"?\.)?"?(\w+)"?',
            r'^CREATE\s+(?:UNIQUE\s+)?INDEX\s+\S+\s+ON\s+(?:"?\w+"?\.)?"?(\w+)"?',
            r'^COMMENT\s+ON\s+(?:TABLE|COLUMN)\s+(?:"?\w+"?\.)?"?(\w+)"?']
    for pat in pats:
        m = re.match(pat, stmt, re.I)
        if m:
            return m.group(1).upper()
    return None


def create_tables(p, db):
    reachable, have, msg = existing(db)
    if not reachable:
        raise Stop(f"database {db['database']} in {db['container']} not reached: {msg}")
    stmts = statements(read_text(p.ddl))
    wanted = list(ddl(p))
    missing = [t for t in wanted if t not in have]
    run = [s for s in stmts if (table_of(s) in missing) or (table_of(s) is None and missing
                                                             and not re.match(r'^(CONNECT|SET\s+SCHEMA)\b', s, re.I))]
    if run:
        ok, out = db2_run(db, ';\n'.join(run) + ';', stop=False, allowed=ALREADY_THERE)
        eprint(out[-2000:])
        if not ok:
            raise Stop(f"creating the tables of {p.rel(p.ddl)} in {db['database']}/{db['schema']} failed (see stderr)",
                       created=[], missing=missing)
    _, now, _ = existing(db)
    still = [t for t in wanted if t not in now]
    if still:
        raise Stop(f"after --create-tables these tables are still missing: {', '.join(still)}", missing=still)
    return {'created': missing, 'skipped': [t for t in wanted if t not in missing]}


def reset(p, db):
    ok, out = db2_run(db, reset_sql(ddl(p)), stop=True)
    if not ok:
        raise Stop(f"reset of {db['database']}/{db['schema']} failed: {out[-800:]}")
    return {'emptied': reset_tables(ddl(p))}


def tables(p, db):
    reachable, have, msg = existing(db)
    if not reachable:
        raise Stop(f"database {db['database']} in {db['container']} not reached: {msg}")
    order = [t for t in reset_tables(ddl(p)) if t in have]
    counts = {}
    if order:
        sql = ' UNION ALL '.join(f"SELECT '{t}', COUNT(*) FROM {t}" for t in order) + ';'
        ok, out = db2_run(db, sql, stop=False)
        for r in _rows(out):
            parts = r.split()
            if len(parts) == 2 and parts[1].isdigit():
                counts[parts[0]] = int(parts[1])
    return {'tables': {t: (counts.get(t) if t in have else None) for t in ddl(p)}}


def check(p, db):
    reachable, have, msg = existing(db)
    if not reachable:
        return 1, {'status': 'unreachable', 'error': msg}
    wanted = list(ddl(p))
    missing = [t for t in wanted if t not in have]
    out = {'present': [t for t in wanted if t in have], 'missing': missing}
    if missing:
        return 2, {'status': 'tables-missing', **out, 'next': 'db.py --create-tables'}
    return 0, {'status': 'ok', **out}


def probe(p, db):
    """The first unit case (cases.json), without its fixture, against the recording database: its SQL
    must reach the database. On empty tables the outcome itself does not matter."""
    unit = json.loads(read_text(p.unit_cases))['cases'][0] if p.unit_cases.is_file() else None
    if unit is None:
        raise Stop(f'{p.rel(p.unit_cases)} has no case to probe with')
    cases = {'unit': p.entry, 'db2': conn(db),
             'cases': [{'name': 'probe', 'inputs': unit['inputs'], 'env': unit.get('env') or {}}]}
    runner = tool(p.mu, 'cobol-runner')['url']
    import os
    with tempfile.TemporaryDirectory() as d:
        f = Path(d) / 'cases.json'
        f.write_text(json.dumps(cases), encoding='utf-8')
        proc = subprocess.run([sys.executable, '-B', str(RUN_COBOL), str(p.unit.resolve()), '--cases', str(f), '--out', d,
                               '--runner', runner, '--no-sql', '--all'], capture_output=True, text=True,
                              encoding='utf-8', errors='replace', env={**os.environ, **db_env(db)})
        out = Path(d) / 'probe.json'
        result = json.loads(out.read_text(encoding='utf-8'))['result'] if out.is_file() else {}
    text = json.dumps(result)[:4000]
    sqlerr = [w for w in ('SQL1013N', 'SQL30081N', 'SQL1031N', 'SQL1032N', 'SQL30082N', 'SQL1336N') if w in text]
    eprint(proc.stdout[-1500:], proc.stderr[-1500:])
    if not result.get('ok') or sqlerr:
        return 1, {'status': 'runner-not-reaching-db', 'sqlErrors': sqlerr,
                   'error': f"the runner did not reach {db['database']} ({', '.join(sqlerr) or 'no result'})"}
    return 0, {'status': 'ok', 'runnerReachesDb': True}


def run():
    ap = parser('Check, fill and empty the recording database.')
    for flag in ('check', 'tables', 'create-tables', 'reset', 'runner-probe'):
        ap.add_argument(f'--{flag}', action='store_true')
    a = ap.parse_args()
    p = Paths(a.mu, a.entry)
    db = recording_db(p.mu)
    doc = {'database': db['database'], 'schema': db['schema'], 'container': db['container'], 'section': db['section'],
           'runnerHost': f"{db['runner_host']}:{db['port']}"}
    code = 0
    if a.create_tables:
        doc['createTables'] = create_tables(p, db)
    if a.reset:
        doc['reset'] = reset(p, db)
    if a.tables:
        doc.update(tables(p, db))
    if a.check or not any((a.create_tables, a.reset, a.tables, a.runner_probe)):
        c, r = check(p, db)
        code = max(code, c)
        doc['check'] = r
        if c:
            doc['status'] = r['status']
    if a.runner_probe:
        c, r = probe(p, db)
        doc['runnerProbe'] = r
        if c:
            code = 1
            doc['status'] = r['status']
    return code, doc


if __name__ == '__main__':
    main(run)
