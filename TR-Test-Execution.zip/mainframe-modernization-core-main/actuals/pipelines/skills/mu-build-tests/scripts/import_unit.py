#!/usr/bin/env python3
"""Start the plan from the unit's recorded cases: <mu>/unit/<E>/cases.json -> basic plan cases.

    python -B import_unit.py <mu> [--entry E]

Needs a plan with its contract (inputMap, constantInputs, defaults). Every unit case becomes a
plan case of the same name with `origin: basic`, its COBOL inputs read back into params through
inputMap (a group: its count and occurrences into a list of items). Its fixture is copied
unchanged into the working fixtures (tests/fixtures/<E>/); a working fixture of the same name
with other content is never overwritten - that is reported and the case is skipped.

design/tests.md is taken as it is: the `## <name>` block of the case gives `design` {request,
outcome, rows, rules[], notAsserted, doesNotVerify} (raw strings) and `ruleIds` (R<n> from its
`Rules:` line). A basic case already in the plan keeps everything the agent set; its `design` is
written again and the tests.md rule ids missing from its ruleIds are added (never removed).

The case's clock is its env CAGENSHIM_CLOCK, else the cases.json top-level env one, else plan
defaults.clock; one other than defaults.clock becomes the plan case's `clock`. An input equal to
the value its constantInputs entry has at that clock (`clock:<fmt>` evaluated there) is that
constant, not an extra input; one that differs from its `clock:` constant is dropped too (the case
records at its own clock) and named in `warnings`.

Inputs no param carries go to the case's extraInputs, which makes it not-representable with a
reason naming them; so does a group count that differs from the items sent. Category is left for
the agent ("category": null): build.py refuses the plan until every case has one. Nothing is
recorded here: the unit's `expect` values are not copied.

Exit 2 with `gaps` when a unit case has no tests.md block or a tests.md block names no unit case
(the plan is written all the same); 1 when the plan or the unit cannot be read.
"""

import json
import re
import shutil
import sys
from pathlib import Path

sys.dont_write_bytecode = True

from btlib import (Paths, Stop, constant_inputs, defaults, design_rules, eprint, is_clock_input, is_group, load_plan,  # noqa: E402
                   main, parser, read_text, schema_fields, shim_clock, tests_md_blocks, valid_clock, write_json)


def pairs_of(raw):
    if isinstance(raw, dict):
        return [(k, '' if v is None else str(v)) for k, v in raw.items()]
    out = []
    for item in raw or []:
        if isinstance(item, (list, tuple)) and len(item) == 2:
            out.append((item[0], '' if item[1] is None else str(item[1])))
        elif isinstance(item, dict):
            out += [(k, '' if v is None else str(v)) for k, v in item.items()]
    return out


def design_of(block):
    return {k: block.get(k) for k in ('request', 'outcome', 'rows', 'rules', 'notAsserted', 'doesNotVerify')}


def run():
    ap = parser('Import unit/<E>/cases.json and design/tests.md into the plan as basic cases.')
    a = ap.parse_args()
    p = Paths(a.mu, a.entry)
    plan = load_plan(p)
    imap = plan.get('inputMap') or {}
    if not imap:
        raise Stop('the plan has no inputMap: declare the contract first (PLAN.md)')
    if not p.unit_cases.is_file():
        raise Stop(f'{p.rel(p.unit_cases)} not found')
    unit = json.loads(read_text(p.unit_cases))
    blocks = tests_md_blocks(p)
    rules = design_rules(p)
    fields = schema_fields(p)['inputs']
    scalar = {f: k for k, f in imap.items() if isinstance(f, str)}
    count_of = {g['count']: k for k, g in imap.items() if is_group(g)}
    item_of = {f: (k, key) for k, g in imap.items() if is_group(g) for key, f in g['item'].items()}
    const = plan.get('constantInputs') or {}
    clocked = {f for f, v in const.items() if is_clock_input(v)}
    top_env = unit.get('env') or {}
    plan_clock = defaults(plan).get('clock')
    by_name = {c.get('name'): c for c in plan.get('cases') or []}
    added, refreshed, skipped, nr, warnings = [], [], [], [], []
    labels = set()
    unit_names = [uc.get('name') for uc in unit.get('cases') or []]
    gaps = [{'kind': 'no-tests-md-block', 'case': n,
             'detail': f'unit case {n} has no "## {n}" block in design/tests.md'} for n in unit_names if n not in blocks]
    gaps += [{'kind': 'no-unit-case', 'case': n,
              'detail': f'design/tests.md block "## {n}" names no case of {p.rel(p.unit_cases)}'}
             for n in blocks if n not in unit_names]
    for n, b in blocks.items():
        for r in b['ruleIds']:
            if rules and r not in rules:
                warnings.append(f'tests.md {n}: rule {r} is not a rule of design/rules.md')

    for uc in unit.get('cases') or []:
        name = uc.get('name')
        block = blocks.get(name)
        if name in by_name:
            pc = by_name[name]
            if pc.get('origin', 'basic') == 'basic' and block:
                pc['origin'] = 'basic'
                pc['design'] = design_of(block)
                ids = list(pc.get('ruleIds') or [])
                pc['ruleIds'] = ids + [r for r in block['ruleIds'] if r not in ids]
                refreshed.append(name)
            else:
                skipped.append(f'{name}: the plan already has it')
            continue
        clock = (uc.get('env') or {}).get('CAGENSHIM_CLOCK') or top_env.get('CAGENSHIM_CLOCK') or plan_clock
        clock = str(clock) if clock else None
        if valid_clock(clock):
            fixed = dict(constant_inputs(plan, clock))
        else:
            if clock:
                warnings.append(f'unit case {name}: clock {clock!r} is not ^[0-9]{{14}}([0-9]{{1,6}})?$')
            fixed = {f: v for f, v in const.items() if not is_clock_input(v)}
        params, extra, counts, groups = {}, {}, {}, {}
        for f, v in pairs_of(uc.get('inputs')):
            m = re.match(r'(.+)\(([0-9]+)\)\Z', f)
            base, occ = (m.group(1), int(m.group(2))) if m else (f, None)
            if occ and base in item_of:
                g, key = item_of[base]
                groups.setdefault(g, {}).setdefault(occ, {})[key] = v
            elif f in count_of:
                counts[count_of[f]] = (f, v)
            elif f in scalar:
                params[scalar[f]] = v
            elif f in fixed and fixed[f] == v:
                continue
            elif f in clocked:
                at = f' ({fixed[f]!r} at {clock})' if f in fixed else ''
                warnings.append(f'unit case {name}: {f} {v!r} differs from its clock constant{at}: dropped, '
                                'the case records at its own clock')
                continue
            else:
                extra[f] = v
        for g, occs in groups.items():
            n = max(occs)
            params[g] = [occs.get(i, {}) for i in range(1, n + 1)]
        for g, (f, v) in counts.items():
            sent = len(params.get(g) or [])
            if v.strip() == '' and sent == 0:
                continue
            if g not in params:
                params[g] = []
            if v.strip() != str(sent):
                extra[f] = v
        fx = uc.get('fixture')
        fixture = None
        if fx:
            src = p.unit_cases.parent / fx
            if not src.is_file():
                src = p.unit / fx
            if not src.is_file():
                skipped.append(f'{name}: fixture {fx} not found beside cases.json')
                continue
            fixture = Path(fx).name
            dst = p.fixtures / fixture
            if dst.is_file() and dst.read_bytes() != src.read_bytes():
                skipped.append(f"{name}: working fixture {fixture} differs from the unit's {fx} - not overwritten")
                continue
            if not dst.is_file():
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(src, dst)
        case = {'name': name, 'origin': 'basic', 'category': None,
                'about': f"unit case {name}: {str(uc.get('about') or '').strip()}", 'params': params}
        if block:
            case['ruleIds'] = list(block['ruleIds'])
            case['design'] = design_of(block)
        if fixture and fixture != defaults(plan).get('fixture'):
            case['fixture'] = fixture
        if clock and (not plan_clock or shim_clock(clock) != shim_clock(plan_clock)):
            case['clock'] = clock
        if extra:
            case['extraInputs'] = extra
            case['status'] = 'not-representable'
            case['reason'] = 'imported from the unit: inputs no API field carries: ' + ', '.join(sorted(extra))
            nr.append(f"{name}: {', '.join(sorted(extra))}")
        for f in extra:
            base = re.sub(r'\([0-9]+\)\Z', '', f)
            if base not in fields:
                raise Stop(f'unit case {name}: input {f} is not in schema.yaml')
        labels.update((uc.get('verify') or {}).keys())
        plan.setdefault('cases', []).append(case)
        added.append(name)
    write_json(p.plan, plan)
    for s in skipped:
        eprint(f'skipped {s}')
    for g in gaps:
        eprint(f"gap: {g['detail']}")
    doc = {'plan': p.rel(p.plan), 'added': added, 'refreshed': refreshed, 'skipped': skipped,
           'notRepresentable': nr, 'gaps': gaps, 'warnings': warnings,
           'unitVerifyLabels': sorted(labels), 'planTables': sorted((plan.get('tables') or {}).keys()),
           'next': 'set "category" of every imported case (build.py refuses null)'}
    if gaps:
        return 2, {'status': 'gaps', **doc}
    return doc


if __name__ == '__main__':
    main(run)
