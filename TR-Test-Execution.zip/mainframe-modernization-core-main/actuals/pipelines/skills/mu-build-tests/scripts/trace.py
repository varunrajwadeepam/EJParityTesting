#!/usr/bin/env python3
"""tests/package/<E>/traceability.md from the installed package.

    python -B trace.py <mu> [--entry E]

Reads tests/package/<E>/<E>-tests.json (rules[], cases[].ruleIds, cases[].paragraphs,
coverage.paragraphs) and design/rules.md (From cells, through arms.rules_md). Writes four short
tables: rule -> cases -> paragraphs; business paragraph -> rules citing it (From) -> cases that
executed it; uncovered business paragraphs; cases without rule ids. Only golden cases prove.
"""

import sys

sys.dont_write_bytecode = True

from arms import rules_md  # noqa: E402
from btlib import Paths, Stop, main, parser, read_json, write_text  # noqa: E402


def _j(xs, empty='-'):
    return ', '.join(xs) if xs else empty


def render(p, suite, cites):
    cases = suite.get('cases') or []
    golden = [c for c in cases if c.get('status') == 'golden']
    paras_cov = (suite.get('coverage') or {}).get('paragraphs') or []
    biz = [x for x in paras_cov if x.get('kind', 'business') == 'business']
    case_by_name = {c.get('name'): c['id'] for c in cases}

    def cases_of_para(x):
        out = [case_by_name.get(n, n) for n in x.get('cases') or []]
        key = f"{x['program']}.{x['name']}"
        out += [c['id'] for c in golden if key in (c.get('paragraphs') or []) and c['id'] not in out]
        return out

    from_of = {}
    for (prog, para), rids in cites.items():
        for r in rids:
            from_of.setdefault(r, []).append(f'{prog}.{para}')
    lines = [f'# traceability - {suite.get("unit") or p.entry}', '',
             f"Package version {suite.get('package', {}).get('version')}, "
             f"contentHash {str(suite.get('package', {}).get('contentHash', ''))[:16]}. "
             'Golden cases only prove a rule; paragraphs are the business paragraphs a case executed.', '',
             '## Rule -> cases -> paragraphs', '', '| rule | cases | paragraphs executed | From (rules.md) |',
             '|---|---|---|---|']
    unproven = []
    for r in suite.get('rules') or []:
        rid = r['id']
        cs = [c for c in golden if rid in (c.get('ruleIds') or [])]
        if not cs:
            unproven.append(rid)
        executed = sorted({x for c in cs for x in c.get('paragraphs') or []})
        lines.append(f"| {rid} | {_j([c['id'] for c in cs])} | {_j(executed)} | {_j(from_of.get(rid))} |")
    lines += ['', '## Paragraph -> rules -> cases', '', '| paragraph | lines | rules (From) | cases |', '|---|---|---|---|']
    uncovered = []
    for x in biz:
        cs = cases_of_para(x)
        ln = x.get('lines') or []
        rng = f'{ln[0]}-{ln[1]}' if len(ln) == 2 else ''
        if not cs:
            uncovered.append((x, rng))
        lines.append(f"| {x['program']}.{x['name']} | {rng} | {_j(cites.get((x['program'], x['name'])))} | {_j(cs)} |")
    lines += ['', f'## Uncovered business paragraphs ({len(uncovered)})', '']
    if uncovered:
        lines += ['| paragraph | lines | rules (From) |', '|---|---|---|']
        lines += [f"| {x['program']}.{x['name']} | {rng} | {_j(cites.get((x['program'], x['name'])))} |"
                  for x, rng in uncovered]
    else:
        lines.append('(none)')
    no_rule = [c for c in cases if not c.get('ruleIds')]
    lines += ['', f'## Cases without rule ids ({len(no_rule)})', '']
    if no_rule:
        lines += ['| case | name | status |', '|---|---|---|']
        lines += [f"| {c['id']} | {c.get('name', '')} | {c.get('status', '')} |" for c in no_rule]
    else:
        lines.append('(none)')
    lines.append('')
    return '\n'.join(lines), {'rules': len(suite.get('rules') or []), 'unprovenRules': unproven,
                              'paragraphs': len(biz), 'uncovered': len(uncovered),
                              'casesWithoutRules': [c['id'] for c in no_rule]}


def run():
    ap = parser('Write package/<E>/traceability.md from the installed package.')
    a = ap.parse_args()
    p = Paths(a.mu, a.entry)
    if not p.suite.is_file():
        raise Stop(f'no installed package {p.rel(p.suite)}: build.py --install first')
    suite = read_json(p.suite, 'package')
    cites = rules_md(p)[0] if p.rules_md.is_file() else {}
    text, doc = render(p, suite, cites)
    out = p.package / 'traceability.md'
    write_text(out, text)
    return {'traceability': p.rel(out), **doc}


if __name__ == '__main__':
    main(run)
