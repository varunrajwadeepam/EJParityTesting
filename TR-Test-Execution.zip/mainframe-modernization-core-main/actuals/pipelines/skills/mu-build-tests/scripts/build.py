#!/usr/bin/env python3
"""Assemble <E>-tests.json from the plan and the recorded runs.

    python -B build.py <mu> [--entry E] [--install] [--accept-regressions] [--new-contract]

Pure: reads the base suite (previous/<E>/<E>-tests.json, else the published one), the plan, the
runs record.py cached, design/rules.md and extracted-logic/paragraph-index.json; writes the suite,
build.json, build-report.md, coverage.json and uncovered.md under tests/.tmp/<E>/. Nothing about
a particular unit is in here: the plan declares the contract and every rule below is applied to
every case.

  the plan       holds every case, by name (kebab-case, else refused). A base case keeps its id, name and place; a name
                 the base suite does not have gets the next id (after every base and removed
                 id). A base case missing from the plan is refused: keep it, or drop it through
                 plan.removed { <name>: { id, reason } } (the id and the name are never reused).
  origin         every plan case is `basic` (import_unit, from unit/<E>/cases.json + tests.md,
                 with its `design` block) or `advanced` (the agent's).
  status         plan says not-representable -> not-representable (reason required, request and
                 expected null). Run aborted, or its repeats disagree -> not-recorded (reason: the
                 runtime's error line / "not repeatable"). A path value through |enum that only the
                 COBOL field's padding or cut maps -> not-representable (unspellable). Else golden.
  legacy         read through plan.outputs (btlib.legacy_of), plus `verify`: the raw CLP rows of
                 every table check, and technicalFailure when the failure flag is set.
  expected       with an api: the operation's answer for the recorded outcome (status, body or
                 `empty`), plus `tables`: per check the query, the columns, the typed rows the
                 COBOL left, and how to compare them.
  clockSensitive every golden case also ran once at its probe clock (record.py): true when that run
                 aborted or its outcome differs (run id and inputs aside), or a fired decision is
                 clockDependent. A probe difference without such a decision is reported.
  decisions      plan.decisions, applied to every golden case on every build (base cases too):
                 kind java -> anticipatedJavaDivergence, kind stack -> stackDivergence, compare
                 joins a 2xx body's compare; `answer` decides the expected answer on top of the
                 recorded one (decidedAnswer keeps the recorded one; a rebuild starts from it).
  existing case  as tc-gen: a golden case whose outcome differs from its base recording is a
                 REGRESSION (kept as it was, exit 2, unless --accept-regressions) - unless its
                 fixture changed since, or --new-contract changed the legacySchema: then UPDATED;
                 other table checks, or a changed binding on the same outcome: UPDATED;
                 not-recorded that now runs: PROMOTED; repeats that disagree: a regression when
                 golden. Base cases record.py did not run are CARRIED forward (binding applied again).
  rules          design/rules.md: every numbered rule is R<n>; rules[] gets provenBy from the
                 golden cases whose ruleIds name it.
  coverage       coverage.py over the golden cases' runs (never a probe) and the paragraph index;
                 build.json `runs` names each run by case ({name: run key}).
  package        format 3, tc-gen body order (unit, api, binding, goldenMaster, comparison,
                 comparisonRules, resetTables, statuses, legacySchema, rules, coverage, recordings,
                 cases); version raised when contentHash changes; package.inputs outside the seal.

--install writes tests/package/<E>/<E>-tests.json and copies the fixture files the cases name
into that folder (flat, unchanged); package *.sql no case names are removed (previous/ keeps
them). It refuses to replace a published suite that was never rotated (rotate.py) and to install
with regressions. Exit 0 built; 2 regressions; 1 plan or run errors.
"""

import json
import re
import shutil
import sys
from decimal import Decimal

sys.dont_write_bytecode = True

import coverage as cov  # noqa: E402  (the sibling coverage.py)
from btlib import (CASE_NAME, CATEGORIES, FORMAT, ORIGINS, SCHEMA_ID, STATUS_TEXTS, STATUSES, Paths, Stop,  # noqa: E402
                   bad_clocks, check_key, check_sql, checks_changed, checks_of, clock_inputs, compare_errors, compare_of, content_hash,
                   contract_errors, ddl, decide, decision_errors, defaults, pending_decisions, design_mismatches, design_rules, dumps, expected_for, field_of, fires,
                   generator, is_list, iso_now, key_of, legacy_contract, legacy_of, load_base, load_plan, main,
                   operation_for, padded_variant, parser, plan_inputs, probe_clock, published, read_json, request_for,
                   reset_tables, run_key, same_outcome, schema_fields, schema_types, sha256, table_types, typed_rows,
                   unknown_tables, write_json, write_text)

KEYS = ['id', 'name', 'origin', 'category', 'about', 'ruleIds', 'status', 'reason', 'fixture', 'clock', 'clockSensitive',
        'request', 'expected', 'decidedAnswer', 'compare', 'anticipatedJavaDivergence', 'stackDivergence', 'design',
        'paragraphs', 'recording', 'legacy']
DESIGN_KEYS = ('request', 'outcome', 'rows', 'rules', 'notAsserted', 'doesNotVerify')
# Fields a base case takes from the plan or derives again, never from the base suite.
PLAN_FIELDS = ('ruleIds', 'compare', 'origin', 'design', 'decidedAnswer', 'anticipatedJavaDivergence', 'stackDivergence')
# How a consumer compares a replayed case with this package: fixed, the same for every unit (tc-gen).
COMPARISON_RULES = [
    {'id': 'STATUS', 'rule': 'the HTTP status equals expected.status (every bound golden case)'},
    {'id': 'BODY_WHOLE_ON_2XX', 'rule': 'for a 2xx status the whole body equals expected.body: the same keys, the same values'},
    {'id': 'OUTCOME_ONLY_ON_ERROR', 'rule': 'for any other status only the status is compared, never the body'},
    {'id': 'EMPTY_MEANS_NO_BODY', 'rule': 'expected.empty: the answer has no body'},
    {'id': 'RTRIM', 'rule': 'strings are right-trimmed on both sides'},
    {'id': 'NULL_AS_BLANK', 'rule': 'null equals the empty string'},
    {'id': 'NUMBERS_BY_VALUE', 'rule': 'numbers compare by value (decimal scale not kept)'},
    {'id': 'ARRAYS_IN_ORDER', 'rule': 'arrays compare element by element in order, unless the case compares that path as a set'},
    {'id': 'CASE_COMPARE', 'rule': "a case's compare[]: mode set = that array as a multiset; mode ignore = that path is not "
                                   "compared ([] = every element); each entry carries its reason"},
    {'id': 'TABLES_AFTER_CALL', 'rule': 'every case with expected.tables, error answers included: after the call each table is '
                                        'read with its query and its rows compared (typed; strings right-trimmed, NULL as blank, '
                                        'numbers by value, dates YYYY-MM-DD), the row count always, ordered row by row or as a set'},
    {'id': 'STATE_BEFORE_CALL', 'rule': 'before every case the tables of resetTables are emptied in that order, then the case '
                                        'fixture is applied'},
]
COMPARISON_TEXT = ('COBOL: the legacySchema fields byte-exact. Java: '
                   + '; '.join(f"{x['id']}: {x['rule']}" for x in COMPARISON_RULES) + '.')


def copy(v):
    return json.loads(dumps(v), parse_float=Decimal)


def two_xx_body(exp):
    return bool(exp) and isinstance(exp.get('status'), int) and 200 <= exp['status'] < 300 and isinstance(exp.get('body'), dict)


def run():
    ap = parser('Assemble the package from the plan and the recorded runs.')
    ap.add_argument('--install', action='store_true', help='write the package folder (after rotate.py)')
    ap.add_argument('--accept-regressions', action='store_true')
    ap.add_argument('--new-contract', action='store_true')
    a = ap.parse_args()
    p = Paths(a.mu, a.entry)
    plan = load_plan(p)
    OUT = plan.get('outputs') or {}
    IN, RUN = key_of(OUT, '$inputs'), key_of(OUT, '$runId')
    if not IN or not RUN:
        raise Stop('plan.outputs needs one "$inputs" and one "$runId" entry (PLAN.md "outputs")')
    bad = contract_errors(p, plan, {'new-contract': a.new_contract})
    if bad:
        raise Stop("the plan breaks the naming rules or the base suite's contract (PLAN.md \"Names\")", errors=bad)
    clocks = bad_clocks(plan)
    if clocks:
        raise Stop('clocks: ^[0-9]{14}([0-9]{1,6})?$, and defaults.probeClock other than defaults.clock', errors=clocks)
    bad = decision_errors(plan)
    if bad:
        raise Stop('the plan\'s decisions or the binding\'s failure answers are refused (PLAN.md "Decisions")', errors=bad)
    header = plan.get('suiteHeader') or {}
    old = load_base(p) or {**header, 'legacySchema': OUT, 'cases': []}
    new_contract = dumps(legacy_contract(old.get('legacySchema'))) != dumps(OUT)
    if new_contract and not a.new_contract:
        raise Stop("the base suite's legacySchema is not the plan's outputs: copy it into the plan; only the user may "
                   'change the contract (--new-contract)')
    index = read_json(p.tmp / 'index.json', 'run index (run record.py first)')
    carried_fp = index.get('$carried') or {}
    API = plan.get('api')
    D = defaults(plan)
    DECISIONS = plan.get('decisions') or {}
    PENDING = pending_decisions(p, plan)
    shims = D.get('shims') or ['cagen']
    tables = ddl(p)
    fields = schema_fields(p)
    types = schema_types(p)
    OCCURS = {k: (fields['outputs'].get(next(iter(v['columns'].values()), None)) or 100) for k, v in OUT.items() if is_list(v)}
    RULES = design_rules(p)
    errors, regressions, promotions, updates, carried, removed, notes, bindings = [], [], [], [], [], [], [], []
    clock_gaps, decided, unspellable, notes_changed, design_diffs, pending = [], [], [], [], [], []
    fingerprints, state = {}, {'newest': ''}

    # ------------------------------------------------------------ one recorded run
    def run_file(label):
        key = index.get(label)
        if not key:
            raise Stop(f'no recorded run for {label} -- run record.py')
        return read_json(p.runs / f'{key}.json', 'run')

    def outcome(label, inputs, checks, probe=False):
        r = run_file(label)
        fp = sha256(dumps(r['fingerprint']))[:12]
        if not probe:      # a probe run is no recording of the suite: it never dates it, never fingerprints it
            if r.get('recordedAt', '') > state['newest']:
                state['newest'] = r['recordedAt']
            fingerprints[fp] = r['fingerprint']
        pt = r.get('parityTester') or {}
        recording = {'recordedAt': r.get('recordedAt'), 'fingerprint': fp,
                     'parityTester': f"{pt['commit']}{'+dirty' if pt.get('dirty') else ''}" if pt.get('commit') else None,
                     'repeats': len(r['repeats']), 'runIds': [x.get('runId') for x in r['repeats']]}
        blocks = []
        for x in r['repeats']:
            actual = x['outputs'] if x.get('ok') and x.get('outputs') else None
            raw = {c: x['verify'].get(c, []) for c in checks}
            typed = {c: typed_rows(x['verify'].get(f'{c}#typed', []), plan['tables'][c], f'{label} check {c}')
                     for c in checks}
            blocks.append((actual, legacy_of(actual, plan, inputs, x.get('runId'), raw if checks else None), typed))
        first = blocks[0]
        repeatable = all((b[0] is None) == (first[0] is None) and same_outcome(b[1], first[1], plan)
                         and dumps(b[2]) == dumps(first[2]) for b in blocks)
        out = {'legacy': first[1], 'typed': first[2], 'coverage': r.get('coverage'), 'recording': recording,
               'repeatable': repeatable, 'checks': list(checks),
               'fixtureSha': (r['fingerprint'].get('fixture') or {}).get('sha256')}
        if first[0] is None:
            x = r['repeats'][0]
            text = '\n'.join([x.get('stderr') or '', *[str(e) for e in x.get('driverErrors') or []], str(x.get('error') or '')])
            m = re.search(r'libcob: error: [^\n]+', text)
            out['aborted'] = (m.group(0) if m else text.strip().split('\n')[0]) or 'run produced no output'
            out['legacy'] = legacy_of(None, plan, inputs, None)
        return out

    def expected(pc, legacy, o=None):
        if not API:
            return None
        e = expected_for(API, pc, legacy, OUT, OCCURS)
        if o is not None and o.get('checks'):
            e['tables'] = [{'name': plan['tables'][c]['table'], 'query': check_sql(plan['tables'][c]),
                            'columns': list(plan['tables'][c]['columns']), 'rows': o['typed'].get(c, []),
                            'compare': compare_of(plan['tables'][c])} for c in o['checks']]
        return e

    def outcome_change(was, now, sql_changed=False):
        """'same', 'checks' (the same outcome, but other table checks or check SQL than recorded) or 'differs'."""
        def checks(l):
            return sorted((l.get('verify') or {}).keys())
        if checks(was) == checks(now) and not sql_changed:
            return 'same' if same_outcome(was, now, plan) else 'differs'

        def bare(l):
            return {k: v for k, v in l.items() if k != 'verify'}
        return 'checks' if same_outcome(bare(was), bare(now), plan) else 'differs'

    def meta(pc, where):
        m = {'origin': pc.get('origin')}
        if pc.get('origin') not in ORIGINS:
            errors.append(f"{where}: origin {pc.get('origin')!r} not in {'/'.join(ORIGINS)}")
        if pc.get('ruleIds'):
            for r in pc['ruleIds']:
                if r not in RULES:
                    errors.append(f'{where}: ruleId {r} is not a rule of design/rules.md (R<n> = rule n)')
            m['ruleIds'] = list(pc['ruleIds'])
        cmp = [*(plan.get('compare') or []), *(pc.get('compare') or [])]
        errors.extend(compare_errors(cmp, where))
        if cmp:
            m['compare'] = cmp
        for k in pc.get('suppressRules') or []:
            if k not in DECISIONS:
                errors.append(f'{where}: suppressRules names {k}, which is no decision of the plan')
        if pc.get('origin') == 'basic' and pc.get('design') is not None:
            m['design'] = {k: (pc['design'] or {}).get(k) for k in DESIGN_KEYS}
        elif pc.get('design') is not None:
            errors.append(f'{where}: only a basic case carries a design block (import_unit writes it)')
        return m

    def brief(legacy, typed=None):
        if not legacy or not legacy.get(RUN):
            return ''
        sc = ' '.join(f"{k}={str(legacy.get(k, '')).strip()}" for k in OUT if field_of(OUT[k]))
        ls = ' '.join(f'{k}:{len(legacy.get(k) or [])}' for k in OUT if is_list(OUT[k]))
        tb = ' '.join(f'{c}:{len(rows)}' for c, rows in (typed or {}).items())
        return ' | '.join(x for x in (sc, ls, f'rows {tb}' if tb else '') if x)

    # ------------------------------------------------------------ the cases
    REMOVED = plan.get('removed') or {}
    plan_cases = plan.get('cases') or []
    bad = [str(pc.get('name')) for pc in plan_cases if not CASE_NAME.match(str(pc.get('name') or ''))]
    if bad:
        raise Stop('case names must be kebab-case (^[a-z0-9]+(-[a-z0-9]+)*$)', errors=bad)
    plan_by_name = {}
    for pc in plan_cases:
        if pc.get('name') in plan_by_name:
            errors.append(f"plan: case name {pc.get('name')} twice")
        plan_by_name[pc.get('name')] = pc
    base_by_name = {c['name']: c for c in old.get('cases') or []}
    for rn, r in REMOVED.items():
        if not r.get('id') or not r.get('reason'):
            errors.append(f'removed {rn}: id and reason are required')
        elif rn in base_by_name and base_by_name[rn]['id'] != r['id']:
            errors.append(f"removed {rn}: the base suite has it as {base_by_name[rn]['id']}, not {r['id']}")
        if rn in plan_by_name:
            errors.append(f'plan case {rn}: the name of a removed case is never reused')
    for name, c in base_by_name.items():
        if name not in plan_by_name and name not in REMOVED:
            errors.append(f"base case {c['id']} {name} is not in the plan: keep it there, or drop it through plan.removed")
    if errors:
        raise Stop('the plan does not fit the base suite', errors=errors)

    def sig(inputs, clock, fixture, request):
        return dumps([inputs, clock, fixture, [request.get('method'), request.get('url'), request.get('body'),
                                               request.get('principal')] if request else None])

    seen = {}
    prefix = plan.get('idPrefix') or ''
    used = [int(re.sub(r'\D', '', str(x['id']).replace(prefix, '', 1)) or 0)
            for x in [*(old.get('cases') or []), *REMOVED.values()]]
    next_id = [max([0, *used])]
    added, out_cases = [], []
    runs_of = {}            # case name -> run record coverage (for coverage.py)
    key_of_run = {}         # case name -> its run key (build.json runs)
    label_of = {}           # case name -> its run label
    is_base = set()

    def new_id():
        next_id[0] += 1
        return f'{prefix}{next_id[0]:03d}'

    def restored(bc):
        """A base case as its recording gave it: a decided answer is derived again on every build."""
        c = copy(bc)
        da = c.pop('decidedAnswer', None)
        if da and 'recorded' in da:
            c['expected'] = da['recorded']
        return c

    order = [c['name'] for c in old.get('cases') or []] + [pc['name'] for pc in plan_cases if pc['name'] not in base_by_name]
    for name in order:
        if name in REMOVED:
            removed.append(f"{REMOVED[name]['id']} {name}: {REMOVED[name]['reason']}")
            continue
        pc = plan_by_name[name]
        bc = restored(base_by_name[name]) if name in base_by_name else None
        where = f'case {name}'
        if pc.get('category') not in CATEGORIES:
            errors.append(f"{where}: category {pc.get('category')!r} not in {'/'.join(CATEGORIES)}")
        if not pc.get('about'):
            errors.append(f'{where}: about is required')
        for k in pc.get('params') or {}:
            if k not in (plan.get('inputMap') or {}):
                errors.append(f"{where}: param {k} is not in the plan's inputMap")
        nr = pc.get('status') == 'not-representable'
        if pc.get('status') and not nr:
            errors.append(f'{where}: a plan may only set status not-representable')
        if nr and not pc.get('reason'):
            errors.append(f'{where}: not-representable needs a reason')
        if pc.get('extraInputs') and not nr:
            errors.append(f'{where}: extraInputs have no API field, so the case must be not-representable')
        clock = pc.get('clock') or D.get('clock')
        fixture = pc.get('fixture') or D.get('fixture')
        inputs = plan_inputs(plan, pc, fields['inputs'], clock)
        checks = checks_of(plan, pc)
        request, problem = (None, None) if nr or not API else request_for(API, pc)
        if problem:
            errors.append(f'{where}: no request can mean it ({problem}): mark it not-representable with that reason')
            continue
        s = sig(inputs, clock, fixture, request)
        if s in seen:
            errors.append(f'{where}: same COBOL inputs, clock, fixture and API request as {seen[s]}')
            continue
        seen[s] = name
        cid = bc['id'] if bc else new_id()
        who = f'{cid} {name}'
        if bc:
            is_base.add(name)
            if dumps(inputs) != dumps([[f, v] for f, v in (bc.get('legacy') or {}).get(IN, {}).items()]):
                errors.append(f'{where}: its inputs differ from the base case {cid}: give it a new name')
            if fixture != bc.get('fixture'):
                errors.append(f"{where}: fixture {fixture}, but the base case was recorded on {bc.get('fixture')}: change "
                              'the rows of that fixture instead')
        base = {'id': cid, 'name': name, 'category': pc.get('category'), 'about': pc.get('about'), **meta(pc, where)}
        label = f'suite:{name}' if bc else f'plan:{name}'
        label_of[name] = label
        kept = {**{k: bc[k] for k in KEYS if k in bc and k not in PLAN_FIELDS}, **base} if bc else None

        if bc and label in carried_fp:
            # Recorded on today's fingerprint (record.py): a run could only reproduce it.
            if (bc.get('recording') or {}).get('fingerprint') != carried_fp[label]:
                errors.append(f'{who}: carried forward on {carried_fp[label]}, but recorded on '
                              f"{(bc.get('recording') or {}).get('fingerprint')} -- re-run record.py")
            if checks_changed(plan, bc, checks):
                errors.append(f"{who}: carried forward, but its check SQL changed "
                              f"({', '.join(checks_changed(plan, bc, checks))}) -- re-run record.py")
            if (bc.get('recording') or {}).get('recordedAt', '') > state['newest']:
                state['newest'] = bc['recording']['recordedAt']
            carried.append(who)
            c = kept
            if nr and c.get('status') != 'not-representable':
                notes.append(f"{who}: {c.get('status')} -> not-representable ({pc['reason']})")
                c.update(status='not-representable', reason=pc['reason'], clockSensitive=False, request=None, expected=None,
                         anticipatedJavaDivergence=[], stackDivergence=[])
            if c.get('status') == 'golden':
                key = run_key(inputs, clock, fixture, shims, check_key(plan, checks, tables), carried_fp[label])
                f = p.runs / f'{key}.json'
                if f.is_file():
                    runs_of[name] = read_json(f, 'run').get('coverage')
                    key_of_run[name] = key
                else:
                    c['paragraphs'] = list(base_by_name[name].get('paragraphs') or [])
                    notes.append(f'{who}: carried forward, its run is not in the cache: paragraphs from the base suite, '
                                 'not in the coverage totals (record.py --force to re-run)')
            if c.get('status') == 'golden' and API:
                # The outcome is carried, the binding is today's; the rows are the recorded ones.
                had = bool(bc.get('request'))
                fresh = expected(pc, bc['legacy'])
                if (bc.get('expected') or {}).get('tables'):
                    fresh['tables'] = bc['expected']['tables']
                if not had:
                    bindings.append(f"{who}: bound to {request['method']} {request['url']}")
                elif dumps(request) != dumps(bc.get('request')) or dumps(fresh) != dumps(bc.get('expected')):
                    updates.append(f"{who}: api binding changed -- {(bc.get('request') or {}).get('url')} -> {request['url']}, "
                                   f"expected status {(bc.get('expected') or {}).get('status')} -> {fresh.get('status')}, "
                                   'outcome unchanged (carried forward)')
                c['request'], c['expected'] = request, fresh
            out_cases.append(c)
            continue

        o = outcome(label, inputs, checks)
        rec = {'recording': o['recording']}

        def nr_case(reason):
            return {**base, 'status': 'not-representable', 'reason': reason, 'fixture': fixture, 'clock': clock,
                    'clockSensitive': False, 'request': None, 'expected': None, 'anticipatedJavaDivergence': [],
                    'stackDivergence': [], 'legacy': o['legacy'], **rec}

        def golden_case():
            return {**base, 'status': 'golden', 'fixture': fixture, 'clock': clock, 'clockSensitive': False,
                    'request': request, 'expected': expected(pc, o['legacy'], o), 'anticipatedJavaDivergence': [],
                    'stackDivergence': [], 'legacy': o['legacy'], **rec}

        if bc:
            st = bc.get('status')
            if nr:
                if st != 'not-representable':
                    notes.append(f"{who}: {st} -> not-representable ({pc['reason']})")
                c = nr_case(pc['reason'])
            elif not o['repeatable']:
                msg = (f"{who}: not repeatable -- {o['recording']['repeats']} runs on unchanged inputs gave different "
                       f"outcomes ({', '.join(str(x) for x in o['recording']['runIds'])})")
                (regressions if st == 'golden' else notes).append(msg)
                c = kept
            elif o.get('aborted'):
                c = kept
                if st == 'golden':
                    regressions.append(f"{who}: golden, now aborts: {o['aborted']}")
                elif st == 'not-recorded':
                    c.update(reason=o['aborted'], legacy=o['legacy'], **rec)
            elif st == 'golden':
                now = o['legacy']
                sql = checks_changed(plan, bc, checks)
                change = outcome_change(bc['legacy'], now, bool(sql))
                c = kept
                if change == 'checks':
                    updates.append(f"{who}: table checks {sorted((bc['legacy'].get('verify') or {}))} -> "
                                   f"{sorted((now.get('verify') or {}))}"
                                   + (f" (check SQL changed: {', '.join(sql)})" if sql else '') + ', outcome otherwise unchanged')
                elif change == 'differs':
                    fp_before = (old.get('recordings') or {}).get((bc.get('recording') or {}).get('fingerprint')) or {}
                    seeded = (fp_before.get('fixture') or {}).get('sha256') != o['fixtureSha']
                    if seeded or new_contract:
                        updates.append(f"{who}: {'fixture' if seeded else 'contract'} changed -- was "
                                       f"{brief(bc['legacy']) or '(no outcome)'}; now {brief(now, o['typed'])}")
                    else:
                        regressions.append(f"{who}: recorded outcome differs from today's run")
                        if not a.accept_regressions:
                            out_cases.append(kept)
                            continue
                fresh = expected(pc, now, o)
                if change == 'same' and bc.get('expected') and dumps(fresh) != dumps(bc.get('expected')):
                    updates.append(f"{who}: api binding changed -- expected status {bc['expected'].get('status')} -> "
                                   f"{(fresh or {}).get('status')}, outcome unchanged")
                if API and not bc.get('request'):
                    bindings.append(f"{who}: bound to {request['method']} {request['url']}")
                c.update(request=request, expected=fresh, legacy=now, **rec)
                runs_of[name] = o.get('coverage')
            elif st == 'not-recorded':
                promotions.append(f"{who}: not-recorded -> golden ({bc.get('reason') or 'no reason recorded'} no longer happens)")
                c = golden_case()
                runs_of[name] = o.get('coverage')
            else:
                # not-representable before, the plan no longer says so
                why = padded_variant(API, plan, pc, types)
                if why:
                    c = nr_case(why)
                else:
                    promotions.append(f"{who}: not-representable -> golden (the plan no longer marks it)")
                    c = golden_case()
                    runs_of[name] = o.get('coverage')
            out_cases.append(c)
            continue

        if nr:
            c = nr_case(pc['reason'])
        elif not o['repeatable']:
            c = {**base, 'status': 'not-recorded',
                 'reason': f"not repeatable: {o['recording']['repeats']} runs on unchanged inputs gave different outcomes",
                 'fixture': fixture, 'clock': clock, 'clockSensitive': False, 'request': request, 'expected': None,
                 'anticipatedJavaDivergence': [], 'stackDivergence': [], 'legacy': legacy_of(None, plan, inputs, None), **rec}
        elif o.get('aborted'):
            c = {**base, 'status': 'not-recorded', 'reason': o['aborted'], 'fixture': fixture, 'clock': clock,
                 'clockSensitive': False, 'request': request, 'expected': None, 'anticipatedJavaDivergence': [],
                 'stackDivergence': [], 'legacy': o['legacy'], **rec}
        else:
            c = golden_case()
            runs_of[name] = o.get('coverage')
        added.append(c)
        out_cases.append(c)
    if errors:
        raise Stop('the build found errors', errors=errors)

    # ------------------------------------------------------------ derived, for every golden case
    # The same rules for a base case and a new one, on every build: unspellable enum variants, the
    # probe clock, the decisions (notes, compare, decided answers).
    for c in out_cases:
        c.setdefault('stackDivergence', [])
        c.setdefault('anticipatedJavaDivergence', [])
        if c.get('status') != 'golden' or not (c.get('legacy') or {}).get(IN):
            continue
        name = c['name']
        pc = plan_by_name[name]
        who = f"{c['id']} {name}"
        why = padded_variant(API, plan, pc, types)
        if why:
            for k in ('request', 'expected'):
                c[k] = None
            for k in ('compare', 'decidedAnswer'):
                c.pop(k, None)
            c.update(status='not-representable', reason=why, clockSensitive=False, anticipatedJavaDivergence=[],
                     stackDivergence=[])
            runs_of.pop(name, None)
            unspellable.append(f'{who}: {why}')
            continue
        pclock = probe_clock(plan, c.get('clock'))
        checks = checks_of(plan, pc)
        try:
            pr = outcome(f"{label_of[name]}@probe", clock_inputs(plan, [[f, v] for f, v in c['legacy'][IN].items()], pclock),
                         checks, probe=True)
        except Stop as e:
            errors.append(f'{who}: no probe run at {pclock} ({e})')
            continue
        measured = bool(pr.get('aborted')) or not same_outcome(c['legacy'], pr['legacy'], plan)
        exp = c.get('expected')
        suppressed = set(pc.get('suppressRules') or [])
        fired = [(k, r) for k, r in DECISIONS.items()
                 if k not in suppressed and fires(str(r['when']), pc, c['legacy'], measured, exp or None, API)]

        def text(r):
            t = str(r['text']).replace('{date}', str(c.get('clock'))[:8], 1)
            src = r.get('source')
            return t if not src or t.startswith(str(src)) else f'{src}: {t}'
        was = list(base_by_name.get(name, {}).get('anticipatedJavaDivergence') or [])
        c['anticipatedJavaDivergence'] = [*[text(r) for _, r in fired if (r.get('kind') or 'java') == 'java'],
                                          *(pc.get('divergence') or [])]
        c['stackDivergence'] = [*[text(r) for _, r in fired if r.get('kind') == 'stack'], *(pc.get('stack') or [])]
        if name in is_base and was != c['anticipatedJavaDivergence']:
            gone = [x for x in was if x not in c['anticipatedJavaDivergence']]
            new = [x for x in c['anticipatedJavaDivergence'] if x not in was]
            notes_changed.append(f'{who}: -{len(gone)} +{len(new)}' + (f' (dropped: {gone[0][:90]}...)' if gone else ''))
        cmp = list(c.get('compare') or [])
        if two_xx_body(exp):
            for _, r in fired:
                cmp += [x for x in r.get('compare') or [] if not any(
                    y.get('path') == x.get('path') and y.get('mode') == x.get('mode') for y in cmp)]
        if cmp:
            c['compare'] = cmp
        else:
            c.pop('compare', None)
        dependent = any(r.get('clockDependent') for _, r in fired)
        c['clockSensitive'] = measured or dependent
        if measured and not dependent:
            clock_gaps.append(f'{who}: differs at the probe clock {pclock}, but no clockDependent decision fires')
        answering = [(k, r) for k, r in fired if r.get('answer') is not None]
        if answering and exp:
            try:
                new, da = decide(answering, exp)
            except Stop as e:
                errors.append(f'{who}: {e}')
                continue
            why = '; '.join(f'{k}: {PENDING[k]}' for k, _ in answering if k in PENDING)
            if why:
                # The source is not decided: the text stays, the recorded answer stays expected.
                c['decidedAnswer'] = {**da, 'pending': True, 'reason': why}
                pending.append(f"{who}: {exp.get('status')} -> {new.get('status')} by {da['source']} not applied ({why})")
                continue
            c['expected'], c['decidedAnswer'] = new, da
            if not two_xx_body(new):
                c.pop('compare', None)
            decided.append(f"{who}: {exp.get('status')} -> {new.get('status')} by {da['source']} (decision "
                           f"{', '.join(da['rules'])}" + (f"; set {len(da['set'])}" if da.get('set') else '')
                           + (f"; tables {da['tables']}" if 'tables' in da else '') + ')')

    # ------------------------------------------------------------ validate
    ids = set()
    for c in out_cases:
        cid = c.get('id')
        if cid in ids:
            errors.append(f'duplicate id {cid}')
        ids.add(cid)
        for k in c:
            if k not in KEYS:
                errors.append(f'{cid}: field {k} is not part of the case structure')
        st = c.get('status')
        if st not in STATUSES:
            errors.append(f'{cid}: status {st}')
        if st == 'golden' and not (c.get('legacy') or {}).get(RUN):
            errors.append(f'{cid}: golden without legacy.{RUN}')
        if st == 'golden' and API and (not c.get('request') or not c.get('expected')):
            errors.append(f'{cid}: golden without request/expected although the plan has an api')
        if st != 'golden' and c.get('expected') is not None:
            errors.append(f'{cid}: {st} must have expected null')
        if st == 'not-representable' and c.get('request') is not None:
            errors.append(f'{cid}: not-representable must have request null')
        for ln, rows in (c.get('legacy') or {}).items():
            if is_list(OUT.get(ln)) and len(rows or []) > OCCURS[ln]:
                errors.append(f'{cid}: list {ln} has {len(rows)} rows, more than its OCCURS {OCCURS[ln]}')
    if errors:
        raise Stop('the build found errors', errors=errors)

    # ------------------------------------------------------------ design expectations (basic cases)
    for c in out_cases:
        if c.get('origin') == 'basic' and c.get('design'):
            op = operation_for(API, plan_by_name[c['name']]) if API else None
            for d in design_mismatches(c, op):
                design_diffs.append(f"{c['id']} {c['name']}: {d}")

    # ------------------------------------------------------------ coverage (coverage.py)
    pindex = read_json(p.paragraph_index, 'paragraph index') if p.paragraph_index.is_file() else {}
    if not pindex:
        notes.append(f'{p.rel(p.paragraph_index)} not found: paragraph coverage is empty')
    used = [c['name'] for c in out_cases if c.get('status') == 'golden' and runs_of.get(c['name']) is not None]
    runs = [{'case': n, 'coverage': runs_of[n]} for n in used]
    run_keys = {n: key_of_run.get(n) or index.get(label_of[n]) for n in used}
    coverage = cov.compute(pindex, runs, p.sources if p.sources.is_dir() else None)
    for c in out_cases:
        if c['name'] in runs_of or 'paragraphs' not in c or c.get('status') != 'golden':
            c['paragraphs'] = list((coverage.get('cases') or {}).get(c['name']) or []) if c.get('status') == 'golden' else []
    write_json(p.tmp / 'coverage.json', coverage)
    if hasattr(cov, 'uncovered_md'):
        write_text(p.tmp / 'uncovered.md', cov.uncovered_md(coverage))

    # ------------------------------------------------------------ the package
    def proven(rid):
        return [c['id'] for c in out_cases if c.get('status') == 'golden' and rid in (c.get('ruleIds') or [])]
    rules = [{'id': rid, 'text': text, 'provenBy': proven(rid)} for rid, text in RULES.items()]
    unproven = [r['id'] for r in rules if not r['provenBy']]
    used_fp = {(c.get('recording') or {}).get('fingerprint') for c in out_cases}
    recordings = {k: v for k, v in sorted({**(old.get('recordings') or {}), **fingerprints}.items()) if k in used_fp}
    schema = dict(OUT)
    if plan.get('tables'):
        schema['tables'] = table_types(plan, tables)
    golden_text = plan.get('goldenMaster') or old.get('goldenMaster') or ''
    if state['newest']:
        golden_text = re.sub(r'recorded [0-9]{4}-[0-9]{2}-[0-9]{2}', f"recorded {state['newest'][:10]}", golden_text, count=1)
    named = sorted({c['fixture'] for c in out_cases if c.get('fixture')} | ({D['fixture']} if D.get('fixture') else set()))
    unknown = unknown_tables(plan, tables, [p.fixtures / fx for fx in named])
    if unknown:
        raise Stop(f"tables not in unit/schema.sql: {', '.join(unknown)}")
    RESET = reset_tables(tables)  # the list record.py empties before every run, in its order
    body = {'unit': p.entry, 'api': header.get('api', old.get('api', '')),
            'binding': published(API) if API else None, 'goldenMaster': golden_text,
            'comparison': COMPARISON_TEXT, 'comparisonRules': COMPARISON_RULES, 'resetTables': RESET,
            'statuses': {**STATUS_TEXTS, **(header.get('statuses') or old.get('statuses') or {})}, 'legacySchema': schema, 'rules': rules,
            'coverage': coverage, 'recordings': recordings, 'cases': [{k: c[k] for k in KEYS if k in c} for c in out_cases]}
    chash = content_hash(body)
    prev = old.get('package') or {}
    version = prev.get('version') if prev.get('contentHash') == chash else (prev.get('version') or 0) + 1
    suite = {'package': {'schema': SCHEMA_ID, 'format': FORMAT, 'version': version, 'contentHash': chash,
                         'generator': generator(p), 'inputs': p.inputs()}, **body}

    def by(k):
        m = {}
        for c in out_cases:
            m[str(c.get(k))] = m.get(str(c.get(k)), 0) + 1
        return m
    db_rows = {n: [0, 0, 0] for n in plan.get('tables') or {}}
    for c in out_cases:
        if c.get('status') == 'golden':
            for n, rows in ((c.get('legacy') or {}).get('verify') or {}).items():
                if n in db_rows:
                    db_rows[n][0 if rows else 1] += 1
                    db_rows[n][2] += len(rows)
    tot = coverage.get('totals') or {}
    tp, tl = tot.get('paragraphs') or {}, tot.get('lines') or {}
    report = [
        f'# tests build -- {p.entry}', '',
        f'cases: {len(out_cases)} (base {len(base_by_name)}, carried forward {len(carried)}, removed {len(removed)}, '
        f'added {len(added)})', f'base: {p.rel(p.previous / p.suite.name) if (p.previous / p.suite.name).is_file() else "none"}',
        f"status: {dumps(by('status'))}", f"origin: {dumps(by('origin'))}", f"category: {dumps(by('category'))}", '',
        f'## Regressions ({len(regressions)})', *[f'- {x}' for x in regressions], '',
        f'## Updated by a fixture or contract change ({len(updates)})', *[f'- {x}' for x in updates], '',
        f'## Carried forward ({len(carried)})',
        *([f"- not run: each was recorded on today's fingerprint: {carried[0]} .. {carried[-1]}"] if carried else []), '',
        f'## Removed ({len(removed)})', *[f'- {x}' for x in removed], '',
        f'## Promotions ({len(promotions)})', *[f'- {x}' for x in promotions], '',
        f'## Notes ({len(notes)})', *[f'- {x}' for x in notes], '',
        f'## Not representable: the API cannot spell what the COBOL saw ({len(unspellable)})',
        *[f'- {x}' for x in unspellable], '',
        f'## Decided answers ({len(decided)})',
        '- the expected answer comes from the decision; the recorded answer stays in legacy and decidedAnswer.recorded',
        *([f'- {x}' for x in decided] or ['(none)']), '',
        f'## Pending decisions ({len(pending)})',
        '- a decided answer whose source is not answered or settled: expected stays the recorded answer, '
        'decidedAnswer.pending; settle the source, rebuild',
        *([f'- {x}' for x in pending] or ['(none)']), '',
        f'## Clock: dependent without a rule ({len(clock_gaps)})',
        *([f'- {x}' for x in clock_gaps] or ['(none: every case the probe clock shows as clock-dependent has a '
                                              'clockDependent decision)']), '',
        f'## Divergence notes changed on base cases ({len(notes_changed)})', *[f'- {x}' for x in notes_changed], '',
        f'## Design expectations differ ({len(design_diffs)})',
        '- basic cases whose binding (method, path) or expected status is not what design/tests.md says: each one a PQ question',
        *([f'- {x}' for x in design_diffs] or ['(none)']), '',
        '## Package header', f"- binding: {'published' if API else 'none (COBOL-only baseline)'}",
        f"- resetTables: {', '.join(RESET) or '(none)'}",
        f"- cases with compare ignore: {sum(1 for c in out_cases if any(x.get('mode') == 'ignore' for x in c.get('compare') or []))}",
        f"- cases with stackDivergence: {sum(1 for c in out_cases if c.get('stackDivergence'))}",
        f"- clockSensitive golden cases: {sum(1 for c in out_cases if c.get('status') == 'golden' and c.get('clockSensitive'))}", '',
        f'## API bindings ({len(bindings)})', *[f'- {x}' for x in bindings], '',
        f"## Database after the call ({len(db_rows)} table checks)",
        *[f"- {n} ({plan['tables'][n]['table']}): {v[0]} golden cases leave rows, {v[1]} leave none, {v[2]} rows in all"
          for n, v in db_rows.items()], '',
        f"## Rules of design/rules.md no golden case proves ({len(unproven)})", ', '.join(unproven) or '(none)', '',
        '## Added', '| id | origin | status | name | outcome | technical failure / reason |', '|---|---|---|---|---|---|',
        *[f"| {c['id']} | {c.get('origin')} | {c['status']} | {c['name']} | {brief(c['legacy']).replace('|', '/')} | "
          f"{'/'.join(str(v).strip() for v in (c['legacy'].get('technicalFailure') or {}).values()) or c.get('reason', '')} |"
          for c in added], '',
        '## Coverage (business paragraphs; details: coverage.json, uncovered.md)',
        f"paragraphs {tp.get('covered', 0)}/{tp.get('total', 0)} covered, lines {tl.get('covered', 0)}/{tl.get('code', 0)}"
        f"{' (estimated)' if tot.get('estimated') else ''}; programs never entered: "
        f"{', '.join(coverage.get('notEntered') or []) or '(none)'}",
        *[f'- warning: {w}' for w in coverage.get('warnings') or []], '',
        '## Package',
        f"format {FORMAT} · version {version} · contentHash {chash[:16]} · fingerprints {', '.join(recordings) or '(none)'}"
        f" · rules {len(rules)}", '']
    write_text(p.tmp / 'build-report.md', '\n'.join(report))

    target = p.tmp / p.suite.name
    accept = bool(a.accept_regressions)
    summary = {'entry': p.entry, 'cases': len(out_cases), 'added': len(added), 'carried': len(carried),
               'removed': len(removed), 'updated': updates, 'regressions': regressions, 'promotions': promotions,
               'bindings': len(bindings), 'notes': notes, 'byStatus': by('status'), 'byOrigin': by('origin'),
               'decided': decided, 'pendingDecisions': pending, 'clockGaps': clock_gaps, 'unspellable': unspellable, 'designDiffs': design_diffs,
               'unprovenRules': unproven, 'coverage': {'paragraphs': tp, 'lines': tl}, 'runs': run_keys,
               'version': version, 'contentHash': chash, 'report': p.rel(p.tmp / 'build-report.md'), 'installed': False}
    was = p.tmp / 'build.json'
    summary['installedAt'] = (read_json(was, 'build.json') if was.is_file() else {}).get('installedAt')
    if a.install:
        if regressions and not accept:
            summary.update(status='regressions', error='refusing to install with regressions -- see build-report.md')
            write_json(p.tmp / 'build.json', summary)
            write_json(target, suite)
            summary['suite'] = p.rel(target)
            return 2, summary
        if p.suite.is_file() and not (p.previous / p.suite.name).is_file():
            raise Stop(f'{p.rel(p.suite)} has no copy in {p.rel(p.previous)}: run rotate.py first')
        target = p.suite
        p.package.mkdir(parents=True, exist_ok=True)
        named = sorted({c['fixture'] for c in out_cases if c.get('fixture')})
        for fx in named:
            shutil.copyfile(p.fixtures / fx, p.package / fx)
        for f in p.package.glob('*.sql'):
            if f.name not in named:
                f.unlink()
        summary['installed'] = True
        summary['installedAt'] = iso_now()
    write_json(target, suite)
    summary['suite'] = p.rel(target)
    code = 2 if regressions and not accept else 0
    summary['status'] = 'regressions' if code == 2 else 'built'
    write_json(p.tmp / 'build.json', summary)
    return code, summary


if __name__ == '__main__':
    main(run)
