#!/usr/bin/env python3
"""tests/tests-open-questions.md: the PQ-n entries of the command (design convention plus `Blocking:`).

    python -B questions.py <mu> [--entry E] [list]
    python -B questions.py <mu> [--entry E] add --title T --question Q --decision D [--affects A]
                                [--step S] [--blocking yes|no]

Entry format:
    ## PQ-<n> - <title>

    Step: <step> · Status: open | answered | settled
    Blocking: yes | no
    Question: <...>
    Decision taken: <...>
    Affects: <rules, cases>
    Answer: <filled by the user; the next run applies it>

A line that starts no known label continues the field above it. An Answer that is empty or a
`<...>` placeholder is not filled. Importable: parse(path, prefix='PQ') (prefix OQ: design's
design-open-questions.md, same format without `Blocking:`), answered(entries), settled(entries),
decided(entries), open_blocking(entries), next_id(entries), append(path, entry). append() only ever adds text at the
end of the file; existing entries are never rewritten.
"""

import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True

from btlib import Paths, Stop, main, parser, read_text  # noqa: E402

HEADER = ('# tests-open-questions.md\n\n'
          'An entry only where the design is silent and the wrong reading changes a case. '
          '`Blocking: yes` holds the package at needs-answers until the Answer is filled.\n')
_HEAD = re.compile(r'^##\s+(OQ|PQ)-([0-9]+)\s*(?:[-–—]\s*(.*))?$')
_FIELDS = {'Question': 'question', 'Decision taken': 'decision', 'Affects': 'affects', 'Answer': 'answer',
           'Blocking': 'blocking'}
_LABEL = re.compile(r'^(Question|Decision taken|Affects|Answer|Blocking):\s*(.*)$')
_STEP = re.compile(r'^Step:\s*(.*?)\s*(?:[·|]\s*Status:\s*(.*))?$')
_STATUS = re.compile(r'^Status:\s*(.*)$')
STATUSES = ('open', 'answered', 'settled')


def _filled(text):
    t = (text or '').strip()
    return bool(t) and not re.fullmatch(r'<[^>]*>', t)


def parse(path, prefix='PQ'):
    """[{id, n, title, step, status, blocking (bool), question, decision, affects, answer, answered (bool)}]
    of the `## <prefix>-<n>` entries."""
    path = Path(path)
    if not path.is_file():
        return []
    out, cur, key = [], None, None
    for line in read_text(path).splitlines():
        m = _HEAD.match(line.strip())
        if m and m.group(1) == prefix:
            cur = {'id': f'{prefix}-{m.group(2)}', 'n': int(m.group(2)), 'title': (m.group(3) or '').strip(), 'step': '',
                   'status': '', 'blocking': '', 'question': '', 'decision': '', 'affects': '', 'answer': ''}
            out.append(cur)
            key = None
            continue
        if cur is None:
            continue
        if line.startswith('#'):            # another heading ends the entry
            cur, key = None, None
            continue
        s = line.strip()
        if not s:
            key = None
            continue
        m = _STEP.match(s)
        if m:
            cur['step'] = m.group(1).strip()
            if m.group(2) is not None:
                cur['status'] = m.group(2).strip()
            key = None
            continue
        m = _STATUS.match(s)
        if m:
            cur['status'] = m.group(1).strip()
            key = None
            continue
        m = _LABEL.match(s)
        if m:
            key = _FIELDS[m.group(1)]
            cur[key] = m.group(2).strip()
            continue
        if key:
            cur[key] = (cur[key] + '\n' + s).strip()
    for e in out:
        st = e['status'].lower()
        e['status'] = next((x for x in STATUSES if st == x), st if st and '|' not in st else 'open')
        e['blocking'] = e['blocking'].strip().lower().startswith('y')
        e['answered'] = _filled(e['answer'])
        if not e['answered']:
            e['answer'] = ''
    return out


def answered(entries):
    """Entries whose Answer is filled and that are not settled yet: the run applies them."""
    return [e for e in entries if e['answered'] and e['status'] != 'settled']


def settled(entries):
    return [e for e in entries if e['status'] == 'settled']


def decided(entries):
    """Entries a decision may rest on: Answer filled, or status answered or settled."""
    return [e for e in entries if e['answered'] or e['status'] in ('answered', 'settled')]


def open_blocking(entries):
    """Blocking entries with no Answer that are not settled."""
    return [e for e in entries if e['blocking'] and not e['answered'] and e['status'] != 'settled']


def open_entries(entries):
    return [e for e in entries if not e['answered'] and e['status'] != 'settled']


def next_id(entries):
    return f"PQ-{max([e['n'] for e in entries] or [0]) + 1}"


def _one_line(v):
    return re.sub(r'\s*\n\s*', ' ', str(v or '')).strip()


def append(path, entry):
    """Append one entry (dict: title, question, decision; optional step, status, blocking, affects,
    answer, id). Returns the id. Text is only ever added at the end of the file."""
    path = Path(path)
    entries = parse(path)
    eid = entry.get('id') or next_id(entries)
    if not re.fullmatch(r'PQ-[0-9]+', eid):
        raise Stop(f'bad question id {eid}')
    if any(e['id'] == eid for e in entries):
        raise Stop(f'{eid} already exists in {path}')
    for k in ('title', 'question', 'decision'):
        if not _one_line(entry.get(k)):
            raise Stop(f'a question needs {k}')
    status = entry.get('status') or 'open'
    if status not in STATUSES:
        raise Stop(f'status {status} is not one of {STATUSES}')
    blocking = entry.get('blocking')
    blocking = 'yes' if blocking in (True, 'yes', 'y', 'true') else 'no'
    text = (f"## {eid} - {_one_line(entry['title'])}\n\n"
            f"Step: {_one_line(entry.get('step')) or '-'} · Status: {status}\n"
            f"Blocking: {blocking}\n"
            f"Question: {_one_line(entry['question'])}\n"
            f"Decision taken: {_one_line(entry['decision'])}\n"
            f"Affects: {_one_line(entry.get('affects')) or '-'}\n"
            f"Answer: {_one_line(entry.get('answer'))}\n")
    path.parent.mkdir(parents=True, exist_ok=True)
    existing = read_text(path) if path.is_file() else ''
    with open(path, 'a', encoding='utf-8', newline='\n') as fh:
        if not existing:
            fh.write(HEADER)
            existing = HEADER
        if not existing.endswith('\n'):
            fh.write('\n')
        fh.write('\n' + text)
    return eid


def summary(entries):
    return {'total': len(entries), 'open': [e['id'] for e in open_entries(entries)],
            'blocking': [e['id'] for e in open_blocking(entries)], 'answered': [e['id'] for e in answered(entries)],
            'settled': [e['id'] for e in settled(entries)]}


def run():
    ap = parser('List or append the PQ entries of tests/tests-open-questions.md.')
    ap.add_argument('action', nargs='?', default='list', choices=['list', 'add'])
    ap.add_argument('--title')
    ap.add_argument('--question')
    ap.add_argument('--decision')
    ap.add_argument('--affects')
    ap.add_argument('--step')
    ap.add_argument('--blocking', choices=['yes', 'no'], default='no')
    a = ap.parse_args()
    p = Paths(a.mu, a.entry)
    if a.action == 'add':
        eid = append(p.questions, {'title': a.title, 'question': a.question, 'decision': a.decision,
                                   'affects': a.affects, 'step': a.step, 'blocking': a.blocking})
        return {'added': eid, 'file': p.rel(p.questions), **summary(parse(p.questions))}
    entries = parse(p.questions)
    return {'file': p.rel(p.questions), **summary(entries), 'entries': entries}


if __name__ == '__main__':
    main(run)
