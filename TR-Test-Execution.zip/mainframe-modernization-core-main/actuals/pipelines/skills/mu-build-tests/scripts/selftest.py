#!/usr/bin/env python3
"""Offline self-test of the scripts: a small MU, a stand-in for run_cobol.py, the whole cycle.

    python -B selftest.py [--keep DIR]

Needs no runner, no Db2. Builds a workspace in a temporary folder (or DIR, kept), then runs
import_unit (gaps, exit 2) -> record -> build -> build --install -> rotate (once per run id) ->
record (carried forward) -> build, a changed program (regression, exit 2) and a changed fixture
(updated, exit 0), db.py against the stand-in, and checks the package against what format 3 and
the mu-build-tests additions promise. stdout: one JSON object; exit 0 when every check holds.
"""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
E = 'E000001'

STAND_IN = r'''
"""Stand-in for run_cobol.py: the same CLI and db2_run, a made-up program behind it."""
import argparse, json, os, sys
from pathlib import Path

def container_cli():
    return 'docker'

def db2_run(sql, quiet=True, stop=False, allowed=()):
    return True, ''

def refuse_script(sql):
    return None

def outcome(inputs, clock, fixture):
    mode = os.environ.get('BT_FAKE_MODE', 'normal')
    cmd = inputs.get('CMD', '')
    out = {'ERROR-ENCOUNTERED-SW': ' ', 'LAST-STATUS': '  ', 'CUR-AB-NAME': 'E000001 '}
    rows, cover = {'evt': [], 'lines': []}, [[3, 4]]
    if cmd == 'ABEND':
        return None, rows, cover
    if cmd == 'ADD':
        if 'nouser' in (fixture or ''):
            out.update({'RESP-CODE-S-0004': '1', 'NBR-0005': '      '})
        else:
            nbr = 'N' + clock[8:13]
            amt = '11.50' if mode == 'changed' else '10.50'
            if 'edited' in Path(fixture).read_text():
                amt = '12.50'
            out.update({'RESP-CODE-S-0004': '0', 'NBR-0005': nbr})
            rows['evt'] = [{'NBR': nbr, 'USER_ID': inputs.get('USER-ID-0001', '').ljust(4), 'AMT': amt, 'PROC_DT': '2024-08-16'}]
            n = int(inputs.get('CNT-0002MA', '0') or 0)
            rows['lines'] = [{'NBR': nbr, 'SEQ': i, 'AMT': inputs.get(f'ITEM-AMT-0003({i})', '0')} for i in range(1, n + 1)]
    elif cmd == 'DEL':
        # the server date (a clock-derived input) decides: after 2024 the event is too old to delete
        late = inputs.get('SRV-DATE', '')[:4] > '2024'
        out.update({'RESP-CODE-S-0004': '1' if late else '0', 'NBR-0005': '      '})
        cover = [[5, 5]]
    elif cmd == 'SHOW':
        out.update({'RESP-CODE-S-0004': '0', 'NBR-0005': '      '})
        cover = [[5, 5]]
    else:
        out.update({'RESP-CODE-S-0004': '9999', 'NBR-0005': '      '})
        cover = [[6, 6]]
    return out, rows, cover


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('unit_dir'); ap.add_argument('--cases'); ap.add_argument('--out'); ap.add_argument('--runner')
    ap.add_argument('--all', action='store_true'); ap.add_argument('--no-sql', action='store_true')
    a = ap.parse_args()
    cfg = json.loads(Path(a.cases).read_text(encoding='utf-8'))
    db2 = cfg.get('db2') or {}
    if 'dsn' in db2 or db2.get('schema') != os.environ.get('RUN_COBOL_DB2_SCHEMA'):
        print('stand-in: the db2 block must carry the schema and no dsn', file=sys.stderr)
        return 3
    for case in cfg['cases']:
        inputs = {f: v for f, v in case['inputs']} if isinstance(case['inputs'], list) else dict(case['inputs'])
        clock = case.get('env', {}).get('CAGENSHIM_CLOCK', '20240816103000')
        out, rows, cover = outcome(inputs, clock, case.get('fixture'))
        verify = {}
        for label in case.get('verify') or {}:
            check = label.split('#')[0]
            if label.endswith('#typed'):
                lines = [json.dumps({k: (float(v) if k == 'AMT' else v) for k, v in r.items()}) for r in rows[check]]
            else:
                lines = ['  '.join(str(v) for v in r.values()) for r in rows[check]]
            verify[label] = {'ok': True, 'rows': lines}
        cov = {'programs': [{'program': 'E000001', 'source': 'E000001.CBL', 'entered': True, 'executed': cover,
                             'instrumentedLines': 4}]}
        if out is None:
            result = {'runId': 'r-abend', 'ok': False, 'outputs': [], 'run': {'stderr': 'libcob: error: boom (E000001)'},
                      'coverage': cov}
        else:
            result = {'runId': f"r-{abs(hash(json.dumps(case['inputs']))) % 10000}", 'ok': True,
                      'outputs': [{'field': k, 'occurrence': None, 'value': v} for k, v in out.items()], 'coverage': cov}
        Path(a.out, case['name'] + '.json').write_text(json.dumps({'case': case, 'fixture': {'ok': True, 'output': ''},
                                                                   'verify': verify, 'result': result}), encoding='utf-8')
    return 0

if __name__ == '__main__':
    sys.exit(main())
'''

SCHEMA_YAML = '''unit: E000001
inputs:
  - name: CMD
    type: "X(8)"
  - name: USER-ID-0001
    type: "X(4)"
  - name: AMT-0001
    type: "9(9)V99"
  - name: NBR-0001
    type: "X(6)"
  - name: CNT-0002MA
    type: "9(3)"
  - name: ITEM-AMT-0003
    type: "9(9)V99 OCCURS 3"
  - name: KIND-0001
    type: "X(4)"
  - name: SRV-DATE
    type: "X(8)"
outputs:
  - name: RESP-CODE-S-0004
    type: "9(4)"
  - name: NBR-0005
    type: "X(6)"
  - name: ERROR-ENCOUNTERED-SW
    type: "X"
'''

DDL = '''CREATE TABLE USERS (
	USER_ID CHAR(4) NOT NULL,
	CONSTRAINT USERS_PK PRIMARY KEY (USER_ID)
);
CREATE TABLE EVT (
	NBR CHAR(6) NOT NULL,
	USER_ID CHAR(4),
	AMT DECIMAL(11,2),
	PROC_DT DATE,
	CONSTRAINT EVT_PK PRIMARY KEY (NBR),
	CONSTRAINT EVT_FK FOREIGN KEY (USER_ID) REFERENCES USERS(USER_ID) ON DELETE RESTRICT
);
CREATE TABLE LINES (
	NBR CHAR(6) NOT NULL,
	SEQ SMALLINT NOT NULL,
	AMT DECIMAL(11,2),
	CONSTRAINT LINES_FK FOREIGN KEY (NBR) REFERENCES EVT(NBR) ON DELETE CASCADE
);
'''

COBOL = '\n'.join(['       IDENTIFICATION DIVISION.', '       PROGRAM-ID. E000001.', '       PROCEDURE DIVISION.',
                   '           MOVE 1 TO X.', '           MOVE 2 TO Y.', '           MOVE 3 TO Z.', '           GOBACK.']) + '\n'

INDEX = {'programs': {E: {'paragraphs': [
    {'name': 'P-ADD', 'lines': [3, 4], 'kind': 'business', 'statements': 2},
    {'name': 'P-DEL', 'lines': [5, 5], 'kind': 'business', 'statements': 1},
    {'name': 'P-OTHER', 'lines': [6, 6], 'kind': 'business', 'statements': 1},
    {'name': 'P-EXIT', 'lines': [7, 7], 'kind': 'mechanism', 'statements': 1}]}}}

TESTS_MD = '''# tests.md

## The standard request body

Text without labelled lines: not a case.

# E000001

## add-ok

Add with two items.

Request: POST /evt
  {"userId": "U1", "amount": 10.50}

Expected outcome: 201

Expected rows: one EVT row, two LINES rows.

Rules: 1
Not asserted: -
Does not verify: the order of the inserts.

## add-nouser

Request: POST /evt for U1 without a user row
Expected outcome: 404
Expected rows: none
Rules: 1, 2 (the delete side)
Not asserted: -
Does not verify: -

## delete-ok

Request: DELETE /evt/{number}
Expected outcome: 204, no body.
Expected rows: none
Rules: 2
Not asserted: -
Does not verify: -

## bad-cmd

Request: none
Expected outcome: no endpoint.
Expected rows: -
Rules: -
Not asserted: -
Does not verify: -

## orphan-case

Request: GET /nothing
Expected outcome: 200
Rules: 2
'''


def unit_cases():
    add = [['CMD', 'ADD'], ['USER-ID-0001', 'U1'], ['AMT-0001', '10.50'], ['CNT-0002MA', '2'],
           ['ITEM-AMT-0003(1)', '1.00'], ['ITEM-AMT-0003(2)', '2.00']]
    return {'unit': E, 'cases': [
        {'name': 'add-ok', 'about': 'add with two items', 'fixture': 'fixtures/user.sql', 'inputs': add,
         'verify': {'evt': 'select * from EVT'}},
        {'name': 'add-nouser', 'about': 'add for an unknown user', 'fixture': 'fixtures/nouser.sql', 'inputs': add[:3]},
        {'name': 'delete-ok', 'about': 'delete an event', 'fixture': 'fixtures/evt.sql',
         'inputs': {'CMD': 'DEL', 'NBR-0001': 'N00001'}},
        {'name': 'bad-cmd', 'about': 'unknown command', 'env': {'CAGENSHIM_CLOCK': '20240105070809000000'},
         'inputs': [['CMD', 'XXX'], ['SRV-DATE', '20240105']]},
        {'name': 'abend', 'about': 'the program abends', 'fixture': 'fixtures/user.sql',
         'inputs': [['CMD', 'ABEND'], ['SRV-DATE', '20231231']]},
    ]}


def workspace(root):
    mu = root / 'mu' / 't'
    unit = mu / 'unit' / E
    for d in (unit / 'sources', unit / 'fixtures', mu / 'design', mu / 'extracted-logic'):
        d.mkdir(parents=True, exist_ok=True)
    (mu / 'mu.yaml').write_text(f'name: t\nentry_points: [{E}]\nportfolio_id: 1\n', encoding='utf-8')
    (mu / 'tools.yaml').write_text('db2:\n  kind: local\n  container: fake-db2\n  database: TESTDB\n  runner_host: db2\n'
                                   '  port: 50000\n  user: u\n  password: p\n  schema: DSCHEMA\ngolden-db2:\n  kind: local\n'
                                   '  schema: TSCHEMA\ncobol-runner:\n  kind: local\n  url: http://localhost:1\n', encoding='utf-8')
    (mu / 'design' / 'design-open-questions.md').write_text(
        '# design-open-questions.md\n\n## Settled\n\n- x\n\n## OQ-1 - Clock\n\nStep: 2 · Status: settled\nQuestion: q\n'
        'Decision taken: d\nAffects: -\nAnswer: confirmed\n\n## OQ-2 - Open one\n\nStep: 2 · Status: open\nQuestion: q\n'
        'Decision taken: d\nAffects: -\nAnswer: <filled by the user; the next run applies it>\n', encoding='utf-8')
    (mu / 'design' / 'design.md').write_text('# design.md\n\n## Processing date {#D-2}\n\n## Errors\n\n```\n## In a fence\n```\n',
                                             encoding='utf-8')
    (mu / 'tests').mkdir(exist_ok=True)
    (mu / 'tests' / 'tests-open-questions.md').write_text(
        '# tests-open-questions.md\n\n## PQ-3 - Unknown user\n\nStep: 3 · Status: open\nBlocking: no\nQuestion: q\n'
        'Decision taken: d\nAffects: -\nAnswer: 422, as decided\n\n## PQ-4 - Open\n\nStep: 3 · Status: open\nBlocking: no\n'
        'Question: q\nDecision taken: d\nAffects: -\nAnswer:\n', encoding='utf-8')
    (mu / 'unit' / 'schema.sql').write_text(DDL, encoding='utf-8')
    (unit / 'sources' / f'{E}.CBL').write_text(COBOL, encoding='utf-8')
    (unit / 'driver.cbl').write_text('       PROGRAM-ID. DRIVER.\n', encoding='utf-8')
    (unit / 'schema.yaml').write_text(SCHEMA_YAML, encoding='utf-8')
    (unit / 'cases.json').write_text(json.dumps(unit_cases(), indent=1), encoding='utf-8')
    (unit / 'fixtures' / 'user.sql').write_text("INSERT INTO USERS (USER_ID) VALUES ('U1');\n", encoding='utf-8')
    (unit / 'fixtures' / 'nouser.sql').write_text("DELETE FROM USERS WHERE USER_ID = 'U1';\n", encoding='utf-8')
    (unit / 'fixtures' / 'evt.sql').write_text("INSERT INTO USERS (USER_ID) VALUES ('U1');\nINSERT INTO EVT (NBR, USER_ID) "
                                               "VALUES ('N00001', 'U1');\n", encoding='utf-8')
    (mu / 'design' / 'rules.md').write_text('# rules\n\n| # | Rule | From | Target home |\n|---|---|---|---|\n'
                                            '| 1 | Add stores the event and its items. | `E000001` P-ADD (3-4) | `Svc.add` |\n'
                                            '| 2 | Delete removes the event. | `E000001` P-DEL (5-5) | `Svc.delete` |\n',
                                            encoding='utf-8')
    (mu / 'design' / 'tests.md').write_text(TESTS_MD, encoding='utf-8')
    (mu / 'extracted-logic' / 'paragraph-index.json').write_text(json.dumps(INDEX, indent=1), encoding='utf-8')
    return mu


PLAN = {
    'idPrefix': 'TC-T-',
    'defaults': {'fixture': 'user.sql', 'clock': '20240816103000', 'probeClock': '20250105070809', 'shims': ['cagen'],
                 'repeats': 2, 'checks': ['evt', 'lines']},
    'constantInputs': {'SRV-DATE': 'clock:yyyyMMdd'},
    'inputMap': {'command': 'CMD', 'userId': 'USER-ID-0001', 'amount': 'AMT-0001', 'number': 'NBR-0001',
                 'items': {'count': 'CNT-0002MA', 'item': {'amount': 'ITEM-AMT-0003'}}, 'kind': 'KIND-0001'},
    'outputs': {'inputs': '$inputs', 'runId': '$runId', 'number': 'NBR-0005', 'respCode': 'RESP-CODE-S-0004|number'},
    'technicalFailure': {'flag': 'ERROR-ENCOUNTERED-SW', 'ok': ['', 'N'], 'fields': {'lastStatus': 'LAST-STATUS'}},
    'tables': {'evt': {'table': 'EVT', 'columns': ['NBR', 'USER_ID', 'AMT', 'PROC_DT'], 'orderBy': ['NBR'], 'compare': 'ordered'},
               'lines': {'table': 'LINES', 'columns': ['NBR', 'SEQ', 'AMT'], 'orderBy': ['NBR', 'SEQ'], 'compare': 'ordered'}},
    'api': {'operations': [
        {'name': 'add', 'when': {'command': 'ADD'}, 'method': 'POST', 'pathTemplate': '/evt',
         'body': {'userId': 'param:userId|trim', 'amount': 'param:amount|number',
                  'items': {'$param': 'items', '$item': {'amount': 'item:amount|number'}}},
         'response': {'outcome': 'respCode', 'map': {'0': {'status': 201, 'body': {'number': 'scalar:number|trim'}},
                                                     '1': {'status': 404, 'body': {'code': 'const:"NOT_FOUND"'}}}},
         'technicalFailure': {'status': 500, 'body': {'code': 'const:"FAILED"'}, 'source': 'design.md#errors',
                              '_note': 'comment keys are not published'}},
        {'name': 'delete', 'when': {'command': 'DEL'}, 'method': 'DELETE', 'pathTemplate': '/evt/{number}',
         'path': {'number': 'param:number|trim'},
         'response': {'outcome': 'respCode', 'map': {'0': {'status': 200, 'empty': True}}}},
        {'name': 'show', 'when': {'command': 'SHOW'}, 'method': 'GET', 'pathTemplate': '/evt/kinds/{kind}',
         'path': {'kind': 'param:kind|enum'}, 'response': {'outcome': 'respCode', 'map': {'0': {'status': 200, 'body': {}}}}},
        {'name': 'abend', 'when': {'command': 'ABEND'}, 'method': 'POST', 'pathTemplate': '/abend',
         'response': {'status': 500}}],
        'enumMaps': {'kind': {'OPEN': 'open'}}},
    'decisions': {
        'clock': {'when': 'operation:add', 'clockDependent': True, 'source': 'OQ-1',
                  'text': 'the number comes from the Java clock'},
        'nouser': {'when': 'legacy:respCode=1&operation:add', 'source': 'PQ-3',
                   'text': 'the Java answers an unknown user as a validation error',
                   'answer': {'status': 422, 'tables': 'recorded'}},
        'procdate': {'when': 'case:add-ok', 'source': 'design.md#D-2', 'text': 'the Java takes PROC_DT from its clock',
                     'answer': {'set': [{'path': 'tables.EVT[0].PROC_DT', 'value': '2025-01-05'}], 'tables': 'recorded'}},
        'collation': {'when': 'case:show-open', 'kind': 'stack', 'text': 'ASCII collation on this stack'}},
    'goldenMaster': 'stand-in; recorded 0000-00-00',
    'suiteHeader': {'api': 'POST /evt, DELETE /evt/{number}', 'comparison': 'status, body, rows',
                    'statuses': {'golden': 'g', 'not-representable': 'n', 'not-recorded': 'r'}},
    'cases': [],
}



def units(check):
    """btlib's pure parts, called directly (tc-gen selftest checks, ported)."""
    sys.path.insert(0, str(HERE))
    import btlib as b

    def raises(fn, text=''):
        try:
            fn()
        except b.Stop as e:
            return text in str(e)
        return False

    # ---- clock
    check([b.valid_clock(x) for x in ('20240816103000', '20240816103000123456', '202408161030001', '2024081610300',
                                      '202408161030001234567', 20240816103000)] == [True, True, True, False, False, False],
          'clock: 14 digits, or 14 plus up to six fraction digits')
    check([b.shim_clock(x) for x in ('20240816103000', '20240816103000123456', '2024081610300012')]
          == ['20240816103000', '20240816103000123456', '20240816103000120000'], 'clock: the shim gets 14 or 20 digits')
    check(b.clock_value('clock:yyyy-MM-dd HH:mm:ss.ffffff', '2024081610300012') == '2024-08-16 10:30:00.120000'
          and b.clock_value('clock:yyyyMMdd', '20240816103000') == '20240816', 'clock: clock:<fmt> tokens, fraction padded')
    plan = {'defaults': {'clock': '20240816103000', 'probeClock': '20250105070809'},
            'constantInputs': {'SRV-DATE': 'clock:yyyyMMdd', 'MODE': 'X'}}
    check(b.probe_clock(plan, '20240816103000') == '20250105070809' and b.probe_clock(plan, '20200101000000')
          == '20240816103000', 'clock: probe = probeClock, or the default clock for a case at another clock')
    check(b.clock_inputs(plan, [['SRV-DATE', '20240816'], ['MODE', 'X'], ['A', '1']], '20250105070809')
          == [['SRV-DATE', '20250105'], ['MODE', 'X'], ['A', '1']], 'clock: a base case probe re-evaluates clock: inputs')
    check(any('probeClock' in e for e in b.bad_clocks({'defaults': {'clock': '20240816103000'}}))
          and any('other than' in e for e in b.bad_clocks({'defaults': {'clock': '20240816103000', 'probeClock': '20240816103000'}})),
          'clock: probeClock required and other than clock')

    # ---- binding (one endpoint and operations)
    api = {'operations': [
        {'name': 'add', 'when': {'command': 'ADD'}, 'method': 'POST', 'pathTemplate': '/things',
         'body': {'userId': 'param:userId|trim|blankAbsent', 'day': 'param:day|date',
                  'details': {'$param': 'details', '$item': {'amount': 'item:amount|number'}}},
         'response': {'outcome': 'responseCode', 'map': {'0': {'status': 201, 'body': {'id': 'scalar:thingId|trim'}},
                                                         '1': {'status': 404, 'body': {'code': 'const:"NOT_FOUND"'}}},
                      'otherwise': {'status': 500, 'body': {'code': 'const:"UNEXPECTED"'}}},
         'technicalFailure': {'status': 500, 'body': {'code': 'const:"DB-ERROR"'}, 'source': 'OQ-2',
                              'causes': [{'when': {'lastStatus': 'IA'}, 'status': 400, 'body': {'code': 'const:"BAD"'},
                                          'source': 'PQ-6'}]}},
        {'name': 'put', 'when': {'command': 'PUT'}, 'method': 'PUT', 'pathTemplate': '/things/{thingId}',
         'path': {'thingId': 'param:thingId|trim'}, 'response': {'status': 200, 'empty': True}}]}
    pc = {'name': 'a', 'params': {'command': 'ADD', 'userId': 'AB12', 'day': '20240315', 'details': [{'amount': '1.50'}]}}
    req, _ = b.request_for(api, pc)
    check(req['body'] == {'userId': 'AB12', 'day': '2024-03-15', 'details': [{'amount': b.Decimal('1.50')}]},
          'binding: body with |date and a $param group')
    blank, _ = b.request_for(api, {'params': {'command': 'ADD', 'userId': '  '}})
    check('userId' not in blank['body'], 'binding: |blankAbsent leaves the key out')
    put, _ = b.request_for(api, {'params': {'command': 'PUT', 'thingId': 'T1'}})
    check(put['body'] == {} and put['url'] == '/things/T1' and put['thingId'] == 'T1',
          'binding: a PUT keeps its (empty) body; path placeholder stated on the request')
    check(b.expected_for(api, pc, {'responseCode': 7}) == {'status': 500, 'body': {'code': 'UNEXPECTED'}},
          'binding: otherwise')
    check(b.expected_for(api, pc, {'responseCode': 0, 'technicalFailure': {'lastStatus': 'IA '}})['status'] == 400
          and b.expected_for(api, pc, {'technicalFailure': {'lastStatus': 'XX'}})['status'] == 500,
          'binding: technical failure answered per cause, else the answer')
    check([a.get('source') for _, a in b.failure_answers(api)] == ['OQ-2', 'PQ-6'], 'binding: failure answers listed')
    check('blank' in (b.unrepresentable(api, {'params': {'command': 'PUT', 'thingId': ' '}}) or '')
          and 'no API operation' in (b.unrepresentable(api, {'params': {'command': 'X'}}) or ''),
          'binding: blank placeholder / no operation -> unrepresentable')
    lk = {'method': 'GET', 'pathTemplate': '/lookups/{t}', 'path': {'t': 'param:table|enum'},
          'enumMaps': {'table': {'STAT LINE EXT ': 'STAT_LINE_EXT', 'POOL CODE': 'POOL_CODE'}}}
    paths = [b.request_for(lk, {'params': {'table': v}})[0]['path'] for v in ('STAT LINE EXT', 'STAT LINE EXT ', 'POOL CODE', 'XYZ')]
    check(paths == ['/lookups/STAT_LINE_EXT', '/lookups/STAT_LINE_EXT', '/lookups/POOL_CODE', '/lookups/XYZ'],
          'binding: an enum key matches with or without its trailing blanks')
    types = {'inputs': {'TBL': 'X(9)'}}
    lp = {'inputMap': {'table': 'TBL'}}
    check(b.padded_variant(lk, lp, {'params': {'table': 'POOL CODEX'}}, types) is not None
          and b.padded_variant(lk, lp, {'params': {'table': 'POOL CODE'}}, types) is None
          and b.padded_variant(lk, lp, {'params': {'table': 'XYZ'}}, types) is None,
          'binding: a value only the field cut maps is unspellable; mapped and unknown values are not')
    one = {'method': 'GET', 'pathTemplate': '/l', 'query': {'q': 'param:q'},
           'response': {'status': 200, 'statusMap': {'scalar': 'rc', 'map': {'4': 404}},
                        'body': {'items': 'list:items', 'more': 'full:items',
                                 'codes': {'$list': 'items', '$item': {'code': 'col:code|trim'}}}}}
    outs = {'items': {'count': 'N', 'columns': {'code': 'C', 'text': 'T'}}}
    r1, _ = b.request_for(one, {'params': {'q': 'x y'}})
    e1 = b.expected_for(one, {'params': {}}, {'rc': 4, 'items': [['c ', 'd']]}, outs, {'items': 1})
    check(r1['url'] == '/l?q=x%20y' and 'body' not in r1 and e1 == {'status': 404, 'body': {
        'items': [{'code': 'c', 'text': 'd'}], 'more': True, 'codes': [{'code': 'c'}]}},
          'binding: one endpoint, statusMap, list:, full:, $list/col:')
    who = {'method': 'GET', 'pathTemplate': '/v1/menus', 'principal': 'param:userId|trim|blankAbsent'}
    r2, _ = b.request_for(who, {'params': {'userId': 'U001 '}})
    r3, _ = b.request_for(who, {'params': {'userId': '  '}})
    check(r2.get('principal') == 'U001' and list(r2) == ['method', 'path', 'query', 'principal', 'url']
          and 'principal' not in r3, 'binding: principal after query, left out when absent')
    check(b.published({'a': 1, '_c': 2, 'l': [{'_x': 1, 'y': 2}]}) == {'a': 1, 'l': [{'y': 2}]}, 'binding: published drops _ keys')

    # ---- names
    np = {'inputMap': {'command': 'CMD-0001', 'caller': 'USER-ID-0002'},
          'outputs': {'inputs': '$inputs', 'runId': '$runId'},
          'api': {'method': 'POST', 'pathTemplate': '/x/{id}', 'path': {'id': 'param:command'}, 'principal': 'param:caller',
                  'body': {'user': 'param:command'}}}
    errs = b.naming_errors(np)
    check(any('name it "userId"' in e for e in errs) and any('path {id}' in e for e in errs)
          and any('body key "user"' in e for e in errs), 'names: principal noun, path placeholder, body key')

    # ---- legacy, typed rows, reset order
    lp = {'outputs': {'inputs': '$inputs', 'runId': '$runId'}, 'inputMap': {},
          'technicalFailure': {'extraFlags': {'VIEW-OVERFLOW-SW': ['', 'N']},
                               'fields': {**b.CAGEN_FAILURE['fields'], 'viewOverflow': 'VIEW-OVERFLOW-SW'}}}
    l4 = b.legacy_of({'STATUS-FLAG': ' ', 'VIEW-OVERFLOW-SW': 'Y'}, lp, [], 'r1')
    l5 = b.legacy_of({'STATUS-FLAG': ' ', 'VIEW-OVERFLOW-SW': 'N'}, lp, [], 'r1')
    check((l4.get('technicalFailure') or {}).get('viewOverflow') == 'Y' and 'technicalFailure' not in l5,
          'legacy: an extra flag outside its ok values marks the failure (flag, ok kept from the default)')
    tf = b.failure_of({'technicalFailure': {'ok': ['', 'N'], 'fields': {'viewOverflow': 'V', 'failedIn': 'X'}}})
    check(tf['flag'] == 'STATUS-FLAG' and tf['ok'] == ['', 'N'] and tf['fields']['failedIn'] == 'X'
          and tf['fields']['viewOverflow'] == 'V' and tf['fields']['lastStatus'] == 'LAST-STATUS'
          and list(tf['fields'])[:5] == list(b.CAGEN_FAILURE['fields']) and b.CAGEN_FAILURE['fields']['failedIn'] == 'CUR-AB-NAME',
          'technicalFailure: plan keys over the default per key, fields merged')
    row = b.db2_json_row('{"A":-000000012.50,"B":000000000.00,"C":00012,"F":"007 -000.10","I":null}')
    check(row == {'A': b.Decimal('-12.50'), 'B': b.Decimal('0.00'), 'C': 12, 'F': '007 -000.10', 'I': None},
          'typed row: a Db2 DECIMAL with leading zeros reads as a number')
    t = {'P': {'columns': {}, 'parents': []}, 'C': {'columns': {}, 'parents': ['P']},
         'G': {'columns': {}, 'parents': ['C']}, 'O': {'columns': {}, 'parents': []}}
    check(b.reset_tables(t) == ['G', 'C', 'P', 'O'] and b.reset_sql(t) == ''.join(f'DELETE FROM {x};\n' for x in 'GCPO')
          and b.unknown_tables({'tables': {'n': {'table': 'NOPE'}, 'p': {'table': 'P'}}}, t, []) == ['NOPE'],
          'resetTables: every schema.sql table, foreign-key children first, one list for reset and package; unknown named')

    # ---- predicates
    def f(when, legacy=None, exp=None, **params):
        return b.fires(when, {'name': 'x', 'params': params}, legacy or {}, False, exp)
    check([f('notDate:d', d=x) for x in ('20241301', '20230229', '99999999', '00000101', '20240229', 20240816, '0', '')]
          == [True, True, True, True, False, False, False, False], 'predicate: notDate')
    check([f('negative:d', d=-1), f('negative:d', d=5), f('above:d=99999999', d=100000000),
           f('above:d=99999999', d='99999999'), f('negative:d')] == [True, False, True, False, False], 'predicate: negative / above')
    check([f('wider:s=5', s='ABCDEF'), f('wider:s=5', s='ABCDE   ')] == [True, False], 'predicate: wider')
    check([f('param:t=POOL CODE|PROGRAM CODE', t='PROGRAM CODE  '), f('param:t=POOL CODE|PROGRAM CODE', t='X')]
          == [True, False], 'predicate: param alternatives')
    check([f('absent:a'), f('absent:a', a='x'), f('zero:a', a='000'), f('zero:a'), f('absentOrZero:a'),
           f('blank:a', a='  '), f('blank:a')] == [True, False, True, False, True, True, False], 'predicate: absent/zero/blank')
    check([f('legacy:rc=0', {'rc': 0}), f('legacy:rc=0', {'rc': '1 '}), f('failure:lastStatus=IA', {'technicalFailure': {'lastStatus': 'IA '}}),
           f('technicalFailure', {'technicalFailure': {'x': 1}}), f('status:404', exp={'status': 404}), f('case:x'),
           f('case:y'), f('legacy:rc=0&case:x', {'rc': 0}), f('legacy:rc=0&case:y', {'rc': 0})]
          == [True, False, True, True, True, True, False, True, False], 'predicate: legacy/failure/status/case and &')
    check(b.fires('unmapped:k', {'params': {'k': 'ZZ'}}, {}, False, None, {'enumMaps': {'k': {'A': 'a'}}})
          and not b.fires('unmapped:k', {'params': {'k': 'A'}}, {}, False, None, {'enumMaps': {'k': {'A': 'a'}}}),
          'predicate: unmapped')

    # ---- decisions
    def derrs(**d):
        return b.decision_errors({'decisions': {'d': {'when': 'case:x', 'text': 'x', **d}}})
    check(any('source' in e for e in derrs()) and not derrs(source='PQ-1') and not derrs(kind='stack')
          and any('source' in e for e in derrs(kind='stack', answer={'status': 422}))
          and not derrs(source='design.md#D-3') and any('source' in e for e in derrs(source='PAR-U-01')),
          'decisions: source OQ-n / PQ-n / design.md#... for kind java and any answer; v1 PAR- refused')
    check(any('not compared' in e for e in derrs(source='PQ-1', text='the echo is not compared'))
          and any('expected status' in e for e in derrs(source='PQ-1', text='the Java expects 404'))
          and any('unknown predicate' in e for e in derrs(source='PQ-1', when='bogus:x'))
          and any('<param>=<number>' in e for e in derrs(source='PQ-1', when='above:x'))
          and any('only a kind java' in e for e in derrs(source='PQ-1', kind='stack', answer={'status': 422}))
          and any('answer.tables' in e for e in derrs(source='PQ-1', answer={'tables': 'all'})),
          'decisions: prose comparison, stated status, unknown predicate, bad answer refused')
    check(any('divergenceRules' in e for e in b.decision_errors({'divergenceRules': {'x': {}}}))
          and any('needs a source' in e for e in b.decision_errors({'api': {'method': 'GET', 'pathTemplate': '/x',
                                                                             'technicalFailure': {'status': 500}}})),
          'decisions: divergenceRules refused; a failure answer without source refused')
    exp = {'status': 201, 'body': {'n': 'A'}, 'tables': [{'name': 'T', 'columns': ['A', 'B'], 'rows': [[1, 'x']],
                                                            'query': 'q', 'compare': 'set'}]}
    r = {'source': 'PQ-1', 'answer': {'status': 422, 'tables': 'notCompared'}}
    new, da = b.decide([('d', r)], exp)
    check(new == {'status': 422, 'body': {}} and da['recorded'] == exp and da['tables'] == 'notCompared'
          and da['recordedStatus'] == 201 and da['status'] == 422, 'decide: status, rows not compared, recorded kept')
    new, _ = b.decide([('d', {'source': 'PQ-1', 'answer': {'set': [{'path': 'tables.T[0].B', 'value': 'y'},
                                                                  {'path': 'body.n', 'value': 'B'}], 'tables': 'recorded'}})], exp)
    check(new['tables'][0]['rows'] == [[1, 'y']] and new['body'] == {'n': 'B'} and exp['tables'][0]['rows'] == [[1, 'x']],
          'decide: set changes a row value and a body value, the recorded answer untouched')
    check(raises(lambda: b.decide([('d', {'source': 'PQ-1', 'answer': {'status': 422}})], exp), 'answer.tables')
          and raises(lambda: b.decide([('d', {'source': 'PQ-1', 'answer': {'set': [{'path': 'body.zz', 'value': 1}],
                                                                           'tables': 'recorded'}})], exp), 'no zz')
          and raises(lambda: b.decide([('a', {'source': 'PQ-1', 'answer': {'status': 422, 'tables': 'recorded'}}),
                                       ('b', {'source': 'PQ-2', 'answer': {'status': 409, 'tables': 'recorded'}})], exp),
                     'different answers'), 'decide: tables required with rows, absent path, conflicting answers refused')

    # ---- run key: the check SQL, not the check names
    tp = {'tables': {'t': {'table': 'T', 'columns': ['A', 'B'], 'orderBy': ['A']}}}
    ty = {'T': {'columns': {'A': 'CHAR(4)', 'B': 'DECIMAL(9,2)'}}}

    def rk(**chg):
        pl = json.loads(json.dumps(tp))
        pl['tables']['t'].update(chg)
        return b.run_key([['X', '1']], '20240816103000', 'f.sql', ['cagen'], b.check_key(pl, ['t'], ty), 'fp')
    keys = [rk(), rk(columns=['A']), rk(orderBy=['B']), rk(where="A = 'x'")]
    check(len(set(keys)) == 4 and rk() == keys[0], 'run key: a changed column list, ORDER BY or where gives a new key')
    k = b.check_key(tp, ['t'], ty)[0]
    check(k[1] == 'SELECT A, B FROM T ORDER BY A' and 'JSON_OBJECT' in k[2]
          and b.check_key(tp, ['t'], {'T': {'columns': {'A': 'CHAR(400)', 'B': 'DECIMAL(9,2)'}}})[0][2] != k[2],
          'run key: raw and typed check SQL (the typed one follows the column types)')
    rec = {'status': 'golden', 'expected': {'tables': [{'name': 'T', 'query': 'SELECT A, B FROM T ORDER BY A'}]}}
    check(b.checks_changed(tp, rec, ['t']) == [] and b.checks_changed({'tables': {'t': {**tp['tables']['t'], 'where': 'A > 1'}}},
                                                                    rec, ['t']) == ['t']
          and b.checks_changed(tp, {**rec, 'status': 'not-recorded'}, []) == [],
          'checks_changed: the recorded query against the plan, golden cases only')

    # ---- decided sources: heading anchors
    with tempfile.TemporaryDirectory() as d:
        md = Path(d) / 'design.md'
        md.write_text('# design.md - the target\n\n## The WIP number (`Gen.make(ts)`)\n\n## Errors\n\n## Errors\n\n'
                      '## Dates {#D-7}\n\n<a id="x-1"></a>\n\n```\n## In code\n```\n', encoding='utf-8')
        check(b.design_anchors(md) == {'designmd---the-target', 'the-wip-number-genmakets', 'errors', 'errors-1', 'dates',
                                       'd-7', 'x-1'}, 'design.md anchors: GitHub slugs, repeats numbered, {#id}, <a id>, fences skipped')

    # ---- design expectations
    c = {'design': {'request': 'PUT /things/{thingId}', 'outcome': '200 OK'}, 'status': 'golden',
         'request': {'method': 'PUT', 'path': '/things/T1', 'url': '/things/T1'}, 'expected': {'status': 200}}
    check(b.design_mismatches(c, api['operations'][1]) == [], 'design: method, templated path and status match')
    c1 = {**c, 'design': {'request': 'PUT /things/T1, clock fixed at 2024-08-16', 'outcome': '200 OK'}}
    check(b.design_mismatches(c1, None) == [], 'design: a comma after the path is not part of it')
    c2 = {**c, 'design': {'request': 'POST /other', 'outcome': 'HTTP 201'}}
    check(b.design_mismatches(c2, None) == ['method: design POST, binding PUT', 'path: design /other, binding /things/T1',
                                            'status: design 201, expected 200'], 'design: mismatches listed')
    c3 = {'design': {'request': 'GET /x', 'outcome': '404'}, 'status': 'not-representable', 'request': None, 'expected': None}
    check(len(b.design_mismatches(c3, None)) == 2, 'design: no request / no expected answer listed')


def canonical_hash(doc):
    body = {k: v for k, v in doc.items() if k != 'package'}
    return hashlib.sha256(json.dumps(body, ensure_ascii=False, separators=(',', ':'), sort_keys=True)
                          .encode('utf-8')).hexdigest()


def main():
    ap = argparse.ArgumentParser(description='Offline self-test of the mu-build-tests scripts.')
    ap.add_argument('--keep', help='build the workspace in this folder (emptied first) and keep it')
    a = ap.parse_args()
    failures, passed = [], []

    def check(cond, what):
        print(('ok    ' if cond else 'FAIL  ') + what, file=sys.stderr)
        (passed if cond else failures).append(what)

    units(check)

    if a.keep:
        root = Path(a.keep).resolve()
        if root.exists():
            shutil.rmtree(root)
        root.mkdir(parents=True)
        holder = None
    else:
        holder = tempfile.TemporaryDirectory()
        root = Path(holder.name)
    try:
        mu = workspace(root)
        stand_in = root / 'run_cobol_stand_in.py'
        stand_in.write_text(STAND_IN, encoding='utf-8')
        env = {**os.environ, 'BT_RUN_COBOL': str(stand_in), 'PYTHONDONTWRITEBYTECODE': '1', 'BT_RETRY_WAIT': '0'}
        tests = mu / 'tests'
        plan_file = tests / 'plan' / f'{E}.plan.json'
        fixtures = tests / 'fixtures' / E
        pkg = tests / 'package' / E
        prev = tests / 'previous' / E
        tmp = tests / '.tmp' / E
        plan_file.parent.mkdir(parents=True)
        plan_file.write_text(json.dumps(PLAN, indent=1), encoding='utf-8')

        def script(name, *extra, mode='normal', expect=0):
            r = subprocess.run([sys.executable, '-B', str(HERE / name), 'mu/t', *extra], cwd=root, capture_output=True,
                               text=True, encoding='utf-8', env={**env, 'BT_FAKE_MODE': mode})
            if r.returncode != expect:
                print(r.stdout[-3000:], r.stderr[-3000:], file=sys.stderr)
            check(r.returncode == expect, f"{name} {' '.join(extra)} exits {expect} (got {r.returncode})")
            try:
                doc = json.loads(r.stdout)
                one = isinstance(doc, dict) and r.stdout.strip().count('\n') == 0
            except ValueError:
                doc, one = {}, False
            check(one and 'status' in doc, f'{name} {" ".join(extra)}: stdout is one JSON object with a status')
            return doc

        # ---- import_unit: basic cases, design blocks, gaps
        doc = script('import_unit.py', expect=2)
        gaps = {(g['kind'], g['case']) for g in doc.get('gaps') or []}
        check(gaps == {('no-tests-md-block', 'abend'), ('no-unit-case', 'orphan-case')},
              'import_unit: gaps name the case without a block and the block without a case')
        plan = json.loads(plan_file.read_text(encoding='utf-8'))
        check(len(plan['cases']) == 5 and (fixtures / 'evt.sql').is_file(), 'five unit cases and their fixtures imported')
        check(all(c.get('origin') == 'basic' for c in plan['cases']), 'every imported case is origin basic')
        add = next(c for c in plan['cases'] if c['name'] == 'add-ok')
        check(add['params'].get('items') == [{'amount': '1.00'}, {'amount': '2.00'}], 'the item group became a list of items')
        check(add['design']['request'] == 'POST /evt\n  {"userId": "U1", "amount": 10.50}'
              and add['design']['outcome'] == '201' and add['design']['rules'] == ['1']
              and add['design']['doesNotVerify'] == 'the order of the inserts.' and add['ruleIds'] == ['R1'],
              'add-ok: design block and ruleIds from tests.md')
        nou = next(c for c in plan['cases'] if c['name'] == 'add-nouser')
        check(nou['ruleIds'] == ['R1', 'R2'] and nou['design']['rules'] == ['1', '2 (the delete side)'],
              'add-nouser: Rules line with a note -> R1, R2')
        check('design' not in next(c for c in plan['cases'] if c['name'] == 'abend'), 'abend: no tests.md block, no design')
        bad, abd = (next(c for c in plan['cases'] if c['name'] == n) for n in ('bad-cmd', 'abend'))
        check(bad.get('clock') == '20240105070809000000' and 'extraInputs' not in bad and 'status' not in bad
              and 'clock' not in abd and 'extraInputs' not in abd,
              'import_unit: an input equal to its clock: constant at the case clock is that constant; '
              'a case clock other than defaults.clock kept')
        check([w for w in doc.get('warnings') or [] if 'clock constant' in w]
              == ["unit case abend: SRV-DATE '20231231' differs from its clock constant ('20240816' at 20240816103000): "
                  'dropped, the case records at its own clock'],
              'import_unit: an input other than its clock: constant is dropped and named in warnings')
        cats = {'add-ok': 'Happy', 'add-nouser': 'Error', 'delete-ok': 'Happy', 'bad-cmd': 'Robustness', 'abend': 'Error'}
        for c in plan['cases']:
            c['category'] = cats[c['name']]
            if c['name'] == 'bad-cmd':
                c.update(status='not-representable', reason='no operation serves an unknown command')
        extra = {k: v for k, v in add.items() if k not in ('design',)}
        plan['cases'].append({**extra, 'name': 'add-clock', 'origin': 'advanced', 'clock': '20240105070809',
                              'about': 'add at another clock', 'category': 'Boundary', 'ruleIds': ['R1']})
        plan['cases'].append({'name': 'show-open', 'origin': 'advanced', 'category': 'Happy', 'about': 'show the open kind',
                              'params': {'command': 'SHOW', 'kind': 'OPEN'}, 'checks': []})
        plan['cases'].append({'name': 'show-padded', 'origin': 'advanced', 'category': 'Edge', 'checks': [],
                              'about': 'a kind only the X(4) cut maps', 'params': {'command': 'SHOW', 'kind': 'OPENX'}})
        plan_file.write_text(json.dumps(plan, indent=1), encoding='utf-8')
        doc = script('import_unit.py', expect=2)
        check(sorted(doc.get('refreshed') or []) == ['add-nouser', 'add-ok', 'bad-cmd', 'delete-ok'] and not doc.get('added'),
              'import_unit again: basic cases refreshed, nothing added')
        plan = json.loads(plan_file.read_text(encoding='utf-8'))
        check(next(c for c in plan['cases'] if c['name'] == 'add-ok')['category'] == 'Happy', 'refresh keeps the category')

        # ---- no golden-db2: a hard block, nothing emptied in db2
        tools_yaml = mu / 'tools.yaml'
        good_tools = tools_yaml.read_text(encoding='utf-8')
        tools_yaml.write_text(good_tools.replace('golden-db2:\n  kind: local\n  schema: TSCHEMA\n', ''), encoding='utf-8')
        doc = script('preflight.py', '--offline', expect=1)
        check(any('no golden-db2' in x for x in doc.get('blocks') or []) and 'golden-db2:' in str(doc.get('add'))
              and 'GM_<MU>' in str(doc.get('add')), 'preflight --offline: no golden-db2 blocks, the section to add given')
        for name, *flag in (('record.py',), ('db.py', '--reset')):
            d = script(name, *flag, expect=1)
            check('no golden-db2' in str(d.get('error')) and not (tmp / 'runs').exists(),
                  f'{name}: no golden-db2 -> exit 1, no fallback to db2')
        tools_yaml.write_text(good_tools.replace('golden-db2:\n  kind: local\n  schema: TSCHEMA\n',
                                                 'golden-db2:\n  kind: local\n  schema: dschema\n'), encoding='utf-8')
        d = script('db.py', '--reset', expect=1)
        check('the db2 database' in str(d.get('error')), 'db.py: a golden-db2 naming the db2 schema is refused')
        tools_yaml.write_text(good_tools, encoding='utf-8')
        doc = script('preflight.py', '--offline')
        check(doc.get('blocks') == [] and 'add' not in doc, 'preflight --offline: golden-db2 present, no block')

        # ---- record, build
        doc = script('record.py')
        check(doc.get('database') == 'TESTDB/TSCHEMA' and 'warnings' not in doc, 'record: on golden-db2, no fallback warning')
        check(doc.get('probes') == 8, f"record: one probe run per case (8, got {doc.get('probes')})")
        rj = json.loads((tmp / 'record.json').read_text(encoding='utf-8'))
        check(rj.get('status') == 'ok' and rj['counts'].get('probes') == 8 and rj['counts'].get('recorded') == doc.get('recorded')
              and rj.get('failures') == [] and rj.get('finishedAt') and rj.get('carried') == 0,
              'record: record.json status ok, counts, no failures')
        index = json.loads((tmp / 'index.json').read_text(encoding='utf-8'))
        probe = json.loads((tmp / 'runs' / f"{index['plan:add-ok@probe']}.json").read_text(encoding='utf-8'))
        main_ = json.loads((tmp / 'runs' / f"{index['plan:add-ok']}.json").read_text(encoding='utf-8'))
        clk = json.loads((tmp / 'runs' / f"{index['plan:add-clock@probe']}.json").read_text(encoding='utf-8'))
        check(len(probe['repeats']) == 1 and probe['clock'] == PLAN['defaults']['probeClock'] and len(main_['repeats']) == 2
              and dict(probe['inputs'])['SRV-DATE'] == '20250105' and dict(main_['inputs'])['SRV-DATE'] == '20240816',
              'record: probe once at probeClock, clock-derived input evaluated at each clock')
        check(clk['clock'] == PLAN['defaults']['clock'], 'record: a case at another clock probes at the default clock')
        check(not any('@default-clock' in k for k in index), 'record: no default-clock shadow run')
        doc = script('build.py')
        suite = json.loads((tmp / f'{E}-tests.json').read_text(encoding='utf-8'))
        by = {c['name']: c for c in suite['cases']}
        check(suite['package']['format'] == 3 and suite['package']['version'] == 1
              and suite['package']['generator']['name'] == 'mu-build-tests', 'format 3, version 1, generator mu-build-tests')
        check(suite['package']['contentHash'] == canonical_hash(suite), 'contentHash = sha256 of the canonical JSON')
        check(sorted(suite['package']['inputs']) == ['design/rules.md', 'design/tests.md',
                                                    'extracted-logic/paragraph-index.json', 'unit/schema.sql']
              and all(suite['package']['inputs'].values()), 'package.inputs: the four input hashes')
        a_ = by['add-ok']
        check(a_['origin'] == 'basic' and a_['design']['outcome'] == '201' and by['add-clock']['origin'] == 'advanced'
              and 'design' not in by['add-clock'], 'origin and design in the package')
        check(a_['status'] == 'golden' and a_['expected']['status'] == 201 and a_['expected']['body'] == {'number': 'N10300'},
              'add-ok: 201 with the recorded number')
        check(a_['request']['body'] == {'userId': 'U1', 'amount': 10.5, 'items': [{'amount': 1.0}, {'amount': 2.0}]},
              'add-ok: request.body built from the legacy inputs')
        t = {x['name']: x for x in a_['expected']['tables']}
        check(t['EVT']['rows'] == [['N10300', 'U1  ', 10.5, '2025-01-05']] and t['EVT']['compare'] == 'ordered',
              'add-ok: typed EVT row in expected.tables, PROC_DT set by the decision')
        da = a_.get('decidedAnswer') or {}
        rt = {x['name']: x for x in (da.get('recorded') or {}).get('tables') or []}
        check(da.get('source') == 'design.md#D-2' and da.get('rules') == ['procdate'] and da.get('status') == 201
              and da.get('recordedStatus') == 201 and da.get('tables') == 'recorded' and len(da.get('set') or []) == 1
              and rt.get('EVT', {}).get('rows') == [['N10300', 'U1  ', 10.5, '2024-08-16']],
              'add-ok: decidedAnswer keeps the recorded answer (value-level set)')
        check(a_['legacy']['inputs'].get('SRV-DATE') == '20240816' and by['add-clock']['legacy']['inputs'].get('SRV-DATE')
              == '20240105', 'clock-derived constant input in legacy.inputs, per case clock')
        check(len(t['LINES']['rows']) == 2 and t['LINES']['query'].startswith('SELECT NBR, SEQ, AMT FROM LINES'),
              'add-ok: LINES rows and their query')
        check(a_['legacy']['verify']['evt'][0].startswith('N10300'), 'add-ok: raw rows in legacy.verify')
        check('OQ-1: the number comes from the Java clock' in a_['anticipatedJavaDivergence'],
              'add-ok: decision by operation, its source first')
        check(a_['clockSensitive'] is True and by['delete-ok']['clockSensitive'] is True
              and by['show-open']['clockSensitive'] is False, 'clockSensitive from the probe runs')
        check(by['show-open']['stackDivergence'] == ['ASCII collation on this stack'] and a_['stackDivergence'] == [],
              'kind stack -> stackDivergence')
        sp = by['show-padded']
        check(sp['status'] == 'not-representable' and 'X(4)' in sp['reason'] and sp['request'] is None
              and sp['expected'] is None and by['show-open']['request']['path'] == '/evt/kinds/open',
              'unspellable enum variant: not-representable with its reason')
        dl = by['delete-ok']
        check(dl['expected'].get('empty') is True and dl['expected']['body'] is None and
              all(x['rows'] == [] for x in dl['expected']['tables']), 'delete-ok: empty answer, zero rows stated')
        check(dl['request']['url'] == '/evt/N00001', 'delete-ok: path built')
        nu = by['add-nouser']
        check(nu['expected']['status'] == 422 and nu['decidedAnswer']['recordedStatus'] == 404
              and nu['decidedAnswer']['recorded']['status'] == 404 and nu['decidedAnswer']['source'] == 'PQ-3'
              and nu['legacy']['respCode'] == 1 and len(nu['expected']['tables']) == 2, 'add-nouser: decided 404 -> 422')
        check(by['abend']['status'] == 'not-recorded' and 'libcob' in by['abend']['reason'], 'abend: not-recorded, runtime line')
        check(by['bad-cmd']['status'] == 'not-representable' and by['bad-cmd']['request'] is None, 'bad-cmd: not-representable')
        check(by['add-clock']['clockSensitive'] is True, 'add-clock: clockSensitive from the probe run')
        check(suite['binding']['operations'][0]['technicalFailure'].get('source') == 'design.md#errors'
              and '_note' not in suite['binding']['operations'][0]['technicalFailure'], 'binding published without _ keys')
        check([x['id'] for x in suite['comparisonRules']] == ['STATUS', 'BODY_WHOLE_ON_2XX', 'OUTCOME_ONLY_ON_ERROR',
              'EMPTY_MEANS_NO_BODY', 'RTRIM', 'NULL_AS_BLANK', 'NUMBERS_BY_VALUE', 'ARRAYS_IN_ORDER', 'CASE_COMPARE',
              'TABLES_AFTER_CALL', 'STATE_BEFORE_CALL'] and suite['resetTables'] == ['LINES', 'EVT', 'USERS'],
              'comparisonRules (11, tc-gen) and resetTables (children first)')
        check(suite['resetTables'] == rj.get('resetTables'), 'resetTables: the package list is the list the recording emptied')
        check(list(suite)[1:] == ['unit', 'api', 'binding', 'goldenMaster', 'comparison', 'comparisonRules', 'resetTables',
                                  'statuses', 'legacySchema', 'rules', 'coverage', 'recordings', 'cases'],
              'package body in tc-gen order')
        check(by['abend']['request']['body'] == {} and by['abend']['request']['method'] == 'POST',
              'a POST without a declared body still carries {}')
        rep = (tmp / 'build-report.md').read_text(encoding='utf-8')
        sec = rep.split('## Design expectations differ')[1].split('\n## ')[0]
        check('add-nouser: status: design 404, expected 422' in sec and 'delete-ok: status: design 204, expected 200' in sec
              and 'add-ok' not in sec and 'path:' not in sec, 'report: design expectations differ')
        check('delete-ok: differs at the probe clock 20250105070809, but no clockDependent decision fires' in rep
              and 'add-ok: differs' not in rep, 'report: clock dependent without a rule')
        check('add-ok: 201 -> 201 by design.md#D-2' in rep and 'add-nouser: 404 -> 422 by PQ-3' in rep,
              'report: decided answers')
        check('show-padded' in rep.split('## Not representable')[1].split('\n## ')[0], 'report: unspellable listed')
        schema = json.loads((HERE.parent / 'schema' / 'tests.schema.json').read_text(encoding='utf-8'))
        allowed, need = set(schema['$defs']['case']['properties']), set(schema['$defs']['case']['required'])
        check(all(set(x) <= allowed for x in suite['cases']), 'schema: every case key is allowed')
        check(all(need <= set(x) for x in suite['cases']), 'schema: every required case key is there')
        check(set(suite) <= set(schema['properties']) and set(schema['required']) <= set(suite),
              'schema: the top-level keys are the schema ones')
        rules = {r['id']: r for r in suite['rules']}
        check(rules['R1']['provenBy'] == [a_['id'], by['add-nouser']['id'], by['add-clock']['id']]
              and rules['R2']['provenBy'] == [by['add-nouser']['id'], dl['id']], 'rules from design/rules.md with provenBy')
        cv = suite['coverage']
        check(all(k in cv for k in ('totals', 'programs', 'paragraphs', 'cases', 'outside', 'notEntered')),
              'package coverage has the coverage.py keys')
        check(a_['paragraphs'] == [f'{E}.P-ADD'] and dl['paragraphs'] == [f'{E}.P-DEL'] and by['abend']['paragraphs'] == [],
              'per-case paragraphs from coverage.py')
        tp = cv['totals']['paragraphs']
        check(tp.get('total') == 3 and tp.get('covered') == 2, 'business paragraphs: 2 of 3 covered (mechanism not counted)')
        check((tmp / 'coverage.json').is_file() and (tmp / 'uncovered.md').is_file() and (tmp / 'build-report.md').is_file()
              and (tmp / 'build.json').is_file(), 'coverage.json, uncovered.md, build-report.md, build.json written')
        check('MOVE' not in (tmp / 'uncovered.md').read_text(encoding='utf-8'), 'uncovered.md quotes no source')
        bj = json.loads((tmp / 'build.json').read_text(encoding='utf-8'))
        check(sorted(bj.get('runs') or {}) == sorted(n for n, c in by.items() if c['status'] == 'golden')
              and not any(k == index.get(f'plan:{n}@probe') for n, k in bj['runs'].items()),
              'build.json runs: one run key per golden case, never a probe')
        cdoc = script('coverage.py')
        check(cdoc.get('totals', {}).get('paragraphs') == tp and cdoc['totals'].get('lines') == cv['totals']['lines']
              and str(cdoc.get('runsFrom')).endswith('build.json'), "coverage.py: the last build's runs, build's totals")

        script('build.py', '--install')
        sys.path.insert(0, str(HERE))
        import btlib as b
        ddl_t = b.ddl(b.Paths(str(mu)))
        check(b.suite_run_keys(json.loads(plan_file.read_text(encoding='utf-8')),
                               json.loads((pkg / f'{E}-tests.json').read_text(encoding='utf-8')), ddl_t)
              == json.loads((tmp / 'build.json').read_text(encoding='utf-8'))['runs'],
              'installed package -> case -> run key: the keys build.json names')
        check(b.runner_container(str(mu)) == 'parity-cobol-runner', 'fingerprint: no cobol-runner container -> parity-cobol-runner')
        seen = []
        real_image_of, b.image_of = b.image_of, lambda c: seen.append(c) or f'sha256:{c}'
        try:
            fp = b.fingerprint(b.Paths(str(mu)), 'user.sql', ['cagen'], {'container': 'fake-db2', 'database': 'D', 'schema': 'S'}, {})
        finally:
            b.image_of = real_image_of
        check(fp['runnerImage'] == 'sha256:parity-cobol-runner' and seen[0] == 'parity-cobol-runner',
              'fingerprint: runnerImage from the default runner container, never null for a missing name')
        check(sorted(f.name for f in pkg.iterdir() if f.is_file()) == [f'{E}-tests.json', 'evt.sql', 'nouser.sql', 'user.sql'],
              'install: the suite and the fixtures, flat')

        # ---- rotate, carried forward
        doc = script('rotate.py', '--run-id', 'run-1')
        check(doc.get('rotated') is True and (prev / f'{E}-tests.json').is_file() and (prev / f'{E}.plan.json').is_file()
              and (prev / 'manifest.json').is_file() and (prev / 'user.sql').is_file(),
              'rotate: previous/<E>/ holds the package, the plan and manifest.json')
        doc = script('rotate.py', '--run-id', 'run-1')
        check(doc.get('status') == 'already-rotated', 'rotate: once per run id')
        doc = script('record.py')
        check(doc.get('carried') == 8 and doc.get('probes') == 8, 'second run: base cases carried forward, probed again')
        script('build.py')
        again = json.loads((tmp / f'{E}-tests.json').read_text(encoding='utf-8'))
        same = again['package']['contentHash'] == suite['package']['contentHash']
        if not same:
            was = {c['name']: c for c in suite['cases']}
            for c in again['cases']:
                diff = [k for k in set(c) | set(was.get(c['name'], {})) if c.get(k) != was.get(c['name'], {}).get(k)]
                if diff:
                    print(f"  differs: {c['name']}: {sorted(diff)}", file=sys.stderr)
            print(f"  top level: {[k for k in again if k != 'cases' and again[k] != suite.get(k)]}", file=sys.stderr)
        check(again['package']['version'] == 1 and same, 'unchanged inputs: the same package, same version')
        check({c['name']: c['paragraphs'] for c in again['cases']}['add-ok'] == [f'{E}.P-ADD'],
              'carried case: paragraphs from the cached run')

        # ---- a changed check SQL: a new run key, base cases run again
        plan_now = plan_file.read_text(encoding='utf-8')
        before = json.loads((tmp / 'build.json').read_text(encoding='utf-8'))['runs']
        wh = json.loads(plan_now)
        wh['tables']['lines']['where'] = 'SEQ > 0'
        plan_file.write_text(json.dumps(wh, indent=1), encoding='utf-8')
        doc = script('record.py')
        check(doc.get('carried') == 0 and doc.get('recorded', 0) > 0, 'check SQL changed: base cases run again, not carried')
        doc = script('build.py')
        after = json.loads((tmp / 'build.json').read_text(encoding='utf-8'))['runs']
        check(any('check SQL changed: lines' in u for u in doc.get('updated') or []) and not doc.get('regressions'),
              'check SQL changed: an update naming the check, no regression')
        check(after['add-ok'] != before['add-ok'] and after['delete-ok'] != before['delete-ok'],
              'check SQL changed: new run keys for the cases with that check')
        plan_file.write_text(plan_now, encoding='utf-8')
        doc = script('record.py')
        check(doc.get('carried') == 8, 'check SQL as recorded again: base cases carried forward')
        script('build.py')

        script('record.py', '--force', mode='changed')
        doc = script('build.py', mode='changed', expect=2)
        check(doc.get('status') == 'regressions' and any('recorded outcome differs' in r for r in doc.get('regressions') or []),
              'changed program: a regression, exit 2')
        script('build.py', '--install', mode='changed', expect=2)

        f = fixtures / 'user.sql'
        f.write_text(f.read_text() + '-- edited\n', encoding='utf-8')
        script('record.py', mode='changed')
        doc = script('build.py', mode='changed')
        check(any('fixture changed' in u for u in doc.get('updated') or []), 'changed fixture: cases updated, not regressions')
        v2 = json.loads((tmp / f'{E}-tests.json').read_text(encoding='utf-8'))
        check(v2['package']['version'] == 2, 'changed content: version 2')

        # ---- refusals: the probe clock, a decision's source, conflicting answers
        good = plan_file.read_text(encoding='utf-8')

        def refused(change, what, *texts):
            bad = json.loads(good)
            change(bad)
            plan_file.write_text(json.dumps(bad, indent=1), encoding='utf-8')
            for name in ('record.py', 'build.py') if what.startswith('probe') else ('build.py',):
                d = script(name, expect=1)
                check(all(t in json.dumps(d) for t in texts), f'{name} refuses {what}')
            plan_file.write_text(good, encoding='utf-8')
        refused(lambda x: x['defaults'].update(probeClock=x['defaults']['clock']), 'probeClock = clock', 'probeClock')
        refused(lambda x: x['defaults'].pop('probeClock'), 'probe clock missing', 'probeClock')
        rj = json.loads((tmp / 'record.json').read_text(encoding='utf-8'))
        check(rj.get('status') == 'failed' and len(rj.get('failures') or []) == 1
              and 'probeClock' in rj['failures'][0]['reason'] and rj.get('finishedAt'),
              'record: a failed run leaves record.json status failed with its failure')
        refused(lambda x: x['decisions']['clock'].update(source='PAR-U-01'), 'a decision citing a v1 register row', 'source')

        # ---- a decided answer on an open source: pending, expected stays the recorded answer
        for src, why in (('PQ-4', 'PQ-4 is open'), ('PQ-9', 'PQ-9 is not in'), ('OQ-2', 'OQ-2 is open'),
                         ('design.md#nowhere', 'no heading anchor #nowhere')):
            pend = json.loads(good)
            pend['decisions']['nouser']['source'] = src
            plan_file.write_text(json.dumps(pend, indent=1), encoding='utf-8')
            d = script('build.py', mode='changed')
            nu = {c['name']: c for c in json.loads((tmp / f'{E}-tests.json').read_text(encoding='utf-8'))['cases']}['add-nouser']
            da = nu.get('decidedAnswer') or {}
            check(nu['expected']['status'] == 404 and da.get('pending') is True and why in da.get('reason', '')
                  and da.get('status') == 422 and da.get('recorded') == nu['expected']
                  and any(t.startswith(f'{src}: ') for t in nu['anticipatedJavaDivergence'])
                  and len(d.get('pendingDecisions') or []) == 1 and not any('add-nouser' in x for x in d.get('decided') or []),
                  f'pending decision ({src}): text kept, expected not replaced, decidedAnswer.pending with the reason')
        rep = (tmp / 'build-report.md').read_text(encoding='utf-8')
        check('add-nouser: 404 -> 422 by design.md#nowhere not applied' in rep.split('## Pending decisions (1)')[1].split(chr(10) + '## ')[0],
              'report: Pending decisions section')
        plan_file.write_text(good, encoding='utf-8')
        d = script('build.py', mode='changed')
        check(not d.get('pendingDecisions') and len(d.get('decided') or []) == 2,
              'decided sources (OQ settled, PQ answered, design.md {#D-2} anchor): no pending decision')
        refused(lambda x: x['decisions'].update(other={'when': 'legacy:respCode=1&operation:add', 'source': 'PQ-4', 'text': 'x',
                                                       'answer': {'status': 409, 'tables': 'recorded'}}),
                'conflicting answers on one case', 'different answers')
        refused(lambda x: x['cases'][0].update(name='Add_OK'), 'a case name not kebab-case', 'kebab-case', 'Add_OK')
        nost = json.loads(good)
        nost['suiteHeader'].pop('statuses')
        plan_file.write_text(json.dumps(nost, indent=1), encoding='utf-8')
        script('build.py', mode='changed')
        st = json.loads((tmp / f'{E}-tests.json').read_text(encoding='utf-8'))['statuses']
        check(st == {**b.STATUS_TEXTS, **json.loads((prev / f'{E}-tests.json').read_text(encoding='utf-8'))['statuses']}
              and sorted(st) == sorted(b.STATUSES), 'statuses: the three keys always written')
        prev_suite = prev / f'{E}-tests.json'
        kept_prev = prev_suite.read_text(encoding='utf-8')
        nb = json.loads(kept_prev)
        nb.pop('statuses')
        prev_suite.write_text(json.dumps(nb), encoding='utf-8')
        script('build.py', mode='changed')
        st = json.loads((tmp / f'{E}-tests.json').read_text(encoding='utf-8'))['statuses']
        check(st == b.STATUS_TEXTS, 'statuses: default texts when neither plan nor base has them')
        prev_suite.write_text(kept_prev, encoding='utf-8')
        plan_file.write_text(good, encoding='utf-8')
        refused(lambda x: x.update(divergenceRules={'r': {'when': 'case:add-ok', 'text': 'x'}}), 'divergenceRules',
                'divergenceRules')

        # ---- db.py against the stand-in (its CLP knows no table)
        doc = script('db.py', '--check', expect=2)
        check(doc.get('status') == 'tables-missing' and doc.get('schema') == 'TSCHEMA', 'db.py --check: tables missing, schema')
        doc = script('db.py', '--reset')
        check(doc.get('reset', {}).get('emptied') == ['LINES', 'EVT', 'USERS'], 'db.py --reset: children first')

        # ---- usage errors are JSON too
        script('build.py', '--no-such-flag', expect=1)
    finally:
        if holder:
            holder.cleanup()
    print(f"{'all checks hold' if not failures else str(len(failures)) + ' check(s) failed'}", file=sys.stderr)
    print(json.dumps({'status': 'ok' if not failures else 'failed', 'passed': len(passed), 'failed': failures}))
    return 1 if failures else 0


if __name__ == '__main__':
    sys.exit(main())
