# The package: `tests/package/<E>/<E>-tests.json`

Written only by `build.py`. Detail: `schema/tests.schema.json`. Top-level keys, in order:

| key | content |
|---|---|
| `package` | `schema`, `format` 3, `version`, `contentHash`, `generator` {name, scriptsHash, parityTester}, `inputs`, `state` |
| `unit` | the entry point |
| `api` | one line from plan `suiteHeader.api` |
| `binding` | plan `api` without `_` keys; `null` = COBOL-only baseline |
| `goldenMaster` | plan text, newest recording date filled in |
| `comparison` / `comparisonRules` | fixed: STATUS, BODY_WHOLE_ON_2XX, OUTCOME_ONLY_ON_ERROR, EMPTY_MEANS_NO_BODY, RTRIM, NULL_AS_BLANK, NUMBERS_BY_VALUE, ARRAYS_IN_ORDER, CASE_COMPARE, TABLES_AFTER_CALL, STATE_BEFORE_CALL |
| `resetTables` | every table of `unit/schema.sql`, children first; emptied before every case, then the fixture |
| `statuses` | plan `suiteHeader.statuses`, else the base suite's; golden, not-representable, not-recorded always present (default texts) |
| `legacySchema` | plan `outputs` verbatim + `tables` {check: table, columns with DDL type, orderBy, compare} |
| `rules` | `design/rules.md` rows: {id `R<n>`, text, provenBy [golden case ids]} |
| `coverage` | coverage.py over golden runs (never a probe): totals (with `outsideLines`), programs, paragraphs, cases, outside, notEntered |
| `recordings` | fingerprint id -> members, driver, fixture, ddl, shims, runnerImage, db2Image, database, env |
| `cases` | below |

## Case keys, in order

| key | content |
|---|---|
| `id`, `name`, `origin`, `category`, `about`, `ruleIds` | from the plan; a base case keeps id and name |
| `status` / `reason` | below; `reason` on every non-golden case |
| `fixture`, `clock` | file of the package folder; the run's clock |
| `clockSensitive` | the probe run aborted or differed, or a fired decision is `clockDependent` |
| `request` | {method, path, <path values>, query, principal?, url, body?}; `null` when not-representable |
| `expected` | {status, body \| empty, tables?: [{name, query, columns, rows, compare}]}; `null` unless golden |
| `decidedAnswer` | a decision's `answer` replaced `expected`: {source, rules, status, recordedStatus, set?, tables?, recorded}; `pending: true` + `reason` when the source is not decided: `expected` stays the recorded answer |
| `compare` | [{path, mode set\|ignore, reason}] |
| `anticipatedJavaDivergence` / `stackDivergence` | texts of the fired kind java / kind stack decisions |
| `design` | basic cases: the `design/tests.md` block |
| `paragraphs` | PROG.PARA the golden run executed |
| `recording` | {recordedAt, fingerprint, parityTester, repeats, runIds} |
| `legacy` | plan `outputs` read from the run, + `verify` (raw CLP rows per check), + `technicalFailure` when flagged |

## Statuses

| status | when | request / expected |
|---|---|---|
| `golden` | recorded, repeats agree | set (with an api) |
| `not-representable` | plan says so, or an unspellable `\|enum` variant | null / null; legacy kept |
| `not-recorded` | run aborted (reason: runtime error line) or repeats disagree (`not repeatable`) | request kept / null |

## Seal

- `contentHash` = sha256 of canonical JSON (sorted keys, compact, UTF-8) of the document without `package`; `version` + 1 when it changes.
- `package.inputs` (sha256 of `design/rules.md`, `design/tests.md`, `extracted-logic/paragraph-index.json`, `unit/schema.sql`) and `package.state` (state.py) are outside the seal.

Limit: response headers (e.g. `Location`) are not part of the binding.
