"""The questions that wait for a person, across the commands (decision 6), and the next move.

  OQ  design/design-open-questions.md            mu-design
  IQ  implement/implement-open-questions.md      mu-implement
  PQ  tests/tests-open-questions.md              mu-build-tests
  VQ, RG  validation/validation-open-questions.md   mu-validate

One list, blocking first, each with its file, status and blocking flag. The next move names the command to run
(`/mu-implement`, `/mu-build-tests`, `/mu-validate`, `/mu-report --confirm`; `/pipelines:...` in the plugin).
"""

from __future__ import annotations

from pathlib import Path

from .common import read_text
from .mufiles import Mu

FILES = (("design", "design-open-questions.md", "mu-design"),
         ("implement", "implement-open-questions.md", "mu-implement"),
         ("tests", "tests-open-questions.md", "mu-build-tests"),
         ("validation", "validation-open-questions.md", "mu-validate"))
PREFIX_ORDER = ("OQ", "IQ", "PQ", "VQ", "RG")


def _key(item: dict) -> tuple:
    prefix, _, number = item["id"].partition("-")
    try:
        n = float(number)
    except ValueError:
        n = 0.0
    return (0 if item.get("blocking") else 1, PREFIX_ORDER.index(prefix) if prefix in PREFIX_ORDER else 9, n)


def collect(mu: Mu) -> dict:
    """Every question of the four files: per file its counts, and one list of the open ones, blocking first."""
    from . import l0                                  # the shared parser of the open-questions template
    files, items = [], []
    for folder, name, owner in FILES:
        path = mu.folder / folder / name
        q = l0.questions(read_text(path), mu.rel(path))
        files.append({"file": mu.rel(path), "present": q["present"], "owner": owner, "total": q["total"],
                      "open": q["open"], "answered": q["answered"], "settled": q["settled"],
                      "blockingOpen": q["blockingOpen"],
                      "ids": sorted({i["id"].split("-")[0] for i in q["items"]}, key=PREFIX_ORDER.index)})
        for i in q["items"]:
            items.append({"id": i["id"], "title": i["title"], "file": mu.rel(path), "owner": owner,
                          "step": i.get("step"), "status": i.get("status") or ("answered" if i["answered"] else "open"),
                          "blocking": bool(i.get("blocking")), "answered": i["answered"],
                          "question": i.get("question"), "decision": i.get("decision"), "affects": i.get("affects"),
                          "answer": i.get("answer")})
    open_items = sorted((i for i in items if not i["answered"]), key=_key)
    by_prefix = {}
    for i in items:
        p = i["id"].split("-")[0]
        row = by_prefix.setdefault(p, {"total": 0, "open": 0, "blockingOpen": 0})
        row["total"] += 1
        row["open"] += 0 if i["answered"] else 1
        row["blockingOpen"] += 1 if i["blocking"] and not i["answered"] else 0
    return {"files": files, "open": open_items, "answered": [i for i in items if i["answered"]],
            "total": len(items), "openCount": len(open_items),
            "blockingOpen": sum(1 for i in open_items if i["blocking"]), "byPrefix": by_prefix}


def next_move(mu: Mu, l0: dict, build: dict, lc: dict, l4: dict, questions: dict) -> dict | None:
    """The command to run next, in the pipeline's order: a blocking question first, then the first level that waits
    for a command, then what the failures of the last run ask for (as mu-validate classified them), then the
    product's own suites."""
    blocking = [i for i in questions["open"] if i["blocking"]]
    if blocking:
        first = blocking[0]
        ids = ", ".join(i["id"] for i in blocking if i["owner"] == first["owner"])
        return {"level": "Questions", "command": mu.command(first["owner"]), "owner": "a named person",
                "why": f"{ids} in {first['file']} blocks {first['owner']}: answer it on the Answer line, then run "
                       f"{mu.command(first['owner'])}"}
    gate = (l4.get("gate") or {}) if isinstance(l4, dict) else {}
    if gate.get("open"):
        return {"level": "L4", "command": mu.command("mu-validate"), "owner": "a named person",
                "why": f"the record gate {gate['open']} waits for a named person's answer in "
                       "validation/validation-open-questions.md; then mu-validate applies it and replays"}
    if lc.get("state") == "results" and lc.get("packageState") != "ready":
        return {"level": "LC", "command": mu.command("mu-build-tests"), "owner": "mu-build-tests",
                "why": f"the test package is {lc.get('packageState')}"}
    candidates = [("L0", l0["phases"]["design"]), ("L0", l0["phases"]["implementation"]), ("LC", lc), ("L4", l4)]
    for layer, level in candidates:
        if level.get("state") in ("not_produced", "not_reached", "not_run") and level.get("next"):
            return {"level": layer, "command": level["next"], "owner": level.get("owner"), "why": level.get("reason")}
    if l4.get("state") == "results":
        hashes = l4.get("hashes") or {}
        classes = l4.get("classes") or {}
        listed = classes.get("listed") or {}
        if listed.get("BINDING") or listed.get("PACKAGE"):
            n = listed.get("BINDING", 0) + listed.get("PACKAGE", 0)
            return {"level": "L4", "command": mu.command("mu-build-tests"), "owner": "mu-build-tests",
                    "why": f"BINDING/PACKAGE {n}: the package's binding or recordings, as mu-validate classified them "
                           f"in {classes.get('file')}"}
        if listed.get("SOLUTION"):
            rules = "; ".join(f"{r['id']}" + (f" ({r['home']})" if r.get("home") else "") + f" x{len(r['scenarios'])}"
                              for r in classes.get("suspectRules") or [] if "SOLUTION" in r.get("classes", []))
            return {"level": "L4", "command": mu.command("mu-implement"), "owner": "mu-implement",
                    "why": f"SOLUTION {listed['SOLUTION']} in {classes.get('file')}"
                           + (f": suspect rules {rules}" if rules else "")}
        if listed.get("ENVIRONMENT"):
            return {"level": "L4", "command": mu.command("mu-validate"), "owner": "environment",
                    "why": f"ENVIRONMENT {listed['ENVIRONMENT']}: fix the environment (database, configuration), "
                           "then replay"}
        if listed.get("UNKNOWN"):
            return {"level": "L4", "command": mu.command("mu-validate"), "owner": "a person (question)",
                    "why": f"UNKNOWN {listed['UNKNOWN']}: answer the questions in {classes.get('file')}"}
        if l4["counts"].get("FAILED") and not classes.get("ofRun"):
            return {"level": "L4", "command": mu.command("mu-validate"), "owner": "mu-validate",
                    "why": "the failures of the last run are not classified (failures.md is not of this run)"}
        if (hashes.get("product") or {}).get("isCurrent") is False or (hashes.get("package") or {}).get("isCurrent") \
                is False:
            return {"level": "L4", "command": mu.command("mu-validate"), "owner": "mu-validate",
                    "why": "the product or the package has changed since the last run"}
    if build.get("state") in ("not_run", "not_reached", "not_produced") and build.get("next"):
        return {"level": "L1-L3", "command": build["next"], "owner": build.get("owner"), "why": build.get("reason")}
    return None


def input_files(mu: Mu) -> list[Path]:
    return [mu.folder / folder / name for folder, name, _ in FILES if (mu.folder / folder / name).is_file()]
