"""Maven for mu-report (--confirm): batch mode, logged, validation/target/m2 the only written repository and
~/.m2/repository a read-only tail (Maven 3.9+). MU_REPORT_MVN replaces mvn (a JSON array; selftest stand-ins)."""

from __future__ import annotations

import json
import os
from pathlib import Path

from .common import Stop, run, which


def mvn_cmd() -> list[str]:
    over = os.environ.get("MU_REPORT_MVN")
    if over:
        try:
            value = json.loads(over)
            if isinstance(value, list) and value:
                return [str(x) for x in value]
        except ValueError:
            pass
        return [over]
    found = which("mvn")
    if not found:
        raise Stop("Maven (mvn) is not on PATH: install Maven 3.9+ and retry")
    return [found]


def repo_flags(head: Path, tail: Path | None) -> list[str]:
    flags = [f"-Dmaven.repo.local={head}"]
    if tail is not None:
        flags.append(f"-Dmaven.repo.local.tail={tail}")
    return flags


def mvn(arguments: list[str], cwd: Path, log: Path, head: Path, tail: Path | None, timeout: int = 3600,
        env: dict | None = None) -> tuple[int, str]:
    """`env`: the whole environment of the build (None = inherited); never logged, it may hold credentials."""
    return run([*mvn_cmd(), "-B", "-ntp", *repo_flags(head, tail), *arguments], cwd=cwd, timeout=timeout, log=log,
               env=env)
