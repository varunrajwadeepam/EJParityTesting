"""The test results report of one MU as a document: every level of the test pyramid (L0 to L4, LC under them), each
with its status AND its state - a level with nothing to show says why and whose move it is (owner, next command).
Every number is counted here from the files; nothing is estimated, and nothing is a verdict.
"""

from __future__ import annotations

from pathlib import Path

from . import l0 as l0lib, parity, questions as qlib, suites, tests_level
from .common import SKILLS, file_sha, iso_now, rel, sha256
from .levels import LAYERS, STATE_LABELS, severity, worst
from .mufiles import Mu, identity, product_module

REPORT_FORMAT = 2          # part of the inputs fingerprint: bump it when the content changes, so every page rebuilds


def _plural(n: int, word: str, plural: str | None = None) -> str:
    return f"{n:,} {word if n == 1 else (plural or word + 's')}"


# --------------------------------------------------------------------------- layers


def _absent_row(level: dict) -> dict:
    return {"status": "none", "state": level.get("state") or "not_run",
            "headline": level.get("short") or level.get("reason") or "not run",
            "owner": level.get("owner"), "next": level.get("next")}


def _l0_row(l0: dict) -> dict:
    if l0.get("state") != "results":
        return _absent_row(l0)
    parts = []
    for key, label in (("design", "design"), ("implementation", "implementation")):
        phase = l0["phases"][key]
        if not phase["present"]:
            parts.append(f"{label} {STATE_LABELS[phase['state']].lower()}")
        elif phase["steps"] and phase["stepsDone"] == len(phase["steps"]):
            parts.append(f"{label} complete")
        else:
            parts.append(f"{label} {phase['stepsDone']} of {len(phase['steps'])} steps")
    total = sum(l0["openQuestions"].values())
    if total:
        parts.append(_plural(total, "open question"))
    return {"status": l0["status"], "state": "results", "headline": "; ".join(parts)}


def _level_row(build: dict, lv: str) -> dict:
    if not build.get("available"):
        return _absent_row(build)
    info = build["levels"][lv]
    t = info["totals"]
    if not t["tests"]:
        return {"status": info["status"], "state": "results", "headline": "no tests at this level"}
    headline = f"{t['passed']:,} of {_plural(t['tests'], 'test')} passed"
    if t["failures"] or t["errors"]:
        headline += f", {t['failures'] + t['errors']:,} failed"
    if t["skipped"]:
        headline += f", {t['skipped']:,} skipped"
    if lv == "L3":
        headline += " · real Db2" if info.get("realDb2") else " · in-memory database" if info.get("inMemory") else ""
    return {"status": info["status"], "state": "results", "headline": headline}


def _evidence_row(level: dict) -> dict:
    if level.get("state") != "results":
        return _absent_row(level)
    return {"status": level["status"], "state": "results", "headline": level.get("headline") or ""}


def layers(l0: dict, build: dict, lc: dict, l4: dict) -> list[dict]:
    rows = []
    for layer, name, band, in_scope in LAYERS:
        if layer == "L0":
            row = _l0_row(l0)
        elif layer in ("L1", "L2", "L3"):
            row = _level_row(build, layer)
        elif layer == "L4":
            row = _evidence_row(l4)
        elif layer == "LC":
            row = _evidence_row(lc)
        elif layer == "L5":
            row = {"status": "none", "state": "planned", "headline": "planned: real-mainframe parity"}
        elif layer == "L6":
            row = {"status": "none", "state": "out_of_scope", "headline": "run and signed off by the client"}
        else:
            row = {"status": "none", "state": "out_of_scope", "headline": "not in this release"}
        rows.append({"id": layer, "name": name, "band": band, "inScope": in_scope,
                     "stateLabel": STATE_LABELS[row["state"]], **row})
    return rows


# --------------------------------------------------------------------------- attention, overall, measures, gaps, next


def gaps(l0: dict, build: dict, lc: dict, l4: dict) -> list[dict]:
    """Everything that is open, not run or not reached - each with its owner. `status` orders it (fail first)."""
    found = []

    def add(layer, status, item, owner, command=None):
        found.append({"layer": layer, "status": status, "item": item, "owner": owner, "next": command})

    for key, title in (("design", "Design"), ("implementation", "Implementation")):
        phase = l0["phases"][key]
        owner = l0lib.OWNERS[key]
        if not phase["present"]:
            add("L0", "none", f"{title}: {phase['reason']}", phase.get("owner"), phase.get("next"))
            continue
        if phase.get("blocked"):
            add("L0", "fail", f"{title}: a step is blocked - {phase['blocked']}", owner)
        undone = [s["step"] for s in phase["steps"] if s["status"].lower() not in l0lib.DONE]
        if undone:
            add("L0", "warn", f"{title}: steps not done - {', '.join(undone)}", owner)
        q = phase["questions"]
        if q["open"]:
            ids = ", ".join(i["id"] for i in q["items"] if not i["answered"])
            add("L0", "warn", f"{title}: {_plural(q['open'], 'open question')} waiting for an answer ({ids})",
                "architect / MU owner")
        rv = phase["review"]
        open_high, open_medium = rv["openBySeverity"]["High"], rv["openBySeverity"]["Medium"]
        if open_high or open_medium:
            add("L0", "warn", f"{title}: open review findings - {open_high} high, {open_medium} medium", owner)
        gate_key, gate_name = ("ruleCoverage", "rule-coverage gate") if key == "design" else \
            ("traceability", "traceability gate")
        gate = phase.get(gate_key) or {}
        if not gate.get("ran"):
            add("L0", "none", f"{title}: {gate_name} {gate.get('reason') or 'not re-run'}", owner)
        elif gate.get("status") != "pass":
            add("L0", "warn", f"{title}: {gate_name} - {(gate.get('business') or 0) - (gate.get('covered') or 0)} "
                              f"business paragraph(s) neither cited nor exempt", owner)
    if not build.get("available"):
        add("L1-L3", "none", build.get("reason") or "the product's suites were not run", build.get("owner"),
            build.get("next"))
    else:
        for lv in ("L1", "L2", "L3"):
            info = build["levels"][lv]
            if info["failing"]:
                add(lv, "fail", f"{_plural(len(info['failing']), 'failing test')} in the product's {lv} suite",
                    "mu-implement")
            for note in info.get("notes") or []:
                if "skipped" in note or "not built" in note or "coverage" in note:
                    add(lv, "warn", note, "mu-implement")
        if build.get("mode") == "fast" and build.get("source") == "last-build":
            add("L1-L3", "none", "the product's own last build was read, not re-run on a known content hash", "mu-report")
    for layer, level in (("LC", lc), ("L4", l4)):
        if level.get("state") != "results":
            add(layer, "none", level.get("reason"), level.get("owner"), level.get("next"))
    if lc.get("state") == "results":
        if lc["packageState"] != "ready":
            add("LC", "fail" if lc["packageState"] in ("blocked", "failed") else "warn",
                f"the test package is {lc['packageState']}"
                + (" (" + ", ".join(f"{k}: {v}" for k, v in lc["reasons"].items()) + ")" if lc.get("reasons") else ""),
                "mu-build-tests", lc.get("next"))
        pq = lc["questions"]
        if pq["open"]:
            ids = ", ".join(i["id"] for i in pq["items"] if not i["answered"])
            add("LC", "fail" if pq["blockingOpen"] else "warn",
                f"{_plural(pq['open'], 'open question')} of the test package waiting for an answer ({ids}"
                + (f"; {pq['blockingOpen']} blocking" if pq["blockingOpen"] else "; none blocking") + ")",
                "SME / MU owner")
        if lc["stale"]:
            add("LC", "warn", "the package is stale: " + ", ".join(map(str, lc["stale"])), "mu-build-tests")
        if lc["countsDisagree"] or lc["coverage"]["disagree"]:
            add("LC", "warn", "tests-state.json and the package disagree on "
                + ", ".join(lc["countsDisagree"] + lc["coverage"]["disagree"]), "mu-build-tests")
        unproven = lc["rules"]["unproven"]
        if unproven:
            add("LC", "none", f"{_plural(len(unproven), 'rule')} of {lc['rules']['total']} without a proving case ("
                + ", ".join(r["id"] for r in unproven) + ")", "mu-build-tests")
        if lc["uncovered"]:
            missing = [u["paragraph"] for u in lc["uncovered"] if not u["reason"]]
            add("LC", "warn" if missing else "none",
                f"{_plural(len(lc['uncovered']), 'business paragraph')} no case reaches"
                + (" - without a reason in the arms table: " + ", ".join(missing) if missing else
                   " (reasons in the arms table)"), "mu-build-tests")
    if l4.get("state") == "results":
        classes = l4["classes"]
        if classes["ofRun"]:
            for cls, n in classes["listed"].items():
                rules = [r["id"] for r in classes["suspectRules"] if cls in r["classes"]]
                add("L4", "fail", f"{_plural(n, 'scenario')} differ{'s' if n == 1 else ''} from the legacy - class "
                    f"{cls}" + ((" - suspect rule " if len(rules) == 1 else " - suspect rules ") + ", ".join(rules)
                                if rules else ""), parity.CLASS_OWNER.get(cls) or "-")
        elif l4["counts"]["FAILED"]:
            add("L4", "fail", f"{_plural(l4['counts']['FAILED'], 'scenario')} differ from the legacy, not classified "
                "for this run", "mu-validate")
        if l4["counts"]["BLOCKED"]:
            add("L4", "warn", f"{_plural(l4['counts']['BLOCKED'], 'scenario')} blocked", "mu-validate")
        if not l4.get("repeatable"):
            add("L4", "warn", f"the runs differ ({l4['differencesBetweenRuns']} differences between runs)",
                "mu-validate")
        for w in l4.get("warnings") or []:
            add("L4", "warn", w, "mu-validate")
        vq = l4["questions"]
        if vq["open"]:
            add("L4", "fail" if vq["blockingOpen"] else "warn",
                f"{_plural(vq['open'], 'open question')} of mu-validate waiting for an answer ("
                + ", ".join(i["id"] for i in vq["items"] if not i["answered"]) + ")", "a named person")
    add("L5", "none", "real-mainframe parity: planned", "project")
    add("L6", "none", "user acceptance: run and signed off by the client", "client")
    add("L7 / L8", "none", "non-functional checks and test effectiveness: not in this release", "project")
    return found


def attention(found: list[dict], limit: int = 6) -> list[dict]:
    """The items a reader acts on first: failures, then warnings - each with its owner."""
    ranked = sorted((g for g in found if g["status"] in ("fail", "warn")), key=lambda g: -severity(g["status"]))
    return ranked[:limit]


def overall(layer_rows: list[dict], l4: dict) -> dict:
    """The worst status of the levels with results, one line per level in scope, and the sentence of L4."""
    in_scope = [r for r in layer_rows if r["inScope"]]
    reached = [r["id"] for r in in_scope if r["state"] == "results"]
    lines = [{"level": r["id"], "status": r["status"] if r["state"] == "results" else "none",
              "state": r["state"], "text": r["headline"]} for r in in_scope]
    if l4.get("state") == "results":
        status = worst(r["status"] for r in in_scope if r["state"] == "results")
        return {"status": status, "label": None, "sentence": l4.get("sentence") or l4.get("headline") or "",
                "lines": lines}
    reason = str(l4.get("reason") or "").rstrip(".")
    so_far = f"Results so far: {', '.join(reached)}." if reached else "No level has results yet."
    return {"status": "none", "label": "In progress", "lines": lines,
            "sentence": f"Parity with the legacy (L4) is not reached yet - {reason}. {so_far}"}


def _pct(part, whole) -> str:
    return f"{100.0 * part / whole:.1f}%" if whole else "-"


def measures(build: dict, lc: dict, l4: dict) -> list[dict]:
    """The key measures of the Test Strategy this evidence can compute today."""
    rows = []
    if lc.get("state") == "results":
        lines = lc["coverage"]["lines"]
        share = lc["coverage"]["linesPercent"]
        rows.append({"measure": "Legacy statement coverage", "definition": "code lines of the business paragraphs "
                     "the cases execute (package coverage)",
                     "value": f"{share}% ({lines.get('covered')} of {lines.get('code')} lines)"
                     if share is not None else "-", "target": "at least 90%",
                     "status": "none" if share is None else "pass" if share >= 90 else "warn"})
    else:
        rows.append({"measure": "Legacy statement coverage", "definition": "legacy statements the cases execute",
                     "value": lc.get("short") or "not reached", "target": "at least 90%", "status": "none"})
    if l4.get("state") == "results":
        rows.append({"measure": "Reproducibility", "definition": "identical results on unchanged inputs",
                     "value": f"{l4.get('runs')} runs " + ("identical" if l4.get("identical") else
                                                         f"with {l4.get('differencesBetweenRuns')} differences"),
                     "target": "100%", "status": "pass" if l4.get("identical") else "warn"})
    else:
        rows.append({"measure": "Reproducibility", "definition": "identical results on unchanged inputs",
                     "value": l4.get("short") or "not reached", "target": "100%", "status": "none"})
    if build.get("available"):
        mu_row = next((m for m in build["modules"] if m["role"] == "mu"), None)
        ratio = ((mu_row or {}).get("lineCoverage") or {}).get("ratio")
        if ratio is not None:
            rows.append({"measure": f"Line coverage ({mu_row['artifactId']})", "definition": "lines of the MU module "
                         "the product's tests execute (JaCoCo)", "value": f"{ratio * 100:.1f}%",
                         "target": "at least 80%", "status": "pass" if ratio >= 0.80 else "fail"})
        skipped = sum(build["levels"][lv]["totals"]["skipped"] for lv in ("L1", "L2", "L3"))
        rows.append({"measure": "Skipped tests", "definition": "required tests skipped (each one to explain)",
                     "value": f"L1-L3 {skipped}", "target": "0 unexplained", "status": "warn" if skipped else "pass"})
    else:
        rows.append({"measure": "Line coverage", "definition": "lines of the MU module the product's tests execute "
                     "(JaCoCo)", "value": build.get("short") or "not run", "target": "at least 80%", "status": "none"})
    rows.append({"measure": "Planted-defect detection", "definition": "planted critical defects caught by the parity "
                 "layers", "value": "not run (L8)", "target": "at least 90%", "status": "none"})
    return rows


# --------------------------------------------------------------------------- inputs and the document


def input_files(mu: Mu, mode: str, product: dict | None) -> list[Path]:
    """Every file the report reads (besides the solution, which counts by its content hash)."""
    files = [mu.folder / "mu.yaml", mu.tools_file]
    files += l0lib.input_files(mu)
    files += suites.input_files(mu, product)
    files += tests_level.input_files(mu)
    files += parity.input_files(mu)
    files += qlib.input_files(mu)
    seen, unique = set(), []
    for f in files:
        key = str(f.resolve())
        if f.is_file() and key not in seen:
            seen.add(key)
            unique.append(f)
    return unique


def _key(path: Path, mu: Mu) -> str:
    """An input's name: relative to the workspace; the command's own scripts (gate scripts) as `.claude/...` also
    when the workspace is another folder (`--workspace`), so a copied workspace keeps the same names."""
    shown = rel(path, mu.workspace)
    if shown.startswith("../"):
        tools = SKILLS.parent.resolve()
        try:
            return ".claude/" + Path(path).resolve().relative_to(tools).as_posix()
        except ValueError:
            pass
    return shown


def inputs(files: list[Path], mu: Mu) -> dict[str, str]:
    return {_key(f, mu): file_sha(f) for f in sorted(files, key=lambda p: _key(p, mu))}


def fingerprint(digests: dict[str, str], product: dict | None, mode: str) -> str:
    lines = [f"format\t{REPORT_FORMAT}", f"mode\t{mode}", f"solution\t{(product or {}).get('hash')}"]
    lines.extend(f"{path}\t{digest}" for path, digest in sorted(digests.items()))
    return sha256("\n".join(lines))


def build(mu: Mu, mode: str, record: dict | None, product: dict | None) -> dict:
    """The report document. `record`: the L1-L3 build record (fast or confirm); `product`: mufiles.identity."""
    l0 = l0lib.read(mu, mu.scratch)
    module = product_module(mu)
    build_levels = suites.levels(record, (module or {}).get("artifactId"))
    lc = tests_level.read(mu, l0["phases"]["design"]["present"])
    l4 = parity.read(mu, lc, product)
    rows = layers(l0, build_levels, lc, l4)
    found = gaps(l0, build_levels, lc, l4)
    asked = qlib.collect(mu)
    digests = inputs(input_files(mu, mode, product), mu)
    return {
        "schemaVersion": 1, "reportFormat": REPORT_FORMAT, "generatedBy": "mu-report", "generatedAt": iso_now(),
        "mode": mode, "mu": {"name": mu.name, "description": mu.manifest.get("description"),
                             "du": mu.manifest.get("du"), "entryPoints": mu.entries, "folder": mu.mu_arg},
        "product": {k: v for k, v in product.items() if k != "manifest"} if product else None,
        "productModule": module, "productFiles": (product or {}).get("manifest"),
        "inputsFingerprint": fingerprint(digests, product, mode),
        "overall": overall(rows, l4), "attention": attention(found),
        "next": qlib.next_move(mu, l0, build_levels, lc, l4, asked),
        "layers": rows, "l0": l0, "build": build_levels, "lc": lc, "l4": l4, "questions": asked,
        "measures": measures(build_levels, lc, l4), "gaps": found,
        "sources": list(digests), "inputs": digests,
    }


def _changes(before: dict, now: dict, prefix: str = "") -> dict[str, list[str]]:
    return {"added": sorted(prefix + p for p in set(now) - set(before)),
            "removed": sorted(prefix + p for p in set(before) - set(now)),
            "modified": sorted(prefix + p for p in set(now) & set(before) if now[p] != before[p])}


def status(mu: Mu, built: dict) -> dict:
    """`current`, or `changed` with the input files added, removed or modified - the product's own files (by the
    content hash's file list recorded in the page, shown as `<solution>/<path>`) among them - and the product's
    hashes."""
    mode = built.get("mode") or "fast"
    product = identity(mu)
    digests = inputs(input_files(mu, mode, product), mu)
    if built.get("inputsFingerprint") == fingerprint(digests, product, mode):
        return {"status": "current", "generatedAt": built.get("generatedAt"), "mode": mode,
                "product": (product or {}).get("revision")}
    before = built.get("inputs") or {p: None for p in built.get("sources") or []}
    old_hash, new_hash = (built.get("product") or {}).get("hash"), (product or {}).get("hash")
    found = _changes(before, digests)
    product_change = None
    if old_hash != new_hash:
        product_change = {"before": (old_hash or "")[:16] or None, "now": (new_hash or "")[:16] or None}
        recorded = built.get("productFiles")
        if isinstance(recorded, dict) and product:
            files = _changes(recorded, product.get("manifest") or {}, product["solution"].rstrip("/") + "/")
            product_change["files"] = files
            for key in found:
                found[key] = sorted(set(found[key]) | set(files[key]))
    return {"status": "changed", "generatedAt": built.get("generatedAt"), "mode": mode,
            **{k: v[:50] for k, v in found.items()}, "product": product_change,
            "formatChanged": built.get("reportFormat") != REPORT_FORMAT,
            "next": mu.command("mu-report") + (" --confirm" if mode == "confirm" else "")}
