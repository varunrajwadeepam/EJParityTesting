"""LC - legacy characterisation, the oracle of L4: what mu-build-tests keeps in `tests/` (`tests-state.json`,
`tests-report.md`, `tests-open-questions.md`, `package/<E>/<E>-tests.json`, `package/<E>/traceability.md`,
`notes/<E>-arms.md`); acceptance comes from `validation/validation-state.json`. Never `tests/.tmp/` or
`tests/previous/`.

Counts are the ones `tests-state.json` holds; the package's own `cases[]` and `coverage` are counted beside them and
any disagreement is shown, never resolved. Percentages are computed here from the two numbers they are made of.
"""

from __future__ import annotations

import re
from pathlib import Path

from .common import read_json_or_none, read_text
from .levels import absent, worst
from .mdtext import tables
from .mufiles import Mu

STATUSES = ("golden", "not-representable", "not-recorded")
ORIGINS = ("basic", "advanced")
COUNT_KEYS = {"cases": None, "basic": ("origin", "basic"), "advanced": ("origin", "advanced"),
              "golden": ("status", "golden"), "notRepresentable": ("status", "not-representable"),
              "notRecorded": ("status", "not-recorded"), "clockSensitive": ("clockSensitive", True),
              "decided": ("decidedAnswer", True)}
READY = "ready"


def state_file(mu: Mu) -> Path:
    return mu.tests / "tests-state.json"


def package_files(mu: Mu) -> list[Path]:
    return [mu.tests / "package" / e / f"{e}-tests.json" for e in mu.entries]


def entry_of(mu: Mu, st: dict | None) -> str | None:
    entry = (st or {}).get("entry")
    return str(entry) if entry else (mu.entries[0] if mu.entries else None)


def package_path(mu: Mu, entry: str | None, st: dict | None = None) -> Path | None:
    recorded = ((st or {}).get("package") or {}).get("path")
    if recorded and (mu.workspace / recorded).is_file():
        return mu.workspace / recorded
    if entry:
        return mu.tests / "package" / entry / f"{entry}-tests.json"
    return None


def package_doc(mu: Mu, entry: str | None, st: dict | None = None) -> dict | None:
    path = package_path(mu, entry, st)
    doc = read_json_or_none(path) if path else None
    return doc if isinstance(doc, dict) else None


def pct(part, whole) -> float | None:
    """A share in percent with one decimal, from the two numbers of the file (None when the whole is 0)."""
    return round(100.0 * part / whole, 1) if isinstance(part, int) and isinstance(whole, int) and whole else None


# --------------------------------------------------------------------------- the arms table (decision 11)


def arms(text: str | None) -> dict[str, list[dict]]:
    """`notes/<E>-arms.md`: program.paragraph -> its rows {arm, lines, condition, rules, cases}."""
    out: dict[str, list[dict]] = {}
    for t in tables(text or ""):
        low = [h.lower() for h in t["header"]]
        if not low or "program.paragraph" not in low:
            continue
        for r in t["rows"]:
            row = {k.lower(): (v or "").strip() for k, v in r.items()}
            key = row.get("program.paragraph")
            if not key:
                continue
            out.setdefault(key, []).append({
                "arm": row.get("arm id") or None, "lines": row.get("lines") or None,
                "condition": next((v for k, v in row.items() if k.startswith("condition")), "") or None,
                "rules": row.get("rule ids") or None, "cases": row.get("case ids") or None})
    return out


def _reason(rows: list[dict]) -> str | None:
    """The reason an arms row gives for a paragraph no case reaches: its condition and its rule-ids cell."""
    parts = []
    for r in rows:
        text = "; ".join(x for x in (r.get("condition"), r.get("rules")) if x)
        if text:
            parts.append((f"{r['arm']}: " if r.get("arm") else "") + text)
    return " | ".join(parts) or None


def _notes(text: str | None) -> str | None:
    match = re.search(r"^##\s+Notes\s*$(.*?)(?=^##\s|\Z)", text or "", re.M | re.S)
    body = " ".join((match.group(1) if match else "").split())
    return body or None


# --------------------------------------------------------------------------- the package


def _counted(cases: list[dict]) -> dict:
    out = {}
    for key, how in COUNT_KEYS.items():
        if how is None:
            out[key] = len(cases)
        elif how[1] is True:
            out[key] = sum(1 for c in cases if c.get(how[0]))
        else:
            out[key] = sum(1 for c in cases if c.get(how[0]) == how[1])
    return out


def _uncovered(package: dict, arms_rows: dict[str, list[dict]]) -> tuple[list[dict], int]:
    """Business paragraphs no case executed, each with the arms table's reason; and the uncovered mechanism count."""
    rows, mechanism = [], 0
    for p in ((package.get("coverage") or {}).get("paragraphs") or []):
        if not isinstance(p, dict) or p.get("covered"):
            continue
        if p.get("kind") != "business":
            mechanism += 1
            continue
        key = f"{p.get('program')}.{p.get('name')}"
        lines = p.get("lines") or []
        found = arms_rows.get(key) or []
        rows.append({"paragraph": key, "program": p.get("program"), "name": p.get("name"),
                     "lines": f"{lines[0]}-{lines[1]}" if len(lines) == 2 else None,
                     "codeLines": p.get("codeLines"), "reason": _reason(found),
                     "rules": sorted({x for r in found for x in re.findall(r"\bR\d+[a-z]?\b", r.get("rules") or "")},
                                     key=lambda x: int(re.sub(r"\D", "", x) or 0)),
                     "arms": [r["arm"] for r in found if r.get("arm")]})
    return rows, mechanism


def _acceptance(mu: Mu, entry: str | None, content_hash: str | None) -> dict | None:
    """The record gate of mu-validate as `validation-state.json` holds it: settled by whom, when, how many golden
    masters accepted, whether the imported package is the current one."""
    vs = read_json_or_none(mu.validation / "validation-state.json")
    if not isinstance(vs, dict):
        return None
    gate = vs.get("gate") or {}
    imported = (vs.get("imports") or {}).get(entry or "") or {}
    imp = vs.get("import") or {}
    acc = vs.get("acceptance") or {}
    return {"file": mu.rel(mu.validation / "validation-state.json"),
            "gate": gate.get("settled"), "open": gate.get("open"), "by": gate.get("by"), "at": gate.get("at"),
            "accepted": gate.get("accepted"), "disputed": gate.get("disputed") or [],
            "acceptedScenarios": len(acc) if isinstance(acc, dict) else None,
            "goldenStates": imp.get("goldenStates") or {},
            "importedVersion": imported.get("version"), "importedHash": imported.get("contentHash"),
            "importedAt": imported.get("importedAt"),
            "importedIsCurrent": (imported.get("contentHash") == content_hash) if imported and content_hash else None}


def read(mu: Mu, design_present: bool) -> dict:
    """The LC level: evidence with status and state, or a state with its owner and the next command."""
    from . import l0                                  # the shared open-questions parser
    st = read_json_or_none(state_file(mu))
    if not isinstance(st, dict):
        if not design_present:
            return {"present": False, **absent("not_reached", "the design is not there: mu-build-tests builds the "
                                               "package from design/ and unit/", "mu-design", mu.command("mu-design"),
                                               short="waiting for the design")}
        return {"present": False, **absent("not_produced", "tests/tests-state.json is not there: no test package "
                                           "yet", "mu-build-tests", mu.command("mu-build-tests"),
                                           short="no test package yet")}
    entry = entry_of(mu, st)
    ppath = package_path(mu, entry, st)
    package = package_doc(mu, entry, st)
    qfile = mu.tests / "tests-open-questions.md"
    pq = l0.questions(read_text(qfile), mu.rel(qfile))
    state = str(st.get("state") or "unknown")
    if package is None:
        return {"present": True, "entry": entry, "packageState": state, "questions": pq,
                **absent("not_produced", f"tests-state.json is {state}, the package "
                         f"{mu.rel(ppath) if ppath else 'of the entry'} is not there", "mu-build-tests",
                         mu.command("mu-build-tests"), short=f"package {state}, no package file")}
    meta = package.get("package") or {}
    cases = [c for c in package.get("cases") or [] if isinstance(c, dict)]
    counts = {k: (st.get("counts") or {}).get(k) for k in COUNT_KEYS}
    counted = _counted(cases)
    disagree = sorted(k for k in COUNT_KEYS if counts.get(k) is not None and counts[k] != counted[k])
    cov = st.get("coverage") or {}
    para, lines = cov.get("paragraphs") or {}, cov.get("lines") or {}
    totals = (package.get("coverage") or {}).get("totals") or {}
    coverage_disagree = [k for k in ("paragraphs", "lines") if totals.get(k) and cov.get(k) and totals[k] != cov[k]]
    arms_file = mu.tests / "notes" / f"{entry}-arms.md"
    arms_text = read_text(arms_file)
    uncovered, mechanism_uncovered = _uncovered(package, arms(arms_text))
    rules = [r for r in package.get("rules") or [] if isinstance(r, dict) and r.get("id")]
    unproven = [{"id": r["id"], "text": r.get("text")} for r in rules if not r.get("provenBy")]
    trace = mu.tests / "package" / entry / "traceability.md"
    decided_by_source: dict[str, int] = {}
    for c in cases:
        if c.get("decidedAnswer"):
            src = str((c["decidedAnswer"] or {}).get("source"))
            decided_by_source[src] = decided_by_source.get(src, 0) + 1
    not_representable = [{"id": c.get("id"), "name": c.get("name"), "reason": c.get("reason")}
                         for c in cases if c.get("status") == "not-representable"]
    not_recorded = [{"id": c.get("id"), "name": c.get("name"), "reason": c.get("reason")}
                    for c in cases if c.get("status") == "not-recorded"]
    content_hash = meta.get("contentHash") or (st.get("package") or {}).get("contentHash")
    acceptance = _acceptance(mu, entry, content_hash)
    reasons = st.get("reasons") or {}
    stale = st.get("stale") or []
    # status: the package's state first, then what waits for a person
    found = [("pass" if state == READY else "fail" if state in ("blocked", "failed") else "warn",
              None if state == READY else f"package state {state}")]
    if pq["blockingOpen"]:
        found.append(("fail", f"{pq['blockingOpen']} blocking PQ open"))
    elif pq["open"]:
        found.append(("warn", f"{pq['open']} open PQ"))
    if stale:
        found.append(("warn", f"{len(stale)} stale input(s)"))
    if disagree or coverage_disagree:
        found.append(("warn", "tests-state.json and the package disagree"))
    if any(u["reason"] is None for u in uncovered):
        found.append(("warn", "an uncovered paragraph has no reason in the arms table"))
    status = worst(s for s, _ in found)
    notes = [n for _, n in found if n]
    headline = (f"package v{meta.get('version')} {state}: {counts.get('cases')} cases "
                f"({counts.get('golden')} golden, {counts.get('notRepresentable')} not representable"
                + (f", {counts.get('notRecorded')} not recorded" if counts.get("notRecorded") else "")
                + f"); paragraphs {para.get('covered')}/{para.get('total')}, lines {lines.get('covered')}/"
                  f"{lines.get('code')}" + (f"; {pq['open']} open PQ" if pq["open"] else ""))
    return {
        "present": True, "available": True, "state": "results", "status": status, "notes": notes,
        "headline": headline, "short": headline,
        "entry": entry, "packageState": state, "scope": st.get("scope"), "reasons": reasons, "stale": stale,
        "warnings": st.get("warnings") or [], "timestamps": st.get("timestamps") or {},
        "stateFile": mu.rel(state_file(mu)), "packageFile": mu.rel(ppath),
        "packages": [mu.rel(ppath)],
        "package": {"version": meta.get("version"), "format": meta.get("format"), "contentHash": content_hash,
                    "state": meta.get("state"), "generator": meta.get("generator") or {},
                    "goldenMaster": package.get("goldenMaster"), "api": package.get("api"),
                    "comparisonRules": [r.get("id") for r in package.get("comparisonRules") or [] if isinstance(r, dict)]},
        "counts": counts, "countedInPackage": counted, "countsDisagree": disagree,
        "byStatus": {s: sum(1 for c in cases if c.get("status") == s) for s in STATUSES},
        "byOrigin": {o: sum(1 for c in cases if c.get("origin") == o) for o in ORIGINS},
        "byCategory": dict(sorted(((k, sum(1 for c in cases if c.get("category") == k))
                                   for k in {c.get("category") for c in cases if c.get("category")}),
                                  key=lambda kv: -kv[1])),
        "decidedBySource": dict(sorted(decided_by_source.items(), key=lambda kv: (-kv[1], kv[0]))),
        "notRepresentable": not_representable, "notRecorded": not_recorded,
        "coverage": {"paragraphs": para, "lines": lines, "outsideLines": cov.get("outsideLines"),
                     "estimated": cov.get("estimated"),
                     "paragraphsPercent": pct(para.get("covered"), para.get("total")),
                     "linesPercent": pct(lines.get("covered"), lines.get("code")),
                     "packageTotals": {k: totals.get(k) for k in ("paragraphs", "lines", "outsideLines")},
                     "disagree": coverage_disagree, "mechanismUncovered": mechanism_uncovered},
        "uncovered": uncovered, "armsFile": mu.rel(arms_file) if arms_text is not None else None,
        "armsNotes": _notes(arms_text),
        "rules": {"total": len(rules), "proven": len(rules) - len(unproven), "unproven": unproven},
        "traceability": {"present": trace.is_file(), "file": mu.rel(trace) if trace.is_file() else None},
        "questions": pq, "acceptance": acceptance,
    }


def input_files(mu: Mu) -> list[Path]:
    files = [state_file(mu), mu.tests / "tests-report.md", mu.tests / "tests-open-questions.md"]
    st = read_json_or_none(state_file(mu))
    entries = list(dict.fromkeys(([entry_of(mu, st)] if isinstance(st, dict) and entry_of(mu, st) else [])
                                 + mu.entries))
    for e in entries:
        files += [mu.tests / "package" / e / f"{e}-tests.json", mu.tests / "package" / e / "traceability.md",
                  mu.tests / "notes" / f"{e}-arms.md"]
    return [f for f in files if f.is_file()]
