"""Where the product reads the clock past the case clock E2E pins.

The validation boot pins every Spring ``Clock`` bean to the case clock (``ClockPinning``), so code that asks an
injected ``Clock`` runs on the recording's date. Code that reads the system clock itself does not: a
``Clock.systemDefaultZone()`` outside a ``@Bean`` method, a ``LocalDate.now()`` / ``Instant.now()`` ... without a clock,
``System.currentTimeMillis()``, ``new Date()``, and SQL's ``CURRENT DATE`` (the database server's clock). This module
finds those reads in the product's main sources - comments ignored - so the limits of the pinned clock are reported
before a run instead of discovered in triage. A read is evidence to look at, not a defect: a fallback that a pinned
caller never reaches reads the system clock harmlessly.
"""

from __future__ import annotations

import re
from pathlib import Path

_PATTERNS = (
    ("system-clock", re.compile(r"\bClock\s*\.\s*system(?:DefaultZone|UTC)?\s*\(")),
    ("now-without-clock", re.compile(r"\b(?:LocalDate|LocalDateTime|LocalTime|Instant|ZonedDateTime|OffsetDateTime|"
                                     r"OffsetTime|Year|YearMonth|MonthDay)\s*\.\s*now\s*\(\s*\)")),
    ("system-millis", re.compile(r"\bSystem\s*\.\s*currentTimeMillis\s*\(\s*\)")),
    ("new-date", re.compile(r"\bnew\s+(?:java\.util\.)?Date\s*\(\s*\)|\bCalendar\s*\.\s*getInstance\s*\(\s*\)")),
)
# SQL's special registers, in a string literal and upper case (prose such as "the current date" is no query)
_SQL_CURRENT = re.compile(r"\bCURRENT[ _](?:DATE|TIMESTAMP|TIME)\b")
_ORDER = ("system-clock", "sql-current", "now-without-clock", "system-millis", "new-date")
_METHOD = re.compile(r"^\s*(?:@\w+(?:\([^)]*\))?\s+)*(?:(?:public|protected|private|static|final|synchronized|default|"
                     r"abstract|native)\s+)*(?:<[^>]+>\s+)?([\w.$<>\[\], ?]+?)\s+(\w+)\s*\([^;{}]*\)?\s*"
                     r"(?:throws\s+[\w.,\s]+)?[{;]?\s*$")
_NOT_A_METHOD = {"if", "for", "while", "switch", "catch", "return", "new", "else", "do", "try", "synchronized"}


def _blank(text: str) -> str:
    return re.sub(r"[^\n]", " ", text)


def split_source(text: str) -> tuple[str, str]:
    """(the Java source with every comment blanked out, its string literals only - everything else blanked); line
    breaks kept in both, so line numbers hold. Text blocks and character literals are literals too."""
    code, strings, i, n = [], [], 0, len(text)
    while i < n:
        ch = text[i]
        if text.startswith('"""', i):
            end = text.find('"""', i + 3)
            end = n if end < 0 else end + 3
            code.append(text[i:end])
            strings.append(text[i:end])
            i = end
        elif ch in "\"'":
            j = i + 1
            while j < n and text[j] != ch and text[j] != "\n":
                j += 2 if text[j] == "\\" else 1
            code.append(text[i:j + 1])
            strings.append(text[i:j + 1] if ch == '"' else _blank(text[i:j + 1]))
            i = j + 1
        elif text.startswith("//", i) or text.startswith("/*", i):
            end = text.find("\n", i) if text.startswith("//", i) else text.find("*/", i + 2)
            end = n if end < 0 else end + (0 if text.startswith("//", i) else 2)
            code.append(_blank(text[i:end]))
            strings.append(_blank(text[i:end]))
            i = end
        else:
            code.append(ch)
            strings.append(ch if ch == "\n" else " ")
            i += 1
    return "".join(code), "".join(strings)


def strip_comments(text: str) -> str:
    return split_source(text)[0]


def _declaration(lines: list[str], k: int) -> tuple[str, str, bool] | None:
    match = _METHOD.match(lines[k])
    if match and match.group(2) not in _NOT_A_METHOD and match.group(1).split()[-1] not in _NOT_A_METHOD:
        return match.group(2), match.group(1).split()[-1], any("@Bean" in lines[j] for j in range(max(0, k - 3), k + 1))
    return None


def _in_annotation(lines: list[str], index: int) -> bool:
    """Whether a line belongs to an annotation's arguments (``@Query("..." + ...)`` above its method)."""
    for k in range(index, max(-1, index - 15), -1):
        text = lines[k].strip()
        if text.startswith("@"):
            return True
        if k < index and text.endswith((";", "{", "}")):
            return False
    return False


def _enclosing(lines: list[str], index: int) -> tuple[str | None, str | None, bool]:
    """(the method a line is in - or, inside an annotation, the method it annotates -, its return type, whether it is a
    ``@Bean`` method): the nearest declaration, a heuristic for a report."""
    if _in_annotation(lines, index):
        for k in range(index + 1, min(len(lines), index + 15)):
            found = _declaration(lines, k)
            if found:
                return found
    for k in range(index, -1, -1):
        found = _declaration(lines, k)
        if found:
            return found
    return None, None, False


def scan(texts: dict[Path, str], rel) -> dict:
    """Every clock read in ``texts`` (file -> source): ``reads`` (file, line, kind, call, method, pinned) and counts.
    ``pinned`` is true only for a ``Clock.system*()`` that a ``@Bean`` method returning ``Clock`` hands to Spring -
    the bean E2E replaces."""
    reads = []
    for path in sorted(texts):
        code, strings = split_source(texts[path])
        lines, literal_lines = code.split("\n"), strings.split("\n")
        # the declarations read without their string literals: a "${app.clock.zone:UTC}" in a parameter's @Value
        # would otherwise hide the method it belongs to
        masked = "".join(" " if s not in " \n" else c for c, s in zip(code, strings)).split("\n")
        for number, line in enumerate(lines):
            found = [(kind, m.group(0)) for kind, pattern in _PATTERNS for m in pattern.finditer(line)]
            found += [("sql-current", " ".join(m.group(0).upper().replace("_", " ").split()))
                      for m in _SQL_CURRENT.finditer(literal_lines[number])]
            for kind, call in found:
                method, returns, bean = _enclosing(masked, number)
                reads.append({"file": rel(path), "line": number + 1, "kind": kind,
                              "call": call if kind == "sql-current" else re.sub(r"\s+", "", call), "method": method,
                              "pinned": kind == "system-clock" and bean and returns == "Clock"})
    reads.sort(key=lambda r: (r["pinned"], _ORDER.index(r["kind"]), r["file"], r["line"]))   # the system clock first
    unpinned = [r for r in reads if not r["pinned"]]
    return {"reads": reads, "unpinned": len(unpinned), "pinnedBeans": len(reads) - len(unpinned),
            "byKind": {k: sum(1 for r in unpinned if r["kind"] == k) for k in _ORDER
                       if any(r["kind"] == k for r in unpinned)},
            "files": len({r["file"] for r in unpinned})}


def describe(found: dict, shown: int = 5) -> str | None:
    """One line for the manifest's notes (None when nothing reads the clock past the pinned beans)."""
    if not found["unpinned"]:
        return None
    first = [r for r in found["reads"] if not r["pinned"]][:shown]
    where = "; ".join(f"{r['file']}:{r['line']} {r['call']}" + (f" in {r['method']}" if r["method"] else "")
                      for r in first)
    return (f"the product reads the clock past the pinned case clock in {found['unpinned']} place(s) of "
            f"{found['files']} file(s) ({', '.join(f'{k} {n}' for k, n in found['byKind'].items())}) - e.g. {where}: "
            "a scenario that reaches them runs on the real date, not the recording's")
