"""L0 - the design gates of the phases before the test line, as mu-design and mu-implement leave them:

  Design          `design/report.md` (step table, counts line, blocked, review findings, waiting for the user),
                  `design/design-open-questions.md` (OQ-n), the rule-coverage gate (`check_rule_coverage.py`, re-run
                  when present) and the design's recordings of the legacy (`unit/<entry>/cases.json`: the basic
                  set, not the oracle)
  Implementation  `implement/report.md` (steps, counts, build and tests as recorded, test database, traceability as
                  recorded, review findings), `implement/implement-open-questions.md` (IQ-n), `implement/
                  traceability.md`, the traceability gate (`validate_traceability.py` over the product module's
                  `src/main/java`, with the design's exemptions from `check_rule_coverage.py --allow-out`)

Every count is read from the files or from a checker's output; the checkers write only under `report/.tmp/`. A phase
that left no file is "not produced", a gate that could not be re-run is "not run", with the reason - never passed.
"""

from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

from .common import SHARED_SCRIPTS, SKILLS, read_json_or_none, read_text, rel
from .levels import absent, worst
from .mdtext import first_table, sections, tables
from .mufiles import Mu, product_module

QUESTION_IDS = ("OQ", "IQ", "PQ", "VQ", "RG")
_QUESTION = re.compile(r"^##\s+((?:" + "|".join(QUESTION_IDS) + r")-\d+(?:\.\d+)?)\s*[-–—:]\s*(.*?)\s*$")
_STATUS = re.compile(r"Status:\s*([A-Za-z-]+)")
_STEP = re.compile(r"Step:\s*(.*?)\s*(?:·|$)")
_COUNT_PART = re.compile(r"^\s*(.*?)\s+(\d+(?:\s*/\s*\d+)?)\s*(.*?)\s*$")
_PERCENT = re.compile(r"(\d+(?:\.\d+)?)\s*%\s*(?:of\s+)?(\w+)?")
_NOTHING = ("nothing", "none", "-", "")
SEVERITIES = ("High", "Medium", "Low")
DONE = ("done", "green", "passed", "skipped", "n/a", "not needed")
FAILED = ("blocked", "failed", "red")
OWNERS = {"design": "mu-design", "implementation": "mu-implement"}


# --------------------------------------------------------------------------- phase report parsers


def counts_line(text: str) -> list[dict]:
    """The `Rules 46 · cases 26 · …` line under the step table: [{label, value, note}]."""
    for line in text.splitlines():
        if line.count("·") >= 1 and not line.lstrip().startswith(("|", "#", "-", ">")) and re.search(r"\d", line):
            parts = []
            for part in line.split("·"):
                match = _COUNT_PART.match(part)
                if match:
                    parts.append({"label": match.group(1).strip(), "value": re.sub(r"\s+", "", match.group(2)),
                                  "note": match.group(3).strip(" ()") or None})
            if parts:
                return parts
    return []


def steps(text: str) -> list[dict]:
    table = first_table(text, "Step")
    return [{"step": r.get("Step", ""), "status": r.get("Status", "").strip(), "note": r.get("Note") or None}
            for r in (table or {}).get("rows", [])]


def findings(text: str) -> dict:
    """The review findings table: rows, counts by severity and by outcome (applied / rejected / open / other)."""
    table = next((t for t in tables(text) if any("severity" in h.lower() for h in t["header"])), None)
    rows = []
    for r in (table or {}).get("rows", []):
        severity_cell = next((v for k, v in r.items() if k.lower() == "severity"), "")
        outcome_cell = next((v for k, v in r.items() if "applied" in k.lower() or "outcome" in k.lower()), "")
        severity = next((s for s in SEVERITIES if severity_cell.lower().startswith(s.lower()[:3])), "Unrated")
        low = outcome_cell.lower()
        outcome = "open" if "open" in low else "applied" if "applied" in low else "rejected" if "rejected" in low \
            else "other"
        rows.append({"number": r.get("#"), "reviewer": r.get("Reviewer"), "severity": severity,
                     "severityText": severity_cell, "finding": r.get("Finding"), "outcome": outcome,
                     "outcomeText": outcome_cell,
                     "where": next((v for k, v in r.items() if k.lower().startswith("where")), None)})
    by_severity = {s: sum(1 for r in rows if r["severity"] == s) for s in (*SEVERITIES, "Unrated")}
    by_outcome = {o: sum(1 for r in rows if r["outcome"] == o) for o in ("applied", "rejected", "open", "other")}
    open_by_severity = {s: sum(1 for r in rows if r["severity"] == s and r["outcome"] == "open")
                        for s in (*SEVERITIES, "Unrated")}
    return {"rows": rows, "total": len(rows), "bySeverity": by_severity, "byOutcome": by_outcome,
            "openBySeverity": open_by_severity}


def questions(text: str | None, file: str | None = None) -> dict:
    """An open-questions file (the shared template): settled lines, and per question its id, title, step, status,
    blocking, question, decision taken, affects and answer. `answered` = an `Answer:` with text, or a status
    answered / settled / closed."""
    if text is None:
        return {"present": False, "file": file, "items": [], "settled": 0, "open": 0, "answered": 0, "total": 0,
                "blockingOpen": 0}
    items, current, settled, in_settled = [], None, 0, False
    for raw in text.splitlines():
        line = raw.rstrip()
        match = _QUESTION.match(line)
        if match:
            current = {"id": match.group(1), "title": match.group(2), "step": None, "status": None,
                       "blocking": None, "question": None, "decision": None, "affects": None, "answer": None,
                       "file": file}
            items.append(current)
            in_settled = False
            continue
        if line.startswith("## "):
            in_settled = "settled" in line.lower()
            current = None
            continue
        if in_settled and line.lstrip().startswith("- "):
            settled += 1
            continue
        if current is None:
            continue
        if line.startswith("Step:") or "Status:" in line[:60]:
            status = _STATUS.search(line)
            step = _STEP.search(line)
            current["status"] = status.group(1).lower() if status else current["status"]
            current["step"] = step.group(1) if step and line.startswith("Step:") else current["step"]
        elif line.startswith("Blocking:"):
            current["blocking"] = line[len("Blocking:"):].strip().lower().startswith("yes")
        elif line.startswith("Question:"):
            current["question"] = line[len("Question:"):].strip() or None
        elif line.startswith("Decision taken:"):
            current["decision"] = line[len("Decision taken:"):].strip() or None
        elif line.startswith("Affects:"):
            current["affects"] = line[len("Affects:"):].strip() or None
        elif line.startswith("Answer:"):
            current["answer"] = line[len("Answer:"):].strip() or None
        elif current.get("answer") is not None and line.strip():
            current["answer"] += " " + line.strip()
    for item in items:
        item["answered"] = bool(item["answer"]) or item["status"] in ("answered", "settled", "closed")
    answered = sum(1 for i in items if i["answered"])
    return {"present": True, "file": file, "items": items, "settled": settled, "answered": answered,
            "open": len(items) - answered, "total": len(items),
            "blockingOpen": sum(1 for i in items if i["blocking"] and not i["answered"])}


def _blocked(section_text: str | None) -> str | None:
    text = (section_text or "").strip()
    return None if text.lower().rstrip(".") in _NOTHING else text


# --------------------------------------------------------------------------- the gates


def coverage_script() -> Path:
    return SHARED_SCRIPTS / "check_rule_coverage.py"


def traceability_script(mu: Mu) -> Path:
    architecture = str((mu.manifest.get("target") or {}).get("architecture_skill") or "target-java-3tier")
    return SKILLS / architecture / "scripts" / "validate_traceability.py"


def _shown(path: Path, mu: Mu) -> str:
    """A pipeline file relative to the workspace, else to the pipeline's own root (the plugin's folder)."""
    try:
        return path.resolve().relative_to(mu.workspace).as_posix()
    except ValueError:
        root = SKILLS.parent
        try:
            return f"{root.name}/{path.resolve().relative_to(root).as_posix()}"
        except ValueError:
            return path.name


def _run_checker(command: list[str], cwd: Path, timeout: int = 300) -> tuple[int, str]:
    done = subprocess.run(command, capture_output=True, timeout=timeout, cwd=str(cwd), stdin=subprocess.DEVNULL)
    return done.returncode, (done.stdout + b"\n" + done.stderr).decode("utf-8", errors="replace")


_COVERAGE_LINE = re.compile(r"(\d+) paragraphs, (\d+) business, (\d+) (?:with a rule or a reason|cited or exempt)")
_FINDING_LINE = re.compile(r"^([A-Z_]+):\s+(\S+)\s+(\S+)\s*(.*)$")


def _checker_counts(output: str) -> dict:
    match = _COVERAGE_LINE.search(output)
    found = [{"kind": m.group(1), "program": m.group(2), "paragraph": m.group(3), "detail": m.group(4).strip()}
             for m in map(_FINDING_LINE.match, output.splitlines()) if m]
    if not match:
        return {"read": False, "findings": found}
    return {"read": True, "paragraphs": int(match.group(1)), "business": int(match.group(2)),
            "covered": int(match.group(3)), "findings": found}


def java_roots(mu: Mu) -> list[Path]:
    module = product_module(mu)
    if not module or mu.solution is None:
        return []
    root = mu.solution / module["dir"] / "src" / "main" / "java"
    return [root] if root.is_dir() else []


def gates(mu: Mu, scratch: Path) -> dict:
    """The rule-coverage gate and the traceability gate, re-run by their own scripts when present (read only; their
    outputs go to `scratch` only)."""
    index = mu.folder / "extracted-logic" / "paragraph-index.json"
    rules = mu.folder / "design" / "rules.md"
    stubs = mu.folder / "design" / "stubs.md"
    cov_script, trace_script = coverage_script(), traceability_script(mu)
    result = {"ruleCoverage": {"status": "none", "ran": False}, "traceability": {"status": "none", "ran": False}}
    if not index.is_file() or not rules.is_file():
        missing = "extracted-logic/paragraph-index.json" if not index.is_file() else "design/rules.md"
        reason = f"not re-run: {missing} is not there (mu-design writes it)"
        result["ruleCoverage"]["reason"] = result["traceability"]["reason"] = reason
        return result
    if not cov_script.is_file():
        reason = f"not re-run: {_shown(cov_script, mu)} is not there"
        result["ruleCoverage"]["reason"] = reason
        result["traceability"]["reason"] = reason + "; the traceability gate needs the design's exemptions it writes"
        return result
    scratch.mkdir(parents=True, exist_ok=True)
    allow = scratch / "allow.txt"
    if allow.is_file():
        allow.unlink()
    command = [sys.executable, "-B", str(cov_script), "--index", str(index), "--rules", str(rules),
               "--allow-out", str(allow), "--warn-only"]
    if stubs.is_file():
        command += ["--external", str(stubs)]
    code, out = _run_checker(command, mu.workspace)
    counts = _checker_counts(out)
    rc = result["ruleCoverage"]
    rc.update({"ran": True, "exitCode": code, "script": _shown(cov_script, mu), **counts})
    if counts.get("read"):
        rc["status"] = "pass" if not counts["findings"] and counts["covered"] == counts["business"] else "warn"
    else:
        rc["status"], rc["reason"] = "warn", "the checker's output could not be read"
    tr = result["traceability"]
    if not trace_script.is_file():
        tr["reason"] = f"not re-run: {_shown(trace_script, mu)} is not there"
        return result
    roots = java_roots(mu)
    if not roots:
        module = product_module(mu)
        tr["reason"] = ("not re-run: the product module is not known (validation-state.json solution.facts, "
                        "implement/report.md Module table)" if not module else
                        f"not re-run: {module['dir']}/src/main/java is not in the solution")
        return result
    out_json = scratch / "traceability.json"
    if out_json.is_file():
        out_json.unlink()
    command = [sys.executable, "-B", str(trace_script), "--index", str(index), "--java", *map(str, roots),
               "--json", str(out_json), "--warn-only"]
    if stubs.is_file():
        command += ["--external", str(stubs)]
    if allow.is_file():
        command += ["--allow", str(allow)]
    code, out = _run_checker(command, mu.workspace)
    doc = read_json_or_none(out_json) or {}
    tr.update({"ran": True, "exitCode": code, "script": _shown(trace_script, mu),
               "javaRoots": [rel(r, mu.workspace) for r in roots]})
    if doc:
        kinds: dict[str, int] = {}
        for f in doc.get("findings") or []:
            kinds[f.get("kind", "?")] = kinds.get(f.get("kind", "?"), 0) + 1
        tr.update({"read": True, "files": doc.get("files"), "paragraphs": doc.get("paragraphs"),
                   "business": doc.get("business"), "covered": doc.get("covered"), "findingsByKind": kinds,
                   "findings": [{k: f.get(k) for k in ("kind", "program", "paragraph", "detail")}
                                for f in (doc.get("findings") or [])[:50]]})
        tr["status"] = "pass" if not doc.get("findings") and doc.get("covered") == doc.get("business") else "warn"
    else:
        tr["status"], tr["reason"] = "warn", "the checker wrote no JSON"
    return result


# --------------------------------------------------------------------------- phases


def _phase_status(step_rows: list[dict], blocked: str | None, open_questions: int, open_high: int,
                  gate_statuses: list[str]) -> tuple[str, str]:
    if not step_rows:
        return "none", "no step table in report.md"
    not_done = [s for s in step_rows if s["status"].lower() not in DONE]
    if blocked or any(s["status"].lower() in FAILED for s in step_rows):
        return "fail", "a step is blocked" if blocked else "a step failed"
    if not_done:
        return "warn", f"{len(not_done)} step(s) not done"
    if open_high or "warn" in gate_statuses or "fail" in gate_statuses:
        return "warn", "open findings or gate findings"
    if open_questions:
        return "warn", f"{open_questions} open question(s) waiting for the user"
    return "pass", "every step done; no open question, high finding or gate finding"


def characterisation(mu: Mu) -> dict:
    """The design's recordings of the legacy (the basic set): per entry point the cases of `unit/<E>/cases.json` and
    how many carry an `expect` block (run-cobol writes it from a run, never by hand)."""
    units = []
    for cases_file in sorted((mu.folder / "unit").glob("*/cases.json")):
        doc = read_json_or_none(cases_file) or {}
        cases = [c for c in (doc.get("cases") if isinstance(doc, dict) else doc) or []
                 if isinstance(c, dict) and c.get("name")]
        units.append({"unit": cases_file.parent.name, "cases": len(cases),
                      "recorded": sum(1 for c in cases if c.get("expect")), "file": rel(cases_file, mu.workspace)})
    return {"units": units, "cases": sum(u["cases"] for u in units), "recorded": sum(u["recorded"] for u in units)}


def _questions_file(mu: Mu, phase: str, name: str) -> dict:
    path = mu.folder / phase / name
    return questions(read_text(path), rel(path, mu.workspace))


def design(mu: Mu, gate: dict) -> dict:
    folder = mu.folder / "design"
    report = read_text(folder / "report.md")
    oq = _questions_file(mu, "design", "design-open-questions.md")
    chars = characterisation(mu)
    if report is None:
        return {"present": False, **absent("not_produced", "design/report.md is not there", "mu-design",
                                           mu.command("mu-design")),
                "questions": oq, "characterisation": chars, "ruleCoverage": gate["ruleCoverage"]}
    parts = sections(report)
    rows = steps(report)
    review = findings(report)
    blocked = _blocked(parts.get("blocked"))
    status, note = _phase_status(rows, blocked, oq["open"], review["openBySeverity"]["High"],
                                 [gate["ruleCoverage"]["status"]])
    recorded_claim = next((ln.strip() for ln in report.splitlines() if ln.lower().startswith("paragraph coverage")),
                          None)
    return {"present": True, "status": status, "state": "results", "note": note,
            "file": rel(folder / "report.md", mu.workspace), "steps": rows,
            "stepsDone": sum(1 for s in rows if s["status"].lower() in DONE), "counts": counts_line(report),
            "blocked": blocked,
            "toolGaps": [line.lstrip("- ").strip() for line in (parts.get("tool gaps") or "").splitlines()
                         if line.strip().startswith("- ")],
            "review": review, "waitingForTheUser": parts.get("waiting for the user") or None,
            "questions": oq, "characterisation": chars, "ruleCoverage": gate["ruleCoverage"],
            "ruleCoverageRecorded": recorded_claim, "documents": [p.name for p in sorted(folder.glob("*.md"))]}


def recorded_test_database(mu: Mu) -> dict:
    """The implementation's record of where its integration tests ran (`Test database: …`): the line, and whether
    it names a Db2 the tests reached."""
    body = sections(read_text(mu.folder / "implement" / "report.md") or "").get("build and tests") or ""
    line = next((ln.strip() for ln in body.splitlines() if ln.lower().startswith("test database")), None)
    return {"testDatabase": line,
            "testDatabaseIsDb2": bool(line and re.search(r"db2", line, re.I) and "not run" not in line.lower())}


_TRACE_RECORDED = re.compile(r"`?(\d+)`?\s+business paragraphs,\s+`?(\d+)`?\s+cited or exempt.*?`?(\d+)`?\s+findings",
                             re.S)


def implementation(mu: Mu, gate: dict, design_present: bool) -> dict:
    folder = mu.folder / "implement"
    report = read_text(folder / "report.md")
    iq = _questions_file(mu, "implement", "implement-open-questions.md")
    if report is None:
        state = "not_produced" if design_present else "not_reached"
        reason = ("implement/report.md is not there" if design_present else
                  "the design is not there: mu-implement builds the product from design/")
        owner, command = ("mu-implement", mu.command("mu-implement")) if design_present else \
            ("mu-design", mu.command("mu-design"))
        return {"present": False, **absent(state, reason, owner, command), "questions": iq,
                "traceability": gate["traceability"]}
    parts = sections(report)
    rows = steps(report)
    review = findings(report)
    blocked = _blocked(parts.get("blocked"))
    build_table = next((t for t in tables(report) if t["header"] and t["header"][0].lower() == "module"), None)
    build_rows = [{"module": r.get("Module"), "build": r.get("Build"),
                   "unit": next((v for k, v in r.items() if k.lower().startswith("unit")), None),
                   "integration": next((v for k, v in r.items() if k.lower().startswith("integration")), None)}
                  for r in (build_table or {}).get("rows", [])]
    body = parts.get("build and tests") or ""
    coverage_line = next((ln for ln in body.splitlines() if ln.lower().startswith("line coverage")), None)
    coverage = None
    if coverage_line:
        match = _PERCENT.search(coverage_line)
        coverage = {"text": coverage_line.strip(), "percent": float(match.group(1)) if match else None,
                    "of": (match.group(2) if match else None)}
    trace_text = parts.get("traceability") or ""
    match = _TRACE_RECORDED.search(trace_text)
    trace_recorded = ({"business": int(match.group(1)), "covered": int(match.group(2)),
                       "findings": int(match.group(3)), "text": trace_text.split("\n\n", 1)[0].strip()}
                      if match else ({"text": trace_text.split("\n\n", 1)[0].strip()} if trace_text else None))
    status, note = _phase_status(rows, blocked, iq["open"], review["openBySeverity"]["High"],
                                 [gate["traceability"]["status"]])
    trace_file = folder / "traceability.md"
    return {"present": True, "status": status, "state": "results", "note": note,
            "file": rel(folder / "report.md", mu.workspace), "steps": rows,
            "stepsDone": sum(1 for s in rows if s["status"].lower() in DONE), "counts": counts_line(report),
            "blocked": blocked, "buildAndTests": build_rows, "coverage": coverage, **recorded_test_database(mu),
            "traceabilityRecorded": trace_recorded,
            "traceabilityFile": rel(trace_file, mu.workspace) if trace_file.is_file() else None,
            "review": review, "waitingForTheUser": parts.get("waiting for the user") or None, "questions": iq,
            "traceability": gate["traceability"], "productModule": product_module(mu)}


def read(mu: Mu, scratch: Path) -> dict:
    gate = gates(mu, scratch)
    d = design(mu, gate)
    phases = {"design": d, "implementation": implementation(mu, gate, d["present"])}
    present = [p for p in phases.values() if p["present"]]
    open_q = {"design": d["questions"]["open"], "implementation": phases["implementation"]["questions"]["open"]}
    if not present:
        return {"phases": phases, "openQuestions": open_q,
                **absent("not_produced", "neither design/report.md nor implement/report.md is there", "mu-design",
                         mu.command("mu-design"))}
    return {"phases": phases, "openQuestions": open_q, "available": True, "state": "results",
            "status": worst(p["status"] for p in present)}


def input_files(mu: Mu) -> list[Path]:
    files = [mu.folder / "design" / n for n in ("report.md", "design-open-questions.md", "rules.md", "stubs.md")]
    files += [mu.folder / "implement" / n for n in ("report.md", "implement-open-questions.md", "traceability.md")]
    files.append(mu.folder / "extracted-logic" / "paragraph-index.json")
    files += sorted((mu.folder / "unit").glob("*/cases.json"))
    files += [coverage_script(), traceability_script(mu)]
    return [f for f in files if f.is_file()]
