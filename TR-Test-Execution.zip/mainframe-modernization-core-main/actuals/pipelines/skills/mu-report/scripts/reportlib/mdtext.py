"""Markdown helpers for the phase reports: pipe tables and `## ` sections."""

from __future__ import annotations

import re

_TABLE_ROW = re.compile(r"^\s*\|(.+)\|\s*$")
_SEPARATOR = re.compile(r"^\s*\|?\s*:?-{3,}")


def cells(line: str) -> list[str]:
    return [c.strip() for c in re.split(r"(?<!\\)\|", line.strip())[1:-1]]


def tables(text: str) -> list[dict]:
    """Every pipe table of a Markdown text: {header, rows (dicts by header), section (the heading above it)}."""
    found, lines, section = [], text.splitlines(), None
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("#"):
            section = line.lstrip("#").strip()
        if _TABLE_ROW.match(line) and i + 1 < len(lines) and _SEPARATOR.match(lines[i + 1]):
            header = cells(line)
            rows = []
            i += 2
            while i < len(lines) and _TABLE_ROW.match(lines[i]):
                row = cells(lines[i])
                rows.append({header[k] if k < len(header) else f"col{k}": row[k] for k in range(len(row))})
                i += 1
            found.append({"header": header, "rows": rows, "section": section})
            continue
        i += 1
    return found


def first_table(text: str, first_column: str) -> dict | None:
    return next((t for t in tables(text) if t["header"] and t["header"][0].lower() == first_column.lower()), None)


def sections(text: str) -> dict[str, str]:
    """`## Heading` -> its body (to the next `## `), heading lower-cased."""
    found, current, body = {}, None, []
    for line in text.splitlines():
        if line.startswith("## "):
            if current is not None:
                found[current] = "\n".join(body).strip()
            current, body = line[3:].strip().lower(), []
        elif current is not None:
            body.append(line)
    if current is not None:
        found[current] = "\n".join(body).strip()
    return found


def unquote(text: str | None) -> str:
    """A cell without its code marks: "`revol-wip-dir`" -> "revol-wip-dir"."""
    return (text or "").replace("`", "").strip()
