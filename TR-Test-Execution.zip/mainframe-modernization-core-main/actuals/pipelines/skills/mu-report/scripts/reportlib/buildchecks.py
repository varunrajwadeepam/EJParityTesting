"""The product's own test suites - pyramid levels L1 unit, L2 contract and L3 integration - read from the files a build
writes: surefire / failsafe reports (``target/*-reports/TEST-*.xml``, every test case with its result and, for a
failure, its message, exception type and the head of its stack trace), the JaCoCo report (``target/site/**/jacoco.xml``)
and, when the build ran here, its log (each module's outcome, each coverage check's).

A test class belongs to ONE level by a published, deterministic rule over its own source and the sources of the
classes it extends in the same test tree - never by a model's reading. First match wins (decision U-95, the v2 rule
D13: a test that boots the application and reaches its database is an integration test even when it calls the API):

  L2 contract     (1) the class name contains ``Contract``; (2) a web slice without a database (@WebMvcTest,
                  @WebFluxTest)
  L3 integration  (3) the class boots a Spring context or a data slice (@SpringBootTest, @DataJdbcTest, @DataJpaTest,
                  @JdbcTest), or its name ends in IntegrationTest / IT / ITCase, or Failsafe runs it
  L2 contract     (4) the source drives the API without a context (MockMvc, WebTestClient, TestRestTemplate,
                  RestAssured)
  L1 unit         (5) every other test class

An L3 class runs on a real Db2 when its sources name one (``jdbc:db2:``, a Db2 container), or when the build ran with
a Db2 connection and the product's datasource is taken from the environment (``${...}`` in ``spring.datasource.url``)
with no in-memory database in its test resources. It runs on an in-memory database when its sources (or the classes
it extends) name one (``jdbc:h2:``, H2's embedded type) or its module's test resources configure one - the product's
database tests on H2 in DB2 mode. Both are information about the level, never its status: H2 in DB2 mode is a valid
L3 database (decision U-113, superseding U-85's "not a real Db2" warning).

Which modules count for a Migration Unit: its product module, every reactor module it depends on (directly or
through another), and the application module; the other modules - other MUs' - are listed, never counted.
"""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from pathlib import Path

from .clockreach import strip_comments

LEVELS = ("L1", "L2", "L3")
LEVEL_NAMES = {"L1": "Unit", "L2": "Contract", "L3": "Integration"}
LEVEL_RULES = {
    "L2": "the class name contains Contract, or it is a web slice without a database (@WebMvcTest, @WebFluxTest), or - "
          "booting no Spring context - it drives the API (MockMvc, WebTestClient, TestRestTemplate, RestAssured)",
    "L3": "the class (or a class it extends) boots a Spring context or a data slice (@SpringBootTest, @DataJdbcTest, "
          "@DataJpaTest, @JdbcTest), or its name ends in IntegrationTest, IT or ITCase, or Failsafe runs it - also "
          "when it calls the API",
    "L1": "every other test class",
}
ROLES = ("mu", "shared", "application", "other")

_API = re.compile(r"\b(MockMvc|WebTestClient|TestRestTemplate|RestAssured)\b")
_WEB_SLICE = re.compile(r"@(WebMvcTest|WebFluxTest)\b")
_CONTEXT = re.compile(r"@(SpringBootTest|DataJdbcTest|DataJpaTest|JdbcTest)\b")
_INTEGRATION_NAME = re.compile(r"(IntegrationTest|IT|ITCase)$")
_DB2 = re.compile(r"jdbc:db2:|\bDb2Container\b|org\.testcontainers", re.I)
_IN_MEMORY = re.compile(r"jdbc:(h2|hsqldb|derby):", re.I)
_IN_MEMORY_SOURCE = re.compile(r"jdbc:(?:h2|hsqldb|derby):|EmbeddedDatabaseType\.(?:H2|HSQL|DERBY)\b", re.I)
_ENV_URL = re.compile(r"^\s*url:\s*['\"]?\$\{", re.M)
_PACKAGE = re.compile(r"^\s*package\s+([\w.]+)\s*;", re.M)
_EXTENDS = re.compile(r"\bclass\s+\w+(?:<[^>{]*>)?\s+extends\s+([\w.]+)")
_CHECK = re.compile(r"--- jacoco(?:-maven-plugin)?:[^:\s]+:check \([^)]*\) @ (\S+) ---")
_PLUGIN = re.compile(r"--- \S+:[^:\s]+:\S+ \([^)]*\) @ ")
_SUMMARY = re.compile(r"^\[INFO\] (.+?)[\s.]+(SUCCESS|FAILURE|SKIPPED)(?:\s|$)")
_POM_NS = re.compile(r"^\{[^}]*\}")


# --------------------------------------------------------------------------- the reactor


def _local(tag: str) -> str:
    return _POM_NS.sub("", tag)


def _child(element, name: str):
    for item in list(element) if element is not None else []:
        if _local(item.tag) == name:
            return item
    return None


def _children(element, name: str) -> list:
    return [item for item in list(element) if _local(item.tag) == name] if element is not None else []


def _text(element, name: str) -> str | None:
    found = _child(element, name)
    return found.text.strip() if found is not None and found.text else None


def _project(path: Path):
    return ET.parse(path).getroot()


def module_folders(root: Path) -> list[str]:
    """The folders of the reactor's modules (root ``pom.xml`` ``<modules>``, one level); [] without a readable POM."""
    try:
        top = _project(root / "pom.xml")
    except (OSError, ET.ParseError):
        return []
    return [m.text.strip() for m in _children(_child(top, "modules"), "module") if m.text and m.text.strip()]


def reactor(root: Path) -> list[dict]:
    """The reactor's modules (root ``pom.xml`` ``<modules>``, one level): folder, artifactId, name, the reactor modules
    it depends on (by artifactId), and its coverage rules."""
    top = _project(root / "pom.xml")
    folders = [m.text.strip() for m in _children(_child(top, "modules"), "module") if m.text and m.text.strip()]
    modules = []
    for folder in folders:
        pom_file = root / folder / "pom.xml"
        if not pom_file.is_file():
            continue
        project = _project(pom_file)
        dependencies = [_text(d, "artifactId") for d in _children(_child(project, "dependencies"), "dependency")]
        modules.append({"module": folder, "artifactId": _text(project, "artifactId") or folder,
                        "name": _text(project, "name"), "dependencies": [d for d in dependencies if d],
                        "coverageRules": coverage_rules(project)})
    known = {m["artifactId"] for m in modules}
    for m in modules:
        m["dependsOn"] = sorted(d for d in m.pop("dependencies") if d in known and d != m["artifactId"])
    return modules


def roles(modules: list[dict], mu_artifact: str | None, app_artifact: str | None) -> dict[str, str]:
    """artifactId -> mu | shared | application | other."""
    by_id = {m["artifactId"]: m for m in modules}
    shared: set[str] = set()
    todo = list(by_id.get(mu_artifact, {}).get("dependsOn", []))
    while todo:
        current = todo.pop()
        if current in shared or current == mu_artifact:
            continue
        shared.add(current)
        todo.extend(by_id.get(current, {}).get("dependsOn", []))
    found = {}
    for artifact in by_id:
        if artifact == mu_artifact:
            found[artifact] = "mu"
        elif artifact == app_artifact:
            found[artifact] = "application"
        elif artifact in shared:
            found[artifact] = "shared"
        else:
            found[artifact] = "other"
    return found


def coverage_rules(project) -> list[dict]:
    """The JaCoCo ``check`` limits a module's POM declares: [{counter, value, minimum}]."""
    rules = []
    build = _child(project, "build")
    for plugin in _children(_child(build, "plugins"), "plugin"):
        if _text(plugin, "artifactId") != "jacoco-maven-plugin":
            continue
        for execution in _children(_child(plugin, "executions"), "execution"):
            goals = [g.text.strip() for g in _children(_child(execution, "goals"), "goal") if g.text]
            if "check" not in goals:
                continue
            configuration = _child(execution, "configuration")
            for rule in _children(_child(configuration, "rules"), "rule"):
                for limit in _children(_child(rule, "limits"), "limit"):
                    minimum = _text(limit, "minimum")
                    rules.append({"counter": _text(limit, "counter") or "INSTRUCTION",
                                  "value": _text(limit, "value") or "COVEREDRATIO",
                                  "minimum": _number(minimum)})
    return rules


def _number(text: str | None):
    if text is None:
        return None
    try:
        return float(text.rstrip("%")) / (100 if text.endswith("%") else 1)
    except ValueError:
        return None


# --------------------------------------------------------------------------- classification


def test_sources(module_dir: Path) -> dict[str, Path]:
    """Fully qualified class name -> source file, for every ``src/test/java/**/*.java`` of a module."""
    found = {}
    base = module_dir / "src" / "test" / "java"
    for source in sorted(base.rglob("*.java")) if base.is_dir() else []:
        text = source.read_text(encoding="utf-8", errors="replace")
        package = _PACKAGE.search(text)
        found[(package.group(1) + "." if package else "") + source.stem] = source
    return found


def classify(name: str, sources: dict[str, Path], runner: str = "surefire") -> tuple[str, str]:
    """(level, reason) of a test class (its name as surefire reports it; a nested class counts as its outer one)."""
    outer = name.split("$", 1)[0]
    simple = outer.rsplit(".", 1)[-1]
    if "Contract" in simple:
        return "L2", "the class name contains Contract"
    texts = _lineage(outer, sources)
    for text in texts:
        found = _WEB_SLICE.search(text)
        if found:
            return "L2", f"a web slice without a database (@{found.group(1)})"
    for text in texts:
        found = _CONTEXT.search(text)
        if found:
            return "L3", f"it boots a Spring context or a data slice (@{found.group(1)})"
    if _INTEGRATION_NAME.search(simple):
        return "L3", f"the class name ends in {_INTEGRATION_NAME.search(simple).group(1)}"
    if runner == "failsafe":
        return "L3", "Failsafe runs it"
    for text in texts:
        found = _API.search(text)
        if found:
            return "L2", f"it drives the API without a Spring context ({found.group(1)})"
    return "L1", "no contract or integration marker"


def uses_db2(name: str, sources: dict[str, Path]) -> bool:
    """Whether the class (or a class it extends) names a real Db2: a ``jdbc:db2:`` URL, a Db2 container."""
    return any(_DB2.search(text) for text in _lineage(name.split("$", 1)[0], sources))


def uses_in_memory(name: str, sources: dict[str, Path]) -> bool:
    """Whether the class (or a class it extends) names an in-memory database: a ``jdbc:h2:`` URL, H2's embedded type."""
    return any(_IN_MEMORY_SOURCE.search(text) for text in _lineage(name.split("$", 1)[0], sources))


def datasource_from_environment(module_dir: Path) -> dict:
    """Whether the module's datasource URL comes from the environment (``url: ${...}`` in its main application
    configuration) and whether its test resources name an in-memory database instead."""
    main = module_dir / "src" / "main" / "resources"
    test = module_dir / "src" / "test" / "resources"
    configs = (sorted(main.glob("application*.y*ml")) + sorted(main.glob("application*.properties"))) \
        if main.is_dir() else []
    texts = [p.read_text(encoding="utf-8", errors="replace") for p in configs]
    env_url = any(_ENV_URL.search(t) or re.search(r"spring\.datasource\.url\s*=\s*\$\{", t) for t in texts)
    test_files = [p for p in sorted(test.rglob("*")) if p.is_file() and p.suffix in (".yml", ".yaml", ".properties")] \
        if test.is_dir() else []
    in_memory = any(_IN_MEMORY.search(p.read_text(encoding="utf-8", errors="replace")) for p in test_files)
    return {"environment": bool(env_url), "inMemoryInTests": bool(in_memory)}


def _lineage(name: str, sources: dict[str, Path], depth: int = 5) -> list[str]:
    """The comment-free sources of a class and of the classes it extends inside the same test tree."""
    texts, seen = [], set()
    current = name
    while current and current not in seen and len(texts) < depth:
        seen.add(current)
        path = sources.get(current)
        if path is None:
            break
        text = strip_comments(path.read_text(encoding="utf-8", errors="replace"))
        texts.append(text)
        parent = _EXTENDS.search(text)
        current = _resolve(parent.group(1), current, sources) if parent else None
    return texts


def _resolve(parent: str, child: str, sources: dict[str, Path]) -> str | None:
    if parent in sources:
        return parent
    package = child.rsplit(".", 1)[0] if "." in child else ""
    same = f"{package}.{parent}" if package else parent
    if same in sources:
        return same
    tail = "." + parent.rsplit(".", 1)[-1]
    matches = [n for n in sources if n.endswith(tail)]
    return matches[0] if len(matches) == 1 else None


# --------------------------------------------------------------------------- reports


TRACE_LINES = 14                         # the head of a stack trace kept per failing test (the report is for people)


def report_files(module_dir: Path) -> list[Path]:
    """The surefire / failsafe ``TEST-*.xml`` and the JaCoCo ``jacoco.xml`` files of a module's ``target/``."""
    found = []
    for folder in ("surefire-reports", "failsafe-reports"):
        reports = module_dir / "target" / folder
        found += sorted(reports.glob("TEST-*.xml")) if reports.is_dir() else []
    site = module_dir / "target" / "site"
    found += sorted(site.rglob("jacoco.xml")) if site.is_dir() else []
    return found


def read_suites(module_dir: Path) -> tuple[list[dict], list[dict]]:
    """(the test classes - one per report file, each with its test cases -, the failing tests) of a module's surefire
    and failsafe reports. A test case: name, result passed | failed | error | skipped, seconds and, for a failure, its
    message, exception type and the head of its stack trace."""
    classes, failing = [], []
    for runner, folder in (("surefire", "surefire-reports"), ("failsafe", "failsafe-reports")):
        reports = module_dir / "target" / folder
        for report in sorted(reports.glob("TEST-*.xml")) if reports.is_dir() else []:
            try:
                suite = ET.parse(report).getroot()
            except ET.ParseError:
                continue
            if _local(suite.tag) == "testsuites":
                suites = _children(suite, "testsuite")
            else:
                suites = [suite]
            for item in suites:
                cases = []
                for case in _children(item, "testcase"):
                    entry = {"name": case.get("name"), "result": "passed", "seconds": _seconds(case.get("time"))}
                    for kind, result in (("failure", "failed"), ("error", "error"), ("skipped", "skipped")):
                        problem = _child(case, kind)
                        if problem is None:
                            continue
                        entry["result"] = result
                        entry["message"] = _first_line(problem.get("message") or problem.text) or None
                        if kind != "skipped":
                            entry["type"] = problem.get("type")
                            entry["trace"] = _trace(problem.text)
                            failing.append({"class": case.get("classname") or item.get("name"),
                                            "test": case.get("name"), "kind": kind, "message": entry["message"],
                                            "type": entry["type"], "trace": entry["trace"]})
                        break
                    cases.append(entry)
                classes.append({"class": item.get("name") or report.stem[5:], "runner": runner,
                                **{k: int(item.get(k, "0") or 0) for k in ("tests", "failures", "errors", "skipped")},
                                "seconds": _seconds(item.get("time")), "cases": cases})
    return classes, failing


_RUNTIME_FRAME = re.compile(r"^\s*at (org\.junit\.|org\.opentest4j\.|org\.apiguardian\.|java\.base/|java\.|jdk\.|sun\.|"
                            r"org\.apache\.maven\.|org\.springframework\.test\.|org\.assertj\.|org\.hamcrest\.)")


def _trace(text: str | None) -> list[str]:
    """The head of a stack trace for people: the exception lines, then the frames of the code under test (test and
    product) before the frames of JUnit, the JDK and the build; the rest as a count."""
    lines = [ln.rstrip() for ln in (text or "").splitlines() if ln.strip()]
    first_frame = next((i for i, ln in enumerate(lines) if ln.lstrip().startswith("at ")), len(lines))
    message, frames = lines[:first_frame], lines[first_frame:]
    own = [ln for ln in frames if not _RUNTIME_FRAME.match(ln)]
    rest = [ln for ln in frames if _RUNTIME_FRAME.match(ln)]
    picked = (message[:4] + own + rest)[:TRACE_LINES]
    head = [ln if len(ln) <= 220 else ln[:217] + "..." for ln in picked]
    if len(lines) > len(picked):
        head.append(f"... {len(lines) - len(picked)} more lines")
    return head


def _seconds(text: str | None) -> float:
    try:
        return round(float((text or "0").replace(",", "")), 3)
    except ValueError:
        return 0.0


def _first_line(text: str | None, limit: int = 240) -> str:
    line = next((ln.strip() for ln in (text or "").splitlines() if ln.strip()), "")
    return line if len(line) <= limit else line[:limit - 3] + "..."


def read_coverage(module_dir: Path) -> dict | None:
    """The report-level JaCoCo counters of a module: {LINE: {covered, missed, ratio}, BRANCH: ..., ...}."""
    site = module_dir / "target" / "site"
    found = sorted(site.rglob("jacoco.xml"), key=lambda p: (len(p.parts), str(p))) if site.is_dir() else []
    if not found:
        return None
    try:
        report = ET.parse(found[0]).getroot()
    except ET.ParseError:
        return None
    counters = {}
    for counter in _children(report, "counter"):
        covered, missed = int(counter.get("covered", "0")), int(counter.get("missed", "0"))
        total = covered + missed
        counters[counter.get("type")] = {"covered": covered, "missed": missed,
                                         "ratio": round(covered / total, 4) if total else None}
    return {"file": found[0].relative_to(module_dir).as_posix(), "counters": counters}


def coverage_checks(log_text: str) -> dict[str, str]:
    """artifactId -> met | not_met, from each ``jacoco:check`` execution's output in the build log."""
    outcomes: dict[str, str] = {}
    current = None
    for line in log_text.splitlines():
        started = _CHECK.search(line)
        if started:
            current = started.group(1)
            continue
        if _PLUGIN.search(line):
            current = None
            continue
        if current is None:
            continue
        if "All coverage checks have been met" in line:
            outcomes[current] = "met"
        elif "Rule violated" in line or "Coverage checks have not been met" in line:
            outcomes[current] = "not_met"
    return outcomes


def _plain(text: str) -> str:
    return re.sub(r"[^a-z0-9]", "", text.lower())


def _same(label: str, candidate: str) -> bool:
    """Whether a reactor-summary label names the module: the same, cut short, or followed by its version."""
    a, b = _plain(label), _plain(candidate)
    if not a or not b:
        return False
    if a == b or (len(a) >= 12 and b.startswith(a)):
        return True
    return a.startswith(b) and re.fullmatch(r"[0-9]+(?:snapshot)?", a[len(b):]) is not None


def module_outcomes(log_text: str, modules: list[dict]) -> dict[str, str]:
    """artifactId -> SUCCESS | FAILURE | SKIPPED, from the build log's reactor summary. A module is named there by its
    ``<name>`` (else its artifactId), possibly followed by its version, padded with dots - or with none when the name
    is long, possibly cut short - and with any non-ASCII character mangled by the console: names are compared on
    their letters and digits only."""
    labels = []
    in_summary = False
    for line in log_text.splitlines():
        if "Reactor Summary" in line:
            in_summary = True
            continue
        if in_summary:
            found = _SUMMARY.match(line)
            if found:
                labels.append((found.group(1).strip(), found.group(2)))
            elif "BUILD SUCCESS" in line or "BUILD FAILURE" in line:
                break
    outcomes = {}
    for module in modules:
        for candidate in (module.get("name"), module["artifactId"]):
            if not candidate:
                continue
            match = next((status for label, status in labels if _same(label, candidate)), None)
            if match:
                outcomes[module["artifactId"]] = match
                break
    return outcomes


def collect(copy: Path, log_text: str | None, db2_connection: bool = False) -> list[dict]:
    """Every reactor module of a built tree with its test classes (level, reason, counts, test cases, real Db2,
    in-memory database), failing tests, coverage counters, coverage rules and - with a build log - the outcome of its
    coverage check and of its build. ``db2_connection``: the build ran with a Db2 connection in the environment (an L3
    class of a module whose datasource comes from the environment then ran on that Db2)."""
    modules = reactor(copy)
    built = module_outcomes(log_text, modules) if log_text is not None else {}
    checks = coverage_checks(log_text) if log_text is not None else {}
    for module in modules:
        folder = copy / module["module"]
        sources = test_sources(folder)
        classes, failing = read_suites(folder)
        datasource = datasource_from_environment(folder)
        env_db2 = db2_connection and datasource["environment"] and not datasource["inMemoryInTests"]
        for entry in classes:
            entry["level"], entry["reason"] = classify(entry["class"], sources, entry["runner"])
            source = sources.get(entry["class"].split("$", 1)[0])
            entry["source"] = source.relative_to(copy).as_posix() if source else None
            named = uses_db2(entry["class"], sources)
            entry["db2"] = named or (env_db2 and entry["level"] == "L3")
            entry["db2Evidence"] = ("the test names a Db2" if named else
                                    "the build's Db2 connection (the datasource comes from the environment)"
                                    if entry["db2"] else None)
            entry["inMemory"] = uses_in_memory(entry["class"], sources) or (
                datasource["inMemoryInTests"] and entry["level"] == "L3" and not entry["db2"])
        module.update({"outcome": built.get(module["artifactId"]), "classes": classes, "failing": failing,
                       "testSources": len(sources), "coverage": read_coverage(folder), "datasource": datasource,
                       "coverageCheck": checks.get(module["artifactId"], "not_evaluated" if log_text is not None
                                                   else "not_known")})
    return modules


def totals(classes: list[dict]) -> dict[str, int]:
    found = {"classes": len(classes), "tests": 0, "failures": 0, "errors": 0, "skipped": 0}
    for entry in classes:
        for key in ("tests", "failures", "errors", "skipped"):
            found[key] += entry.get(key, 0)
    found["passed"] = found["tests"] - found["failures"] - found["errors"] - found["skipped"]
    return found
