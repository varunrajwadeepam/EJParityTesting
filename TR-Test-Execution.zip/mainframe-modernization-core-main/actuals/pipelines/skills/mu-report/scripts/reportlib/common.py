"""Shared helpers of the mu-report scripts: one JSON object on stdout, exit 0 done, 2 decision or input needed,
1 failed. Python 3.10+, standard library plus PyYAML (through tools_config.py). Run from the workspace root."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path

for _stream in (sys.stdout, sys.stderr):
    if hasattr(_stream, "reconfigure"):
        _stream.reconfigure(encoding="utf-8", errors="replace", newline="\n")

HERE = Path(__file__).resolve().parent              # ${CLAUDE_PLUGIN_ROOT}/skills/mu-report/scripts/reportlib
SCRIPTS = HERE.parent
SKILL = SCRIPTS.parent                              # ${CLAUDE_PLUGIN_ROOT}/skills/mu-report
SKILLS = SKILL.parent                               # ${CLAUDE_PLUGIN_ROOT}/skills
SHARED_SCRIPTS = SKILLS.parent / "scripts"          # ${CLAUDE_PLUGIN_ROOT}/scripts
TOOLS_CONFIG = SHARED_SCRIPTS / "tools_config.py"


def slash_command(name: str) -> str:
    """`/pipelines:<name>` in the plugin, `/<name>` in a local .claude/."""
    return f"/pipelines:{name}" if (SKILLS.parent / ".claude-plugin" / "plugin.json").is_file() else f"/{name}"


class Stop(Exception):
    """code 1 = failed, 2 = decision or input needed; keyword arguments go into the JSON answer."""

    def __init__(self, message: str, code: int = 1, **extra):
        super().__init__(message)
        self.code = code
        self.extra = extra


def eprint(*xs) -> None:
    print(*xs, file=sys.stderr)


def emit(doc: dict) -> None:
    sys.stdout.write(json.dumps(doc, ensure_ascii=True) + "\n")
    sys.stdout.flush()


def main(fn) -> None:
    """fn() returns (exit code, answer dict) or an answer dict (exit 0)."""
    try:
        r = fn()
        code, doc = r if isinstance(r, tuple) else (0, r)
    except Stop as e:
        eprint(f"ERROR {e}")
        code = e.code
        doc = {"status": "failed" if code == 1 else "needs-input", "error": str(e), **e.extra}
    except SystemExit as e:
        if not isinstance(e.code, str):
            raise
        eprint(f"ERROR {e.code}")
        code, doc = 1, {"status": "failed", "error": e.code}
    except Exception as e:  # noqa: BLE001 - a crash is still one JSON object on stdout, exit 1
        traceback.print_exc(file=sys.stderr)
        code, doc = 1, {"status": "failed", "error": f"{type(e).__name__}: {e}"}
    doc = dict(doc or {})
    doc.setdefault("status", "ok" if code == 0 else "needs-input" if code == 2 else "failed")
    emit(doc)
    sys.exit(code)


class Parser(argparse.ArgumentParser):
    """argparse whose usage errors come back as one JSON object, exit 1."""

    def error(self, message):
        emit({"status": "failed", "error": f"usage: {message}", "usage": self.format_usage().strip()})
        sys.exit(1)


# --------------------------------------------------------------------------- paths


def rel(path: Path, base: Path) -> str:
    """`path` relative to `base` with forward slashes (absolute when on another drive)."""
    try:
        return os.path.relpath(path, base).replace("\\", "/")
    except ValueError:
        return Path(path).as_posix()


def long_path(path) -> Path:
    """Windows extended-length form of an absolute path (copies sit deeper than the product)."""
    resolved = Path(path).resolve()
    if os.name != "nt":
        return resolved
    text = str(resolved)
    if text.startswith("\\\\?\\"):
        return resolved
    if text.startswith("\\\\"):
        return Path("\\\\?\\UNC\\" + text[2:])
    return Path("\\\\?\\" + text)


# --------------------------------------------------------------------------- files and hashes


def sha256(data) -> str:
    return hashlib.sha256(data.encode("utf-8") if isinstance(data, str) else data).hexdigest()


def file_sha(path) -> str | None:
    path = Path(path)
    if not path.is_file():
        return None
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def read_text(path) -> str | None:
    path = Path(path)
    return path.read_text(encoding="utf-8", errors="replace") if path.is_file() else None


def read_json(path, what: str = "file"):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise Stop(f"{what} {Path(path).as_posix()} not found") from None
    except ValueError as e:
        raise Stop(f"{what} {Path(path).as_posix()} is not valid JSON: {e}") from None


def read_json_or_none(path):
    """The JSON of `path`, or None when it is missing or unreadable (a source that is not there yet)."""
    try:
        return json.loads(Path(path).read_text(encoding="utf-8")) if Path(path).is_file() else None
    except (ValueError, OSError):
        return None


def write_text(path, text: str) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)


def write_json(path, value) -> None:
    """Atomic: a temp file renamed over the old one."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    os.replace(tmp, path)


def iso_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# --------------------------------------------------------------------------- processes


def which(name: str) -> str | None:
    found = shutil.which(name)
    if found or os.name != "nt":
        return found
    for suffix in (".cmd", ".bat", ".exe"):
        found = shutil.which(name + suffix)
        if found:
            return found
    return None


def run(cmd, cwd=None, timeout: int = 3600, log=None, env=None) -> tuple[int, str]:
    """(returncode, stdout+stderr text). Never through a shell. `env`: the whole environment (None: inherited),
    never logged."""
    try:
        p = subprocess.run(list(map(str, cmd)), cwd=str(cwd) if cwd else None, capture_output=True,
                           timeout=timeout, stdin=subprocess.DEVNULL, env=env)
    except FileNotFoundError:
        raise Stop(f"{cmd[0]} is not installed or not on PATH") from None
    except subprocess.TimeoutExpired:
        raise Stop(f"{' '.join(map(str, cmd))} did not finish within {timeout}s") from None
    out = (p.stdout or b"").decode("utf-8", errors="replace") + (p.stderr or b"").decode("utf-8", errors="replace")
    if log is not None:
        write_text(log, "$ " + " ".join(map(str, cmd)) + "\n" + out)
    return p.returncode, out


def last_lines(text: str, count: int = 25) -> list[str]:
    return [line for line in text.splitlines() if line.strip()][-count:]


def home_m2() -> Path:
    """The user's Maven repository, a read-only tail (MU_REPORT_M2_TAIL overrides ~/.m2/repository)."""
    over = os.environ.get("MU_REPORT_M2_TAIL")
    return Path(over).resolve() if over else Path.home() / ".m2" / "repository"
