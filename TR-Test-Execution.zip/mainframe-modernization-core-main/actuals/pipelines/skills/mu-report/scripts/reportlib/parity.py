"""L4 - emulated functional parity, from what mu-validate keeps in `validation/`: `validation-state.json`,
`runs/<run-id>/summary.json`, `runs/<run-id>/run-1/e2e-replay.json`, `failures.md`, `validation-open-questions.md`.
Never `validation/.tmp/` or `validation/e2e/`.

The counts are the run summary's. The per-scenario rows join the framework's replay report (`run-1/e2e-replay.json`)
with the package `cases[]` (rules, paragraphs, decided answer, category, origin) and `failures.md` (class, confidence,
suspect rules, evidence). The classes of failure are shown as mu-validate classified them - never re-derived here.
"""

from __future__ import annotations

import re
from pathlib import Path

from . import clockreach, tests_level
from .common import read_json_or_none, read_text
from .levels import absent, worst
from .mufiles import Mu, product_module

OUTCOMES = ("PASSED", "FAILED", "BLOCKED", "NOT_APPLICABLE", "SKIPPED")
CLASSES = ("BINDING", "SOLUTION", "ENVIRONMENT", "PACKAGE", "DECISION", "UNKNOWN")
CLASS_OWNER = {"BINDING": "mu-build-tests", "PACKAGE": "mu-build-tests", "SOLUTION": "mu-implement",
               "ENVIRONMENT": "environment", "DECISION": None, "UNKNOWN": "a person (question)"}
DIFFS_SHOWN = 20
_RULE = re.compile(r"\b(R\d+[a-z]?)\b(?:\s*\(`([^`]*)`\))?")


def state(mu: Mu) -> dict | None:
    st = read_json_or_none(mu.validation / "validation-state.json")
    return st if isinstance(st, dict) else None


def latest_run(mu: Mu) -> tuple[Path, dict] | None:
    """The newest run's summary, by its finish time (never by folder name)."""
    runs = mu.validation / "runs"
    found = []
    for path in sorted(runs.glob("*/summary.json")) if runs.is_dir() else []:
        doc = read_json_or_none(path)
        if isinstance(doc, dict):
            found.append((str(doc.get("finishedAt") or doc.get("startedAt") or ""), path.parent.name, path, doc))
    if not found:
        return None
    newest = max(found, key=lambda f: (f[0], f[1]))
    return newest[2], newest[3]


# --------------------------------------------------------------------------- failures.md


def rule_refs(text: str | None) -> list[dict]:
    """`R13 (`WipService.create`), R2` -> [{id, home}] in order, each id once."""
    out, seen = [], set()
    for m in _RULE.finditer(text or ""):
        if m.group(1) not in seen:
            seen.add(m.group(1))
            out.append({"id": m.group(1), "home": m.group(2)})
    return out


def failures(text: str | None, run_id: str | None) -> dict:
    """`failures.md` of mu-validate: whether it is of run `run_id`, its header counts, its `Not compared` list, and
    per scenario the lines it wrote (`Class`, `Confidence`, `Pre-class`, `Operation`, `Rules`, `Suspect rules`, `Why`,
    `Fields`, `Difference`, `Exception`, `Signals`, `Next`)."""
    if text is None:
        return {"present": False, "ofRun": False, "items": [], "notCompared": []}
    head = re.search(r"^Run\s+(\S+)", text, re.M)
    of_run = bool(head and run_id and head.group(1) == run_id)
    classes_line = re.search(r"classes:\s*(.*)$", text, re.M)
    header_classes = {m.group(1): int(m.group(2)) for m in re.finditer(r"\b([A-Z]+)\s+(\d+)",
                                                                         classes_line.group(1))} \
        if classes_line else {}
    items, current, section = [], None, None
    not_compared = []
    for raw in text.splitlines():
        line = raw.rstrip()
        m = re.match(r"^##\s+(\S+)\s+-\s+(.*)$", line)
        if m:
            current = {"id": m.group(1), "title": m.group(2).strip(), "class": None, "confidence": None}
            items.append(current)
            section = None
            continue
        if line.startswith("## "):
            current, section = None, line[3:].strip().lower()
            continue
        if section == "not compared" and line.startswith("- ") and line[2:].strip().lower() != "none":
            not_compared.append(line[2:].strip())
            continue
        if current is None or ":" not in line:
            continue
        last = None
        for part in line.split(" · "):
            if ":" in part and re.match(r"^[A-Z][\w -]*:", part):
                key, value = part.split(":", 1)
                last = key.strip().lower()
                current[last] = value.strip()
            elif last:
                current[last + "Detail"] = part.strip()
    for f in items:
        f["class"] = (f.get("class") or "").strip("* ") or None
        f["suspects"] = rule_refs(f.get("suspect rules"))
        f["ruleRefs"] = rule_refs(f.get("rules"))
    items = [f for f in items if f.get("class")]
    return {"present": True, "ofRun": of_run, "runId": head.group(1) if head else None, "items": items,
            "headerClasses": header_classes, "notCompared": not_compared}


# --------------------------------------------------------------------------- the scenarios


def _by_kind(diffs) -> dict:
    out: dict[str, int] = {}
    for d in diffs or []:
        if isinstance(d, dict):
            out[str(d.get("kind"))] = out.get(str(d.get("kind")), 0) + 1
    return out


def _decided(d: dict | None) -> dict | None:
    if not isinstance(d, dict):
        return None
    return {"source": d.get("source"), "status": d.get("status"), "recordedStatus": d.get("recordedStatus"),
            "tables": d.get("tables"), "rules": d.get("rules") or []}


def _row(s: dict, case: dict, failure: dict | None) -> dict:
    strict, contract = s.get("strict") or {}, s.get("contract") or {}
    verdict = contract if s.get("verdictProfile") == "contract" else (strict if s.get("verdictProfile") else contract)
    status = s.get("status") if s.get("status") in OUTCOMES else "NOT_RUN"
    shown = [{"path": d.get("field"), "kind": d.get("kind"), "expected": d.get("legacy"), "actual": d.get("target")}
             for d in (verdict.get("diffs") or [])[:DIFFS_SHOWN] if isinstance(d, dict)] if status != "PASSED" else []
    decided = _decided(case.get("decidedAnswer"))
    not_compared = []
    if decided and decided.get("tables") == "notCompared":
        not_compared.append("the tables after the call (decided answer)")
    for c in case.get("compare") or []:
        if isinstance(c, dict) and c.get("mode") == "ignore":
            not_compared.append(f"{c.get('path')}" + (f" ({c.get('reason')})" if c.get("reason") else ""))
    row = {"id": s.get("scenarioId"), "title": s.get("title") or case.get("name"), "status": status,
           "strict": strict.get("status"), "contract": contract.get("status"),
           "profile": s.get("verdictProfile"), "lens": s.get("lens"),
           "strictByKind": _by_kind(strict.get("diffs")), "contractByKind": _by_kind(contract.get("diffs")),
           "differences": shown, "differenceCount": len(verdict.get("diffs") or []),
           "notes": s.get("notes") or [], "hypotheses": s.get("hypotheses") or [],
           "message": s.get("message") if status != "PASSED" else None,
           "rules": case.get("ruleIds") or [], "paragraphs": case.get("paragraphs") or [],
           "category": case.get("category"), "origin": case.get("origin"), "caseStatus": case.get("status"),
           "clockSensitive": bool(case.get("clockSensitive")), "decided": decided,
           "stackDivergence": case.get("stackDivergence") or [], "notCompared": not_compared,
           "reason": case.get("reason") if status != "PASSED" else None, "inPackage": bool(case)}
    if failure:
        row["failure"] = {"class": failure.get("class"), "confidence": failure.get("confidence"),
                          "preClass": failure.get("pre-class"), "suspects": failure.get("suspects") or [],
                          "rules": failure.get("ruleRefs") or [], "operation": failure.get("operation"),
                          "http": failure.get("operationDetail"), "why": failure.get("why"),
                          "exception": failure.get("exception"), "difference": failure.get("difference"),
                          "next": failure.get("next")}
    return row


def _from_summary(summary: dict) -> list[dict]:
    """Rows from the summary's lists when the replay report is not there: failed[], blocked[], other[]."""
    out = []
    for key, status in (("failed", "FAILED"), ("blocked", "BLOCKED")):
        for f in summary.get(key) or []:
            if isinstance(f, dict):
                out.append({"scenarioId": f.get("scenarioId"), "title": f.get("title"), "status": status,
                            "message": f.get("message"), "hypotheses": f.get("hypotheses") or []})
    for f in summary.get("other") or []:
        if isinstance(f, dict):
            out.append({"scenarioId": f.get("scenarioId"), "status": f.get("status"), "message": f.get("reason")})
    return out


def decided_summary(rows: list[dict]) -> dict:
    mine = [r for r in rows if r.get("decided")]

    def by_source(status):
        found: dict[str, int] = {}
        for r in mine:
            if r["status"] == status:
                key = str(r["decided"].get("source"))
                found[key] = found.get(key, 0) + 1
        return found

    return {"scenarios": len(mine), "passed": sum(1 for r in mine if r["status"] == "PASSED"),
            "failed": sum(1 for r in mine if r["status"] == "FAILED"),
            "passedBySource": by_source("PASSED"), "failedBySource": by_source("FAILED")}


# --------------------------------------------------------------------------- the clock scan (decision 8)


def clock_scan(mu: Mu, lc: dict) -> dict:
    """Where the product reads the time past the injected Clock - only when the package has clock-sensitive cases."""
    sensitive = ((lc.get("counts") or {}).get("clockSensitive")) or 0
    if not sensitive:
        return {"ran": False, "reason": "no clock-sensitive case in the package"}
    module = product_module(mu)
    root = (mu.solution / module["dir"] / "src" / "main" / "java") if module and mu.solution else None
    if root is None or not root.is_dir():
        return {"ran": False, "reason": "the product module's src/main/java is not there", "clockSensitive": sensitive}
    texts = {p: p.read_text(encoding="utf-8", errors="replace") for p in sorted(root.rglob("*.java"))}
    found = clockreach.scan(texts, lambda p: mu.rel(p))
    unpinned = [r for r in found["reads"] if not r["pinned"]]
    return {"ran": True, "clockSensitive": sensitive, "files": len(texts), "root": mu.rel(root),
            "unpinned": found["unpinned"], "pinnedBeans": found["pinnedBeans"], "byKind": found["byKind"],
            "reads": unpinned[:20], "text": clockreach.describe(found)}


# --------------------------------------------------------------------------- the level


def read(mu: Mu, lc: dict, product: dict | None) -> dict:
    """The L4 level: evidence with status and state, or a state with its owner and the next command."""
    from . import l0                                  # the shared open-questions parser
    st = state(mu)
    run = latest_run(mu)
    if st is None and run is None:
        if not lc.get("present"):
            return absent("not_reached", "no test package yet: mu-validate replays the package of mu-build-tests",
                          lc.get("owner") if lc.get("state") == "not_reached" else "mu-build-tests",
                          lc.get("next") if lc.get("state") == "not_reached" else mu.command("mu-build-tests"),
                          short="waiting for the test package")
        return absent("not_produced", "validation/validation-state.json is not there: the package has not been "
                      "replayed yet", "mu-validate", mu.command("mu-validate"), short="not replayed yet")
    st = st or {}
    qfile = mu.validation / "validation-open-questions.md"
    vq = l0.questions(read_text(qfile), mu.rel(qfile))
    gate = st.get("gate") or {}
    gate_info = {"settled": gate.get("settled"), "open": gate.get("open"), "by": gate.get("by"), "at": gate.get("at"),
                 "accepted": gate.get("accepted"), "disputed": gate.get("disputed") or []}
    if run is None:
        done = [k for k, v in (st.get("steps") or {}).items() if isinstance(v, dict) and v.get("exit") == 0]
        reason = "mu-validate has not finished a replay run yet" + (f" (last step done: {done[-1]})" if done else "")
        if gate.get("open"):
            reason += f"; the record gate {gate['open']} waits for a named person's answer"
        return absent("not_run", reason, "mu-validate", mu.command("mu-validate"), short="no replay run yet",
                      gate=gate_info, questions=vq)
    path, summary = run
    run_id = summary.get("runId") or path.parent.name
    entry = summary.get("entry") or lc.get("entry")
    replay_path = path.parent / "run-1" / "e2e-replay.json"
    replay = read_json_or_none(replay_path)
    raw = (replay or {}).get("scenarios") if isinstance(replay, dict) else None
    per_scenario = "replay" if isinstance(raw, list) else "summary"
    if raw is None:
        raw = _from_summary(summary)
    package = tests_level.package_doc(mu, entry, read_json_or_none(tests_level.state_file(mu)))
    cases = {c.get("id"): c for c in (package or {}).get("cases") or [] if isinstance(c, dict)}
    fdoc = failures(read_text(mu.validation / "failures.md"), run_id)
    by_failure = {f["id"]: f for f in fdoc["items"]} if fdoc["ofRun"] else {}
    rows = [_row(s, cases.get(s.get("scenarioId")) or {}, by_failure.get(s.get("scenarioId")))
            for s in raw if isinstance(s, dict) and s.get("scenarioId")]
    counts = {k: int((summary.get("counts") or {}).get(k, 0)) for k in OUTCOMES}
    total = summary.get("scenarios") if isinstance(summary.get("scenarios"), int) else sum(counts.values())
    runnable = counts["PASSED"] + counts["FAILED"]
    per_run = [{"run": r.get("run"), "counts": r.get("counts") or {}, "digest": r.get("digest"),
                "identicalToPrevious": r.get("identicalToPrevious"), "seconds": r.get("seconds"),
                "surefire": r.get("surefire") or {}} for r in summary.get("perRun") or [] if isinstance(r, dict)]
    digests = {r["digest"] for r in per_run if r.get("digest")}
    identical = bool(per_run) and len(digests) == 1 and not summary.get("differencesBetweenRuns")
    # hashes of what was replayed against what is there now
    snap = summary.get("snapshot") or {}
    pkg = summary.get("package") or {}
    imported = (st.get("imports") or {}).get(entry or "") or {}
    current_pkg = (lc.get("package") or {}).get("contentHash")
    fw_installed = (st.get("framework") or {}).get("fingerprint")
    hashes = {
        "product": {"replayed": snap.get("hash"), "revision": snap.get("revision"),
                    "current": (product or {}).get("hash"),
                    "isCurrent": (snap.get("hash") == product["hash"]) if product and snap.get("hash") else None},
        "package": {"replayed": pkg.get("contentHash"), "version": pkg.get("version"),
                    "installed": imported.get("contentHash"), "current": current_pkg,
                    "matchesInstalled": (pkg.get("contentHash") == imported.get("contentHash"))
                    if imported.get("contentHash") and pkg.get("contentHash") else None,
                    "isCurrent": (pkg.get("contentHash") == current_pkg) if current_pkg and pkg.get("contentHash")
                    else None},
        "framework": {"replayed": summary.get("framework"), "installed": fw_installed,
                      "version": (st.get("framework") or {}).get("version"),
                      "matchesInstalled": (summary.get("framework") == fw_installed)
                      if fw_installed and summary.get("framework") else None}}
    # failure classes, as mu-validate wrote them
    analysis = st.get("analysis") or {}
    recorded_classes = analysis.get("classCounts") if analysis.get("runId") == run_id else None
    listed = {}
    for f in fdoc["items"] if fdoc["ofRun"] else []:
        listed[f["class"]] = listed.get(f["class"], 0) + 1
    suspects: dict[str, dict] = {}
    for f in fdoc["items"] if fdoc["ofRun"] else []:
        for r in f["suspects"]:
            entry_row = suspects.setdefault(r["id"], {"id": r["id"], "home": r.get("home"), "scenarios": [],
                                                      "classes": []})
            entry_row["scenarios"].append(f["id"])
            if f["class"] not in entry_row["classes"]:
                entry_row["classes"].append(f["class"])
    classes = {"recorded": recorded_classes, "listed": listed, "header": fdoc.get("headerClasses") or {},
               "file": mu.rel(mu.validation / "failures.md") if fdoc["present"] else None,
               "ofRun": fdoc["ofRun"], "notCompared": fdoc.get("notCompared") or [],
               "suspectRules": sorted(suspects.values(), key=lambda r: (-len(r["scenarios"]),
                                                                        int(re.sub(r"\D", "", r["id"]) or 0))),
               "owners": {c: CLASS_OWNER.get(c) for c in listed}}
    clock = clock_scan(mu, lc)
    warnings = list(summary.get("warnings") or [])
    if clock.get("ran") and clock.get("unpinned"):
        warnings.append(f"clock: {clock['text']}")
    if hashes["product"]["isCurrent"] is False:
        warnings.append(f"the product has changed since this run (replayed {snap.get('revision')}, now "
                        f"{(product or {}).get('revision')})")
    if hashes["package"]["isCurrent"] is False:
        warnings.append("the test package has changed since this run")
    if hashes["package"]["matchesInstalled"] is False:
        warnings.append("the run replayed another package than the one mu-validate installed last")
    if fdoc["present"] and not fdoc["ofRun"] and counts["FAILED"]:
        warnings.append(f"failures.md is of run {fdoc.get('runId')}, not of {run_id}: the failures are not "
                        "classified for this run")
    if per_scenario == "summary":
        warnings.append("run-1/e2e-replay.json is not there: rows from the summary's lists only")
    missing = [s for s in rows if not s["inPackage"]]
    if package is not None and missing:
        warnings.append(f"{len(missing)} scenario(s) of the run are not cases of the current package")
    status = "fail" if counts["FAILED"] else "warn" if counts["BLOCKED"] or not summary.get("repeatable") \
        else "pass" if runnable else "none"
    if warnings and status == "pass":
        status = "warn"
    if gate.get("open"):
        status = worst([status, "warn"])
    class_text = ", ".join(f"{c} {n}" for c, n in sorted((recorded_classes or listed).items(),
                                                         key=lambda kv: CLASSES.index(kv[0]) if kv[0] in CLASSES
                                                         else 99))
    parts = [f"{counts['PASSED']} passed", f"{counts['FAILED']} failed"]
    parts += [f"{counts[k]} {k.lower().replace('_', ' ')}" for k in ("BLOCKED", "NOT_APPLICABLE", "SKIPPED")
              if counts[k]]
    runs_text = (f"{summary.get('runs')} runs identical" if identical else
                 f"{summary.get('runs')} runs, {len(summary.get('differencesBetweenRuns') or [])} differences")
    headline = f"{', '.join(parts)} of {total} scenarios; {runs_text}" + (f"; {class_text}" if class_text else "")
    suspect_text = ", ".join(f"{r['id']} x{len(r['scenarios'])}" for r in classes["suspectRules"])
    sentence = (f"L4: {counts['PASSED']} of {runnable} runnable scenarios match the legacy under the contract "
                f"comparison and {counts['FAILED']} differ" + (f" ({class_text}" + (f"; suspect rules {suspect_text}"
                                                                                    if suspect_text else "") + ")"
                                                                if class_text else "")
                + f"; {runs_text}")
    return {
        "available": True, "status": status, "state": "results", "headline": headline, "short": headline,
        "sentence": sentence, "runId": run_id, "file": mu.rel(path),
        "replayFile": mu.rel(replay_path) if isinstance(replay, dict) else None, "perScenario": per_scenario,
        "entry": entry, "mode": summary.get("mode"), "startedAt": summary.get("startedAt"),
        "finishedAt": summary.get("finishedAt"), "seconds": summary.get("seconds"),
        "runs": summary.get("runs"), "repeatable": summary.get("repeatable"), "identical": identical,
        "perRun": per_run, "differencesBetweenRuns": len(summary.get("differencesBetweenRuns") or []),
        "counts": counts, "total": total, "runnable": runnable, "columns": summary.get("columns") or {},
        "goldenStates": summary.get("goldenStates") or {}, "environment": {
            k: v for k, v in (summary.get("environment") or {}).items() if "PASSWORD" not in k.upper()},
        "previousRunId": summary.get("previousRunId"), "identicalToPrevious": summary.get("identicalToPrevious"),
        "delta": summary.get("deltaFromPrevious"), "hashes": hashes, "classes": classes,
        "decided": decided_summary(rows), "scenarios": rows,
        "runsListed": [{"runId": r.get("runId"), "finishedAt": r.get("finishedAt"), "counts": r.get("counts"),
                        "repeatable": r.get("repeatable")} for r in st.get("runs") or [] if isinstance(r, dict)],
        "gate": gate_info, "acceptedScenarios": len(st.get("acceptance") or {}),
        "questions": vq, "clock": clock, "warnings": warnings,
        "productModule": ((st.get("solution") or {}).get("facts") or {}).get("productModule"),
        "testModule": (st.get("solution") or {}).get("module"),
    }


def input_files(mu: Mu) -> list[Path]:
    files = [mu.validation / "validation-state.json", mu.validation / "failures.md",
             mu.validation / "validation-open-questions.md"]
    run = latest_run(mu)
    if run:
        files += [run[0], run[0].parent / "run-1" / "e2e-replay.json"]
    return [f for f in files if f.is_file()]
