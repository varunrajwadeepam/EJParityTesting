"""The vocabulary of the report: statuses, the test pyramid's layers and the states of a level.

A level's status is pass / warn / fail / none (none = nothing to judge). Its *state* says why, so a reader never
takes "none" for "passed":

  results          evidence was read and counted
  not_reached      the command before it has not delivered what it needs
  not_produced     the file this level reads does not exist yet (with its owner)
  not_run          a check that could have run did not (with its reason and owner)
  not_implemented  this release of the report does not read the level yet
  planned / out_of_scope   later releases, or the client's

A level without evidence is `none` with `reason`, `owner` (the command whose move it is) and `next` (the command
line to run).
"""

from __future__ import annotations

STATUSES = ("pass", "warn", "fail", "none")
_SEVERITY = {"none": 0, "pass": 1, "warn": 2, "fail": 3}
STATES = ("results", "not_reached", "not_produced", "not_run", "not_implemented", "planned", "out_of_scope")
STATE_LABELS = {"results": "Results", "not_reached": "Not reached", "not_produced": "Not produced",
                "not_run": "Not run", "not_implemented": "Not implemented", "planned": "Planned",
                "out_of_scope": "Out of scope"}

# id, name, band, in scope of this release; in page order (LC, the oracle, before L4 that replays it)
LAYERS = (
    ("L0", "Design gates", "design", True),
    ("L1", "Unit", "design", True),
    ("L2", "Contract", "design", True),
    ("L3", "Integration", "design", True),
    ("LC", "Legacy characterisation", "foundation", True),
    ("L4", "Emulated functional parity", "parity", True),
    ("L5", "Real functional parity", "parity", False),
    ("L6", "User acceptance", "acceptance", False),
    ("L7", "Non-functional", "pillar", False),
    ("L8", "Test effectiveness", "pillar", False),
)


def worst(statuses) -> str:
    found = [s for s in statuses if s in _SEVERITY]
    return max(found, key=_SEVERITY.get) if found else "none"


def severity(status: str) -> int:
    return _SEVERITY.get(status, 0)


def absent(state: str, reason: str, owner: str | None, next_command: str | None, short: str | None = None,
           **extra) -> dict:
    """A level with nothing to show: status none, its state, why, whose move it is and the command to run."""
    assert state in STATES and state != "results", state
    return {"available": False, "status": "none", "state": state, "reason": reason, "short": short or reason,
            "owner": owner, "next": next_command, **extra}
