"""L1 unit, L2 contract, L3 integration - the product's own suites. Their source, in this order:

  1. the checks record `validation/target/checks/<hash16>.json` of the product's current content hash, written by an
     earlier `--confirm` (of any MU of the shared solution);
  2. else the reports the product's last build left in `solution/<module>/target/` (surefire / failsafe XML,
     JaCoCo), read where they are - the revision they were built from is not known;
  3. else "not run" - `--confirm` runs them.

`--confirm` builds a copy of the product (by content hash) in `validation/target/checks/<hash16>/` and writes the
record; it is reused for the same hash unless `--rebuild`. `solution/` is never written - not even `target/`. A
failing test, a module that does not build or a coverage gate that is not met is a result, never a script failure.
"""

from __future__ import annotations

import os
import re
import shutil
import time
from datetime import datetime, timezone
from pathlib import Path

from . import buildchecks, maven
from .common import Stop, home_m2, iso_now, last_lines, long_path, read_json_or_none, write_json
from .mufiles import Mu, hash_of, manifest_of, product_module, reachable, test_database

COMMAND = "mvn verify -fae -Dmaven.test.failure.ignore=true -Dspring-boot.repackage.skip=true"
COVERAGE_TARGET = 0.80                   # Test Strategy: L1 80% line coverage
LEVEL_RULE = "U-95"                      # the level rule a record's classes were assigned by
ENV_DEFAULTS = {"url": "DB_URL", "username": "DB_USERNAME", "password": "DB_PASSWORD", "schema": "DB_SCHEMA"}
_PLACEHOLDER = r"\$\{(\w+)(?::[^}]*)?\}"


def checks_dir(mu: Mu) -> Path:
    return mu.test_solution / "target" / "checks"


def record_file(mu: Mu, revision: str) -> Path:
    return checks_dir(mu) / f"{revision}.json"


def checks_record(mu: Mu, revision: str | None) -> dict | None:
    """The completed checks record of `revision` (hash16), its classes' levels by the current rule; None when there
    is none."""
    if not revision:
        return None
    record = read_json_or_none(record_file(mu, revision))
    if not isinstance(record, dict) or record.get("status") != "completed" or record.get("revision") != revision:
        return None
    record = dict(record)
    record.setdefault("mode", "confirm")
    record["source"] = "checks"
    if record.get("levelRule") != LEVEL_RULE:
        _relevel(record, mu)
    return record


def _relevel(record: dict, mu: Mu) -> None:
    """A record of an earlier rule: the levels re-read from the sources of its copy when the copy is still there."""
    copy = mu.workspace / (record.get("copy") or f"validation/target/checks/{record.get('revision')}")
    reread = False
    for module in record.get("modules") or []:
        folder = long_path(copy / module.get("module", ""))
        sources = buildchecks.test_sources(folder) if folder.is_dir() else {}
        if not sources:
            continue
        reread = True
        for entry in module.get("classes") or []:
            entry["level"], entry["reason"] = buildchecks.classify(entry["class"], sources,
                                                                   entry.get("runner", "surefire"))
    record["note"] = ("recorded by an earlier rule: the test levels re-read from the checked copy"
                      if reread else "recorded by an earlier rule: the levels are the earlier rule's - --confirm "
                      "--rebuild assigns them by the current one")


def last_build_files(solution: Path) -> list[Path]:
    """The report files of the product's last build: every reactor module's `target/{surefire,failsafe}-reports/
    TEST-*.xml` and `target/site/**/jacoco.xml`."""
    folders = [solution / m for m in buildchecks.module_folders(solution)] or [solution]
    files = []
    for folder in folders:
        files += buildchecks.report_files(folder)
    return files


def _newest(files: list[Path]) -> str | None:
    times = [p.stat().st_mtime for p in files if p.name.startswith("TEST-")]
    if not times:
        return None
    return datetime.fromtimestamp(max(times), tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def fast(mu: Mu, product: dict | None, implement: dict) -> dict:
    """The source of L1 - L3 without building anything (see the module text). `product`: mufiles.identity;
    `implement`: l0.recorded_test_database (whether mu-implement's integration tests ran on a Db2)."""
    revision = (product or {}).get("revision")
    record = checks_record(mu, revision)
    if record:
        record["reused"] = True
        return record
    confirm = mu.command("mu-report", "--confirm")
    if not product or not product.get("hasPom"):
        reason = ("mu.yaml names no solution folder" if mu.solution is None else
                  f"{mu.rel(mu.solution)} holds no pom.xml: there is no product to read")
        return {"status": "not_available", "mode": "fast", "source": None, "state": "not_reached",
                "reason": reason, "short": "no product to read", "owner": "mu-implement",
                "next": mu.command("mu-implement")}
    files = last_build_files(mu.solution)
    if not any(p.name.startswith("TEST-") for p in files):
        return {"status": "not_available", "mode": "fast", "source": None, "state": "not_run",
                "reason": f"the product's suites have not been run here: no checks record for {revision} and no "
                          f"build reports in {mu.rel(mu.solution)} (target/ is not kept)",
                "short": "not run - --confirm runs them", "owner": "mu-report", "next": confirm}
    db2 = bool(implement.get("testDatabaseIsDb2"))
    modules = buildchecks.collect(mu.solution, None, db2_connection=db2)
    if db2:
        for module in modules:
            for entry in module["classes"]:
                if entry.get("db2") and str(entry.get("db2Evidence") or "").startswith("the build's"):
                    entry["db2Evidence"] = "the implementation's record: " + (implement.get("testDatabase") or "")
    return {"status": "completed", "mode": "fast", "source": "last-build", "revision": None, "kind": "last-build",
            "reportsWrittenAt": _newest(files), "command": None, "build": None, "exitCode": None,
            "modules": modules, "levelRules": buildchecks.LEVEL_RULES, "levelRule": LEVEL_RULE,
            "note": f"the reports the product's last build left in {mu.rel(mu.solution)} - not re-run by the "
                    f"report; the revision they were built from is not recorded"}


def database_env(mu: Mu, db: dict) -> tuple[dict, dict]:
    """The product's datasource variables, filled from the test database: the `${NAME}` placeholders of
    `spring.datasource.url / username / password` and of a `schema:` key (e.g. `hikari.schema`) or `SET SCHEMA` in the
    main `application*.yml|yaml|properties` of the product module (then the other reactor modules); DB_URL /
    DB_USERNAME / DB_PASSWORD / DB_SCHEMA for those the configuration does not name. Returns (values, names), names =
    {url, username, password, schema, files, fromConfiguration}; the values hold the password and are never written."""
    names = dict(ENV_DEFAULTS)
    found: set[str] = set()
    files: list[str] = []
    folders = []
    module = product_module(mu)
    if module and mu.solution is not None:
        folders.append(mu.solution / module["dir"])
    if mu.solution is not None and (mu.solution / "pom.xml").is_file():
        folders += [mu.solution / m for m in buildchecks.module_folders(mu.solution)] + [mu.solution]
    seen = set()
    for folder in folders:
        resources = folder / "src" / "main" / "resources"
        if str(resources) in seen or not resources.is_dir():
            continue
        seen.add(str(resources))
        for path in sorted(resources.glob("application*")):
            if path.suffix not in (".yml", ".yaml", ".properties"):
                continue
            text = path.read_text(encoding="utf-8", errors="replace")
            hit = False
            for key in ("url", "username", "password", "schema"):
                if key in found:
                    continue
                match = (re.search(rf"^\s*{key}\s*:\s*['\"]?{_PLACEHOLDER}", text, re.M)
                         or re.search(rf"^\s*spring\.datasource\.(?:hikari\.)?{key}\s*=\s*{_PLACEHOLDER}", text, re.M))
                if key == "schema" and not match:
                    match = re.search(rf"SET\s+(?:CURRENT\s+)?SCHEMA\s*=?\s*{_PLACEHOLDER}", text, re.I)
                if match:
                    names[key] = match.group(1)
                    found.add(key)
                    hit = True
            if hit:
                files.append(mu.rel(path))
    url = f"jdbc:db2://{db['host']}:{db['port']}/{db['database']}"
    values = {names["url"]: url, names["username"]: db.get("user") or "", names["password"]: db.get("password") or "",
              names["schema"]: db.get("schema") or ""}
    return values, {**names, "files": files, "fromConfiguration": sorted(found)}


def installed_snapshot(mu: Mu, product: dict) -> Path | None:
    """mu-validate's installed snapshot `validation/target/product/<hash16>/` when its hash is the product's."""
    products = mu.test_solution / "target" / "product"
    installed = read_json_or_none(products / "installed.json") or {}
    folder = products / product["revision"]
    if installed.get("hash") == product["hash"] and (folder / "pom.xml").is_file():
        return folder
    return None


def materialize(mu: Mu, product: dict, copy: Path) -> dict:
    """Write the copy of the product (its content-hash file list; target/ and the rest left out): from the installed
    snapshot when its hash matches, else from `solution/`. The copy's own content hash must be the product's."""
    wanted = manifest_of(mu.solution)
    if hash_of(wanted) != product["hash"]:
        raise Stop(f"{mu.rel(mu.solution)} changed while the report ran: run again")
    snapshot = installed_snapshot(mu, product)
    source, origin = (snapshot, "snapshot") if snapshot is not None else (mu.solution, "solution")
    if snapshot is not None and manifest_of(snapshot) != wanted:
        source, origin = mu.solution, "solution"          # a snapshot edited by hand: not used
    base, out = long_path(source), long_path(copy)
    if out.exists():
        shutil.rmtree(out)
    for name in sorted(wanted):
        dest = out / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(base / name, dest)
    copied = manifest_of(copy)
    if hash_of(copied) != product["hash"]:
        raise Stop(f"the copy in {mu.rel(copy)} is not the product {product['revision']} (it changed during the copy?): "
                   f"run again")
    return {"source": origin, "dir": mu.rel(source), "files": len(copied), "hash": product["hash"]}


def confirm(mu: Mu, product: dict | None, rebuild: bool = False) -> dict:
    """Build a copy of the product by content hash in `validation/target/checks/<hash16>/` with
    `mvn verify -fae -Dmaven.test.failure.ignore=true` (private repository validation/target/m2, ~/.m2 a read-only
    tail; the product's datasource variables from tools.yaml test-db2, else db2), read its suites and write the record
    `<hash16>.json`. A completed record of the same hash is reused (nothing is called) unless `rebuild`. Exit 2 when
    there is no test database (`input_required`) or it does not answer (`database_unreachable`)."""
    if not product or not product.get("hasPom"):
        where = mu.rel(mu.solution) if mu.solution is not None else "mu.yaml solution (not set)"
        raise Stop(f"{where} holds no pom.xml: there is no product to build", code=2, reason="no_product",
                   next=mu.command("mu-implement"))
    revision = product["revision"]
    if not rebuild:
        found = checks_record(mu, revision)
        if found:
            found["reused"] = True
            return found
    db = test_database(mu, with_secret=True)
    if db is None:
        raise Stop(f"{mu.rel(mu.tools_file)} defines no test database (test-db2, or db2): define it, start it and "
                   f"re-run with --confirm", code=2, reason="input_required")
    where = {k: db[k] for k in ("source", "host", "port", "database", "schema")}
    if not reachable(db["host"], db["port"]):
        raise Stop(f"the test database {db['source']} ({db['host']}:{db['port']}/{db['database']}) does not answer: "
                   f"start it (the parity tester starts the parity Db2) and re-run with --confirm", code=2,
                   reason="database_unreachable", database=where)
    checks = checks_dir(mu)
    for old in sorted(checks.iterdir()) if checks.is_dir() else []:
        if old.is_dir():                              # the disposable copies; the records (*.json) stay
            shutil.rmtree(long_path(old))
    copy = checks / revision
    made = materialize(mu, product, copy)
    values, names = database_env(mu, db)
    env = dict(os.environ)
    env.update(values)
    log = checks / f"{revision}.log"                 # beside the record; the copy folder is disposable
    started_at, started = iso_now(), time.monotonic()
    code, out = maven.mvn(["-f", str(copy / "pom.xml"), "verify", "-fae", "-Dmaven.test.failure.ignore=true",
                           "-Dspring-boot.repackage.skip=true"], cwd=copy, log=log,
                          head=mu.test_solution / "target" / "m2", tail=home_m2(), env=env)
    modules = buildchecks.collect(long_path(copy), out, db2_connection=True)
    record = {"schemaVersion": 2, "generatedBy": "mu-report", "status": "completed", "mode": "confirm",
              "source": "checks", "revision": revision, "hash": product["hash"], "kind": "content-hash",
              "solution": product.get("solution"), "copiedFrom": made, "command": COMMAND,
              "startedAt": started_at, "finishedAt": iso_now(), "seconds": round(time.monotonic() - started, 1),
              "exitCode": code, "build": "success" if code == 0 else "failed", "log": mu.rel(log),
              "copy": mu.rel(copy), "repository": mu.rel(mu.test_solution / "target" / "m2"),
              "database": {**where, "user": db.get("user"),
                           "environment": {k: names[k] for k in ("url", "username", "password", "schema")},
                           "environmentFrom": names["files"]},
              "levelRules": buildchecks.LEVEL_RULES, "levelRule": LEVEL_RULE, "modules": modules}
    if not modules:
        record.update({"status": "failed", "reason": "the build produced no module to read", "tail": last_lines(out)})
    write_json(record_file(mu, revision), record)
    if record["status"] != "completed":
        raise Stop(f"the checks build of {revision} produced nothing to read; see {mu.rel(log)}", log=mu.rel(log),
                   tail=record["tail"])
    record["reused"] = False
    return record


def levels(record: dict | None, mu_artifact: str | None, app_artifact: str | None = None) -> dict:
    """L1, L2 and L3 of this MU from a build record - the modules it counts: its own, those it depends on and the
    application; the other MUs' modules are listed, never counted. Unknown MU module: every module counts."""
    if not record or record.get("status") != "completed":
        record = record or {}
        reason = record.get("reason") or "the product's suites were not run"
        return {"available": False, "state": record.get("state") or "not_run", "reason": reason,
                "short": record.get("short") or reason, "owner": record.get("owner"), "next": record.get("next"),
                "mode": record.get("mode"), "source": None, "modules": [], "coverageTarget": COVERAGE_TARGET,
                "levels": {lv: {"status": "none", "totals": buildchecks.totals([]), "failing": [], "notes": [],
                                "byModule": [], "realDb2": False, "inMemory": False,
                                "rule": buildchecks.LEVEL_RULES[lv], "classes": []}
                           for lv in buildchecks.LEVELS}}
    modules = record.get("modules") or []
    known = {m["artifactId"] for m in modules}
    if mu_artifact in known:
        role = buildchecks.roles(modules, mu_artifact, app_artifact)
    else:
        role = {a: "application" if a == app_artifact else "shared" for a in known}
    counted = [m for m in modules if role.get(m["artifactId"]) != "other"]
    rows = []
    for m in modules:
        counters = (m.get("coverage") or {}).get("counters", {})
        minimum = next((r["minimum"] for r in m.get("coverageRules") or []
                        if r.get("counter") == "LINE" and r.get("value") == "COVEREDRATIO"), None)
        rows.append({"module": m["module"], "artifactId": m["artifactId"], "role": role.get(m["artifactId"], "other"),
                     "outcome": m.get("outcome"), "testSources": m.get("testSources"),
                     "byLevel": {lv: buildchecks.totals([c for c in m.get("classes") or [] if c["level"] == lv])
                                 for lv in buildchecks.LEVELS},
                     "lineCoverage": counters.get("LINE"), "instructionCoverage": counters.get("INSTRUCTION"),
                     "branchCoverage": counters.get("BRANCH"), "lineMinimum": minimum,
                     "hasGate": bool(m.get("coverageRules")), "coverageCheck": m.get("coverageCheck"),
                     "inMemoryInTests": (m.get("datasource") or {}).get("inMemoryInTests")})
    unbuilt = [m["artifactId"] for m in counted if m.get("outcome") in ("FAILURE", "SKIPPED")]
    result_levels = {}
    for lv in buildchecks.LEVELS:
        classes = [{"module": m["artifactId"], **c} for m in counted for c in m.get("classes") or [] if c["level"] == lv]
        names = {c["class"] for c in classes}
        failing = [{"module": m["artifactId"], **f} for m in counted for f in m.get("failing") or []
                   if f.get("class") in names or (f.get("class") or "").split("$", 1)[0] in names]
        tot = buildchecks.totals(classes)
        notes = []
        if tot["failures"] or tot["errors"] or unbuilt:
            status = "fail"
            if unbuilt:
                notes.append("not built: " + ", ".join(unbuilt))
        elif not tot["tests"]:
            status = "none"
            notes.append("no test of this level in the counted modules")
        elif tot["skipped"]:
            status = "warn"
            notes.append(f"{tot['skipped']} skipped test(s) to explain")
        else:
            status = "pass"
        result_levels[lv] = {"status": status, "totals": tot, "failing": failing, "notes": notes,
                             "rule": buildchecks.LEVEL_RULES[lv],
                             "classes": [{k: c.get(k) for k in ("module", "class", "runner", "tests", "failures",
                                                                "errors", "skipped", "seconds", "reason", "db2",
                                                                "db2Evidence", "inMemory", "source", "cases")}
                                         for c in classes],
                             "byModule": [{"artifactId": r["artifactId"], "role": r["role"], **r["byLevel"][lv]}
                                          for r in rows if r["role"] != "other" and r["byLevel"][lv]["classes"]]}
    gate_failed = [r["artifactId"] for r in rows if r["role"] != "other" and r["coverageCheck"] == "not_met"]
    if gate_failed:
        result_levels["L1"]["status"] = "fail"
        result_levels["L1"]["notes"].append("coverage gate not met: " + ", ".join(gate_failed))
    mu_row = next((r for r in rows if r["role"] == "mu"), None)
    ratio = ((mu_row or {}).get("lineCoverage") or {}).get("ratio")
    if ratio is not None and ratio < COVERAGE_TARGET and result_levels["L1"]["status"] == "pass":
        result_levels["L1"]["status"] = "warn"
        result_levels["L1"]["notes"].append(f"line coverage {ratio * 100:.1f}% is below the strategy's "
                                            f"{COVERAGE_TARGET * 100:.0f}%")
    l3 = result_levels["L3"]
    db2 = sorted(c["class"] for c in l3["classes"] if c.get("db2"))
    in_memory_modules = {r["artifactId"] for r in rows if r["role"] != "other" and r.get("inMemoryInTests")}
    in_memory = sorted(c["class"] for c in l3["classes"]
                       if not c.get("db2") and (c.get("inMemory") or c.get("module") in in_memory_modules))
    l3["realDb2"] = bool(db2) and not in_memory          # information, never a status (U-113)
    l3["db2Classes"] = db2
    l3["db2Evidence"] = sorted({c.get("db2Evidence") for c in l3["classes"] if c.get("db2Evidence")})
    l3["inMemory"] = bool(in_memory)
    l3["inMemoryClasses"] = in_memory
    others = [r["artifactId"] for r in rows if r["role"] == "other"]
    return {"available": True, "state": "results", "mode": record.get("mode"), "source": record.get("source"),
            "revision": record.get("revision"), "ranAt": record.get("finishedAt") or record.get("reportsWrittenAt"),
            "seconds": record.get("seconds"), "command": record.get("command"), "build": record.get("build"),
            "exitCode": record.get("exitCode"), "log": record.get("log"), "database": record.get("database"),
            "copiedFrom": record.get("copiedFrom"), "hash": record.get("hash"),
            "note": record.get("note"), "reused": record.get("reused", False), "modules": rows,
            "levels": result_levels, "notCounted": others, "coverageTarget": COVERAGE_TARGET,
            "muModule": (mu_row or {}).get("artifactId"),
            "casesRecorded": all(c.get("cases") is not None for lv in result_levels.values() for c in lv["classes"])}


def input_files(mu: Mu, product: dict | None) -> list[Path]:
    """The files L1 - L3 are read from: the checks record of the current hash, else the last build's reports."""
    record = record_file(mu, product["revision"]) if product else None
    if record is not None and checks_record(mu, product["revision"]):
        return [record]
    if product and product.get("hasPom"):
        return last_build_files(mu.solution)
    return []
