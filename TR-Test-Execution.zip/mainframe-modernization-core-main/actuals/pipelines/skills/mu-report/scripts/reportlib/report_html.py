"""The test results report as ONE self-contained HTML page (no external font, script or image), rendered from the
report document only - the document is embedded in the page (`<script type="application/json" id="test-results">`),
so the page never says more than its data.

Opened, the page shows what matters first - the overall line, the pyramid with one status per level, four figures,
the items that need attention with their owner, and the next move. Every detail is folded (`<details>`): a
section's summary line already states its status and headline numbers.

Status is never colour alone: every status mark carries an icon and a label, every chart a legend with counts. The
palette is the client deck's, light and dark. Printing expands every fold.
"""

from __future__ import annotations

import json
import re
from html import escape

from .buildchecks import LEVEL_RULES
from .levels import worst

ICONS = {"pass": "&#10003;", "warn": "!", "fail": "&#10005;", "none": "&#8211;"}
LABELS = {"pass": "Passed", "warn": "Attention", "fail": "Failed", "none": "Not run"}
OUTCOMES = (("PASSED", "pass", "Passed"), ("FAILED", "fail", "Failed"), ("BLOCKED", "warn", "Blocked"),
            ("NOT_APPLICABLE", "none", "Not applicable"), ("SKIPPED", "none", "Skipped"),
            ("NOT_RUN", "none", "Not run"))
OUTCOME = {k: (s, label) for k, s, label in OUTCOMES}
ROLE_LABELS = {"mu": "this MU", "shared": "shared", "application": "application", "other": "other MU"}
SECTION_OF = {"L0": "sec-l0", "L1": "sec-build", "L2": "sec-build", "L3": "sec-build", "L4": "sec-l4", "LC": "sec-lc",
              "L5": "sec-gaps", "L6": "sec-gaps", "L7": "sec-gaps", "L8": "sec-gaps"}
DECIDED = "&#9670;"                  # the mark of a decided answer

CSS = """
:root {
  --bg: #f3f5f4; --surface: #ffffff; --surface-2: #eaefee; --ink: #13222b; --ink-2: #46555d; --ink-3: #6a787f;
  --rule: #d5dcdb; --rule-strong: #b3c0bf; --accent: #0b6e78; --accent-ink: #0a616a; --accent-soft: #d9eeec;
  --good: #0ca30c; --warn: #fab219; --crit: #d03b3b; --neutral: #c7cfce; --on-neutral: #13222b;
  --tip-bg: #13222b; --tip-ink: #f3f5f4;
  --font: "Segoe UI", Calibri, system-ui, -apple-system, Roboto, Arial, sans-serif;
  --mono: Consolas, "Cascadia Mono", ui-monospace, Menlo, monospace;
  color-scheme: light;
}
@media (prefers-color-scheme: dark) {
  :root:where(:not([data-theme="light"])) {
    --bg: #0e161b; --surface: #142029; --surface-2: #1a2831; --ink: #e3ebee; --ink-2: #a8b7be; --ink-3: #85969e;
    --rule: #26363f; --rule-strong: #3a515c; --accent: #43b6c0; --accent-ink: #72cdd5; --accent-soft: #123338;
    --neutral: #4a5c65; --on-neutral: #e3ebee; --tip-bg: #e3ebee; --tip-ink: #0e161b; color-scheme: dark;
  }
}
:root[data-theme="dark"] {
  --bg: #0e161b; --surface: #142029; --surface-2: #1a2831; --ink: #e3ebee; --ink-2: #a8b7be; --ink-3: #85969e;
  --rule: #26363f; --rule-strong: #3a515c; --accent: #43b6c0; --accent-ink: #72cdd5; --accent-soft: #123338;
  --neutral: #4a5c65; --on-neutral: #e3ebee; --tip-bg: #e3ebee; --tip-ink: #0e161b; color-scheme: dark;
}
* { box-sizing: border-box; }
html, body { margin: 0; }
body { background: var(--bg); color: var(--ink); font-family: var(--font); font-size: 15px; line-height: 1.55; }
a { color: var(--accent-ink); }
:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; border-radius: 3px; }
.page { max-width: 1200px; margin: 0 auto; padding: 0 24px 64px; }
header.top { background: #13222b; color: #e3ebee; }
header.top .page { padding-top: 26px; padding-bottom: 24px; }
.eyebrow { font-size: 12px; letter-spacing: .12em; text-transform: uppercase; color: #8fd3d9; margin: 0 0 6px; }
header.top h1 { font-size: 30px; line-height: 1.2; margin: 0 0 4px; font-weight: 600; }
header.top .desc { color: #b9c7cc; margin: 0 0 12px; font-size: 15px; }
header.top .meta { display: flex; flex-wrap: wrap; gap: 6px 22px; font-size: 13.5px; color: #b9c7cc; }
header.top .meta b { color: #ffffff; font-weight: 600; }
header.top code { font-family: var(--mono); font-size: 12.5px; color: #ffffff; }
.tools { float: right; display: flex; gap: 6px; }
.btn { background: transparent; border: 1px solid #46555d; color: #d5e0e4; border-radius: 6px; font: inherit;
  font-size: 12.5px; padding: 3px 10px; cursor: pointer; }
.btn:hover { border-color: #8fd3d9; color: #ffffff; }
.btn.light { border-color: var(--rule-strong); color: var(--ink-2); background: var(--surface); }
.btn.light:hover { border-color: var(--accent); color: var(--accent-ink); }
.banner { margin: 18px 0 0; border-radius: 8px; padding: 10px 14px; background: var(--surface); border: 1px solid var(--rule);
  border-left: 4px solid var(--warn); font-size: 14px; }
.banner.info { border-left-color: var(--accent); }
.overall { display: flex; gap: 14px; align-items: flex-start; margin: 22px 0 0; padding: 16px 18px; background: var(--surface);
  border: 1px solid var(--rule); border-radius: 10px; }
.overall .chip { font-size: 13.5px; padding: 3px 12px 3px 5px; }
.overall .chip .ic { width: 20px; height: 20px; font-size: 12px; }
.overall p { margin: 0; font-size: 16px; }
h2 { font-size: 20px; margin: 0 0 8px; font-weight: 600; }
h3 { font-size: 15px; margin: 18px 0 8px; font-weight: 600; }
p.lead { margin: 0 0 12px; color: var(--ink-2); max-width: 920px; }
.muted { color: var(--ink-3); }
.card { background: var(--surface); border: 1px solid var(--rule); border-radius: 10px; padding: 16px 18px; }
.glance { display: grid; grid-template-columns: minmax(0, 470px) minmax(0, 1fr); gap: 18px; align-items: start;
  margin-top: 16px; }
@media (max-width: 980px) { .glance { grid-template-columns: minmax(0, 1fr); } }
.tiles { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
.tile { background: var(--surface); border: 1px solid var(--rule); border-radius: 10px; padding: 12px 16px; }
.tile .label { font-size: 13px; color: var(--ink-2); }
.tile .value { font-size: 28px; font-weight: 600; line-height: 1.2; margin: 4px 0 2px; }
.tile .sub { font-size: 12.5px; color: var(--ink-3); }
.attention { margin-top: 16px; }
.attention ol { margin: 0; padding: 0; list-style: none; }
.attention li { display: grid; grid-template-columns: auto minmax(0, 1fr) auto; gap: 10px; align-items: baseline;
  padding: 8px 0; border-bottom: 1px solid var(--rule); }
.attention li:last-child { border-bottom: 0; }
.attention .owner { font-size: 12.5px; color: var(--ink-3); white-space: nowrap; }
.attention .lvl { font-family: var(--mono); font-size: 12px; color: var(--accent-ink); margin-right: 6px; }
nav.toc { display: flex; flex-wrap: wrap; gap: 6px; align-items: center; margin: 26px 0 10px; }
nav.toc a { color: var(--ink-2); text-decoration: none; font-size: 13px; padding: 3px 10px; border-radius: 999px;
  background: var(--surface); border: 1px solid var(--rule); }
nav.toc a:hover { color: var(--accent-ink); border-color: var(--accent); }
nav.toc .spacer { flex: 1; }
details.sec { background: var(--surface); border: 1px solid var(--rule); border-radius: 10px; margin-top: 10px; }
details.sec > summary { display: flex; flex-wrap: wrap; gap: 6px 12px; align-items: center; padding: 13px 18px; cursor: pointer;
  list-style: none; border-radius: 10px; }
details.sec[open] > summary { border-bottom: 1px solid var(--rule); border-radius: 10px 10px 0 0; }
details > summary::-webkit-details-marker { display: none; }
details > summary::before { content: ""; width: 8px; height: 8px; border-right: 2px solid var(--ink-3);
  border-bottom: 2px solid var(--ink-3); transform: rotate(-45deg); margin-right: 4px; flex: none; }
details[open] > summary::before { transform: rotate(45deg); }
details.sec > summary:hover { background: var(--surface-2); }
.lv { font-family: var(--mono); font-size: 13px; color: var(--accent-ink); background: var(--accent-soft); border-radius: 4px;
  padding: 1px 7px; }
.sec-title { font-size: 17px; font-weight: 600; }
.sec-head { color: var(--ink-2); font-size: 14px; flex: 1 1 280px; }
.sec-body { padding: 14px 18px 18px; }
details.sub { border-top: 1px solid var(--rule); }
details.sub:first-of-type { margin-top: 12px; }
details.sub > summary { display: flex; flex-wrap: wrap; gap: 4px 10px; align-items: center; padding: 9px 2px; cursor: pointer;
  list-style: none; }
details.sub > summary:hover .sub-title { color: var(--accent-ink); }
.sub-title { font-weight: 600; font-size: 14.5px; }
.sub-meta { color: var(--ink-3); font-size: 13px; }
.sub-body { padding: 4px 0 14px 18px; }
table { border-collapse: collapse; width: 100%; font-size: 13.5px; }
th { text-align: left; font-weight: 600; color: var(--ink-2); font-size: 12.5px; border-bottom: 1px solid var(--rule-strong);
  padding: 6px 9px; vertical-align: bottom; }
td { border-bottom: 1px solid var(--rule); padding: 6px 9px; vertical-align: top; }
tr:last-child td { border-bottom: 0; }
td.num, th.num { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
td.id { white-space: nowrap; font-family: var(--mono); font-size: 12.5px; }
table.compact { width: auto; min-width: 320px; }
code, .mono { font-family: var(--mono); font-size: 12.5px; }
pre.gherkin { font-family: var(--mono); font-size: 12.5px; background: var(--surface-2); border-radius: 6px; padding: 8px 10px;
  margin: 6px 0; white-space: pre-wrap; }
.chip { display: inline-flex; align-items: center; gap: 5px; border-radius: 999px; padding: 1px 9px 1px 4px;
  font-size: 12.5px; font-weight: 600; white-space: nowrap; background: var(--surface-2); color: var(--ink); }
.chip .ic { display: inline-grid; place-items: center; width: 17px; height: 17px; border-radius: 50%; font-size: 11px;
  font-weight: 700; }
.chip.pass .ic { background: var(--good); color: #ffffff; }
.chip.fail .ic { background: var(--crit); color: #ffffff; }
.chip.warn .ic { background: var(--warn); color: #13222b; }
.chip.none .ic { background: var(--neutral); color: var(--on-neutral); }
.badge { display: inline-block; font-size: 11px; font-weight: 700; letter-spacing: .04em; text-transform: uppercase;
  border-radius: 4px; padding: 1px 6px; background: var(--accent-soft); color: var(--accent-ink); }
.kv { display: grid; grid-template-columns: max-content minmax(0, 1fr); gap: 4px 16px; font-size: 14px; margin: 4px 0 8px; }
.kv dt { color: var(--ink-2); } .kv dd { margin: 0; }
.ba { position: relative; display: inline-block; font-family: var(--mono); font-size: 11.5px; font-weight: 600;
  line-height: 1.5; padding: 0 6px; margin: 1px 3px 1px 0; border-radius: 4px; text-decoration: none; white-space: nowrap;
  border: 1px solid transparent; }
.ba.rule { background: var(--surface); color: var(--ink); border-color: var(--accent); }
.ba:hover { border-color: var(--accent); }
a.ext { font-size: 12px; font-weight: 400; margin-left: 8px; white-space: nowrap; }
a.sref { text-decoration: none; display: inline-block; margin: 1px 6px 1px 0; }
a.sref .chip { font-family: var(--mono); font-weight: 600; font-size: 11.5px; }
a.sref:hover .chip { outline: 1px solid var(--accent); }
details.refs > summary { cursor: pointer; color: var(--accent-ink); font-size: 13px; list-style: none; }
details.refs > summary::before { display: none; }
.ba[data-tip]:hover::after, .ba[data-tip]:focus-visible::after { content: attr(data-tip); position: absolute; left: 0;
  top: calc(100% + 6px); z-index: 30; width: max-content; max-width: 380px; white-space: pre-line; text-align: left;
  background: var(--tip-bg); color: var(--tip-ink); font-family: var(--font); font-size: 12.5px; font-weight: 400;
  line-height: 1.45; padding: 8px 10px; border-radius: 6px; box-shadow: 0 4px 14px rgba(0,0,0,.25); pointer-events: none; }
.nav-current { outline: 2px solid var(--accent); outline-offset: 3px; border-radius: 6px; }
tr.nav-current { outline: none; }
tr.nav-current > td { background: var(--accent-soft); }
tr.nav-current > td:first-child { box-shadow: inset 3px 0 0 var(--accent); }
pre.trace { font-family: var(--mono); font-size: 11.5px; background: var(--surface-2); border-radius: 6px; padding: 6px 8px;
  margin: 4px 0; white-space: pre-wrap; overflow-wrap: anywhere; max-height: 280px; overflow: auto; }
details.trace > summary { cursor: pointer; color: var(--accent-ink); font-size: 12.5px; list-style: none; margin-top: 2px; }
details.trace > summary::before { display: none; }
details.tc > summary .chip { min-width: 74px; }
.bar { display: flex; gap: 2px; height: 14px; width: 100%; min-width: 120px; margin: 4px 0; }
.bar.slim { height: 10px; }
.bar > span { display: block; height: 100%; min-width: 3px; color: #ffffff; font-size: 10.5px; font-weight: 700;
  line-height: 14px; text-align: center; overflow: visible; white-space: nowrap; }
.bar > span:first-child { border-radius: 4px 0 0 4px; }
.bar > span:last-child { border-radius: 0 4px 4px 0; }
.bar > span:only-child { border-radius: 4px; }
.seg-pass { background: var(--good); }
.seg-fail { background: var(--crit); }
.seg-warn { background: var(--warn); color: #13222b !important; }
.seg-none { background: var(--neutral); color: var(--on-neutral) !important; }
.legend { display: flex; flex-wrap: wrap; gap: 4px 16px; font-size: 12.5px; color: var(--ink-2); margin: 2px 0 6px; }
.legend i { display: inline-block; width: 10px; height: 10px; border-radius: 2px; margin-right: 5px; vertical-align: -1px; }
.legend b { color: var(--ink); font-variant-numeric: tabular-nums; }
.cov { position: relative; height: 10px; background: var(--accent-soft); border-radius: 4px; min-width: 110px; }
.cov > span { position: absolute; left: 0; top: 0; bottom: 0; background: var(--accent); border-radius: 4px 0 0 4px; }
.cov > i { position: absolute; top: -3px; bottom: -3px; width: 2px; background: var(--ink); }
.callout { border-left: 4px solid var(--warn); background: var(--surface-2); border-radius: 0 8px 8px 0; padding: 10px 14px;
  margin: 10px 0; font-size: 14px; }
.callout.info { border-left-color: var(--accent); }
.callout.none { border-left-color: var(--neutral); }
.decided { display: inline-block; max-width: 100%; border-left: 3px solid var(--accent); padding-left: 6px; margin: 2px 0; }
td.note { overflow-wrap: anywhere; min-width: 16em; }
td.mono, p, li, dd, code { overflow-wrap: anywhere; }
td .chip { white-space: normal; border-radius: 12px; }
.kv dd { overflow-wrap: anywhere; min-width: 0; }
input.filter { font: inherit; font-size: 13px; padding: 4px 9px; border: 1px solid var(--rule-strong); border-radius: 6px;
  background: var(--surface); color: var(--ink); width: min(360px, 100%); margin: 4px 0 8px; }
.pyramid text { font-family: var(--font); }
.pyramid a { cursor: pointer; }
.pyramid a:hover polygon, .pyramid a:hover rect, .pyramid a:focus polygon { stroke: var(--ink); stroke-width: 2; }
.pyramid .t-name { font-size: 13px; font-weight: 600; }
.pyramid .t-sub { font-size: 11px; }
.pyramid .p-pass { fill: var(--good); } .pyramid .p-fail { fill: var(--crit); }
.pyramid .p-warn { fill: var(--warn); } .pyramid .p-none { fill: var(--neutral); }
.pyramid .x-pass, .pyramid .x-fail { fill: #ffffff; } .pyramid .x-warn { fill: #13222b; }
.pyramid .x-none { fill: var(--on-neutral); }
.pillars { display: flex; gap: 8px; margin-top: 10px; flex-wrap: wrap; font-size: 12.5px; color: var(--ink-2); }
.layers td:first-child a { font-family: var(--mono); text-decoration: none; }
nav.tabs { position: sticky; top: 0; z-index: 20; display: flex; flex-wrap: wrap; gap: 4px; align-items: center;
  margin: 18px 0 6px; padding: 8px 0; background: var(--bg); border-bottom: 1px solid var(--rule); }
nav.tabs a.tab { display: inline-flex; align-items: center; gap: 6px; color: var(--ink-2); text-decoration: none;
  font-size: 14px; font-weight: 600; padding: 5px 14px; border-radius: 8px 8px 0 0; border: 1px solid transparent; }
nav.tabs a.tab:hover { color: var(--accent-ink); }
nav.tabs a.tab[aria-selected="true"] { color: var(--ink); background: var(--surface); border-color: var(--rule);
  border-bottom-color: var(--surface); }
nav.tabs .spacer { flex: 1; }
.tab-ic { display: inline-grid; place-items: center; width: 16px; height: 16px; border-radius: 50%; font-size: 10px;
  font-weight: 700; }
.tab-ic.pass { background: var(--good); color: #fff; } .tab-ic.fail { background: var(--crit); color: #fff; }
.tab-ic.warn { background: var(--warn); color: #13222b; } .tab-ic.none { background: var(--neutral); color: var(--on-neutral); }
.js .panel { display: none; } .js .panel.active { display: block; }
section.sec { background: var(--surface); border: 1px solid var(--rule); border-radius: 10px; margin-top: 12px; }
section.sec > .sec-h { display: flex; flex-wrap: wrap; gap: 6px 12px; align-items: center; padding: 13px 18px;
  border-bottom: 1px solid var(--rule); }
.overall ul.lines { list-style: none; margin: 8px 0 0; padding: 0; font-size: 13.5px; color: var(--ink-2); }
.overall ul.lines li { margin: 3px 0; } .overall ul.lines a { text-decoration: none; margin-right: 4px; }
.ba-r { display: inline-block; font-family: var(--mono); font-size: 11.5px; font-weight: 600; padding: 0 6px;
  margin: 1px 3px 1px 0; border-radius: 4px; border: 1px solid var(--accent); white-space: nowrap; }
.filters { display: flex; flex-wrap: wrap; gap: 8px 16px; align-items: center; margin: 6px 0 10px; font-size: 13px; }
.filters select, .filters input { font: inherit; font-size: 13px; padding: 3px 6px; border: 1px solid var(--rule-strong);
  border-radius: 6px; background: var(--surface); color: var(--ink); max-width: 260px; }
footer { margin-top: 36px; color: var(--ink-3); font-size: 12.5px; border-top: 1px solid var(--rule); padding-top: 14px; }
@media (prefers-reduced-motion: reduce) { * { scroll-behavior: auto !important; } }
@media print {
  :root { --bg: #ffffff; }
  .tools, nav.toc, nav.tabs, input.filter, .filters { display: none; }
  .js .panel { display: block; }
  header.top { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  .tile, table, .callout { break-inside: avoid; }
  details.sec { break-inside: auto; }
  .bar > span, .chip .ic, .cov, .pyramid { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  .seg-fail { background-image: repeating-linear-gradient(45deg, rgba(0,0,0,.35) 0 2px, transparent 2px 6px); }
  .ba[data-tip]::after { display: none; }
}
@media (forced-colors: active) {
  .seg-fail { background-image: repeating-linear-gradient(45deg, CanvasText 0 2px, transparent 2px 6px); }
  .bar > span { border: 1px solid CanvasText; }
}
"""

SCRIPT = """
(function () {
  var doc = document, root = doc.documentElement;
  var theme = doc.getElementById('theme');
  if (theme) theme.addEventListener('click', function () {
    var dark = root.getAttribute('data-theme') === 'dark' ||
      (!root.getAttribute('data-theme') && window.matchMedia('(prefers-color-scheme: dark)').matches);
    root.setAttribute('data-theme', dark ? 'light' : 'dark');
  });
  function all(open) { doc.querySelectorAll('main .panel.active details').forEach(function (d) { d.open = open; }); }
  var ex = doc.getElementById('expand-all'), co = doc.getElementById('collapse-all');
  if (ex) ex.addEventListener('click', function () { all(true); });
  if (co) co.addEventListener('click', function () { all(false); });
  var current = null;
  root.classList.add('js');
  var tabs = doc.querySelectorAll('nav.tabs a.tab');
  function show(panelId) {
    tabs.forEach(function (t) { t.setAttribute('aria-selected', t.getAttribute('data-tab') === panelId ? 'true' : 'false'); });
    doc.querySelectorAll('.panel').forEach(function (p) { p.classList.toggle('active', p.id === panelId); });
  }
  show('tab-overview');
  function reveal(id) {
    var el = doc.getElementById(id);
    if (!el) return false;
    var panel = el.closest ? el.closest('.panel') : null;
    if (panel) show(panel.id);
    if (el.classList.contains('panel')) { window.scrollTo(0, 0); return true; }
    for (var p = el; p; p = p.parentElement) { if (p.tagName === 'DETAILS') p.open = true; }
    el.scrollIntoView({block: 'start'});
    if (current && current !== el) current.classList.remove('nav-current');
    current = el;
    el.classList.add('nav-current');
    return true;
  }
  doc.addEventListener('click', function (e) {
    var a = e.target.closest ? e.target.closest('a[href^="#"]') : null;
    if (!a) return;
    var id = decodeURIComponent(a.getAttribute('href').slice(1));
    if (id && doc.getElementById(id)) { e.preventDefault(); history.replaceState(null, '', '#' + id); reveal(id); }
  });
  if (location.hash) reveal(decodeURIComponent(location.hash.slice(1)));
  var saved = [];
  window.addEventListener('beforeprint', function () {
    saved = [];
    doc.querySelectorAll('details').forEach(function (d) { saved.push([d, d.open]); d.open = true; });
  });
  window.addEventListener('afterprint', function () { saved.forEach(function (s) { s[0].open = s[1]; }); });
  doc.querySelectorAll('input[data-filter-scope]').forEach(function (input) {
    var scope = doc.getElementById(input.getAttribute('data-filter-scope'));
    input.hidden = false;
    input.addEventListener('input', function () {
      var q = input.value.trim().toLowerCase();
      scope.querySelectorAll('details.tc').forEach(function (d) {
        var head = d.querySelector('summary').textContent.toLowerCase().indexOf(q) >= 0, any = false;
        d.querySelectorAll('tbody tr').forEach(function (r) {
          var hit = q === '' || head || r.textContent.toLowerCase().indexOf(q) >= 0;
          r.hidden = !hit; any = any || hit;
        });
        d.hidden = q !== '' && !head && !any;
        d.open = q !== '' && !d.hidden;
      });
    });
  });
  doc.querySelectorAll('input[data-filter]').forEach(function (input) {
    var table = doc.getElementById(input.getAttribute('data-filter'));
    input.hidden = false;
    input.addEventListener('input', function () {
      var q = input.value.trim().toLowerCase();
      table.querySelectorAll('tbody tr').forEach(function (r) {
        r.hidden = q !== '' && r.textContent.toLowerCase().indexOf(q) < 0;
      });
    });
  });
  var data = null;
  try { data = JSON.parse(doc.getElementById('test-results').textContent); } catch (err) { data = null; }
  var tbl = doc.getElementById('l4-table');
  if (data && data.l4 && data.l4.scenarios && tbl) {
    var rows = data.l4.scenarios, body = tbl.querySelector('tbody'), box = doc.getElementById('l4-filters');
    var STATUS = {PASSED: ['pass', 'Passed', '\u2713'], FAILED: ['fail', 'Failed', '\u2715'], BLOCKED: ['warn', 'Blocked', '!'],
      NOT_APPLICABLE: ['none', 'Not applicable', '\u2013'], SKIPPED: ['none', 'Skipped', '\u2013'], NOT_RUN: ['none', 'Not run', '\u2013']};
    function esc(v) { return String(v == null ? '' : v).replace(/[&<>"]/g, function (c) {
      return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]; }); }
    function chipHtml(st) { var s = STATUS[st] || ['none', st, '\u2013'];
      return '<span class="chip ' + s[0] + '"><span class="ic" aria-hidden="true">' + s[2] + '</span>' + esc(s[1]) + '</span>'; }
    function detail(s) {
      var out = [];
      if (s.reason) out.push(esc(s.reason));
      (s.differences || []).forEach(function (f) { out.push('<code>' + esc(f.path) + '</code> <span class="muted">' + esc(f.kind) +
        '</span>: legacy <code>' + esc(f.expected) + '</code> \u2192 Java <code>' + esc(f.actual) + '</code>'); });
      if (s.failure) out.push(chipHtml('FAILED').replace('Failed', esc(s.failure['class'])) + ' confidence ' + esc(s.failure.confidence) +
        ((s.failure.suspects || []).length ? ' \u00b7 suspect rules ' + s.failure.suspects.map(function (r) { return '<b>' + esc(r.id) + '</b>'; }).join(', ') : ''));
      if (s.decided) out.push('<span class="decided"><b>\u25c6 Decided answer:</b> ' + esc(s.decided.status) + ', by ' + esc(s.decided.source) +
        (s.decided.recordedStatus != null ? '. The legacy recording answers ' + esc(s.decided.recordedStatus) + '.' : '.') + '</span>');
      var kinds = Object.keys(s.strictByKind || {});
      if (s.strict === 'DIFF' && s.contract === 'MATCH' && kinds.length) out.push('<span class="muted">Strict only: ' +
        kinds.map(function (k) { return esc(k) + ' ' + s.strictByKind[k]; }).join(', ') + '</span>');
      if ((s.hypotheses || []).length) out.push('<span class="muted">Producer\u2019s hypothesis: ' + esc(s.hypotheses.join('; ')) + '</span>');
      if ((s.notCompared || []).length) out.push('<span class="muted">Not compared: ' + esc(s.notCompared.join('; ')) + '</span>');
      return out.join('<br>');
    }
    var html = rows.map(function (s, i) {
      return '<tr data-i="' + i + '" id="sc-' + esc(s.id) + '"><td>' + chipHtml(s.status) + '</td><td class="id">' + esc(s.id) +
        '</td><td>' + esc(s.title) + '<br><span class="muted">' + esc(s.category || '') + ' \u00b7 ' + esc(s.origin || '') +
        '</span></td><td>' + (s.rules || []).map(function (r) { return '<span class="ba-r">' + esc(r) + '</span>'; }).join('') +
        '</td><td class="mono">' + esc(s.strict || '-') + ' / ' + esc(s.contract || '-') + '</td><td class="note">' + detail(s) + '</td></tr>';
    });
    body.innerHTML = html.join('');
    var trs = body.querySelectorAll('tr'), shown = doc.getElementById('l4-shown');
    function apply() {
      var f = {}; box.querySelectorAll('[data-l4]').forEach(function (x) { f[x.getAttribute('data-l4')] = x.value.trim(); });
      var q = (f.text || '').toLowerCase(), n = 0;
      rows.forEach(function (s, i) {
        var ok = (!f.status || s.status === f.status) && (!f.rule || (s.rules || []).indexOf(f.rule) >= 0) &&
          (!f.paragraph || (s.paragraphs || []).indexOf(f.paragraph) >= 0) &&
          (!q || trs[i].textContent.toLowerCase().indexOf(q) >= 0);
        trs[i].hidden = !ok; if (ok) n++;
      });
      shown.textContent = n + ' of ' + rows.length + ' shown';
    }
    box.hidden = false;
    box.querySelectorAll('[data-l4]').forEach(function (x) { x.addEventListener(x.tagName === 'SELECT' ? 'change' : 'input', apply); });
    apply();
  }
})();
"""


# --------------------------------------------------------------------------- small pieces


def e(value) -> str:
    return escape("" if value is None else str(value))


def md(value) -> str:
    """Text from a phase's Markdown, escaped, with its inline code marks (`x`) shown as code."""
    return re.sub(r"`([^`]+)`", r"<code>\1</code>", e(value))


def num(value) -> str:
    return f"{value:,}" if isinstance(value, int) and not isinstance(value, bool) else e(value)


def chip(status: str, label: str | None = None) -> str:
    status = status if status in ICONS else "none"
    return (f'<span class="chip {status}"><span class="ic" aria-hidden="true">{ICONS[status]}</span>'
            f'{e(label or LABELS[status])}</span>')


def layer_chip(row: dict) -> str:
    """A layer's status - or, when it has nothing to judge, its state (not reached, not run, planned ...)."""
    if row.get("state") and row["state"] != "results":
        return chip("none", row.get("stateLabel"))
    return chip(row["status"])


def sentence(text) -> str:
    text = str(text or "").strip()
    return (text[:1].upper() + text[1:] + ("" if text.endswith((".", "!", "?")) else ".")) if text else ""


def pct(part, whole, digits: int = 1) -> str:
    return f"{100.0 * part / whole:.{digits}f}%" if whole else "-"


def plural(n: int, word: str, many: str | None = None) -> str:
    return f"{n:,} {word if n == 1 else (many or word + 's')}"


def stacked(counts: dict, slim: bool = False, inline_min: float = 0.12, what: str = "scenarios") -> str:
    """A stacked bar of outcome counts in the fixed order, a hover title per segment, inline counts only where they
    fit; the legend (rendered separately) carries every count."""
    total = sum(v for v in counts.values() if isinstance(v, int))
    if not total:
        return '<span class="muted">-</span>'
    parts = []
    for key, status, label in OUTCOMES:
        value = counts.get(key, 0)
        if not value:
            continue
        share = value / total
        text = f"{ICONS[status]} {value:,}" if share >= inline_min and not slim else ""
        title = f"{label}: {value:,} of {total:,} {what} ({pct(value, total)})"
        parts.append(f'<span class="seg-{status}" style="flex:{value} 1 0" title="{e(title)}">{text}</span>')
    return (f'<div class="bar{" slim" if slim else ""}" role="img" aria-label="{e(legend_text(counts))}">'
            + "".join(parts) + "</div>")


def legend(counts: dict) -> str:
    items = [f'<span><i class="seg-{status}"></i>{ICONS[status]} {e(label)} <b>{counts[key]:,}</b></span>'
             for key, status, label in OUTCOMES if counts.get(key)]
    return '<div class="legend">' + "".join(items) + "</div>"


def legend_text(counts: dict) -> str:
    return ", ".join(f"{label} {counts[key]}" for key, _, label in OUTCOMES if counts.get(key))


def counts_text(counts: dict) -> str:
    return ", ".join(f"{counts[k]} {label.lower()}" for k, _, label in OUTCOMES if counts.get(k)) or "-"


def test_counts(t: dict) -> dict:
    return {"PASSED": t.get("passed", 0), "FAILED": t.get("failures", 0) + t.get("errors", 0),
            "SKIPPED": t.get("skipped", 0)}


def coverage_bar(ratio, minimum, target=None) -> str:
    if ratio is None:
        return '<span class="muted">-</span>'
    mark = minimum if minimum is not None else target
    label = "gate" if minimum is not None else "strategy target"
    tick = f'<i style="left:calc({mark * 100:.1f}% - 1px)" title="{label} {mark * 100:.0f}%"></i>' \
        if mark is not None else ""
    return (f'<div class="cov" role="img" aria-label="{ratio * 100:.1f}% covered" title="{ratio * 100:.1f}% covered">'
            f'<span style="width:{ratio * 100:.1f}%"></span>{tick}</div>')


def ratio_text(counter) -> str:
    ratio = (counter or {}).get("ratio")
    return f"{ratio * 100:.1f}%" if ratio is not None else "-"


def table(head: list[str], rows: list[str], table_id: str | None = None, nums: tuple = (), cls: str = "") -> str:
    cols = "".join(f'<th scope="col"{" class=num" if i in nums else ""}>{h}</th>' for i, h in enumerate(head))
    ident = f' id="{e(table_id)}"' if table_id else ""
    klass = f' class="{cls}"' if cls else ""
    return f'<table{ident}{klass}><thead><tr>{cols}</tr></thead><tbody>{"".join(rows)}</tbody></table>'


def section(ident: str, level: str, title: str, status_html: str, headline: str, body: str) -> str:
    level_html = f'<span class="lv">{e(level)}</span>' if level else ""
    return (f'<section class="sec" id="{ident}"><div class="sec-h">{level_html}<span class="sec-title">{e(title)}</span>'
            f'{status_html}<span class="sec-head">{headline}</span></div><div class="sec-body">{body}</div>'
            f'</section>')


def fold(title: str, body: str, meta: str = "", ident: str | None = None) -> str:
    ident_html = f' id="{e(ident)}"' if ident else ""
    meta_html = f'<span class="sub-meta">{meta}</span>' if meta else ""
    return (f'<details class="sub"{ident_html}><summary><span class="sub-title">{e(title)}</span>{meta_html}</summary>'
            f'<div class="sub-body">{body}</div></details>')


def callout(text: str, kind: str = "") -> str:
    return f'<div class="callout {kind}">{text}</div>'


def _trim(text: str, limit: int = 240) -> str:
    text = " ".join(str(text or "").split())
    return text if len(text) <= limit else text[:limit - 1].rstrip() + "…"



# --------------------------------------------------------------------------- the top of the page


def pyramid(layers: list[dict]) -> str:
    """L0 at the base up to L6, LC as the foundation slab; each band its status colour, name and status label; a band
    is a link to its section."""
    by_id = {row["id"]: row for row in layers}
    stack = ["L0", "L1", "L2", "L3", "L4", "L5", "L6"]
    width, band, gap, top = 470, 40, 4, 140
    step = (width - top) / (2 * len(stack))
    height = len(stack) * (band + gap) + 40
    cx = width / 2
    shapes = []
    for i, layer in enumerate(stack):
        row = by_id.get(layer, {"name": layer, "status": "none", "headline": "", "state": "out_of_scope",
                                "stateLabel": "Out of scope"})
        yb = height - 40 - i * (band + gap)
        wb, wt = width - 2 * step * i, width - 2 * step * (i + 1)
        points = (f"{cx - wb / 2:.1f},{yb:.1f} {cx + wb / 2:.1f},{yb:.1f} {cx + wt / 2:.1f},{yb - band:.1f} "
                  f"{cx - wt / 2:.1f},{yb - band:.1f}")
        status = row["status"] if row.get("state") == "results" else "none"
        label = LABELS[status] if row.get("state") == "results" else row.get("stateLabel", "")
        title = f"{layer} {row['name']}: {row['headline']}"
        shapes.append(f'<a href="#{SECTION_OF[layer]}" aria-label="{e(title)}"><title>{e(title)}</title>'
                      f'<polygon class="p-{status}" points="{points}"/>'
                      f'<text class="t-name x-{status}" x="{cx}" y="{yb - band / 2 - 2:.1f}" text-anchor="middle">'
                      f'{e(layer)} &#183; {e(row["name"])}</text>'
                      f'<text class="t-sub x-{status}" x="{cx}" y="{yb - band / 2 + 12:.1f}" text-anchor="middle">'
                      f'{ICONS[status]} {e(label)}</text></a>')
    lc = by_id.get("LC", {"status": "none", "headline": "", "state": "not_reached", "stateLabel": "Not reached"})
    lc_status = lc["status"] if lc.get("state") == "results" else "none"
    lc_label = LABELS[lc_status] if lc.get("state") == "results" else lc.get("stateLabel", "")
    slab_y = height - 34
    shapes.append(f'<a href="#sec-lc" aria-label="{e("LC Legacy characterisation: " + lc["headline"])}">'
                  f'<title>{e("LC Legacy characterisation: " + lc["headline"])}</title>'
                  f'<rect class="p-{lc_status}" x="0" y="{slab_y}" width="{width}" height="28" rx="4"/>'
                  f'<text class="t-name x-{lc_status}" x="{cx}" y="{slab_y + 19}" text-anchor="middle">'
                  f'LC &#183; Legacy characterisation &#8212; {ICONS[lc_status]} {e(lc_label)}</text></a>')
    return (f'<svg class="pyramid" viewBox="0 0 {width} {height}" width="100%" role="img" '
            f'aria-label="The test pyramid with the status of each level">{"".join(shapes)}</svg>')


def header(doc: dict) -> str:
    mu = doc["mu"]
    product = doc.get("product") or {}
    module = doc.get("productModule") or {}
    meta = []
    if product:
        meta.append(f'<span>Product <code>{e(product.get("solution"))}</code> content hash '
                    f'<code title="{e(product.get("hash"))}">{e(product.get("revision"))}</code> '
                    f'({num(product.get("files"))} files)</span>')
    else:
        meta.append('<span>Product: no solution folder</span>')
    if module:
        meta.append(f'<span>Module <code>{e(module.get("artifactId"))}</code></span>')
    meta.append(f'<span>Generated <b>{e(doc.get("generatedAt"))}</b></span>')
    entry = ", ".join(mu.get("entryPoints") or [])
    desc = e(mu.get("description")) + (f' &#183; entry point <code>{e(entry)}</code>' if entry else "")
    return (f'<header class="top"><div class="page"><div class="tools">'
            f'<button class="btn" id="theme" type="button">Light / dark</button></div>'
            f'<p class="eyebrow">Test results report &#183; L0 to L4</p>'
            f'<h1>Migration Unit {e(mu.get("name"))}</h1><p class="desc">{desc}</p>'
            f'<div class="meta">{"".join(meta)}</div></div></header>')


def banners(doc: dict) -> str:
    found = []
    build = doc.get("build") or {}
    if build.get("available") and build.get("source") == "last-build":
        found.append("L1 - L3 show the product's own last build (its reports in <code>solution/</code>), not a run "
                     "on a known content hash.")
    return "".join(f'<div class="banner">{text}</div>' for text in found)


def _tile_absent(level: dict) -> str:
    return e(level.get("short") or _trim(level.get("reason"), 90))


def tiles(doc: dict) -> str:
    l4, build, lc, q = doc["l4"], doc["build"], doc["lc"], doc.get("questions") or {}
    items = []
    if l4.get("state") == "results":
        c = l4["counts"]
        rest = ", ".join(f"{c[k]:,} {k.lower().replace('_', ' ')}" for k in ("FAILED", "BLOCKED", "NOT_APPLICABLE")
                         if c.get(k))
        items.append(("Parity with the legacy (L4)", f'{c["PASSED"]:,} / {l4["runnable"]:,}',
                      f'passed of the runnable &#183; {e(rest)} &#183; '
                      + ("runs identical" if l4.get("identical") else "runs differ")))
    else:
        items.append(("Parity with the legacy (L4)", e(STATE_TEXT.get(l4.get("state"), "")), _tile_absent(l4)))
    if build.get("available"):
        tests = sum(build["levels"][lv]["totals"]["tests"] for lv in ("L1", "L2", "L3"))
        passed = sum(build["levels"][lv]["totals"]["passed"] for lv in ("L1", "L2", "L3"))
        source = "the --confirm run of this content hash" if build.get("source") == "checks" else "the product's last build"
        items.append(("Product tests passed (L1 - L3)", f"{passed:,} / {tests:,}", source))
    else:
        items.append(("Product tests (L1 - L3)", e(STATE_TEXT.get(build.get("state"), "Not run")), _tile_absent(build)))
    if lc.get("state") == "results":
        cov = lc["coverage"]
        items.append(("Legacy characterisation (LC)", f'{num(lc["counts"].get("cases"))} cases',
                      f'{num(cov["paragraphs"].get("covered"))} / {num(cov["paragraphs"].get("total"))} paragraphs '
                      f'&#183; {num(cov["lines"].get("covered"))} / {num(cov["lines"].get("code"))} lines'))
    else:
        items.append(("Legacy characterisation (LC)", e(STATE_TEXT.get(lc.get("state"), "")), _tile_absent(lc)))
    by = " &#183; ".join(f'{p} {v["open"]}' for p, v in (q.get("byPrefix") or {}).items())
    items.append(("Open questions", f'{q.get("openCount", 0):,}',
                  (by + f' &#183; blocking {q.get("blockingOpen", 0)}') if by else "none asked"))
    return '<div class="tiles">' + "".join(
        f'<div class="tile"><div class="label">{e(t[0])}</div><div class="value">{t[1]}</div>'
        f'<div class="sub">{t[2]}</div></div>' for t in items) + "</div>"


STATE_TEXT = {"results": "Results", "not_reached": "Not reached", "not_produced": "Not produced",
              "not_run": "Not run", "not_implemented": "Not read yet", "planned": "Planned",
              "out_of_scope": "Out of scope"}


def next_html(doc: dict) -> str:
    move = doc.get("next")
    if not move:
        return ('<div class="card next"><h2>Next move</h2><p class="muted">No command waits: every level that can be '
                'read has its results.</p></div>')
    return (f'<div class="card next" id="sec-next"><h2>Next move</h2><p><code>{e(move["command"])}</code> '
            f'<span class="muted">({e(move["level"])}, {e(move.get("owner"))})</span></p>'
            f'<p class="muted">{md(sentence(move.get("why")))}</p></div>')


def glance(doc: dict) -> str:
    layers = doc["layers"]
    rows = "".join(f'<tr><td><a href="#{SECTION_OF[r["id"]]}">{e(r["id"])}</a></td><td>{e(r["name"])}</td>'
                   f'<td>{layer_chip(r)}</td><td>{e(r["headline"])}'
                   + (f' <span class="muted">&#8594; <code>{e(r["next"])}</code></span>' if r.get("next") else "")
                   + '</td></tr>' for r in layers if r["band"] != "pillar")
    pillars = "".join(f'<span>{chip("none", r["id"] + " " + r["name"])} {e(r["headline"])}</span>'
                      for r in layers if r["band"] == "pillar")
    ov = doc["overall"]
    lines = "".join(f'<li><a href="#{SECTION_OF[x["level"]]}" class="mono">{e(x["level"])}</a> '
                    f'{chip(x["status"]) if x["state"] == "results" else chip("none", STATE_TEXT.get(x["state"]))} '
                    f'{e(x["text"])}</li>' for x in ov.get("lines") or [])
    overall_html = (f'<div class="overall">{chip(ov["status"], ov.get("label"))}<div><p>{e(sentence(ov["sentence"]))}'
                    f'</p><ul class="lines">{lines}</ul></div></div>')
    attention_items = doc.get("attention") or []
    if attention_items:
        items = "".join(f'<li>{chip(a["status"])}<span><span class="lvl">{e(a["layer"])}</span>{e(sentence(a["item"]))}'
                        f'</span><span class="owner">{e(a["owner"])}</span></li>' for a in attention_items)
        more = len([g for g in doc["gaps"] if g["status"] in ("fail", "warn")]) - len(attention_items)
        more_html = (f'<p class="muted" style="margin:8px 0 0">{more} more in '
                     f'<a href="#sec-gaps">Open items and owners</a>.</p>' if more > 0 else "")
        attention_html = f'<div class="card attention"><h2>Needs attention</h2><ol>{items}</ol>{more_html}</div>'
    else:
        attention_html = '<div class="card attention"><h2>Needs attention</h2><p class="muted">Nothing.</p></div>'
    return (f'{banners(doc)}{overall_html}<div class="glance"><div class="card">{pyramid(layers)}'
            f'<div class="pillars">{pillars}</div></div><div>{tiles(doc)}<div class="card layers" '
            f'style="margin-top:12px;padding:6px 8px">'
            f'{table(["Level", "Name", "Status", "Result"], [rows])}</div></div></div>{attention_html}{next_html(doc)}')


# --------------------------------------------------------------------------- L0


def _steps_table(steps: list[dict]) -> str:
    rows = [f'<tr><td style="white-space:nowrap">{e(s["step"])}</td>'
            f'<td>{chip("pass", s["status"]) if s["status"].lower() == "done" else chip("warn", s["status"])}'
            f'</td><td>{md(s.get("note") or "")}</td></tr>' for s in steps]
    return table(["Step", "Status", "Note"], rows)


def _counts_html(counts: list[dict]) -> str:
    if not counts:
        return ""
    items = "".join(f'<dt>{e(c["label"][:1].upper() + c["label"][1:])}</dt><dd><b>{e(c["value"])}</b>'
                    + (f' <span class="muted">({md(c["note"])})</span>' if c.get("note") else "") + "</dd>"
                    for c in counts)
    return f'<dl class="kv">{items}</dl>'


def _review_html(review: dict) -> str:
    if not review["total"]:
        return '<p class="muted">No review findings recorded.</p>'
    rows = [f'<tr><td>{e(s)}</td><td class="num">{review["bySeverity"][s]}</td>'
            f'<td class="num">{review["openBySeverity"][s]}</td></tr>'
            for s in ("High", "Medium", "Low", "Unrated") if review["bySeverity"][s]]
    summary = table(["Severity", "Findings", "Still open"], rows, nums=(1, 2), cls="compact")
    outcome = review["byOutcome"]
    line = (f'<p class="muted">{review["total"]} findings: {outcome["applied"]} applied, {outcome["rejected"]} '
            f'rejected, {outcome["open"]} open' + (f', {outcome["other"]} other' if outcome["other"] else "") + ".</p>")
    not_applied = [r for r in review["rows"] if r["outcome"] != "applied"]
    detail = ""
    if not_applied:
        detail_rows = [f'<tr><td class="num">{e(r["number"])}</td><td>{e(r["severityText"])}</td><td>{md(r["finding"])}</td>'
                       f'<td>{md(r["outcomeText"])}</td><td class="muted">{md(r.get("where"))}</td></tr>'
                       for r in not_applied]
        detail = fold("Findings not applied", table(["#", "Severity", "Finding", "Outcome", "Where / why"], detail_rows),
                      plural(len(not_applied), "finding"))
    return summary + line + detail


def _questions_html(q: dict, title: str) -> str:
    if not q["present"]:
        return ""
    if not q["items"]:
        settled = f', {q["settled"]} settled' if q["settled"] else ""
        return f'<p class="muted">{title}: none{settled}.</p>'
    rows = [f'<tr><td class="id">{e(i["id"])}</td><td>{md(i["title"])}</td><td>{e(i.get("step"))}</td>'
            f'<td>{chip("pass", "answered") if i["answered"] else chip("warn", "open")}</td>'
            f'<td>{md(i.get("decision") or i.get("question") or "")}</td></tr>' for i in q["items"]]
    meta = f'{q["open"]} open, {q["answered"]} answered' + (f', {q["settled"]} settled' if q["settled"] else "")
    return fold(title, table(["Id", "Title", "Step", "Status", "Decision taken (until answered)"], rows), meta)


def _gate_html(gate: dict, name: str) -> str:
    if not gate.get("ran"):
        return f'<dt>{e(name)}</dt><dd>{chip("none", "not re-run")} <span class="muted">{e(gate.get("reason"))}</span></dd>'
    text = (f'{gate.get("covered")} of {gate.get("business")} business paragraphs '
            + ("cited in the code or exempt" if name.startswith("Trace") else "with a rule or a reason"))
    findings = gate.get("findings") or []
    return (f'<dt>{e(name)}</dt><dd>{chip(gate["status"])} {e(text)}'
            + (f' &#183; {len(findings)} finding(s)' if findings else "") + "</dd>")


def _row(layers: list[dict], layer: str) -> dict:
    return next(r for r in layers if r["id"] == layer)


def _absent_callout(level: dict, label: str) -> str:
    owner = f' <span class="muted">Owner: {e(level.get("owner"))}.</span>' if level.get("owner") else ""
    command = f' Next: <code>{e(level["next"])}</code>.' if level.get("next") else ""
    return callout(f'{chip("none", label)} {e(sentence(level.get("reason")))}{command}{owner}', "none")


def l0_section(l0: dict, layers: list[dict]) -> str:
    row = _row(layers, "L0")
    phases = l0["phases"]
    d, i = phases["design"], phases["implementation"]
    rows = []
    for title, phase, owner in (("Design", d, "mu-design"), ("Implementation", i, "mu-implement")):
        if not phase["present"]:
            rows.append(f'<tr><td>{e(title)}</td><td>{chip("none", STATE_TEXT[phase["state"]])}</td>'
                        f'<td colspan="2" class="muted">{e(sentence(phase.get("reason")))}'
                        + (f' Next: <code>{e(phase["next"])}</code>' if phase.get("next") else "") + '</td></tr>')
            continue
        result = (f'{phase["stepsDone"]} of {len(phase["steps"])} steps done; '
                  f'{plural(phase["review"]["total"], "review finding")} ({phase["review"]["byOutcome"]["open"]} open)')
        questions = f'{phase["questions"]["open"]} open of {phase["questions"]["total"]}'
        rows.append(f'<tr><td>{e(title)} <span class="muted">({e(owner)})</span></td><td>{chip(phase["status"])}</td>'
                    f'<td>{e(result)}</td><td>{e(questions)}</td></tr>')
    overview = table(["Phase", "Status", "Result", "Open questions"], rows)
    parts = [f'<p class="lead">Each phase before the test line checks its own output. These are the results it '
             f'recorded, re-checked by the pipeline\'s own scripts where they are present.</p>{overview}']
    if d["present"]:
        ch = d["characterisation"]
        char = (f'{ch["recorded"]} of {plural(ch["cases"], "case")} recorded on the real COBOL '
                f'<span class="muted">(the design\'s basic set - the oracle of L4 is the test package, LC)</span>'
                if ch["units"] else '<span class="muted">none</span>')
        gate_dl = (f'<dl class="kv">{_gate_html(d["ruleCoverage"], "Rule-coverage gate")}'
                   + (f'<dt>As the design recorded it</dt><dd>{md(d.get("ruleCoverageRecorded"))}</dd>'
                      if d.get("ruleCoverageRecorded") else "")
                   + f'<dt>Recordings of the design</dt><dd>{char}</dd></dl>')
        gaps_html = ("<h3>Tool gaps</h3><ul>" + "".join(f"<li>{md(t)}</li>" for t in d["toolGaps"]) + "</ul>") \
            if d.get("toolGaps") else ""
        body = (_counts_html(d["counts"]) + gate_dl + fold("Steps", _steps_table(d["steps"]),
                f'{d["stepsDone"]} of {len(d["steps"])} done') + fold("Review findings", _review_html(d["review"]),
                f'{d["review"]["total"]} findings, {d["review"]["byOutcome"]["open"]} open')
                + _questions_html(d["questions"], "Design open questions") + gaps_html
                + (f'<h3>Waiting for the user</h3><p>{md(d["waitingForTheUser"])}</p>' if d.get("waitingForTheUser") else "")
                + f'<p class="muted">Source: <code>{e(d["file"])}</code></p>')
        parts.append(fold("Design (mu-design)", body, f'{chip(d["status"])} {e(d.get("note"))}'))
    if i["present"]:
        build_rows = [f'<tr><td class="id">{md(r["module"])}</td><td>{md(r["build"])}</td><td>{e(r["unit"])}</td>'
                      f'<td>{e(r["integration"])}</td></tr>' for r in i["buildAndTests"]]
        recorded = table(["Module", "Build", "Unit run / failed / skipped", "Integration run / failed / skipped"],
                         build_rows) if build_rows else '<p class="muted">No Module table in the report.</p>'
        cov = i.get("coverage") or {}
        tr = i.get("traceabilityRecorded") or {}
        module = i.get("productModule") or {}
        dl = (f'<dl class="kv">{_gate_html(i["traceability"], "Traceability gate")}'
              + (f'<dt>Traceability, as recorded</dt><dd>{md(tr.get("text"))}</dd>' if tr else "")
              + (f'<dt>Traceability report</dt><dd><code>{e(i["traceabilityFile"])}</code></dd>'
                 if i.get("traceabilityFile") else "")
              + (f'<dt>Product module</dt><dd><code>{e(module.get("artifactId"))}</code> '
                 f'<span class="muted">({e(module.get("source"))})</span></dd>' if module else "")
              + (f'<dt>Coverage, as recorded</dt><dd>{md(cov.get("text"))}</dd>' if cov else "")
              + (f'<dt>Test database</dt><dd>{md(i.get("testDatabase"))}</dd>' if i.get("testDatabase") else "")
              + "</dl>")
        body = (_counts_html(i["counts"]) + dl + fold("Build and tests as the phase recorded them", recorded)
                + fold("Steps", _steps_table(i["steps"]), f'{i["stepsDone"]} of {len(i["steps"])} done')
                + fold("Review findings", _review_html(i["review"]),
                       f'{i["review"]["total"]} findings, {i["review"]["byOutcome"]["open"]} open')
                + _questions_html(i["questions"], "Implementation open questions")
                + (f'<h3>Waiting for the user</h3><p>{md(i["waitingForTheUser"])}</p>' if i.get("waitingForTheUser") else "")
                + f'<p class="muted">Source: <code>{e(i["file"])}</code></p>')
        parts.append(fold("Implementation (mu-implement)", body, f'{chip(i["status"])} {e(i.get("note"))}'))
    if l0.get("state") != "results":
        parts.insert(0, _absent_callout(l0, row["stateLabel"]))
    return section("sec-l0", "L0", "Design and implementation", layer_chip(row), e(row["headline"]), "".join(parts))


# --------------------------------------------------------------------------- L1 - L3


def build_section(build: dict, layers: list[dict]) -> str:
    status = [_row(layers, lv) for lv in ("L1", "L2", "L3")]
    if not build.get("available"):
        label = STATE_TEXT.get(build.get("state"), "Not run")
        body = (_absent_callout(build, label)
                + '<p class="muted">With <code>--confirm</code> the report copies the product by content hash to '
                  '<code>validation/target/checks/</code>, builds and tests it there against the MU\'s test database '
                  '(tools.yaml <code>test-db2</code>) and reads the reports. The product itself is never written.</p>'
                + _level_rule_fold(build))
        return section("sec-build", "L1-L3", "Unit, contract and integration", chip("none", label),
                       e(build.get("short") or "the product's suites have not been run here"), body)
    levels = build["levels"]
    level_rows = []
    for lv, name in (("L1", "Unit"), ("L2", "Contract"), ("L3", "Integration")):
        info = levels[lv]
        t = info["totals"]
        level_rows.append(
            f'<tr><td class="mono">{lv}</td><td>{name}</td><td class="num">{t["classes"]:,}</td>'
            f'<td class="num">{t["tests"]:,}</td><td class="num">{t["passed"]:,}</td>'
            f'<td class="num">{t["failures"] + t["errors"]:,}</td><td class="num">{t["skipped"]:,}</td>'
            f'<td style="min-width:170px">{stacked(test_counts(t), what="tests")}</td>'
            f'<td>{chip(info["status"], "; ".join(info.get("notes") or []) or None)}</td></tr>')
    lead = ("The product's own test suites, " + ("built and tested on a copy of content hash "
            f'<code>{e(build.get("revision"))}</code>' if build.get("mode") == "confirm" else
            "as the product's last build left their reports in <code>solution/</code>") + ".")
    ran = []
    if build.get("ranAt"):
        ran.append(f'ran {e(build["ranAt"])}')
    if build.get("seconds"):
        ran.append(f'{e(build["seconds"])} s')
    if build.get("build"):
        ran.append(f'build {e(build["build"])}')
    if build.get("reused"):
        ran.append("reused: this content hash was checked before")
    db = build.get("database") or {}
    if db:
        ran.append(f'database {e(db.get("source"))} {e(db.get("host"))}:{e(db.get("port"))}/{e(db.get("database"))}'
                   + (f' schema <code>{e(db.get("schema"))}</code>' if db.get("schema") else ""))
    if (build.get("copiedFrom") or {}).get("source"):
        ran.append(f'copied from the {e(build["copiedFrom"]["source"])} <code>{e(build["copiedFrom"].get("dir"))}</code>')
    l3 = levels["L3"]
    db2_html = (callout(f'<b>L3 on a real Db2:</b> {len(l3["db2Classes"])} integration test class(es) - '
                        + e("; ".join(l3.get("db2Evidence") or [])) + ".", "info") if l3.get("realDb2") else
                callout(f'<b>L3 on an in-memory database:</b> {e(", ".join(l3.get("inMemoryClasses") or []))}.', "info")
                if l3.get("inMemory") else
                callout("<b>Database of L3 not shown.</b> No counted integration test names a Db2 or an in-memory "
                        "database, and the build did not run with a Db2 connection the product's datasource reads.",
                        "info") if l3["totals"]["tests"] else "")
    module_rows = []
    others = []
    for m in build["modules"]:
        if m["role"] == "other":
            others.append(m["artifactId"])
            continue
        line = (m.get("lineCoverage") or {}).get("ratio")
        check = m.get("coverageCheck")
        gate = (chip("pass", "met") if check == "met" else chip("fail", "not met") if check == "not_met" else
                chip("none", "no gate") if check == "not_evaluated" or not m.get("hasGate") else
                chip("none", "not known"))
        cells = "".join(f'<td class="num">{m["byLevel"][lv]["tests"]:,}</td>' for lv in ("L1", "L2", "L3"))
        module_rows.append(
            f'<tr><td class="mono">{e(m["artifactId"])}</td><td>{e(ROLE_LABELS.get(m["role"], m["role"]))}</td>'
            f'<td>{e(m.get("outcome") or "-")}</td>{cells}<td class="num">{ratio_text(m.get("lineCoverage"))}</td>'
            f'<td class="num">{ratio_text(m.get("instructionCoverage"))}</td>'
            f'<td class="num">{ratio_text(m.get("branchCoverage"))}</td>'
            f'<td style="min-width:120px">{coverage_bar(line, m.get("lineMinimum"), build.get("coverageTarget"))}</td>'
            f'<td>{gate}</td></tr>')
    modules = table(["Module", "Role", "Build", "L1", "L2", "L3", "Lines", "Instructions", "Branches",
                     "Lines vs target", "Coverage gate"], module_rows, nums=(3, 4, 5, 6, 7, 8))
    modules += (f'<p class="muted">Not counted (other Migration Units\' modules): {e(", ".join(others))}</p>'
                if others else "")
    modules += (f'<p class="muted">The strategy\'s target is {build.get("coverageTarget", 0.8) * 100:.0f}% line '
                f'coverage (the tick); "no gate" = the build declares no JaCoCo check.</p>')
    failing = [(lv, f) for lv in ("L1", "L2", "L3") for f in levels[lv]["failing"]]
    failing_html = ""
    if failing:
        items = [f'<tr><td class="id">{lv}</td><td class="id"><a href="#{test_class_key(f["class"])}">'
                 f'{e(_simple(f["class"]))}</a></td><td class="mono">{e(f["test"])}</td>'
                 f'<td>{chip("fail", "error" if f["kind"] == "error" else "failed")}</td>'
                 f'<td>{_problem_html(f)}</td></tr>' for lv, f in failing[:300]]
        more = (f'<p class="muted">… and {len(failing) - 300} more - every one is in its class below.</p>'
                if len(failing) > 300 else "")
        failing_html = fold("Failing tests", table(["Level", "Class", "Test", "Result", "Message"], items) + more,
                            f'{plural(len(failing), "test")} in {plural(len({f["class"] for _, f in failing}), "class", "classes")}',
                            ident="build-failing")
    per_level = "".join(_level_tests_fold(lv, name, levels[lv]) for lv, name in
                        (("L1", "Unit"), ("L2", "Contract"), ("L3", "Integration")) if levels[lv]["classes"])
    body = (f'<p class="lead">{lead}</p><p class="muted" style="margin-top:-6px">{" &#183; ".join(ran)}</p>'
            f'{table(["Level", "Name", "Classes", "Tests", "Passed", "Failed", "Skipped", "Distribution", "Status"], level_rows, nums=(2, 3, 4, 5, 6))}'
            f'{legend({"PASSED": 1, "FAILED": 1, "SKIPPED": 1}).replace("<b>1</b>", "")}{db2_html}'
            + failing_html + per_level + fold("By module - build and coverage", modules) + _level_rule_fold(build))
    tests = sum(levels[lv]["totals"]["tests"] for lv in ("L1", "L2", "L3"))
    passed = sum(levels[lv]["totals"]["passed"] for lv in ("L1", "L2", "L3"))
    overall = worst(r["status"] for r in status)
    return section("sec-build", "L1-L3", "Unit, contract and integration", chip(overall),
                   e(f"{passed:,} of {plural(tests, 'test')} passed - " + " · ".join(
                       f"{r['id']} {r['headline']}" for r in status)), body)


CASE_RESULTS = {"passed": ("pass", "passed"), "failed": ("fail", "failed"), "error": ("fail", "error"),
                "skipped": ("warn", "skipped")}


def _simple(name: str) -> str:
    return name.rsplit(".", 1)[-1]


def test_class_key(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.:-]", "-", f"tc-{name.split('$', 1)[0]}")


def _problem_html(entry: dict) -> str:
    """A failing test's message, exception type and the head of its stack trace (folded)."""
    html = md(entry.get("message") or "")
    if entry.get("type"):
        html += f' <span class="muted">({e(_simple(entry["type"]))})</span>'
    trace = entry.get("trace") or []
    if trace:
        html += (f'<details class="trace"><summary>Stack trace ({len(trace)} lines)</summary>'
                 f'<pre class="trace">{e(chr(10).join(trace))}</pre></details>')
    return html


def _class_status(c: dict) -> str:
    if c.get("failures") or c.get("errors"):
        return "fail"
    if c.get("skipped"):
        return "warn"
    return "pass" if c.get("tests") else "none"


def _class_fold(c: dict) -> str:
    """One test class: its summary line says it all (result, tests, time, why this level); unfolded, its test cases."""
    status = _class_status(c)
    bad = (c.get("failures") or 0) + (c.get("errors") or 0)
    label = (f"{bad} failed" if bad else f"{c.get('skipped')} skipped" if c.get("skipped") else
             "passed" if c.get("tests") else "no tests")
    meta = (f'{plural(c.get("tests") or 0, "test")} &#183; {c.get("seconds") or 0:.2f} s &#183; {e(c.get("reason"))}'
            + (" &#183; real Db2" if c.get("db2") else "") + (f' &#183; {e(c.get("module"))}' if c.get("module") else ""))
    cases = c.get("cases")
    if cases is None:
        inner = '<p class="muted">The test cases were not recorded by this build - re-run with --confirm --rebuild.</p>'
    else:
        rows = []
        for t in cases:
            kind, text = CASE_RESULTS.get(t.get("result"), ("none", t.get("result")))
            rows.append(f'<tr><td class="mono">{e(t.get("name"))}</td><td>{chip(kind, text)}</td>'
                        f'<td class="num">{t.get("seconds") or 0:.3f} s</td>'
                        f'<td>{_problem_html(t) if t.get("result") != "passed" else ""}</td></tr>')
        inner = table(["Test", "Result", "Time", "Message"], rows, nums=(2,))
    source = f'<p class="muted"><code>{e(c.get("source"))}</code> &#183; runner {e(c.get("runner"))}</p>' \
        if c.get("source") else f'<p class="muted">runner {e(c.get("runner"))}</p>'
    return (f'<details class="sub tc" id="{test_class_key(c["class"])}"><summary>{chip(status, label)}'
            f'<span class="sub-title mono">{e(_simple(c["class"]))}</span><span class="sub-meta">{meta}</span>'
            f'</summary><div class="sub-body">{source}{inner}</div></details>')


def _level_tests_fold(lv: str, name: str, info: dict) -> str:
    t = info["totals"]
    bad = t["failures"] + t["errors"]
    ordered = sorted(info["classes"], key=lambda c: (-((c.get("failures") or 0) + (c.get("errors") or 0)),
                                                      -(c.get("skipped") or 0), c["class"]))
    scope = f"tests-{lv}"
    body = (f'<input class="filter" type="search" data-filter-scope="{scope}" hidden placeholder="Filter by class or '
            f'test name" aria-label="Filter the {lv} tests"><div id="{scope}">'
            + "".join(_class_fold(c) for c in ordered) + "</div>")
    meta = (f'{chip(info["status"])} {plural(t["tests"], "test")} in {plural(t["classes"], "class", "classes")}'
            + (f' &#183; {bad} failed' if bad else "") + (f' &#183; {t["skipped"]} skipped' if t["skipped"] else ""))
    return fold(f"{lv} {name} tests", body, meta, ident=f"build-{lv}")


def _level_rule_fold(build: dict) -> str:
    rules ="".join(f"<li><b>{lv}</b> {e(LEVEL_RULES[lv])}</li>" for lv in ("L2", "L3", "L1"))
    return fold("How a test class gets its level", f"<p>One level per class, first match wins:</p><ul>{rules}</ul>")


def _kv(pairs) -> str:
    return '<dl class="kv">' + "".join(f"<dt>{e(k)}</dt><dd>{v}</dd>" for k, v in pairs if v is not None) + "</dl>"


def _short_hash(value, n: int = 12) -> str:
    return f'<code title="{e(value)}">{e(str(value)[:n])}</code>' if value else '<span class="muted">-</span>'


def _match_chip(flag, yes: str, no: str) -> str:
    if flag is None:
        return ""
    return " " + (chip("pass", yes) if flag else chip("warn", no))


def _open_questions_table(items: list[dict], with_file: bool = False) -> str:
    rows = []
    for i in items:
        state = chip("pass", i.get("status") or "answered") if i["answered"] else chip("warn", i.get("status") or "open")
        block = chip("fail", "blocking") if i.get("blocking") and not i["answered"] else \
            ('<span class="muted">yes</span>' if i.get("blocking") else '<span class="muted">no</span>')
        rows.append(f'<tr><td class="id">{e(i["id"])}</td><td>{md(i["title"])}</td>'
                    + (f'<td title="{e(i.get("file"))}">{e(i.get("owner"))}</td>' if with_file else "")
                    + f'<td>{state}</td><td>{block}</td><td>{md(i.get("decision") or i.get("question") or "")}'
                    + (f'<br><span class="muted">Affects: {md(i["affects"])}</span>' if i.get("affects") else "")
                    + "</td></tr>")
    head = ["Id", "Title"] + (["Command"] if with_file else []) + ["Status", "Blocking",
                                                                           "Decision taken (until answered)"]
    return table(head, rows)


def lc_section(lc: dict, layers: list[dict]) -> str:
    row = _row(layers, "LC")
    title = "Legacy characterisation and the record gate"
    if lc.get("state") != "results":
        extra = ""
        if lc.get("packages"):
            extra = ('<p class="muted">Package: ' + ", ".join(f"<code>{e(p)}</code>" for p in lc["packages"])
                     + (f' &#183; state <b>{e(lc.get("packageState"))}</b>' if lc.get("packageState") else "") + "</p>")
        body = (_absent_callout(lc, row["stateLabel"]) + extra
                + '<p class="muted">The oracle of L4: the legacy\'s recorded answers in the test package of '
                  'mu-build-tests, accepted at the record gate of mu-validate.</p>')
        return section("sec-lc", "LC", title, layer_chip(row), e(row["headline"]), body)
    c, k = lc["counts"], lc["countedInPackage"]
    pkg = lc["package"]
    gen = pkg.get("generator") or {}
    reasons = lc.get("reasons") or {}
    facts = _kv([
        ("Package state", f'{chip("pass" if lc["packageState"] == "ready" else "warn", lc["packageState"])} '
                          f'scope <b>{e(lc.get("scope"))}</b>'
                          + (" &#183; reasons: " + e("; ".join(f"{a}: {b}" for a, b in reasons.items()))
                             if reasons else ' <span class="muted">no open reason</span>')),
        ("Package", f'<code>{e(lc["packageFile"])}</code> &#183; version <b>{e(pkg.get("version"))}</b> &#183; '
                    f'format {e(pkg.get("format"))} &#183; content hash {_short_hash(pkg.get("contentHash"))}'),
        ("Recorded by", e(f'{gen.get("name") or "-"} (scripts {gen.get("scriptsHash") or "-"}) on '
                          f'{pkg.get("goldenMaster") or "-"}')),
        ("Comparison rules", e(", ".join(pkg.get("comparisonRules") or []) or "-")),
        ("Traceability", f'<code>{e(lc["traceability"]["file"])}</code>' if lc["traceability"]["present"]
         else chip("warn", "not there")),
        ("Stale inputs", e(", ".join(map(str, lc["stale"]))) if lc.get("stale") else None),
    ])
    rows = []
    for key, label in (("cases", "Cases"), ("basic", "basic (the design's set)"), ("advanced", "advanced"),
                       ("golden", "golden (recorded, the oracle)"), ("notRepresentable", "not representable"),
                       ("notRecorded", "not recorded"), ("clockSensitive", "clock-sensitive"),
                       ("decided", "with a decided answer")):
        agree = "" if c.get(key) == k.get(key) else f' {chip("warn", "package: " + str(k.get(key)))}'
        rows.append(f'<tr><td>{e(label)}</td><td class="num">{num(c.get(key))}</td><td>{agree}</td></tr>')
    cases = table(["Cases", "tests-state.json", ""], rows, nums=(1,), cls="compact")
    cats = ", ".join(f"{e(a)} {b}" for a, b in (lc.get("byCategory") or {}).items())
    cases += f'<p class="muted">By category: {cats or "-"}.</p>' if cats else ""
    cov = lc["coverage"]
    para, lines = cov["paragraphs"], cov["lines"]
    cov_rows = [f'<tr><td>Business paragraphs</td><td class="num">{num(para.get("covered"))}</td>'
                f'<td class="num">{num(para.get("uncovered"))}</td><td class="num">{num(para.get("total"))}</td>'
                f'<td class="num">{e(cov.get("paragraphsPercent"))}%</td><td>{coverage_bar((cov.get("paragraphsPercent") or 0) / 100, None, 0.9)}</td></tr>',
                f'<tr><td>Code lines of those paragraphs</td><td class="num">{num(lines.get("covered"))}</td>'
                f'<td class="num">{num(lines.get("uncovered"))}</td><td class="num">{num(lines.get("code"))}</td>'
                f'<td class="num">{e(cov.get("linesPercent"))}%</td><td>{coverage_bar((cov.get("linesPercent") or 0) / 100, None, 0.9)}</td></tr>']
    coverage = (table(["Coverage", "covered", "uncovered", "total", "share", ""], cov_rows, nums=(1, 2, 3, 4))
                + f'<p class="muted">{num(cov.get("outsideLines"))} executed lines lie outside every indexed paragraph '
                  f'(generated code); {num(cov.get("mechanismUncovered"))} mechanism paragraph(s) not reached. '
                  'Package coverage, from tests-state.json'
                + (" - <b>the package's own totals differ</b>" if cov.get("disagree") else "") + ".</p>")
    unc_rows = [f'<tr><td class="id">{e(u["paragraph"])}</td><td class="num">{e(u.get("lines"))}</td>'
                f'<td>{_rule_chips(u["rules"])}</td>'
                f'<td>{md(u["reason"]) if u["reason"] else chip("warn", "no reason in the arms table")}</td></tr>'
                for u in lc["uncovered"]]
    uncovered = (table(["Paragraph", "Lines", "Rules", "Reason (arms table)"], unc_rows, nums=(1,))
                 + (f'<p class="muted">From <code>{e(lc["armsFile"])}</code>'
                    + (f': {md(lc["armsNotes"])}' if lc.get("armsNotes") else "") + "</p>" if lc.get("armsFile") else "")
                 ) if unc_rows else '<p class="muted">Every business paragraph is reached by a case.</p>'
    rules = lc["rules"]
    unproven = (table(["Rule", "Text"], [f'<tr><td class="id">{e(r["id"])}</td><td>{md(_trim(r.get("text"), 300))}</td>'
                                         f'</tr>' for r in rules["unproven"]])
                if rules["unproven"] else '<p class="muted">Every rule has a golden case that proves it.</p>')
    decided = ", ".join(f"{e(s)} {n}" for s, n in (lc.get("decidedBySource") or {}).items())
    nr = [f'<tr><td class="id">{e(x["id"])}</td><td>{e(x.get("name"))}</td><td>{e(x.get("reason"))}</td></tr>'
          for x in lc["notRepresentable"] + lc["notRecorded"]]
    pq = lc["questions"]
    acc = lc.get("acceptance") or {}
    golden = ", ".join(f"{n} {s.lower()}" for s, n in (acc.get("goldenStates") or {}).items()) or "-"
    gate_html = (_kv([
        ("Record gate", (chip("pass", f'{acc["gate"]} settled') if acc.get("gate") else chip("warn", "not settled"))
         + (f' {chip("warn", acc["open"] + " open")}' if acc.get("open") else "")),
        ("Accepted by", f'<b>{e(acc.get("by"))}</b> <span class="muted">(as stored in validation-state.json)</span>'
         if acc.get("by") else '<span class="muted">nobody yet</span>'),
        ("At", e(acc.get("at")) if acc.get("at") else None),
        ("Golden masters", f'{num(acc.get("accepted"))} accepted, {len(acc.get("disputed") or [])} disputed; '
                           f'states after import: {e(golden)}'),
        ("Imported package", f'v{e(acc.get("importedVersion"))} {_short_hash(acc.get("importedHash"))}'
         + _match_chip(acc.get("importedIsCurrent"), "the current package", "not the current package")
         if acc.get("importedHash") else None),
    ]) + '<p class="muted">The recordings were made on the parity tester (GnuCOBOL, Db2 LUW), not on the '
         'mainframe: the emulator is not qualified here, every verdict carries this caveat.</p>') if acc else \
        '<p class="muted">Not accepted yet: mu-validate holds the record gate.</p>'
    lead = (f'<p class="lead">The oracle of L4: the legacy COBOL\'s answers, recorded by mu-build-tests into one test '
            f'package per entry point and accepted at the record gate of mu-validate. '
            f'<b>{num(c.get("cases"))}</b> cases, <b>{num(c.get("golden"))}</b> golden; '
            f'<b>{num(para.get("covered"))} of {num(para.get("total"))}</b> business paragraphs and '
            f'<b>{num(lines.get("covered"))} of {num(lines.get("code"))}</b> code lines executed.</p>')
    body = (lead + facts + "<h3>Cases</h3>" + cases
            + (f'<p class="muted">{DECIDED} Decided answers: {num(c.get("decided"))} case(s) expect the answer the '
               f'design decided, not the recorded one ({decided}).</p>' if c.get("decided") else "")
            + "<h3>Coverage of the legacy</h3>" + coverage
            + fold("Business paragraphs no case reaches", uncovered, plural(len(lc["uncovered"]), "paragraph"),
                   ident="lc-uncovered")
            + fold("Rules without a proving case", unproven, f'{len(rules["unproven"])} of {rules["total"]} rules',
                   ident="lc-unproven")
            + (fold("Cases without an API request (not representable / not recorded)",
                    table(["Case", "Name", "Reason"], nr), plural(len(nr), "case")) if nr else "")
            + fold("Open questions of the package (PQ)", _open_questions_table(pq["items"]) if pq["items"] else
                   '<p class="muted">None.</p>', f'{pq["open"]} open, {pq["blockingOpen"]} blocking', ident="lc-pq")
            + fold("The record gate (acceptance)", gate_html, e(acc.get("gate") or "not settled"))
            + f'<p class="muted">Source: <code>{e(lc["stateFile"])}</code>, <code>{e(lc["packageFile"])}</code></p>')
    return section("sec-lc", "LC", title, layer_chip(row), e(row["headline"]), body)


# --------------------------------------------------------------------------- L4


def difference_line(f: dict) -> str:
    path = f'<code>{e(f.get("path"))}</code>'
    kind = f.get("kind")
    if kind == "ROW_MISSING_IN_TARGET":
        return f'{path}: row missing in the Java - <code>{breakable(f.get("expected"))}</code>'
    if kind == "ROW_EXTRA_IN_TARGET":
        return f'{path}: extra row in the Java - <code>{breakable(f.get("actual"))}</code>'
    if kind == "ROW_COUNT":
        return f'{path}: rows - legacy <code>{e(f.get("expected"))}</code> &#8594; Java <code>{e(f.get("actual"))}</code>'
    if kind == "MISSING_IN_TARGET":
        return f'{path}: missing in the Java (legacy <code>{breakable(f.get("expected"))}</code>)'
    return (f'{path} <span class="muted">{e(kind)}</span>: legacy <code>{breakable(f.get("expected"))}</code> '
            f'&#8594; Java <code>{breakable(f.get("actual"))}</code>')


def breakable(value) -> str:
    return e(value).replace("|", "|<wbr>")


def decided_box(d: dict) -> str:
    recorded = d.get("recordedStatus")
    text = (f'<b>{DECIDED} Decided answer:</b> {e(d.get("status"))}, by {e(d.get("source"))}'
            + (f". The legacy recording answers {e(recorded)}." if recorded is not None else ".")
            + {"recorded": " Tables after the call: compared with the recording.",
               "notCompared": " Tables after the call: not compared."}.get(d.get("tables"), ""))
    return f'<span class="decided">{text}</span>'


def _failure_html(f: dict) -> str:
    sus = ", ".join(f'<b>{e(r["id"])}</b>' + (f' (<code>{e(r["home"])}</code>)' if r.get("home") else "")
                    for r in f.get("suspects") or [])
    parts = [f'{chip("fail", f["class"])} confidence {e(f.get("confidence"))}'
             + (f' &#183; operation {e(f.get("operation"))}' if f.get("operation") else "")
             + (f' &#183; {e(f.get("http"))}' if f.get("http") else "")]
    if sus:
        parts.append(f"Suspect rules: {sus}")
    if f.get("exception"):
        parts.append(f'<span class="muted">Exception: {e(_trim(f["exception"], 300))}</span>')
    if f.get("why"):
        parts.append(f'<span class="muted">Why: {md(_trim(f["why"], 400))}</span>')
    if f.get("next"):
        parts.append(f'<span class="muted">Next (mu-validate): {e(f["next"])}</span>')
    return "<br>".join(parts)


def _scenario_detail(s: dict) -> str:
    parts = []
    if s.get("reason"):
        parts.append(e(s["reason"]))
    elif s.get("message") and s["status"] not in ("FAILED",):
        parts.append(e(_trim(s["message"], 300)))
    if s.get("differences"):
        more = s["differenceCount"] - len(s["differences"])
        parts.append(f'{num(s["differenceCount"])} difference(s) under {e(s.get("profile"))}'
                     + (f" - the first {len(s['differences'])}" if more > 0 else "") + ":<br>"
                     + "<br>".join(difference_line(f) for f in s["differences"]))
    if s.get("failure"):
        parts.append(_failure_html(s["failure"]))
    if s.get("decided"):
        parts.append(decided_box(s["decided"]))
    if s.get("hypotheses"):
        parts.append('<span class="muted">Producer\'s hypothesis: ' + e(_trim("; ".join(map(str, s["hypotheses"])), 400))
                     + "</span>")
    if s.get("notCompared"):
        parts.append('<span class="muted">Not compared: ' + e("; ".join(s["notCompared"])) + "</span>")
    if s.get("stackDivergence"):
        parts.append('<span class="muted">Recorded on the test stack, not the mainframe: '
                     + e(_trim("; ".join(map(str, s["stackDivergence"])), 400)) + "</span>")
    return "<br>".join(parts)


def _rule_chips(ids) -> str:
    return "".join(f'<span class="ba-r">{e(r)}</span>' for r in ids) or '<span class="muted">-</span>'


def _scenario_rows(rows: list[dict]) -> list[str]:
    out = []
    for s in rows:
        status, label = OUTCOME.get(s["status"], ("none", s["status"]))
        out.append(f'<tr><td>{chip(status, label)}</td><td class="id">{e(s["id"])}</td><td>{e(s.get("title"))}</td>'
                   f'<td>{_rule_chips(s.get("rules"))}</td>'
                   f'<td class="mono">{e(s.get("strict") or "-")} / {e(s.get("contract") or "-")}</td>'
                   f'<td class="note">{_scenario_detail(s)}</td></tr>')
    return out


SCENARIO_HEAD = ["Result", "Scenario", "Title", "Rules", "Strict / contract", "Difference / note"]


def l4_section(l4: dict, layers: list[dict]) -> str:
    row = _row(layers, "L4")
    title = "Emulated functional parity"
    if l4.get("state") != "results":
        extra = (f'<p class="muted">Latest run <code>{e(l4.get("runId"))}</code> (<code>{e(l4.get("file"))}</code>)</p>'
                 if l4.get("runId") else "")
        gate = l4.get("gate") or {}
        if gate.get("open"):
            extra += callout(f'The record gate <b>{e(gate["open"])}</b> waits for a named person\'s answer in '
                             '<code>validation/validation-open-questions.md</code>.')
        body = (_absent_callout(l4, row["stateLabel"]) + extra
                + '<p class="muted">L4 replays every accepted recording of the package against the product\'s API, on '
                  'the rows the legacy ran on, and compares the answers (mu-validate).</p>')
        return section("sec-l4", "L4", title, layer_chip(row), e(row["headline"]), body)
    c = l4["counts"]
    cols = l4.get("columns") or {}
    decided = l4.get("decided") or {}
    hashes = l4["hashes"]
    lead = (f'<p class="lead">The product answered every scenario of the package through its API, on the rows the '
            f'legacy COBOL ran on, and each answer was compared with the accepted recording. '
            f'<b>{num(c["PASSED"])} of {num(l4["runnable"])}</b> runnable scenarios match under the contract '
            f'comparison'
            + (f' ({num(decided.get("passed"))} of them the answer the design decided)' if decided.get("passed") else "")
            + f'; {num(c["FAILED"])} differ. Results, not verdicts: the class of each difference is mu-validate\'s.</p>')
    col_rows = [f'<tr><td>{e(name)}</td><td class="num">{num((cols.get(key) or {}).get("MATCH", 0))}</td>'
                f'<td class="num">{num((cols.get(key) or {}).get("DIFF", 0))}</td><td class="muted">{e(note)}</td></tr>'
                for key, name, note in (("strict", "Strict", "every field byte for byte, shown for information"),
                                        ("contract", "Contract (the verdict)",
                                         "the package's comparison rules and decisions"))]
    columns = table(["Comparison", "match", "differ", ""], col_rows, nums=(1, 2), cls="compact")
    run_rows = [f'<tr><td class="num">{e(r["run"])}</td><td>{e(counts_text(r["counts"]))}</td>'
                f'<td class="mono">{e(r.get("digest"))}</td><td>{e(r.get("identicalToPrevious"))}</td>'
                f'<td class="num">{e(r.get("seconds"))}</td></tr>' for r in l4["perRun"]]
    runs = table(["Run", "Results", "Digest", "Identical to the one before", "Seconds"], run_rows, nums=(0, 4))
    facts = _kv([
        ("Run", f'<code>{e(l4["runId"])}</code>, {e(l4.get("startedAt"))} - {e(l4.get("finishedAt"))} '
                f'<span class="muted">(<code>{e(l4["file"])}</code>)</span>'),
        ("Repeatability", (chip("pass", "identical") if l4.get("identical") else chip("warn", "differ"))
         + f' {num(l4.get("runs"))} runs, {num(l4.get("differencesBetweenRuns"))} differences between them'),
        ("Product replayed", f'{_short_hash(hashes["product"]["replayed"], 16)}'
         + _match_chip(hashes["product"]["isCurrent"], "the current content hash", "the product has changed since")),
        ("Package replayed", f'v{e(hashes["package"].get("version"))} {_short_hash(hashes["package"]["replayed"])}'
         + _match_chip(hashes["package"]["matchesInstalled"], "as installed", "not the installed one")
         + _match_chip(hashes["package"]["isCurrent"], "the current package", "the package has changed since")),
        ("Framework", f'{e(hashes["framework"].get("version"))} {_short_hash(hashes["framework"]["replayed"])}'
         + _match_chip(hashes["framework"]["matchesInstalled"], "as installed", "not the installed one")),
        ("Database", e(", ".join(f"{k} {v}" for k, v in (l4.get("environment") or {}).items()
                                 if k in ("E2E_DB_URL", "E2E_DB_SCHEMA", "E2E_TARGET_CLOCK")))),
        ("Test module", f'<code>{e(l4.get("testModule"))}</code> for the product module '
                        f'<code>{e(l4.get("productModule"))}</code>' if l4.get("testModule") else None),
    ])
    classes = l4["classes"]
    cls_counts = classes["recorded"] or classes["listed"]
    class_rows = [f'<tr><td>{chip("fail", k)}</td><td class="num">{num(v)}</td>'
                  f'<td class="num">{num(classes["listed"].get(k, 0))}</td><td>{e(classes["owners"].get(k) or "-")}</td>'
                  f'</tr>' for k, v in cls_counts.items()]
    sus_rows = [f'<tr><td class="id">{e(r["id"])}</td><td><code>{e(r.get("home") or "-")}</code></td>'
                f'<td>{e(", ".join(r["classes"]))}</td><td>{e(", ".join(r["scenarios"]))}</td></tr>'
                for r in classes["suspectRules"]]
    triage = ((table(["Class", "validation-state.json", "failures.md", "Owner"], class_rows, nums=(1, 2), cls="compact")
               if class_rows else '<p class="muted">No failure to classify.</p>')
              + (table(["Suspect rule", "Target home", "Class", "Scenarios"], sus_rows) if sus_rows else "")
              + (f'<p class="muted">As mu-validate classified them in <code>{e(classes["file"])}</code>'
                 + ("" if classes["ofRun"] else " - <b>of another run</b>") + ".</p>" if classes.get("file") else ""))
    differing = [s for s in l4["scenarios"] if s["status"] in ("FAILED", "BLOCKED")]
    apart = [s for s in l4["scenarios"] if s["status"] in ("NOT_APPLICABLE", "SKIPPED", "NOT_RUN")]
    gate = l4.get("gate") or {}
    gate_html = _kv([
        ("Record gate", (chip("pass", f'{gate["settled"]} settled') if gate.get("settled") else chip("warn", "not settled"))
         + (f' {chip("warn", gate["open"] + " open")}' if gate.get("open") else "")),
        ("Accepted by", f'<b>{e(gate.get("by"))}</b> <span class="muted">(as stored)</span>' if gate.get("by") else None),
        ("At", e(gate.get("at")) if gate.get("at") else None),
        ("Golden masters", f'{num(gate.get("accepted"))} accepted, {len(gate.get("disputed") or [])} disputed; '
                           + e(", ".join(f"{n} {s.lower()}" for s, n in (l4.get("goldenStates") or {}).items()))),
    ])
    vq = l4["questions"]
    parts = [lead, stacked(c), legend(c), facts, "<h3>Strict and contract comparison</h3>", columns,
             fold("Runs", runs, plural(len(l4["perRun"]), "run"))]
    clock = l4.get("clock") or {}
    if clock.get("ran") and clock.get("unpinned"):
        reads = [f'<tr><td class="mono">{e(r["file"])}:{e(r["line"])}</td><td><code>{e(r["call"])}</code></td>'
                 f'<td>{e(r.get("method") or "-")}</td><td>{e(r["kind"])}</td></tr>' for r in clock["reads"]]
        parts.append(callout(f'<b>Clock:</b> {num(clock["clockSensitive"])} case(s) are clock-sensitive and the product '
                             f'reads the time past the injected <code>Clock</code> in {num(clock["unpinned"])} place(s): '
                             'a scenario that reaches them runs on the real date, not the recording\'s.'
                             + table(["Where", "Call", "Method", "Kind"], reads), "warn"))
    if decided.get("scenarios"):
        parts.append(callout(f'<b>{DECIDED} Decided answers:</b> {num(decided["scenarios"])} scenario(s) expect the answer '
                             f'the design decided, not the recorded one; {num(decided.get("passed"))} give it, '
                             f'{num(decided.get("failed"))} differ from it '
                             f'({e(", ".join(f"{k} {v}" for k, v in (decided.get("passedBySource") or {}).items()))}).',
                             "info"))
    parts.append("<h3>Failures by class</h3>" + triage)
    if differing:
        parts.append(fold("Differing scenarios", table(SCENARIO_HEAD, _scenario_rows(differing)),
                          plural(len(differing), "scenario"), ident="l4-differing"))
    if apart:
        parts.append(fold("Not applicable", table(SCENARIO_HEAD, _scenario_rows(apart)), plural(len(apart), "scenario")))
    parts.append(fold("All scenarios", scenarios_table(l4), plural(len(l4["scenarios"]), "scenario"), ident="l4-all"))
    parts.append(fold("The record gate and acceptance", gate_html, e(gate.get("settled") or "not settled")))
    parts.append(fold("Questions of mu-validate (VQ, RG)", _open_questions_table(vq["items"]) if vq["items"] else
                      '<p class="muted">None.</p>', f'{vq["open"]} open, {vq["answered"]} answered'))
    if l4.get("warnings"):
        parts.insert(1, "".join(callout(e(sentence(w))) for w in l4["warnings"]))
    return section("sec-l4", "L4", title, layer_chip(row), e(row["headline"]), "".join(parts))


def scenarios_table(l4: dict) -> str:
    """The table of every scenario as data: the rows are drawn by the page's script from the embedded document
    (`l4.scenarios`), with filters by status, rule and paragraph."""
    statuses = [k for k, _, _ in OUTCOMES if any(s["status"] == k for s in l4["scenarios"])]
    rules = sorted({r for s in l4["scenarios"] for r in s.get("rules") or []},
                   key=lambda r: (int(re.sub(r"\D", "", r) or 0), r))
    paragraphs = sorted({p for s in l4["scenarios"] for p in s.get("paragraphs") or []})
    opts = lambda values, every: (f'<option value="">{e(every)}</option>'
                                  + "".join(f'<option value="{e(v)}">{e(v)}</option>' for v in values))
    return (f'<div class="filters" id="l4-filters" hidden>'
            f'<label>Status <select data-l4="status">{opts(statuses, "all")}</select></label>'
            f'<label>Rule <select data-l4="rule">{opts(rules, "all")}</select></label>'
            f'<label>Paragraph <select data-l4="paragraph">{opts(paragraphs, "all")}</select></label>'
            f'<label>Text <input type="search" data-l4="text" placeholder="id, title, class"></label>'
            f'<span class="muted" id="l4-shown"></span></div>'
            + table(SCENARIO_HEAD, [], table_id="l4-table")
            + '<noscript><p class="muted">The table of all scenarios is drawn from the embedded data by the page\'s '
              'script; the differing and not applicable scenarios are listed above.</p></noscript>')


# --------------------------------------------------------------------------- questions


def questions_section(q: dict) -> str:
    files = [f'<tr><td class="mono">{e(f["file"])}</td><td>{e(", ".join(f["ids"]) or "-")}</td>'
             f'<td>{e(f["owner"])}</td><td class="num">{num(f["total"])}</td><td class="num">{num(f["open"])}</td>'
             f'<td class="num">{num(f["blockingOpen"])}</td><td class="num">{num(f["answered"])}</td></tr>'
             if f["present"] else
             f'<tr><td class="mono">{e(f["file"])}</td><td colspan="6" class="muted">not there</td></tr>'
             for f in q["files"]]
    body = ('<p class="lead">Every question a command left for a person, one list, blocking first. The decision taken '
            'stands until it is answered on the question\'s <code>Answer:</code> line.</p>'
            + table(["File", "Ids", "Command", "Questions", "Open", "Blocking", "Answered"], files,
                    nums=(3, 4, 5, 6))
            + ("<h3>Open</h3>" + _open_questions_table(q["open"], with_file=True) if q["open"] else
               '<p class="muted">No open question.</p>')
            + (fold("Answered and settled", _open_questions_table(q["answered"], with_file=True),
                    plural(len(q["answered"]), "question")) if q["answered"] else ""))
    status = "fail" if q["blockingOpen"] else "warn" if q["openCount"] else "pass"
    by = ", ".join(f'{p} {v["open"]}' for p, v in q["byPrefix"].items() if v["open"])
    head = (f'{q["openCount"]} open' + (f' ({by})' if by else "") + f', {q["blockingOpen"]} blocking, '
            f'{q["total"] - q["openCount"]} answered or settled')
    return section("sec-questions", "", "Questions", chip(status, f'{q["openCount"]} open'), e(head), body)


def gaps_section(rows: list[dict]) -> str:
    order = {"fail": 0, "warn": 1, "none": 2, "pass": 3}
    body_rows = [f'<tr><td class="mono">{e(r["layer"])}</td><td>{chip(r["status"], "open" if r["status"] == "none" else None)}'
                 f'</td><td>{e(sentence(r["item"]))}</td><td>{e(r["owner"])}</td></tr>'
                 for r in sorted(rows, key=lambda r: order.get(r["status"], 9))]
    acting = len([r for r in rows if r["status"] in ("fail", "warn")])
    body = ('<p class="lead">A check that could not run is listed here with its owner - never counted as passed.</p>'
            + table(["Level", "Status", "Item", "Owner"], body_rows))
    return section("sec-gaps", "", "Open items and owners", chip("warn" if acting else "none", f"{acting} to act on"),
                   e(f"{len(rows)} items: what is open, not run or not reached, and whose move it is"), body)


def measures_section(rows: list[dict]) -> str:
    body_rows = [f'<tr><td>{e(r["measure"])}</td><td class="muted">{e(r["definition"])}</td><td>{e(r["value"])}</td>'
                 f'<td>{e(r["target"])}</td><td>{chip(r["status"], "pending" if r["status"] == "none" else None)}</td></tr>'
                 for r in rows]
    computed = [r for r in rows if r["status"] != "none"]
    failing = [r for r in computed if r["status"] in ("fail", "warn")]
    body = ('<p class="lead">The key measures of the Test Strategy this evidence can compute today.</p>'
            + table(["Measure", "Definition", "Value", "Target", "Status"], body_rows))
    headline = (f"{len(computed)} of {len(rows)} measures computed"
                + (f", {len(failing)} off target" if failing else "")
                + ("" if computed else " - most of them follow from the parity runs (L4)"))
    status = chip("fail" if any(r["status"] == "fail" for r in computed) else "warn" if failing else
                  "pass" if computed else "none", None if computed else "pending")
    return section("sec-measures", "", "Key measures", status, e(headline), body)


def evidence_section(doc: dict) -> str:
    items = "".join(f"<li><code>{e(s)}</code></li>" for s in doc.get("sources") or [])
    body = (f'<dl class="kv"><dt>Mode</dt><dd>{e(doc.get("mode"))}</dd><dt>Inputs fingerprint</dt>'
            f'<dd><code>{e(doc.get("inputsFingerprint"))}</code></dd><dt>Report format</dt>'
            f'<dd>{e(doc.get("reportFormat"))}</dd><dt>Product content hash</dt>'
            f'<dd><code>{e((doc.get("product") or {}).get("hash") or "no solution folder")}</code></dd></dl>'
            + fold("Files this report was counted from", f"<ul>{items}</ul>", plural(len(doc.get("sources") or []),
                                                                                       "file")))
    return section("sec-evidence", "", "Evidence", "", e(f"{len(doc.get('sources') or [])} files, fingerprinted"), body)


TABS = (("tab-overview", "Overview", None), ("tab-l0", "L0", "L0"), ("tab-build", "L1 - L3", "L1"),
        ("tab-lc", "LC", "LC"), ("tab-l4", "L4", "L4"), ("tab-questions", "Questions", None))


def render(doc: dict) -> str:
    layers = doc["layers"]
    by_id = {r["id"]: r for r in layers}
    build_status = worst(by_id[lv]["status"] for lv in ("L1", "L2", "L3") if by_id[lv]["state"] == "results")
    q = doc.get("questions") or {"openCount": 0, "blockingOpen": 0}
    marks = {"tab-l0": by_id["L0"], "tab-lc": by_id["LC"], "tab-l4": by_id["L4"],
             "tab-build": {"status": build_status, "state": "results" if build_status != "none" else "x"},
             "tab-questions": {"status": "fail" if q["blockingOpen"] else "warn" if q["openCount"] else "pass",
                               "state": "results"}}
    buttons = []
    for ident, label, _ in TABS:
        mark = marks.get(ident)
        icon = ""
        if mark:
            st = mark["status"] if mark.get("state") == "results" else "none"
            icon = f'<span class="tab-ic {st}" aria-hidden="true">{ICONS[st]}</span>'
        buttons.append(f'<a class="tab" role="tab" href="#{ident}" data-tab="{ident}">{icon}{e(label)}</a>')
    controls = ('<span class="spacer"></span><button class="btn light" id="expand-all" type="button">Expand all</button>'
                '<button class="btn light" id="collapse-all" type="button">Collapse all</button>')
    panels = {
        "tab-overview": glance(doc) + gaps_section(doc["gaps"]) + measures_section(doc["measures"])
        + evidence_section(doc),
        "tab-l0": l0_section(doc["l0"], layers), "tab-build": build_section(doc["build"], layers),
        "tab-lc": lc_section(doc["lc"], layers), "tab-l4": l4_section(doc["l4"], layers),
        "tab-questions": questions_section(q) if q.get("files") else "",
    }
    body = "".join(f'<div class="panel" id="{ident}" role="tabpanel">{panels[ident]}</div>' for ident, _, _ in TABS)
    data = json.dumps(doc, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    title = f"Test results report - {doc['mu'].get('name')}"
    return ("<!DOCTYPE html>\n<html lang=\"en\"><head><meta charset=\"utf-8\">"
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
            f"<title>{e(title)}</title><style>{CSS}</style></head><body>{header(doc)}"
            f"<main class=\"page\"><nav class=\"tabs\" role=\"tablist\" aria-label=\"Levels\">{''.join(buttons)}"
            f"{controls}</nav>{body}"
            f"<footer>Generated by mu-report (report format {e(doc.get('reportFormat'))}) from the files listed under "
            f"Evidence. Every number is counted by a script from those files; nothing here is estimated by a model. "
            f"Results, not verdicts.</footer></main>"
            f"<script type=\"application/json\" id=\"test-results\">{data}</script>"
            f"<script>{SCRIPT}</script></body></html>\n")
