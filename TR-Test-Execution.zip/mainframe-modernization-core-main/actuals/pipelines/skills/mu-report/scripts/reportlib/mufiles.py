"""The workspace as mu-report reads it: the MU work folder (`mu/<MU>`), its manifest and tools.yaml (through
${CLAUDE_PLUGIN_ROOT}/scripts/tools_config.py), the shared `solution/` and its content hash, the product module of the MU.

Content hash (the product's identity, the same rule as mu-validate's snapshot): sha256 over `<path>\\t<sha256>\\n`
of every file of the mu.yaml `solution` folder, sorted, target/ .git/ .idea/ .vscode/ node_modules/ .claude/
left out. Revision = its first 16 hex digits.
"""

from __future__ import annotations

import importlib.util
import os
import socket
from dataclasses import dataclass, field
from pathlib import Path

from . import buildchecks, mdtext
from .common import TOOLS_CONFIG, Stop, file_sha, long_path, read_json_or_none, read_text, rel, sha256, slash_command

COPY_SKIP = {".git", "target", ".idea", ".vscode", "node_modules", ".claude"}
TEST_SOLUTION = "validation"

_TC: dict = {}


def tools_config():
    if "m" not in _TC:
        spec = importlib.util.spec_from_file_location("tools_config", TOOLS_CONFIG)
        mod = importlib.util.module_from_spec(spec)
        try:
            spec.loader.exec_module(mod)
        except SystemExit as e:                      # PyYAML missing
            raise Stop(str(e.code)) from None
        _TC["m"] = mod
    return _TC["m"]


def disk_case(path: Path) -> Path:
    """`path` with every part spelled as on disk (a case-insensitive file system accepts `mu/P510` for `mu/p510`)."""
    parts = Path(path).parts
    out = Path(parts[0])
    for part in parts[1:]:
        try:
            out = out / next((p.name for p in out.iterdir() if p.name.lower() == part.lower()), part)
        except OSError:
            out = out / part
    return out


# --------------------------------------------------------------------------- the MU


@dataclass
class Mu:
    workspace: Path
    folder: Path                      # mu/<MU>
    mu_arg: str                       # as the user types it, relative to the workspace
    manifest: dict
    solution: Path | None             # mu.yaml `solution`, None when not set
    _raw_tools: dict | None = field(default=None, repr=False)

    @property
    def name(self) -> str:
        return str(self.manifest.get("name") or self.folder.name)

    @property
    def entries(self) -> list[str]:
        return [str(e) for e in self.manifest.get("entry_points") or []]

    @property
    def report(self) -> Path:
        return self.folder / "report"

    @property
    def scratch(self) -> Path:
        return self.report / ".tmp"

    @property
    def history(self) -> Path:
        return self.report / "history"

    @property
    def tests(self) -> Path:
        return self.folder / "tests"

    @property
    def validation(self) -> Path:
        return self.folder / "validation"

    @property
    def test_solution(self) -> Path:
        return self.workspace / TEST_SOLUTION

    @property
    def tools_file(self) -> Path:
        return self.folder / "tools.yaml"

    def rel(self, path) -> str:
        return rel(Path(path), self.workspace)

    def command(self, name: str, *options: str) -> str:
        """The command line a person runs next, e.g. `/mu-validate mu/p510`."""
        return " ".join([slash_command(name), self.mu_arg, *options])

    # ------------------------------------------------------------ tools.yaml, partial
    def raw_tools(self) -> dict:
        if self._raw_tools is None:
            if not self.tools_file.is_file():
                self._raw_tools = {}
            else:
                import yaml
                self._raw_tools = yaml.safe_load(self.tools_file.read_text(encoding="utf-8")) or {}
        return self._raw_tools

    def tool(self, name: str, key: str | None = None):
        """A tools.yaml section (or one key of it) with secrets and {mu} resolved; None when the file, the section
        or the key is not there. An unresolved ${NAME} is a decision for the user (exit 2)."""
        section = self.raw_tools().get(name)
        if not isinstance(section, dict) or (key is not None and key not in section):
            return None
        try:
            return tools_config().tool(str(self.folder), name, key)
        except SystemExit as e:
            raise Stop(str(e.code), code=2, reason="tools_config") from None


def load_mu(workspace: Path, mu_arg: str) -> Mu:
    workspace = Path(workspace).resolve()
    folder = (workspace / mu_arg).resolve() if not Path(mu_arg).is_absolute() else Path(mu_arg).resolve()
    if not (folder / "mu.yaml").is_file():
        raise Stop(f"{Path(mu_arg).as_posix()}/mu.yaml not found: run from the workspace root with the MU folder "
                   f"(mu/<MU>)")
    folder = disk_case(folder)
    try:
        shown = folder.relative_to(disk_case(workspace)).as_posix()
    except ValueError:
        shown = folder.as_posix()
    try:
        manifest = tools_config().tool(str(folder), "mu") or {}
    except SystemExit as e:
        raise Stop(str(e.code)) from None
    sol = manifest.get("solution")
    solution = (workspace / str(sol)).resolve() if sol else None
    return Mu(workspace=workspace, folder=folder, mu_arg=shown, manifest=manifest, solution=solution)


def test_database(mu: Mu, with_secret: bool = False) -> dict | None:
    """The MU's test database as mu-implement uses it: `test-db2`, else `db2` (host localhost). The password only
    when asked for, never into a report."""
    for name in ("test-db2", "db2"):
        raw = mu.raw_tools().get(name)
        if not isinstance(raw, dict):
            continue
        value = {k: mu.tool(name, k) for k in ("host", "port", "database", "schema", "user") if k in raw}
        db = {"source": name, "host": value.get("host") or "localhost", "port": int(value.get("port") or 50000),
              "database": value.get("database"), "schema": value.get("schema"), "user": value.get("user")}
        if with_secret:
            db["password"] = mu.tool(name, "password")
        return db
    return None


def reachable(host: str, port: int, timeout: float = 3.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


# --------------------------------------------------------------------------- the product's identity


def manifest_of(solution):
    out = {}
    base = long_path(solution)
    for root, dirs, files in os.walk(base):
        dirs[:] = sorted(d for d in dirs if d not in COPY_SKIP)
        for name in sorted(files):
            src = Path(root) / name
            out[src.relative_to(base).as_posix()] = file_sha(src)
    return out


def hash_of(manifest):
    return sha256("".join(f"{p}\t{d}\n" for p, d in sorted(manifest.items())))


def identity(mu: Mu) -> dict | None:
    """The product as it is on disk: {solution, hash, revision, files, hasPom, manifest (path -> sha256)}; None when
    there is no solution folder."""
    if mu.solution is None or not mu.solution.is_dir():
        return None
    man = manifest_of(mu.solution)
    h = hash_of(man)
    return {"solution": mu.rel(mu.solution), "hash": h, "revision": h[:16], "files": len(man),
            "hasPom": (mu.solution / "pom.xml").is_file(), "manifest": man}


# --------------------------------------------------------------------------- the product module of the MU


def product_module(mu: Mu) -> dict | None:
    """The reactor module of this MU: `validation-state.json solution.facts.productModule`, else the first row of the
    Module table of `implement/report.md`; never `solution/<mu name>`. {artifactId, dir, source} or None."""
    name, source, folder = None, None, None
    facts = ((read_json_or_none(mu.validation / "validation-state.json") or {}).get("solution") or {}).get("facts")
    if isinstance(facts, dict) and facts.get("productModule"):
        name, folder = str(facts["productModule"]), facts.get("productModuleDir")
        source = "validation/validation-state.json solution.facts.productModule"
    else:
        table = mdtext.first_table(read_text(mu.folder / "implement" / "report.md") or "", "Module")
        first = mdtext.unquote(((table or {}).get("rows") or [{}])[0].get("Module"))
        if first:
            name, source = first, "implement/report.md Module table"
    if not name:
        return None
    if not folder and mu.solution is not None and (mu.solution / "pom.xml").is_file():
        try:
            found = next((m for m in buildchecks.reactor(mu.solution) if name in (m["artifactId"], m["module"])), None)
        except Exception:                    # noqa: BLE001 - an unreadable reactor: no folder from it
            found = None
        if found:
            name, folder = found["artifactId"], found["module"]
    folder = folder or name
    present = mu.solution is not None and (mu.solution / folder).is_dir()
    return {"artifactId": name, "dir": folder, "source": source, "present": present}
