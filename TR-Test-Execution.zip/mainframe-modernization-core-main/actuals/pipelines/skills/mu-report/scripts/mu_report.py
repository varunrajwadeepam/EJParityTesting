#!/usr/bin/env python3
"""mu-report: the test results report of one MU - every level of the test pyramid, L0 to L4 and LC, as ONE
self-contained HTML page with the report document embedded in it.

    python -B ${CLAUDE_PLUGIN_ROOT}/skills/mu-report/scripts/mu_report.py build <mu> [--confirm] [--rebuild] [--json]
    python -B ${CLAUDE_PLUGIN_ROOT}/skills/mu-report/scripts/mu_report.py status <mu> [--json]

build   reads the MU folder (design/, implement/, unit/, tests/, validation/), the product's suites (the checks
        record of the content hash, else the reports of the last build in solution/) and writes
        mu/<MU>/report/test-results.html and report/history/test-results-<MU>-<YYYY-MM-DD>-<hhmm>[-n].html (local time;
        an existing dated copy is never overwritten).
        Scratch in report/.tmp/. A missing folder is a level state with its owner and next command, never an error.
status  compares the inputs and the content hash of solution/ with those recorded in the page:
        current, changed (with the files) or not_built. Writes nothing.

One JSON object on stdout; exit 0 done, 2 decision or input needed, 1 failed.
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
import sys
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))

from reportlib import l0 as l0lib, report, report_html, suites  # noqa: E402
from reportlib.common import Parser, Stop, main, write_text  # noqa: E402
from reportlib.mufiles import identity, load_mu  # noqa: E402

PAGE = "test-results.html"
_EMBEDDED = re.compile(r'<script type="application/json" id="test-results">(.*?)</script>', re.S)


def embedded(page: Path) -> dict | None:
    """The report document embedded in a built page."""
    if not page.is_file():
        return None
    match = _EMBEDDED.search(page.read_text(encoding="utf-8", errors="replace"))
    if not match:
        return None
    try:
        return json.loads(match.group(1).replace("<\\/", "</"))
    except ValueError:
        return None


def history_name(mu_name: str, generated_at: str) -> str:
    """test-results-<MU>-<YYYY-MM-DD>-<hhmm>.html from the document's generatedAt (UTC), in local time."""
    local = datetime.strptime(generated_at, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc).astimezone()
    day, clock = local.strftime("%Y-%m-%d"), local.strftime("%H%M")
    return f"test-results-{re.sub(r'[^A-Za-z0-9_.-]', '_', mu_name)}-{day}-{clock}.html"


def history_path(folder: Path, name: str) -> Path:
    """The dated copy's path; an existing copy is never overwritten: -2, -3, ... is added before .html."""
    path, n = folder / name, 1
    while path.exists():
        n += 1
        path = folder / f"{name[:-len('.html')]}-{n}.html"
    return path


def _workspace(args) -> Path:
    return Path(args.workspace).resolve() if args.workspace else Path.cwd()


def handle_build(args):
    if args.rebuild and not args.confirm:
        raise Stop("--rebuild needs --confirm")
    mu = load_mu(_workspace(args), args.mu)
    product = identity(mu)
    mode = "confirm" if args.confirm else "fast"
    if mode == "confirm":
        record = suites.confirm(mu, product, rebuild=args.rebuild)
    else:
        record = suites.fast(mu, product, l0lib.recorded_test_database(mu))
    document = report.build(mu, mode, record, product)
    html = report_html.render(document)
    page = mu.report / PAGE
    copy = history_path(mu.history, history_name(mu.name, document["generatedAt"]))
    write_text(page, html)
    write_text(copy, html)
    return {"status": "built", "html": mu.rel(page), "history": mu.rel(copy), "mode": mode,
            "product": (product or {}).get("revision"),
            "overall": document["overall"]["label"] or document["overall"]["status"],
            "sentence": document["overall"]["sentence"],
            "layers": {r["id"]: f"{r['status']} ({r['stateLabel']}): {r['headline']}" for r in document["layers"]
                       if r["inScope"]},
            "attention": [f"[{a['layer']}] {a['item']} - {a['owner']}" for a in document["attention"]],
            "next": (document.get("next") or {}).get("command"),
            "suites": _suites_summary(document.get("build") or {}, record),
            "gaps": len(document["gaps"]), "inputsFingerprint": document["inputsFingerprint"]}


def _suites_summary(build: dict, record: dict | None) -> dict:
    """L1 - L3 in the answer: the source and revision of what ran, per level tests / failures / errors / skipped, and
    the MU module's line coverage."""
    if not build.get("available"):
        return {"state": build.get("state"), "reason": build.get("short") or build.get("reason")}
    record = record or {}
    mu_row = next((m for m in build.get("modules") or [] if m.get("role") == "mu"), None)
    line = (mu_row or {}).get("lineCoverage") or {}
    out = {"source": build.get("source"), "revision": build.get("revision"), "reused": build.get("reused"),
           "ranAt": build.get("ranAt"), "build": build.get("build"), "seconds": build.get("seconds"),
           "log": build.get("log"), "copiedFrom": (record.get("copiedFrom") or {}).get("source"),
           "database": {k: (build.get("database") or {}).get(k) for k in ("source", "host", "port", "database",
                                                                            "schema")}
           if build.get("database") else None,
           "lineCoverage": {"module": (mu_row or {}).get("artifactId"), "covered": line.get("covered"),
                            "missed": line.get("missed"), "ratio": line.get("ratio")} if line else None}
    for lv, data in (build.get("levels") or {}).items():
        t = data.get("totals") or {}
        out[lv] = {"status": data.get("status"), **{k: t.get(k) for k in ("classes", "tests", "failures", "errors",
                                                                          "skipped")}}
    return out


def handle_status(args):
    mu = load_mu(_workspace(args), args.mu)
    page = mu.report / PAGE
    built = embedded(page)
    if built is None:
        return {"status": "not_built", "html": mu.rel(page), "next": mu.command("mu-report")}
    return {**report.status(mu, built), "html": mu.rel(page)}


def build_parser() -> Parser:
    ap = Parser(prog="mu_report", description="mu-report: the test results page of one MU")
    sub = ap.add_subparsers(dest="command", required=True, parser_class=Parser)
    for name, text in (("build", "write the test results page"), ("status", "whether the page is still current")):
        sp = sub.add_parser(name, help=text)
        sp.add_argument("mu", help="the MU folder, mu/<MU>")
        sp.add_argument("--workspace", help="the workspace root (default: the current folder)")
        sp.add_argument("--json", action="store_true", help="accepted; the answer is always one JSON object")
        if name == "build":
            sp.add_argument("--confirm", action="store_true",
                            help="build and test a copy of the product by content hash (L1-L3)")
            sp.add_argument("--rebuild", action="store_true", help="with --confirm: run again for the same hash")
    return ap


def run(argv=None):
    args = build_parser().parse_args(argv)
    return {"build": handle_build, "status": handle_status}[args.command](args)


if __name__ == "__main__":
    main(run)
