#!/usr/bin/env python3
"""Offline self-test of mu-report (no Maven, no Db2, no git): a throw-away workspace with one synthetic MU per stage
of progress (empty, design, + implement, + tests, + validation, + a run), every level state asserted, the page and
the command through mu_report.py, the content hash against mu-validate's snapshot rule, nothing written outside
mu/<MU>/report/.

    python -B ${CLAUDE_PLUGIN_ROOT}/skills/mu-report/scripts/selftest.py [--keep]
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
RUNNER = HERE / "mu_report.py"
SNAPSHOT_SCRIPTS = HERE.parents[1] / "mu-validate" / "scripts"
REAL_SOLUTION = HERE.parents[3] / "solution"
P510_HASH = "253dc52cd8f4a825bf8ca569be3c07a5be8f68d98b8d7cfe8f93062221cf5788"     # solution/ on 2026-11-06
sys.path.insert(0, str(HERE))

from reportlib import buildchecks, common, l0, mufiles, parity, questions, report, report_html, suites  # noqa: E402
from reportlib import tests_level  # noqa: E402
from reportlib.common import slash_command  # noqa: E402

MU_YAML = """\
# MU manifest
name: {name}
description: Demo service (DEMO_S)
du: demo
entry_points: [DEMO0001]
portfolio_id: 7                     # comment after a value
target:
  architecture_skill: target-java-3tier
  archetype: REST
solution: {solution}
"""

TOOLS_YAML = """\
secrets: ~/.config/none-mu-report-selftest/secrets.env

test-db2:
  kind: local
  host: localhost
  port: 1
  database: TESTDB
  schema: DB2INST1
  user: db2inst1
  password: ${MU_REPORT_SELFTEST_PW}
"""

DESIGN_REPORT = """\
# report.md - demo

| Step | Status | Note |
|---|---|---|
| 0 Preflight | done | all there |
| 2 Rules | done | 3 rules; coverage check clean |
| 9 Report | done | |

Rules 3 · cases 2 · stubs 0 · open questions 1

Paragraph coverage, from `check_rule_coverage.py`: 5 business paragraphs of 6, 5 with a rule, 0 findings left.

## Blocked

Nothing.

## Tool gaps

- the runner is slow

## Review findings

| # | Reviewer | Severity | Finding | applied / rejected / open | Where / why |
|---|---|---|---|---|---|
| 1 | R1 | High | a thing | applied | rules |
| 2 | R2 | High/Med | another | open | design |
| 3 | R3 | Low/Med | small | rejected | why |

## Waiting for the user

OQ-1 in design-open-questions.md.
"""

DESIGN_OQ = """\
# design-open-questions.md

## Settled

- one settled line
- two settled lines

## OQ-1 - The clock

Step: rules · Status: open
Question: which clock?
Decision taken: the system clock.

Answer:

## OQ-2 - The zone

Step: design · Status: open
Question: which zone?

Answer: UTC, decided by the architect 2026-10-01
"""

PQ_FILE = """\
# tests-open-questions.md

## PQ-1 - A recorded server date

Step: 3 · Status: open
Blocking: no
Question: which date?
Decision taken: the recorded one.
Affects: case add-clock-variant.
Answer:

## RG-1 - Record gate DEMO0001 v1

Step: gate · Status: settled
Blocking: yes
Question: accept?
Answer: accepted by Jane Doe
"""

IMPLEMENT_REPORT = """\
# report.md - demo

| Step | Status | Note |
|---|---|---|
| 0 Preflight | done | |
| 5 Build and unit tests | green | 5 unit tests |
| 6 Integration tests | green | `test-db2` |

Work items 2/2 · rules covered 3/3 · open questions 0

## Build and tests

| Module | Build | Unit run / failed / skipped | Integration run / failed / skipped |
|---|---|---|---|
| `demo-mod` | SUCCESS | 5 / 0 / 0 | 2 / 0 / 0 |

Test database: `test-db2` - localhost:50000/TESTDB, schema `DB2INST1`.

## Traceability

From the gate, not from reading: `5` business paragraphs, `5` cited or exempt
(`100`%), `0` findings. Report: `implement/traceability.md`.

## Review findings

| # | Reviewer | Severity | Finding | applied / rejected / open | Where / why |
|---|---|---|---|---|---|

## Blocked

None.
"""

ROOT_POM = """<project xmlns="http://maven.apache.org/POM/4.0.0"><modelVersion>4.0.0</modelVersion>
  <groupId>g</groupId><artifactId>root</artifactId><version>1</version><packaging>pom</packaging>
  <modules><module>demo-mod</module><module>other-mod</module></modules></project>
"""
MOD_POM = """<project xmlns="http://maven.apache.org/POM/4.0.0"><modelVersion>4.0.0</modelVersion>
  <artifactId>{a}</artifactId></project>
"""
APP_YML = """spring:
  datasource:
    url: ${DB_URL}
    username: ${DB_USERNAME}
"""


# ---------------------------------------------------------------- a package, a run and its failures (LC, L4)
PKG_HASH = "aa11" * 16
FW_HASH = "fw00" * 16


def _case(i, origin, status, category, rules, paras, clock=False, **extra):
    return {"id": f"TC-{i}", "name": f"case-{i}", "origin": origin, "category": category, "ruleIds": rules,
            "status": status, "clockSensitive": clock, "paragraphs": paras, "stackDivergence": [], **extra}


CASES = [
    _case(1, "basic", "golden", "Happy", ["R1"], ["A.P1", "A.P2"], clock=True),
    _case(2, "basic", "golden", "Error", ["R2"], ["A.P1"],
          decidedAnswer={"source": "OQ-1", "status": 400, "recordedStatus": 200, "tables": "notCompared"}),
    _case(3, "advanced", "golden", "Edge", ["R1", "R2"], ["A.P2"], clock=True),
    _case(4, "advanced", "golden", "Boundary", ["R2"], ["A.P3"]),
    _case(5, "advanced", "not-representable", "Edge", ["R3"], [], reason="no API request for this command"),
    _case(6, "advanced", "golden", "Edge", ["R3"], ["A.P3"]),
]
PACKAGE = {
    "package": {"format": 3, "version": 2, "contentHash": PKG_HASH, "state": "ready",
                "generator": {"name": "mu-build-tests", "scriptsHash": "s1"}},
    "goldenMaster": "cobol-runner", "comparisonRules": [{"id": "STATUS"}, {"id": "RTRIM"}],
    "rules": [{"id": "R1", "text": "one", "provenBy": ["TC-1", "TC-3"]}, {"id": "R2", "text": "two",
              "provenBy": ["TC-2", "TC-3", "TC-4"]}, {"id": "R3", "text": "three", "provenBy": ["TC-6"]},
              {"id": "R4", "text": "four: a duplicate no input reaches", "provenBy": []}],
    "coverage": {"totals": {"paragraphs": {"total": 4, "covered": 3, "uncovered": 1},
                            "lines": {"code": 40, "covered": 29, "uncovered": 11}, "outsideLines": 7},
                 "paragraphs": [
                     {"program": "A", "name": "P1", "kind": "business", "covered": True, "lines": [1, 9]},
                     {"program": "A", "name": "P2", "kind": "business", "covered": True, "lines": [10, 19]},
                     {"program": "A", "name": "P3", "kind": "business", "covered": True, "lines": [20, 29]},
                     {"program": "A", "name": "P4", "kind": "business", "covered": False, "lines": [100, 110],
                      "codeLines": 11},
                     {"program": "A", "name": "M1", "kind": "mechanism", "covered": False, "lines": [200, 201]}]},
    "cases": CASES}
TESTS_STATE = {"entry": "DEMO0001", "state": "ready", "scope": "full", "reasons": {},
               "package": {"version": 2, "contentHash": PKG_HASH,
                           "path": "mu/{name}/tests/package/DEMO0001/DEMO0001-tests.json"},
               "counts": {"cases": 6, "basic": 2, "advanced": 4, "golden": 5, "notRepresentable": 1,
                          "notRecorded": 0, "clockSensitive": 2, "decided": 1},
               "coverage": {"paragraphs": {"total": 4, "covered": 3, "uncovered": 1},
                            "lines": {"code": 40, "covered": 29, "uncovered": 11}, "outsideLines": 7,
                            "estimated": False}, "stale": []}
ARMS = """\
# DEMO0001 - arms

## A

| arm id | program.paragraph | lines | condition (agent) | rule ids | case ids |
|---|---|---|---|---|---|
| A-1 | A.P1 | 1-9 | the happy path | R1 | case-1 |
| A-9 | A.P4 | 100-110 | duplicate row: unreachable (the key is new) | R4 |  |

## Notes

A-9 is unreachable by input: PQ-1.
"""
LC_PQ = """\
# tests-open-questions.md

## PQ-1 - A duplicate no input reaches

Step: 7 · Status: open
Blocking: no
Question: leave it uncovered?
Decision taken: left uncovered.
Answer:

## PQ-2 - The zone

Step: 3 · Status: open
Blocking: no
Question: which zone?
Decision taken: UTC.
Answer:
"""
VQ = """\
# validation-open-questions.md

## VQ-1 - Replay schema

Step: preflight · Status: settled
Blocking: yes
Question: which schema?
Answer: E2E_DEMO_1

## RG-1 - Record gate DEMO0001 v2: 5 golden masters to accept

Step: gate · Status: settled
Blocking: yes
Question: accept?
Answer: approved by Jane Doe
"""
FAILURES = """\
# failures.md - demo / DEMO0001

Run R1 · snapshot x · 2026-11-06 · evidence `mu/demo/validation/.tmp/analysis.json`

Failed 2 · blocked 0 · skipped 0 · classes: SOLUTION 1, PACKAGE 1

## Not compared

- none

## TC-3 - case-3

Class: SOLUTION · Confidence: high · Pre-class: SOLUTION (high)
Operation: create · HTTP expected 201, actual 500
Rules: R1 (`Svc.a`)
Suspect rules: R2 (`Svc.b`)
Exception: x.ProcessingFailedException: boom
Next: implementer

## TC-4 - case-4

Class: PACKAGE · Confidence: medium · Pre-class: PACKAGE (medium)
Rules: R2 (`Svc.b`)
Suspect rules: -
Next: mu-build-tests
"""


def _verdict(status, diffs=()):
    return {"status": status, "diffs": [{"field": f, "kind": k, "legacy": a, "target": b} for f, k, a, b in diffs]}


def replay_scenarios():
    value = [("x", "VALUE", "1", "2")]
    out = []
    for i, st, strict, contract in ((1, "PASSED", ("MATCH", []), ("MATCH", [])),
                                    (2, "PASSED", ("DIFF", value), ("MATCH", [])),
                                    (3, "FAILED", ("DIFF", value), ("DIFF", value)),
                                    (4, "FAILED", ("DIFF", [("table:T[]", "ROW_COUNT", "1", "0")]),
                                     ("DIFF", [("table:T[]", "ROW_COUNT", "1", "0")])),
                                    (6, "PASSED", ("DIFF", value), ("MATCH", []))):
        out.append({"scenarioId": f"TC-{i}", "title": f"case-{i}", "status": st, "message": f"m{i}",
                    "strict": _verdict(strict[0], strict[1]), "contract": _verdict(contract[0], contract[1]),
                    "verdictProfile": "contract", "notes": [], "hypotheses": ["OQ-9: maybe"] if i == 3 else []})
    out.insert(4, {"scenarioId": "TC-5", "title": "case-5", "status": "NOT_APPLICABLE", "message": "no request",
                   "notes": [], "hypotheses": []})
    return out


def summary(product_hash, run_id="R1"):
    return {"format": 1, "entry": "DEMO0001", "runId": run_id, "startedAt": "2026-11-06T11:58:00Z",
            "finishedAt": "2026-11-06T12:00:00Z", "snapshot": {"hash": product_hash, "revision": product_hash[:16]},
            "package": {"contentHash": PKG_HASH, "version": 2}, "framework": FW_HASH, "runs": 2,
            "perRun": [{"run": 1, "counts": {"PASSED": 3, "FAILED": 2, "NOT_APPLICABLE": 1}, "digest": "d1"},
                       {"run": 2, "counts": {"PASSED": 3, "FAILED": 2, "NOT_APPLICABLE": 1}, "digest": "d1",
                        "identicalToPrevious": True}],
            "repeatable": True, "differencesBetweenRuns": [], "scenarios": 6,
            "counts": {"PASSED": 3, "FAILED": 2, "BLOCKED": 0, "NOT_APPLICABLE": 1, "SKIPPED": 0},
            "columns": {"strict": {"MATCH": 1, "DIFF": 4}, "contract": {"MATCH": 3, "DIFF": 2}},
            "goldenStates": {"ACCEPTED": 5}, "warnings": []}


def validation_state(with_run: bool, product_hash: str | None = None):
    st = {"format": 1, "steps": {"preflight": {"status": "ready", "exit": 0}, "import": {"status": "imported", "exit": 0}},
          "solution": {"module": "demo-e2e", "facts": {"productModule": "demo-mod", "productModuleDir": "demo-mod"}},
          "runs": [], "framework": {"version": "0.2.0", "fingerprint": FW_HASH},
          "imports": {"DEMO0001": {"version": 2, "contentHash": PKG_HASH, "importedAt": "2026-11-06T11:00:00Z"}},
          "import": {"goldenStates": {"ACCEPTED": 5}}}
    if with_run:
        st["gate"] = {"open": None, "settled": "RG-1", "by": "Jane Doe", "at": "2026-11-06T11:30:00Z", "accepted": 5,
                      "disputed": []}
        st["acceptance"] = {f"TC-{i}": {"by": "Jane Doe", "gate": "RG-1"} for i in (1, 2, 3, 4, 6)}
        st["analysis"] = {"runId": "R1", "classCounts": {"SOLUTION": 1, "PACKAGE": 1}}
        st["runs"] = [{"runId": "R1", "finishedAt": "2026-11-06T12:00:00Z", "snapshotHash": product_hash}]
    return st


class T:
    def __init__(self, keep: bool):
        self.keep = keep
        self.ws = Path(tempfile.mkdtemp(prefix="mur-selftest-"))
        self.fails, self.n = [], 0
        self.env = dict(os.environ)
        self.env.update({"PYTHONDONTWRITEBYTECODE": "1", "MU_REPORT_SELFTEST_PW": "testenv"})
        os.environ["MU_REPORT_SELFTEST_PW"] = "testenv"

    # ---------------------------------------------------------------- helpers
    def check(self, cond, what: str) -> None:
        self.n += 1
        if not cond:
            self.fails.append(what)
            print(f"FAIL {what}", file=sys.stderr)

    def w(self, rel: str, text: str) -> Path:
        p = self.ws / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)
        return p

    def run(self, *args: str) -> tuple[int, dict]:
        p = subprocess.run([sys.executable, "-B", str(RUNNER), *args], cwd=str(self.ws), capture_output=True,
                           env=self.env, timeout=600)
        out = p.stdout.decode("utf-8", errors="replace").strip().splitlines()
        try:
            doc = json.loads(out[-1]) if out else {}
        except ValueError:
            doc = {"raw": out}
        if len(out) != 1:
            doc["_lines"] = len(out)
        return p.returncode, doc

    def mu(self, name: str):
        return mufiles.load_mu(self.ws, f"mu/{name}")

    def doc(self, name: str, record: dict | None = None) -> dict:
        mu = self.mu(name)
        product = mufiles.identity(mu)
        if record is None:
            record = suites.fast(mu, product, l0.recorded_test_database(mu))
        return report.build(mu, "fast", record, product)

    @staticmethod
    def states(doc: dict) -> dict:
        return {r["id"]: (r["status"], r["state"]) for r in doc["layers"]}

    def tree(self) -> dict:
        """path -> (size, mtime_ns, sha) of every file of the workspace outside mu/*/report/."""
        out = {}
        for p in sorted(self.ws.rglob("*")):
            if p.is_file():
                rel = p.relative_to(self.ws).as_posix()
                if re.match(r"mu/[^/]+/report/", rel):
                    continue
                st = p.stat()
                out[rel] = (st.st_size, st.st_mtime_ns, mufiles.file_sha(p))
        return out

    # ---------------------------------------------------------------- the synthetic MUs
    def stage(self, name: str, upto: int, solution: str | None = None) -> None:
        """0 empty, 1 design, 2 + implement and a solution, 3 + tests, 4 + validation state, 5 + a run."""
        sol = solution or f"solution-{name}/"
        self.w(f"mu/{name}/mu.yaml", MU_YAML.format(name=name, solution=sol))
        if upto >= 1:
            self.w(f"mu/{name}/tools.yaml", TOOLS_YAML)
            self.w(f"mu/{name}/design/report.md", DESIGN_REPORT)
            self.w(f"mu/{name}/design/design-open-questions.md", DESIGN_OQ)
            self.w(f"mu/{name}/design/rules.md", "# rules\n")
            self.w(f"mu/{name}/unit/DEMO0001/cases.json", json.dumps({"unit": "DEMO0001", "cases": [
                {"name": "c1", "expect": {"A": "1"}}, {"name": "c2"}]}))
        if upto >= 2:
            self.w(f"mu/{name}/implement/report.md", IMPLEMENT_REPORT)
            self.w(f"mu/{name}/implement/implement-open-questions.md", "# implement-open-questions.md\n\n## Settled\n")
            self.w(f"mu/{name}/implement/traceability.md", "# Traceability\n")
            if not solution:
                self.w(f"{sol}pom.xml", ROOT_POM)
                self.w(f"{sol}demo-mod/pom.xml", MOD_POM.format(a="demo-mod"))
                self.w(f"{sol}other-mod/pom.xml", MOD_POM.format(a="other-mod"))
                self.w(f"{sol}demo-mod/src/main/java/x/A.java", "package x;\nclass A {}\n")
                self.w(f"{sol}demo-mod/src/main/resources/application.yml", APP_YML)
        if upto >= 3:
            ts = json.loads(json.dumps(TESTS_STATE).replace("{name}", name))
            self.w(f"mu/{name}/tests/tests-state.json", json.dumps(ts))
            self.w(f"mu/{name}/tests/tests-open-questions.md", LC_PQ)
            self.w(f"mu/{name}/tests/package/DEMO0001/DEMO0001-tests.json", json.dumps(PACKAGE))
            self.w(f"mu/{name}/tests/package/DEMO0001/traceability.md", "# traceability - DEMO0001\n")
            self.w(f"mu/{name}/tests/notes/DEMO0001-arms.md", ARMS)
        if upto == 4:
            self.w(f"mu/{name}/validation/validation-state.json", json.dumps(validation_state(False)))
        if upto >= 5:
            product = mufiles.identity(self.mu(name))
            h = product["hash"] if product else "0" * 64
            self.w(f"mu/{name}/validation/validation-state.json", json.dumps(validation_state(True, h)))
            self.w(f"mu/{name}/validation/runs/R1/summary.json", json.dumps(summary(h)))
            self.w(f"mu/{name}/validation/runs/R1/run-1/e2e-replay.json",
                   json.dumps({"mode": "REPLAY", "scenarios": replay_scenarios()}))
            self.w(f"mu/{name}/validation/failures.md", FAILURES)
            self.w(f"mu/{name}/validation/validation-open-questions.md", VQ)

    # ---------------------------------------------------------------- the checks
    def t_parsers(self):
        st = l0.steps(DESIGN_REPORT)
        self.check([s["status"] for s in st] == ["done", "done", "done"], f"parsers: steps {st}")
        self.check(l0.counts_line(DESIGN_REPORT) == [{"label": "Rules", "value": "3", "note": None},
                                                     {"label": "cases", "value": "2", "note": None},
                                                     {"label": "stubs", "value": "0", "note": None},
                                                     {"label": "open questions", "value": "1", "note": None}],
                   "parsers: counts line")
        f = l0.findings(DESIGN_REPORT)
        self.check(f["bySeverity"] == {"High": 2, "Medium": 0, "Low": 1, "Unrated": 0}
                   and f["byOutcome"] == {"applied": 1, "rejected": 1, "open": 1, "other": 0}
                   and f["openBySeverity"]["High"] == 1, f"parsers: review findings {f['bySeverity']}")
        q = l0.questions(DESIGN_OQ)
        self.check((q["total"], q["open"], q["answered"], q["settled"]) == (2, 1, 1, 2)
                   and q["items"][0]["decision"] == "the system clock."
                   and q["items"][1]["answer"].startswith("UTC"), f"parsers: OQ file {q['total']} {q['open']}")
        pq = l0.questions(PQ_FILE, "mu/x/tests/tests-open-questions.md")
        ids = [(i["id"], i["blocking"], i["answered"]) for i in pq["items"]]
        self.check(ids == [("PQ-1", False, False), ("RG-1", True, True)] and pq["items"][0]["affects"]
                   == "case add-clock-variant." and pq["blockingOpen"] == 0, f"parsers: PQ / RG with Blocking {ids}")
        impl = l0.steps(IMPLEMENT_REPORT)
        self.check(all(s["status"].lower() in l0.DONE for s in impl), "parsers: 'green' is a done step")

    def t_stages(self):
        for name, upto in (("s0", 0), ("s1", 1), ("s2", 2), ("s3", 3), ("s4", 4), ("s5", 5)):
            self.stage(name, upto)
        d = self.doc("s0")
        s = self.states(d)
        self.check(s["L0"] == ("none", "not_produced") and s["L1"] == ("none", "not_reached")
                   and s["LC"] == ("none", "not_reached") and s["L4"] == ("none", "not_reached")
                   and s["L5"] == ("none", "planned"), f"stage empty: states {s}")
        self.check(d["next"]["command"] == slash_command("mu-design") + " mu/s0" and d["product"] is None
                   and d["overall"]["label"] == "In progress", f"stage empty: next {d['next']}")
        d = self.doc("s1")
        s = self.states(d)
        impl = d["l0"]["phases"]["implementation"]
        self.check(s["L0"] == ("warn", "results") and impl["state"] == "not_produced"
                   and impl["next"] == slash_command("mu-implement") + " mu/s1"
                   and s["L1"] == ("none", "not_reached") and s["LC"] == ("none", "not_produced")
                   and s["L4"] == ("none", "not_reached"), f"stage design: states {s}")
        self.check(d["next"]["command"] == slash_command("mu-implement") + " mu/s1", f"stage design: next {d['next']}")
        ch = d["l0"]["phases"]["design"]["characterisation"]
        self.check((ch["cases"], ch["recorded"]) == (2, 1), f"stage design: the design's recordings {ch}")
        rc = d["l0"]["phases"]["design"]["ruleCoverage"]
        self.check(not rc["ran"] and "paragraph-index.json" in rc["reason"], f"stage design: gate not re-run {rc}")
        self.check(d["lc"]["owner"] == "mu-build-tests" and d["lc"]["next"] == slash_command("mu-build-tests") + " mu/s1"
                   and d["l4"]["owner"] == "mu-build-tests", f"stage design: LC/L4 owners {d['lc']['owner']}")
        d = self.doc("s2")
        s = self.states(d)
        self.check(s["L0"][1] == "results" and s["L1"] == ("none", "not_run") and s["LC"] == ("none", "not_produced")
                   and d["build"]["next"] == slash_command("mu-report") + " mu/s2 --confirm"
                   and d["next"]["command"] == slash_command("mu-build-tests") + " mu/s2",
                   f"stage implement: states {s} next {d['next']}")
        self.check(d["product"]["revision"] == d["product"]["hash"][:16] and d["product"]["files"] == 5,
                   f"stage implement: content hash identity {d['product']}")
        self.check(d["productModule"] == {"artifactId": "demo-mod", "dir": "demo-mod", "present": True,
                                          "source": "implement/report.md Module table"},
                   f"stage implement: product module from the Module table {d['productModule']}")
        tr = d["l0"]["phases"]["implementation"]["traceabilityRecorded"]
        self.check(tr and (tr["business"], tr["covered"], tr["findings"]) == (5, 5, 0),
                   f"stage implement: traceability as recorded {tr}")
        d = self.doc("s3")
        s = self.states(d)
        self.check(s["LC"] == ("warn", "results") and d["lc"]["present"]
                   and d["lc"]["packages"] == ["mu/s3/tests/package/DEMO0001/DEMO0001-tests.json"]
                   and s["L4"] == ("none", "not_produced") and d["l4"]["next"] == slash_command("mu-validate") + " mu/s3",
                   f"stage tests: states {s}")
        self.check(d["next"]["command"] == slash_command("mu-validate") + " mu/s3", f"stage tests: next {d['next']}")
        d = self.doc("s4")
        s = self.states(d)
        self.check(s["L4"] == ("none", "not_run") and "import" in d["l4"]["reason"], f"stage validation: L4 {d['l4']}")
        self.check(d["productModule"]["source"].startswith("validation/validation-state.json"),
                   f"stage validation: product module from validation-state.json {d['productModule']}")
        d = self.doc("s5")
        self.check(self.states(d)["L4"] == ("fail", "results") and d["l4"]["runId"] == "R1",
                   f"stage run: L4 results {self.states(d)['L4']}")
        names = {g["owner"] for g in self.doc("s1")["gaps"]}
        self.check({"mu-implement", "mu-build-tests", "architect / MU owner"} <= names, f"gaps: owners {names}")

    # ---------------------------------------------------------------- LC, L4, questions (3c)
    def t_lc(self):
        d = self.doc("s5")
        lc = d["lc"]
        src = json.loads((self.ws / "mu/s5/tests/tests-state.json").read_text(encoding="utf-8"))
        pkg = json.loads((self.ws / "mu/s5/tests/package/DEMO0001/DEMO0001-tests.json").read_text(encoding="utf-8"))
        self.check(lc["counts"] == src["counts"] and lc["countsDisagree"] == [], f"lc: counts = tests-state.json {lc['counts']}")
        self.check(lc["byStatus"] == {"golden": 5, "not-representable": 1, "not-recorded": 0}
                   and lc["byOrigin"] == {"basic": 2, "advanced": 4}, f"lc: counted in the package {lc['byStatus']}")
        cov = lc["coverage"]
        self.check(cov["paragraphs"] == src["coverage"]["paragraphs"] and cov["lines"] == src["coverage"]["lines"]
                   and cov["outsideLines"] == 7 and cov["paragraphsPercent"] == 75.0 and cov["linesPercent"] == 72.5
                   and cov["mechanismUncovered"] == 1, f"lc: coverage from the file {cov}")
        unc = lc["uncovered"]
        self.check(len(unc) == 1 and unc[0]["paragraph"] == "A.P4" and unc[0]["rules"] == ["R4"]
                   and "unreachable" in unc[0]["reason"] and unc[0]["arms"] == ["A-9"],
                   f"lc: uncovered paragraph with its reason from the arms table {unc}")
        self.check([r["id"] for r in lc["rules"]["unproven"]] == [r["id"] for r in pkg["rules"] if not r["provenBy"]]
                   == ["R4"], f"lc: rules without a proving case {lc['rules']}")
        self.check(lc["questions"]["open"] == 2 and lc["status"] == "warn" and lc["packageState"] == "ready",
                   f"lc: open PQ make it warn {lc['status']}")
        acc = lc["acceptance"]
        self.check(acc["gate"] == "RG-1" and acc["by"] == "Jane Doe" and acc["accepted"] == 5
                   and acc["importedIsCurrent"] is True, f"lc: acceptance from validation-state.json {acc}")
        # a package whose counts disagree with tests-state.json is shown, never resolved
        self.stage("s9", 3)
        st = json.loads((self.ws / "mu/s9/tests/tests-state.json").read_text(encoding="utf-8"))
        st["counts"]["golden"] = 99
        st["state"] = "needs-answers"
        self.w("mu/s9/tests/tests-state.json", json.dumps(st))
        lc9 = self.doc("s9")["lc"]
        self.check(lc9["countsDisagree"] == ["golden"] and lc9["counts"]["golden"] == 99
                   and lc9["countedInPackage"]["golden"] == 5 and lc9["status"] == "warn",
                   f"lc: disagreement shown {lc9['countsDisagree']}")
        self.check(self.doc("s9")["next"]["command"] == slash_command("mu-build-tests") + " mu/s9",
                   "lc: a package not ready sends to mu-build-tests")

    def t_l4(self):
        d = self.doc("s5")
        l4 = d["l4"]
        sm = json.loads((self.ws / "mu/s5/validation/runs/R1/summary.json").read_text(encoding="utf-8"))
        self.check(l4["counts"] == sm["counts"] and l4["total"] == 6 and l4["runnable"] == 5
                   and l4["columns"] == sm["columns"], f"l4: counts and columns = summary.json {l4['counts']}")
        self.check(l4["repeatable"] and l4["identical"] and l4["runs"] == 2, "l4: two identical runs")
        h = l4["hashes"]
        self.check(h["product"]["isCurrent"] is True and h["package"]["matchesInstalled"] is True
                   and h["package"]["isCurrent"] is True and h["framework"]["matchesInstalled"] is True,
                   f"l4: hashes current {h}")
        rows = {r["id"]: r for r in l4["scenarios"]}
        self.check(len(rows) == 6 and rows["TC-3"]["rules"] == ["R1", "R2"] and rows["TC-3"]["paragraphs"] == ["A.P2"]
                   and rows["TC-3"]["failure"]["class"] == "SOLUTION"
                   and rows["TC-3"]["failure"]["suspects"] == [{"id": "R2", "home": "Svc.b"}]
                   and rows["TC-2"]["decided"]["source"] == "OQ-1" and rows["TC-2"]["notCompared"]
                   and rows["TC-4"]["differences"][0]["kind"] == "ROW_COUNT"
                   and rows["TC-6"]["strictByKind"] == {"VALUE": 1} and rows["TC-5"]["status"] == "NOT_APPLICABLE",
                   "l4: rows joined with the package cases and failures.md")
        cl = l4["classes"]
        self.check(cl["recorded"] == {"SOLUTION": 1, "PACKAGE": 1} and cl["listed"] == {"SOLUTION": 1, "PACKAGE": 1}
                   and cl["header"] == {"SOLUTION": 1, "PACKAGE": 1} and cl["ofRun"]
                   and [r["id"] for r in cl["suspectRules"]] == ["R2"], f"l4: classes as mu-validate wrote them {cl}")
        self.check(l4["gate"]["by"] == "Jane Doe" and l4["gate"]["accepted"] == 5 and l4["acceptedScenarios"] == 5
                   and l4["questions"]["total"] == 2 and l4["questions"]["open"] == 0, f"l4: gate and VQ {l4['gate']}")
        self.check(l4["decided"] == {"scenarios": 1, "passed": 1, "failed": 0, "passedBySource": {"OQ-1": 1},
                                     "failedBySource": {}}, f"l4: decided answers {l4['decided']}")
        self.check(l4["clock"]["ran"] and l4["clock"]["unpinned"] == 0 and not l4["warnings"],
                   f"l4: clock scan ran (clock-sensitive cases), found nothing {l4['clock']}")
        self.check(d["next"]["command"] == slash_command("mu-build-tests") + " mu/s5" and "PACKAGE" in d["next"]["why"],
                   f"l4: next move for PACKAGE first, as mu-validate {d['next']}")
        self.check(any(g["layer"] == "L4" and g["status"] == "fail" and "SOLUTION" in g["item"] and "R2" in g["item"]
                       and g["owner"] == "mu-implement" for g in d["gaps"]), "l4: a SOLUTION gap with its suspect rule")
        page = report_html.render(d)
        self.check("Clock:" not in page, "l4: no clock section when nothing reads past the Clock")
        # failures.md of another run: not classified, a warning; SOLUTION only -> mu-implement
        self.stage("s10", 5)
        self.w("mu/s10/validation/failures.md", FAILURES.replace("Run R1", "Run R0"))
        d10 = self.doc("s10")
        self.check(not d10["l4"]["classes"]["ofRun"] and any("not of R1" in w for w in d10["l4"]["warnings"])
                   and d10["next"]["command"] == slash_command("mu-validate") + " mu/s10",
                   f"l4: failures.md of another run {d10['next']}")
        self.w("mu/s10/validation/failures.md", FAILURES.split("## TC-4")[0])
        d10 = self.doc("s10")
        self.check(d10["next"]["command"] == slash_command("mu-implement") + " mu/s10"
                   and "R2" in d10["next"]["why"], f"l4: SOLUTION -> mu-implement {d10['next']}")
        # a time read past the injected Clock: a warning on L4 and its section
        self.w("solution-s10/demo-mod/src/main/java/x/C.java",
               "package x;\nclass C { java.time.LocalDate d() { return java.time.LocalDate.now(); } }\n")
        d10 = self.doc("s10")
        self.check(d10["l4"]["clock"]["unpinned"] == 1 and any(w.startswith("clock:") for w in d10["l4"]["warnings"])
                   and "Clock:" in report_html.render(d10), f"l4: clock warning {d10['l4']['clock']}")
        # the product changed since the run
        self.check(d10["l4"]["hashes"]["product"]["isCurrent"] is False, "l4: a product change since the run is seen")

    def t_questions(self):
        q = questions.collect(self.mu("s5"))
        self.check(q["openCount"] == 3 and [i["id"] for i in q["open"]] == ["OQ-1", "PQ-1", "PQ-2"]
                   and q["byPrefix"]["VQ"] == {"total": 1, "open": 0, "blockingOpen": 0}
                   and q["byPrefix"]["RG"]["total"] == 1, f"questions: one list {[i['id'] for i in q['open']]}")
        self.w("mu/s9/tests/tests-open-questions.md", LC_PQ.replace("PQ-2 - The zone\n\nStep: 3 · Status: open\n"
                                                                  "Blocking: no", "PQ-2 - The zone\n\nStep: 3 · "
                                                                  "Status: open\nBlocking: yes"))
        q = questions.collect(self.mu("s9"))
        d = self.doc("s9")
        self.check(q["open"][0]["id"] == "PQ-2" and q["blockingOpen"] == 1
                   and d["next"]["command"] == slash_command("mu-build-tests") + " mu/s9" and "PQ-2" in d["next"]["why"],
                   f"questions: blocking first, next move answers it {d['next']}")
        saved = common.SKILLS
        try:
            fake = self.ws / "_plugin" / "skills"
            (fake.parent / ".claude-plugin").mkdir(parents=True)
            (fake.parent / ".claude-plugin" / "plugin.json").write_text("{}", encoding="utf-8")
            common.SKILLS = fake
            self.check(self.mu("s5").command("mu-implement") == "/pipelines:mu-implement mu/s5",
                       "questions: a plugin copy prints /pipelines:...")
        finally:
            common.SKILLS = saved
        self.check(self.mu("s5").command("mu-implement") == slash_command("mu-implement") + " mu/s5", "questions: the command in the form of this install")

    def t_numbers(self):
        """Every number on the page of the run stage, against the source files."""
        d = self.doc("s5")
        page = report_html.render(d)
        text = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", page.split('<script type="application/json"')[0]))
        sm = json.loads((self.ws / "mu/s5/validation/runs/R1/summary.json").read_text(encoding="utf-8"))
        st = json.loads((self.ws / "mu/s5/tests/tests-state.json").read_text(encoding="utf-8"))
        c, cov, cols = sm["counts"], st["coverage"], sm["columns"]
        expected = [
            f"{c['PASSED']} / {c['PASSED'] + c['FAILED']}",                                  # L4 tile
            f"{c['PASSED']} passed, {c['FAILED']} failed, {c['NOT_APPLICABLE']} not applicable of {sm['scenarios']}",
            f"{c['PASSED']} of {c['PASSED'] + c['FAILED']} runnable",
            f"Strict {cols['strict']['MATCH']} {cols['strict']['DIFF']}",
            f"Contract (the verdict) {cols['contract']['MATCH']} {cols['contract']['DIFF']}",
            f"{st['counts']['cases']} cases",
            f"{cov['paragraphs']['covered']} / {cov['paragraphs']['total']} paragraphs",
            f"{cov['lines']['covered']} / {cov['lines']['code']} lines",
            f"paragraphs {cov['paragraphs']['covered']}/{cov['paragraphs']['total']}, lines "
            f"{cov['lines']['covered']}/{cov['lines']['code']}",
            f"Business paragraphs {cov['paragraphs']['covered']} {cov['paragraphs']['uncovered']} "
            f"{cov['paragraphs']['total']} 75.0%",
            f"Code lines of those paragraphs {cov['lines']['covered']} {cov['lines']['uncovered']} "
            f"{cov['lines']['code']} 72.5%",
            f"{cov['outsideLines']} executed lines lie outside",
            "SOLUTION 1 1", "PACKAGE 1 1", "Jane Doe", "5 accepted, 0 disputed",
            f"{sm['runs']} runs, 0 differences between them", "1 of 4 rules",
        ]
        for i, (k, label) in enumerate((("cases", "Cases"), ("basic", "basic (the design's set)"),
                                        ("advanced", "advanced"), ("golden", "golden (recorded, the oracle)"),
                                        ("notRepresentable", "not representable"), ("clockSensitive", "clock-sensitive"),
                                        ("decided", "with a decided answer"))):
            expected.append(f"{label} {st['counts'][k]}")
        missing = [x for x in expected if x.replace("'", "&#x27;") not in text and x not in text]
        self.check(not missing, f"numbers: every number of the page is the source file's (missing {missing})")
        emb = json.loads(re.search(r'<script type="application/json" id="test-results">(.*?)</script>', page,
                                   re.S).group(1).replace("<\\/", "</"))
        self.check(len(emb["l4"]["scenarios"]) == sm["scenarios"] and 'id="l4-table"' in page
                   and 'data-l4="rule"' in page and 'data-l4="paragraph"' in page and 'data-l4="status"' in page,
                   "numbers: the scenarios table is data in the page with filters by status, rule, paragraph")

    def t_module_never_mu_name(self):
        self.stage("p9", 1, solution="solution-s2/")
        self.w("solution-s2/p9/pom.xml", MOD_POM.format(a="p9"))
        self.check(mufiles.product_module(self.mu("p9")) is None, "product module: never solution/<mu name>")
        shutil.rmtree(self.ws / "solution-s2" / "p9")

    def t_tools(self):
        mu = self.mu("s1")
        db = mufiles.test_database(mu)
        self.check(db["source"] == "test-db2" and db["port"] == 1 and "password" not in db, f"tools: test-db2 {db}")
        self.check(mufiles.test_database(mu, with_secret=True)["password"] == "testenv",
                   "tools: the password only on request, ${NAME} from the environment")
        self.stage("t1", 0)
        self.w("mu/t1/tools.yaml", "db2:\n  port: 50000\n  database: TESTDB\n  user: u\n")
        db = mufiles.test_database(self.mu("t1"))
        self.check(db["source"] == "db2" and db["host"] == "localhost" and db["port"] == 50000,
                   f"tools: db2 when test-db2 is absent {db}")
        mu0 = self.mu("s0")
        self.check(mu0.tool("test-db2") is None and mufiles.test_database(mu0) is None,
                   "tools: no tools.yaml is not fatal")
        self.check(self.mu("s1").tool("mflens") is None, "tools: a missing section is not fatal")

    def _java(self, module: Path, name: str, body: str) -> None:
        p = module / "src" / "test" / "java" / "x" / f"{name}.java"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(f"package x;\n{body}\n", encoding="utf-8")

    def t_level_rule(self):
        module = self.ws / "_lv" / "m"
        self._java(module, "ItSupport", "@SpringBootTest(webEnvironment = RANDOM_PORT)\nabstract class ItSupport { "
                                        "io.restassured.RestAssured r; }")
        self._java(module, "WipAddIT", "class WipAddIT extends ItSupport { }")
        self._java(module, "HandlerTest", "class HandlerTest { MockMvc mvc = MockMvcBuilders.standaloneSetup(); }")
        self._java(module, "SliceTest", "@WebMvcTest\nclass SliceTest { MockMvc mvc; }")
        self._java(module, "PaymentContractTest", "class PaymentContractTest { }")
        self._java(module, "PlainTest", "class PlainTest { /* @SpringBootTest in a comment */ }")
        sources = buildchecks.test_sources(module)
        level = {n: buildchecks.classify(f"x.{n}", sources)[0] for n in
                 ("WipAddIT", "HandlerTest", "SliceTest", "PaymentContractTest", "PlainTest")}
        self.check(level == {"WipAddIT": "L3", "HandlerTest": "L2", "SliceTest": "L2", "PaymentContractTest": "L2",
                             "PlainTest": "L1"}, f"level rule: {level}")
        self.check(buildchecks.classify("x.Other", sources, runner="failsafe")[0] == "L3", "level rule: failsafe is L3")
        shutil.rmtree(self.ws / "_lv")

    @staticmethod
    def surefire(module: Path, classname: str, tests: int, failures: int = 0, runner: str = "surefire") -> None:
        cases = "".join(f'<testcase classname="{classname}" name="t{i}"/>' for i in range(tests - failures))
        cases += "".join(f'<testcase classname="{classname}" name="f{i}"><failure message="boom">x</failure>'
                         f'</testcase>' for i in range(failures))
        p = module / "target" / f"{runner}-reports" / f"TEST-{classname}.xml"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(f'<testsuite name="{classname}" tests="{tests}" failures="{failures}" errors="0" skipped="0" '
                     f'time="0.1">{cases}</testsuite>', encoding="utf-8")

    def t_suites(self):
        self.stage("s6", 2)
        module = self.ws / "solution-s6" / "demo-mod"
        self._java(module, "ServiceTest", "class ServiceTest { }")
        self._java(module, "ApiIT", "@SpringBootTest\nclass ApiIT { }")
        self.surefire(module, "x.ServiceTest", 4, failures=1)
        self.surefire(module, "x.ApiIT", 2, runner="failsafe")
        site = module / "target" / "site" / "jacoco"
        site.mkdir(parents=True)
        (site / "jacoco.xml").write_text('<report name="demo"><counter type="LINE" missed="10" covered="90"/></report>',
                                         encoding="utf-8")
        other = self.ws / "solution-s6" / "other-mod"
        self.surefire(other, "y.OtherTest", 3)
        d = self.doc("s6")
        lv = d["build"]["levels"]
        self.check(d["build"]["available"] and d["build"]["source"] == "last-build"
                   and lv["L1"]["totals"]["tests"] == 4 and lv["L1"]["status"] == "fail"
                   and lv["L3"]["totals"]["tests"] == 2 and lv["L3"]["realDb2"] is True,
                   f"suites: last build read by level {lv['L1']['totals']} {lv['L3']['totals']}")
        self.check("implementation's record" in lv["L3"]["db2Evidence"][0], f"suites: Db2 evidence {lv['L3']['db2Evidence']}")
        self.check(d["build"]["muModule"] == "demo-mod" and d["build"]["notCounted"] == ["other-mod"],
                   f"suites: the MU module counts, the other is listed {d['build']['notCounted']}")
        mu_row = next(m for m in d["build"]["modules"] if m["role"] == "mu")
        self.check(mu_row["lineCoverage"]["ratio"] == 0.9, f"suites: JaCoCo line ratio {mu_row['lineCoverage']}")
        self.check(any("failing test" in g["item"] for g in d["gaps"]), "suites: failing tests are a gap")
        self.check(any(p.endswith("TEST-x.ServiceTest.xml") for p in d["sources"]), "suites: reports are inputs")
        page = report_html.render(d)
        self.check('id="build-failing"' in page and 'id="tc-x.ServiceTest"' in page and 'data-filter-scope="tests-L1"'
                   in page and "<details open" not in page, "suites: the page folds every class and the failures")
        db2_root = self.ws / "_db2"
        (db2_root / "m" / "src" / "main" / "resources").mkdir(parents=True)
        (db2_root / "pom.xml").write_text('<project xmlns="http://maven.apache.org/POM/4.0.0"><modules><module>m'
                                          '</module></modules></project>', encoding="utf-8")
        (db2_root / "m" / "pom.xml").write_text('<project xmlns="http://maven.apache.org/POM/4.0.0"><artifactId>m'
                                                '</artifactId></project>', encoding="utf-8")
        (db2_root / "m" / "src" / "main" / "resources" / "application.yml").write_text(
            "spring:\n  datasource:\n    url: ${DB_URL}\n", encoding="utf-8")
        self._java(db2_root / "m", "WipAddIT", "@SpringBootTest\nclass WipAddIT { }")
        self.surefire(db2_root / "m", "x.WipAddIT", 3, runner="failsafe")
        without = buildchecks.collect(db2_root, None, db2_connection=False)[0]["classes"][0]
        with_db2 = buildchecks.collect(db2_root, None, db2_connection=True)[0]["classes"][0]
        self.check((without["level"], without["db2"]) == ("L3", False) and (with_db2["level"], with_db2["db2"])
                   == ("L3", True), "suites: L3 on Db2 when the build had one and the datasource is from the env")
        shutil.rmtree(db2_root)

    def t_gates(self):
        self.w("mu/s2/extracted-logic/paragraph-index.json", '{"programs": {}}')
        fake = self.w("_scripts/check_rule_coverage.py", "import sys\nprint('9 From citations; 60 paragraphs, "
                      "50 business, 50 with a rule or a reason (100%)')\n")
        saved = l0.coverage_script, l0.traceability_script
        try:
            l0.coverage_script = lambda: fake
            l0.traceability_script = lambda mu: self.ws / "_none" / "validate_traceability.py"
            mu = self.mu("s2")
            gate = l0.gates(mu, mu.scratch)
            self.check(gate["ruleCoverage"]["ran"] and gate["ruleCoverage"]["status"] == "pass"
                       and gate["ruleCoverage"]["business"] == 50 and not gate["traceability"]["ran"]
                       and "is not there" in gate["traceability"]["reason"], f"gates: rule coverage re-run {gate}")
            l0.coverage_script = lambda: self.ws / "_none" / "check_rule_coverage.py"
            gate = l0.gates(mu, mu.scratch)
            self.check("is not there" in gate["ruleCoverage"]["reason"]
                       and "needs the design's exemptions" in gate["traceability"]["reason"],
                       f"gates: missing scripts are a reason {gate}")
        finally:
            l0.coverage_script, l0.traceability_script = saved
            (self.ws / "mu/s2/extracted-logic/paragraph-index.json").unlink()

    def t_page(self):
        d = self.doc("s1")
        page = report_html.render(d)
        self.check([r["id"] for r in d["layers"]][:6] == ["L0", "L1", "L2", "L3", "LC", "L4"],
                   f"page: levels in pyramid order L0 L1 L2 L3 LC L4 {[r['id'] for r in d['layers']]}")
        self.check(page.count('<section class="sec"') == 8 and "<details open" not in page
                   and page.count('role="tabpanel"') == 6,
                   f"page: 8 sections in 6 tabs ({page.count('<section class=' + chr(34) + 'sec' + chr(34))})")
        self.check(not re.search(r'<(script|link|img)[^>]+(src|href)="https?:', page), "page: self-contained")
        emb = re.search(r'<script type="application/json" id="test-results">(.*?)</script>', page, re.S).group(1)
        self.check(json.loads(emb.replace("<\\/", "</"))["inputsFingerprint"] == d["inputsFingerprint"],
                   "page: the document is embedded")
        for anchor in ("sec-l0", "sec-build", "sec-lc", "sec-l4", "sec-gaps", "sec-measures", "sec-evidence",
                       "sec-questions", "tab-overview", "tab-l0", "tab-build", "tab-lc", "tab-l4", "tab-questions"):
            self.check(f'id="{anchor}"' in page, f"page: anchor {anchor}")
        self.check("Needs attention" in page and "Next move" in page and 'id="expand-all"' in page
                   and "nav-current" in page and "current.classList.remove('nav-current')" in page,
                   "page: attention, next move, controls, navigation marks only the current target")
        self.check("triage not implemented" not in page.lower(), "page: no 'triage not implemented' text")
        low = page.lower()
        self.check("ba-artifacts" not in low and "business documentation" not in low and "git" not in
                   re.sub(r"digit|legit", "", low.split("<script>")[0]), "page: no BA block, no git")

    def t_cli(self):
        code, d = self.run("status", "mu/s2", "--json")
        self.check(code == 0 and d.get("status") == "not_built", f"cli: status before build {d}")
        before = self.tree()
        code, d = self.run("build", "mu/s2", "--json")
        self.check(code == 0 and d.get("status") == "built" and d.get("html") == "mu/s2/report/test-results.html"
                   and re.fullmatch(r"mu/s2/report/history/test-results-s2-\d{4}-\d\d-\d\d-\d{4}\.html",
                                    d.get("history") or "") and "_lines" not in d, f"cli: build {d}")
        self.check((self.ws / "mu/s2/report/test-results.html").is_file()
                   and (self.ws / d.get("history", "x")).is_file(), "cli: page and dated copy written")
        first = self.ws / d.get("history", "x")
        first_bytes = first.read_bytes() if first.is_file() else b""
        code, d2 = self.run("build", "mu/s2")
        second = d2.get("history") or ""
        self.check(code == 0 and second != d.get("history") and first.read_bytes() == first_bytes
                   and re.fullmatch(r"mu/s2/report/history/test-results-s2-\d{4}-\d\d-\d\d-\d{4}(-\d+)?\.html", second)
                   and (self.ws / second).is_file(), f"cli: second build keeps the first dated copy {second}")
        import importlib.util
        spec = importlib.util.spec_from_file_location("mu_report_cli", RUNNER)
        cli = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cli)
        hist = self.ws / ".hist"
        hist.mkdir(exist_ok=True)
        name = "test-results-x-2026-01-02-0304.html"
        self.check(cli.history_path(hist, name).name == name, "history: free name used as is")
        (hist / name).write_text("a", encoding="utf-8")
        self.check(cli.history_path(hist, name).name == "test-results-x-2026-01-02-0304-2.html",
                   "history: taken name -> -2")
        (hist / "test-results-x-2026-01-02-0304-2.html").write_text("b", encoding="utf-8")
        self.check(cli.history_path(hist, name).name == "test-results-x-2026-01-02-0304-3.html"
                   and (hist / name).read_text(encoding="utf-8") == "a", "history: -2 taken -> -3, none overwritten")
        shutil.rmtree(hist)
        for name in ("s0", "s1", "s3", "s4", "s5", "s6"):
            code, r = self.run("build", f"mu/{name}")
            self.check(code == 0 and r.get("status") == "built", f"cli: build stage {name} {r}")
        after = self.tree()
        changed = sorted(k for k in set(before) | set(after) if before.get(k) != after.get(k))
        self.check(not changed, f"cli: nothing written outside mu/<MU>/report/ {changed[:10]}")
        code, d = self.run("status", "mu/s2")
        self.check(d.get("status") == "current", f"cli: status current {d}")
        rpt = self.ws / "mu/s2/implement/report.md"
        rpt.write_text(rpt.read_text(encoding="utf-8") + "\nmore\n", encoding="utf-8")
        code, d = self.run("status", "mu/s2")
        self.check(d.get("status") == "changed" and d.get("modified") == ["mu/s2/implement/report.md"]
                   and d.get("product") is None and d.get("next") == slash_command("mu-report") + " mu/s2",
                   f"cli: status changed with the modified file {d}")
        self.w("solution-s2/demo-mod/src/main/java/x/B.java", "class B {}\n")
        self.w("solution-s2/demo-mod/target/classes/B.class", "x")
        code, d = self.run("status", "mu/s2")
        self.check(d.get("status") == "changed" and (d.get("product") or {}).get("before")
                   and d["product"]["before"] != d["product"]["now"], f"cli: a product change is seen {d}")
        code, d = self.run("build", "mu/s2", "--confirm")
        self.check(code == 2 and d.get("status") == "needs-input" and d.get("reason") == "database_unreachable"
                   and (d.get("database") or {}).get("port") == 1 and "testenv" not in json.dumps(d)
                   and not (self.ws / "validation/target/checks").exists(),
                   f"cli: --confirm with the test database down: exit 2 database_unreachable, nothing built {d}")
        code, d = self.run("build", "mu/s2", "--rebuild")
        self.check(code == 1 and d.get("status") == "failed", f"cli: --rebuild needs --confirm {d}")
        code, d = self.run("build", "mu/none")
        self.check(code == 1 and "mu.yaml not found" in d.get("error", ""), f"cli: missing MU fails {d}")
        code, d = self.run("frobnicate")
        self.check(code == 1 and d.get("error", "").startswith("usage:"), f"cli: usage error as JSON {d}")

    FAKE_MVN = """import json, os, sys
from pathlib import Path
cwd = Path.cwd()
calls = Path(os.environ["MU_REPORT_SELFTEST_CALLS"])
calls.write_text(calls.read_text() + "x" if calls.is_file() else "x")
Path(os.environ["MU_REPORT_SELFTEST_ENV"]).write_text(json.dumps({k: os.environ.get(k) for k in
    ("DB_URL", "DB_USERNAME", "DB_PASSWORD", "APP_SCHEMA", "DB_SCHEMA")}))
args = sys.argv[1:]
assert any(a.startswith("-Dmaven.repo.local=") for a in args) and "verify" in args, args
for cls, runner, n, f in (("x.ServiceTest", "surefire", 3, 1), ("x.ApiIT", "failsafe", 2, 0)):
    d = cwd / "demo-mod" / "target" / (runner + "-reports")
    d.mkdir(parents=True, exist_ok=True)
    cases = "".join('<testcase classname="%s" name="t%d"/>' % (cls, i) for i in range(n - f))
    cases += "".join('<testcase classname="%s" name="f%d"><failure message="boom" type="java.lang.AssertionError">'
                     'java.lang.AssertionError: boom at x.S.t(S.java:1)</failure></testcase>' % (cls, i)
                     for i in range(f))
    (d / ("TEST-" + cls + ".xml")).write_text('<testsuite name="%s" tests="%d" failures="%d" errors="0" skipped="0" '
                                             'time="0.1">%s</testsuite>' % (cls, n, f, cases))
site = cwd / "demo-mod" / "target" / "site" / "jacoco"
site.mkdir(parents=True, exist_ok=True)
(site / "jacoco.xml").write_text('<report name="d"><counter type="LINE" missed="20" covered="80"/></report>')
print("[INFO] Reactor Summary:")
print("[INFO] root ............................................. SUCCESS [  0.1 s]")
print("[INFO] demo-mod ......................................... SUCCESS [  0.1 s]")
print("[INFO] other-mod ........................................ SUCCESS [  0.1 s]")
print("[INFO] BUILD SUCCESS")
"""

    def t_confirm(self):
        """--confirm: env mapping, Db2 unreachable, a fake mvn with a fake listening Db2 port, the record reused, the
        installed snapshot as the source, status changed naming a touched product file."""
        import socket
        import threading
        self.stage("s7", 2)
        sol = self.ws / "solution-s7"
        self.w("solution-s7/demo-mod/src/main/resources/application.yml",
               "spring:\n  datasource:\n    url: ${DB_URL}\n    username: ${DB_USERNAME}\n    password: ${DB_PASSWORD}\n"
               "    hikari:\n      schema: ${APP_SCHEMA:DB2INST1}\n")
        self._java(sol / "demo-mod", "ServiceTest", "class ServiceTest { }")
        self._java(sol / "demo-mod", "ApiIT", "@SpringBootTest\nclass ApiIT { }")
        mu = self.mu("s7")
        values, names = suites.database_env(mu, {"host": "h", "port": 5, "database": "D", "user": "u", "password": "p",
                                                 "schema": "S"})
        self.check(values == {"DB_URL": "jdbc:db2://h:5/D", "DB_USERNAME": "u", "DB_PASSWORD": "p", "APP_SCHEMA": "S"}
                   and names["schema"] == "APP_SCHEMA" and names["files"] ==
                   ["solution-s7/demo-mod/src/main/resources/application.yml"],
                   f"confirm: env mapping from application.yml (hikari schema) {values} {names}")
        self.stage("s8", 2)
        v8, n8 = suites.database_env(self.mu("s8"), {"host": "h", "port": 5, "database": "D", "user": "u",
                                                     "schema": "S"})
        self.check(v8 == {"DB_URL": "jdbc:db2://h:5/D", "DB_USERNAME": "u", "DB_PASSWORD": "", "DB_SCHEMA": "S"}
                   and n8["fromConfiguration"] == ["url", "username"], f"confirm: env defaults {v8} {n8}")
        listener = socket.socket()
        listener.bind(("127.0.0.1", 0))
        listener.listen(8)
        port = listener.getsockname()[1]
        stop = threading.Event()

        def serve():
            listener.settimeout(0.2)
            while not stop.is_set():
                try:
                    conn, _ = listener.accept()
                    conn.close()
                except OSError:
                    pass
        threading.Thread(target=serve, daemon=True).start()
        self.w("mu/s7/tools.yaml", TOOLS_YAML.replace("host: localhost", "host: 127.0.0.1")
               .replace("port: 1", f"port: {port}"))
        fake = self.w("_fake/mvn.py", self.FAKE_MVN)
        calls, envf = self.ws / "_fake" / "calls.txt", self.ws / "_fake" / "env.json"
        saved = dict(self.env)
        self.env.update({"MU_REPORT_MVN": json.dumps([sys.executable, "-B", str(fake)]),
                         "MU_REPORT_SELFTEST_CALLS": str(calls), "MU_REPORT_SELFTEST_ENV": str(envf),
                         "MU_REPORT_M2_TAIL": str(self.ws / "_fake" / "m2tail")})
        try:
            before = {k: v for k, v in self.tree().items() if k.startswith("solution-s7/")}
            code, d = self.run("build", "mu/s7", "--confirm")
            rev = (mufiles.identity(self.mu("s7")) or {}).get("revision")
            rec_file = self.ws / "validation" / "target" / "checks" / f"{rev}.json"
            rec = json.loads(rec_file.read_text(encoding="utf-8")) if rec_file.is_file() else {}
            st = d.get("suites") or {}
            self.check(code == 0 and d.get("status") == "built" and d.get("mode") == "confirm"
                       and st.get("source") == "checks" and st.get("reused") is False and st.get("revision") == rev
                       and st.get("L1", {}).get("tests") == 3 and st.get("L1", {}).get("failures") == 1
                       and st.get("L3", {}).get("tests") == 2 and (st.get("lineCoverage") or {}).get("ratio") == 0.8
                       and st.get("copiedFrom") == "solution", f"confirm: built once, counts per level {d}")
            self.check(rec.get("status") == "completed" and rec.get("revision") == rev and rec.get("source") == "checks"
                       and rec.get("levelRule") == suites.LEVEL_RULE and rec.get("copiedFrom", {}).get("source") ==
                       "solution" and rec.get("database", {}).get("port") == port and "testenv" not in
                       rec_file.read_text(encoding="utf-8") and rec.get("database", {}).get("environment", {})
                       .get("schema") == "APP_SCHEMA", f"confirm: the record (main's shape, no password) {rec}")
            seen = json.loads(envf.read_text(encoding="utf-8")) if envf.is_file() else {}
            self.check(seen == {"DB_URL": f"jdbc:db2://127.0.0.1:{port}/TESTDB", "DB_USERNAME": "db2inst1",
                                "DB_PASSWORD": "testenv", "APP_SCHEMA": "DB2INST1", "DB_SCHEMA": None},
                       f"confirm: the build's environment {seen}")
            page = (self.ws / "mu/s7/report/test-results.html").read_text(encoding="utf-8")
            self.check("testenv" not in page and "schema <code>DB2INST1</code>" in page,
                       "confirm: the page names the database and schema, never the password")
            code, d = self.run("build", "mu/s7", "--confirm")
            self.check(code == 0 and (d.get("suites") or {}).get("reused") is True
                       and calls.read_text() == "x", f"confirm: reused for the same hash, no Maven call {d}")
            after = {k: v for k, v in self.tree().items() if k.startswith("solution-s7/")}
            self.check(before == after and not list(sol.rglob("target")), "confirm: the solution is never written")
            code, d = self.run("status", "mu/s7")
            self.check(d.get("status") == "current" and d.get("mode") == "confirm", f"confirm: status current {d}")
            products = self.ws / "validation" / "target" / "product"
            prod = mufiles.identity(self.mu("s7"))
            for name in prod["manifest"]:
                dest = products / rev / name
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(sol / name, dest)
            self.w(f"validation/target/product/{rev}/demo-mod/target/x.jar", "jar")
            self.w("validation/target/product/installed.json", json.dumps({"revision": rev, "hash": prod["hash"]}))
            code, d = self.run("build", "mu/s7", "--confirm", "--rebuild")
            self.check(code == 0 and (d.get("suites") or {}).get("copiedFrom") == "snapshot"
                       and calls.read_text() == "xx" and not (self.ws / f"validation/target/checks/{rev}/demo-mod/"
                                                                         f"target/x.jar").exists(),
                       f"confirm: --rebuild runs again, copied from the installed snapshot of the same hash {d}")
            src = sol / "demo-mod" / "src" / "main" / "java" / "x" / "A.java"
            src.write_text(src.read_text(encoding="utf-8") + "// touched\n", encoding="utf-8")
            code, d = self.run("status", "mu/s7")
            touched = "solution-s7/demo-mod/src/main/java/x/A.java"
            self.check(d.get("status") == "changed" and touched in (d.get("modified") or [])
                       and (d.get("product") or {}).get("files", {}).get("modified") == [touched]
                       and d["product"]["before"] == rev and d.get("next", "").endswith("--confirm"),
                       f"confirm: status changed names the touched product file {d}")
            self.w("mu/s7/tools.yaml", TOOLS_YAML)
            code, d = self.run("build", "mu/s7", "--confirm")
            self.check(code == 2 and d.get("reason") == "database_unreachable" and calls.read_text() == "xx",
                       f"confirm: a new hash with the database down: exit 2, no Maven call {d}")
            self.w("mu/s7/tools.yaml", "secrets: ~/.config/none-mu-report-selftest/secrets.env\n")
            code, d = self.run("build", "mu/s7", "--confirm")
            self.check(code == 2 and d.get("reason") == "input_required", f"confirm: no test database: exit 2 {d}")
        finally:
            self.env = saved
            stop.set()
            listener.close()

    def t_hash(self):
        tree = self.ws / "_hash"
        for rel, text in (("pom.xml", "<p/>"), ("a/src/X.java", "x"), ("a/target/c.class", "t"), (".git/HEAD", "g"),
                          (".claude/s.md", "c"), ("node_modules/n.js", "n"), ("a/.idea/i.xml", "i"),
                          ("b/ü file.txt", "u"), ("b/.vscode/v.json", "v"), ("b/c/d/e.txt", "e")):
            p = tree / rel
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(text.encode("utf-8"))
        ours = mufiles.hash_of(mufiles.manifest_of(tree))
        theirs = self._validate_hash(tree)
        self.check(ours == theirs and len(mufiles.manifest_of(tree)) == 4,
                   f"hash: same as mu-validate's snapshot on a synthetic tree ({ours[:16]} / {str(theirs)[:16]})")
        shutil.rmtree(tree)
        if REAL_SOLUTION.is_dir():
            ours = mufiles.hash_of(mufiles.manifest_of(REAL_SOLUTION))
            theirs = self._validate_hash(REAL_SOLUTION)
            self.check(ours == theirs, f"hash: same as mu-validate's snapshot on the workspace solution/ ({ours})")
            self.real_hash = ours

    @staticmethod
    def _validate_hash(tree: Path) -> str | None:
        code = ("import sys; sys.path.insert(0, sys.argv[1]); from pathlib import Path; "
                "from steps.snapshot import manifest_of, hash_of; print(hash_of(manifest_of(Path(sys.argv[2]))))")
        p = subprocess.run([sys.executable, "-B", "-c", code, str(SNAPSHOT_SCRIPTS), str(tree)], capture_output=True,
                           timeout=300)
        out = p.stdout.decode("utf-8", errors="replace").strip().splitlines()
        return out[-1] if p.returncode == 0 and out else None

    def main(self) -> int:
        self.real_hash = None
        try:
            for t in (self.t_parsers, self.t_stages, self.t_module_never_mu_name, self.t_tools, self.t_level_rule,
                      self.t_suites, self.t_gates, self.t_page, self.t_lc, self.t_l4, self.t_questions, self.t_numbers,
                      self.t_cli, self.t_confirm, self.t_hash):
                t()
        finally:
            if not self.keep:
                shutil.rmtree(self.ws, ignore_errors=True)
        doc = {"status": "ok" if not self.fails else "failed", "checks": self.n, "failed": self.fails,
               "solutionHash": self.real_hash, "solutionHashIsP510Of20261106": self.real_hash == P510_HASH
               if self.real_hash else None, **({"workspace": str(self.ws)} if self.keep else {})}
        print(json.dumps(doc))
        return 0 if not self.fails else 1


if __name__ == "__main__":
    sys.exit(T("--keep" in sys.argv).main())
