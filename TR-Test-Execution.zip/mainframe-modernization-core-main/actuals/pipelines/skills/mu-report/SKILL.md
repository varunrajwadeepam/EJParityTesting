---
name: mu-report
description: Test results report of one Migration Unit - every level of the test pyramid (L0 design gates, L1-L3 the product's suites, LC legacy characterisation, L4 parity) as one self-contained HTML page, built at any point of the migration.
argument-hint: "mu/<MU> [--confirm] [--rebuild]"
disable-model-invocation: true
---

# Report the test results of one Migration Unit

A command, not a stage: runs at any point of the migration and changes nothing the other commands
produced. Per level: results, or the state (`not_reached`, `not_produced`, `not_run`, ...) with the
owner and the next command. Results, never verdicts; every number is counted by the script.

`<mu>` is the argument, normally `mu/<MU>`; layout in `${CLAUDE_PLUGIN_ROOT}/templates/workspace/CLAUDE.md`.
Run from the workspace root. `S` below is `python -B ${CLAUDE_PLUGIN_ROOT}/skills/mu-report/scripts/mu_report.py`.
`$S build <mu> [--confirm] [--rebuild] --json` and `$S status <mu> --json` print one JSON object and
exit 0 done, 2 input or decision needed, 1 failed.

## Inputs, read only

- `<mu>/mu.yaml`, `<mu>/tools.yaml` (via `${CLAUDE_PLUGIN_ROOT}/scripts/tools_config.py`: solution, `test-db2`
  else `db2`; a missing section is not an error).
- L0: `<mu>/design/` (`report.md`, `design-open-questions.md`, `rules.md`), `<mu>/implement/`
  (`report.md`, `implement-open-questions.md`, `traceability.md`); `check_rule_coverage.py` and
  `validate_traceability.py` re-run when present; `<mu>/unit/<E>/cases.json` (the design's recordings).
- L1-L3: the checks record `validation/target/checks/<hash16>.json` of the solution's content hash
  and its reports, else `solution/**/target/{surefire,failsafe}-reports/` and `target/site/jacoco/`
  of the last build, else `not_run`.
- LC: `<mu>/tests/` (`tests-state.json`, `tests-report.md`, `tests-open-questions.md`,
  `package/<E>/<E>-tests.json`, `package/<E>/traceability.md`, `notes/<E>-arms.md`).
- L4: `<mu>/validation/` (`validation-state.json` incl. `solution.facts.productModule`,
  `runs/<run-id>/summary.json`, `runs/<run-id>/run-1/e2e-replay.json`, `failures.md`,
  `validation-open-questions.md`).

Never read: COBOL, `previous/`, the `.tmp/` folders of other commands.

## Outputs

- `<mu>/report/test-results.html` - the page, the report document embedded.
- `<mu>/report/history/test-results-<MU>-<YYYY-MM-DD>-<hhmm>.html` (local time) per build; when the
  name exists `-2`, `-3`, ... is added; a dated copy is never overwritten.
- Scratch `<mu>/report/.tmp/`.
- With `--confirm` only: the copy `validation/target/checks/<hash16>/`, its record `<hash16>.json`,
  log `<hash16>.log`, the private repository `validation/target/m2`.

Nothing else is written; never under `solution/`.

## Order of work

1. `$S build <mu> --json`. Add `--confirm` only when the user asks for it: it builds and tests a
   copy of the product by content hash against the test database (L1-L3); the record is reused for
   the same hash. Add `--rebuild` only when the user asks to run the same hash again.
2. Exit 2: say what `error` asks for and stop. `reason` `database_unreachable`: the test database
   does not answer - say so, do not start it. `input_required`: `tools.yaml` names no test
   database. `no_product`: there is no product to build. Exit 1: report `error` as it is and stop.
3. Exit 0: print the script's summary in its words - the page path (`html`, `history`), `overall`
   and `sentence`, each line of `layers`, the `attention` items with their owner, `suites` when
   present (source, revision, reused, database), and `next`.

`$S status <mu> --json` (on "is the report current?"): print `status` - `current`, `changed` (with
`added`, `removed`, `modified`, `product`) or `not_built` - and `next`. Writes nothing.

## Rules

- Print only what the script printed; never count, estimate or re-derive a number; add no status,
  verdict or class of your own.
- Do not edit the page or anything the script reads; a defect in an input is reported, not fixed.
- Do not start or stop a database, Docker, the parity tester or the product; do not clean the test
  database.
- A level with no evidence is `none` with its reason, owner and next command - never `pass`.
- Write only into `<mu>/report/` and, with `--confirm`, `validation/target/`.

## Next move

The page and `next` name the command: `/pipelines:mu-design`, `/pipelines:mu-implement`, `/pipelines:mu-build-tests`,
`/pipelines:mu-validate` (with `<mu>`), or `/pipelines:mu-report <mu> --confirm` when L1-L3 have not run. Say it as the
next move; never run it yourself. The user only says "resume" or runs `/pipelines:mu-report` again after the
other command or the fix.

Self-test: `python -B ${CLAUDE_PLUGIN_ROOT}/skills/mu-report/scripts/selftest.py`.
