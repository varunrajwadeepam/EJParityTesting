#!/usr/bin/env python3
"""Check `rules.md` against the paragraph index: did every paragraph produce a rule?

`mu-design` says the rule inventory is the specification and the only traceability the
target has, and that every extracted-logic paragraph ends either in a rule's `From`
cell or in "Paragraphs that produced no rule". This is that check, as a set comparison
over the two files rather than a reading of them - and it is the design-phase half of
traceability. The architecture skill's `validate_traceability.py` is the other half,
over the code, and takes the same index.

Target-agnostic on purpose: a paragraph producing a rule is a property of the migration,
not of the stack it is migrated to, so this lives with the command rather than in an
architecture skill.

  UNCITED           a business paragraph in no `From` cell and in no coverage row. The
                    check that matters: the paragraph had statements or reported an
                    outcome and the design says nothing about it, which is the shape of
                    a behaviour that is about to be lost.
  NO_REASON         a coverage row with no reason in its last cell. Exempting a
                    paragraph is a judgement and has to be a visible one.
  STALE_RANGE       a cited range that is not the range the index gives. The range is
                    the one part of a citation nobody can recall, and a wrong one sends
                    the next reader - or the implementer writing the Javadoc - to the
                    wrong place.
  MISSING_RANGE     a paragraph cited with no range at all.
  UNKNOWN_PARAGRAPH a citation naming a paragraph in no extracted-logic document.
  WRONG_PROGRAM     the paragraph exists, under a different member than the one cited.
  NO_PROGRAM        a paragraph cited with no member named before it in the cell.
  UNKNOWN_PROGRAM   a member cited that the index does not hold and `stubs.md` does not
                    register as a neighbor or an absent module.
  BOTH              a paragraph that is both cited by a rule and listed as producing no
                    rule. The two lists disagree; one of them is wrong.

Exits non-zero on any finding. The citation form it reads is the one the `rules.md`
template specifies:

    | 14 | <the rule> | `A7549229` PARA-1956030950 (2010-2043) | <target home> |

and the coverage rows it reads are the table under "Paragraphs that produced no rule":

    | `A7549229` | `MAIN-1955993749` | 1650-1673 | cursor family, one query per method |

A rule row is recognised by a number in its first cell and a coverage row by a member
id, so neither depends on where the headings are.

    python ${CLAUDE_PLUGIN_ROOT}/scripts/check_rule_coverage.py \
        --index <mu>/extracted-logic/paragraph-index.json --rules <mu>/design/rules.md \
        --external <mu>/design/stubs.md

`--coverage-out` writes the coverage table for every business paragraph no rule cites,
carrying over whatever reasons `rules.md` already gives, which is the list to paste back
and fill in. `--allow-out` writes the same exemptions in the format
`validate_traceability.py --allow` reads, so the design's judgement is reused by
implement instead of being made twice.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path

# A `From` cell names the member in backticks and then its paragraphs, so several
# paragraphs of one member can share the one member name - the form the template
# shows. A member standing alone in a cell sets the member for what follows it.
MEMBER = re.compile(r"`(?P<program>[A-Z][A-Z0-9#@$]{2,10})`")
# A paragraph name as CA Gen generates it, with the line range that should follow it.
# The suffix takes a run of dashes, not one: `PARA-1955996229---RGVC` is a real name,
# and a single-dash suffix cut it short at the model id and then reported the
# correctly-cited full name as a paragraph in no document.
CITE = re.compile(r"(?P<name>\b[A-Z][A-Z0-9]*(?:-[A-Z][A-Z0-9]*)*-\d{4,}(?:-+[A-Z0-9]+)*)"
                  r"`?(?:\s*\((?P<first>\d+)(?:\s*-\s*(?P<last>\d+))?\))?")
RULE_NUMBER = re.compile(r"\A\**(\d+)\**\Z")
SEPARATOR = re.compile(r"\A[\s|:-]+\Z")
DIGITS = re.compile(r"\d+")
# A rule cell names runtime modules too - `TIRFDDUR`, `TIRFNUM` - and they are the
# shape of a member id. They are never provenance: a TIR module has no
# extracted-logic document by design (`stubs.md`: "TIR runtime modules are not
# listed"), and reading one as the member of the paragraphs after it attributes real
# paragraphs to a module that cannot hold them.
RUNTIME_MODULE = re.compile(r"\ATIR[A-Z0-9]*\Z")
# A `stubs.md` row: the member is the first cell, `neighbor` or `absent` the second.
STUB_ROW = re.compile(r"^\|\s*`?(?P<program>[A-Z][A-Z0-9#@$]{2,10})`?\s*\|"
                      r"\s*`?(?P<kind>neighbor|absent)`?\s*\|")


def cells(line: str) -> list[str] | None:
    """The cells of one Markdown table row, or `None` if the line is not one."""
    stripped = line.strip()
    if not stripped.startswith("|") or SEPARATOR.match(stripped):
        return None
    return [cell.strip() for cell in stripped.strip("|").split("|")]


def paragraph_shape(index: dict) -> set[int]:
    """The digit-run lengths of real paragraph names, read off the index.

    A rule cell is prose and holds tokens that look like a paragraph and are not. A
    view field carries its view number - `RV-LOOKUP-CD-ID-0151`, `EFF-DT-0034` - and
    matches any pattern loose enough to accept a paragraph suffix; 12 of them are named
    in the measured tree's rule inventory and every one was reported as a citation of a
    paragraph in no document until this was derived instead of guessed. Every real
    paragraph name carries the 10-digit CA Gen model id.
    """
    runs = {len(m) for entry in index.values() for para in entry["paragraphs"]
            for m in DIGITS.findall(para["name"])}
    return runs or {6, 7, 8, 9, 10}


def parse_citations(text: str, para_runs: set[int]) -> list[dict]:
    """Every paragraph citation in one cell, each with the member it is under.

    The member carries forward across the paragraphs after it, so
    ``` `A7549229` PARA-1955993943 (2572-2754), PARA-1956030950 (2010-2043) ``` is two
    citations of one member. A paragraph met before any member is returned with
    `program=None` rather than attached to a guess.
    """
    marks: list[tuple[int, str, object]] = []
    for m in MEMBER.finditer(text):
        if not RUNTIME_MODULE.match(m.group("program")):
            marks.append((m.start(), "program", m.group("program")))
    for m in CITE.finditer(text):
        # A view field carries a short view number; a paragraph carries the model id.
        if not any(len(run) in para_runs for run in DIGITS.findall(m.group("name"))):
            continue
        span = None
        if m.group("first"):
            first = int(m.group("first"))
            span = [first, int(m.group("last")) if m.group("last") else first]
        marks.append((m.start(), "paragraph", (m.group("name"), span)))

    found: list[dict] = []
    current: str | None = None
    for _, kind, value in sorted(marks, key=lambda mark: mark[0]):
        if kind == "program":
            # A member in backticks is never also a paragraph: a paragraph name
            # carries the model id and a member id has no `-`.
            current = value  # type: ignore[assignment]
            continue
        name, span = value  # type: ignore[misc]
        found.append({"program": current, "paragraph": name, "range": span})
    return found


def read_rules(path: Path, para_runs: set[int]) -> tuple[list[dict], list[dict]]:
    """The rule citations and the coverage rows of a `rules.md`.

    A rule row has a number in its first cell; a coverage row has a member id there.
    Any other table - a mapping, an outcome list - has neither and is skipped, which is
    what keeps this from reading a table it was not meant to.
    """
    citations: list[dict] = []
    coverage: list[dict] = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        row = cells(line)
        if not row or len(row) < 2:
            continue
        if RULE_NUMBER.match(row[0]):
            for cell in row[1:]:
                for cite in parse_citations(cell, para_runs):
                    citations.append(dict(cite, at=f"{path.as_posix()}:{number}",
                                          rule=RULE_NUMBER.match(row[0]).group(1)))
            continue
        head = MEMBER.fullmatch(row[0]) or re.fullmatch(
            r"[A-Z][A-Z0-9#@$]{2,10}", row[0])
        if not head or RUNTIME_MODULE.match(row[0].strip("` ")):
            continue
        program = head.group(1) if head.re is MEMBER else row[0]
        for cite in parse_citations(row[1], para_runs):
            span = cite["range"]
            if span is None and len(row) > 2:
                if (m := re.fullmatch(r"(\d+)(?:\s*-\s*(\d+))?", row[2].strip("` "))):
                    span = [int(m.group(1)),
                            int(m.group(2) or m.group(1))]
            coverage.append({"program": cite["program"] or program,
                             "paragraph": cite["paragraph"], "range": span,
                             "reason": row[-1] if len(row) > 3 else "",
                             "at": f"{path.as_posix()}:{number}"})
    return citations, coverage


def load_external(path: Path | None) -> dict[str, str]:
    """The non-internal members, from `stubs.md`.

    A neighbor or an absent module is not this MU's to document, so a rule that cites
    one for what this MU does with its result is citing a member with no extracted-logic
    document by design, not by mistake.
    """
    if not path or not path.exists():
        return {}
    return {m.group("program"): m.group("kind")
            for raw in path.read_text(encoding="utf-8").splitlines()
            if (m := STUB_ROW.match(raw.strip()))}


def resolve(findings: list[dict], cite: dict, known: dict, programs: set[str],
            external: dict[str, str]) -> tuple[str, str] | None:
    """The index key a citation really names, recording what was wrong with it.

    Returns `None` when the citation does not resolve to a paragraph in the index, so
    the caller neither counts it as coverage nor checks its range.
    """
    name, program = cite["paragraph"], cite["program"]
    if program is not None and program not in programs:
        if program in external:
            return None
        findings.append(dict(kind="UNKNOWN_PROGRAM", at=cite["at"], program=program,
                             paragraph=name,
                             detail=f"no extracted-logic document, and stubs.md does "
                                    f"not register it as a neighbor or absent"))
        return None
    if program is not None and (program, name) in known:
        return program, name
    elsewhere = sorted(p for (p, q) in known if q == name)
    if not elsewhere:
        findings.append(dict(kind="UNKNOWN_PARAGRAPH", at=cite["at"], program=program,
                             paragraph=name, detail="in no extracted-logic document"))
        return None
    findings.append(dict(kind="WRONG_PROGRAM" if program else "NO_PROGRAM",
                         at=cite["at"], program=program, paragraph=name,
                         detail="found under " + ", ".join(elsewhere)))
    return elsewhere[0], name


def main() -> int:
    parser = argparse.ArgumentParser(
        description=__doc__.splitlines()[0],
        formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    parser.add_argument("--index", type=Path, required=True,
                        help="paragraph-index.json written by extract_logic.py --index")
    parser.add_argument("--rules", type=Path, required=True,
                        help="the MU's design/rules.md")
    parser.add_argument("--external", type=Path,
                        help="the MU's design/stubs.md: members registered there are "
                             "neighbors or absent modules, not missing documents")
    parser.add_argument("--coverage-out", type=Path,
                        help="write the 'Paragraphs that produced no rule' table for "
                             "everything no rule cites, keeping the reasons already given")
    parser.add_argument("--allow-out", type=Path,
                        help="write the exemptions in validate_traceability --allow "
                             "format, so implement reuses the design's judgement")
    parser.add_argument("--warn-only", action="store_true",
                        help="report and exit 0; for a design part-way through")
    args = parser.parse_args()

    index = json.loads(args.index.read_text(encoding="utf-8"))["programs"]
    programs = set(index)
    known = {(p, para["name"]): para
             for p, entry in index.items() for para in entry["paragraphs"]}
    external = load_external(args.external)
    citations, coverage = read_rules(args.rules, paragraph_shape(index))

    findings: list[dict] = []
    cited: dict[tuple[str, str], list[str]] = {}
    for cite in citations:
        key = resolve(findings, cite, known, programs, external)
        if key is None:
            continue
        cited.setdefault(key, []).append(cite["at"])
        want = known[key]["lines"]
        if cite["range"] is None:
            findings.append(dict(kind="MISSING_RANGE", at=cite["at"], program=key[0],
                                 paragraph=key[1],
                                 detail=f"index says {want[0]}-{want[1]}"))
        elif want and cite["range"] != want:
            findings.append(dict(kind="STALE_RANGE", at=cite["at"], program=key[0],
                                 paragraph=key[1],
                                 detail=f"cited {cite['range'][0]}-{cite['range'][1]}, "
                                        f"index says {want[0]}-{want[1]}"))

    exempt: dict[tuple[str, str], str] = {}
    for row in coverage:
        key = resolve(findings, row, known, programs, external)
        if key is None:
            continue
        reason = row["reason"].strip().strip("-— ")
        if not reason:
            findings.append(dict(kind="NO_REASON", at=row["at"], program=key[0],
                                 paragraph=key[1],
                                 detail="listed as producing no rule with no reason"))
            continue
        if key in cited:
            findings.append(dict(kind="BOTH", at=row["at"], program=key[0],
                                 paragraph=key[1],
                                 detail="cited by a rule and listed as producing none, "
                                        f"cited at {', '.join(cited[key])}"))
            continue
        exempt[key] = reason

    business = {key: para for key, para in known.items()
                if para["kind"] == "business"}
    uncited = [key for key in business if key not in cited and key not in exempt]
    for key in sorted(uncited):
        para = business[key]
        findings.append(dict(kind="UNCITED", at="-", program=key[0], paragraph=key[1],
                             detail=f"lines {para['lines'][0]}-{para['lines'][1]}, "
                                    f"{para['statements']} statements"))

    counts = Counter(f["kind"] for f in findings)
    covered = len(business) - len(uncited)
    print(f"{len(citations)} From citations over {len(cited)} paragraphs, "
          f"{len(exempt)} exempt; {len(known)} paragraphs, {len(business)} business, "
          f"{covered} with a rule or a reason "
          f"({covered * 100 // max(len(business), 1)}%)")
    for kind in ("UNCITED", "NO_REASON", "BOTH", "MISSING_RANGE", "STALE_RANGE",
                 "UNKNOWN_PARAGRAPH", "WRONG_PROGRAM", "NO_PROGRAM",
                 "UNKNOWN_PROGRAM"):
        if counts[kind]:
            print(f"  {kind:18s} {counts[kind]}")

    order = {k: i for i, k in enumerate(
        ("STALE_RANGE", "MISSING_RANGE", "BOTH", "NO_REASON", "WRONG_PROGRAM",
         "NO_PROGRAM", "UNKNOWN_PARAGRAPH", "UNKNOWN_PROGRAM", "UNCITED"))}
    findings.sort(key=lambda f: (order.get(f["kind"], 9), f["program"] or "",
                                 f["paragraph"]))
    for f in findings:
        print(f"{f['kind']}: {f['program'] or '(no member cited)'} {f['paragraph']}"
              f"  {f['detail']}" + (f"  at {f['at']}" if f["at"] != "-" else ""))

    if args.coverage_out:
        rows = sorted(set(uncited) | set(exempt))
        out = ["### Paragraphs that produced no rule", "",
               "Every business paragraph of `extracted-logic/` that no rule cites, with "
               "one clause saying why it produced none. Generated by "
               "`check_rule_coverage.py --coverage-out`; a row with no reason is a "
               "finding, not an omission.", "",
               "| Member | Paragraph | Lines | Why no rule |", "|---|---|---|---|"]
        for key in rows:
            para = known[key]
            span = (f"{para['lines'][0]}-{para['lines'][1]}" if para["lines"] else "—")
            out.append(f"| `{key[0]}` | `{key[1]}` | {span} | "
                       f"{exempt.get(key, '')} |")
        args.coverage_out.parent.mkdir(parents=True, exist_ok=True)
        args.coverage_out.write_text("\n".join(out) + "\n", encoding="utf-8")
        print(f"wrote {args.coverage_out}", file=sys.stderr)

    if args.allow_out:
        out = ["# Paragraphs the design decided need no citation, from rules.md",
               "# \"Paragraphs that produced no rule\". Regenerated by",
               "# check_rule_coverage.py --allow-out; do not edit here."]
        out += [f"{program} {paragraph} {reason}"
                for (program, paragraph), reason in sorted(exempt.items())]
        args.allow_out.parent.mkdir(parents=True, exist_ok=True)
        args.allow_out.write_text("\n".join(out) + "\n", encoding="utf-8")
        print(f"wrote {args.allow_out}", file=sys.stderr)

    return 1 if findings and not args.warn_only else 0


if __name__ == "__main__":
    raise SystemExit(main())
