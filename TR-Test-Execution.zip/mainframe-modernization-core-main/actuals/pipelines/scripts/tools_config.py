"""Reads one tool's section from <mu>/tools.yaml, with secrets and {mu} resolved.

    python tools_config.py <mu-folder> <tool>             whole section as JSON
    python tools_config.py <mu-folder> <tool> <key.path>  one value, e.g. auth.method
    python tools_config.py <mu-folder> mu <key.path>      a value from mu.yaml, e.g. portfolio_id

${NAME} is taken from the environment first, then from the file named by the
top-level `secrets:` key (NAME=value lines). An unresolved ${NAME} is an error.
"""
import json
import os
import re
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    sys.exit(f'tools_config: PyYAML is missing; run: {Path(sys.executable).name} -m pip install pyyaml')

VAR = re.compile(r'\$\{(\w+)\}')


def load_secrets(path):
    values = {}
    if path and Path(path).expanduser().is_file():
        for line in Path(path).expanduser().read_text(encoding='utf-8').splitlines():
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                k, v = line.split('=', 1)
                values[k.strip()] = v.strip()
    return values


def resolve(node, mu, secrets):
    if isinstance(node, dict):
        return {k: resolve(v, mu, secrets) for k, v in node.items()}
    if isinstance(node, list):
        return [resolve(v, mu, secrets) for v in node]
    if isinstance(node, str):
        def var(m):
            name = m.group(1)
            if name in os.environ:
                return os.environ[name]
            if name in secrets:
                return secrets[name]
            sys.exit(f'tools_config: ${{{name}}} is not set (environment or secrets file)')
        return VAR.sub(var, node.replace('{mu}', mu))
    return node


def tool(mu_folder, name, key_path=None):
    """Returns the section (or one value in it), resolving only what is returned."""
    mu = Path(mu_folder).resolve()
    if name == 'mu':                            # the manifest, not a tool
        cfg = {'mu': yaml.safe_load((mu / 'mu.yaml').read_text(encoding='utf-8')) or {}}
    else:
        cfg = yaml.safe_load((mu / 'tools.yaml').read_text(encoding='utf-8')) or {}
    if name not in cfg:
        sys.exit(f'tools_config: no section "{name}" in {mu / "tools.yaml"}')
    section = dict(cfg[name])
    if 'home' in section:                       # relative to tools.yaml
        section['home'] = (mu / section['home']).resolve().as_posix()
    value = section
    for key in (key_path.split('.') if key_path else []):
        if not isinstance(value, dict) or key not in value:
            sys.exit(f'tools_config: no key "{key_path}" in section "{name}"')
        value = value[key]
    return resolve(value, mu.as_posix(), load_secrets(cfg.get('secrets')))


if __name__ == '__main__':
    if len(sys.argv) not in (3, 4):
        sys.exit(__doc__)
    value = tool(*sys.argv[1:])
    print(value if isinstance(value, str) else json.dumps(value, indent=2))
