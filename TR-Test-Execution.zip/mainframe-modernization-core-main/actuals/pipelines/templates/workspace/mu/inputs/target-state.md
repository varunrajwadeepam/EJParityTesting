# Target stack

## Platform

- <Java, framework and build tool versions>
- <database and driver; how the connection and schema are configured>
- <test libraries>

## Fixed values

Every required stack fact of the architecture skill (for `target-java-3tier`: Java package
root, module layout, port and base path, business time zone, security, whether the
database may be written). A missing fact becomes an open question with an assumed value.

| Fact | Value | Source |
|---|---|---|
| Java package root | `<root>` | <SME / assumed - confirm> |
| Module layout | <...> | |
| Port | <...> | |
| Base path | <...> | |
| Business time zone | <...> | |
| Security | <...> | |

# SME notes

- <business meaning, naming and known exceptions the code does not show>
