# MU workspace

One Migration Unit (MU) = one work folder. Skills, scripts and templates come from the
`pipelines` plugin (`${CLAUDE_PLUGIN_ROOT}` in the skills); nothing of them is copied here.

```
<workspace>/           workspace root: CLAUDE.md, optional .claude/settings.json (enables the plugin for the team); start Claude Code here
  tools/parity-tester/ the COBOL runner and Db2 (any path; tools.yaml points to it)
  mu/<MU>/             one MU work folder - the command's <mu>; created by /pipelines:mu-init
    mu.yaml              MU manifest, incl. portfolio_id and archetype
    tools.yaml           tool access (URLs, logins by reference); read via the plugin's scripts/tools_config.py (shared by both phases)
    inputs/              target-state.md (# Target stack, # SME notes), deps/*.usage.md,
                         db-schema/ (DDL as reference),
                         cobol/ (provided, or extracted from MFLens; for the runner only)
    unit/
      schema.sql           tables the cases need, created in the runner's Db2
      stubs/               <NAME>.CBL: hand-written run stubs for programs missing from the tree
      <entry>/             run-cobol unit per entry point
        sources/, driver.cbl      built by run-cobol (parity-tester)
        cases.json, fixtures/     cases to run
        .run-cobol/               what the COBOL returned
    extracted-logic/     one <PROGRAM>.md per internal program (none at or behind a mu.yaml boundary), plus paragraph-index.json:
                         registry of every COBOL paragraph, generated in design, used for
                         later code traceability checks. Written by cobol-logic-extractor
                         scripts only; nothing else goes here
    design/              rules.md, dictionary.md, design.md, tests.md,
                         stubs.md, interface.md, design-open-questions.md, report.md,
                         hld.md (for humans; not read by mu-implement)
    implement/           mu-implement: plan.md, implement-open-questions.md, <name>.usage.md, report.md
      .tmp/                implement temp files and own scripts
    tests/               mu-build-tests: plan/, fixtures/, notes/, package/<entry>/ (the test package), previous/,
                         tests-state.json, tests-report.md, tests-open-questions.md
      .tmp/                runs cache, coverage, temp files and own scripts
    validation/          mu-validate: e2e/ (framework assets derived from the package), runs/<run-id>/,
                         failures.md, validation-state.json, validation-report.md, validation-open-questions.md
      .tmp/                analysis.json, failures-draft.md, temp files and own scripts
    report/              mu-report: test-results.html (the test results page), history/ (dated copies
                         test-results-<MU>-<YYYY-MM-DD>-<hhmm>.html, local time)
      .tmp/                gate re-runs, temp files
    .tmp/                temp files and own scripts
  solution/            shared solution codebase (mu.yaml `solution`); mu-implement writes code only here
  tools/e2e-framework/ the replay test framework (elsewhere: tools.yaml `e2e-framework.path`)
  validation/          mu-validate's test solution: Maven reactor beside solution/, one <mu>-e2e module per MU;
                       target/ holds the product snapshots and the private Maven repository
```

Commands: `/pipelines:mu-init mu/<MU>`, `/pipelines:mflens-login mu/<MU>`,
`/pipelines:mu-design mu/<MU>`, `/pipelines:mu-implement mu/<MU>`,
`/pipelines:mu-build-tests mu/<MU>`, `/pipelines:mu-validate mu/<MU>`, `/pipelines:mu-report mu/<MU>`.
