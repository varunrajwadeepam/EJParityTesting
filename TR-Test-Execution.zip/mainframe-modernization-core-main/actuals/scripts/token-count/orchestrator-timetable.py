"""
Build a token-spend timetable (CSV) for a Claude Code orchestrator session.

Segments the orchestrator's JSONL transcript into alternating ACTIVE
(orchestrator reasoning / dispatching) and WAIT (blocked on a subagent
invoked via the `Agent` tool) windows, then sums token usage and estimated
cost per window. Produces the same "facts table" shape used in
orechstrator-timetable.md, with cache-write tokens split into their two
TTL buckets (5-minute and 1-hour ephemeral caches).

Token accounting matches this project's existing chat-stat-*.csv files:
every raw `assistant` entry's `usage` block is summed as-is (no dedup by
message id), which is the convention that reconciles with those files.

Usage:
    python scripts/orchestrator-timetable.py <path-to-orchestrator.jsonl>
    python scripts/orchestrator-timetable.py <path-to-orchestrator.jsonl> --output timetable.csv
    python scripts/orchestrator-timetable.py <path-to-orchestrator.jsonl> --model claude-opus-4-8
    python scripts/orchestrator-timetable.py <path-to-orchestrator.jsonl> --input-price 2.00 --output-price 10.00

Pricing:
    Base input/output price is looked up from --model (or auto-detected
    from the transcript's `message.model` field). Cache prices are derived
    from the standard ratios: cache read = 0.1x input, cache write (5m) =
    1.25x input, cache write (1h) = 2x input. Override the base price with
    --input-price / --output-price if the model isn't in the table below.
"""

import argparse
import csv
import json
import sys
from datetime import datetime, timedelta
from pathlib import Path

# Base (input, output) USD price per million tokens. Cache prices are
# derived from these via the ratios in CACHE_RATIOS below.
PRICING = {
    "claude-fable-5": (10.00, 50.00),
    "claude-mythos-5": (10.00, 50.00),
    "claude-opus-4-8": (5.00, 25.00),
    "claude-opus-4-7": (5.00, 25.00),
    "claude-opus-4-6": (5.00, 25.00),
    "claude-opus-4-5": (5.00, 25.00),
    "claude-sonnet-5": (3.00, 15.00),
    "claude-sonnet-4-6": (3.00, 15.00),
    "claude-sonnet-4-5": (3.00, 15.00),
    "claude-haiku-4-5": (1.00, 5.00),
}
DEFAULT_MODEL = "claude-sonnet-5"

CACHE_RATIOS = {
    "read": 0.1,
    "write_5m": 1.25,
    "write_1h": 2.0,
}

AGENT_TOOL_NAMES = {"Agent"}


def read_jsonl(path):
    entries = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return entries


def parse_ts(ts_str):
    return datetime.fromisoformat(ts_str.replace("Z", "+00:00"))


def collect_assistant_events(entries):
    """Collect unique assistant turns by message ID, accumulating usage across streaming chunks."""
    seen_message_ids = {}  # message_id -> {ts, usage, model}

    for entry in entries:
        if entry.get("type") != "assistant":
            continue
        message = entry.get("message", {})
        usage = message.get("usage")
        ts = entry.get("timestamp")
        if not usage or not ts:
            continue

        msg_id = message.get("id")
        parsed_ts = parse_ts(ts)

        if msg_id:
            # Accumulate usage for the same message_id (streaming chunks)
            if msg_id not in seen_message_ids:
                seen_message_ids[msg_id] = {
                    "ts": parsed_ts,
                    "usage": {
                        "input_tokens": 0,
                        "output_tokens": 0,
                        "cache_read_input_tokens": 0,
                        "cache_creation": {"ephemeral_5m_input_tokens": 0, "ephemeral_1h_input_tokens": 0}
                    },
                    "model": message.get("model")
                }

            # Use earliest timestamp for this message_id
            if parsed_ts < seen_message_ids[msg_id]["ts"]:
                seen_message_ids[msg_id]["ts"] = parsed_ts

            # Accumulate tokens
            accumulated = seen_message_ids[msg_id]["usage"]
            accumulated["input_tokens"] += usage.get("input_tokens", 0)
            accumulated["output_tokens"] += usage.get("output_tokens", 0)
            accumulated["cache_read_input_tokens"] += usage.get("cache_read_input_tokens", 0)
            cache_creation = usage.get("cache_creation") or {}
            accumulated["cache_creation"]["ephemeral_5m_input_tokens"] += cache_creation.get("ephemeral_5m_input_tokens", 0)
            accumulated["cache_creation"]["ephemeral_1h_input_tokens"] += cache_creation.get("ephemeral_1h_input_tokens", 0)
        else:
            # No message ID: treat as separate turn (shouldn't happen often)
            seen_message_ids[f"_no_id_{len(seen_message_ids)}"] = {
                "ts": parsed_ts,
                "usage": usage,
                "model": message.get("model")
            }

    # Convert to list and sort by timestamp
    events = [{"ts": v["ts"], "usage": v["usage"], "model": v["model"]}
              for v in seen_message_ids.values()]
    events.sort(key=lambda e: e["ts"])
    return events


def collect_agent_dispatches(entries, agent_tool_names):
    """Find Agent tool_use calls and their matching tool_result returns.

    Returns a list of dicts sorted by call time: {call_ts, result_ts, label}.
    Duplicate assistant/tool_result entries for the same tool_use id (seen
    in some transcripts) are collapsed by keeping the earliest timestamp.
    """
    calls = {}  # tool_use_id -> {call_ts, label}
    for entry in entries:
        if entry.get("type") != "assistant":
            continue
        message = entry.get("message", {})
        content = message.get("content")
        if not isinstance(content, list):
            continue
        ts = entry.get("timestamp")
        if not ts:
            continue
        ts = parse_ts(ts)
        for block in content:
            if not isinstance(block, dict) or block.get("type") != "tool_use":
                continue
            if block.get("name") not in agent_tool_names:
                continue
            tool_id = block.get("id")
            inp = block.get("input", {}) or {}
            label = inp.get("description") or inp.get("subagent_type") or "Agent call"
            existing = calls.get(tool_id)
            if existing is None or ts < existing["call_ts"]:
                calls[tool_id] = {"call_ts": ts, "label": label}

    results = {}  # tool_use_id -> result_ts
    for entry in entries:
        if entry.get("type") != "user":
            continue
        message = entry.get("message", {})
        content = message.get("content")
        if not isinstance(content, list):
            continue
        ts = entry.get("timestamp")
        if not ts:
            continue
        ts = parse_ts(ts)
        for block in content:
            if not isinstance(block, dict) or block.get("type") != "tool_result":
                continue
            tool_id = block.get("tool_use_id")
            if tool_id not in calls:
                continue
            if tool_id not in results or ts < results[tool_id]:
                results[tool_id] = ts

    dispatches = []
    for tool_id, call in calls.items():
        dispatches.append({
            "call_ts": call["call_ts"],
            "result_ts": results.get(tool_id),
            "label": call["label"],
        })
    dispatches.sort(key=lambda d: d["call_ts"])
    return dispatches


def build_segments(events, dispatches, session_start, session_end):
    """Alternate ACTIVE / WAIT windows: [prev_boundary, call_ts) ACTIVE,
    [call_ts, result_ts) WAIT, repeat, final ACTIVE to session_end."""
    segments = []  # (state, label, start, end)
    boundary = session_start
    prev_label = None
    n = len(dispatches)

    for i, d in enumerate(dispatches):
        call_ts = d["call_ts"]
        result_ts = d["result_ts"] or session_end

        if i == 0:
            active_label = f"Orchestrator: session start -> dispatch ({d['label']})"
        else:
            active_label = f"Orchestrator: validate ({prev_label}) -> dispatch ({d['label']})"
        segments.append(("ACTIVE", active_label, boundary, call_ts))

        wait_label = f"WAIT: {d['label']}"
        segments.append(("WAIT", wait_label, call_ts, result_ts))

        boundary = result_ts
        prev_label = d["label"]

    if n == 0:
        segments.append(("ACTIVE", "Orchestrator: full session (no subagent dispatches found)",
                          boundary, session_end))
    else:
        segments.append(("ACTIVE", f"Orchestrator: finalize (after {prev_label})",
                          boundary, session_end))

    return segments


def sum_usage(events, start, end):
    """Sum usage for events with start <= ts < end."""
    n = 0
    input_tok = out_tok = write_5m = write_1h = read_tok = 0
    for e in events:
        if start <= e["ts"] < end:
            n += 1
            u = e["usage"]
            input_tok += u.get("input_tokens", 0)
            out_tok += u.get("output_tokens", 0)
            read_tok += u.get("cache_read_input_tokens", 0)
            cache_creation = u.get("cache_creation") or {}
            write_5m += cache_creation.get("ephemeral_5m_input_tokens", 0)
            write_1h += cache_creation.get("ephemeral_1h_input_tokens", 0)
    return n, input_tok, out_tok, write_5m, write_1h, read_tok


def detect_model(events):
    for e in events:
        if e.get("model"):
            return e["model"]
    return None


def resolve_prices(model, input_price_override, output_price_override):
    input_price, output_price = PRICING.get(model, PRICING[DEFAULT_MODEL])
    if input_price_override is not None:
        input_price = input_price_override
    if output_price_override is not None:
        output_price = output_price_override
    return {
        "input": input_price,
        "output": output_price,
        "cache_read": input_price * CACHE_RATIOS["read"],
        "cache_write_5m": input_price * CACHE_RATIOS["write_5m"],
        "cache_write_1h": input_price * CACHE_RATIOS["write_1h"],
    }


def segment_cost(input_tok, out_tok, write_5m, write_1h, read_tok, prices):
    return (
        input_tok / 1e6 * prices["input"]
        + out_tok / 1e6 * prices["output"]
        + write_5m / 1e6 * prices["cache_write_5m"]
        + write_1h / 1e6 * prices["cache_write_1h"]
        + read_tok / 1e6 * prices["cache_read"]
    )


def main():
    parser = argparse.ArgumentParser(
        description="Build a token-spend timetable CSV from an orchestrator JSONL transcript"
    )
    parser.add_argument("file", help="Path to the orchestrator .jsonl transcript")
    parser.add_argument("--output", "-o", help="Output CSV path (default: <input>-timetable.csv)")
    parser.add_argument("--model", help=f"Pricing model key, e.g. one of {sorted(PRICING)} "
                                          f"(default: auto-detect from transcript, else {DEFAULT_MODEL})")
    parser.add_argument("--input-price", type=float, default=None,
                         help="Override base input price (USD per MTok)")
    parser.add_argument("--output-price", type=float, default=None,
                         help="Override base output price (USD per MTok)")
    parser.add_argument("--agent-tool-name", action="append", default=None,
                         help="Tool name that dispatches a subagent (repeatable; default: Agent)")
    args = parser.parse_args()

    path = Path(args.file)
    if not path.exists():
        print(f"Error: File not found: {path}", file=sys.stderr)
        sys.exit(1)

    entries = read_jsonl(path)
    if not entries:
        print("No entries found in file.", file=sys.stderr)
        sys.exit(1)

    events = collect_assistant_events(entries)
    if not events:
        print("No assistant usage events found in file.", file=sys.stderr)
        sys.exit(1)

    agent_tool_names = set(args.agent_tool_name) if args.agent_tool_name else AGENT_TOOL_NAMES
    dispatches = collect_agent_dispatches(entries, agent_tool_names)

    session_start = events[0]["ts"]
    session_end = events[-1]["ts"] + timedelta(milliseconds=1)

    segments = build_segments(events, dispatches, session_start, session_end)

    model = args.model or detect_model(events) or DEFAULT_MODEL
    if model not in PRICING:
        print(f"Warning: unknown model '{model}', falling back to {DEFAULT_MODEL} pricing", file=sys.stderr)
    prices = resolve_prices(model, args.input_price, args.output_price)

    rows = []
    totals = {"n": 0, "input": 0, "output": 0, "write_5m": 0, "write_1h": 0, "read": 0, "cost": 0.0, "dur": 0.0}

    for i, (state, label, start, end) in enumerate(segments):
        n, input_tok, out_tok, write_5m, write_1h, read_tok = sum_usage(events, start, end)
        cost = segment_cost(input_tok, out_tok, write_5m, write_1h, read_tok, prices)
        dur_min = (end - start).total_seconds() / 60.0

        rows.append({
            "Segment": f"S{i}",
            "State": state,
            "Label": label,
            "Start (UTC)": start.strftime("%d-%m-%Y %H:%M:%S"),
            "Duration (min)": round(dur_min, 2),
            "Orchestrator Turns": n,
            "Input Tokens": input_tok,
            "Output Tokens": out_tok,
            "Cache Write 5m Tokens": write_5m,
            "Cache Write 1h Tokens": write_1h,
            "Cache Read Tokens": read_tok,
            "Cost USD": round(cost, 4),
        })

        totals["n"] += n
        totals["input"] += input_tok
        totals["output"] += out_tok
        totals["write_5m"] += write_5m
        totals["write_1h"] += write_1h
        totals["read"] += read_tok
        totals["cost"] += cost
        totals["dur"] += dur_min

    rows.append({
        "Segment": "",
        "State": "",
        "Label": "TOTAL",
        "Start (UTC)": "",
        "Duration (min)": round(totals["dur"], 2),
        "Orchestrator Turns": totals["n"],
        "Input Tokens": totals["input"],
        "Output Tokens": totals["output"],
        "Cache Write 5m Tokens": totals["write_5m"],
        "Cache Write 1h Tokens": totals["write_1h"],
        "Cache Read Tokens": totals["read"],
        "Cost USD": round(totals["cost"], 4),
    })

    output_path = Path(args.output) if args.output else path.with_name(path.stem + "-timetable.csv")
    with open(output_path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    print(f"Model: {model}  (input ${prices['input']:.2f} / output ${prices['output']:.2f} per MTok)")
    print(f"Dispatches found: {len(dispatches)}  Segments: {len(segments)}")
    print(f"Written: {output_path}")


if __name__ == "__main__":
    main()
