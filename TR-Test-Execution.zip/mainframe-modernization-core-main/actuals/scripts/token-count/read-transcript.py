"""
Read Claude Code JSONL transcript as a readable conversation.

Usage:
    python scripts/read-transcript.py <path-to-jsonl>
    python scripts/read-transcript.py <path-to-jsonl> --tools-only
    python scripts/read-transcript.py <path-to-jsonl> --no-thinking
    python scripts/read-transcript.py <path-to-jsonl> --full
    python scripts/read-transcript.py <path-to-jsonl> --output chat.md
    python scripts/read-transcript.py <path-to-jsonl> --tokens --output chat.md

Examples:
    # Main conversation
    python scripts/read-transcript.py "C:\\Users\\...\\session-id.jsonl"

    # Subagent conversation
    python scripts/read-transcript.py "C:\\Users\\...\\subagents\\agent-xxx.jsonl"

    # Full text, no truncation
    python scripts/read-transcript.py <path> --full --output transcript.md

    # Show only tool calls + results
    python scripts/read-transcript.py <path> --tools-only --full

    # Include token usage statistics at the beginning of output
    python scripts/read-transcript.py <path> --tokens --output transcript.md
"""

import io
import json
import sys
import argparse
from pathlib import Path
from textwrap import indent

# Ensure stdout handles unicode on Windows terminals
if hasattr(sys.stdout, 'buffer'):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')


SEPARATOR = "─" * 60
COLORS = {
    "system": "\033[90m",
    "user": "\033[36m",
    "assistant": "\033[32m",
    "thinking": "\033[90;3m",
    "tool_use": "\033[33m",
    "tool_result": "\033[35m",
    "reset": "\033[0m",
}


def colorize(text, role, use_color=True):
    if not use_color:
        return text
    color = COLORS.get(role, "")
    return f"{color}{text}{COLORS['reset']}"


def truncate_text(text, max_lines=30, full=False):
    if full:
        return text
    lines = text.split("\n")
    if len(lines) > max_lines:
        return "\n".join(lines[:max_lines]) + f"\n  ... ({len(lines) - max_lines} more lines)"
    return text


def format_tool_input(inp, full=False):
    lines = []

    for k, v in inp.items():
        val = str(v)
        if not full and len(val) > 200:
            val = val[:200] + "..."
        lines.append(f"  {k}: {val}")

    return "\n".join(lines)


def format_tool_result_text(content, max_lines=30, full=False):
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict):
                text = block.get("text", block.get("content", json.dumps(block, indent=2)))
                parts.append(str(text))
            else:
                parts.append(str(block))
        text = "\n".join(parts)
    elif isinstance(content, dict):
        text = content.get("text", content.get("content", json.dumps(content, indent=2)))
    else:
        text = str(content) if content else "(empty)"

    return truncate_text(text, max_lines, full)


def read_jsonl(path):
    entries = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return entries


def _count_action(stats, tool_name, tool_use_result, is_error, result_text=None):
    """Attribute one tool_result to an action counter.

    Main-session transcripts populate toolUseResult as a structured dict on
    success (type/file/structuredPatch/stdout/etc.), so that shape is checked
    first. Subagent transcripts don't: toolUseResult is None on success or a
    plain error string, so we fall back to the originating tool's name plus
    the rendered result text to tell a file creation from an edit.
    """
    if isinstance(tool_use_result, dict):
        tr = tool_use_result
        tr_type = tr.get('type')
        if tr_type == 'text' and 'file' in tr:
            stats['files_read'] += 1
        elif tr_type == 'create':
            stats['files_created'] += 1
        elif 'structuredPatch' in tr and tr_type != 'create':
            stats['files_edited'] += 1
        elif 'stdout' in tr or 'stderr' in tr:
            stats['bash_commands'] += 1
        elif 'filenames' in tr and 'mode' in tr:
            stats['greps'] += 1
        return

    if is_error:
        return

    if tool_name == 'Read':
        stats['files_read'] += 1
    elif tool_name == 'Write':
        if result_text and 'created successfully' in result_text:
            stats['files_created'] += 1
        else:
            stats['files_edited'] += 1
    elif tool_name == 'Edit':
        stats['files_edited'] += 1
    elif tool_name == 'Bash':
        stats['bash_commands'] += 1
    elif tool_name == 'Grep':
        stats['greps'] += 1


def extract_token_usage(entries):
    """Extract token usage and session metadata from entries."""
    stats = {
        # identity
        'session_id': None,
        'session_title': None,
        'git_branch': None,
        'entrypoint': None,
        'version': None,
        'permission_modes': set(),
        'cwds': [],
        # timing
        'timestamps': [],
        # api
        'api_calls': 0,       # real model invocations (unique message.id)
        'content_blocks': 0,  # raw assistant JSONL entries (multiple per call when streaming)
        'tool_use_turns': 0,
        'end_turns': 0,
        'model': None,
        # tokens
        'input_tokens': 0,
        'output_tokens': 0,
        'cache_read_tokens': 0,
        'cache_create_tokens': 0,
        'cache_create_5m_tokens': 0,
        'cache_create_1h_tokens': 0,
        # actions
        'files_read': 0,
        'files_edited': 0,
        'files_created': 0,
        'bash_commands': 0,
        'greps': 0,
        'tool_errors': 0,
        'hook_errors': 0,
        'thinking_blocks': 0,
        'user_turns': 0,
    }

    # tool_use id -> tool name, needed because subagent transcripts don't
    # populate toolUseResult as a structured dict (it's None on success or a
    # plain error string), unlike main-session transcripts. Tracking the
    # originating tool name lets action counts fall back to it.
    pending_tools = {}

    # track seen message ids to count real API calls (one per unique message.id)
    seen_message_ids = set()

    for entry in entries:
        entry_type = entry.get('type')

        # --- session metadata (any entry type) ---
        if not stats['session_id'] and 'sessionId' in entry:
            stats['session_id'] = entry['sessionId']
        if not stats['git_branch'] and 'gitBranch' in entry:
            stats['git_branch'] = entry['gitBranch']
        if not stats['entrypoint'] and 'entrypoint' in entry:
            stats['entrypoint'] = entry['entrypoint']
        if not stats['version'] and 'version' in entry:
            stats['version'] = entry['version']
        cwd = entry.get('cwd')
        if cwd and (not stats['cwds'] or stats['cwds'][-1] != cwd):
            stats['cwds'].append(cwd)

        # --- session title ---
        if entry_type == 'ai-title':
            title = entry.get('aiTitle')
            if title:
                stats['session_title'] = title

        # --- hook errors ---
        if entry_type == 'attachment':
            att = entry.get('attachment', {})
            if att.get('type') == 'hook_non_blocking_error':
                stats['hook_errors'] += 1

        # --- timestamps for duration ---
        ts = entry.get('timestamp')
        if ts and entry_type in ('user', 'assistant'):
            stats['timestamps'].append({'time': ts, 'type': entry_type})

        # --- user entries ---
        if entry_type == 'user':
            msg = entry.get('message', {})
            content = msg.get('content', [])

            # real user prompt (not a tool-result turn)
            if entry.get('promptSource') == 'sdk':
                stats['user_turns'] += 1

            pm = entry.get('permissionMode')
            if pm:
                stats['permission_modes'].add(pm)

            # tool results inside user message
            if isinstance(content, list):
                for block in content:
                    if not isinstance(block, dict) or block.get('type') != 'tool_result':
                        continue
                    is_error = block.get('is_error')
                    if is_error:
                        stats['tool_errors'] += 1
                    tool_name = pending_tools.get(block.get('tool_use_id'))
                    if tool_name:
                        result_text = block.get('content')
                        if not isinstance(result_text, str):
                            result_text = None
                        _count_action(stats, tool_name, entry.get('toolUseResult'), is_error, result_text)

        # --- assistant entries: track tool_use ids for the next user entry ---
        if entry_type == 'assistant':
            msg = entry.get('message', {})
            for block in msg.get('content', []) if isinstance(msg.get('content'), list) else []:
                if isinstance(block, dict) and block.get('type') == 'tool_use':
                    pending_tools[block.get('id')] = block.get('name')

        # --- assistant entries: token usage ---
        if entry_type != 'assistant':
            continue

        message = entry.get('message', {})
        usage = message.get('usage')
        if not usage:
            continue

        stats['content_blocks'] += 1

        msg_id = message.get('id')
        is_new_call = msg_id not in seen_message_ids
        if msg_id:
            seen_message_ids.add(msg_id)
        else:
            is_new_call = True  # no id: treat every entry as a separate call

        if is_new_call:
            stats['api_calls'] += 1

            if not stats['model']:
                stats['model'] = message.get('model', 'unknown')

            stop_reason = message.get('stop_reason', '')
            if stop_reason == 'tool_use':
                stats['tool_use_turns'] += 1
            elif stop_reason == 'end_turn':
                stats['end_turns'] += 1

        stats['input_tokens'] += usage.get('input_tokens', 0)
        stats['output_tokens'] += usage.get('output_tokens', 0)
        stats['cache_read_tokens'] += usage.get('cache_read_input_tokens', 0)
        stats['cache_create_tokens'] += usage.get('cache_creation_input_tokens', 0)
        cache_creation = usage.get('cache_creation') or {}
        stats['cache_create_5m_tokens'] += cache_creation.get('ephemeral_5m_input_tokens', 0)
        stats['cache_create_1h_tokens'] += cache_creation.get('ephemeral_1h_input_tokens', 0)

        for block in message.get('content', []):
            if isinstance(block, dict) and block.get('type') == 'thinking':
                stats['thinking_blocks'] += 1

    stats['permission_modes'] = sorted(stats['permission_modes'])
    return stats


def calculate_timing(timestamps):
    """Calculate total, active, and idle time from conversation timestamps."""
    from datetime import datetime

    if len(timestamps) < 2:
        return None

    # Sort by time
    timestamps = sorted(timestamps, key=lambda x: x['time'])

    # Parse timestamps
    def parse_ts(ts_str):
        return datetime.fromisoformat(ts_str.replace('Z', '+00:00'))

    first_ts = parse_ts(timestamps[0]['time'])
    last_ts = parse_ts(timestamps[-1]['time'])
    total_seconds = (last_ts - first_ts).total_seconds()

    # Calculate active time (user/assistant response intervals)
    active_seconds = 0
    idle_seconds = 0

    for i in range(len(timestamps) - 1):
        current = timestamps[i]
        next_entry = timestamps[i + 1]

        current_time = parse_ts(current['time'])
        next_time = parse_ts(next_entry['time'])
        interval = (next_time - current_time).total_seconds()

        # Active: user → assistant or assistant → assistant (tool calls)
        if current['type'] == 'user' and next_entry['type'] == 'assistant':
            active_seconds += interval
        elif current['type'] == 'assistant' and next_entry['type'] == 'assistant':
            active_seconds += interval
        # Idle: assistant → user (waiting for user input)
        elif current['type'] == 'assistant' and next_entry['type'] == 'user':
            idle_seconds += interval
        # user → user (shouldn't happen often, count as idle)
        else:
            idle_seconds += interval

    efficiency = (active_seconds / total_seconds * 100) if total_seconds > 0 else 0

    return {
        'total_seconds': total_seconds,
        'active_seconds': active_seconds,
        'idle_seconds': idle_seconds,
        'efficiency': efficiency,
        'start_time': first_ts,
        'end_time': last_ts
    }


def format_duration(seconds):
    """Format seconds as human-readable duration."""
    if seconds < 60:
        return f"{int(seconds)}s"
    elif seconds < 3600:
        mins = int(seconds // 60)
        secs = int(seconds % 60)
        return f"{mins}m {secs}s" if secs > 0 else f"{mins}m"
    else:
        hours = int(seconds // 3600)
        mins = int((seconds % 3600) // 60)
        return f"{hours}h {mins}m"


def format_token_summary(stats):
    """Format token usage summary as text."""
    W = 60
    SEP = "=" * W

    if stats['content_blocks'] == 0:
        return f"Token Usage Summary:\n{SEP}\nNo token usage data found in transcript.\n"

    lines = []
    lines.append("Token Usage Summary:")
    lines.append(SEP)

    # --- Session identity ---
    if stats['session_title']:
        lines.append(f"Title:           {stats['session_title']}")
    if stats['session_id']:
        lines.append(f"Session ID:      {stats['session_id']}")

    meta_parts = []
    if stats['git_branch']:
        meta_parts.append(f"Branch: {stats['git_branch']}")
    if stats['entrypoint']:
        meta_parts.append(f"Entrypoint: {stats['entrypoint']}")
    if stats['version']:
        meta_parts.append(f"Version: {stats['version']}")
    if meta_parts:
        lines.append(f"{'   '.join(meta_parts)}")

    if stats['permission_modes']:
        lines.append(f"Permissions:     {', '.join(stats['permission_modes'])}")

    unique_cwds = list(dict.fromkeys(stats['cwds']))
    if len(unique_cwds) == 1:
        lines.append(f"Working Dir:     {unique_cwds[0]}")
    elif len(unique_cwds) > 1:
        lines.append(f"Working Dirs:    {unique_cwds[0]}  (+{len(unique_cwds) - 1} more)")

    lines.append("")

    # --- Timing ---
    timing = calculate_timing(stats['timestamps'])
    if timing:
        start_str = timing['start_time'].strftime("%d-%m-%Y %H:%M")
        total_dur = format_duration(timing['total_seconds'])
        active_dur = format_duration(timing['active_seconds'])
        idle_dur = format_duration(timing['idle_seconds'])
        efficiency = timing['efficiency']
        lines.append(f"Start:           {start_str}")
        lines.append(f"Duration:        {total_dur}  (Active: {active_dur}, Idle: {idle_dur}, {efficiency:.1f}%)")
        lines.append("")

    # --- API calls ---
    lines.append(f"Turns:           {stats['api_calls']:,}  (Tool calls: {stats['tool_use_turns']:,}, End turns: {stats['end_turns']:,})")
    lines.append(f"Content Blocks:  {stats['content_blocks']:,}  (JSONL entries per turn, avg {stats['content_blocks']/max(stats['api_calls'],1):.1f})")
    lines.append(f"User Turns:      {stats['user_turns']:,}  (real prompts, excl. tool-result turns)")
    lines.append(f"Model:           {stats['model']}")
    if stats['thinking_blocks']:
        lines.append(f"Thinking Blocks: {stats['thinking_blocks']:,}")
    lines.append("")

    # --- Tokens ---
    total_input = stats['input_tokens'] + stats['cache_read_tokens'] + stats['cache_create_tokens']
    lines.append("Input Tokens:")
    lines.append(f"  Regular:       {stats['input_tokens']:,}")
    lines.append(f"  Cache Read:    {stats['cache_read_tokens']:,}")
    lines.append(f"  Cache Write:   {stats['cache_create_tokens']:,}"
                 f"  (5min: {stats['cache_create_5m_tokens']:,}, 1hr: {stats['cache_create_1h_tokens']:,})")
    lines.append(f"  Total:         {total_input:,}")
    lines.append("")
    lines.append(f"Output Tokens:   {stats['output_tokens']:,}")
    lines.append("")
    total_tokens = total_input + stats['output_tokens']
    lines.append(f"Total Tokens:    {total_tokens:,}")
    if total_input > 0:
        cache_rate = (stats['cache_read_tokens'] / total_input) * 100
        lines.append(f"Cache Hit Rate:  {cache_rate:.1f}%")
    lines.append("")

    # --- Actions ---
    lines.append("Actions:")
    lines.append(f"  Files read:    {stats['files_read']:<6}  Files edited:  {stats['files_edited']:<6}  Files created: {stats['files_created']}")
    lines.append(f"  Bash commands: {stats['bash_commands']:<6}  Greps:         {stats['greps']:<6}  Tool errors:   {stats['tool_errors']}")
    if stats['hook_errors']:
        lines.append(f"  Hook errors:   {stats['hook_errors']}")

    lines.append(SEP)
    lines.append("")

    return "\n".join(lines)


def render_transcript(entries, tools_only=False, show_thinking=True, use_color=True, max_result_lines=30, full=False):
    output = []
    step = 0

    # Track tool_use IDs to match with results
    pending_tools = {}

    for entry in entries:
        entry_type = entry.get("type", "")

        # Skip non-conversation entries
        if entry_type in ("queue-operation", "file-history-snapshot", "ai-title", "last-prompt", "attachment"):
            continue

        message = entry.get("message", {})
        role = message.get("role", entry_type)
        content = message.get("content", "")

        # --- USER messages (contain tool results OR text) ---
        if entry_type == "user" or role == "user":
            if isinstance(content, list):
                for block in content:
                    if not isinstance(block, dict):
                        continue

                    block_type = block.get("type", "")

                    # Tool result block
                    if block_type == "tool_result":
                        tool_id = block.get("tool_use_id", "")
                        tool_name = pending_tools.get(tool_id, "unknown")
                        result_content = block.get("content", "")
                        is_error = block.get("is_error", False)

                        step += 1
                        err_marker = " [ERROR]" if is_error else ""
                        header = f"[{step}] <<< RESULT ({tool_name}){err_marker} <<< (id: {tool_id})"
                        formatted = format_tool_result_text(result_content, max_result_lines, full)

                        output.append(colorize(header, "tool_result", use_color))
                        output.append(colorize(formatted, "tool_result", use_color))
                        output.append("")

                    # Text block in user message
                    elif block_type == "text":
                        if tools_only:
                            continue
                        text = block.get("text", "")
                        if not text.strip():
                            continue
                        step += 1
                        header = f"[{step}] === USER {'=' * 50}"
                        text = truncate_text(text, 30, full)
                        output.append(colorize(header, "user", use_color))
                        output.append(colorize(text, "user", use_color))
                        output.append("")

            elif isinstance(content, str) and content.strip():
                if tools_only:
                    continue
                step += 1
                header = f"[{step}] === USER {'=' * 50}"
                body = truncate_text(content, 30, full)
                output.append(colorize(header, "user", use_color))
                output.append(colorize(body, "user", use_color))
                output.append("")

        # --- ASSISTANT messages ---
        elif entry_type == "assistant" or role == "assistant":
            if not isinstance(content, list):
                content = [{"type": "text", "text": str(content)}] if content else []

            for block in content:
                if not isinstance(block, dict):
                    continue

                block_type = block.get("type", "")

                # Thinking
                if block_type == "thinking":
                    if not show_thinking or tools_only:
                        continue
                    step += 1
                    header = f"[{step}] --- thinking ---"
                    thinking = block.get("thinking", "")
                    thinking = truncate_text(thinking, 10, full)
                    output.append(colorize(header, "thinking", use_color))
                    output.append(colorize(indent(thinking, "  "), "thinking", use_color))
                    output.append("")

                # Text output
                elif block_type == "text":
                    if tools_only:
                        continue
                    text = block.get("text", "")
                    if not text.strip():
                        continue
                    step += 1
                    header = f"[{step}] === ASSISTANT {'=' * 46}"
                    text = truncate_text(text, 30, full)
                    output.append(colorize(header, "assistant", use_color))
                    output.append(colorize(text, "assistant", use_color))
                    output.append("")

                # Tool use
                elif block_type == "tool_use":
                    step += 1
                    tool_id = block.get("id", "")
                    name = block.get("name", "unknown")
                    inp = block.get("input", {})

                    # Track for matching with result
                    pending_tools[tool_id] = name

                    header = f"[{step}] >>> TOOL: {name} >>> (id: {tool_id})"
                    input_text = format_tool_input(inp, full)

                    output.append(colorize(header, "tool_use", use_color))
                    output.append(colorize(f"  Parameters ({len(inp)}):", "tool_use", use_color))
                    if input_text:
                        output.append(colorize(input_text, "tool_use", use_color))
                    output.append("")

    return "\n".join(output)


def main():
    parser = argparse.ArgumentParser(
        description="Read Claude Code JSONL transcript as a readable conversation"
    )
    parser.add_argument("file", help="Path to the .jsonl transcript file")
    parser.add_argument("--tools-only", action="store_true", help="Show only tool calls and results")
    parser.add_argument("--no-thinking", action="store_true", help="Hide thinking blocks")
    parser.add_argument("--no-color", action="store_true", help="Disable colored output")
    parser.add_argument("--full", action="store_true", help="Show full text without any truncation")
    parser.add_argument("--output", "-o", help="Write to file instead of stdout")
    parser.add_argument("--max-result-lines", type=int, default=30, help="Max lines per tool result (default: 30)")
    parser.add_argument("--tokens", action="store_true", help="Include token usage statistics at the beginning")

    args = parser.parse_args()

    path = Path(args.file)
    if not path.exists():
        print(f"Error: File not found: {path}", file=sys.stderr)
        sys.exit(1)

    entries = read_jsonl(path)
    if not entries:
        print("No entries found in file.", file=sys.stderr)
        sys.exit(1)

    use_color = not args.no_color and not args.output
    max_lines = 999999 if args.full else args.max_result_lines

    # Generate token summary if requested
    token_summary = ""
    if args.tokens:
        stats = extract_token_usage(entries)
        token_summary = format_token_summary(stats)

    transcript = render_transcript(
        entries,
        tools_only=args.tools_only,
        show_thinking=not args.no_thinking,
        use_color=use_color,
        max_result_lines=max_lines,
        full=args.full,
    )

    # Combine token summary and transcript
    output = token_summary + transcript if args.tokens else transcript

    if args.output:
        out_path = Path(args.output)
        out_path.write_text(output, encoding="utf-8")
        print(f"Written to {out_path} ({len(entries)} entries)")
    else:
        print(output)
        print(f"\n{'=' * 60}")
        print(f"Total entries: {len(entries)}")
        print(f"File: {path}")


if __name__ == "__main__":
    main()
