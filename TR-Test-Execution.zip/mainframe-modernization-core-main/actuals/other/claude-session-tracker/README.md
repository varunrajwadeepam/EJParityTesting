# Claude Session Tracker

A custom status line for [Claude Code](https://code.claude.com) that shows live session and
per-subagent statistics: model, project, effort, context %, accumulated cost, active
(non-idle) time, turn/tool counters, auto-compaction counts, and a full input/output/cache
token breakdown - cross-platform (Windows, macOS, Linux), pure Python standard library, no
dependencies.

It also keeps a **machine-readable ledger of every session's statistics**
(`~/.claude/all-sessions-stat.json`). Typing `>>>save work-id=… phase=…` in a chat ties the
session to a work-id and phase, **without the text ever reaching the model**. `>>>save
checkpoint` freezes a snapshot, and `/show-usage-stat` reports spending per work-id. See
[Session ledger, work marking and spending report](#session-ledger-work-marking-and-spending-report).

## What it shows

**Main status line** (one line, updates on every main-thread event and every 10 seconds):

```
Sonnet 5 | RevDB-revol-com | high | ctx:19% | cost:$59.5012 | time:205m01s | turns:15 | tools:505 | compacts:0 | in:276.6k | out:101.7k | cw:962.2k | cr:6.1M
```

| Field | Meaning |
|---|---|
| `Sonnet 5` | Model display name (the `Claude ` prefix is stripped) |
| `RevDB-revol-com` | Project folder name |
| `work:P510 \| phase:design` | Only once the session is marked with `>>>save` - the work-id and phase the session's stats are tied to |
| `high` | Reasoning effort level, when the model supports it |
| `ctx:19%` | Current context window usage, read directly from Claude Code's own `context_window.used_percentage` |
| `cost:$59.5012` | Accumulated session cost in USD, read directly from Claude Code's own `cost.total_cost_usd` - already includes every subagent's spend (verified against the transcript's internal `cost-state`/`modelUsage` accounting) |
| `time:205m01s` | **Active** time, not wall-clock elapsed: model generation + tool execution, across the main thread **and** every subagent, excluding the gap between a turn-ending reply and your next prompt (which could be an arbitrarily long, or infinite, wait). Subagents running in parallel are **added up**, so this is agent time (work done, like cost), and it can exceed wall-clock time. Ticks live while a tool is still running rather than freezing until it returns - see [How it works](#how-it-works-brief) |
| `turns:15` | Genuine human-submitted prompts on the main thread **plus** every subagent's task prompt and every follow-up message sent to it (a coordinator's "round 2" via SendMessage, or you typing to the agent). Filters out the tool-result "user" messages the API round-trips for tool calls, other `isMeta` injections, and local slash commands (`/clear`, `/model`, ...) and their output |
| `tools:505` | Tool calls issued, across the main thread **and** every subagent that ran in this session |
| `compacts:0` | Auto-compaction events that happened on the **main thread** conversation (not merged with subagents - see below) |
| `in / out / cw / cr` | Accumulated input / output / cache-write / cache-read tokens since session start, surviving `/resume`, across the main thread **and** every subagent. Each count is the larger of the transcript sum and Claude Code's latest internal `cost-state` snapshot, which can be badly out of date (see below) |

**Per-subagent row** (one per active subagent, in the agent panel below the prompt):

```
claude-code-guide | running | haiku-4-5-20251001-v1:0 | ctx:2% | time:1m05s | turns:1 | tools:7 | tokens:290.2k | compacts:0
```

An agent sent a follow-up after it finished (a coordinator's "round 2") also shows its
current run:

```
P508 rules | running | sonnet-5-5 | ctx:30% | time:109m14s (run 2: 19m40s) | turns:2 | tools:182 | tokens:46.4M | compacts:0
```

| Field | Meaning |
|---|---|
| `claude-code-guide` | Subagent name/label/type |
| `running` | Subagent status |
| `haiku-4-5-...` | Resolved model id for that subagent (shortened) |
| `ctx:2%` | That subagent's own current context usage (`tokenCount / contextWindowSize`) |
| `time:1m05s` | That subagent's own active time, summed over all of its runs (same definition as the main line's `time:`, computed from its own transcript). Each run stops at the subagent's `SubagentHandback` call; the idle wait until a follow-up message is not counted |
| `(run 2: 19m40s)` | Only once the agent has run more than once: the current run's number and active time. Agents started together in the same round show the same run time, even when their totals differ |
| `turns:1` | That subagent's task prompt plus every follow-up message sent to it |
| `tools:7` | Tool calls made by that subagent |
| `tokens:290.2k` | Accumulated input+output+cache tokens for that subagent only (once per API message `id`) |
| `compacts:0` | Auto-compaction events for that specific subagent's own conversation |

Per-subagent cost in dollars is intentionally **not** shown - see [Known limitations](#known-limitations).

## Session ledger, work marking and spending report

### The ledger

The status line keeps one record per session in `~/.claude/all-sessions-stat.json`:
model, effort, project, transcript path, start time, cost, ctx %, active time, turns, tools,
compacts and the four token counts. It's refreshed on every status-line run, so the record
always holds the session's latest numbers, whether or not anyone ever marks it.

```json
{
  "schema": 1,
  "sessions": {
    "<session-id>": {
      "session_id": "…", "work_id": "", "work_phase": "", "marked_at": "",
      "checkpoint": false, "checkpoint_at": "",
      "started_at": "2026-10-15T09:52:20Z", "first_seen": "…", "last_updated": "…",
      "project_dir": "…", "transcript_path": "…", "model": "Sonnet 5.5", "effort": "high",
      "cost_usd": 2.33, "ctx_pct": 41, "active_sec": 862, "turns": 3, "tools": 55, "compacts": 0,
      "tokens": {"in": 240, "out": 89600, "cw": 333400, "cr": 3000000}
    }
  },
  "checkpoints": [ { "...same fields...", "checkpoint": true, "checkpoint_at": "…" } ]
}
```

- A stat refresh never touches the marks (`work_id`, `work_phase`) or the checkpoints.
- The file is rewritten only when a stat actually changed, and at most once every 8 seconds
  per session (`CLAUDE_STAT_MIN_WRITE_SEC` overrides it). `last_updated` therefore means
  "when the stats last changed", not "when the status line last ran". While a turn is
  running, `active_sec` advances every refresh, so a busy session writes on each 10-second
  refresh.

#### Several chats at once

Every open chat runs its own status line, and `>>>save` can arrive at any moment from any
chat, so the ledger is built for concurrent writers:

- **Writes are serialised by an operating-system lock** on `all-sessions-stat.json.lock`
  (`msvcrt` on Windows, `fcntl` on macOS/Linux). The OS releases it as soon as its holder
  exits, even when the holder is killed, so there is never a stale lock to wait out or take
  over. The lock file itself stays in place; that is normal.
- **Each write replaces the file in one step** (temp file + rename), so it is never left
  half-written. Temp files left by a killed writer are swept on the next save.
- **A failed read is never mistaken for an empty ledger.** An unreadable or malformed ledger
  stops all writing (the status line keeps rendering) instead of being overwritten.
  `all-sessions-stat.json.bak`, refreshed at most every 5 minutes, is a recovery copy.
- **Windows file-sharing collisions are retried.** Windows refuses to replace a file another
  process is reading, and refuses to open it mid-replace, so reads and replaces retry
  briefly with jittered back-off.
- **An idle session skips the shared write.** A small per-session fingerprint file under
  `~/.claude/stat-cache/` remembers what that session last wrote. While the stats are
  unchanged, the session does not touch the ledger lock at all.
- **Marks and checkpoints write only while holding the lock.** If another chat holds it for
  longer than 3 seconds, `>>>save` answers "the ledger is busy … Try again." rather than
  risking a lost update.

Verified on Windows with a 90-second stress run of 16 status-line loops, 4 `>>>save` /
checkpoint loops and 2 report readers in parallel: 555 status lines and 281 saves, no
failures, no lost marks, every acknowledged checkpoint written, no leftover files. 600
simultaneous marks from 20 processes lost nothing, and a writer killed while holding the
lock blocked nobody.

### Marking a session: `>>>save`

Type these in the chat prompt. A `UserPromptSubmit` hook intercepts any prompt starting
with `>>>save`, applies it and **blocks the prompt**. A blocked prompt is erased and never
sent to the model, so it adds nothing to the session's context and costs no tokens. You see
only a one-line confirmation.

| You type | Effect |
|---|---|
| `>>>save work-id=ABC123 phase=design` | Sets both marks |
| `>>>save phase=build` | Rewrites the phase only; the work-id stays |
| `>>>save work-id= phase=build` | An empty value clears that mark |
| `>>>save work-id="ABC 1" phase=x` | Quotes allow values with spaces |
| `>>>save` | Clears both marks |
| `>>>save checkpoint` | Freezes a copy of the session's record (see below) |
| `>>>save junk` / `>>>save foo=1` | Rejected with a usage hint; nothing changes |

Keys are case-insensitive; `work-id`, `work_id`, `workid` and `id` all mean the work-id, and
`phase`, `work-phase` and `work_phase` all mean the phase. Values may contain any letters,
Cyrillic, accented and CJK included. Within 10 s the status line shows `work:… | phase:…`.

Parsing is strict, so a typo is rejected rather than half-applied. Each of these is refused
with a message and leaves the marks unchanged: spaces around `=` (`work-id = A`), a comma,
semicolon or `=` inside a value (`work-id=A,`), stray words or extra lines, an unclosed
quote, the same key twice, and `checkpoint` combined with anything else.

The hook always answers within 6 seconds, inside its 10-second timeout. If it can't finish
in time, it replies "NOT confirmed - timed out" and still blocks the prompt; check the
`work:`/`phase:` marks in the status line and retry. Any `>>>save` prompt is blocked, even
when the hook can't read its input, so the text never falls through to the model.

### Freezing a snapshot: `>>>save checkpoint`

A session keeps running after you mark it, so its live numbers keep growing.
`>>>save checkpoint` appends a **copy** of the session's current record to the ledger's
`checkpoints` list, with `checkpoint: true` and `checkpoint_at: <UTC time>`. The copy is never
updated again. Live records stay `checkpoint: false`.

- It only works once the session has a work-id; otherwise it is rejected with a hint.
- It recomputes the stats from the session's transcript first, so the copy is current, not
  as of the last status-line refresh. The live record is brought up to date too. Cost comes
  from the last refresh, or from the transcript's own cost snapshot if that is higher. If
  re-reading a very large transcript takes longer than 3 seconds, the checkpoint uses the
  last refresh's numbers instead, and the reply says so.
- Take as many as you like; they're numbered per session.

### Spending report: `/show-usage-stat`

A user-level slash command, available in every project:

```
/show-usage-stat                 every session that has a work-id
/show-usage-stat P510 ABC123     only these work-ids (case-insensitive)
/show-usage-stat --all           also sessions never marked (work-id "-")
```

It prints three Markdown tables:
- **Sessions**, grouped by work-id and phase;
- **By work-id**, with a grand total;
- **Checkpoints**, listed separately. Checkpoints are copies of the same sessions, so they
  are **never added to the totals**, which would double-count.

The same report runs outside Claude: `python ~/.claude/scripts/usage_report.py [args]`.
Unlike `>>>save`, the slash command's output does enter the chat and uses one small model
turn.

## How it works (brief)

Claude Code pipes a JSON blob to the configured `statusLine`/`subagentStatusLine` command on
stdin and prints whatever the command writes to stdout. The transcript parsing lives in
`scripts/session_stats.py`, shared by `statusline.py` and the `>>>save checkpoint` hook so
both compute identical numbers. `scripts/statusline.py` and `scripts/subagent-statusline.py`:

- Read stdin as raw bytes decoded as UTF-8, which is what Claude Code sends. Text-mode
  stdin on Windows would decode with the system code page (e.g. cp1252) and garble any
  non-ASCII project path, transcript path or mark. Both scripts give up after 5 seconds if
  stdin is never closed, so orphaned runs exit instead of piling up.
- Read the live fields Claude Code already computes (`cost.total_cost_usd`,
  `context_window.used_percentage`, etc.) - trusted as-is, never recomputed.
- For token/turn/tool/compaction stats Claude Code doesn't expose directly, they parse the
  session's own transcript file(s) (`~/.claude/projects/<project>/<session-id>.jsonl` and its
  sibling `<session-id>/subagents/agent-<id>.jsonl` files).
- **Tokens** are summed from `message.usage` in every transcript, main thread and every
  subagent alike. Usage is taken **once per API message `id`**: one response is written as
  several transcript lines (one per content block) that all repeat the same `usage` object,
  and summing every line over-counted tokens roughly 2.5x. Claude Code also writes a
  `{"type": "cost-state", "modelUsage": {...}}` snapshot to the main transcript. It merges
  every thread by model and includes small internal calls that never appear in a transcript,
  but it is written only now and then and can be badly out of date. One session at $56 had a
  single snapshot, written when it had cost $0.33. Each token count is therefore the larger
  of the two: a current snapshot adds its few extra internal calls, and a stale one can never
  hide what was spent.
- Never write to the transcripts or Claude Code's own files. The only thing written is the
  tracker's own ledger (`statusline.py`, via `session_record.py`); `subagent-statusline.py`
  writes nothing.

**Active time**, specifically: walks each transcript in order, tracking whether the
conversation is "active" (from a real prompt through every tool call and response) or
"waiting on you" (from a turn-ending reply, i.e. one whose `stop_reason` isn't `"tool_use"`,
until the next real prompt). Only time in the active state gets summed; if the transcript's
last event is still active (a tool is running right now), the sum extends to the current
wall-clock time so it keeps ticking instead of freezing until the next transcript write.
Two real Claude Code transcript quirks this has to work around, both discovered by comparing
computed active time against known tool-call counts until the numbers stopped being
absurdly low:
  - **A single logical response is written to the transcript multiple times as it streams
    in** (same message `id`, growing `content`), and `stop_reason` itself stays `null` on
    those in-progress writes - it's only set on a later, separate write of the same `id` once
    the response is truly complete. Treating a `null` `stop_reason` (or the absence of a
    `tool_use` content block, which has the same problem) as "turn-ending" misclassifies an
    in-progress write as final. For a subagent's own transcript, which has no further real
    prompt to reset that misclassification, this single mistake silently zeroed out nearly
    all of its active time. Fix: treat `null` as "still streaming, unknown yet" and leave the
    active/waiting state unchanged, only ever act on a genuinely non-null `stop_reason`.
  - **Auto-loaded skill content is injected as a `"user"`-role message** (plain text, not a
    `tool_result`), which without an explicit check reads exactly like a genuine human prompt
    to a naive filter - inflating both `turns:` and (by incorrectly resetting the active/idle
    state) active time. Claude Code marks these `isMeta: true`; genuine prompts never carry
    that flag, so filtering on it fixes both. (For *active time*, though, an `isMeta` entry
    that resumes the main thread on its own - a subagent's hand-back message, a scheduled
    wake-up firing - does start activity; otherwise all the work in such a resumed turn
    is dropped.)
  - **A subagent ends by calling the `SubagentHandback` tool, not with a turn-ending text
    reply**, and that write usually carries a `null` `stop_reason`. Without treating that
    call as the subagent's final event, a finished subagent never reaches "waiting" and its
    trailing time keeps ticking until "now" - with three finished subagents the main line's
    `time:` grew ~3 seconds per real second, forever.
  - **A follow-up message to a finished subagent is recorded as `isMeta`** (a coordinator's
    SendMessage "round 2", marked `origin.kind: "coordinator"`, or you typing to the agent,
    `"human"`). Unlike other `isMeta` injections, it starts a new run and counts as a turn.
    Without that, the subagent's row froze at the end of its first run.
  - **Consecutive prompts with nothing in between** (a re-sent or queued prompt) and **local
    slash commands** (`/clear`, `/model`, ...) are recorded as user entries but never start
    model work, so the gaps around them are not counted as active.
  - **A turn interrupted mid-tool and resumed much later** (e.g. the window closed overnight)
    looks like one tool call that ran for hours. No single gap longer than 30 minutes counts
    as active; nothing legitimately runs that long without a transcript write, since a Bash
    call times out at 10 minutes.

## Requirements

- Claude Code CLI installed and working.
- Python 3.6+ on `PATH`, reachable as either `python` or `python3`. The configured commands
  try `python` first, then fall back to `python3`:
  - **Windows:** `python` is the real interpreter. `python3` is often the Microsoft Store
    alias stub, which always fails, costs about 0.4 s per run and left orphaned processes
    behind, so it is never tried first.
  - **macOS / Linux with only `python3`:** the shell fails to find `python` in about a
    millisecond without reading stdin, so `python3` still receives the whole payload.
  - **`python` is Python 2:** the script fails to compile before reading stdin, so the
    `python3` fallback works the same way.

## Install

### Automated - "just run"

```bash
python install.py      # Windows
python3 install.py     # macOS / Linux
```

One script, auto-detects the OS via `sys.platform` - no separate per-OS variant needed. The
installer:

1. Copies `statusline.py`, `subagent-statusline.py`, `session_stats.py`, `session_record.py`
   and `usage_report.py` from `scripts/` into `~/.claude/scripts/` (marking them executable
   on macOS/Linux; that step is a no-op on Windows).
2. Copies `commands/show-usage-stat.md` into `~/.claude/commands/`, which makes
   `/show-usage-stat` available in every project.
3. Backs up your existing `~/.claude/settings.json` (if any) to
   `~/.claude/settings.json.bak-<timestamp>` before touching it.
4. Merges in `statusLine` and `subagentStatusLine` entries, plus one `UserPromptSubmit` hook
   for `>>>save`. It leaves every other setting untouched (permissions, model, and every
   other hook on any event). Re-running the installer updates its own hook in place rather
   than adding a duplicate.
5. Prints exactly what it changed.

> **Windows/macOS/Linux support note:** only the Windows path (`sys.platform == "win32"`)
> has actually been run and verified end-to-end so far, against a temporary fake home
> directory. The macOS/Linux branch (`chmod 755` on the copied scripts, otherwise identical
> logic) has not yet been exercised on a real Mac or Linux machine - there's nothing
> platform-specific in the rest of the script that should break, but please report back if
> you hit anything.

Restart Claude Code (fully quit and relaunch, not just a new conversation) afterwards.

### Manual install

1. Copy all five files from `scripts/` into `~/.claude/scripts/`, and
   `commands/show-usage-stat.md` into `~/.claude/commands/` (create the folders if they
   don't exist):
   ```
   ~/.claude/scripts/statusline.py
   ~/.claude/scripts/subagent-statusline.py
   ~/.claude/scripts/session_stats.py
   ~/.claude/scripts/session_record.py
   ~/.claude/scripts/usage_report.py
   ~/.claude/commands/show-usage-stat.md
   ```
2. On macOS/Linux, make them executable (optional, the configured command invokes them via
   `python`/`python3` either way): `chmod +x ~/.claude/scripts/*.py`
3. Open (or create) `~/.claude/settings.json` and add these keys, keeping everything else in
   the file as-is. If you already have a `hooks` section, add the `UserPromptSubmit` entry to
   it rather than replacing it:
   ```json
   {
     "statusLine": {
       "type": "command",
       "command": "python ~/.claude/scripts/statusline.py 2>/dev/null || python3 ~/.claude/scripts/statusline.py",
       "refreshInterval": 10
     },
     "subagentStatusLine": {
       "type": "command",
       "command": "python ~/.claude/scripts/subagent-statusline.py 2>/dev/null || python3 ~/.claude/scripts/subagent-statusline.py"
     },
     "hooks": {
       "UserPromptSubmit": [
         {
           "hooks": [
             {
               "type": "command",
               "command": "python ~/.claude/scripts/session_record.py hook 2>/dev/null || python3 ~/.claude/scripts/session_record.py hook",
               "timeout": 10
             }
           ]
         }
       ]
     }
   }
   ```
4. Restart Claude Code (fully quit and relaunch).

## Uninstall / rollback

- Remove the `statusLine` and `subagentStatusLine` keys and the `UserPromptSubmit` hook
  entry that runs `session_record.py hook` from `~/.claude/settings.json`. Or restore your
  `settings.json.bak-<timestamp>` backup from the automated install.
- Optionally delete the five scripts from `~/.claude/scripts/` and
  `~/.claude/commands/show-usage-stat.md`.
- The ledger `~/.claude/all-sessions-stat.json` is your data; it is never deleted
  automatically. Remove it yourself if you no longer need it, together with its helper
  files: `all-sessions-stat.json.bak`, `all-sessions-stat.json.lock` and the
  `~/.claude/stat-cache/` folder.

## Known limitations

- **The ledger grows without limit.** Every session that ever ran a status line gets a
  record, including background sessions with no conversation ($0, 0 turns), and nothing is
  pruned. `/show-usage-stat` hides unmarked sessions unless `--all` is given.
- **A session's stats appear only once its status line has run.** A `>>>save` typed before
  that records the marks alone; the stats fill in on the next refresh.
- **The `>>>save` hook only takes effect after Claude Code reloads its settings.** After
  installing, restart Claude Code, or open `/hooks` once in a running session. Until then,
  a `>>>save` prompt goes to the model like any other text.
- **The last few seconds of a session can go unrecorded.** A chat closed within one refresh
  (10 s) of its last activity keeps the values from the refresh before. A
  `>>>save checkpoint` taken before closing captures everything, because it recomputes the
  stats from the transcript itself.
- **A corrupted ledger is not repaired automatically.** If `all-sessions-stat.json` is
  damaged (for example, hand-edited into invalid JSON), recording stops and `>>>save` reports
  the problem, but nothing overwrites the file. Fix it or restore it from
  `all-sessions-stat.json.bak` by hand. While it stays broken, every refresh takes about 3
  seconds longer.
- **Status-line cost grows with transcript size.** Every refresh re-reads the whole main
  transcript and every subagent transcript: about 1 s for a session of a few MB, about 6.5 s
  with 100+ MB of subagent transcripts.

- **No per-subagent dollar cost.** Claude Code doesn't expose cost at per-subagent
  granularity - only a per-model breakdown (`modelUsage`) that mixes together every thread
  using the same model. Showing a real number would require a hand-maintained price-per-model
  table, and we didn't have a way to verify Bedrock-specific rates for current models
  (Sonnet 5 / Opus 5 / Haiku 4.5) - only Anthropic's first-party API list price, which may not
  match your actual bill on Bedrock/Vertex/Foundry. Rather than show a possibly-wrong dollar
  figure, we dropped it. The session-level `cost:` field is unaffected and is accurate,
  Bedrock or not, since it's Claude Code's own number.
- **`ctx:` can briefly exceed 100%.** Auto-compaction is reactive, not preemptive: on a
  fast-growing context, real usage can climb past the model's window size in the ~1-2 minutes
  a compaction pass takes to run, before the next one catches up. That's a real, if brief,
  overshoot in Claude Code's own numbers, not a bug in these scripts.
- **The main line can go stale during a long subagent wait**, unless `refreshInterval` is set
  (it is, by default, to 10 seconds in this install). Claude Code only re-runs the main
  `statusLine` command on main-thread events (a new assistant message, `/compact`, permission
  mode changes, ...) - those go quiet while the main thread just waits on a background
  subagent, so without a timer the line freezes until the subagent finishes.
- **Requires Git Bash on Windows for the exact command shown above.** Claude Code runs
  status-line commands through Git Bash when it's installed, or PowerShell otherwise. The
  `~/...` path and `||` fallback syntax are Bash syntax; if a Windows machine has no Git Bash
  installed, Claude Code falls back to PowerShell and this exact command string will not work
  as-is. This has only been exercised with Git Bash present.
- **Context window sizes on Bedrock/Vertex/Foundry can differ from Anthropic's direct API**
  (e.g. Opus 5 gets a 200K window on some third-party providers instead of the native 1M) -
  the `ctx:` percentages are only as meaningful as the `contextWindowSize` Claude Code itself
  reports for that provider.
