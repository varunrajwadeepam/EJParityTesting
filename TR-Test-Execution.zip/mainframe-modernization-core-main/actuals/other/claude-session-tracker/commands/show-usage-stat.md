---
description: Report spending per work-id from ~/.claude/all-sessions-stat.json (args - optional work-ids, or --all to include unmarked sessions)
argument-hint: "[work-id ...] [--all]"
allowed-tools: Bash(python:*), Bash(python3:*)
---

!`python ~/.claude/scripts/usage_report.py $ARGUMENTS 2>/dev/null || python3 ~/.claude/scripts/usage_report.py $ARGUMENTS`

Show the report above to the user exactly as it is. Add nothing, run no tools.
