#!/usr/bin/env python3
"""
Install the Claude Code session tracker: status lines, the session ledger hook and
the /show-usage-stat command. Cross-platform - just run:
    python install.py      (Windows)
    python3 install.py     (macOS / Linux)
"""
import json
import os
import shutil
import sys
import time
from pathlib import Path

# `python` first, `python3` as the fallback. On Windows `python3` is often the
# Microsoft Store alias stub: it always fails, costs ~0.4 s per run, and left
# orphaned processes behind - so it must not be tried first. On macOS/Linux
# without a `python`, the shell fails to find it in a millisecond without
# reading stdin, so `python3` still gets the whole payload. (A `python` that is
# Python 2 fails to compile the script, also before reading stdin.)
STATUSLINE_COMMAND = (
    "python ~/.claude/scripts/statusline.py 2>/dev/null "
    "|| python3 ~/.claude/scripts/statusline.py"
)
SUBAGENT_STATUSLINE_COMMAND = (
    "python ~/.claude/scripts/subagent-statusline.py 2>/dev/null "
    "|| python3 ~/.claude/scripts/subagent-statusline.py"
)
SESSION_HOOK_COMMAND = (
    "python ~/.claude/scripts/session_record.py hook 2>/dev/null "
    "|| python3 ~/.claude/scripts/session_record.py hook"
)
# Recognises our hook entry in an existing settings.json, so a re-install
# updates it in place instead of adding a duplicate.
SESSION_HOOK_MARKER = "session_record.py hook"
# Keep above session_record.MIN_WRITE_INTERVAL_SEC (8 s), or regular refreshes
# get coalesced away.
REFRESH_INTERVAL_SECONDS = 10

SCRIPT_FILES = ["statusline.py", "subagent-statusline.py", "session_stats.py",
                "session_record.py", "usage_report.py"]
COMMAND_FILES = ["show-usage-stat.md"]

PLATFORM_NAMES = {"win32": "Windows", "darwin": "macOS", "linux": "Linux"}


def main():
    platform_name = PLATFORM_NAMES.get(sys.platform, sys.platform)
    make_executable = sys.platform != "win32"

    package_dir = Path(__file__).resolve().parent
    source_scripts_dir = package_dir / "scripts"
    source_commands_dir = package_dir / "commands"
    claude_dir = Path.home() / ".claude"
    target_scripts_dir = claude_dir / "scripts"
    target_commands_dir = claude_dir / "commands"
    settings_path = claude_dir / "settings.json"

    print("Claude Session Tracker installer ({})".format(platform_name))
    print("  Claude home:     {}".format(claude_dir))
    print("  Scripts target:  {}".format(target_scripts_dir))
    print("  Settings file:   {}".format(settings_path))
    print()

    # 1. Copy the statusline scripts into ~/.claude/scripts/
    target_scripts_dir.mkdir(parents=True, exist_ok=True)
    for filename in SCRIPT_FILES:
        src = source_scripts_dir / filename
        if not src.is_file():
            print("ERROR: expected script not found: {}".format(src))
            sys.exit(1)
        dst = target_scripts_dir / filename
        shutil.copyfile(src, dst)
        if make_executable:
            os.chmod(dst, 0o755)
        print("  copied {} -> {}".format(filename, dst))

    # 1b. Copy the user-level slash command(s) into ~/.claude/commands/
    target_commands_dir.mkdir(parents=True, exist_ok=True)
    for filename in COMMAND_FILES:
        src = source_commands_dir / filename
        if not src.is_file():
            print("ERROR: expected command not found: {}".format(src))
            sys.exit(1)
        dst = target_commands_dir / filename
        shutil.copyfile(src, dst)
        print("  copied {} -> {}".format(filename, dst))

    # 2. Merge statusLine / subagentStatusLine into ~/.claude/settings.json,
    #    preserving every other existing key. Back up the original first.
    settings = {}
    if settings_path.is_file():
        backup_path = settings_path.with_name(
            "settings.json.bak-{}".format(time.strftime("%Y%m%d-%H%M%S"))
        )
        shutil.copyfile(settings_path, backup_path)
        print("  backed up existing settings.json -> {}".format(backup_path))
        try:
            settings = json.loads(settings_path.read_text(encoding="utf-8"))
        except Exception as exc:
            print("ERROR: existing settings.json is not valid JSON: {}".format(exc))
            print("Fix or remove it, then re-run this installer.")
            sys.exit(1)

    for key, new_value in (
        ("statusLine", {
            "type": "command",
            "command": STATUSLINE_COMMAND,
            "refreshInterval": REFRESH_INTERVAL_SECONDS,
        }),
        ("subagentStatusLine", {
            "type": "command",
            "command": SUBAGENT_STATUSLINE_COMMAND,
        }),
    ):
        old_value = settings.get(key)
        if old_value is not None and old_value != new_value:
            print("  NOTE: replacing existing '{}' setting:".format(key))
            print("    old: {}".format(json.dumps(old_value)))
            print("    new: {}".format(json.dumps(new_value)))
        settings[key] = new_value

    # 3. Merge the UserPromptSubmit hook that handles ">>>save ...", keeping
    #    every other hook (on this and on any other event) untouched.
    merge_session_hook(settings)

    claude_dir.mkdir(parents=True, exist_ok=True)
    settings_path.write_text(json.dumps(settings, indent=2) + "\n", encoding="utf-8")
    print("  wrote {}".format(settings_path))

    print()
    print("Done. Restart Claude Code (fully quit and relaunch) to pick up the new status line,")
    print("the '>>>save' hook and the /show-usage-stat command.")


def merge_session_hook(settings):
    our_hook = {"type": "command", "command": SESSION_HOOK_COMMAND, "timeout": 10}
    hooks = settings.get("hooks")
    if not isinstance(hooks, dict):
        hooks = {}
        settings["hooks"] = hooks
    groups = hooks.get("UserPromptSubmit")
    if not isinstance(groups, list):
        groups = []
        hooks["UserPromptSubmit"] = groups
    for group in groups:
        for i, hook in enumerate((group or {}).get("hooks") or []):
            if SESSION_HOOK_MARKER in str((hook or {}).get("command", "")):
                if hook != our_hook:
                    group["hooks"][i] = our_hook
                    print("  updated existing UserPromptSubmit session hook")
                else:
                    print("  UserPromptSubmit session hook already present")
                return
    groups.append({"hooks": [our_hook]})
    print("  added UserPromptSubmit session hook ('>>>save ...')")


if __name__ == "__main__":
    main()
