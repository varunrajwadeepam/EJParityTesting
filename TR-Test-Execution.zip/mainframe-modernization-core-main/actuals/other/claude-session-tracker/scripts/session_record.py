#!/usr/bin/env python3
"""
Per-session statistics ledger: ~/.claude/all-sessions-stat.json

One record per Claude Code session, keyed by session_id:
  - kept current by statusline.py (update_stats), which already computes the stats;
  - marked with a work-id and phase by the UserPromptSubmit hook (this file run as
    `session_record.py hook`), when the user types
        >>>save work-id=ABC123 phase=asd789
    The prompt is blocked, so it never reaches the model and adds nothing to the
    session's context; the reply is shown to the user only.
  - frozen into "checkpoints" by `>>>save checkpoint`, which first recomputes the
    stats from the transcript so the copy is current, not as of the last refresh.

Marks survive later stat updates: update_stats never touches work_id/work_phase.

Concurrency (several chats at once, each with its own status line process):
  - A read that fails is NEVER treated as "the ledger is empty". That mistake
    would write an empty ledger over the real one and lose every session and
    checkpoint, so _load() raises LedgerUnavailable instead and callers abort.
  - The write lock is an OS lock on all-sessions-stat.json.lock (msvcrt/fcntl).
    The OS releases it when its holder exits or is killed, so there is no
    "stale lock" to detect or take over - and no takeover race.
  - Windows refuses to swap a file another process has open, and refuses to open
    one mid-swap, so every read and every swap is retried with jittered backoff.
  - A per-session fingerprint file under ~/.claude/stat-cache/ lets an idle
    session skip the shared write entirely.
  - Writes are coalesced: at most one per MIN_WRITE_INTERVAL_SEC per session.
  - Marks and checkpoints refuse to write at all unless they hold the lock.
  - The hook answers within HOOK_DEADLINE_SEC, well inside its 10 s timeout.
"""
import glob
import hashlib
import json
import os
import random
import re
import shutil
import sys
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

if os.name == "nt":
    import msvcrt

    def _lock_fd(fd):
        os.lseek(fd, 0, os.SEEK_SET)
        msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)  # raises OSError when held elsewhere

    def _unlock_fd(fd):
        os.lseek(fd, 0, os.SEEK_SET)
        msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
else:
    import fcntl

    def _lock_fd(fd):
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)

    def _unlock_fd(fd):
        fcntl.flock(fd, fcntl.LOCK_UN)

CLAUDE_DIR = os.path.join(os.path.expanduser("~"), ".claude")
LEDGER_PATH = os.path.join(CLAUDE_DIR, "all-sessions-stat.json")
LOCK_PATH = LEDGER_PATH + ".lock"
CACHE_DIR = os.path.join(CLAUDE_DIR, "stat-cache")

LOCK_WAIT_SEC = 3            # give up waiting rather than stall the status line
IO_RETRY_DELAYS = (0.02, 0.05, 0.1, 0.2, 0.35, 0.5)
BACKUP_MIN_AGE_SEC = 300     # keep one recovery copy, refreshed at most this often
STALE_TEMP_SEC = 60          # temp files this old belong to a killed writer
# Below the status line's 10 s refreshInterval, so a regular refresh is never
# coalesced away; only bursts of event-driven refreshes are.
MIN_WRITE_INTERVAL_SEC = float(os.environ.get("CLAUDE_STAT_MIN_WRITE_SEC", "8"))
VERIFY_INTERVAL_SEC = 60     # re-check against the real ledger at least this often
HOOK_DEADLINE_SEC = 6        # the hook always answers by then (its timeout is 10 s)
CHECKPOINT_RECOMPUTE_SEC = 3  # budget for re-reading the transcript on checkpoint
SEND_TIMEOUT_SEC = 4         # HTTP budget, inside the hook deadline
SAVE_PREFIX = ">>>save"

# Accepted spellings of the two mark keys.
WORK_ID_KEYS = {"work-id", "work_id", "workid", "id"}
PHASE_KEYS = {"phase", "work-phase", "work_phase"}

# Fields a stat refresh must never overwrite.
_PROTECTED_KEYS = ("work_id", "work_phase", "marked_at", "first_seen", "session_id",
                   "checkpoint", "checkpoint_at", "last_updated")


class LedgerUnavailable(Exception):
    """The ledger exists but could not be read or written right now."""


class LedgerBusy(Exception):
    """Another process holds the write lock."""


def _now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _backup_path():
    return LEDGER_PATH + ".bak"


def _sleep(attempt):
    # Jitter so several status lines waking on the same tick do not keep
    # colliding in lockstep.
    base = IO_RETRY_DELAYS[min(attempt, len(IO_RETRY_DELAYS) - 1)]
    time.sleep(base * (0.5 + random.random()))


class _Lock:
    """Exclusive OS lock on LOCK_PATH. `held` says whether it was acquired.

    The lock file itself is never deleted; only the lock on it matters, and the
    OS drops that the moment the holding process ends, however it ends.
    """

    def __enter__(self):
        deadline = time.time() + LOCK_WAIT_SEC
        attempt = 0
        self.held = False
        self.fd = None
        while True:
            try:
                if self.fd is None:
                    self.fd = os.open(LOCK_PATH, os.O_RDWR | os.O_CREAT)
                _lock_fd(self.fd)
                self.held = True
                return self
            except OSError:
                if time.time() > deadline:
                    return self
                _sleep(attempt)
                attempt += 1

    def __exit__(self, *exc):
        if self.fd is None:
            return
        if self.held:
            try:
                _unlock_fd(self.fd)
            except OSError:
                pass
        try:
            os.close(self.fd)
        except OSError:
            pass


def _read_json(path):
    """(data, status) with status one of "ok", "missing", "unreadable"."""
    for attempt in range(len(IO_RETRY_DELAYS)):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f), "ok"
        except FileNotFoundError:
            return None, "missing"
        except (OSError, ValueError):
            # Windows swap collision, antivirus, search indexer, or a half-read
            # file. All transient; a genuine problem survives the retries.
            _sleep(attempt)
    return None, "unreadable"


def _fresh():
    # "sessions": the live record per session, kept current by the status line.
    # "checkpoints": frozen copies taken by ">>>save checkpoint", never updated.
    return {"schema": 1, "sessions": {}, "checkpoints": []}


def _valid(data):
    return isinstance(data, dict) and isinstance(data.get("sessions"), dict)


def _load():
    """The ledger, or LedgerUnavailable.

    Only a ledger that is genuinely absent (and has no usable backup) yields an
    empty one. An unreadable or malformed ledger raises, because saving on top
    of a wrongly-empty load would destroy every other session's record.
    """
    data, status = _read_json(LEDGER_PATH)
    if status == "ok" and _valid(data):
        if not isinstance(data.get("checkpoints"), list):
            data["checkpoints"] = []
        return data

    backup, backup_status = _read_json(_backup_path())
    if backup_status == "ok" and _valid(backup):
        if not isinstance(backup.get("checkpoints"), list):
            backup["checkpoints"] = []
        if status == "missing":
            return backup  # ledger lost; carry on from the backup
        raise LedgerUnavailable(
            "ledger unreadable/malformed; backup holds {} session(s) - "
            "inspect {} before it is overwritten".format(len(backup["sessions"]), LEDGER_PATH))
    if status == "missing" and backup_status == "missing":
        return _fresh()  # first ever run
    raise LedgerUnavailable("cannot read {} (status: {})".format(LEDGER_PATH, status))


def _refresh_backup():
    """Keep one recent recovery copy, at most once every BACKUP_MIN_AGE_SEC."""
    backup = _backup_path()
    try:
        if os.path.exists(backup) and time.time() - os.path.getmtime(backup) < BACKUP_MIN_AGE_SEC:
            return
        if not os.path.exists(LEDGER_PATH):
            return
        tmp = backup + ".tmp-{}".format(os.getpid())
        try:
            shutil.copyfile(LEDGER_PATH, tmp)
            os.replace(tmp, backup)
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)
    except OSError:
        pass  # a missing backup must never stop a real write


def _sweep_temps():
    """Remove temp files left by writers that were killed mid-write."""
    patterns = (LEDGER_PATH + ".tmp-*", _backup_path() + ".tmp-*",
                os.path.join(CACHE_DIR, "*.tmp-*"))
    cutoff = time.time() - STALE_TEMP_SEC
    for pattern in patterns:
        for path in glob.glob(pattern):
            try:
                if os.path.getmtime(path) < cutoff:
                    os.remove(path)
            except OSError:
                pass


def _save(data):
    """Write the ledger atomically; never leave a temp file behind."""
    tmp = LEDGER_PATH + ".tmp-{}".format(os.getpid())
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        _refresh_backup()
        for attempt in range(len(IO_RETRY_DELAYS)):
            try:
                os.replace(tmp, LEDGER_PATH)
                break
            except OSError:
                # Another process has the ledger open for reading: retry.
                _sleep(attempt)
        else:
            raise LedgerUnavailable("could not replace {} (still in use)".format(LEDGER_PATH))
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except OSError:
            pass
    _sweep_temps()


# ---------------------------------------------------------------- fingerprints
# A tiny per-session file recording what this session last wrote. Only that
# session's own processes touch it, so it is contention-free, and it lets an
# idle session decide "nothing changed" without writing the shared ledger.

def _cache_path(session_id):
    safe = re.sub(r"[^A-Za-z0-9._-]", "_", session_id)[:120]
    return os.path.join(CACHE_DIR, safe + ".json")


def _fingerprint(stats):
    blob = json.dumps(stats, sort_keys=True, default=str).encode("utf-8", "replace")
    return hashlib.sha1(blob).hexdigest()


def _read_cache(session_id):
    data, status = _read_json(_cache_path(session_id))
    return data if status == "ok" and isinstance(data, dict) else None


def _write_cache(session_id, fingerprint, written_at=None):
    """Record the fingerprint; `written_at` is when a ledger write started."""
    path = _cache_path(session_id)
    tmp = path + ".tmp-{}".format(os.getpid())
    try:
        os.makedirs(CACHE_DIR, exist_ok=True)
        previous = _read_cache(session_id) or {}
        entry = {
            "fp": fingerprint,
            "verified_at": time.time(),
            "written_at": written_at if written_at is not None else previous.get("written_at", 0),
        }
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(entry, f)
        os.replace(tmp, path)
    except OSError:
        pass  # the cache is an optimisation; losing it only costs a read
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except OSError:
            pass


def _drop_cache(session_id):
    try:
        os.remove(_cache_path(session_id))
    except OSError:
        pass


# ---------------------------------------------------------------------- public

def _entry(data, session_id):
    entry = data["sessions"].get(session_id)
    if entry is None:
        entry = {
            "session_id": session_id,
            "work_id": "",
            "work_phase": "",
            "marked_at": "",
            "first_seen": _now(),
            "checkpoint": False,
            "checkpoint_at": "",
        }
        data["sessions"][session_id] = entry
    return entry


def _unchanged(entry, stats):
    """True when merging `stats` into `entry` would change nothing."""
    return (entry is not None
            and "checkpoint" in entry and "checkpoint_at" in entry  # old record: upgrade it
            and all(entry.get(k) == v for k, v in stats.items()))


def update_stats(session_id, stats):
    """Merges the latest stats into the session's record; marks are preserved.

    Called by the status line every few seconds, so it is built to do as little
    as possible: an idle session touches only its own fingerprint file, and any
    failure is given up on rather than risking the shared ledger.
    """
    if not session_id:
        return
    stats = {k: v for k, v in stats.items() if k not in _PROTECTED_KEYS}
    fingerprint = _fingerprint(stats)
    cache = _read_cache(session_id) or {}
    now = time.time()

    # Fast path: same stats as last time, and the ledger was verified recently.
    if (cache.get("fp") == fingerprint
            and now - cache.get("verified_at", 0) < VERIFY_INTERVAL_SEC):
        return

    # Coalesce: the stats moved, but this session wrote very recently. Skipping
    # leaves the fingerprint stale, so the next refresh tries again.
    if (cache.get("fp") != fingerprint
            and now - cache.get("written_at", 0) < MIN_WRITE_INTERVAL_SEC):
        return

    try:
        current = _load()
    except LedgerUnavailable:
        return
    if _unchanged(current["sessions"].get(session_id), stats):
        _write_cache(session_id, fingerprint)
        return

    with _Lock() as lock:
        if not lock.held:
            return  # skip this refresh rather than risk a lost update
        try:
            data = _load()
        except LedgerUnavailable:
            return
        # Re-check under the lock: another process may have written meanwhile.
        if _unchanged(data["sessions"].get(session_id), stats):
            _write_cache(session_id, fingerprint)
            return
        entry = _entry(data, session_id)
        entry.update(stats)
        entry.setdefault("checkpoint", False)  # records written before checkpoints existed
        entry.setdefault("checkpoint_at", "")
        entry["last_updated"] = _now()
        try:
            _save(data)
        except (LedgerUnavailable, OSError):
            return
    # `now` (when this run started), not the end of the write: a refresh
    # exactly one refreshInterval later must not fall inside the interval.
    _write_cache(session_id, fingerprint, written_at=now)


def get_marks(session_id):
    """(work_id, work_phase) for the session, empty strings when unknown."""
    try:
        entry = _load()["sessions"].get(session_id) or {}
    except LedgerUnavailable:
        return "", ""
    return entry.get("work_id", ""), entry.get("work_phase", "")


def mark(session_id, work_id=None, phase=None, extra=None):
    """Sets the marks. Raises LedgerBusy / LedgerUnavailable rather than
    writing without the lock, which could lose another session's update."""
    with _Lock() as lock:
        if not lock.held:
            raise LedgerBusy("another session is writing the ledger")
        data = _load()
        entry = _entry(data, session_id)
        if work_id is not None:
            entry["work_id"] = work_id
        if phase is not None:
            entry["work_phase"] = phase
        entry["marked_at"] = _now()
        for key, value in (extra or {}).items():
            entry.setdefault(key, value)
        _save(data)
        result = dict(entry)
    _drop_cache(session_id)  # make the next refresh re-verify against the ledger
    return result


def _recompute(transcript_path):
    """Fresh stats from the transcript, or None if that takes too long or fails.

    Runs in a daemon thread so a huge transcript cannot hold the hook past its
    deadline; on timeout the checkpoint falls back to the ledger's values.
    """
    if not transcript_path or not os.path.isfile(transcript_path):
        return None
    box = {}

    def work():
        try:
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            import session_stats
            box["stats"] = session_stats.collect(transcript_path)
            box["fields"] = session_stats.ledger_fields(box["stats"])
        except Exception:
            pass

    thread = threading.Thread(target=work, daemon=True)
    thread.start()
    thread.join(CHECKPOINT_RECOMPUTE_SEC)
    if thread.is_alive() or "fields" not in box:
        return None
    fields = dict(box["fields"])
    if fields.get("active_sec") is None:
        fields.pop("active_sec")
    if not box["stats"].get("totals"):
        fields.pop("tokens")
    if box["stats"].get("cost_state_usd") is not None:
        fields["cost_state_usd"] = box["stats"]["cost_state_usd"]
    return fields


def checkpoint(session_id, transcript_path=None):
    """Freezes a copy of the session's live record into "checkpoints".

    The stats are recomputed from the transcript first, so the copy is as of
    now rather than as of the status line's latest write. Returns (copy, None),
    or (None, error) when the session has no record or no work-id yet.
    """
    if not transcript_path:
        try:
            entry = _load()["sessions"].get(session_id) or {}
            transcript_path = entry.get("transcript_path")
        except LedgerUnavailable:
            transcript_path = None
    fresh = _recompute(transcript_path)  # outside the lock: may take a second

    with _Lock() as lock:
        if not lock.held:
            raise LedgerBusy("another session is writing the ledger")
        data = _load()
        entry = data["sessions"].get(session_id)
        if not entry:
            return None, "this session has no stat record yet"
        if not entry.get("work_id"):
            return None, "work-id is not set - set it first with {} work-id=...".format(SAVE_PREFIX)
        if fresh:
            fresh = dict(fresh)
            cost_state = fresh.pop("cost_state_usd", None)
            entry.update(fresh)
            # The transcript's cost snapshot can lag the live cost the status
            # line writes, so it may only ever raise the recorded cost.
            if cost_state is not None and cost_state > (entry.get("cost_usd") or 0):
                entry["cost_usd"] = cost_state
            entry["last_updated"] = _now()
        copy = dict(entry)
        copy["tokens"] = dict(entry.get("tokens") or {})
        copy["checkpoint"] = True
        copy["checkpoint_at"] = _now()
        data["checkpoints"].append(copy)
        _save(data)
        copy["checkpoint_no"] = sum(
            1 for c in data["checkpoints"] if c.get("session_id") == session_id)
        copy["recomputed"] = bool(fresh)
    _drop_cache(session_id)
    return copy, None


# One `key=value` pair: the value is a "quoted string" or runs to the next
# whitespace. No spaces around '=' - "work-id = A" is rejected, not misread.
_PAIR = re.compile(r'([\w-]+)=(?:"([^"]*)"|([^\s"]*))')


def parse_save(prompt):
    """Returns (work_id, phase, error) for a '>>>save ...' prompt.

    No parameters at all clears both marks. A key that is given is rewritten,
    an empty value (`work-id=`) included - that clears just that mark. A key
    that is not given (None) keeps its current value. Anything that is not a
    clean key=value pair is an error, so a typo is never half-applied.
    """
    args = prompt.strip()[len(SAVE_PREFIX):].strip()
    if not args:
        return "", "", None
    values = {}
    pos = 0
    while pos < len(args):
        m = _PAIR.match(args, pos)
        if not m or (m.end() < len(args) and not args[m.end()].isspace()):
            bad = args[pos:].split()[0]
            return None, None, "cannot parse '{}' (expected key=value, no spaces around '=')".format(bad)
        key = m.group(1).lower()
        value = (m.group(2) if m.group(2) is not None else m.group(3)).strip()
        if key in WORK_ID_KEYS:
            name = "work-id"
        elif key in PHASE_KEYS:
            name = "phase"
        else:
            return None, None, "unknown key '{}'".format(m.group(1))
        if name in values:
            return None, None, "{} given twice".format(name)
        if re.search(r"[,;=]", value):
            return None, None, "invalid character in {} value '{}'".format(name, value)
        values[name] = value
        pos = m.end()
        while pos < len(args) and args[pos].isspace():
            pos += 1
    return values.get("work-id"), values.get("phase"), None


def _handle_save(payload, prompt):
    """The user-facing reply for a '>>>save ...' prompt. Never raises."""
    session_id = payload.get("session_id") or ""
    if not isinstance(session_id, str):
        session_id = ""
    usage = "usage: {} work-id=ABC123 phase=asd789 | {} checkpoint | {} save [folder] | {} send | {}".format(
        SAVE_PREFIX, SAVE_PREFIX, SAVE_PREFIX, SAVE_PREFIX, SAVE_PREFIX)
    args = prompt.strip()[len(SAVE_PREFIX):].strip()
    try:
        words = args.lower().split()
        if words and words[0] == "checkpoint":
            if len(words) > 1:
                return "checkpoint NOT saved - checkpoint takes no other arguments. " + usage
            if not session_id:
                return "checkpoint NOT saved - no session id"
            transcript = payload.get("transcript_path")
            copy, error = checkpoint(session_id, transcript if isinstance(transcript, str) else None)
            if error:
                return "checkpoint NOT saved - " + error
            reason = "checkpoint #{} saved: work-id={} phase={}".format(
                copy["checkpoint_no"], copy.get("work_id") or "-", copy.get("work_phase") or "-")
            if isinstance(copy.get("cost_usd"), (int, float)):
                reason += ", cost ${:.4f}".format(copy["cost_usd"])
            if not copy.get("recomputed"):
                reason += " (stats as of the last status-line refresh)"
            return reason

        if words and words[0] == "send":
            if len(words) > 1:
                return "NOT sent - send takes no arguments. " + usage
            if not session_id:
                return "NOT sent - no session id"
            try:
                reply, record, recomputed = send_session(session_id, payload)
            except ValueError as exc:
                return "NOT sent - {}".format(exc)
            reason = "session sent to server ({}): work-id={} phase={}".format(
                reply.get("result", "ok"), record.get("work_id"), record.get("work_phase") or "-")
            if isinstance(record.get("cost_usd"), (int, float)):
                reason += ", cost ${:.4f}".format(record["cost_usd"])
            if not recomputed:
                reason += " (stats as of the last status-line refresh)"
            return reason

        if words and words[0] == "save":
            if not session_id:
                return "session stat file NOT written - no session id"
            folder = args[len("save"):].strip()
            if len(folder) >= 2 and folder[0] == folder[-1] and folder[0] in "\"'":
                folder = folder[1:-1].strip()
            path, record, recomputed = export_session(session_id, folder or None, payload)
            reason = "session stat written to {}".format(path)
            if isinstance(record.get("cost_usd"), (int, float)):
                reason += " (cost ${:.4f})".format(record["cost_usd"])
            if not recomputed:
                reason += " (stats as of the last status-line refresh)"
            return reason

        work_id, phase, error = parse_save(prompt)
        if error or not session_id:
            return "session stat NOT saved - {}. {}".format(error or "no session id", usage)
        entry = mark(session_id, work_id, phase, extra={
            "project_dir": os.environ.get("CLAUDE_PROJECT_DIR") or payload.get("cwd") or "",
            "transcript_path": payload.get("transcript_path") or "",
        })
        if not entry.get("work_id") and not entry.get("work_phase"):
            return "session marks cleared"
        reason = "session stat saved: work-id={} phase={}".format(
            entry.get("work_id") or "-", entry.get("work_phase") or "-")
        if isinstance(entry.get("cost_usd"), (int, float)):
            reason += " (cost so far ${:.4f})".format(entry["cost_usd"])
        return reason
    except LedgerBusy:
        return "not saved - the ledger is busy (another chat is writing). Try again."
    except LedgerUnavailable as exc:
        return "not saved - {}".format(exc)
    except Exception as exc:  # never let the prompt reach the model
        return "not saved - unexpected error: {}: {}".format(type(exc).__name__, exc)


def build_record(session_id, payload=None):
    """The session's current stats: the ledger record, refreshed from the
    transcript when that is quick enough. Returns (record, recomputed)."""
    payload = payload or {}
    if re.search(r'[\/:*?"<>|]', session_id):
        raise ValueError("invalid session id")
    try:
        record = dict(_load()["sessions"].get(session_id) or {})
    except LedgerUnavailable:
        record = {}
    record.setdefault("session_id", session_id)
    transcript = (record.get("transcript_path") or payload.get("transcript_path") or "")
    if transcript:
        record["transcript_path"] = transcript
    fresh = _recompute(transcript)
    if fresh:
        fresh = dict(fresh)
        cost_state = fresh.pop("cost_state_usd", None)
        record.update(fresh)
        if cost_state is not None and cost_state > (record.get("cost_usd") or 0):
            record["cost_usd"] = cost_state
    record["saved_at"] = _now()
    return record, bool(fresh)


def server_url():
    """Base URL of the status-works service: STATUS_WORKS_URL, which Claude Code
    takes from the "env" block of settings.json (read from there directly too,
    in case the hook was started without it)."""
    url = os.environ.get("STATUS_WORKS_URL")
    if not url:
        try:
            with open(os.path.join(CLAUDE_DIR, "settings.json"), encoding="utf-8") as f:
                url = (json.load(f).get("env") or {}).get("STATUS_WORKS_URL")
        except (OSError, ValueError, AttributeError):
            url = None
    return url.strip().rstrip("/") if isinstance(url, str) and url.strip() else None


def send_session(session_id, payload=None):
    """POSTs the current session's stats to <server>/sessions.
    Returns (server_reply, record, recomputed). Raises ValueError with a
    user-facing message when it cannot be sent."""
    url = server_url()
    if not url:
        raise ValueError('server url not configured - add "STATUS_WORKS_URL" to the "env" '
                         'block of ~/.claude/settings.json')
    record, recomputed = build_record(session_id, payload)
    if not (record.get("work_id") or "").strip():
        raise ValueError("this session has no work-id - set it first with {} work-id=...".format(SAVE_PREFIX))
    body = json.dumps(record, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url + "/sessions", data=body, method="POST",
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=SEND_TIMEOUT_SEC) as resp:
            reply = json.loads(resp.read().decode("utf-8") or "{}")
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")[:200]
        raise ValueError("server answered HTTP {}: {}".format(exc.code, detail))
    except (urllib.error.URLError, OSError) as exc:
        raise ValueError("cannot reach {}: {}".format(url, getattr(exc, "reason", exc)))
    return reply, record, recomputed


def export_session(session_id, folder=None, payload=None):
    """Writes the session's current stats to <folder>/<session-id>.json.

    The folder defaults to ~/.claude; an existing file is simply replaced.
    Returns (path, record, recomputed).
    """
    folder = os.path.abspath(os.path.expanduser(folder)) if folder else CLAUDE_DIR
    record, recomputed = build_record(session_id, payload)
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, session_id + ".json")
    tmp = "{}.{}.tmp".format(path, os.getpid())
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(record, f, indent=2, ensure_ascii=False)
    for delay in IO_RETRY_DELAYS + (None,):
        try:
            os.replace(tmp, path)
            break
        except OSError:
            if delay is None:
                try:
                    os.remove(tmp)
                except OSError:
                    pass
                raise
            time.sleep(delay)
    return path, record, recomputed


def _block(reason):
    # Blocking erases the prompt - it is never sent to the model - and the
    # reason is shown to the user only.
    sys.stdout.write(json.dumps({"decision": "block", "reason": reason}))
    sys.stdout.flush()


def run_hook():
    started = time.time()
    box = {}

    def read():
        try:
            # Raw bytes decoded as UTF-8: text-mode stdin would use the Windows
            # code page and garble any non-ASCII work-id, phase or path.
            box["raw"] = sys.stdin.buffer.read().decode("utf-8", "replace")
        except Exception:
            box["raw"] = ""

    reader = threading.Thread(target=read, daemon=True)
    reader.start()
    reader.join(HOOK_DEADLINE_SEC)
    raw = box.get("raw")
    if raw is None:
        os._exit(0)  # stdin never closed: cannot tell whose prompt it is

    try:
        payload = json.loads(raw or "{}")
    except ValueError:
        payload = None
    if not isinstance(payload, dict):
        # Unreadable payload. If it looks like a save, block it anyway, so
        # the ">>>save ..." text can never fall through to the model.
        if SAVE_PREFIX in raw.lower():
            _block("not saved - could not read the hook payload")
        return 0
    prompt = payload.get("prompt")
    if not isinstance(prompt, str) or not prompt.lstrip().lower().startswith(SAVE_PREFIX):
        return 0  # not ours: print nothing, so the prompt goes through untouched

    worker = threading.Thread(target=lambda: box.__setitem__("reason", _handle_save(payload, prompt)),
                              daemon=True)
    worker.start()
    worker.join(max(0.5, HOOK_DEADLINE_SEC - (time.time() - started)))
    if worker.is_alive():
        # Answer before Claude Code's hook timeout, which would let the prompt
        # through. Exiting drops the lock; the ledger swap is atomic, so the
        # save either happened completely or not at all.
        _block("NOT confirmed - timed out after {} s. Check the work:/phase: marks "
               "in the status line and retry if they are wrong.".format(HOOK_DEADLINE_SEC))
        os._exit(0)
    _block(box.get("reason") or "not saved - unexpected error")
    return 0


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "hook":
        sys.exit(run_hook())
    print(__doc__)
