#!/usr/bin/env python3
import sys
import os
import json
import threading

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import session_stats

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# Same guard as statusline.py: an orphaned run whose stdin is never closed
# must exit rather than wait forever.
STDIN_DEADLINE_SEC = 5


def _read_stdin(deadline_sec):
    box = {}

    def reader():
        try:
            # Raw UTF-8, not the Windows code page (see statusline.py).
            box["raw"] = sys.stdin.buffer.read().decode("utf-8", "replace")
        except Exception:
            box["raw"] = ""

    thread = threading.Thread(target=reader, daemon=True)
    thread.start()
    thread.join(deadline_sec)
    if thread.is_alive():
        sys.stdout.flush()
        os._exit(0)
    return box.get("raw") or ""


raw = _read_stdin(STDIN_DEADLINE_SEC)

data = None
if raw:
    try:
        data = json.loads(raw)
    except Exception:
        data = None

if not isinstance(data, dict) or not isinstance(data.get("tasks"), list) or not data["tasks"]:
    sys.exit(0)

ESC = "\x1b"
GRAY = ESC + "[2;37m"
TEAL = ESC + "[1;36m"
ORANGE = ESC + "[0;33m"
GREEN_B = ESC + "[1;32m"
PURPLE_B = ESC + "[1;35m"
RESET = ESC + "[0m"
SEP = " " + GRAY + "|" + RESET + " "


def format_model_id(model_id):
    if not model_id or not isinstance(model_id, str):
        return ""
    short = model_id.rsplit(".", 1)[-1]
    if short.startswith("claude-"):
        short = short[len("claude-"):]
    return short


def format_duration(total_sec):
    total_sec = max(0, int(total_sec))
    return "{}m{:02d}s".format(total_sec // 60, total_sec % 60)


def format_tokens(n):
    n = float(n)
    if n >= 1_000_000:
        return "{:.1f}M".format(n / 1_000_000)
    if n >= 1_000:
        return "{:.1f}k".format(n / 1000)
    return str(int(n))


def render(task, session_dir):
    name = task.get("name") or task.get("label") or task.get("type") or ""
    content = TEAL + str(name) + RESET

    status = task.get("status")
    if status:
        content += SEP + ORANGE + str(status) + RESET

    model_short = format_model_id(task.get("model"))
    if model_short:
        content += SEP + GRAY + model_short + RESET

    context_window_size = task.get("contextWindowSize")
    token_count = task.get("tokenCount")
    try:
        if context_window_size and token_count:
            pct = round((float(token_count) / float(context_window_size)) * 100)
            content += SEP + GRAY + "ctx:" + RESET + GREEN_B + str(pct) + "%" + RESET
        elif token_count:
            content += SEP + GRAY + "tok:" + RESET + GREEN_B + str(token_count) + RESET
    except (TypeError, ValueError):
        pass

    # Each subagent's own transcript lives at <session_dir>/subagents/agent-<task.id>.jsonl.
    task_id = task.get("id")
    if session_dir and task_id:
        path = os.path.join(session_dir, "subagents", "agent-{}.jsonl".format(task_id))
        sub = session_stats.scan_subagent(path) if os.path.isfile(path) else None
        if sub:
            if sub["active_ms"] is not None:
                # Total over every run of this agent; when it was sent a
                # follow-up after finishing (a coordinator's "round 2"), also
                # the current run, which is what is ticking now.
                time_text = format_duration(sub["active_ms"] / 1000.0)
                if sub["runs"] > 1:
                    time_text += " (run {}: {})".format(sub["runs"], format_duration(sub["run_ms"] / 1000.0))
                content += SEP + GRAY + "time:" + RESET + TEAL + time_text + RESET
            content += SEP + GRAY + "turns:" + RESET + GREEN_B + str(sub["turns"]) + RESET
            content += SEP + GRAY + "tools:" + RESET + ORANGE + str(sub["tools"]) + RESET
            content += SEP + GRAY + "tokens:" + RESET + PURPLE_B + format_tokens(sub["tokens"]) + RESET
            content += SEP + GRAY + "compacts:" + RESET + ORANGE + str(sub["compacts"]) + RESET
    return task_id, content


main_transcript = data.get("transcript_path")
session_dir = None
if isinstance(main_transcript, str) and main_transcript:
    session_dir = main_transcript[:-len(".jsonl")] if main_transcript.endswith(".jsonl") else main_transcript

for task in data["tasks"]:
    if not isinstance(task, dict):
        continue
    try:
        task_id, content = render(task, session_dir)
    except Exception:
        continue
    print(json.dumps({"id": task_id, "content": content}, ensure_ascii=False))
