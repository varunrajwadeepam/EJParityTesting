#!/usr/bin/env python3
"""
Spending report over ~/.claude/all-sessions-stat.json (see session_record.py).

    usage_report.py                 every session marked with a work-id
    usage_report.py ABC123 XYZ9     only those work-ids (case-insensitive)
    usage_report.py --all           also the sessions never marked (work-id "-")

Prints Markdown: one table of sessions grouped by work-id and phase, then a
per-work-id summary with a grand total.
"""
import json
import os
import sys
import time

LEDGER_PATH = os.path.join(os.path.expanduser("~"), ".claude", "all-sessions-stat.json")


def fmt_tokens(n):
    n = float(n or 0)
    if n >= 1_000_000:
        return "{:.1f}M".format(n / 1_000_000)
    if n >= 1_000:
        return "{:.1f}k".format(n / 1000)
    return str(int(n))


def fmt_time(sec):
    sec = int(sec or 0)
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    return "{}h{:02d}m".format(h, m) if h else "{}m{:02d}s".format(m, s)


def fmt_cost(c):
    return "${:,.2f}".format(c or 0)


def tokens_total(t):
    t = t or {}
    return sum(t.get(k) or 0 for k in ("in", "out", "cw", "cr"))


def table(headers, rows, right=()):
    out = ["| " + " | ".join(headers) + " |",
           "|" + "|".join("---:" if i in right else "---" for i in range(len(headers))) + "|"]
    out += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(out)


def read_ledger(path):
    """The ledger, retrying briefly.

    A status line writing the ledger swaps the file into place, and Windows
    refuses to open it during that swap - so a single failed read means
    "try again in a moment", not "no data".
    """
    last = None
    for delay in (0, 0.05, 0.1, 0.2, 0.35):
        if delay:
            time.sleep(delay)
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except FileNotFoundError:
            raise
        except (OSError, ValueError) as exc:
            last = exc
    raise last


def main(argv):
    include_untagged = "--all" in argv
    wanted = {a.lower() for a in argv if not a.startswith("--")}

    try:
        ledger = read_ledger(LEDGER_PATH)
        sessions = list((ledger.get("sessions") or {}).values())
        checkpoints = [c for c in (ledger.get("checkpoints") or []) if isinstance(c, dict)]
    except FileNotFoundError:
        print("No usage ledger yet ({}).".format(LEDGER_PATH))
        return 0
    except Exception as exc:
        print("Cannot read {}: {}".format(LEDGER_PATH, exc))
        return 1

    picked = []
    for s in sessions:
        wid = (s.get("work_id") or "").strip()
        if wanted:
            if wid.lower() not in wanted:
                continue
        elif not wid and not include_untagged:
            continue
        picked.append(s)

    if not picked:
        scope = ", ".join(sorted(wanted)) if wanted else "any work-id"
        print("No sessions found for {}.".format(scope))
        return 0

    picked.sort(key=lambda s: ((s.get("work_id") or "~").lower(),
                               (s.get("work_phase") or "").lower(),
                               s.get("started_at") or s.get("first_seen") or ""))

    rows = []
    for s in picked:
        t = s.get("tokens") or {}
        rows.append([
            s.get("work_id") or "-",
            s.get("work_phase") or "-",
            (s.get("started_at") or s.get("first_seen") or "")[:16].replace("T", " "),
            os.path.basename((s.get("project_dir") or "").rstrip("/\\")) or "-",
            (s.get("session_id") or "")[:8],
            s.get("model") or "-",
            fmt_cost(s.get("cost_usd")),
            fmt_time(s.get("active_sec")),
            s.get("turns") or 0,
            s.get("tools") or 0,
            fmt_tokens(t.get("in")), fmt_tokens(t.get("out")),
            fmt_tokens(t.get("cw")), fmt_tokens(t.get("cr")),
        ])
    print("## Sessions\n")
    print(table(["Work-id", "Phase", "Started (UTC)", "Project", "Session", "Model",
                 "Cost", "Active", "Turns", "Tools", "In", "Out", "Cache-w", "Cache-r"],
                rows, right=range(6, 14)))

    summary = {}
    for s in picked:
        key = s.get("work_id") or "-"
        agg = summary.setdefault(key, {"sessions": 0, "phases": set(), "cost": 0.0,
                                       "active": 0, "turns": 0, "tokens": 0})
        agg["sessions"] += 1
        if s.get("work_phase"):
            agg["phases"].add(s["work_phase"])
        agg["cost"] += s.get("cost_usd") or 0
        agg["active"] += s.get("active_sec") or 0
        agg["turns"] += s.get("turns") or 0
        agg["tokens"] += tokens_total(s.get("tokens"))

    rows = [[k, a["sessions"], ", ".join(sorted(a["phases"])) or "-", fmt_cost(a["cost"]),
             fmt_time(a["active"]), a["turns"], fmt_tokens(a["tokens"])]
            for k, a in summary.items()]
    rows.append(["**Total**", sum(a["sessions"] for a in summary.values()), "",
                 "**" + fmt_cost(sum(a["cost"] for a in summary.values())) + "**",
                 fmt_time(sum(a["active"] for a in summary.values())),
                 sum(a["turns"] for a in summary.values()),
                 fmt_tokens(sum(a["tokens"] for a in summary.values()))])
    print("\n## By work-id\n")
    print(table(["Work-id", "Sessions", "Phases", "Cost", "Active", "Turns", "Tokens"],
                rows, right=(1, 3, 4, 5, 6)))

    # Checkpoints are frozen copies of the same sessions taken by
    # ">>>save checkpoint" - listed, but never added to the totals above.
    cps = [c for c in checkpoints
           if (c.get("work_id") or "").lower() in wanted or (not wanted and c.get("work_id"))]
    if cps:
        cps.sort(key=lambda c: ((c.get("work_id") or "").lower(), c.get("checkpoint_at") or ""))
        rows = []
        for c in cps:
            t = c.get("tokens") or {}
            rows.append([
                c.get("work_id") or "-",
                c.get("work_phase") or "-",
                (c.get("checkpoint_at") or "")[:16].replace("T", " "),
                (c.get("session_id") or "")[:8],
                fmt_cost(c.get("cost_usd")),
                fmt_time(c.get("active_sec")),
                c.get("turns") or 0,
                c.get("tools") or 0,
                fmt_tokens(tokens_total(t)),
            ])
        print("\n## Checkpoints (frozen snapshots - not included in the totals)\n")
        print(table(["Work-id", "Phase", "Checkpoint (UTC)", "Session", "Cost", "Active",
                     "Turns", "Tools", "Tokens"], rows, right=range(4, 9)))
    return 0


if __name__ == "__main__":
    try:
        # errors="replace": one odd character in a record must not abort the report.
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    sys.exit(main(sys.argv[1:]))
