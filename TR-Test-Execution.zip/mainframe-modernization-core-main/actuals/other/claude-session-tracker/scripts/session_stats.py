#!/usr/bin/env python3
"""
Session statistics computed from a Claude Code transcript.

Shared by statusline.py (every refresh) and session_record.py (">>>save
checkpoint" recomputes them, so a checkpoint never freezes a value the status
line had not written yet). collect(transcript_path) is the entry point.
"""
import glob
import json
import os
from datetime import datetime, timezone

def count_tool_uses(entry):
    msg = entry.get("message")
    if not isinstance(msg, dict):
        return 0
    content = msg.get("content")
    if not isinstance(content, list):
        return 0
    return sum(1 for b in content if isinstance(b, dict) and b.get("type") == "tool_use")


def is_real_user_turn(entry):
    if entry.get("type") != "user":
        return False
    if entry.get("isMeta"):
        # Synthetic injections (e.g. skill content auto-loaded via the Skill
        # tool) are recorded as a "user" role message with plain text
        # content - not a tool_result, so the check below alone wouldn't
        # catch them - but Claude Code marks them isMeta: true, unlike a
        # genuine human-typed prompt.
        return False
    msg = entry.get("message")
    if not isinstance(msg, dict) or msg.get("role") != "user":
        return False
    content = msg.get("content")
    if isinstance(content, list) and content:
        if all(isinstance(b, dict) and b.get("type") == "tool_result" for b in content):
            return False
    if is_local_command(content):
        return False
    return True


def is_followup_message(entry):
    # A message sent to a subagent after its task prompt - by the coordinator
    # (SendMessage, e.g. "round 2") or by the user typing to it. It is recorded
    # isMeta, so is_real_user_turn skips it, but it is a new turn for that agent.
    origin = entry.get("origin")
    return (entry.get("type") == "user" and bool(entry.get("isMeta"))
            and isinstance(origin, dict) and origin.get("kind") in ("coordinator", "human"))


def is_local_command(content):
    # Local slash commands (/clear, /model, ...) and their output are recorded
    # as user entries, but they are neither a prompt nor model work.
    text = content if isinstance(content, str) else "".join(
        b.get("text", "") for b in content or [] if isinstance(b, dict))
    return text.lstrip().startswith(("<command-name>", "<local-command-"))


def add_usage(entry, usage_by_id):
    # One API response is written as several transcript lines (one per
    # content block) sharing a message id, each repeating the same usage
    # object - so usage must be taken once per message id, not per line.
    # Keep the last write, which carries the final output_tokens.
    msg = entry.get("message") or {}
    usage = msg.get("usage")
    if usage:
        key = msg.get("id") or entry.get("uuid") or id(entry)
        usage_by_id[key] = usage


def parse_ts(ts):
    if not ts:
        return None
    try:
        dt = datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        return None


def is_subagent_handback(entry):
    # A subagent ends its run by calling the SubagentHandback tool rather
    # than with a turn-ending text reply, and those writes usually carry
    # stop_reason null - so without this, a finished subagent never reaches
    # `waiting` and its trailing time keeps ticking until "now" forever.
    msg = entry.get("message")
    if not isinstance(msg, dict):
        return False
    content = msg.get("content")
    if not isinstance(content, list):
        return False
    return any(isinstance(b, dict) and b.get("type") == "tool_use"
               and b.get("name") == "SubagentHandback" for b in content)


def classify_for_active_time(entry):
    t = entry.get("type")
    if t == "assistant":
        if is_subagent_handback(entry):
            return "assistant_final"
        # A single logical response gets written to the transcript multiple
        # times as it streams in (same message id, growing content) - the
        # content blocks accumulate progressively, AND stop_reason itself
        # stays null on those in-progress writes, only getting set on a
        # later, separate write of the same id once the response is truly
        # complete. So null means "still streaming, unknown yet" - treat
        # it as ambiguous and leave `waiting` untouched, rather than either
        # tool_use or turn-ending. Checking content blocks instead (or
        # treating null as final) misclassifies in-progress writes as
        # turn-ending, which - especially for a subagent, which never gets
        # a user_real event to reset it - suppresses nearly all active time.
        msg = entry.get("message") or {}
        stop_reason = msg.get("stop_reason")
        if stop_reason is None:
            return "assistant_pending"
        return "assistant_tool" if stop_reason == "tool_use" else "assistant_final"
    if t == "user":
        # Any user entry that isn't purely tool results starts activity - not
        # only a human-typed prompt, but also isMeta injections that resume
        # the main thread on their own (a subagent's hand-back message, a
        # ScheduleWakeup firing). Counting only human prompts here leaves
        # `waiting` stuck and drops all the work those resumed turns do.
        msg = entry.get("message")
        if not isinstance(msg, dict) or msg.get("role") != "user":
            return "user_other"
        content = msg.get("content")
        if isinstance(content, list) and content and all(
                isinstance(b, dict) and b.get("type") == "tool_result" for b in content):
            return "user_other"
        # Local slash commands never start model work - ignore them entirely,
        # or one typed while idle would tick "until now" with nothing running.
        if is_local_command(content):
            return None
        return "user_start"
    return None


# No single gap between transcript events longer than this counts as active.
# Nothing legitimately runs that long without a transcript write (a Bash call
# times out at 10 min); a longer gap is a turn interrupted mid-tool and resumed
# later - e.g. closed overnight - which would otherwise count the whole break.
MAX_ACTIVE_GAP_MS = 30 * 60 * 1000.0


def compute_active_ms(path):
    result = compute_active(path)
    return None if result is None else result[0]


def compute_active(path):
    """
    (active_ms, run_ms, runs), or None if the transcript can't be read.

    "Active" time: model generation + tool execution, excluding the gap
    between a turn-ending assistant reply (no tool_use) and the next real
    user prompt - the part that could be an arbitrarily long human-thinking
    wait, or never end at all. If the transcript is still mid-turn (last
    event isn't a turn-ending reply), extends to "now" so it keeps ticking
    live instead of freezing while a tool is still running.

    A "run" starts at the first prompt and again at every prompt arriving
    after a turn-ending reply. run_ms is the active time of the latest run -
    for a subagent sent a follow-up after it finished, the current round.
    """
    active_ms = 0.0
    run_ms = 0.0
    runs = 0
    waiting = False
    last_ts = None
    last_kind = None
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except Exception:
                    continue
                kind = classify_for_active_time(entry)
                if kind is None:
                    continue
                ts = parse_ts(entry.get("timestamp"))
                if ts is None:
                    continue
                # Two turn-starting user entries in a row with no assistant
                # activity in between (a re-sent/queued prompt, or local slash
                # commands like /clear and /model) means nothing was running
                # during that gap.
                idle_gap = kind == "user_start" and last_kind == "user_start"
                if last_ts is None:
                    runs = 1
                else:
                    delta_ms = (ts - last_ts).total_seconds() * 1000.0
                    if (0 < delta_ms <= MAX_ACTIVE_GAP_MS
                            and not waiting and not idle_gap):
                        active_ms += delta_ms
                        run_ms += delta_ms
                    if kind == "user_start" and waiting:
                        runs += 1
                        run_ms = 0.0
                if kind == "assistant_final":
                    waiting = True
                elif kind == "user_start":
                    waiting = False
                last_ts = ts
                last_kind = kind
        if last_ts is not None and not waiting:
            trailing_ms = (datetime.now(timezone.utc) - last_ts).total_seconds() * 1000.0
            if 0 < trailing_ms <= MAX_ACTIVE_GAP_MS:
                active_ms += trailing_ms
                run_ms += trailing_ms
    except Exception:
        return None
    return active_ms, run_ms, runs


def first_timestamp(path):
    """When the session really started: its transcript's first timestamped entry."""
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                try:
                    ts = json.loads(line).get("timestamp")
                except Exception:
                    continue
                if ts:
                    return ts
    except Exception:
        pass
    return None


TOKEN_KEYS = ("input_tokens", "output_tokens",
              "cache_creation_input_tokens", "cache_read_input_tokens")
SNAPSHOT_KEYS = ("inputTokens", "outputTokens",
                 "cacheCreationInputTokens", "cacheReadInputTokens")


def sum_usage(usage_by_id):
    return {k: sum(u.get(k) or 0 for u in usage_by_id.values()) for k in TOKEN_KEYS}


def scan_subagent(path, usage_by_id=None):
    """One subagent transcript: turns, tools, compacts, usage, active time.

    turns = its task prompt plus every follow-up message it was sent (see
    is_followup_message); its isMeta system reminders are not turns. Usage is
    added to `usage_by_id` (a fresh dict when not given), keyed by message id.
    Returns None if the file can't be read.
    """
    usage = {} if usage_by_id is None else usage_by_id
    result = {"turns": 0, "tools": 0, "compacts": 0, "usage_by_id": usage,
              "active_ms": None, "run_ms": None, "runs": 0}
    own = {}
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except Exception:
                    continue
                if entry.get("type") == "assistant":
                    result["tools"] += count_tool_uses(entry)
                    add_usage(entry, own)
                elif is_real_user_turn(entry) or is_followup_message(entry):
                    result["turns"] += 1
                elif entry.get("type") == "system" and entry.get("subtype") == "compact_boundary":
                    result["compacts"] += 1
    except Exception:
        return None
    usage.update(own)
    result["tokens"] = sum(sum_usage(own).values())
    active = compute_active(path)
    if active is not None:
        result["active_ms"], result["run_ms"], result["runs"] = active
    return result


def collect(transcript):
    """Stats for the session whose main transcript is `transcript`.

    Returns a dict with turns, tools, compacts, active_ms, have_active_time,
    totals (token dict or None), cost_state_usd (latest cost-state snapshot's
    cost, or None) and started_at. Missing/unreadable transcripts give zeros.
    """
    result = {
        "turns": 0, "tools": 0, "compacts": 0,
        "active_ms": 0.0, "have_active_time": False,
        "totals": None, "cost_state_usd": None, "started_at": None,
    }
    if not transcript or not os.path.isfile(transcript):
        return result

    latest_state = None
    # Token usage summed from the transcripts themselves - main thread and
    # every subagent - keyed by API message id across all of them (see
    # add_usage). This is the primary source; see the totals decision below.
    usage_by_id = {}

    try:
        with open(transcript, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except Exception:
                    continue
                if entry.get("type") == "cost-state":
                    latest_state = entry
                elif entry.get("type") == "assistant":
                    result["tools"] += count_tool_uses(entry)
                    add_usage(entry, usage_by_id)
                elif is_real_user_turn(entry):
                    result["turns"] += 1
                elif entry.get("type") == "system" and entry.get("subtype") == "compact_boundary":
                    # Compacts are the main session's own; subagents are not
                    # counted, and ctx comes from the live input.
                    result["compacts"] += 1
    except Exception:
        pass

    main_active = compute_active_ms(transcript)
    if main_active is not None:
        result["active_ms"] += main_active
        result["have_active_time"] = True

    # Every subagent run gets its own transcript under
    # <session_dir>/subagents/agent-*.jsonl, next to the main transcript.
    # Their active times are added up even when they ran in parallel: the
    # total is agent time (work done), not wall-clock time.
    session_dir = transcript
    if session_dir.endswith(".jsonl"):
        session_dir = session_dir[: -len(".jsonl")]
    try:
        for path in glob.glob(os.path.join(session_dir, "subagents", "agent-*.jsonl")):
            sub = scan_subagent(path, usage_by_id)
            if sub is None:
                continue
            result["tools"] += sub["tools"]
            result["turns"] += sub["turns"]
            if sub["active_ms"] is not None:
                result["active_ms"] += sub["active_ms"]
                result["have_active_time"] = True
    except Exception:
        pass

    # Claude Code's {"type": "cost-state"} snapshot merges every thread's usage
    # by model, plus small side calls that never appear in a transcript - but
    # it is written only now and then (one session had a single snapshot from
    # when it had cost $0.33, at $56). So each token count is the larger of
    # the latest snapshot and the transcript sum: a current snapshot wins by
    # its side calls, a stale one can never under-report.
    summed = sum_usage(usage_by_id) if usage_by_id else None
    snapshot = None
    if latest_state:
        snapshot = {k: 0 for k in TOKEN_KEYS}
        for model_usage in (latest_state.get("modelUsage") or {}).values():
            for key, snap_key in zip(TOKEN_KEYS, SNAPSHOT_KEYS):
                snapshot[key] += model_usage.get(snap_key) or 0
        if isinstance(latest_state.get("totalCostUSD"), (int, float)):
            result["cost_state_usd"] = float(latest_state["totalCostUSD"])
    if summed and snapshot:
        result["totals"] = {k: max(summed[k], snapshot[k]) for k in TOKEN_KEYS}
    else:
        result["totals"] = summed or snapshot

    result["started_at"] = first_timestamp(transcript)
    return result


def ledger_fields(stats):
    """The ledger-record fields derived from collect()'s result."""
    totals = stats.get("totals") or {}
    return {
        "active_sec": int(stats["active_ms"] // 1000) if stats.get("have_active_time") else None,
        "turns": stats.get("turns", 0),
        "tools": stats.get("tools", 0),
        "compacts": stats.get("compacts", 0),
        "started_at": stats.get("started_at"),
        "tokens": {
            "in": totals.get("input_tokens", 0),
            "out": totals.get("output_tokens", 0),
            "cw": totals.get("cache_creation_input_tokens", 0),
            "cr": totals.get("cache_read_input_tokens", 0),
        },
    }
