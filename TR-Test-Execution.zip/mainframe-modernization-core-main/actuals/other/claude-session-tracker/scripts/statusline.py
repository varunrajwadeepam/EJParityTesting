#!/usr/bin/env python3
import sys
import os
import json
import threading

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import session_stats

try:
    # errors="replace": one odd character in a stored mark must never blank
    # the whole line.
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# Claude Code pipes the payload in and closes stdin, so the read below returns
# at once. But an orphaned status-line process - its parent gone without the
# pipe being closed - would wait for an end-of-input that never comes and sit
# there forever; they accumulate one per refresh. Give up after a few seconds
# and exit instead, with os._exit so the blocked read cannot hold up the exit.
STDIN_DEADLINE_SEC = 5


def _read_stdin(deadline_sec):
    box = {}

    def reader():
        try:
            # Claude Code sends UTF-8. Text-mode stdin would decode it with the
            # Windows code page (cp1252) and garble any non-ASCII path or mark.
            box["raw"] = sys.stdin.buffer.read().decode("utf-8", "replace")
        except Exception:
            box["raw"] = ""

    thread = threading.Thread(target=reader, daemon=True)
    thread.start()
    thread.join(deadline_sec)
    if thread.is_alive():
        sys.stdout.flush()
        os._exit(0)  # nothing to render without the payload
    return box.get("raw") or ""


raw = _read_stdin(STDIN_DEADLINE_SEC)

data = None
if raw:
    try:
        data = json.loads(raw)
    except Exception:
        data = None

model = ""
proj = ""
effort = None
ctx = None
cost = None
transcript = None
session_id = None

if data:
    model = (data.get("model") or {}).get("display_name") or ""
    current_dir = (data.get("workspace") or {}).get("current_dir")
    if current_dir:
        proj = os.path.basename(current_dir.rstrip("/\\"))
    effort = (data.get("effort") or {}).get("level")
    context_window = data.get("context_window") or {}
    if context_window.get("used_percentage") is not None:
        ctx = context_window.get("used_percentage")
    cost_obj = data.get("cost") or {}
    if cost_obj.get("total_cost_usd") is not None:
        cost = float(cost_obj["total_cost_usd"])
    transcript = data.get("transcript_path")
    session_id = data.get("session_id")

if model.startswith("Claude "):
    model = model[len("Claude "):]

# Transcript-derived stats (main thread + every subagent): see session_stats.
stats = session_stats.collect(transcript)
totals = stats["totals"]
user_turns = stats["turns"]
tool_calls = stats["tools"]
compact_count = stats["compacts"]
active_ms = stats["active_ms"]
have_active_time = stats["have_active_time"]


def format_tokens(n):
    n = float(n)
    if n >= 1_000_000:
        return "{:.1f}M".format(n / 1_000_000)
    if n >= 1_000:
        return "{:.1f}k".format(n / 1000)
    return str(int(n))

# ------------------------------------------------------------
# ANSI colors (Windows 10/11 Terminal, macOS, Linux terminals)
# ------------------------------------------------------------

ESC = "\x1b"
GRAY = ESC + "[2;37m"
BLUE = ESC + "[1;34m"
TEAL = ESC + "[1;36m"
ORANGE = ESC + "[0;33m"
GREEN_B = ESC + "[1;32m"
PURPLE_B = ESC + "[1;35m"
RESET = ESC + "[0m"
SEP = " " + GRAY + "|" + RESET + " "

# ------------------------------------------------------------
# Build line
# ------------------------------------------------------------

# ------------------------------------------------------------
# Session ledger: keep this session's record in
# ~/.claude/all-sessions-stat.json current (see session_record.py), and read
# back the work-id / phase marks set by ">>>save ...". Never allowed to break
# the status line itself.
# ------------------------------------------------------------

work_id = work_phase = ""
if session_id:
    try:
        import session_record

        session_record.update_stats(session_id, {
            "project_dir": ((data.get("workspace") or {}).get("project_dir")
                            or (data.get("workspace") or {}).get("current_dir") or ""),
            "transcript_path": transcript or "",
            "model": model,
            "effort": effort,
            "ctx_pct": ctx,
            "cost_usd": cost,
            **session_stats.ledger_fields(stats),
        })
        work_id, work_phase = session_record.get_marks(session_id)
    except Exception:
        pass

line = BLUE + model + RESET + SEP + TEAL + proj + RESET

if work_id or work_phase:
    line += SEP + GRAY + "work:" + RESET + ORANGE + (work_id or "-") + RESET
    line += SEP + GRAY + "phase:" + RESET + ORANGE + (work_phase or "-") + RESET

if effort:
    line += SEP + ORANGE + effort + RESET

if ctx is not None:
    ctxr = round(float(ctx))
    line += SEP + GRAY + "ctx:" + RESET + GREEN_B + str(ctxr) + "%" + RESET

if cost is not None:
    costf = round(cost, 4)
    line += SEP + GRAY + "cost:" + RESET + PURPLE_B + "$" + str(costf) + RESET

if have_active_time:
    total_sec = int(active_ms // 1000)
    m = total_sec // 60
    s = total_sec % 60
    line += SEP + GRAY + "time:" + RESET + TEAL + "{}m{:02d}s".format(m, s) + RESET

if transcript:
    line += SEP + GRAY + "turns:" + RESET + GREEN_B + str(user_turns) + RESET
    line += SEP + GRAY + "tools:" + RESET + ORANGE + str(tool_calls) + RESET
    line += SEP + GRAY + "compacts:" + RESET + PURPLE_B + str(compact_count) + RESET

if totals:
    parts = [
        GRAY + "in:" + RESET + GREEN_B + format_tokens(totals["input_tokens"]) + RESET,
        GRAY + "out:" + RESET + TEAL + format_tokens(totals["output_tokens"]) + RESET,
        GRAY + "cw:" + RESET + ORANGE + format_tokens(totals["cache_creation_input_tokens"]) + RESET,
        GRAY + "cr:" + RESET + PURPLE_B + format_tokens(totals["cache_read_input_tokens"]) + RESET,
    ]
    line += SEP + SEP.join(parts)

sys.stdout.write(line)
