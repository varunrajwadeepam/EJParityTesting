# DU Instructions — EPICS Pipeline (v0)

**Audience:** EPICS stage agents (`epics-epics`, story generators). Read before writing any EPIC or
story text.

**What this is.** The pipeline-oriented usage contract for the Deployment Unit currently shipped in
the DU distributive: `trvs-mu-library-archetype` (Java 21 / Spring Boot 3.4, one flat library module
per MU). All construction detail lives in the distributive — not here, not in the pipeline. Replace
the archetype and this document is replaced with its counterpart; the pipeline itself changes
nothing.

**Prime directive.** Every story describes **a change to an application that already builds, boots
and answers a health check**. No story stands up a solution.

---

## 1. Facts every story is written against

From the LLD/TSA solution-context block: solution root (default `../../solution`), the app module and
its base package, this MU's module artifactId and package, the sibling modules it may depend on, and
the concerns the basement already provides (logging, security, global error handling, app config).

```text
this MU's writable surface:   docs/epics/…, specs/…            (its own workspace)
                              solution/<this-mu-module>/**     (its own module)
plus exactly two shared lines: <module> in solution/pom.xml, <dependency> in the app pom
everything else in solution/: read-only
```

---

## 2. The Technical Setup EPIC — reduced

The basement exists, so this EPIC is **not** solution structure, dependency injection, logging,
security, hosting or build infrastructure. Its whole content is attaching one module:

| ID | Technical Setup scope |
|---|---|
| DU-EPICS-01 | Generate this MU's module from the archetype with its `groupId` / `artifactId` / `package` / `muName` / `entityName` values stated. |
| DU-EPICS-02 | Confirm the `<module>` entry landed in the reactor pom (auto-appended by `archetype:generate`). |
| DU-EPICS-03 | Add the `<dependency>` on this module to the app module pom — the one manual shared edit. |
| DU-EPICS-04 | `mvn -pl <mu-module> -am verify` passes standalone, 80% JaCoCo met. |
| DU-EPICS-05 | `mvn install` from the solution root, then boot the app and confirm health plus this MU's surface responds. |

Exactly one Technical Setup EPIC, `epic_type: "technical"`, sequenced first. Keep it small — if it
grows past module creation and wiring, scope has leaked in from the basement.

Sequence unchanged: **Technical Setup → external-dependency stubs → business EPICs.** Stubs are a
package inside this MU's module, never a module of their own.

---

## 3. Story text rules

| ID | Rule |
|---|---|
| DU-EPICS-10 | Every file path in a story is inside `solution/<this-mu-module>/**` — except the two wiring lines, which appear only in the Technical Setup EPIC. A story naming a path in the app module or a sibling module is a defect. |
| DU-EPICS-11 | Phrase work as extending a running application, not as building one. |
| DU-EPICS-12 | Write no story for logging, security, global error handling, app configuration, hosting or packaging. The MU's own exception→status mapping inside its own scoped advice is in scope; the app-wide mechanism is not. |
| DU-EPICS-13 | Class names in story text carry the MU entity prefix (`<Entity>GlobalExceptionHandler`, not `GlobalExceptionHandler`) — bean-name collisions in the shared Spring context are real, not hypothetical. |
| DU-EPICS-14 | Packages in story text are `<app base package>.<mu package>.{api|service|mapper|model|exception}`. Never a sibling package tree. |
| DU-EPICS-15 | A story that needs something a sibling module or the basement owns is **blocked and routed back** to that owner's pipeline. Never write a story that duplicates the capability locally or patches the other module. |
| DU-EPICS-16 | No story mentions a deployable, a `main`, a fat JAR or a `java -jar` command for this MU. The deployable is the pre-existing app. |

### Say this, not that

| Not | Yes |
|---|---|
| "Create the solution structure and project layout" | "Generate the MU module from the archetype and wire it into the reactor and app pom" |
| "Configure dependency injection and logging" | (no story — basement provides) |
| "Set up the Spring Boot application and hosting" | (no story — basement provides) |
| "Deploy the service and run it" | "Install the reactor and verify this MU's surface through the running app" |
| "Add a shared date utility to the common layer" | "Depend on the common module's date utility" (or route back if absent) |
| "Build the MU as a runnable service" | "Build the MU as a library module on the app's classpath" |

---

## 4. Acceptance criteria and Definition of Done

| ID | Requirement |
|---|---|
| DU-EPICS-20 | Acceptance criteria are verifiable **through the running application** where the MU has a surface — not only through the module's own unit tests. |
| DU-EPICS-21 | Every story's DoD includes: `mvn -pl <mu-module> -am verify` green standalone, 80% JaCoCo line coverage met. |
| DU-EPICS-22 | Stories that change the MU's exposed surface add to DoD: `mvn install` from the solution root, app boots, health endpoint responds, the surface responds. |
| DU-EPICS-23 | Every story's DoD asserts **no file outside this MU's module was modified**. |
| DU-EPICS-24 | Controller-level test criteria specify standalone MockMvc, never `@WebMvcTest` / `@SpringBootTest` — the MU has no `@SpringBootApplication` of its own. |
| DU-EPICS-25 | Placeholder / not-yet-implemented behaviour is covered by a `@Disabled` stub test naming its unblocking condition, and the story says so. |

---

## 5. Effort and sequencing

Estimate against an existing basement: no bootstrap, framework selection, hosting or CI setup work
exists to size. Technical Setup is small by construction. Business EPIC effort follows the LLD
package design inside the one module — never a per-layer-module multiplier.

---

## 6. Never

- A story that creates a solution, reactor, parent POM, or additional module for this MU.
- A story that edits the app module or a sibling module (beyond the single wiring `<dependency>`).
- A story for basement-owned cross-cutting infrastructure.
- A story that works around a missing upstream capability instead of routing it back.

---

## 7. Supersedes

Where the shipped EPICS pipeline rules conflict, this document wins for a DU-based portfolio:

- `epic-generation` skill: technical EPIC "combines infrastructure (solution structure, NuGet, DI,
  logging) AND deployment (local IIS, build scripts, monitoring)" → module generation and wiring
  only; infrastructure and deployment belong to the DU and the basement.
