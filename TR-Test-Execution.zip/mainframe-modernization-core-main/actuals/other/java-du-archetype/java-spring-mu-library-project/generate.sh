#!/bin/sh
# Generates a new Migration Unit library module from trvs-mu-library-archetype.
#
# Usage: copy this file, edit the ARCHETYPE_* values below, then run:
#   sh generate.sh
#
# Only POSIX sh features are used (no bash-only syntax, no external interpreters,
# no Node/Python/yq -- just this shell script and mvn).
#
# IMPORTANT: unlike trvs-rest-api-service-archetype, this archetype generates a SINGLE flat
# module (packaging=jar, no reactor wrapper). It is meant to be dropped as a new sibling
# directory under an EXISTING solution reactor -- point ARCHETYPE_OUTPUT_DIR at that reactor's
# root (e.g. solution/) and set ARCHETYPE_ARTIFACT_ID to the module's own directory name (e.g.
# revdb-subset3-endpoint-1). After generation you must still, by hand:
#   1. Add <module>ARCHETYPE_ARTIFACT_ID</module> to the reactor's pom.xml.
#   2. Add a <dependency> on this artifact to the app module's pom.xml.
# See ../README.md "Wiring a generated MU into the solution" for both edits in full.

# ============================================================================
# EDIT THESE VALUES
# ============================================================================

# --- Which archetype to generate from (rarely needs to change) ---
ARCHETYPE_SOURCE_GROUP_ID="com.insurance.archetypes"
ARCHETYPE_SOURCE_ARTIFACT_ID="trvs-mu-library-archetype"
ARCHETYPE_SOURCE_VERSION="1.0.0-SNAPSHOT"

# --- New module Maven coordinates (required). artifactId doubles as the generated directory
#     name -- it must not collide with any existing module under ARCHETYPE_OUTPUT_DIR. ---
ARCHETYPE_GROUP_ID="com.insurance.CHANGEME"
ARCHETYPE_ARTIFACT_ID="CHANGEME-endpoint-1"
ARCHETYPE_VERSION="1.0.0-SNAPSHOT"
ARCHETYPE_PACKAGE="com.insurance.CHANGEME.endpoint1"

# --- Archetype-specific properties (required) ---
ARCHETYPE_MU_NAME="CHANGEME Endpoint 1"
ARCHETYPE_ENTITY_NAME="CHANGEME"

# --- Target solution folder this module is generated INTO as a new sibling directory
#     (e.g. the existing solution/ reactor root -- NOT a throwaway staging folder; this
#     archetype has no reactor wrapper to flatten). Defaults to the current directory. ---
ARCHETYPE_OUTPUT_DIR="."

# ============================================================================
# DO NOT EDIT BELOW THIS LINE
# ============================================================================

set -e

for required_name_value in \
    "ARCHETYPE_GROUP_ID:$ARCHETYPE_GROUP_ID" \
    "ARCHETYPE_ARTIFACT_ID:$ARCHETYPE_ARTIFACT_ID" \
    "ARCHETYPE_VERSION:$ARCHETYPE_VERSION" \
    "ARCHETYPE_PACKAGE:$ARCHETYPE_PACKAGE" \
    "ARCHETYPE_MU_NAME:$ARCHETYPE_MU_NAME" \
    "ARCHETYPE_ENTITY_NAME:$ARCHETYPE_ENTITY_NAME"
do
    name="${required_name_value%%:*}"
    value="${required_name_value#*:}"
    if [ -z "$value" ] || [ "$value" = "CHANGEME" ] || [ "$value" = "com.insurance.CHANGEME" ] \
        || [ "$value" = "CHANGEME-endpoint-1" ] || [ "$value" = "com.insurance.CHANGEME.endpoint1" ] \
        || [ "$value" = "CHANGEME Endpoint 1" ]; then
        echo "Edit $name at the top of this script before running it (still set to a CHANGEME placeholder or empty)." >&2
        exit 1
    fi
done

set -- \
    "-DarchetypeGroupId=$ARCHETYPE_SOURCE_GROUP_ID" \
    "-DarchetypeArtifactId=$ARCHETYPE_SOURCE_ARTIFACT_ID" \
    "-DarchetypeVersion=$ARCHETYPE_SOURCE_VERSION" \
    -DinteractiveMode=false \
    "-DoutputDirectory=$ARCHETYPE_OUTPUT_DIR" \
    "-DgroupId=$ARCHETYPE_GROUP_ID" \
    "-DartifactId=$ARCHETYPE_ARTIFACT_ID" \
    "-Dversion=$ARCHETYPE_VERSION" \
    "-Dpackage=$ARCHETYPE_PACKAGE" \
    "-DmuName=$ARCHETYPE_MU_NAME" \
    "-DentityName=$ARCHETYPE_ENTITY_NAME"

echo "Generating $ARCHETYPE_ARTIFACT_ID from $ARCHETYPE_SOURCE_GROUP_ID:$ARCHETYPE_SOURCE_ARTIFACT_ID:$ARCHETYPE_SOURCE_VERSION into $ARCHETYPE_OUTPUT_DIR ..."

mvn archetype:generate "$@"

echo "Done. Generated module: $ARCHETYPE_OUTPUT_DIR/$ARCHETYPE_ARTIFACT_ID"
echo "Remaining manual steps (this archetype cannot edit existing files):"
echo "  1. Add <module>$ARCHETYPE_ARTIFACT_ID</module> to the solution reactor's pom.xml."
echo "  2. Add a <dependency> on this artifact to the app module's pom.xml."
