# Java / Spring MU Library Blueprint — Agent Contract

Maven archetype generating a **Migration Unit library module** — a plain-JAR Spring component
module meant to be composed, as an ordinary Maven dependency, into an existing target-solution
reactor alongside its one app/bootstrap module. Companion to
`../java-spring-rest-project` (`trvs-rest-api-service-archetype`), which generates that app
module. Read both before scaffolding a multi-MU solution.

- **Coordinates:** `com.insurance.archetypes:trvs-mu-library-archetype:1.0.0-SNAPSHOT`
- **Archetype module:** `./mvn-archetype/`
- **Human wrappers:** `./generate.sh`, `./generate.cmd`
- **Stack:** Java 21 / Spring Boot 3.4.2 (parent for managed versions only — see AD-2) / Spring
  Web MVC / JUnit 5 + Mockito + AssertJ / JaCoCo 0.8.12.

## Why this archetype exists

`trvs-rest-api-service-archetype` generates a **complete, self-sufficient microservice**: its own
`@SpringBootApplication`, its own `spring-boot-starter-parent` inheritance, its own logging /
exception-handling / OpenAPI / security infra. That shape is correct for exactly one module per
solution — the app/bootstrap module — but wrong for a Migration Unit like `mu-ep1` or `mu-com` as
described in `docs/cobol-to-java-migration-target-project-structure.md`: those must be **plain
library JARs**, with no independent boot class and no duplicated cross-cutting infrastructure,
that the one app module depends on and folds into its own Spring context.

Dropping an `endpoint-1` folder in as an untracked sibling under `solution/` does nothing by
itself — nothing wires it into the app's classpath or component scan. This archetype generates
the module in the correct *shape* for that wiring; the wiring itself (two `pom.xml` edits) is a
manual step described below, because `archetype:generate` only ever writes into a fresh
directory — it cannot edit an existing `pom.xml`.

---

## What gets generated

**One flat module, not a reactor.** Unlike `trvs-rest-api-service-archetype` (aggregator +
nested module), this archetype writes directly into `{artifactId}/`:

```
{artifactId}/                        packaging=jar, no reactor wrapper, no @SpringBootApplication
├── pom.xml                          parent = spring-boot-starter-parent (managed versions only)
└── src/
    ├── main/java/{package}/
    │   ├── api/controller/{Entity}Controller.java   the ONE default entry point
    │   ├── service/{Entity}Service.java             business logic seam (simulator -> real logic)
    │   ├── mapper/{Entity}Mapper.java                request/response <-> internal model
    │   ├── model/{Entity}Request.java, {Entity}Response.java
    │   ├── exception/
    │   │   ├── GlobalExceptionHandler.java          @RestControllerAdvice(basePackages={package})
    │   │   ├── NotFoundException.java                -> 404
    │   │   ├── FatalProcessingException.java         -> 500
    │   │   └── UpstreamUnavailableException.java     -> 503
    │   └── demo/DemoResponseSimulator.java           temporary — delete on retirement
    └── test/java/{package}/                          mirrors src/main package-for-package
```

No `data/` package, no DB2 dependency, no `infrastructure/db`, no OpenAPI config, no
`SecurityConfig`, no `application.yml` — all of that is the app module's job (AD-2). No
`spring-boot-maven-plugin` execution — this jar is never run on its own.

`mvn verify` on the tree as generated passes its own tests and 80% coverage gate,
**independent of any app module** — `{Entity}ControllerIntegrationTest` uses `@WebMvcTest`
scoped to just this module's controller, not a full `@SpringBootTest`.

## Demo mode

Same idea as the app archetype's demo mode, scoped to this module: `{Entity}Controller` →
`{Entity}Service` → `DemoResponseSimulator`, never a repository. ~50% success, ~50% spread across
400/404/500/503, each a real typed exception routed through this module's own
`GlobalExceptionHandler`. Controlled by no flag (there's no `application.yml` in this module to
hold one) — retire it by replacing the `demoResponseSimulator.simulateOutcome()` call in
`{Entity}Service` with real logic, then delete `demo/` and its test.

## Why `GlobalExceptionHandler` is scoped with `basePackages`

A solution composes several Migration Units plus one app module into **one Spring context**.
`@RestControllerAdvice` is global by default — if every MU's advice were unscoped, they would
collide or silently shadow each other in that shared context. This archetype's
`GlobalExceptionHandler` is annotated `@RestControllerAdvice(basePackages = "${package}")`, so
its authority is limited to controllers under this module's own base package — mirroring the
Maven dependency-direction rule in the target-structure doc (a MU only owns its own behavior,
never a sibling's).

## Architecture decisions — cite by id, don't restate

| id | Decision |
|---|---|
| AD-1 | Single flat module, `packaging=jar`, no reactor wrapper — this archetype adds ONE module to an existing reactor, it does not create one |
| AD-2 | `spring-boot-starter-parent` inherited for managed dependency **versions only** — no `@SpringBootApplication`, no boot-plugin repackage; cross-cutting infra (logging config, OpenAPI, security, DB) stays the app module's exclusive concern |
| AD-3 | Demo mode: controller → service → `DemoResponseSimulator`; errors are real typed exceptions through this module's own handler |
| AD-4 | `GlobalExceptionHandler` scoped via `basePackages` to this module's own base package — never global |
| AD-5 | No dependency on the app module, ever, in either direction |
| AD-6 | May depend on an upstream common MU (`mu-com`-shaped); may **never** depend on a sibling endpoint MU (`mu-ep2`, etc.) — see target-structure doc section 7 |
| AD-7 | JaCoCo 80% line gate at `verify`, runnable and passing standalone, before this module is wired into any solution |
| AD-8 | `api → service → mapper`, with `model`/`exception`/`demo` available to all — mirrors the app archetype's one-directional layer contract |

## Archetype properties

| Property | Default | Meaning |
|---|---|---|
| `groupId` | — | Java group id, typically shared with the solution's app module |
| `artifactId` | — | Module directory name **and** Maven artifactId — must not collide with any existing sibling under the target output directory |
| `package` | — | Java base package. **Recommended:** a subpackage of the app module's own base package (e.g. app = `com.insurance.revdb.subset3`, this MU = `com.insurance.revdb.subset3.endpoint1`) — see "Wiring" below for why |
| `muName` | `Sample Migration Unit` | Human-readable name, used in `pom.xml` `<name>` |
| `entityName` | `Sample` | Names the default placeholder controller/service/mapper/model (e.g. `RevDb`) |

---

## Usage

### 1. Install the archetype (one-time, or after editing it)

```bash
cd project-archetype/mvn-archetype   # this package's own mvn-archetype/, wherever it lives
mvn install
```

### 2. Generate a new MU module

```cmd
copy generate.cmd my-generate.cmd
:: edit the ARCHETYPE_* values in my-generate.cmd, then:
my-generate.cmd
```

Point `ARCHETYPE_OUTPUT_DIR` at the **existing solution reactor root** (e.g. `solution/`), and set
`ARCHETYPE_ARTIFACT_ID` to the new module's own directory name (e.g. `revdb-subset3-endpoint-1`).
Unlike the app archetype's `generate.cmd`, there is **no staging/flatten step here** — this
archetype has no reactor wrapper to flatten, so `ARCHETYPE_OUTPUT_DIR` is the module's direct
parent, not a throwaway folder.

### 3. Wiring a generated MU into the solution (manual — do this every time)

`archetype:generate` only ever writes into a fresh directory; it never edits an existing file.
After generation, two edits by hand (or by an agent that already has the values) are required
before the new module builds or runs as part of the composed app:

**a. Add the module to the solution reactor's `pom.xml`:**

```xml
<modules>
  <module>revdb-subset3-app</module>
  <module>revdb-subset3-endpoint-1</module>   <!-- add this line -->
</modules>
```

**b. Add the module as a dependency of the app module's `pom.xml`** (at the "SHARED LIBRARY
EXTENSION POINT" marker, or anywhere in `<dependencies>`):

```xml
<dependency>
  <groupId>com.insurance.revdb.subset3</groupId>
  <artifactId>revdb-subset3-endpoint-1</artifactId>
  <version>${project.version}</version>
</dependency>
```

Without step (a), Maven's reactor never builds the new module. Without step (b), the module is
never on the app's runtime classpath, so Spring never sees its `@RestController` or
`@RestControllerAdvice` — both are required, and skipping either produces a misleading result
(step (a) alone: the module compiles and tests pass in isolation but nothing changes in the
running app; step (b) alone: Maven fails immediately with "module not found").

**Why the recommended `package` matters:** Spring Boot's default component scan covers the
`@SpringBootApplication` class's own package and everything beneath it. If the app module's base
package is `com.insurance.revdb.subset3` and this MU's `package` property is set to
`com.insurance.revdb.subset3.endpoint1` (a subpackage), the app picks up this module's
`@RestController`/`@Service`/`@RestControllerAdvice` beans **automatically**, with no
`@ComponentScan` change needed in the app module. If a MU's package is a sibling tree instead
(e.g. `com.insurance.endpoint1`, not nested under the app's base package), the app module's
`RevDbSubset3Application` needs an explicit
`@ComponentScan(basePackages = {"com.insurance.revdb.subset3", "com.insurance.endpoint1"})` (or
equivalent) — an extra edit this archetype does not make for you, so prefer the subpackage
convention unless there's a specific reason not to.

### 4. Build and run the composed solution

Once wired, the previously-generated app module is what you build and run — this MU module
compiles into it, it does not run on its own:

```bash
cd solution
mvn verify                       # builds every module in dependency order, all tests + gates
cd revdb-subset3-app
mvn spring-boot:run               # boots the ONE composed app on :8080
curl "http://localhost:8080/v1/{entityname-lowercased}s?key=ABC123"      # app's own default entry point
curl "http://localhost:8080/v1/{mu-entityname-lowercased}s?key=ABC123"   # this MU's entry point, now live in the same process
```

To build/test just this MU module and its dependencies without the rest of the reactor:

```bash
mvn -pl revdb-subset3-endpoint-1 -am verify
```

---

## For LLM subagents: how to use this in a "set up MU basics" story

1. **Determine properties from the story/LLD context**, not interactively: `groupId`/`package`
   from the app module's own base package plus this MU's subpackage segment (see "Wiring"
   above), `entityName` from the MU's primary business entity, `muName` from the MU's
   human-readable name.
2. **Install the archetype once**, then call `archetype:generate` directly with
   `-DinteractiveMode=false` and every property as an explicit `-D<property>=<value>` flag —
   `./generate.sh`/`./generate.cmd` are human wrappers.
3. **Perform both wiring edits from step 3 above in the same story** — a MU scaffolding story
   that generates the module but skips wiring it in is incomplete; the acceptance criteria for
   this story type must include a successful `mvn verify` from the solution reactor root AND a
   live request to this MU's endpoint through the running app module, not just the standalone
   module.
4. **Never add a `data/` package, DB dependency, `application.yml`, or duplicate
   `GlobalExceptionHandler` shape from the app archetype** — those decisions belong to the app
   module only (AD-2). If this MU genuinely needs a data layer, that is a separate,
   later business-logic story, and the resulting repository/entity classes still live in this
   module's own package tree, using whichever DataSource the app module's `application.yml`
   configures (MUs don't configure their own datasources).
5. **Do not let a sibling endpoint MU depend on this one** (AD-6) — if `mu-ep2` needs something
   `mu-ep1` has, that capability belongs in a common MU instead; route the requirement back to
   that MU's own pipeline rather than adding a direct `mu-ep2 → mu-ep1` Maven dependency.
