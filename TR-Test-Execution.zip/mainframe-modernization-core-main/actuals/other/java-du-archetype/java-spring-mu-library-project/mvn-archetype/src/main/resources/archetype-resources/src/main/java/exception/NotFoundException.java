package ${package}.exception;

/**
 * Signals that the requested resource does not exist. Propagates uncaught to
 * {@link GlobalExceptionHandler} -> HTTP 404.
 */
public class NotFoundException extends RuntimeException {

    public NotFoundException(String message) {
        super(message);
    }
}
