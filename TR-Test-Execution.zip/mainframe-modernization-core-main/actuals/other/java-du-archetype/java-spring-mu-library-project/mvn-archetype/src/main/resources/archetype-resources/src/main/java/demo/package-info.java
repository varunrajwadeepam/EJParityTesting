/**
 * Demo-mode response simulator for this Migration Unit -- see
 * {@code DemoResponseSimulator}'s class Javadoc. Delete this package once real business logic
 * replaces the placeholder entry point.
 */
package ${package}.demo;
