package ${package}.demo;

import ${package}.exception.FatalProcessingException;
import ${package}.exception.NotFoundException;
import ${package}.exception.UpstreamUnavailableException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mockito;

import java.util.Random;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ${entityName}DemoResponseSimulatorTest {

    @ParameterizedTest
    @ValueSource(ints = {0, 1, 2, 3, 4})
    void simulateOutcome_succeedsForLowDraws(int draw) {
        ${entityName}DemoResponseSimulator simulator = new ${entityName}DemoResponseSimulator(fixedDraw(draw));
        simulator.simulateOutcome();
    }

    @Test
    void simulateOutcome_throwsIllegalArgumentFor400Draws() {
        assertThatThrownBy(() -> new ${entityName}DemoResponseSimulator(fixedDraw(5)).simulateOutcome())
                .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new ${entityName}DemoResponseSimulator(fixedDraw(6)).simulateOutcome())
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void simulateOutcome_throwsNotFoundFor404Draw() {
        assertThatThrownBy(() -> new ${entityName}DemoResponseSimulator(fixedDraw(7)).simulateOutcome())
                .isInstanceOf(NotFoundException.class);
    }

    @Test
    void simulateOutcome_throwsFatalProcessingFor500Draw() {
        assertThatThrownBy(() -> new ${entityName}DemoResponseSimulator(fixedDraw(8)).simulateOutcome())
                .isInstanceOf(FatalProcessingException.class);
    }

    @Test
    void simulateOutcome_throwsUpstreamUnavailableFor503Draw() {
        assertThatThrownBy(() -> new ${entityName}DemoResponseSimulator(fixedDraw(9)).simulateOutcome())
                .isInstanceOf(UpstreamUnavailableException.class);
    }

    @Test
    void possibleStatusCodes_listsAllFiveOutcomes() {
        assertThat(${entityName}DemoResponseSimulator.possibleStatusCodes()).containsExactly(200, 400, 404, 500, 503);
    }

    private static Random fixedDraw(int draw) {
        Random random = Mockito.mock(Random.class);
        Mockito.when(random.nextInt(10)).thenReturn(draw);
        return random;
    }
}
