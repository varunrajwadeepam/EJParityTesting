package ${package}.service;

import ${package}.demo.${entityName}DemoResponseSimulator;
import ${package}.mapper.${entityName}Mapper;
import ${package}.model.${entityName}Request;
import ${package}.model.${entityName}Response;
import org.springframework.stereotype.Service;

/**
 * Business logic for the default placeholder entry point.
 *
 * <p>Currently delegates entirely to {@link ${entityName}DemoResponseSimulator} -- there is no real business
 * logic or upstream call yet. When ready:
 * <ol>
 *   <li>Inject the real upstream Migration Unit's bean (see the SHARED LIBRARY / UPSTREAM MU
 *       EXTENSION POINT in pom.xml) or downstream integration.</li>
 *   <li>Replace the {@code demoResponseSimulator.simulateOutcome()} call below with real logic.</li>
 *   <li>Delete {@code demo/} entirely once no longer needed.</li>
 * </ol>
 */
@Service
public class ${entityName}Service {

    private final ${entityName}DemoResponseSimulator demoResponseSimulator;
    private final ${entityName}Mapper mapper;

    public ${entityName}Service(${entityName}DemoResponseSimulator demoResponseSimulator, ${entityName}Mapper mapper) {
        this.demoResponseSimulator = demoResponseSimulator;
        this.mapper = mapper;
    }

    public ${entityName}Response handle(${entityName}Request request) {
        // Simulated success/error split -- throws for the error branches, which are caught by
        // GlobalExceptionHandler and mapped to the matching HTTP status.
        demoResponseSimulator.simulateOutcome();

        return mapper.toResponse(request, "DEMO-VALUE", 0);
    }
}
