package ${package}.mapper;

import ${package}.model.${entityName}Request;
import ${package}.model.${entityName}Response;
import org.springframework.stereotype.Component;

/**
 * Translates between this Migration Unit's request/response model and whatever internal
 * representation {@code ${entityName}Service} works with. Currently a pass-through (demo mode
 * never touches real data) -- this is the intended landing spot for COBOL field-level mapping
 * logic once real business rules replace the placeholder entry point.
 */
@Component
public class ${entityName}Mapper {

    public ${entityName}Response toResponse(${entityName}Request request, String value, int generatedAt) {
        return new ${entityName}Response(request.key(), value, generatedAt);
    }
}
