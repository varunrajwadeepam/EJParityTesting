package ${package}.exception;

/**
 * Signals that an upstream dependency (e.g. a common Migration Unit, or a downstream system once
 * one is wired in) is unavailable or overloaded. Propagates uncaught to
 * {@link GlobalExceptionHandler} -> HTTP 503.
 */
public class UpstreamUnavailableException extends RuntimeException {

    public UpstreamUnavailableException(String message) {
        super(message);
    }
}
