/**
 * Typed exceptions and the one {@code @RestControllerAdvice} for this Migration Unit, scoped via
 * {@code basePackages} to this module's own base package -- see
 * {@code GlobalExceptionHandler}'s class Javadoc for why the scoping matters once this module is
 * composed alongside other Migration Units and the app module inside one Spring context.
 */
package ${package}.exception;
