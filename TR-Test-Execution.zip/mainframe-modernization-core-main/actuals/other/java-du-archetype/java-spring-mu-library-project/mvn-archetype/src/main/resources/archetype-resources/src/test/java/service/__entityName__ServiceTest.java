package ${package}.service;

import ${package}.demo.${entityName}DemoResponseSimulator;
import ${package}.mapper.${entityName}Mapper;
import ${package}.model.${entityName}Request;
import ${package}.model.${entityName}Response;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ${entityName}ServiceTest {

    @Mock
    private ${entityName}DemoResponseSimulator demoResponseSimulator;

    @Mock
    private ${entityName}Mapper mapper;

    @Test
    void handle_delegatesToSimulatorThenMapper() {
        ${entityName}Service service = new ${entityName}Service(demoResponseSimulator, mapper);
        ${entityName}Request request = new ${entityName}Request("ABC123");
        ${entityName}Response expected = new ${entityName}Response("ABC123", "DEMO-VALUE", 0);
        when(mapper.toResponse(request, "DEMO-VALUE", 0)).thenReturn(expected);

        ${entityName}Response actual = service.handle(request);

        verify(demoResponseSimulator).simulateOutcome();
        assertThat(actual).isEqualTo(expected);
    }
}
