package ${package}.mapper;

import ${package}.model.${entityName}Request;
import ${package}.model.${entityName}Response;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class ${entityName}MapperTest {

    private final ${entityName}Mapper mapper = new ${entityName}Mapper();

    @Test
    void toResponse_echoesKeyAndCarriesGivenValues() {
        ${entityName}Response response = mapper.toResponse(new ${entityName}Request("ABC123"), "DEMO-VALUE", 0);

        assertThat(response).isEqualTo(new ${entityName}Response("ABC123", "DEMO-VALUE", 0));
    }
}
