package ${package}.model;

/**
 * Response model for the default placeholder entry point.
 *
 * @param key         echoes the requested key
 * @param value       constant demo payload -- replace once real business logic is wired in
 * @param generatedAt placeholder numeric field, currently always 0
 */
public record ${entityName}Response(String key, String value, int generatedAt) {
}
