package ${package}.exception;

import jakarta.validation.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Exception handler for this Migration Unit's own controllers only.
 *
 * <p><b>{@code basePackages} scoping matters here.</b> This module is designed to be composed,
 * as a plain Maven dependency, into a solution alongside its app module and sibling Migration
 * Units -- each of which may bring its own {@code @RestControllerAdvice}. An unscoped
 * {@code @RestControllerAdvice} is GLOBAL by default and would shadow or collide with every
 * other MU's advice inside the one shared Spring context the app module boots. Scoping to
 * {@code ${package}} keeps this handler's authority limited to controllers under this MU's own
 * base package, mirroring the Maven dependency-direction rule in
 * docs/cobol-to-java-migration-target-project-structure.md section 7 (a MU only owns its own
 * behavior, never a sibling's).
 *
 * <p>Converts exceptions to a structured JSON error envelope:
 * <pre>
 * {
 *   "timestamp":     "2026-07-28T10:15:30Z",
 *   "status":        500,
 *   "error":         "Internal Server Error",
 *   "message":       "...",
 *   "path":          "/...",
 *   "correlationId": "..."
 * }
 * </pre>
 */
@RestControllerAdvice(basePackages = "${package}")
public class ${entityName}GlobalExceptionHandler {

    /** MDC key this handler reads back into the error envelope; set by the controller. */
    public static final String MDC_CORRELATION_ID = "correlationId";

    private static final Logger log = LoggerFactory.getLogger(${entityName}GlobalExceptionHandler.class);

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGenericException(Exception ex, WebRequest request) {
        log.error("Unhandled exception: {}", ex.getMessage(), ex);
        return build(HttpStatus.INTERNAL_SERVER_ERROR, ex, request);
    }

    @ExceptionHandler({ConstraintViolationException.class, MissingServletRequestParameterException.class,
            IllegalArgumentException.class})
    public ResponseEntity<Map<String, Object>> handleValidationException(Exception ex, WebRequest request) {
        log.warn("Request validation failed: {}", ex.getMessage());
        return build(HttpStatus.BAD_REQUEST, ex, request);
    }

    @ExceptionHandler(NotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleNotFoundException(NotFoundException ex, WebRequest request) {
        log.warn("Resource not found: {}", ex.getMessage());
        return build(HttpStatus.NOT_FOUND, ex, request);
    }

    @ExceptionHandler(FatalProcessingException.class)
    public ResponseEntity<Map<String, Object>> handleFatalProcessingException(
            FatalProcessingException ex, WebRequest request) {
        log.error("Fatal processing error [correlationId={}]: {}", MDC.get(MDC_CORRELATION_ID), ex.getMessage(), ex);
        return build(HttpStatus.INTERNAL_SERVER_ERROR, ex, request);
    }

    @ExceptionHandler(UpstreamUnavailableException.class)
    public ResponseEntity<Map<String, Object>> handleUpstreamUnavailableException(
            UpstreamUnavailableException ex, WebRequest request) {
        log.error("Upstream unavailable [correlationId={}]: {}", MDC.get(MDC_CORRELATION_ID), ex.getMessage(), ex);
        return build(HttpStatus.SERVICE_UNAVAILABLE, ex, request);
    }

    private static ResponseEntity<Map<String, Object>> build(HttpStatus status, Exception ex, WebRequest request) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", Instant.now().toString());
        body.put("status", status.value());
        body.put("error", status.getReasonPhrase());
        body.put("message", ex.getMessage());
        body.put("path", request.getDescription(false).replace("uri=", ""));
        body.put("correlationId", MDC.get(MDC_CORRELATION_ID));
        return new ResponseEntity<>(body, status);
    }
}
