package ${package}.demo;

import ${package}.exception.FatalProcessingException;
import ${package}.exception.NotFoundException;
import ${package}.exception.UpstreamUnavailableException;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Random;

/**
 * Demonstrates this Migration Unit's success/error response shapes before any real business
 * logic exists.
 *
 * <p>Roughly 50% of calls succeed (no-op return); the remaining 50% is spread across a fixed
 * set of error outcomes -- 400 at ~20%, then 404 / 500 / 503 at ~10% each (see
 * {@link #simulateOutcome()} for the exact draw) -- each raised as a typed exception that
 * {@link ${package}.exception.${entityName}GlobalExceptionHandler} maps to the matching HTTP status.
 *
 * <p>This class -- and demo mode generally -- is meant to be deleted once real business logic
 * replaces the placeholder entry point.
 *
 * <p>Uses an injected {@link Random} (not a {@code new Random()} inline at call time) so tests
 * can substitute a deterministic seed.
 */
@Component
public class ${entityName}DemoResponseSimulator {

    private final Random random;

    public ${entityName}DemoResponseSimulator() {
        this(new Random());
    }

    public ${entityName}DemoResponseSimulator(Random random) {
        this.random = random;
    }

    /**
     * Simulates one of five outcomes from a single 0-9 draw: success (values 0-4, ~50%),
     * 400 (values 5-6, ~20%), 404 (value 7, ~10%), 500 (value 8, ~10%), 503 (value 9, ~10%).
     * The four error branches are not equiprobable; the exact weighting carries no meaning
     * beyond demonstrating each response shape, and callers must not depend on it.
     *
     * @throws IllegalArgumentException for the simulated 400 outcome
     * @throws NotFoundException for the simulated 404 outcome
     * @throws FatalProcessingException for the simulated 500 outcome
     * @throws UpstreamUnavailableException for the simulated 503 outcome
     */
    public void simulateOutcome() {
        int outcome = random.nextInt(10); // 0-9

        if (outcome < 5) {
            return; // ~50%: success
        }
        if (outcome == 5 || outcome == 6) {
            throw new IllegalArgumentException("Demo-mode simulated validation failure");
        }
        if (outcome == 7) {
            throw new NotFoundException("Demo-mode simulated not-found");
        }
        if (outcome == 8) {
            throw new FatalProcessingException("Demo-mode simulated fatal processing failure");
        }
        throw new UpstreamUnavailableException("Demo-mode simulated upstream unavailable condition");
    }

    /** Fixed set of HTTP statuses this simulator can produce, for tests/documentation. */
    public static List<Integer> possibleStatusCodes() {
        return List.of(200, 400, 404, 500, 503);
    }
}
