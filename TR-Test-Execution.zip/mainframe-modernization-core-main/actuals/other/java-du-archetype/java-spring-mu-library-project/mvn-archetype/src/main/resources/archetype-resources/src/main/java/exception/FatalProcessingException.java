package ${package}.exception;

/**
 * Signals a fatal, unrecoverable processing failure in this Migration Unit. Propagates
 * uncaught to {@link GlobalExceptionHandler} -> HTTP 500.
 */
public class FatalProcessingException extends RuntimeException {

    public FatalProcessingException(String message) {
        super(message);
    }

    public FatalProcessingException(String message, Throwable cause) {
        super(message, cause);
    }
}
