package ${package}.model;

/**
 * Request model for the default placeholder entry point.
 *
 * @param key lookup key (single param in, per the archetype's default shape)
 */
public record ${entityName}Request(String key) {

    public ${entityName}Request {
        if (key == null || key.isBlank()) {
            throw new IllegalArgumentException("key is required");
        }
    }
}
