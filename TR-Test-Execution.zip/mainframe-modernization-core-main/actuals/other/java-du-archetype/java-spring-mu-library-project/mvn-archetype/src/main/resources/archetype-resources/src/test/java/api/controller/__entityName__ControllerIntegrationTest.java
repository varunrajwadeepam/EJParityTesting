package ${package}.api.controller;

import ${package}.exception.${entityName}GlobalExceptionHandler;
import ${package}.mapper.${entityName}Mapper;
import ${package}.demo.${entityName}DemoResponseSimulator;
import ${package}.service.${entityName}Service;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Random;

import static org.hamcrest.Matchers.isOneOf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

/**
 * Builds MockMvc directly from real controller/service/mapper/advice instances via
 * {@code standaloneSetup} -- no Spring context, no {@code @SpringBootConfiguration} needed --
 * proving this module's web slice is self-contained independent of any composed app. Uses a
 * real {@code Random} (not seeded) since the assertion only checks membership in the five
 * documented status codes, never a specific one.
 */
class ${entityName}ControllerIntegrationTest {

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        ${entityName}Service service = new ${entityName}Service(
                new ${entityName}DemoResponseSimulator(new Random()), new ${entityName}Mapper());
        ${entityName}Controller controller = new ${entityName}Controller(service);
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new ${entityName}GlobalExceptionHandler())
                .build();
    }

    @Test
    void get${entityName}_returnsOneOfTheDocumentedStatusCodes() throws Exception {
        mockMvc.perform(get("/v1/${entityName.toLowerCase()}s").param("key", "ABC123"))
                .andExpect(result -> {
                    int status = result.getResponse().getStatus();
                    org.hamcrest.MatcherAssert.assertThat(status, isOneOf(200, 400, 404, 500, 503));
                });
    }

    @Test
    void get${entityName}_missingKey_returns400() throws Exception {
        mockMvc.perform(get("/v1/${entityName.toLowerCase()}s"))
                .andExpect(result -> org.hamcrest.MatcherAssert.assertThat(
                        result.getResponse().getStatus(), isOneOf(400)));
    }
}
