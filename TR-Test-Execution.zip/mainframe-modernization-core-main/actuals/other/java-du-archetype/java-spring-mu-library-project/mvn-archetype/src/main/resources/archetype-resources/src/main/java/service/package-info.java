/**
 * Business/use-case logic for this Migration Unit -- one {@code @Service} per entry point.
 * Depends on {@code mapper} and, once wired, an upstream common Migration Unit's beans (see the
 * SHARED LIBRARY / UPSTREAM MU EXTENSION POINT in pom.xml). Must not hold HTTP or JDBC/JPA types.
 */
package ${package}.service;
