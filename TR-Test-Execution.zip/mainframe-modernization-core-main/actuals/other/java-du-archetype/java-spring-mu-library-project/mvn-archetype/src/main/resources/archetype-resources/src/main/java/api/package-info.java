/**
 * Inbound HTTP layer for this Migration Unit: {@code @RestController}s only.
 */
package ${package}.api;
