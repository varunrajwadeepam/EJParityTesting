package ${package}.exception;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.ServletWebRequest;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class ${entityName}GlobalExceptionHandlerTest {

    private final ${entityName}GlobalExceptionHandler handler = new ${entityName}GlobalExceptionHandler();
    private final ServletWebRequest request = new ServletWebRequest(new MockHttpServletRequest());

    @Test
    void handleGenericException_returns500() {
        ResponseEntity<Map<String, Object>> response =
                handler.handleGenericException(new RuntimeException("boom"), request);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(response.getBody()).containsEntry("status", 500);
    }

    @Test
    void handleValidationException_returns400() {
        ResponseEntity<Map<String, Object>> response =
                handler.handleValidationException(new IllegalArgumentException("bad key"), request);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    }

    @Test
    void handleNotFoundException_returns404() {
        ResponseEntity<Map<String, Object>> response =
                handler.handleNotFoundException(new NotFoundException("missing"), request);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
    }

    @Test
    void handleFatalProcessingException_returns500() {
        ResponseEntity<Map<String, Object>> response =
                handler.handleFatalProcessingException(new FatalProcessingException("boom"), request);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Test
    void handleUpstreamUnavailableException_returns503() {
        ResponseEntity<Map<String, Object>> response =
                handler.handleUpstreamUnavailableException(new UpstreamUnavailableException("down"), request);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.SERVICE_UNAVAILABLE);
    }
}
