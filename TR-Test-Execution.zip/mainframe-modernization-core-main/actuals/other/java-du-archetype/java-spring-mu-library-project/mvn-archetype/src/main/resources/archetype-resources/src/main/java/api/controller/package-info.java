/**
 * REST controllers for this Migration Unit's endpoint(s). Controllers stay thin: resolve
 * parameters, delegate to one {@code service} class, return the result. No business logic,
 * no direct exception-to-status mapping (see {@code exception.GlobalExceptionHandler}).
 */
package ${package}.api.controller;
