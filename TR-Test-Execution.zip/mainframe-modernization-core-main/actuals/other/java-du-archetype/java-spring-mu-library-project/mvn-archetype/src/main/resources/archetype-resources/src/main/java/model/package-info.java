/**
 * Request/response records for this Migration Unit's endpoint(s). No HTTP or persistence types.
 */
package ${package}.model;
