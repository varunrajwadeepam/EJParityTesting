@echo off
setlocal
REM Generates a new Migration Unit library module from trvs-mu-library-archetype.
REM
REM Usage: copy this file, edit the ARCHETYPE_* values below, then run:
REM   generate.cmd
REM
REM IMPORTANT: unlike trvs-rest-api-service-archetype, this archetype generates a SINGLE flat
REM module (packaging=jar, no reactor wrapper). It is meant to be dropped as a new sibling
REM directory under an EXISTING solution reactor -- point ARCHETYPE_OUTPUT_DIR at that
REM reactor's root (e.g. solution/) and set ARCHETYPE_ARTIFACT_ID to the module's own directory
REM name (e.g. revdb-subset3-endpoint-1). After generation you must still, by hand:
REM   1. Add <module>ARCHETYPE_ARTIFACT_ID</module> to the reactor's pom.xml.
REM   2. Add a <dependency> on this artifact to the app module's pom.xml.
REM See ../README.md "Wiring a generated MU into the solution" for both edits in full.

REM ============================================================================
REM EDIT THESE VALUES
REM ============================================================================

REM --- Which archetype to generate from (rarely needs to change) ---
set "ARCHETYPE_SOURCE_GROUP_ID=com.insurance.archetypes"
set "ARCHETYPE_SOURCE_ARTIFACT_ID=trvs-mu-library-archetype"
set "ARCHETYPE_SOURCE_VERSION=1.0.0-SNAPSHOT"

REM --- New module Maven coordinates (required). artifactId doubles as the generated directory
REM     name -- it must not collide with any existing module under ARCHETYPE_OUTPUT_DIR. ---
set "ARCHETYPE_GROUP_ID=com.insurance.CHANGEME"
set "ARCHETYPE_ARTIFACT_ID=CHANGEME-endpoint-1"
set "ARCHETYPE_VERSION=1.0.0-SNAPSHOT"
set "ARCHETYPE_PACKAGE=com.insurance.CHANGEME.endpoint1"

REM --- Archetype-specific properties (required) ---
set "ARCHETYPE_MU_NAME=CHANGEME Endpoint 1"
set "ARCHETYPE_ENTITY_NAME=CHANGEME"

REM --- Target solution folder this module is generated INTO as a new sibling directory
REM     (e.g. the existing solution/ reactor root -- NOT a throwaway staging folder; this
REM     archetype has no reactor wrapper to flatten). Defaults to the current directory. ---
set "ARCHETYPE_OUTPUT_DIR=."

REM ============================================================================
REM DO NOT EDIT BELOW THIS LINE
REM ============================================================================

if "%ARCHETYPE_GROUP_ID%"=="com.insurance.CHANGEME" goto :needs_edit
if "%ARCHETYPE_ARTIFACT_ID%"=="CHANGEME-endpoint-1" goto :needs_edit
if "%ARCHETYPE_PACKAGE%"=="com.insurance.CHANGEME.endpoint1" goto :needs_edit
if "%ARCHETYPE_MU_NAME%"=="CHANGEME Endpoint 1" goto :needs_edit
if "%ARCHETYPE_ENTITY_NAME%"=="CHANGEME" goto :needs_edit
goto :run

:needs_edit
echo Edit the ARCHETYPE_* values at the top of this script before running it (still set to a CHANGEME placeholder). 1>&2
exit /b 1

:run
echo Generating %ARCHETYPE_ARTIFACT_ID% from %ARCHETYPE_SOURCE_GROUP_ID%:%ARCHETYPE_SOURCE_ARTIFACT_ID%:%ARCHETYPE_SOURCE_VERSION% into %ARCHETYPE_OUTPUT_DIR% ...

call mvn archetype:generate ^
    "-DarchetypeGroupId=%ARCHETYPE_SOURCE_GROUP_ID%" ^
    "-DarchetypeArtifactId=%ARCHETYPE_SOURCE_ARTIFACT_ID%" ^
    "-DarchetypeVersion=%ARCHETYPE_SOURCE_VERSION%" ^
    -DinteractiveMode=false ^
    "-DoutputDirectory=%ARCHETYPE_OUTPUT_DIR%" ^
    "-DgroupId=%ARCHETYPE_GROUP_ID%" ^
    "-DartifactId=%ARCHETYPE_ARTIFACT_ID%" ^
    "-Dversion=%ARCHETYPE_VERSION%" ^
    "-Dpackage=%ARCHETYPE_PACKAGE%" ^
    "-DmuName=%ARCHETYPE_MU_NAME%" ^
    "-DentityName=%ARCHETYPE_ENTITY_NAME%"

if errorlevel 1 (
    echo Archetype generation failed -- see Maven output above. 1>&2
    exit /b 1
)

echo Done. Generated module: "%ARCHETYPE_OUTPUT_DIR%\%ARCHETYPE_ARTIFACT_ID%"
echo Remaining manual steps (this archetype cannot edit existing files):
echo   1. Add ^<module^>%ARCHETYPE_ARTIFACT_ID%^</module^> to the solution reactor's pom.xml.
echo   2. Add a ^<dependency^> on this artifact to the app module's pom.xml.

endlocal
