# Target Stack — Java 21 / Spring Boot 3.4

> **Route key** `java` · **DU distributive** `trvs-rest-api-service-archetype` (basement) +
> `trvs-mu-library-archetype` (MU module)
>
> Only what the archetypes actually embody. Module shape, ownership, wiring, test design and story
> rules live in `pipeline-DU-{TSA,LLD,EPICS}-instructions-v0.md` and are not repeated here.
>
> **Authority:** the generated POM wins over this file. A difference is a route-back to the DU.

---

## 1. Pins

| | |
|---|---|
| Java | 21 (`java.version`, both POMs) |
| Spring Boot | 3.4.2 (`spring-boot-starter-parent`, inherited independently by each module) |
| JaCoCo | 0.8.12 |
| **App module only** | springdoc 2.7.0 · `com.ibm.db2:jcc` 11.5.8.0 · rest-assured 5.4.0 |

**There is no parent POM.** The reactor root is a `packaging=pom` aggregator; every module inherits
`spring-boot-starter-parent` directly. No shared `dependencyManagement` — cross-module version
alignment is convention only.

---

## 2. What the basement gives you

**Live:** boots with zero DB2 · actuator `health,info,metrics` at `/actuator` · springdoc +
Swagger UI at `/swagger-ui.html` · Logback with a `%X{correlationId}` pattern · HikariCP configured
from `DB_URL` / `DB_USERNAME` / `DB_PASSWORD` / `DB_SCHEMA` · `data/entity` + `data/repository` stub
packages · `app.demo.enabled: true`.

**Inert or absent — each is a route-back, not a local fix:**

| Not there | Detail |
|---|---|
| A usable `DataSource` | `DataSourceAutoConfiguration` + `DataSourceTransactionManagerAutoConfiguration` (and `HibernateJpaAutoConfiguration` under `dblayer=jpa`) are **excluded**. That exclusion is why it boots with no database. First data-access MU needs it removed. |
| Security | `SecurityConfig` is entirely commented out; `spring-boot-starter-security` is deliberately absent. No JWT, no IDP. |
| A correlation-ID filter | No `Filter`, `Interceptor` or `WebMvcConfigurer` anywhere. The MDC value is set per-request **by each MU's own controller**. |
| Scoped error handling | The basement's `GlobalExceptionHandler` is **unscoped** `@RestControllerAdvice`. Neither it nor an MU's carries `@Order`, so for a shared exception type the winner is undefined. |
| A free URL namespace | The basement serves its own live placeholder at `/v1/{entityName-lowercased}s`. A colliding `entityName` collides on path, not only on bean name. |

**ORM is a generation-time choice, not a stack fact.** `dblayer` ∈ {`jpa`, `jdbc`}, **default
`jdbc`** (`NamedParameterJdbcTemplate`). Schema comes from `DB_SCHEMA` at the Hikari connection
level and is **never** written into Java — no `@Table(schema=…)`.

---

## 3. What a generated MU has on its classpath

`spring-boot-starter-web`, `spring-boot-starter-validation`, `spring-boot-starter-test`. **That is
all.** No spring-boot-maven-plugin. Required generation properties beyond the Maven standards:
`muName`, `entityName`.

An MU must add to its own POM, before writing code that needs it:

| To do this | Add |
|---|---|
| JPA data access | `spring-boot-starter-data-jpa` + `com.ibm.db2:jcc` (neither is inherited) |
| JDBC data access | `spring-boot-starter-jdbc` + `com.ibm.db2:jcc` |
| `@Operation` / `@ApiResponse` | `springdoc-openapi-starter-webmvc-ui` — app-module-only today, so these annotations **do not compile** in an MU as generated |
| Exclude config/DTO from coverage | a `<excludes>` block (see §5) |

---

## 4. The error contract, as the template implements it

Handler order in `{Entity}GlobalExceptionHandler`, scoped `@RestControllerAdvice(basePackages = "{package}")`:

| Handled | Status |
|---|---|
| `Exception` — **catch-all, declared first** | 500 |
| `ConstraintViolationException`, `MissingServletRequestParameterException`, `IllegalArgumentException` | 400 |
| `NotFoundException` | 404 |
| `FatalProcessingException` | 500 |
| `UpstreamUnavailableException` | 503 |

Consequences to design around:

- **`@Valid` on a request body yields 500, not 400.** There is no `MethodArgumentNotValidException`
  handler; it falls to the catch-all. The template's 400 path is `@Validated` on the class plus
  `@NotBlank` on a `@RequestParam`. Adding a POST body means adding that handler.
- **Any new exception without its own `@ExceptionHandler` becomes a 500** — it does not propagate.
- The JSON envelope (`timestamp`, `status`, `error`, `message`, `path`, `correlationId`) and the
  correlation ID are **MU-owned**, not inherited: the MU's controller does `MDC.put` / `MDC.remove`
  in a try/finally around the call. Omit that and `correlationId` is `null` in every error body.
- The three exception classes are **per-MU private copies** in the MU's own package, unprefixed.
  There is no shared hierarchy; the basement has its own differently-named set
  (`FatalDataAccessException`, `ViewOverflowException`, its own `NotFoundException`).

---

## 5. Two facts that bite

**`entityName` is an API decision, not a naming preference.** It prefixes
`{Entity}Controller|Service|Mapper|Request|Response|GlobalExceptionHandler|DemoResponseSimulator`
(the three exception classes stay unprefixed) *and* fixes the route:
`@RequestMapping("/v1/{entityName.toLowerCase()}s")`. It is frozen at generation time — before the
OpenAPI contract exists.

**The MU coverage gate has no `<excludes>`.** 80% LINE, `haltOnFailure`, bound to `verify`; the app
module excludes its boot class, `OpenApiConfig` and `SecurityConfig`, the MU excludes nothing. Every
config and DTO class counts. Escape hatch: `-Djacoco.skip=true`.

**Demo mode has no flag in an MU.** The app has `app.demo.enabled`; an MU has no `application.yml`,
so its demo path is retired only by replacing the `simulateOutcome()` call and deleting `demo/`.

---

## 6. Archetype gaps → route-back

| Gap | Consequence |
|---|---|
| No data-layer mode in the MU archetype | every data-access MU hand-adds starter + driver |
| No springdoc in the MU | OpenAPI annotations unavailable as generated |
| No common-style (no-REST) MU mode | a common MU is hand-authored from the endpoint output |
| No `@Disabled` placeholder-test convention in the templates | the rule has no generated example |
| No security | any auth requirement is a basement change |
| `archetype:generate` never edits an existing file (per its own descriptor) | **both** wiring edits are manual — reactor `<module>` and app `<dependency>`. Contradicts the auto-append claim in the LLD instructions; unresolved. |
