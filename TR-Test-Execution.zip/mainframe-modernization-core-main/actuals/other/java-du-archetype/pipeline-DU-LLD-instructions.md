# DU Instructions — LLD Pipeline (v0)

**Audience:** LLD stage agents (`contract`, `data`, `scaffold`, `test`, `verify`). Read before
producing any design artifact.

**What this is.** The pipeline-oriented usage contract for the Deployment Unit currently shipped in
the DU distributive: `trvs-mu-library-archetype` (Java 21 / Spring Boot 3.4, one flat library module
per MU). All construction detail lives in the distributive — not here, not in the pipeline. Replace
the archetype and this document is replaced with its counterpart; the pipeline itself changes
nothing.

**Prime directive.** LLD specifies **how this MU's module is embedded into an already-running
application**. It designs an attachment, not a deployment.

---

## 1. Solution facts

Consume the read-only solution-context block TSA recorded (solution root, app module, app base
package, sibling modules, stack versions, basement-provided concerns). Re-scan the reactor only to
confirm it still matches; report a mismatch rather than silently re-deriving.

---

## 2. The archetype — what a module is made of

Coordinates: `com.insurance.archetypes:trvs-mu-library-archetype:1.0.0-SNAPSHOT`

Properties to specify in the design: `groupId`, `artifactId`, `package`, `muName`, `entityName`.

```text
<artifactId>/                              packaging=jar; parent=spring-boot-starter-parent
├── pom.xml                                (managed versions ONLY; no repackage plugin)
└── src/main/java/<package>/
    ├── api/controller/<Entity>Controller.java        REST surface (endpoint MUs only)
    ├── service/<Entity>Service.java                  business logic
    ├── mapper/<Entity>Mapper.java                    translation
    ├── model/<Entity>Request.java, <Entity>Response.java
    ├── exception/<Entity>GlobalExceptionHandler.java @RestControllerAdvice(basePackages=<package>)
    │   NotFoundException→404  FatalProcessingException→500  UpstreamUnavailableException→503
    └── demo/<Entity>DemoResponseSimulator.java       placeholder responses until logic lands
    src/test/java/<package>/                          mirrored package-for-package
```

---

## 3. Embedding rules

| ID | Rule |
|---|---|
| DU-LLD-01 | **One MU = one flat module.** Never design a parent POM per MU, never layer modules, never a fat JAR. Layers are the packages above. |
| DU-LLD-02 | Internal call direction: `api → service → mapper → model`. No reverse edges. |
| DU-LLD-03 | `package` = `<app base package>.<mu package>`. This puts the MU under the app's default component scan — **no `@ComponentScan` edit in the app module**. A sibling package tree would require one and is forbidden. |
| DU-LLD-04 | **Prefix every shared-name class with the MU's entity name** (`<Entity>GlobalExceptionHandler`, `<Entity>DemoResponseSimulator`). Spring derives bean names from the simple class name; unprefixed names collide across MUs in the one shared context. This is a previously-hit `ConflictingBeanDefinitionException`, not style. |
| DU-LLD-05 | Scope every `@RestControllerAdvice` with `basePackages = "<this MU's package>"`. Unscoped advice is global and shadows every other MU's. |
| DU-LLD-06 | Never depend on the app module. May depend on an upstream common MU; never on a sibling endpoint MU. |
| DU-LLD-07 | Basement concerns (logging, security, global error handling, app config) are consumed, not designed. The MU designs only its own exception→status mapping, inside its own scoped advice. |
| DU-LLD-08 | External-module stubs / ACL adapters go in a package **inside this module**. No separate stub module. |
| DU-LLD-09 | Shared static utilities per ADR-CAGEN-TIR-UTILS: stateless static helpers in the designated **common MU module** — never injected components, never duplicated into this module. If this MU does not own that module, depend on it. |
| DU-LLD-10 | **No MU carries a deployable.** Zero `deployableUnit: true` rows. Record the discovered app module as the pre-existing deployable and verify it was found. |
| DU-LLD-11 | Design artifacts only. Nothing compilable or buildable is written under the LLD output folder — no `.java`, no `pom.xml`, no project files. |

### MU with no REST surface (common-style)

The archetype has **no common-style mode** today. Design such a module as the same shape with
`api/controller`, `demo` and the REST-flavoured `exception` layer **omitted** — keep `service` plus
whatever domain packages the logic needs, still under `<app base package>.<mu package>`, still wired
per §4. Note in the design that generation is hand-authored from the archetype output rather than a
clean generate.

---

## 4. Wiring — the only writes outside this MU's module

Specify these as explicit, ordered steps:

1. **Generate** the module into the solution root from the archetype. `archetype:generate`
   **auto-appends** the `<module>` entry to `solution/pom.xml` when run from inside that reactor.
2. **Add a `<dependency>`** on the new artifact to the app module's `pom.xml`. Always manual —
   `archetype:generate` never edits an existing file.
3. **`mvn install` from the solution root** before `spring-boot:run`. `spring-boot:run` resolves
   sibling modules from the local Maven repository, not the in-memory reactor.
4. **Verify live** through the running app, not only via the module's own tests.

Those two pom lines are the complete set of permitted edits outside `solution/<this-mu-module>/**`.
Nothing else in the reactor may be touched.

---

## 5. Test design

| ID | Rule |
|---|---|
| DU-LLD-20 | Mirror `src/test/java/<package>/…` against main, package-for-package. |
| DU-LLD-21 | Stack: JUnit 5 + Mockito + AssertJ. |
| DU-LLD-22 | Controller tests build MockMvc standalone from real instances (`MockMvcBuilders.standaloneSetup(...)`). **Never** `@WebMvcTest` / `@SpringBootTest` — the MU has no `@SpringBootApplication` of its own and must be testable before it is wired anywhere. |
| DU-LLD-23 | 80% JaCoCo line gate at `mvn verify`, per module. |
| DU-LLD-24 | The module must pass `mvn -pl <mu-module> -am verify` **standalone, before wiring** into the app. |
| DU-LLD-25 | Every implemented class gets a real test; every placeholder class gets one `@Disabled` stub test naming what must happen before it is enabled. |

---

## 6. Never

- Design a parent POM, a module hierarchy, a fat JAR, or a `java -jar` run command for an MU.
- Design `@SpringBootApplication`, app-wide `scanBasePackages`, `application.yml` at app level, or
  app-level logging config.
- Prescribe any edit to the app module or a sibling module beyond the single `<dependency>` line.
- Emit source or build files into the LLD output folder.

---

## 7. Route-back

A gap in the basement or in an upstream common module is recorded as a requirement against that
owner and the design proceeds on the assumption it will be met. Never design a local duplicate, and
never design an edit to a module this MU does not own.

---

## 8. Supersedes

Where the shipped LLD pipeline rules conflict, this document wins for a DU-based portfolio:

- `deployment-scaffold-java` skill: the parent-POM-plus-five-layer-modules shape, the
  `{mu-prefix}-services` fat JAR, app-level `@SpringBootApplication` / `application.yml` /
  `logback-spring.xml` templates, and the `mvn package -pl …-services -am` + `java -jar` deployment
  commands.
- `[PROJ-01]` one Maven parent POM per MU; `[PROJ-02]` `{mu-prefix}-{layer}` module naming;
  `[PROJ-05]` services module as the deployable.
- The scaffold gate "exactly one row carries `deployableUnit: true`; more than one, or none, is a
  blocking defect" → **zero rows, and the pre-existing deployable was discovered and recorded**.
