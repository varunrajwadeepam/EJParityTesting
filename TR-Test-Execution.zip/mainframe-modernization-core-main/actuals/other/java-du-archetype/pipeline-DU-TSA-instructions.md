# DU Instructions — TSA Pipeline (v0)

**Audience:** TSA stage agents (`tsa-target`, `tsa-assemble`). Read before producing any
target-state artifact.

**What this is.** The pipeline-oriented usage contract for the Deployment Unit currently shipped in
the DU distributive: `trvs-mu-library-archetype` (Java 21 / Spring Boot 3.4, one flat library module
per MU). All construction detail lives in the distributive — not here, not in the pipeline. Replace
the archetype and this document is replaced with its counterpart; the pipeline itself changes
nothing.

**Prime directive.** The solution already exists and already runs. TSA describes how **this MU's one
module attaches** to it. TSA never designs an application.

---

## 1. Solution facts — discover, record, do not invent

The shared solution root is given by the pipeline infrastructure config (default `../../solution`).
Read it before writing anything.

| ID | Fact to establish | Where from |
|---|---|---|
| DU-TSA-01 | Solution root path, resolved and confirmed to exist | infra config / constitution |
| DU-TSA-02 | Reactor root `pom.xml`, its `<modules>` list | solution root |
| DU-TSA-03 | The **app module** (the one with `@SpringBootApplication`) and its **base package** | reactor scan |
| DU-TSA-04 | Existing sibling modules: artifactId, package, common vs endpoint | reactor scan |
| DU-TSA-05 | Stack versions actually in force (Java, Spring Boot, build) | app / parent pom |
| DU-TSA-06 | Cross-cutting services the basement already provides: logging, security, error handling, shared config | app module source |

If the solution root is missing or holds no app module, **stop and report** — the DU has not run.
Do not scaffold one.

---

## 2. Architectural rules this MU inherits

| ID | Rule |
|---|---|
| DU-TSA-10 | **One MU contributes exactly one module.** Layering is expressed as *packages inside* that module, never as sibling modules. |
| DU-TSA-11 | The module is a **plain library JAR** — no `@SpringBootApplication`, no fat-JAR packaging, not independently runnable. |
| DU-TSA-12 | Module base package = `<app base package>.<this MU's package>`. Never a sibling package tree. |
| DU-TSA-13 | **No MU carries a deployable.** The deployable is the pre-existing app module — an environmental precondition, recorded as discovered, never designed and never owned. |
| DU-TSA-14 | Dependency direction: endpoint→common ALLOWED; common→endpoint FORBIDDEN; endpoint→sibling endpoint FORBIDDEN; any MU→app module FORBIDDEN. |
| DU-TSA-15 | Cross-cutting concerns are **basement-provided**. Declare the dependency on them; never design logging, security, global error handling or app-wide config as this MU's target architecture. |
| DU-TSA-16 | Sibling modules are **immutable dependencies**. Model them as given interfaces; never restructure, re-layer or re-scope them. |
| DU-TSA-17 | External-module stubs / ACL adapters for this MU live in a **package inside this MU's module**, not as a separate module. |
| DU-TSA-18 | Shared static utilities (e.g. CA:Gen `TIR*` per ADR-CAGEN-TIR-UTILS) belong to the **designated common MU module**. If this MU is not its owner: depend on it, never copy it. If it does not exist yet, that is a prerequisite to route back (§5), not something this MU creates. |
| DU-TSA-19 | Do not re-decide DU-fixed matters: stack, versions, hosting, packaging, module granularity, build tooling. Record them as **inherited constraints**, and raise a route-back if one is genuinely wrong. |

Target shape to keep in view:

```text
solution/                     reactor root (DU-owned)
├── <app-module>/             basement: bootstrap, logging, security, error handling, config
├── <sibling MU modules>/     immutable dependencies
└── <this-mu-module>/         THIS MU's single contribution
    └── <app base pkg>.<mu pkg>.{api|service|mapper|model|exception|...}
```

---

## 3. Output contract

| ID | Requirement |
|---|---|
| DU-TSA-20 | Record discovered DU facts (§1) as a **read-only solution context** block in the target-state artifact, marked discovered-and-not-owned. Downstream LLD and IMPLEMENT consume these instead of re-scanning. |
| DU-TSA-21 | The Target Solution Structure table carries **exactly one owned row** — this MU's module. Sibling and app modules may appear only as context rows, explicitly flagged read-only. |
| DU-TSA-22 | The `Layer` column describes **packages within the module**, not module names. Do not emit `{mu-prefix}-{layer}` module names. |
| DU-TSA-23 | Zero rows carry `deployableUnit: true`. Record the discovered deployable in the solution-context block instead. |
| DU-TSA-24 | State the module's `dependsOn` set explicitly, and confirm it satisfies DU-TSA-14. |
| DU-TSA-25 | ADRs: only decisions this MU actually owns (internal decomposition, data access shape, mapping strategy, stub boundaries). Inherited constraints go in a separate inherited-constraints list, not as new ADRs. |

---

## 4. Never

- Design a solution, reactor, parent POM, module hierarchy or deployment topology.
- Emit a multi-module target structure for one MU.
- Assign this MU a deployable, a `main`, or app-level configuration.
- Design cross-cutting infrastructure the basement already owns.
- Prescribe any change to the app module or to a sibling module.

---

## 5. Route-back

If the basement or an upstream common module is insufficient for this MU's target architecture:
record it as a **requirement raised against the owning unit** (owning MU, or the basement virtual
MU), and design this MU as if that requirement will be met by its owner. Never design around it by
duplicating the capability locally, and never design a change to a module this MU does not own.

---

## 6. Supersedes

Where the shipped TSA pipeline rules conflict, this document wins for a DU-based portfolio:

- `[FMT-10]` "one row per distinct layer, naming the project or module that layer becomes" and
  "identify the one deployable unit" → one row per **module** (one owned), zero deployables.
- Any instruction to produce `{mu-prefix}-{layer}` module names.
