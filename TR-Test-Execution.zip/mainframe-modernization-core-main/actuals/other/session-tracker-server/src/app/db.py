import os
import time

import psycopg
from psycopg.rows import dict_row

DSN = os.environ.get("DATABASE_URL", "postgresql://status:status@localhost:5432/status_works")

SCHEMA = """
CREATE TABLE IF NOT EXISTS session_stat (
    session_id       TEXT PRIMARY KEY,
    work_id          TEXT NOT NULL DEFAULT '',
    work_phase       TEXT NOT NULL DEFAULT '',
    project_dir      TEXT NOT NULL DEFAULT '',
    model            TEXT NOT NULL DEFAULT '',
    effort           TEXT,
    started_at       TIMESTAMPTZ,
    last_updated     TIMESTAMPTZ,
    cost_usd         DOUBLE PRECISION NOT NULL DEFAULT 0,
    ctx_pct          DOUBLE PRECISION,
    active_sec       DOUBLE PRECISION NOT NULL DEFAULT 0,
    turns            INTEGER NOT NULL DEFAULT 0,
    tools            INTEGER NOT NULL DEFAULT 0,
    compacts         INTEGER NOT NULL DEFAULT 0,
    tokens_in        BIGINT NOT NULL DEFAULT 0,
    tokens_out       BIGINT NOT NULL DEFAULT 0,
    tokens_cw        BIGINT NOT NULL DEFAULT 0,
    tokens_cr        BIGINT NOT NULL DEFAULT 0,
    raw              JSONB NOT NULL,
    received_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS session_stat_work_id_idx ON session_stat (work_id);
"""


def connect():
    return psycopg.connect(DSN, row_factory=dict_row)


def init(retries=30, delay=1.0):
    """Creates the schema, waiting for the database to accept connections."""
    for attempt in range(retries):
        try:
            with connect() as conn:
                conn.execute(SCHEMA)
            return
        except psycopg.OperationalError:
            if attempt == retries - 1:
                raise
            time.sleep(delay)
