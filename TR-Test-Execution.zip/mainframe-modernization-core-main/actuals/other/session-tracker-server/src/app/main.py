from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from psycopg.types.json import Jsonb
from pydantic import BaseModel, ConfigDict, Field

from . import db


@asynccontextmanager
async def lifespan(_app):
    db.init()
    yield


app = FastAPI(title="status-works", lifespan=lifespan)


class Tokens(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)
    in_: int = Field(0, alias="in")
    out: int = 0
    cw: int = 0
    cr: int = 0


class SessionStat(BaseModel):
    """The record produced by `>>>save save` (extra fields are kept in `raw`)."""
    model_config = ConfigDict(extra="allow")
    session_id: str = Field(min_length=1)
    work_id: str = Field(pattern=r"\S")  # required, non-blank
    work_phase: Optional[str] = ""
    project_dir: Optional[str] = ""
    model: Optional[str] = ""
    effort: Optional[str] = None
    started_at: Optional[datetime] = None
    last_updated: Optional[datetime] = None
    cost_usd: Optional[float] = 0
    ctx_pct: Optional[float] = None
    active_sec: Optional[float] = 0
    turns: Optional[int] = 0
    tools: Optional[int] = 0
    compacts: Optional[int] = 0
    tokens: Tokens = Tokens()


UPSERT = """
INSERT INTO session_stat (session_id, work_id, work_phase, project_dir, model, effort,
    started_at, last_updated, cost_usd, ctx_pct, active_sec, turns, tools, compacts,
    tokens_in, tokens_out, tokens_cw, tokens_cr, raw, received_at)
VALUES (%(session_id)s, %(work_id)s, %(work_phase)s, %(project_dir)s, %(model)s, %(effort)s,
    %(started_at)s, %(last_updated)s, %(cost_usd)s, %(ctx_pct)s, %(active_sec)s, %(turns)s,
    %(tools)s, %(compacts)s, %(tokens_in)s, %(tokens_out)s, %(tokens_cw)s, %(tokens_cr)s,
    %(raw)s, now())
ON CONFLICT (session_id) DO UPDATE SET
    work_id = EXCLUDED.work_id, work_phase = EXCLUDED.work_phase,
    project_dir = EXCLUDED.project_dir, model = EXCLUDED.model, effort = EXCLUDED.effort,
    started_at = EXCLUDED.started_at, last_updated = EXCLUDED.last_updated,
    cost_usd = EXCLUDED.cost_usd, ctx_pct = EXCLUDED.ctx_pct, active_sec = EXCLUDED.active_sec,
    turns = EXCLUDED.turns, tools = EXCLUDED.tools, compacts = EXCLUDED.compacts,
    tokens_in = EXCLUDED.tokens_in, tokens_out = EXCLUDED.tokens_out,
    tokens_cw = EXCLUDED.tokens_cw, tokens_cr = EXCLUDED.tokens_cr,
    raw = EXCLUDED.raw, received_at = now()
RETURNING (xmax = 0) AS inserted
"""

TOTALS = """
count(*)::int AS sessions,
coalesce(sum(cost_usd), 0) AS cost_usd,
coalesce(sum(active_sec), 0) AS active_sec,
coalesce(sum(turns), 0)::int AS turns,
coalesce(sum(tools), 0)::int AS tools,
coalesce(sum(compacts), 0)::int AS compacts,
coalesce(sum(tokens_in), 0)::bigint AS tokens_in,
coalesce(sum(tokens_out), 0)::bigint AS tokens_out,
coalesce(sum(tokens_cw), 0)::bigint AS tokens_cw,
coalesce(sum(tokens_cr), 0)::bigint AS tokens_cr,
min(started_at) AS first_started_at,
max(last_updated) AS last_updated
"""


@app.get("/work-ids")
def list_work_ids() -> list[dict[str, Any]]:
    """All non-empty work-ids with their session count and total cost."""
    with db.connect() as conn:
        return conn.execute(
            "SELECT work_id, count(*)::int AS sessions, coalesce(sum(cost_usd), 0) AS cost_usd,"
            " max(last_updated) AS last_updated FROM session_stat"
            " WHERE work_id <> '' GROUP BY work_id ORDER BY work_id").fetchall()


@app.post("/sessions")
def store_session(stat: SessionStat) -> dict[str, Any]:
    """Stores (or replaces, by session_id) one session's state."""
    t = stat.tokens
    params = dict(
        session_id=stat.session_id, work_id=stat.work_id or "", work_phase=stat.work_phase or "",
        project_dir=stat.project_dir or "", model=stat.model or "", effort=stat.effort,
        started_at=stat.started_at, last_updated=stat.last_updated, ctx_pct=stat.ctx_pct,
        cost_usd=stat.cost_usd or 0, active_sec=stat.active_sec or 0, turns=stat.turns or 0,
        tools=stat.tools or 0, compacts=stat.compacts or 0,
        tokens_in=t.in_, tokens_out=t.out, tokens_cw=t.cw, tokens_cr=t.cr,
        raw=Jsonb(stat.model_dump(mode="json", by_alias=True)))
    with db.connect() as conn:
        inserted = conn.execute(UPSERT, params).fetchone()["inserted"]
    return {"session_id": stat.session_id, "work_id": params["work_id"],
            "result": "created" if inserted else "updated"}


@app.get("/work-ids/{work_id}/stat")
def work_id_stat(work_id: str) -> dict[str, Any]:
    """Totals for a work-id, a per-phase breakdown and its sessions."""
    with db.connect() as conn:
        total = conn.execute(
            "SELECT " + TOTALS + " FROM session_stat WHERE work_id = %s", (work_id,)).fetchone()
        if not total["sessions"]:
            raise HTTPException(404, "unknown work-id")
        phases = conn.execute(
            "SELECT work_phase AS phase, " + TOTALS + " FROM session_stat"
            " WHERE work_id = %s GROUP BY work_phase ORDER BY min(started_at)",
            (work_id,)).fetchall()
        sessions = conn.execute(
            "SELECT session_id, work_phase AS phase, model, project_dir, started_at, last_updated,"
            " cost_usd, active_sec, turns, tools, compacts, tokens_in, tokens_out, tokens_cw,"
            " tokens_cr FROM session_stat WHERE work_id = %s ORDER BY started_at",
            (work_id,)).fetchall()
    return {"work_id": work_id, "total": total, "phases": phases, "sessions": sessions}


@app.get("/summary")
def summary() -> dict[str, Any]:
    """Every work-id with its totals and per-phase totals, plus a grand total (for the UI)."""
    with db.connect() as conn:
        rows = conn.execute(
            "SELECT work_id, work_phase AS phase, " + TOTALS + " FROM session_stat"
            " WHERE work_id <> '' GROUP BY work_id, work_phase"
            " ORDER BY work_id, min(started_at)").fetchall()
        grand = conn.execute(
            "SELECT " + TOTALS + " FROM session_stat WHERE work_id <> ''").fetchone()
    works: dict[str, dict[str, Any]] = {}
    for row in rows:
        work = works.setdefault(row["work_id"], {"work_id": row["work_id"], "phases": []})
        work["phases"].append({k: v for k, v in row.items() if k != "work_id"})
    for work in works.values():
        phases = work["phases"]
        work["total"] = {
            "sessions": sum(p["sessions"] for p in phases),
            "cost_usd": sum(p["cost_usd"] for p in phases),
            "active_sec": sum(p["active_sec"] for p in phases),
            "turns": sum(p["turns"] for p in phases),
            "tools": sum(p["tools"] for p in phases),
            "tokens_in": sum(p["tokens_in"] for p in phases),
            "tokens_out": sum(p["tokens_out"] for p in phases),
            "tokens_cw": sum(p["tokens_cw"] for p in phases),
            "tokens_cr": sum(p["tokens_cr"] for p in phases),
            "last_updated": max((p["last_updated"] for p in phases if p["last_updated"]),
                                default=None),
        }
    return {"work_ids": list(works.values()), "total": grand}


@app.get("/", include_in_schema=False)
def ui() -> FileResponse:
    return FileResponse(Path(__file__).parent / "static" / "index.html")


@app.post("/work-ids/{work_id}/delete")
def delete_work_id(work_id: str) -> dict[str, Any]:
    """Deletes every session stored under the work-id."""
    with db.connect() as conn:
        deleted = conn.execute(
            "DELETE FROM session_stat WHERE work_id = %s", (work_id,)).rowcount
    if not deleted:
        raise HTTPException(404, "unknown work-id")
    return {"work_id": work_id, "deleted_sessions": deleted}


@app.get("/health")
def health() -> dict[str, str]:
    with db.connect() as conn:
        conn.execute("SELECT 1")
    return {"status": "ok"}
