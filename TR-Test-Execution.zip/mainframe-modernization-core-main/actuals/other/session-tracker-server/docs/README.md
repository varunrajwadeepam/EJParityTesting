# status-works

REST service that collects Claude Code session stats (the JSON written by `>>>save save`)
in PostgreSQL and reports them per work-id.

Run: `cd docker && docker compose up -d --build`, then open http://localhost:8000/docs.
Data lives in the named volume `status-works_pgdata`. It survives `docker compose down`;
only `down -v` deletes it.

| Method | Path | Purpose |
|---|---|---|
| GET | `/work-ids` | work-ids with session count and total cost |
| POST | `/sessions` | store/replace one session state (upsert by `session_id`) |
| GET | `/work-ids/{work_id}/stat` | totals, per-phase breakdown and sessions of a work-id |
| POST | `/work-ids/{work_id}/delete` | delete all sessions of a work-id (404 if none) |
| GET | `/summary` | all work-ids with totals and per-phase totals, plus a grand total |
| GET | `/` | web UI: spendings grouped by work-id (click a row for its phases), Reload button |
| GET | `/health` | liveness + DB check |

`POST /sessions` rejects (422) a missing, empty or blank `work_id`.

## From Claude Code
`>>>save send` posts the current session's stats (only that session) to the service. The
URL comes from `STATUS_WORKS_URL` in the `env` block of `~/.claude/settings.json`:

```json
"env": { "STATUS_WORKS_URL": "http://localhost:8000" }
```

The session needs a work-id first (`>>>save work-id=… phase=…`). `>>>save save [folder]`
still only writes `<session-id>.json` locally.

```
curl -X POST localhost:8000/sessions -H "Content-Type: application/json" \
     -d @$HOME/.claude/<session-id>.json
curl localhost:8000/work-ids
curl localhost:8000/work-ids/P510/stat
```

## Database

One table, `session_stat`, one row per session (primary key `session_id`). Re-posting a
session replaces its row, since session stats only grow. Columns hold the numeric stats for
SQL aggregation, and `raw` (JSONB) keeps the full posted document. Sessions with an empty
work-id are stored but not listed.
