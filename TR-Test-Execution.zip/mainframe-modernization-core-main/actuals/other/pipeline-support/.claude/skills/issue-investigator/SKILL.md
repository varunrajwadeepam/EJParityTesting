---
name: issue-investigator
description: Traces an issue in target code backwards through all pipeline artifacts — IMPLEMENT → EPICS → LLD → TSA → AS-IS → COBOL source — to identify the root cause and report findings with full provenance.
---

# Issue Investigator

## 1. Purpose

**Debug the pipeline, not the solution.** An issue in the generated Java code is a symptom — the real target is the pipeline stage, artifact, instruction, input data, or decision that caused the workflow to produce a wrong result. The goal is to find and report the workflow weakness so it can be fixed at the source, eliminating not just this error but the class of errors it represents.

This skill traces an issue backwards through the pipeline chain to identify:
- **Root cause** — the pipeline stage, artifact, tool, input, or instruction that introduced the error
- **Error propagation** — how the error traveled through downstream stages, whether any stage deepened it or attempted (and failed) to compensate
- **Actionable fix target** — what to change (pipeline logic, script, constitution, supplemental doc, skill, input data, or human decision) so a re-run eliminates the problem

If the user provides COBOL source code, use it as the ultimate ground truth — it can reveal errors that predate all pipelines.

### READ-ONLY — Strict Constraints

**This skill is a read-only investigator.** It inspects artifacts and reports findings. It MUST NOT:

- Build, compile, or execute any code
- Modify, edit, or delete any documentation, pipeline artifact, workflow state file, or constitution
- Run git commands (no commits, no checkouts, no diffs, no stash)
- Attempt to fix, patch, or correct any problem it discovers
- Modify any file in `inputs/`, `knowledge-store/`, `architecture/`, `docs/`, `specs/`, or `solution/`
- Run pipeline commands (`/asis.orchestrate`, `/implement.orchestrate`, etc.)
- Run scripts from `.asis/scripts/`, `.tsa/scripts/`, or any pipeline script folder

**It MAY** create new report files to document its findings (e.g., an investigation report markdown file). These report files are the only files this skill is allowed to write.

### Multiple Issues — Independent Reports

When investigating several issues in one session, produce a **separate, self-contained report for each issue**. Each report must be complete on its own — a reader who sees only that one report must get all necessary details without needing to read any other report. Do not use cross-references like "see Issue #1 report" or "same root cause as above". If two issues share the same root cause, state the full root cause independently in both reports. Duplicate evidence and context freely — self-containment outweighs brevity.

## 2. Pipeline Chain Overview

Investigation walks this chain **in reverse** — from solution code back to COBOL:

```
COBOL Source (mainframe)
        │
   ┌────▼──────┐
   │  MFLens   │  Deterministic + AI analysis of COBOL
   └────┬──────┘  (external tool, not a pipeline)
        │
        ▼
   inputs/                    — MFLens CSV exports, per-program .md docs,
        │                       DB schema/DDL, capability mappings
   ┌────▼────┐
   │  AS-IS  │  knowledge-store/            ◄── MFLens MCP available
   └────┬────┘
   ┌────▼────┐
   │   TSA   │  architecture/target-state/  ◄── MFLens MCP available
   └────┬────┘
   ┌────▼────┐
   │   LLD   │  architecture/LLD/           ◄── MFLens MCP available
   └────┬────┘
   ┌────▼────┐
   │  EPICS  │  docs/epics/                 ◄── MFLens MCP available
   └────┬────┘
   ┌────▼────────┐
   │  IMPLEMENT  │  specs/{work-unit-id}/ → solution/
   └─────────────┘  ▲ NO MFLens/COBOL access — follows instructions only
```

### 2.1 Pipeline → Work Folder → Constitution

| Pipeline | Work Folder | Constitution | Command | MFLens MCP |
|----------|-------------|--------------|---------|------------|
| AS-IS | `knowledge-store/` | `knowledge-store/constitution.md` | `/asis.orchestrate` | Yes |
| TSA | `architecture/target-state/` | `architecture/target-state/constitution.md` | `/tsa.orchestrate` | Yes |
| LLD | `architecture/LLD/` | `architecture/LLD/constitution.md` | `/lld.orchestrate` | Yes |
| EPICS | `docs/epics/` | `docs/epics/constitution.md` | `/epics.orchestrate` | Yes |
| IMPLEMENT | `specs/{work-unit-id}/` | `specs/constitution.md` | `/implement.orchestrate` | **No** |

### 2.2 MFLens Inception Layer (Pre-Pipeline)

Before any pipeline runs, COBOL source is imported into MFLens — an external tool that performs deterministic parsing and AI-assisted analysis. MFLens populates `inputs/`. This is NOT a pipeline — no `.workflow/`, no orchestrator, no constitution.

MFLens produces:
- `inputs/static-analysis/all-*.csv` — deterministic structural data (calls, tables, copybooks, etc.)
- `inputs/static-analysis/programs/{PROGRAM-NAME}.md` — per-program documentation (may include AI-generated summaries)
- Capability mappings and DB schema exports may come from MFLens or other manual sources

**Investigation implication**: errors can originate *before* AS-IS if MFLens misparses COBOL, produces incomplete exports, or its AI summaries are inaccurate. The `inputs/` folder is treated as ground truth by all pipelines, so an MFLens error propagates through the entire chain.

### 2.3 MFLens MCP Access During Pipeline Execution

AS-IS, TSA, LLD, and EPICS stages may access the MFLens MCP server at runtime to extract additional data — including raw COBOL source. These pipelines can self-correct or compensate for gaps in `inputs/`.

**IMPLEMENT has NO MFLens/COBOL access.** It works exclusively from upstream artifacts (stories, LLD, constitution, target-stack). If an upstream error reached IMPLEMENT uncorrected, IMPLEMENT will faithfully reproduce it in Java. This makes IMPLEMENT a pure follower — it amplifies upstream accuracy and upstream errors equally.

**Investigation implication**: when an error exists in final Java code, check whether AS-IS/TSA/LLD/EPICS had MFLens data available to correct it. If they did but didn't, the root cause is in that pipeline's stage logic. If MFLens itself was wrong, the root cause is pre-pipeline.

### 2.4 COBOL Source as Ground Truth (User-Provided)

The user may provide raw COBOL source as additional input. When available, COBOL source supersedes everything — it is the real system behavior.

**When COBOL source is provided, delegate a subagent to perform deep COBOL analysis.** The subagent reconstructs the actual program behavior relevant to the issue, then the investigator compares that behavior against what each pipeline stage captured.

#### COBOL Analysis Subagent Task

Spawn a subagent (read-only) to analyze the provided COBOL source. The subagent should extract, for the program(s) relevant to the issue:

1. **Business logic** — what the program actually does: conditions, branches, calculations, data transformations
2. **Data structures** — WORKING-STORAGE, LINKAGE SECTION, copybook fields, record layouts
3. **SQL operations** — every EXEC SQL statement: SELECT, INSERT, UPDATE, DELETE; tables, columns, WHERE clauses, joins, cursors
4. **Call chain** — every CALL statement: called programs, parameters passed, return codes checked
5. **External interfaces** — CICS transactions, MQ operations, file I/O, VSAM access
6. **Error handling** — SQLCODE checks, EVALUATE/IF branches on return codes, abend handling

The subagent produces a structured summary of actual COBOL behavior focused on the area related to the reported issue.

#### Comparing COBOL Reality Against Pipeline Artifacts

After the subagent returns, compare its findings against what each pipeline stage was supposed to capture. For every aspect of the COBOL behavior relevant to the issue, determine:

| COBOL behavior aspect | Should be captured by | In artifact | Actually captured? | Accuracy |
|----------------------|----------------------|-------------|-------------------|----------|
| SQL table/column usage | AS-IS **map** | `dependency-graph.json` (DB2 edges) | [yes/no/partial] | [correct/wrong/incomplete] |
| SQL table structure | MFLens export | `inputs/db-schema/DDL.sql`, `all-tables.csv` | [yes/no/partial] | [correct/wrong/incomplete] |
| Call chain / dependencies | AS-IS **map** | `dependency-graph.json` (call edges) | [yes/no/partial] | [correct/wrong/incomplete] |
| Business rules / logic | AS-IS **classify**, MFLens | `programs-enriched.json`, `programs/*.md` | [yes/no/partial] | [correct/wrong/incomplete] |
| Integration patterns | AS-IS **classify** | `integration-inventory.json` | [yes/no/partial] | [correct/wrong/incomplete] |
| Data transformations | LLD **data** | `data-flows.md` | [yes/no/partial] | [correct/wrong/incomplete] |
| API contract / interface | LLD **contract** | `bean-contract.md`, `openapi/*.yaml` | [yes/no/partial] | [correct/wrong/incomplete] |
| Functional requirements | EPICS **stories** | `STORY-*.md` acceptance criteria | [yes/no/partial] | [correct/wrong/incomplete] |
| Implementation instructions | IMPLEMENT **specify** | `spec.md` | [yes/no/partial] | [correct/wrong/incomplete] |

For each row where the answer is "no", "partial", or "wrong":
- **Not captured at all** — the pipeline stage that should have captured it failed to do so. Report the stage and artifact.
- **Partially captured** — some aspects are present but key details are missing. Report what's missing and which stage should have included it.
- **Wrongly captured** — the artifact says something different from the COBOL reality. Report the discrepancy, the artifact, and the stage that produced it.
- **Captured correctly but lost downstream** — an earlier stage got it right but a later stage dropped or distorted it. Report both stages.

This comparison is the core of the COBOL ground-truth analysis. It may reveal errors that no pipeline stage flagged because they all inherited the same wrong assumption from `inputs/`.

### 2.5 Supplemental Skills and Instructions

Pipelines may be driven by additional project-specific skills, instruction files, or reference documents beyond the constitution. These supplemental sources add implementation rules, domain knowledge, or behavioral constraints that shape how agents operate.

Check constitution files for references to such documents — they typically mention paths to instruction files, shared library documentation, archetype references, or domain-specific skills. When investigating an unexpected pipeline behavior, these supplemental sources may explain why an agent made a specific decision.

## 3. Pipeline Descriptions and Stage Inventory

### 3.1 AS-IS — Reverse-engineers the COBOL estate into structured knowledge artifacts.

| Stage | Purpose | Key Outputs |
|-------|---------|-------------|
| **normalize** | Merge raw CSV exports into unified program inventory | `programs-enriched.json` |
| **map** | Build dependency graph — call, DB2, external, system-utility, MQ, JCL edges | `dependency-graph.json`, `layer1-readiness-report.md` (Gate) |
| **classify** | Map capabilities, classify program types, detect integration patterns | `capability-map.json`, `integration-inventory.json`, `portfolio-summary.json`, `classification-summary.md` |
| **assess** | Analyze cross-system dependencies, compute ECR | `cross-system-report.md` (Human Gate) |
| **define** | Define bounded contexts and migration units, produce CSA | `bounded-contexts.json`, `CSA.md` (Human Gate) |
| **verify** | Validate completeness and consistency across all AS-IS artifacts | `completeness-report.md`, `consistency-report.md` |

### 3.2 TSA — Designs the target-state architecture from AS-IS knowledge.

| Stage | Purpose | Key Outputs |
|-------|---------|-------------|
| **target** | Design target architecture per bounded context | `TSA.md`, `TSA-adrs.md`, `target-state.json` |
| **validate** | Validate TSA against AS-IS artifacts and target-stack | `TSA-validation-report.md` |
| **assemble** | Assemble final TSA package with sign-off | `TSA-review-sign-off.md` |

### 3.3 LLD — Produces per-migration-unit low-level design from TSA.

| Stage | Purpose | Key Outputs |
|-------|---------|-------------|
| **contract** | Define API/bean contracts, OpenAPI specs | `*-bean-contract.md`, `openapi/*.yaml` |
| **data** | Design data flows and DB migration mapping | `data-flows.md` |
| **scaffold** | Design implementation structure — packages, classes, patterns | `implementation.md` |
| **test** | Design test strategy | `test-strategy.md` |
| **verify** | Cross-check LLD for consistency and TSA fidelity | `design-fidelity-report.md` |

### 3.4 EPICS — Generates epics and user stories from LLD.

| Stage | Purpose | Key Outputs |
|-------|---------|-------------|
| **prepare** | Build FR registry and module disposition | `.registry/fr-index.json`, `fr-register.json`, `mu-index.json`, `module-disposition.json` |
| **epics** | Generate EPIC definitions per migration unit | `EPIC.md` per epic folder |
| **stories** | Generate user stories with acceptance criteria | `STORY-*.md`, `story-catalog.json`, `backlog.csv`, `cobol-source-traceability.md` |
| **validate** | Validate stories against LLD, check completeness | `*-validation-report.md` |

### 3.5 IMPLEMENT — Runs once per work-unit (typically one EPIC's story set). Multiple instances run in parallel. **No MFLens access.**

| Stage | Purpose | Key Outputs |
|-------|---------|-------------|
| **specify** | Produce technical specification from stories + LLD | `spec.md`, `research.md` |
| **clarify** | Resolve ambiguities (may be skipped) | updates to spec.md or skipped |
| **plan** | Create implementation plan | `plan.md` |
| **tasks** | Break plan into atomic tasks | `tasks.md` |
| **implement** | Write Java code into solution/ | Java source + tests; `checklists/implementation-*.md` |
| **review** | Review implementation against spec, LLD, constitution | `review.md`, `checklists/review-quality.md` |

## 4. Artifact Locations

### 4.1 Inputs (Read-Only After Inception)

Ground truth from MFLens and manual sources. All pipelines read from here; none write.

```
inputs/
├── source/                          — COBOL source code (if present)
├── db-schema/                       — DDL.sql, table/column CSVs
├── static-analysis/                 — MFLens CSV exports
│   ├── all-*.csv                    — Structural data (programs, calls, tables, etc.)
│   ├── missing-modules.csv
│   └── programs/{PROGRAM-NAME}.md   — Per-program MFLens documentation
├── target-stack-java.md             — Target technology stack definition
├── Capability*.csv                  — Business capability taxonomy
└── programs-products-capabilities-mapping.csv
```

### 4.2 Knowledge Store (AS-IS Outputs)

| Artifact | Content | Consumed By |
|----------|---------|-------------|
| `programs-enriched.json` | Normalized program inventory | TSA, LLD |
| `dependency-graph.json` | Call graph + DB2/MQ/JCL/external edges | TSA |
| `capability-map.json` | Business capability → program mapping | TSA |
| `integration-inventory.json` | Integration patterns per program | TSA |
| `portfolio-summary.json` | Cross-program patterns | TSA |
| `bounded-contexts.json` | BCs, migration units, program assignments | TSA, LLD, EPICS |
| `cross-system-report.md` | Cross-system dependencies, ECR | TSA |
| `layer1-readiness-report.md` | MAP gate validation | (gate only) |
| `classification-summary.md` | Program types and execution stages | TSA |
| `completeness-report.md` | Coverage gaps | (verification) |
| `consistency-report.md` | Cross-artifact consistency | (verification) |

### 4.3 Architecture Artifacts

```
architecture/
├── current-state/{BC}/
│     CSA.md, CSA-validation-report.md
├── target-state/
│     TSA.md, TSA-adrs.md, target-state.json
│     TSA-validation-report.md, TSA-review-sign-off.md
├── LLD/{MU-ID}/
│     *-bean-contract.md, openapi/*.yaml
│     data-flows.md, implementation.md, test-strategy.md
│     design-fidelity-report.md
├── SAD/SAD-*.md                      — Solution Architecture Documents (snapshots)
└── e2e-tests/                       — Optional E2E test package
```

### 4.4 Docs — EPICs and Stories

```
docs/epics/
├── .registry/                       — fr-index.json, fr-register.json, mu-index.json, module-disposition.json
├── {MU-ID}/
│     backlog.csv, cobol-source-traceability.md, README.md
│     validation/*-validation-report.md
│     {EPIC-ID}/
│       EPIC.md, STORY-*.md, story-catalog.json
└── constitution.md
```

### 4.5 Specs — IMPLEMENT Workspace

One folder per work-unit (typically one EPIC's story set):

```
specs/
├── constitution.md
└── {work-unit-id}/
    ├── spec.md, research.md, plan.md, tasks.md, review.md
    ├── checklists/                  — specification-quality, implementation-quality, implementation-tasks, review-quality
    └── .workflow/                   — (see §5)
```

### 4.6 Solution — Target Java Code

Lives at `../../solution/` relative to workspace (path may vary — check constitution and LLD `implementation.md` for the exact module path). IMPLEMENT stages write Java code here.

## 5. Workflow Execution Data

Every pipeline maintains a `.workflow/` folder inside its work folder. This is the primary source for investigating pipeline execution.

### 5.1 Location Pattern

```
{pipeline-work-folder}/.workflow/
├── context.json              — Immutable pipeline configuration
├── state.json                — Authoritative execution status
├── events.jsonl              — Append-only event log
├── checkpoints/{stage}.json  — Per-stage internal progress
├── results/{stage}.json      — Per-stage output record
└── tmp/                      — Transient working files (if any)
```

### 5.2 context.json

Created by the orchestrator at pipeline start. Read-only after creation. Tells you what the pipeline was configured to do.

Key fields:
- `inputs.*` — what data the pipeline was told to read (and whether present)
- `stages[]` — ordered stage list
- `userInstructions` — human overrides or re-run instructions that may explain deviations
- `workspace.*` — resolved folder paths

### 5.3 state.json

Authoritative pipeline status. **Read this first** when investigating a pipeline.

Key fields:
- `workflow.status` — completed / blocked / failed
- `stages.{stage}.status` — per-stage outcome
- `stages.{stage}.attempt` — retry count (high values = problems)
- `blockingIssue` — active block with code and reason
- `summary.lastSuccessfulStage` / `summary.nextStage`

### 5.4 events.jsonl

Append-only log. Each line is a JSON object. **Richest diagnostic source** — records the *why* behind retries and blocks.

Key event types:
- `workflow_initialized` — pipeline start, input status
- `stage_started` / `stage_completed` — normal flow
- `stage_blocked` — `details.code` + `details.reason` explaining the block
- `workflow_blocked` / `workflow_blocked_resolved` — block lifecycle
- `stage_retry_scheduled` — `details.reason` for the retry
- `stage_marked_stale` — upstream change invalidated a completed stage

### 5.5 results/{stage}.json

Official record of stage output.

Key fields:
- `artifacts[]` — files created/modified, with validation status
- `validation.checks[]` — what was verified, with evidence text
- `verdict` — PASS / PASS_WITH_WARNINGS / FAIL
- `issues[]` — unresolved problems
- `summary` — human-readable description of what was done
- `humanGate` — whether human review was required

### 5.6 checkpoints/{stage}.json

Internal progress for stage recovery. Shows completed sub-phases and next resume point. Useful for understanding partial failures.

## 6. Cross-Pipeline Data Flow

Investigation walks this flow in reverse:

```
COBOL source (mainframe)    ──► MFLens ──► inputs/static-analysis/, inputs/db-schema/
                                          (no .workflow/ — external tool)
                                           │
inputs/source/              ──► AS-IS normalize ──► programs-enriched.json
inputs/static-analysis/     ──► AS-IS map       ──► dependency-graph.json
inputs/db-schema/DDL.sql    ──► AS-IS map/define ──► CSA.md, bounded-contexts.json
                                  │
                            MFLens MCP ──► (AS-IS, TSA, LLD, EPICS can query at runtime)
                                                      │
knowledge-store/*           ──► TSA target      ──► TSA.md, target-state.json
architecture/current-state/ ──► TSA target           │
                                                      │
architecture/target-state/  ──► LLD contract    ──► bean-contract.md, openapi.yaml
                            ──► LLD data        ──► data-flows.md
                            ──► LLD scaffold    ──► implementation.md
                            ──► LLD test        ──► test-strategy.md
                                                      │
architecture/LLD/           ──► EPICS prepare   ──► .registry/*, EPIC.md
                            ──► EPICS stories   ──► STORY-*.md, backlog.csv
                                                      │
docs/epics/{EPIC-ID}/       ──► IMPLEMENT specify ──► spec.md
architecture/LLD/           ──► IMPLEMENT plan    ──► plan.md, tasks.md
                            ──► IMPLEMENT implement ──► Java code in solution/
                            ──► IMPLEMENT review   ──► review.md
```

### 6.1 Key Traceability Links

- **COBOL program → `programs-enriched.json`**: program name key
- **`programs-enriched.json` → `dependency-graph.json`**: program nodes + edges
- **`dependency-graph.json` → `bounded-contexts.json`**: program-to-BC/MU assignment
- **`bounded-contexts.json` → `TSA.md` / `target-state.json`**: BC-level architecture
- **`target-state.json` → LLD `bean-contract` / `data-flows`**: MU-level design
- **LLD → `EPIC.md` / `STORY-*.md`**: FR traceability via `.registry/fr-register.json`
- **`STORY-*.md` → `spec.md`**: story IDs in IMPLEMENT `context.json`
- **`spec.md` → `plan.md` → `tasks.md` → Java code**: task-to-file mapping
- **Java code ← `review.md`**: review references specific files
- **`cobol-source-traceability.md`**: direct COBOL-program-to-story cross-reference

## 7. Investigation Procedure

Walk backwards from the issue. Stop at the layer where the error was introduced. At each layer, read the business artifacts first, then the `.workflow/` execution data.

### Step 1: Locate the Issue in the Solution

Identify the affected Java class/method/file in `solution/`. Determine which IMPLEMENT work-unit produced it by searching `specs/*/tasks.md` or `specs/*/.workflow/results/implement.json` for the file path.

### Step 2: Trace to IMPLEMENT Artifacts

Read from the affected `specs/{work-unit-id}/`:
- `spec.md` — what was specified
- `plan.md` — what was planned
- `tasks.md` — what tasks were executed
- `review.md` — what was reviewed and flagged
- `.workflow/results/implement.json` — what artifacts were created
- `.workflow/results/review.json` — review verdict and checks
- `.workflow/events.jsonl` — blocks, retries, anomalies
- `.workflow/context.json` → `stories[]` — which stories this work unit implements

### Step 3: Trace to EPICs and Stories

From story IDs in IMPLEMENT `context.json`, read `STORY-*.md` files in `docs/epics/`:
- Acceptance criteria — does the issue violate a stated AC?
- FR references — which functional requirements are involved?
- `.registry/fr-register.json` — FR definitions and traceability
- `cobol-source-traceability.md` — which COBOL programs trace to this story?
- EPICS `.workflow/results/validate.json` — did validation catch anything?

### Step 4: Trace to LLD

From FR register and story references, read `architecture/LLD/{MU-ID}/`:
- `bean-contract.md` or `openapi/*.yaml` — is the contract correct?
- `data-flows.md` — is the data mapping correct?
- `implementation.md` — do instructions match what was built?
- `test-strategy.md` — does it cover the failing scenario?
- `design-fidelity-report.md` — fidelity issues already flagged?
- `.workflow/results/*.json` — what each stage verified

### Step 5: Trace to TSA

Read `architecture/target-state/`:
- `TSA.md` — does the architecture describe the behavior correctly?
- `TSA-adrs.md` — ADRs explaining design choices
- `target-state.json` — machine-readable decisions
- `TSA-validation-report.md` — validation issues?
- `.workflow/events.jsonl` — retries or blocks?

### Step 6: Trace to AS-IS

Read `knowledge-store/`:
- `bounded-contexts.json` — program assignment correct?
- `CSA.md` — does current-state match COBOL reality?
- `dependency-graph.json` — dependencies captured?
- `programs-enriched.json` — inventory accurate?
- `cross-system-report.md` — cross-system issues?
- `.workflow/events.jsonl` — blocks, retries, constitution conflicts?

### Step 7: Trace to Source Inputs (MFLens Exports)

Check raw MFLens exports in `inputs/`:
- `inputs/static-analysis/programs/{PROGRAM-NAME}.md` — per-program docs
- `inputs/db-schema/DDL.sql` — authoritative DB2 schema
- `inputs/static-analysis/all-*.csv` — raw structural data

Determine: did AS-IS misinterpret correct MFLens data, or was MFLens data already wrong?

### Step 8: Trace to COBOL Source (Ground Truth)

Applies when the user provides COBOL source or MFLens MCP is available.

If COBOL source is available — perform the **deep COBOL analysis** described in §2.4:
1. Spawn a subagent to reconstruct actual program behavior (business logic, SQL, calls, data structures, interfaces)
2. Compare COBOL reality against each pipeline artifact using the §2.4 comparison table
3. For every aspect not captured, partially captured, or wrongly captured — report the responsible stage and artifact
4. If MFLens itself was wrong, the error predates all pipelines

If COBOL source is NOT available:
- Treat `inputs/` as the lowest reachable ground truth
- Note in the report that COBOL verification was not possible
- Recommend the user provide COBOL source if root cause appears to be in `inputs/`

### Step 8a: Check for Mid-Chain Compensation

Because AS-IS, TSA, LLD, and EPICS can access MFLens MCP, a later pipeline may have compensated for an earlier error. Check:
- Did a downstream pipeline correct a value that was wrong upstream? (compensation)
- Did a pipeline have MFLens data available but fail to use it? (missed compensation)
- Was a correction made in prose but not in machine-readable artifacts? (partial compensation — IMPLEMENT may not see it)
- Did IMPLEMENT faithfully reproduce an uncorrected upstream error? (blind follower pattern)

### Step 9: Check Constitution Chain

At each pipeline level, read the constitution for rules that may have constrained or directed the behavior that produced the issue:
- `knowledge-store/constitution.md` (AS-IS)
- `architecture/target-state/constitution.md` (TSA)
- `architecture/LLD/constitution.md` (LLD)
- `docs/epics/constitution.md` (EPICS)
- `specs/constitution.md` (IMPLEMENT)

Also check for supplemental instruction files, shared library docs, or domain-specific skills referenced within the constitutions. These may contain additional rules that drove agent behavior.

## 8. Root Cause Classification

| Root Cause Layer | Symptoms | Where to Confirm |
|-----------------|----------|-----------------|
| **COBOL Source** | Actual COBOL logic differs from what all artifacts assume (only with user-provided source) | User-provided COBOL vs. `inputs/static-analysis/programs/*.md` |
| **MFLens Import** | Misparse, incomplete export, inaccurate AI summary | `inputs/static-analysis/` vs. COBOL source or MFLens MCP |
| **AS-IS** | Wrong classification, missing edge, wrong BC assignment, failed to compensate via MFLens MCP | `knowledge-store/*.json`, AS-IS `events.jsonl` |
| **TSA** | Wrong architecture decision, missing ADR, incorrect mapping | `architecture/target-state/`, TSA `events.jsonl` |
| **LLD** | Wrong contract, incorrect data flow, missing instruction | `architecture/LLD/`, LLD `events.jsonl` |
| **EPICS** | Missing story, wrong AC, incorrect FR, missing traceability | `docs/epics/`, EPICS `events.jsonl` |
| **IMPLEMENT** | Spec diverged from story, plan missed a file, code bug, review missed it | `specs/{work-unit-id}/`, IMPLEMENT `events.jsonl` |
| **Constitution** | A rule forced incorrect behavior | `*/constitution.md` at the relevant layer |
| **Supplemental docs** | An instruction file or skill referenced by a constitution drove wrong behavior | Path referenced in constitution |
| **Pipeline Agent Logic** | Input was correct but output was wrong, constitution doesn't explain it | Pipeline distributive agent/skill source |

## 9. Pipeline Distributive — Agent Source Code

Each pipeline is implemented as agents, skills, commands, and scripts in the pipeline distributive. When the root cause is in the agent's logic (input correct, output wrong, constitution doesn't explain it), read the agent source.

### 9.1 Obtaining the Distributive Path

Ask the user:

> "The issue appears to originate in the **{pipeline-name}** pipeline's **{stage}** agent logic. To investigate further, I need access to the pipeline agent source code. Where is the pipeline distributive located?"
>
> Default location: `C:\dev_folder\TRVS-MEGA\mainframe-modernization-core\actuals\pipelines`

### 9.2 What to Look For

- Pipeline CLAUDE.md — stage definitions, input/output contracts, agent instructions
- Skills in `{pipeline}/.claude/skills/` — stage-specific behavior
- Scripts in `{pipeline}/.asis/scripts/`, `.tsa/scripts/`, etc. — validation and merge logic
- Templates — artifact templates that shape output format
- Supplemental instruction files referenced by constitutions — domain rules, library docs, archetype patterns

In the agent source, check: does it read all declared inputs? How does it derive outputs? Does it load and respect the constitution? What validation does it run? Are there documented edge cases?

## 10. Report Format

The report targets the **workflow**, not the Java code. The issue in `solution/` is the symptom; the report must point to what to fix so a re-run produces the correct result.

Produce this report at the end of investigation:

```markdown
# Issue Investigation Report

## Symptom
[User's original issue description — the observable problem in the generated code]
- **Observed in**: [solution/ file path]
- **Work Unit**: [IMPLEMENT work-unit-id]
- **Migration Unit / BC**: [MU-ID / BC-ID]

## Root Cause

### Where the error originates
- **Layer**: [COBOL Source | MFLens Import | AS-IS | TSA | LLD | EPICS | IMPLEMENT | Constitution | Supplemental Docs | Pipeline Agent]
- **Pipeline**: [pipeline name]
- **Stage**: [stage name]
- **Artifact**: [path to the earliest artifact containing the error]

**What went wrong**: [One-sentence: what the artifact/stage/instruction got wrong and why]

**Error class**: [Category — e.g., "incomplete input data", "wrong transformation rule", "missing constitution constraint", "MFLens AI summary inaccuracy", "agent failed to read declared input", "validation gap", etc. This identifies the class of errors to prevent, not just this instance.]

## Evidence Chain

Backward trace from symptom to root cause. Each row = one pipeline layer.

| Layer | Artifact | What it says | Correct? | Notes |
|-------|----------|-------------|----------|-------|
| IMPLEMENT | spec.md | [what was specified] | [yes/no] | NO MFLens access |
| EPICS | STORY-xxx.md | [AC text] | [yes/no] | |
| LLD | data-flows.md | [mapping] | [yes/no] | MFLens MCP available |
| TSA | TSA.md | [decision] | [yes/no] | MFLens MCP available |
| AS-IS | programs-enriched.json | [classification] | [yes/no] | MFLens MCP available |
| MFLens | programs/XXX.md | [export data] | [yes/no] | |
| COBOL | (if provided) | [actual logic] | ground truth | |

## COBOL Ground-Truth Comparison (if COBOL source was provided)

What the real COBOL program does vs. what the pipeline captured. Only rows relevant to the issue.

| COBOL behavior | Should be captured by | In artifact | Captured? | Accuracy | Impact on issue |
|---------------|----------------------|-------------|-----------|----------|----------------|
| [actual behavior from COBOL] | [pipeline.stage] | [artifact path] | [yes/no/partial] | [correct/wrong/incomplete] | [how this gap relates to the reported issue] |

- **Not captured at all**: the stage that should have captured it failed — report stage + artifact
- **Partially captured**: key details missing — report what's missing
- **Wrongly captured**: artifact contradicts COBOL — report the discrepancy
- **Captured correctly but lost downstream**: earlier stage got it right, later stage dropped it — report both

## Error Propagation

How the error traveled and transformed through the chain:

- **Introduced at**: [layer + artifact where the error first appears]
- **Deepened by**: [any later stage that made it worse — e.g., wrong interpretation, amplification] or "none"
- **Compensation attempted**: [any stage that partially corrected it — and why the correction was incomplete] or "none"
- **Missed compensation**: [any stage that had MFLens MCP available and could have caught it but didn't] or "none"
- **Reached IMPLEMENT uncorrected**: [yes/no — IMPLEMENT has no MFLens access and followed instructions as-is]

## Workflow Anomalies

[Retries, blocks, stale marks, unusual attempt counts from events.jsonl along the chain. These may indicate the pipeline struggled with the same underlying problem.]

## Fix Target

What to change so a re-run eliminates this error and the class of errors it represents:

| What to fix | Type | Action | Prevents |
|-------------|------|--------|----------|
| [specific file/script/skill/doc] | [pipeline agent | script | constitution | supplemental doc | input data | skill | MFLens config | human decision] | [specific change] | [what class of errors this prevents] |

- **Re-run from**: [which pipeline/stage to re-run after the fix]
- **Downstream regeneration**: [which pipelines/artifacts will need to be regenerated]
- **No code fix needed**: the Java code will be correct after the pipeline re-run produces correct upstream artifacts
```

## 11. Report Review — Subagent Cross-Check

After drafting each report, spawn a **review subagent** to cross-check it. The reviewer runs in an isolated context with read access to the workspace artifacts. One review round per report — no iteration.

### Review Subagent Task

Provide the reviewer with:
- The full draft report text
- The issue description from the user

The reviewer must independently read every artifact and workflow file cited in the report, then check:

1. **Evidence accuracy** — does each cited artifact actually say what the report claims? Quote the relevant text. Flag any misquote, paraphrase error, or fabricated content.
2. **Artifact existence** — does every file path in the report exist in the workspace? Flag phantom paths.
3. **Completeness** — are there artifacts along the evidence chain that the report skipped? Could they change the conclusion?
4. **Logic** — does the evidence chain actually support the stated root cause? Is there an alternative explanation the report didn't consider?
5. **Propagation accuracy** — does the error propagation section correctly describe what each stage did? Verify against `events.jsonl` and `results/*.json`.
6. **COBOL comparison** (if applicable) — does the COBOL ground-truth table accurately reflect the source code? Are the "should be captured by" assignments correct per the pipeline design?
7. **Fix target validity** — is the recommended fix actionable? Does the named file/script/doc exist? Would the proposed change actually prevent the error class?

### Reviewer Output

The reviewer returns a list of findings:

```
## Report Review Findings

- **CONFIRMED**: [aspects of the report that checked out]
- **WEAK**: [claims that are plausible but not fully evidenced — cite what's missing]
- **ERROR**: [factual mistakes — cite the artifact and what it actually says]
- **FABRICATION**: [anything in the report not supported by any artifact]
- **MISSED**: [artifacts or evidence the report should have examined but didn't]
```

### After Review

Read the reviewer's findings. For each ERROR or FABRICATION — correct the report. For each WEAK — either strengthen with evidence or downgrade the claim. For each MISSED — read the cited artifact and update if it changes the conclusion. Append a "Review Notes" section at the end of the final report listing what the review caught and what was corrected.

Do not run a second review round.

## 12. Quick-Reference: File Lookup by Issue Type

| Issue Type | Start Here | Then Check |
|-----------|-----------|-----------|
| Wrong SQL / table structure | `inputs/db-schema/DDL.sql`, `LLD/data-flows.md` | `programs-enriched.json` DB2 edges, `TSA.md` data section |
| Missing API endpoint | `LLD/openapi/*.yaml`, `LLD/*-bean-contract.md` | `TSA.md` REST surface, IMPLEMENT `spec.md` |
| Wrong business rule | `docs/epics/STORY-*.md` (AC), `LLD/implementation.md` | `inputs/static-analysis/programs/*.md`, COBOL source |
| Incorrect data mapping | `LLD/data-flows.md`, `dependency-graph.json` | `inputs/db-schema/DDL.sql`, `programs-enriched.json` |
| Missing dependency | `dependency-graph.json` | `inputs/static-analysis/all-calls.csv`, MFLens MCP |
| Wrong program classification | `programs-enriched.json` | `inputs/static-analysis/all-programs.csv`, AS-IS `events.jsonl` |
| Test gap | `LLD/test-strategy.md`, IMPLEMENT `review.md` | `architecture/e2e-tests/test-scenarios.md` |
| Constitution violation | `*/constitution.md` at relevant layer | `events.jsonl` at that layer |
| MFLens misparse | `inputs/static-analysis/programs/*.md` vs. COBOL source | MFLens MCP re-query |
| Mid-chain compensation | Compare artifact value at each layer | `events.jsonl` for MFLens MCP usage evidence |
| IMPLEMENT blind-follower | IMPLEMENT `spec.md` matches upstream error exactly | Upstream artifact + note: no MFLens access |
