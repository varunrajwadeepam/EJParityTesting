A skill to invastigate any issue through pipeline execution artifacts from Java generated down to initial cobol code.
If locates a issue root and report.
It is recommended to sullpy skill with oroginal cobol code as a groung trooth.
Skill is suposed to run in the workspace where pipeline was executed so uit can access all pipeline artefacts.

run sample:

```
/issue-investigator in the  P7549509-java-parity-findings.md 
report investigate a issue 
"## F3 � No per-code reduction: every revision is returned (26 `ROW`, part of 14 `COUNT`)" 
cobol sources in the 
C:\dev_folder\TRVS-MEGA\CAGenUtility\initial\src\RevDB_P7549509_v2 
folder, common part cobol is in the 
C:\dev_folder\TRVS-MEGA\CAGenUtility\initial\src\RevDB_common_v2 
solution is in the 
../../solution,
execution artifacts are in current workspace.
```
