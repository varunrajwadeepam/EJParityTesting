#!/usr/bin/env bash
# Sends the session tracker's checkpoint export documents to the work-ledger bucket. One file,
# no dependency on the rest of this repository: developers copy it to their own machine.
# See --help.
set -euo pipefail

program="work-ledger-upload.sh"

usage() {
  cat <<'EOF'
work-ledger-upload.sh - send the session tracker's checkpoint export documents
to the work-ledger bucket. Writes only new objects to S3; never changes, moves
or deletes a local file. With --dry-run it writes nothing at all.

USAGE
  work-ledger-upload.sh [--profile <name>] [--dir <directory>] [--dry-run]

OPTIONS
  --profile <name>  the AWS CLI profile of your own SSO session, permission set
                    User   (default: $WORK_LEDGER_PROFILE, else $AWS_PROFILE,
                            else the CLI default)
  --dir <directory> where the tracker writes its export documents
                    (default: $CLAUDE_CHECKPOINT_EXPORT_DIR,
                     else ~/.claude/checkpoint-export)
  --dry-run         check the session and every document, print the S3 key
                    each would get, send nothing
  -h, --help        this text

ENVIRONMENT
  WORK_LEDGER_PROFILE           the profile when --profile is not given; set it
                                once, so that AWS_PROFILE stays free for other
                                tools                       (default: unset)
  AWS_PROFILE                   read by the AWS CLI when neither is given; named
                                here only on the failures below
  AWS_CONFIG_FILE               where the profiles listed on exit 3 are looked
                                up, as the AWS CLI does  (default: ~/.aws/config)
  CLAUDE_CHECKPOINT_EXPORT_DIR  the tracker's export directory, as the tracker
                                itself reads it  (default: ~/.claude/checkpoint-export)
  WORK_LEDGER_BUCKET            the bucket       (default: work-ledger-raw-<account
                                                  of the session>)

WHAT IT DOES
  1. Asks AWS who the session is. Only an SSO session of the permission set
     User (or Administrator) is accepted: its session name is the SSO user and
     AWS sets it, which is what makes an upload attributable. A BedrokLLMAccess
     session is refused, because there the client chooses the session name.
  2. Checks each *.json in the directory: one JSON document, schema_version 1,
     at most 1 MiB. Any other file is skipped and the reason printed. A document
     whose identity.developer is not the SSO user of the session is still sent,
     with the difference noted on its line: who sent it is proven by the key, and
     the tracker may have named you after git or the OS login (see CLAUDE_USER).
  3. Sends each document to raw/<aws:userid>/<file name>, only if that key does
     not exist yet. A document already in the bucket is reported as present and
     counts as success, so running this again is always safe.

  First the directory read - "reading <directory>", with ~ for the home
  directory - then one line per file - sent, present, skipped: <reason>,
  failed: <reason>, or in a dry run would send - then a summary line, which
  also counts the sent documents that carry a note: the line a log is read by.

  When the profile is unknown (exit 1), the session is not valid (exit 2) or is
  not a developer's (exit 3), the first line says which profile the AWS CLI was
  given and where the name came from - --profile, WORK_LEDGER_PROFILE,
  AWS_PROFILE, or none - and adds "WORK_LEDGER_PROFILE is not set in this
  terminal" when it is not.

EXAMPLES
  # Sign in, look first, then send.
  aws sso login --profile my-sso-user
  work-ledger-upload.sh --profile my-sso-user --dry-run
  work-ledger-upload.sh --profile my-sso-user

  # Name the profile once, in ~/.bashrc, and leave out --profile from then on.
  export WORK_LEDGER_PROFILE=my-sso-user
  work-ledger-upload.sh --dry-run

  # From cron, three times a day; a failed run is retried by the next one.
  0 10,14,18 * * * WORK_LEDGER_PROFILE=my-sso-user $HOME/.local/bin/work-ledger-upload.sh >>$HOME/work-ledger-upload.log 2>&1

  # After a non-zero exit, decide on the code.
  work-ledger-upload.sh; case $? in 2) aws sso login --profile my-sso-user ;; esac

EXIT CODES
  0  every document that qualifies was sent or was already in the bucket;
     skipped files are listed above the summary
  1  usage or environment: unknown option, aws or jq missing, an AWS CLI too
     old for conditional writes, the directory missing, the profile unknown,
     AWS unreachable
  2  no valid SSO session: sign in with aws sso login and run again
  3  the session is not a developer's SSO session, for example BedrokLLMAccess;
     the profiles in the AWS CLI config that would do are listed
  4  some documents could not be sent; the next run sends them
EOF
}

die() { # <exit code> <message…>
  local code="$1"
  shift
  printf '%s: %s\n' "$program" "$*" >&2
  exit "$code"
}

profile="${WORK_LEDGER_PROFILE:-}"
profile_from_option=false
export_dir="${CLAUDE_CHECKPOINT_EXPORT_DIR:-$HOME/.claude/checkpoint-export}"
dry_run=false

while (($# > 0)); do
  case "$1" in
  --profile)
    (($# >= 2)) || die 1 "--profile needs a value; see --help"
    profile="$2"
    profile_from_option=true
    shift 2
    ;;
  --dir)
    (($# >= 2)) || die 1 "--dir needs a value; see --help"
    export_dir="$2"
    shift 2
    ;;
  --dry-run)
    dry_run=true
    shift
    ;;
  -h | --help)
    usage
    exit 0
    ;;
  *) die 1 "unknown argument: $1; see --help" ;;
  esac
done

command -v aws >/dev/null 2>&1 || die 1 "the AWS CLI v2 (aws) is not installed"
command -v jq >/dev/null 2>&1 || die 1 "jq is not installed"
[[ -d $export_dir ]] || die 1 "no such directory: $export_dir"

# Spelled out rather than "${profile_args[@]}": bash 3.2, the one macOS ships, calls an empty
# array unbound under set -u.
profile_args=()
[[ -z $profile ]] || profile_args=(--profile "$profile")

# Without --if-none-match the bucket refuses the write, so an older CLI would report every
# document as failed; saying so once is clearer.
aws s3api put-object help 2>/dev/null | grep -q -- '--if-none-match' ||
  die 1 "this AWS CLI has no --if-none-match for put-object; update the AWS CLI v2"

# Which profile the AWS CLI was given and where its name came from, printed before the failures a
# wrong profile explains: an unknown profile, no valid session, not a developer session. A
# variable set for the user but not seen by this terminal shows up here as "not set".
# AWS_PROFILE is read for this line only: the AWS CLI still chooses the profile itself.
report_profile_source() {
  local not_set_note=""
  [[ -n ${WORK_LEDGER_PROFILE:-} ]] || not_set_note=" (WORK_LEDGER_PROFILE is not set in this terminal)"
  if [[ -n $profile ]] && $profile_from_option; then
    printf '%s: profile %s, from --profile\n' "$program" "$profile" >&2
  elif [[ -n $profile ]]; then
    printf '%s: profile %s, from WORK_LEDGER_PROFILE\n' "$program" "$profile" >&2
  elif [[ -n ${AWS_PROFILE:-} ]]; then
    printf '%s: profile %s, from AWS_PROFILE%s\n' "$program" "$AWS_PROFILE" "$not_set_note" >&2
  else
    printf '%s: no profile given, the AWS CLI default%s\n' "$program" "$not_set_note" >&2
  fi
}

login_hint="aws sso login${profile:+ --profile $profile}"
if ! identity_json="$(aws sts get-caller-identity --output json ${profile_args[@]+"${profile_args[@]}"} 2>&1)"; then
  case "$identity_json" in
  *"could not be found"*)
    report_profile_source
    printf '%s\n' "$identity_json" >&2
    die 1 "the AWS CLI does not know this profile"
    ;;
  *"Could not connect"* | *"Connect timeout"* | *"Read timeout"* | *"SSL"* | *[Pp]roxy*)
    printf '%s\n' "$identity_json" >&2
    die 1 "AWS cannot be reached from here; check the network or the proxy"
    ;;
  *)
    report_profile_source
    printf '%s\n' "$identity_json" >&2
    die 2 "no valid SSO session; run: $login_hint"
    ;;
  esac
fi

# Arn of an SSO session: arn:aws:sts::<account>:assumed-role/<role name>/<SSO user>.
# UserId: <role id>:<SSO user>, the value the bucket policy calls aws:userid.
identity_fields="$(jq -r '[.Account, .UserId, .Arn] | map(. // "") | join("\u001f")' <<<"$identity_json")" || {
  report_profile_source
  die 2 "the AWS CLI did not return an identity; run: $login_hint"
}
IFS=$'\x1f' read -r account user_id arn <<<"$identity_fields"
role_name="$(cut -d/ -f2 <<<"$arn")"
sso_user="${user_id#*:}"

# The profiles of the AWS CLI config in this account whose permission set is User or Administrator.
# Read from the file rather than through `aws configure get`, which costs a process per profile.
# input:  the account of the current session
# output: one profile name per line; nothing when the file is missing. Never the account ids: the
#         config may hold profiles of other accounts, and this goes to stderr and so to a cron log.
developer_sso_profiles() { # <account>
  local config_file="${AWS_CONFIG_FILE:-$HOME/.aws/config}"
  [[ -r $config_file ]] || return 0
  # \r: a config edited on Windows ends its lines with CRLF. A UTF-8 BOM, which Notepad writes,
  # would hide the first section header; LC_ALL=C makes awk match it as bytes.
  LC_ALL=C awk -v wanted_account="$1" '
    function flush() {
      if (name != "" && account == wanted_account && (role == "User" || role == "Administrator"))
        print name
    }
    NR == 1 { sub(/^\357\273\277/, "") }
    { sub(/\r$/, "") }
    /^[ \t]*[#;]/ { next }
    /^[ \t]*\[/ {
      flush(); name = ""; role = ""; account = ""
      header = $0
      gsub(/^[ \t]*\[[ \t]*|[ \t]*\][ \t]*$/, "", header)
      if (header == "default") name = "default"
      else if (header ~ /^profile[ \t]+/) { sub(/^profile[ \t]+/, "", header); name = header }
      next
    }
    /=/ {
      key = $0; sub(/=.*/, "", key); gsub(/[ \t]/, "", key)
      value = $0; sub(/^[^=]*=[ \t]*/, "", value); sub(/[ \t]+$/, "", value)
      if (key == "sso_role_name") role = value
      else if (key == "sso_account_id") account = value
    }
    END { flush() }' "$config_file"
}

die_not_developer_session() { # <message…>
  local candidates
  report_profile_source
  printf '%s: %s\n' "$program" "$*" >&2
  candidates="$(developer_sso_profiles "$account")"
  if [[ -n $candidates ]]; then
    printf '%s: profiles here for this account with the permission set User or Administrator:\n' "$program" >&2
    printf '  %s\n' "${candidates//$'\n'/$'\n'  }" >&2
    printf '%s: pass one with --profile, or set WORK_LEDGER_PROFILE once\n' "$program" >&2
  else
    printf '%s: no profile in %s has the permission set User or Administrator for this account; create one with aws configure sso\n' \
      "$program" "${AWS_CONFIG_FILE:-$HOME/.aws/config}" >&2
  fi
  exit 3
}

case "$role_name" in
BedrokLLMAccess)
  die_not_developer_session "this is a BedrokLLMAccess session, whose name the client chooses; use your SSO profile of the permission set User"
  ;;
esac
if [[ ! $arn =~ ^arn:aws:sts::[0-9]+:assumed-role/AWSReservedSSO_(User|Administrator)_[0-9A-Za-z]{16}/ ]] ||
  [[ -z $sso_user || $sso_user == "$user_id" ]]; then
  die_not_developer_session "the session is $role_name, not an SSO session of the permission set User; use your own SSO profile"
fi

bucket="${WORK_LEDGER_BUCKET:-work-ledger-raw-$account}"
key_prefix="raw/$user_id/"
# The ingest function refuses a larger document (MAX_DOCUMENT_BYTES in work_ledger_ingest.py).
max_document_bytes=1048576

# Whether a document is sent.
# input:  a file path, the SSO user
# output: one line on stdout - "ok", "note:<text>" to send it with <text> on its line, or the
#         reason not to send it
document_verdict() {
  local file="$1" user="$2" name="${1##*/}"
  if [[ ! $name =~ ^[A-Za-z0-9._@+-]+\.json$ ]]; then
    printf 'the file name has characters an S3 key here does not take\n'
    return
  fi
  local size
  size="$(wc -c <"$file" | tr -d ' ')"
  if ((size > max_document_bytes)); then
    printf '%s bytes, more than the %s the ledger reads\n' "$size" "$max_document_bytes"
    return
  fi
  # Slurped, so that an empty file (left by a write that crashed) or two documents in one file
  # is refused as a whole: plain jq prints nothing for the first and a verdict per document for the second.
  jq -r -s --arg user "$user" '
    if length != 1 then "not a JSON document"
    else .[0] |
      if type != "object" or .schema_version != 1 then "schema_version is not 1"
      elif (.identity.developer | type) != "string" then "note:identity.developer is missing"
      elif (.identity.developer | ascii_downcase) != ($user | ascii_downcase)
        then "note:identity.developer is \(.identity.developer), not \($user)"
      else "ok" end
    end' "$file" 2>/dev/null || printf 'not a JSON document\n'
}

# Sends one document unless its key exists already. The one place where the write condition
# lives: S3 answers 412 PreconditionFailed for a key that is there.
# output: "sent", "present" or "failed: <reason>"
send_document() {
  local file="$1" key="$2" answer
  if answer="$(aws s3api put-object --bucket "$bucket" --key "$key" --body "$file" \
    --if-none-match '*' --content-type application/json --output json ${profile_args[@]+"${profile_args[@]}"} 2>&1)"; then
    printf 'sent\n'
  elif [[ $answer == *PreconditionFailed* || $answer == *"(412)"* ]]; then
    printf 'present\n'
  else
    printf 'failed: %s\n' "$(grep -v '^[[:space:]]*$' <<<"$answer" | tail -n 1)"
  fi
}

# A literal ~ for the reader: the line goes to logs, where a home path would name the user.
home_dir="${HOME%/}"
shown_dir="$export_dir"
if [[ -n $home_dir ]]; then
  if [[ $shown_dir == "$home_dir" || $shown_dir == "$home_dir/" ]]; then
    shown_dir="~"
  elif [[ $shown_dir == "$home_dir"/* ]]; then
    # shellcheck disable=SC2088
    shown_dir="~/${shown_dir#"$home_dir"/}"
  fi
fi
printf '%s: reading %s\n' "$program" "$shown_dir"

sent=0 present=0 skipped=0 failed=0 would_send=0 sent_noted=0 would_send_noted=0
shopt -s nullglob
for file in "$export_dir"/*.json; do
  [[ -f $file ]] || continue
  name="${file##*/}"
  verdict="$(document_verdict "$file" "$sso_user")"
  note=""
  case "$verdict" in
  ok) ;;
  note:*) note=" (${verdict#note:})" ;;
  *)
    printf 'skipped     %s: %s\n' "$name" "$verdict"
    skipped=$((skipped + 1))
    continue
    ;;
  esac
  key="$key_prefix$name"
  if $dry_run; then
    printf 'would send  %s -> s3://%s/%s%s\n' "$name" "$bucket" "$key" "$note"
    would_send=$((would_send + 1))
    [[ -z $note ]] || would_send_noted=$((would_send_noted + 1))
    continue
  fi
  outcome="$(send_document "$file" "$key")"
  case "$outcome" in
  sent)
    sent=$((sent + 1))
    [[ -z $note ]] || sent_noted=$((sent_noted + 1))
    ;;
  present) present=$((present + 1)) ;;
  *) failed=$((failed + 1)) ;;
  esac
  printf '%-11s %s%s%s\n' "${outcome%%:*}" "$name" "${outcome#"${outcome%%:*}"}" "$note"
done

if $dry_run; then
  printf '%s: dry run as %s, %d would send (%d noted), %d skipped, nothing sent\n' \
    "$program" "$sso_user" "$would_send" "$would_send_noted" "$skipped"
  exit 0
fi
printf '%s: as %s, %d sent (%d noted), %d present, %d skipped, %d failed\n' \
  "$program" "$sso_user" "$sent" "$sent_noted" "$present" "$skipped" "$failed"
((failed == 0)) || exit 4
