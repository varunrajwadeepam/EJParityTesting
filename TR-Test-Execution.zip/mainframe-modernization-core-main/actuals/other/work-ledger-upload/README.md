# Sending your checkpoint exports to the work ledger

> **Who this guide is for:** a developer whose session tracker writes checkpoint export documents,
> one small JSON file per checkpoint in `~/.claude/checkpoint-export/`, and who signs in to the
> project's AWS account with the permission set **User**. No checkout is needed: the uploader is
> one file in this directory, downloaded or copied from a clone. Everything you need is in this
> document.

The files here are a copy, kept by the platform team: see [Source](#source) before changing one.

## What it does, and what it does not

The uploader sends each export document to the work ledger's bucket, under a prefix that only your
own SSO session can write to. A function turns every document into the figures of the
`WorkLedger-By-Work-Phase` dashboard in CloudWatch: cost, tokens and active hours per developer, work
id, phase, model and project.

| It does | It does not |
| :--- | :--- |
| send each document once; a document already in the bucket is reported as `present` | change, move or delete a file in your export directory |
| skip a document it cannot read - not one JSON document, `schema_version` not 1, over 1 MiB - and say why | replace a document in the bucket: nobody but an administrator can |
| send a document whose `identity.developer` is not your SSO user, noting the difference on its line: the key proves who sent it | count a document under the name inside it: the dashboard takes your name from your SSO session |
| work the same from a terminal, cron or Task Scheduler, and from several sessions at once | keep any state of its own: every run offers every file, and the bucket answers for the ones it has |

**Everyone who views the dashboard sees everyone's figures**, as on the existing usage dashboard.
The documents themselves are read only by the ingest function and the administrators.

**Platform:** macOS, Ubuntu Linux or WSL2 with `work-ledger-upload.sh` (bash, the AWS CLI v2,
`jq`); Windows with `work-ledger-upload.ps1` (Windows PowerShell 5.1, the AWS CLI v2). The two take
the same options, print the same lines and exit with the same codes.

## Part 1 - once, on a new machine

### Step 1. Check the tools

**Where:** your machine, any terminal; on Windows, PowerShell.

Purpose: confirm that the AWS CLI v2 is installed.

```
aws --version
```

Purpose, bash only: confirm that `jq` is installed.

```
jq --version
```

**Expected:** `aws-cli/2.…` - 2.27 and later are known to work, and the uploader itself says so if
yours is too old for conditional writes; `jq-1.6` or later.

**If one is missing or older,** install it, then repeat this step.

- AWS CLI v2, macOS: `brew install awscli`; Ubuntu / WSL and Windows: the installer from the AWS CLI
  user guide, "Installing or updating to the latest version of the AWS CLI".
- jq, macOS: `brew install jq`; Ubuntu / WSL: `sudo apt-get install -y jq`.

Purpose: confirm that your session tracker writes checkpoint exports - they are what the uploader
sends. bash:

```
ls ~/.claude/scripts/checkpoint_export.py
```

Windows PowerShell:

```
Test-Path "$env:USERPROFILE\.claude\scripts\checkpoint_export.py"
```

**Expected:** the path printed; on Windows `True`.

**If it is missing** (`No such file or directory`, `False`), the tracker on this machine is a version
without checkpoint export, and there is nothing to send. Install the current one from this
repository, `actuals/other/claude-session-tracker/`, as the **Install** section of its README says,
then repeat this check.

### Step 2. Find your SSO profile with the permission set User

**Where:** your machine, any terminal.

Purpose: find the AWS profile you sign in with - the project's account, permission set **User**.

```
aws configure list-profiles
```

Purpose: confirm the role behind a candidate profile.

```
aws sts get-caller-identity --profile <your-sso-profile> --query Arn --output text
```

**Expected:** `arn:aws:sts::<account-id>:assumed-role/AWSReservedSSO_User_<hash>/<you>@<corp-domain>`.
Use that profile's name wherever this guide says `<your-sso-profile>`. If the call answers
`Token has expired`, run step 4 first and come back. The permission set **Administrator**
(`AWSReservedSSO_Administrator_<hash>`) is accepted too, if that is the one you have; this guide says
User for either.

**Not the Bedrock profile.** A profile whose role is `BedrokLLMAccess` - often the one Claude Code
uses - will not do: there the session name is chosen by the client, so it cannot prove who sent a
document, and the uploader refuses it with exit code 3. Claude Code's Bedrock setup writes
`AWS_PROFILE` naming that profile into `~/.claude/settings.json`, so every command Claude Code runs
gets it, and an uploader given no profile would use it: name yours with `--profile`, or once with
`WORK_LEDGER_PROFILE` in step 3.

**If there is no User profile,** create one. On macOS and Windows the browser opens by itself; on WSL add
`--use-device-code` and open the printed address in the Windows browser.

Purpose: create the SSO profile, answering the prompts listed below.

```
aws configure sso --profile <your-sso-profile>
```

The prompts: a short SSO session name of your choice; the SSO start URL you were given for the
company's AWS access portal; SSO region `us-east-1`; registration scopes - press Enter; allow access
in the browser; choose the project's account and the role **User**; default region `us-east-1`;
output format `json`.

### Step 3. Put the uploader on your machine

**Where:** your machine, the browser and a terminal; on Windows, PowerShell.

Purpose: create the directory the file goes into, if it is not there yet. bash:

```
mkdir -p ~/.local/bin
```

Windows PowerShell:

```
New-Item -ItemType Directory -Force "$env:USERPROFILE\bin" | Out-Null
```

Purpose: get the one file for your platform. In this repository's web page, open the file in
`actuals/other/work-ledger-upload/` and use **Download** (or **Raw**, then save):

- macOS, Linux, WSL: `work-ledger-upload.sh`, saved as `~/.local/bin/work-ledger-upload.sh`;
- Windows: `work-ledger-upload.ps1`, saved as `%USERPROFILE%\bin\work-ledger-upload.ps1`.

Purpose, instead of the download if you have a clone of the repository: copy the same file from it
to the same place, which the commands of this guide expect. After a `git pull`, copy it again.
`<clone>` is the clone's directory. bash:

```
cp <clone>/actuals/other/work-ledger-upload/work-ledger-upload.sh ~/.local/bin/
```

Windows PowerShell:

```
Copy-Item "<clone>\actuals\other\work-ledger-upload\work-ledger-upload.ps1" "$env:USERPROFILE\bin\"
```

Purpose, bash: make it executable.

```
chmod +x ~/.local/bin/work-ledger-upload.sh
```

Purpose, Linux and WSL: confirm that the file arrived whole.

```
sha256sum ~/.local/bin/work-ledger-upload.sh
```

Purpose, macOS: the same check.

```
shasum -a 256 ~/.local/bin/work-ledger-upload.sh
```

Purpose, Windows PowerShell: the same check, printed in lower case as in the table.

```
(Get-FileHash "$env:USERPROFILE\bin\work-ledger-upload.ps1").Hash.ToLower()
```

**Expected:** the sum for your file in [Source](#source).
**A different sum** means the file was changed on the way, most often its line endings: do not run
it; download it again with **Download**, not by copying the text.

Purpose, Windows PowerShell: drop the "downloaded from the internet" mark, which would otherwise
stop the script under the default execution policy.

```
Unblock-File "$env:USERPROFILE\bin\work-ledger-upload.ps1"
```

Purpose: confirm that it runs. bash:

```
~/.local/bin/work-ledger-upload.sh --help
```

Windows PowerShell:

```
powershell -ExecutionPolicy Bypass -File "$env:USERPROFILE\bin\work-ledger-upload.ps1" -Help
```

**Expected:** the help text, ending with `EXIT CODES` and the codes 0-4.

Purpose, optional: run it by name, as `work-ledger-upload.sh`. Ubuntu and WSL put `~/.local/bin` on the
`PATH` of a new login terminal once the directory exists; on macOS, or if `command -v work-ledger-upload.sh`
prints nothing in a new terminal, add it to your shell profile. The commands in this guide keep the full path,
so they work either way.

Purpose, Ubuntu and WSL (bash): add `~/.local/bin` to the `PATH`.

```
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
```

Purpose, macOS (zsh): add `~/.local/bin` to the `PATH`.

```
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.zshrc
```

**Expected:** in a new terminal, `command -v work-ledger-upload.sh` prints its path.

Purpose, optional: name your profile once, so that the uploader needs no `--profile` from then on.
`WORK_LEDGER_PROFILE` is read by the uploader only, so `AWS_PROFILE` stays free for your other tools.
bash:

```
echo 'export WORK_LEDGER_PROFILE=<your-sso-profile>' >> ~/.bashrc
```

Windows PowerShell, as a user environment variable:

```
[Environment]::SetEnvironmentVariable('WORK_LEDGER_PROFILE', '<your-sso-profile>', 'User')
```

**Expected:** in a new terminal, `echo $WORK_LEDGER_PROFILE` (on Windows `$env:WORK_LEDGER_PROFILE`)
prints the profile name. A terminal gets its variables from the program that starts it, so one opened
from a terminal app or an IDE that was already running may still print nothing: see
[When something fails](#when-something-fails).

## Part 2 - every time you send

### Step 4. Sign in to SSO

**Where:** your machine, any terminal.

Purpose: get a fresh SSO session for the upload. On WSL add `--use-device-code`. The AWS CLI does
not read `WORK_LEDGER_PROFILE`: with it set, `aws sso login --profile "$WORK_LEDGER_PROFILE"`, in
PowerShell `aws sso login --profile $env:WORK_LEDGER_PROFILE`.

```
aws sso login --profile <your-sso-profile>
```

**Expected:** `Successfully logged into Start URL: …`.

### Step 5. Look first

**Where:** your machine, any terminal.

Purpose: check the session and every document and see where each would go, sending nothing.
With `WORK_LEDGER_PROFILE` set in step 3, leave out `--profile` (`-Profile`) here and in step 6. bash:

```
~/.local/bin/work-ledger-upload.sh --profile <your-sso-profile> --dry-run
```

Windows PowerShell:

```
powershell -ExecutionPolicy Bypass -File "$env:USERPROFILE\bin\work-ledger-upload.ps1" -Profile <your-sso-profile> -DryRun
```

**Expected:** a first line `work-ledger-upload.sh: reading ~/.claude/checkpoint-export` - the directory it
read, which `--dir` changes; on Windows `~\.claude\checkpoint-export` - then one `would send <file> -> s3://work-ledger-raw-<account-id>/raw/<role id>:<you>@<corp-domain>/<file>`
line per document, perhaps some `skipped <file>: <reason>` lines, and a last line
`work-ledger-upload.sh: dry run as <you>@<corp-domain>, N would send (K noted), M skipped, nothing sent`;
exit code 0. A `skipped` line is not an error: read its reason in [When something fails](#when-something-fails).

### Step 6. Send

**Where:** your machine, any terminal.

Purpose: send the documents the bucket does not have yet. bash:

```
~/.local/bin/work-ledger-upload.sh --profile <your-sso-profile>
```

Windows PowerShell:

```
powershell -ExecutionPolicy Bypass -File "$env:USERPROFILE\bin\work-ledger-upload.ps1" -Profile <your-sso-profile>
```

**Expected:** the same `reading` line, then `sent <file>` for each new document, `present <file>` for each one sent before, and a
last line `work-ledger-upload.sh: as <you>@<corp-domain>, N sent (K noted), P present, M skipped, 0 failed`;
exit code 0. `K noted` counts the documents sent with a note on their line; above 0, read that note in [When something fails](#when-something-fails). Run it again and every `sent` becomes `present`.

**If the last line counts a failure** (exit code 4), the `failed <file>: <reason>` lines say why;
run step 6 again later and it sends what is missing.

### Step 7. Find your figures on the dashboard

**Where:** the AWS console, under the role **`BedrokLLMAccess`**, as for the usage dashboard: from your
User session, **Switch role** to it. The permission set **User**, which sends in step 6, cannot open
CloudWatch dashboards.

Purpose: confirm that the documents arrived. Open CloudWatch, **Dashboards**,
`WorkLedger-By-Work-Phase-OneQuery` - in us-east-1,
[this link](https://us-east-1.console.aws.amazon.com/cloudwatch/home?region=us-east-1#dashboards/dashboard/WorkLedger-By-Work-Phase-OneQuery) -
and set the time range to cover your sessions. Take the link rather than a search for "Dashboards": the
search also offers the **Dashboards** of Billing and Cost Management, another service, where this one is not.
The first time, the console asks before it runs the dashboard's
function, **Invoke Lambda function**: allow it, for this dashboard, once or always.

**Expected:** your developer name - your SSO user before the `@` - in the tables, a minute or so after
step 6, every table at once within a few seconds. A session counts in the time range of its latest checkpoint,
at the time the tracker wrote it.

`WorkLedger-By-Work-Phase` shows the same figures with one widget per table, which the console fills a few at a
time: it is slower, and asks nothing.

To narrow the tables, type into the filters at the top - developer, model, project, work id, phase. Each is a
regular expression matched against the whole value, ignoring case: `.*` for everything, `<work id>` for one work,
`<project>-.*` for every work id that starts with `<project>-`. A filter must not contain `/`.

## Part 3 - optional: send on a schedule

Uploads are safe to repeat, so a schedule only needs to run the command of step 6. An SSO session
expires after the duration the access portal sets; a run after that exits with code 2 and sends
nothing, and the first run after your next `aws sso login` catches up.

Purpose, macOS / Linux / WSL: run at 10:00, 14:00 and 18:00. Add this line with `crontab -e`; cron
does not read `~/.bashrc`, so the line names the profile itself.

```
0 10,14,18 * * * WORK_LEDGER_PROFILE=<your-sso-profile> $HOME/.local/bin/work-ledger-upload.sh >>$HOME/work-ledger-upload.log 2>&1
```

Purpose, Windows: the same times through Task Scheduler.

```
schtasks /Create /TN work-ledger-upload /SC DAILY /ST 10:00 /RI 240 /DU 09:00 /TR "powershell -NoProfile -ExecutionPolicy Bypass -File %USERPROFILE%\bin\work-ledger-upload.ps1 -Profile <your-sso-profile>"
```

**Expected:** `crontab -l` lists the line; on Windows, `SUCCESS: The scheduled task "work-ledger-upload" has successfully been created.`

## The uploader in short

| | bash | PowerShell | Default |
| :--- | :--- | :--- | :--- |
| profile | `--profile <name>` | `-Profile <name>` | `WORK_LEDGER_PROFILE`, else `AWS_PROFILE`, else the CLI default |
| export directory | `--dir <directory>` | `-Dir <directory>` | `CLAUDE_CHECKPOINT_EXPORT_DIR`, else `~/.claude/checkpoint-export` |
| look, send nothing | `--dry-run` | `-DryRun` | off |
| help | `-h`, `--help` | `-Help`, `-h`, `--help` | |

`WORK_LEDGER_BUCKET` names another bucket; the default is `work-ledger-raw-<account of the session>`.

| Exit code | Meaning |
| :--- | :--- |
| 0 | every document that qualifies was sent or was already there; skipped files are listed |
| 1 | usage or environment: unknown option, `aws` or `jq` missing, an AWS CLI too old, no such directory, unknown profile, AWS unreachable |
| 2 | no valid SSO session: step 4 |
| 3 | the session is not your SSO session with User or Administrator, for example `BedrokLLMAccess`; the profiles of this account that would do are listed by name under the message: step 2 |
| 4 | some documents could not be sent: step 6 again later |

## When something fails

| What you see | Step | What it means, and what to do |
| :--- | :--- | :--- |
| `command not found` for `aws` or `jq`, exit code 1 | any | the tool is missing: step 1 |
| `has no --if-none-match for put-object`, exit code 1 | 5, 6 | the AWS CLI is too old: update it, step 1 |
| `The config profile (…) could not be found`, exit code 1 | 2, 5, 6 | the profile name is mistyped or the profile does not exist on this machine - the line above names it and where it came from: step 2 |
| `no such directory`, exit code 1 | 5, 6 | the tracker has not exported anything yet, or writes elsewhere: give that directory with `--dir`; or it is a version without checkpoint export: step 1 |
| `Token has expired`, `no valid SSO session`, exit code 2 | 2, 5, 6 | the SSO session expired: step 4 |
| `this is a BedrokLLMAccess session`, exit code 3 | 5, 6 | the profile is the Bedrock one - the line above the message names it and says where it came from: `--profile`, `WORK_LEDGER_PROFILE` or `AWS_PROFILE`. Use one of the profiles listed under the message, or create one, step 2 |
| `(WORK_LEDGER_PROFILE is not set in this terminal)` above the message, though you set it | 5, 6 | this terminal does not see the variable. Check with `echo $WORK_LEDGER_PROFILE`, on Windows `$env:WORK_LEDGER_PROFILE`: empty means the terminal was started before the variable was set, or by a program that was - a terminal app, an IDE, Claude Code. Close every window of that program and open a new terminal from the Start menu or the Dock, or sign out and in again; until then give the profile with `--profile` (`-Profile`) |
| `not an SSO session of the permission set User`, exit code 3 | 5, 6 | another role or permission set: use one of the profiles listed under the message, or step 2 |
| `no profile in … has the permission set User or Administrator for this account`, exit code 3 | 5, 6 | this machine has no profile of this account that would do: create one, step 2 |
| `sent …` or `would send …` with `(identity.developer is …, not …)`; a summary with `(K noted)` above 0 | 5, 6 | the tracker named you after another identity: your git e-mail, git name or OS login, as it does on Linux and WSL when `CLAUDE_USER` is not set, or on macOS and Windows the e-mail of the OS account, which comes before `CLAUDE_USER`. The document is sent and counted under your SSO user all the same. See which it was with `python ~/.claude/scripts/developer_identity.py --fresh`, which changes nothing: `source: os-account` or `source: os-login-email` means `CLAUDE_USER` cannot change the name, so tell the platform team and attach that output. Otherwise, for the next documents, set `CLAUDE_USER=<you>@<corp-domain>` in your shell profile - on Windows, as a user environment variable - open a new terminal and run the check again: it prints your address with `source: CLAUDE_USER`. Then quit every running Claude Code, the IDE extensions and the desktop app included, delete the tracker's cached identity - `rm ~/.claude/stat-cache/developer.json`, on Windows `Remove-Item "$env:USERPROFILE\.claude\stat-cache\developer.json"` - and start Claude Code from that terminal, an IDE or the desktop app too, since one started from the Dock or the Start menu may not see a variable set in the shell profile: the tracker keeps the identity it found in that file for 24 hours, and a Claude Code started before `CLAUDE_USER` was set writes the old name there again, so without both the old name stays for up to a day. Documents already written keep the old name |
| `skipped …: schema_version is not 1` | 5, 6 | a document from a tracker version this ledger does not read yet: tell the platform team |
| `skipped …: not a JSON document` | 5, 6 | the file is damaged or still being written: it is skipped until the tracker writes a whole one |
| `failed …: … (AccessDenied) …`, exit code 4 | 6 | the bucket refused the write - usually a session that is not your own SSO session; if step 2 shows User, tell the platform team with the line |
| `AWS cannot be reached from here`, exit code 1; `failed …: Could not connect to the endpoint URL`, exit code 4 | 5, 6 | no network to AWS, or a proxy in the way: check it, then the step again |
| `skipped …: … bytes, more than the 1048576 the ledger reads` | 5, 6 | the document is larger than the ledger reads: tell the platform team |
| `not authorized`, `AccessDenied`, or no `WorkLedger-` dashboard in the list | 7 | the console is under the permission set User, or the page is the Billing and Cost Management **Dashboards**: switch role to `BedrokLLMAccess` and open the link in step 7 |
| the OneQuery dashboard shows a message in place of the tables | 7 | read its reason: a query not complete within 20 seconds, or figures marked incomplete at 10,000 rows - narrow the time range or a filter; for any other reason use `WorkLedger-By-Work-Phase` and tell the platform team with the message |
| your name is not on the dashboard | 7 | widen the time range; if the documents were `sent`, tell the platform team - it may have refused them, which the dashboard's Rejected table shows |

## Source

The uploaders and this guide are maintained, with their tests, in the platform team's infrastructure
repository; this directory holds a copy of them as of its commit `3adbdd6`. **Do not change the copy
here**: a change made only here is lost at the next update and is not covered by the tests. Send it to
the platform team instead, who change the source and update this directory from it.

| File | Source in the infrastructure repository | sha256 |
| :--- | :--- | :--- |
| `work-ledger-upload.sh` | `scripts/src/bash/work-ledger/work-ledger-upload.sh` | `9e29f6dcb1cf49b7ea13fa9eed5786a802c7157527bae01893134619fb37129b` |
| `work-ledger-upload.ps1` | `scripts/src/powershell/work-ledger/work-ledger-upload.ps1` | `8915ffbd69db9e263f83f5920e25d684b8763d711807386a934f934d02a15e9b` |
| `README.md` | `docs/guides/work-ledger-upload.md`, with the opening note, steps 1 and 3 and this section adapted | |

`Get-FileHash` without `.ToLower()` prints the sum in upper case; it is the same sum. The sums hold for **Download**, **Raw**
and a git checkout alike: the `.gitattributes` in this directory keeps `work-ledger-upload.ps1` with LF
line endings, as its source has them, where the repository's root rule would write CRLF for `*.ps1`.
