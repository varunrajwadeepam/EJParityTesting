# Sends the session tracker's checkpoint export documents to the work-ledger bucket. The Windows
# twin of scripts/src/bash/work-ledger/work-ledger-upload.sh: the same options, output and exit
# codes. One file, no dependency on the rest of this repository. See -Help.
#
# Dot-sourcing it defines the functions and runs nothing, which is how the Pester tests replace
# Invoke-AwsCli; run as a script it uploads and exits with the code.
[CmdletBinding()]
param(
    [string] $Profile,
    [string] $Dir,
    [switch] $DryRun,
    [Alias('h')]
    [switch] $Help,
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]] $Rest
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$script:ProgramName = 'work-ledger-upload.ps1'

$script:UsageText = @'
work-ledger-upload.ps1 - send the session tracker's checkpoint export documents
to the work-ledger bucket. Writes only new objects to S3; never changes, moves
or deletes a local file. With -DryRun it writes nothing at all.

USAGE
  work-ledger-upload.ps1 [-Profile <name>] [-Dir <directory>] [-DryRun]

OPTIONS
  -Profile <name>   the AWS CLI profile of your own SSO session, permission set
                    User   (default: $env:WORK_LEDGER_PROFILE, else $env:AWS_PROFILE,
                            else the CLI default)
  -Dir <directory>  where the tracker writes its export documents
                    (default: $env:CLAUDE_CHECKPOINT_EXPORT_DIR,
                     else $HOME\.claude\checkpoint-export)
  -DryRun           check the session and every document, print the S3 key
                    each would get, send nothing
  -Help, -h, --help this text

ENVIRONMENT
  WORK_LEDGER_PROFILE           the profile when -Profile is not given; set it
                                once, so that AWS_PROFILE stays free for other
                                tools                       (default: unset)
  AWS_PROFILE                   read by the AWS CLI when neither is given; named
                                here only on the failures below
  AWS_CONFIG_FILE               where the profiles listed on exit 3 are looked
                                up, as the AWS CLI does
                                (default: $HOME\.aws\config)
  CLAUDE_CHECKPOINT_EXPORT_DIR  the tracker's export directory, as the tracker
                                itself reads it  (default: $HOME\.claude\checkpoint-export)
  WORK_LEDGER_BUCKET            the bucket       (default: work-ledger-raw-<account
                                                  of the session>)

WHAT IT DOES
  1. Asks AWS who the session is. Only an SSO session of the permission set
     User (or Administrator) is accepted: its session name is the SSO user and
     AWS sets it, which is what makes an upload attributable. A BedrokLLMAccess
     session is refused, because there the client chooses the session name.
  2. Checks each *.json in the directory: one JSON document, schema_version 1,
     at most 1 MiB. Any other file is skipped and the reason printed. A document
     whose identity.developer is not the SSO user of the session is still sent,
     with the difference noted on its line: who sent it is proven by the key, and
     the tracker may have named you after git or the OS login (see CLAUDE_USER).
  3. Sends each document to raw/<aws:userid>/<file name>, only if that key does
     not exist yet. A document already in the bucket is reported as present and
     counts as success, so running this again is always safe.

  First the directory read - "reading <directory>", with ~ for the home
  directory - then one line per file - sent, present, skipped: <reason>,
  failed: <reason>, or in a dry run would send - then a summary line, which
  also counts the sent documents that carry a note: the line a log is read by.

  When the profile is unknown (exit 1), the session is not valid (exit 2) or is
  not a developer's (exit 3), the first line says which profile the AWS CLI was
  given and where the name came from - -Profile, WORK_LEDGER_PROFILE,
  AWS_PROFILE, or none - and adds "WORK_LEDGER_PROFILE is not set in this
  terminal" when it is not.

EXAMPLES
  # Sign in, look first, then send.
  aws sso login --profile my-sso-user
  powershell -ExecutionPolicy Bypass -File work-ledger-upload.ps1 -Profile my-sso-user -DryRun
  powershell -ExecutionPolicy Bypass -File work-ledger-upload.ps1 -Profile my-sso-user

  # Name the profile once, for your user, and leave out -Profile from then on
  # (a new terminal sees it).
  [Environment]::SetEnvironmentVariable('WORK_LEDGER_PROFILE', 'my-sso-user', 'User')
  powershell -ExecutionPolicy Bypass -File work-ledger-upload.ps1 -DryRun

  # From Task Scheduler, three times a day; a failed run is retried by the next one.
  schtasks /Create /TN work-ledger-upload /SC DAILY /ST 10:00 /RI 240 /DU 09:00 /TR "powershell -NoProfile -ExecutionPolicy Bypass -File %USERPROFILE%\bin\work-ledger-upload.ps1 -Profile my-sso-user"

  # After a non-zero exit, decide on the code.
  powershell -File work-ledger-upload.ps1; if ($LASTEXITCODE -eq 2) { aws sso login --profile my-sso-user }

EXIT CODES
  0  every document that qualifies was sent or was already in the bucket;
     skipped files are listed above the summary
  1  usage or environment: unknown option, aws missing, an AWS CLI too old for
     conditional writes, the directory missing, the profile unknown,
     AWS unreachable
  2  no valid SSO session: sign in with aws sso login and run again
  3  the session is not a developer's SSO session, for example BedrokLLMAccess;
     the profiles in the AWS CLI config that would do are listed
  4  some documents could not be sent; the next run sends them
'@

# Runs the AWS CLI and keeps its two streams apart.
# input:  the CLI's arguments
# output: @{ ExitCode = <int>; StdOut = <string>; StdErr = <string> }
function Invoke-AwsCli {
    param([string[]] $Arguments)
    # Windows PowerShell turns each stderr line of a native program into an error record, and
    # under 'Stop' the first one would end the script.
    $ErrorActionPreference = 'Continue'
    $lines = & aws @Arguments 2>&1
    $code = $LASTEXITCODE
    $out = @($lines | Where-Object { $_ -isnot [System.Management.Automation.ErrorRecord] } | ForEach-Object { "$_" })
    # The line itself is the record's TargetObject: an empty line would otherwise turn into the text
    # "System.Management.Automation.RemoteException".
    $err = @($lines | Where-Object { $_ -is [System.Management.Automation.ErrorRecord] } |
            ForEach-Object { "$($_.TargetObject)" })
    @{ ExitCode = $code; StdOut = ($out -join "`n"); StdErr = ($err -join "`n") }
}

function Write-Failure {
    param([string] $Message)
    [Console]::Error.WriteLine("${script:ProgramName}: $Message")
}

# Which profile the AWS CLI was given and where its name came from, printed before the failures a
# wrong profile explains: an unknown profile, no valid session, not a developer session.
# AWS_PROFILE is read for this line only: the AWS CLI still chooses the profile itself.
function Write-ProfileSource {
    param([string] $Profile, [bool] $FromOption)
    $notSetNote = ''
    if (-not $env:WORK_LEDGER_PROFILE) { $notSetNote = ' (WORK_LEDGER_PROFILE is not set in this terminal)' }
    if ($Profile -and $FromOption) {
        Write-Failure "profile $Profile, from -Profile"
    } elseif ($Profile) {
        Write-Failure "profile $Profile, from WORK_LEDGER_PROFILE"
    } elseif ($env:AWS_PROFILE) {
        Write-Failure "profile $($env:AWS_PROFILE), from AWS_PROFILE$notSetNote"
    } else {
        Write-Failure "no profile given, the AWS CLI default$notSetNote"
    }
}

# The profiles of the AWS CLI config in this account whose permission set is User or Administrator.
# Read from the file rather than through `aws configure get`, which costs a process per profile.
# input:  the config path and the account of the current session
# output: one profile name per profile; nothing when the file is missing. Never the account ids: the
#         config may hold profiles of other accounts, and this goes to stderr and so to a log.
function Get-DeveloperSsoProfile {
    param([string] $ConfigPath, [string] $SessionAccount)
    if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) { return }
    $name = ''; $role = ''; $account = ''
    # A sentinel section at the end flushes the last profile like any other.
    foreach ($line in @(Get-Content -LiteralPath $ConfigPath) + '[end]') {
        $text = $line.Trim()
        if ($text -match '^[#;]') { continue }
        if ($text -match '^\[\s*(.*?)\s*\]$') {
            if ($name -and $account -ceq $SessionAccount -and ($role -ceq 'User' -or $role -ceq 'Administrator')) { $name }
            $header = $Matches[1]
            $role = ''; $account = ''
            if ($header -ceq 'default') { $name = 'default' }
            elseif ($header -cmatch '^profile\s+(.+)$') { $name = $Matches[1] }
            else { $name = '' }
            continue
        }
        if ($text -match '^([^=]+?)\s*=\s*(.*)$') {
            if ($Matches[1] -ceq 'sso_role_name') { $role = $Matches[2] }
            elseif ($Matches[1] -ceq 'sso_account_id') { $account = $Matches[2] }
        }
    }
}

function Write-NotDeveloperSession {
    param([string] $Message, [string] $SessionAccount, [string] $Profile, [bool] $ProfileFromOption)
    Write-ProfileSource -Profile $Profile -FromOption $ProfileFromOption
    Write-Failure $Message
    $configPath = $env:AWS_CONFIG_FILE
    if (-not $configPath) { $configPath = Join-Path (Join-Path $HOME '.aws') 'config' }
    $candidates = @(Get-DeveloperSsoProfile -ConfigPath $configPath -SessionAccount $SessionAccount)
    if ($candidates.Count -gt 0) {
        Write-Failure 'profiles here for this account with the permission set User or Administrator:'
        foreach ($candidate in $candidates) { [Console]::Error.WriteLine("  $candidate") }
        Write-Failure 'pass one with -Profile, or set WORK_LEDGER_PROFILE once'
    } else {
        Write-Failure "no profile in $configPath has the permission set User or Administrator for this account; create one with aws configure sso"
    }
}

# Whether a document is sent: 'ok', 'note:<text>' to send it with <text> on its line, or the
# reason not to send it.
function Get-DocumentVerdict {
    param([System.IO.FileInfo] $File, [string] $SsoUser)
    if ($File.Name -cnotmatch '^[A-Za-z0-9._@+-]+\.json$') {
        return 'the file name has characters an S3 key here does not take'
    }
    # The ingest function refuses a larger document (MAX_DOCUMENT_BYTES in work_ledger_ingest.py).
    $maxDocumentBytes = 1048576
    if ($File.Length -gt $maxDocumentBytes) {
        return "$($File.Length) bytes, more than the $maxDocumentBytes the ledger reads"
    }
    try {
        $document = Get-Content -LiteralPath $File.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
    } catch {
        return 'not a JSON document'
    }
    if ($null -eq $document -or $document -isnot [System.Management.Automation.PSCustomObject]) {
        return 'not a JSON document'
    }
    $schema = $document.PSObject.Properties['schema_version']
    if ($null -eq $schema -or $schema.Value -isnot [int] -or $schema.Value -ne 1) {
        return 'schema_version is not 1'
    }
    $identity = $document.PSObject.Properties['identity']
    $developer = $null
    if ($null -ne $identity -and $identity.Value -is [System.Management.Automation.PSCustomObject]) {
        $developerProperty = $identity.Value.PSObject.Properties['developer']
        if ($null -ne $developerProperty) { $developer = $developerProperty.Value }
    }
    if ($developer -isnot [string]) {
        return 'note:identity.developer is missing'
    }
    if (-not [string]::Equals($developer, $SsoUser, [System.StringComparison]::OrdinalIgnoreCase)) {
        return "note:identity.developer is $developer, not $SsoUser"
    }
    'ok'
}

# Sends one document unless its key exists already. The one place where the write condition
# lives: S3 answers 412 PreconditionFailed for a key that is there.
# output: 'sent', 'present' or 'failed: <reason>'
function Send-Document {
    param([string] $Bucket, [string] $Key, [string] $Path, [string[]] $ProfileArguments)
    $answer = Invoke-AwsCli (@('s3api', 'put-object', '--bucket', $Bucket, '--key', $Key, '--body', $Path,
            '--if-none-match', '*', '--content-type', 'application/json', '--output', 'json') + $ProfileArguments)
    if ($answer.ExitCode -eq 0) { return 'sent' }
    if ($answer.StdErr -match 'PreconditionFailed|\(412\)') { return 'present' }
    $reason = @($answer.StdErr -split "`n" | Where-Object { $_.Trim() -ne '' })
    if ($reason.Count -eq 0) { return "failed: the AWS CLI exited $($answer.ExitCode)" }
    "failed: $($reason[-1].Trim())"
}

# input: a directory as given and the home directory. output: the directory with ~ for the home
# directory, either separator accepted, so that the line a log keeps does not name the user; any other
# directory as given.
function Format-ShownDirectory([string] $Path, [string] $HomeDirectory) {
    $homeDir = ($HomeDirectory -replace '/', '\').TrimEnd('\')
    $dir = $Path -replace '/', '\'
    if (-not $homeDir) { return $Path }
    if ($dir.TrimEnd('\') -ieq $homeDir) { return '~' }
    if ($dir.StartsWith($homeDir + '\', [System.StringComparison]::OrdinalIgnoreCase)) {
        return '~' + $dir.Substring($homeDir.Length)
    }
    $Path
}

# The whole run. Writes the report lines to the output and returns nothing; the exit code is left
# in $script:ExitCode so that a test can read it without it mixing into the lines.
function Invoke-WorkLedgerUpload {
    param([string] $Profile, [string] $Dir, [switch] $DryRun, [switch] $Help, [string[]] $Rest)
    $script:ExitCode = 0

    if ($Help -or ($Rest -contains '--help') -or ($Rest -contains '-h')) {
        $script:UsageText
        return
    }
    if ($Rest) {
        Write-Failure "unknown argument: $($Rest[0]); see -Help"
        $script:ExitCode = 1
        return
    }
    if (-not (Get-Command aws -ErrorAction SilentlyContinue)) {
        Write-Failure 'the AWS CLI v2 (aws) is not installed'
        $script:ExitCode = 1
        return
    }

    $exportDir = $Dir
    if (-not $exportDir) { $exportDir = $env:CLAUDE_CHECKPOINT_EXPORT_DIR }
    if (-not $exportDir) { $exportDir = Join-Path (Join-Path $HOME '.claude') 'checkpoint-export' }
    if (-not (Test-Path -LiteralPath $exportDir -PathType Container)) {
        Write-Failure "no such directory: $exportDir"
        $script:ExitCode = 1
        return
    }

    $profileFromOption = [bool] $Profile
    if (-not $Profile) { $Profile = $env:WORK_LEDGER_PROFILE }
    $profileArguments = @()
    if ($Profile) { $profileArguments = @('--profile', $Profile) }

    # Without --if-none-match the bucket refuses the write, so an older CLI would report every
    # document as failed; saying so once is clearer.
    $helpText = Invoke-AwsCli @('s3api', 'put-object', 'help')
    if ($helpText.StdOut -notmatch '--if-none-match') {
        Write-Failure 'this AWS CLI has no --if-none-match for put-object; update the AWS CLI v2'
        $script:ExitCode = 1
        return
    }

    $loginHint = 'aws sso login'
    if ($Profile) { $loginHint = "aws sso login --profile $Profile" }
    $identityAnswer = Invoke-AwsCli (@('sts', 'get-caller-identity', '--output', 'json') + $profileArguments)
    if ($identityAnswer.ExitCode -ne 0) {
        $unknownProfile = $identityAnswer.StdErr -match 'could not be found'
        $unreachable = -not $unknownProfile -and
            $identityAnswer.StdErr -cmatch 'Could not connect|Connect timeout|Read timeout|SSL|[Pp]roxy'
        if (-not $unreachable) { Write-ProfileSource -Profile $Profile -FromOption $profileFromOption }
        if ($identityAnswer.StdErr) { [Console]::Error.WriteLine($identityAnswer.StdErr) }
        if ($unknownProfile) {
            Write-Failure 'the AWS CLI does not know this profile'
            $script:ExitCode = 1
        } elseif ($unreachable) {
            Write-Failure 'AWS cannot be reached from here; check the network or the proxy'
            $script:ExitCode = 1
        } else {
            Write-Failure "no valid SSO session; run: $loginHint"
            $script:ExitCode = 2
        }
        return
    }
    try {
        $identity = $identityAnswer.StdOut | ConvertFrom-Json
        $account = [string] $identity.Account
        $userId = [string] $identity.UserId
        $arn = [string] $identity.Arn
    } catch {
        Write-ProfileSource -Profile $Profile -FromOption $profileFromOption
        Write-Failure "the AWS CLI did not return an identity; run: $loginHint"
        $script:ExitCode = 2
        return
    }

    # Arn of an SSO session: arn:aws:sts::<account>:assumed-role/<role name>/<SSO user>.
    # UserId: <role id>:<SSO user>, the value the bucket policy calls aws:userid.
    $arnParts = $arn -split '/'
    $roleName = ''
    if ($arnParts.Count -ge 2) { $roleName = $arnParts[1] }
    $separator = $userId.IndexOf(':')
    $ssoUser = ''
    if ($separator -ge 0) { $ssoUser = $userId.Substring($separator + 1) }

    if ($roleName -eq 'BedrokLLMAccess') {
        Write-NotDeveloperSession -SessionAccount $account -Profile $Profile -ProfileFromOption $profileFromOption 'this is a BedrokLLMAccess session, whose name the client chooses; use your SSO profile of the permission set User'
        $script:ExitCode = 3
        return
    }
    if ($arn -cnotmatch '^arn:aws:sts::[0-9]+:assumed-role/AWSReservedSSO_(User|Administrator)_[0-9A-Za-z]{16}/' -or -not $ssoUser) {
        Write-NotDeveloperSession -SessionAccount $account -Profile $Profile -ProfileFromOption $profileFromOption "the session is $roleName, not an SSO session of the permission set User; use your own SSO profile"
        $script:ExitCode = 3
        return
    }

    $bucket = $env:WORK_LEDGER_BUCKET
    if (-not $bucket) { $bucket = "work-ledger-raw-$account" }
    $keyPrefix = "raw/$userId/"

    '{0}: reading {1}' -f $script:ProgramName, (Format-ShownDirectory -Path $exportDir -HomeDirectory $HOME)

    $counts = @{ sent = 0; present = 0; skipped = 0; failed = 0; would = 0; sentNoted = 0; wouldNoted = 0 }
    # Matched here rather than with -Filter, whose wildcards follow the Windows file system's rules,
    # not the case-sensitive *.json of the bash twin.
    $files = @(Get-ChildItem -LiteralPath $exportDir -File | Where-Object { $_.Extension -ceq '.json' } |
            Sort-Object Name)
    foreach ($file in $files) {
        $verdict = Get-DocumentVerdict -File $file -SsoUser $ssoUser
        $note = ''
        if ($verdict.StartsWith('note:')) {
            $note = ' ({0})' -f $verdict.Substring(5)
        } elseif ($verdict -ne 'ok') {
            '{0,-11} {1}: {2}' -f 'skipped', $file.Name, $verdict
            $counts.skipped++
            continue
        }
        $key = $keyPrefix + $file.Name
        if ($DryRun) {
            '{0,-11} {1} -> s3://{2}/{3}{4}' -f 'would send', $file.Name, $bucket, $key, $note
            $counts.would++
            if ($note) { $counts.wouldNoted++ }
            continue
        }
        $outcome = Send-Document -Bucket $bucket -Key $key -Path $file.FullName -ProfileArguments $profileArguments
        $word = ($outcome -split ':', 2)[0]
        $counts[$word]++
        if ($word -eq 'sent' -and $note) { $counts.sentNoted++ }
        $detail = ''
        if ($outcome.Length -gt $word.Length) { $detail = $outcome.Substring($word.Length) }
        '{0,-11} {1}{2}{3}' -f $word, $file.Name, $detail, $note
    }

    if ($DryRun) {
        '{0}: dry run as {1}, {2} would send ({3} noted), {4} skipped, nothing sent' -f $script:ProgramName, $ssoUser,
            $counts.would, $counts.wouldNoted, $counts.skipped
        return
    }
    '{0}: as {1}, {2} sent ({3} noted), {4} present, {5} skipped, {6} failed' -f $script:ProgramName, $ssoUser,
        $counts.sent, $counts.sentNoted, $counts.present, $counts.skipped, $counts.failed
    if ($counts.failed -gt 0) { $script:ExitCode = 4 }
}

if ($MyInvocation.InvocationName -ne '.') {
    Invoke-WorkLedgerUpload -Profile $Profile -Dir $Dir -DryRun:$DryRun -Help:$Help -Rest $Rest
    exit $script:ExitCode
}
